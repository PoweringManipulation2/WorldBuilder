# Context Budget and Pruning

<!-- phase-contract --> Exit contract: run `python3 {baseDir}/scripts/phase_contract.py --build-state <build-state> --stage <context_budget_review>` before this stage's gate; rendered copies ship in the build's worker kit under `exit-contracts/`.
## Navigation

- [Authority](#authority)
- [Profiles](#profiles)
- [Budget model](#budget-model)
- [Activation simulations](#activation-simulations)
- [Generation enforcement](#generation-enforcement)
- [Pruning contract](#pruning-contract)
- [Protected architecture](#protected-architecture)
- [Commands](#commands)
- [Limitations](#limitations)

## Authority

Every current lorebook-bearing build freezes `artifacts/budget-plan.json` under `worldbuilder-budget-pruning-v1`. The plan is build-specific, hash-bound to the frozen default profile, and referenced by the manifest, generation assignments, phase metadata, planning receipt, output receipt, and audit seal.

Bounded source-set coverage and context pressure are separate. Never omit supported entities merely to make a budget report look smaller. Plan the declared supported scope first, then control active context through entry size, activation design, recursion, placement, priority, and receipt-bound pruning.

## Profiles

Simple Mode exposes one **Detail & Context Profile**:

- **Compact**: accepted alias `quick`. Favor concise entries and lower active-context targets without weakening protected coverage.
- **Recommended**: balanced default.
- **Maximum Detail**: accepted alias `full detail`. Increase supported depth while retaining hard context and activation limits.

Advanced Mode may select `automatic`, `review`, or `custom` budget policy. Custom exact token and layer targets require Advanced Mode and a reasoned override file. A profile is frozen per build; changing it invalidates downstream planning, assignments, phases, audits, and delivery lineage.

## Budget model

Track all of the following:

- Permanent card cost.
- Constant lore cost.
- Opening cost.
- Non-prompt cost.
- Largest direct activation.
- Recursive activation cost.
- Worst-case fan-out.
- Layer allocation.
- Era allocation.
- Per-entry soft and hard targets.
- Entry priority and insertion behavior.
- Total authored lore versus the active lorebook budget.

**Permanent, opening, and non-prompt card cost are three different meters, not one blended
total.** Only `description`, `personality`, `scenario`, `system_prompt`, and
`post_history_instructions` sit in the prompt on every turn, so only that sum (permanent card
cost) is capped against `permanent_card_target`/`permanent_card_hard`. `first_mes`, the single
active `alternate_greetings` entry (never the sum of all of them; only one swipe is ever live),
and `mes_example` are opening cost: chat history and example dialogue that scrolls or pushes out
over the conversation, not a fixed cost. It is reported and soft-warned against the same target,
but never blocks. `creator_notes` is non-prompt cost: SillyTavern displays it in the character
panel and never puts it into the prompt at all, so it is reported only and never capped or warned,
even when it is a large generated block.

WorldBuilder prefers an approved target-model or frontend token count when one is supplied, then a declared planning estimate. Otherwise it uses the deterministic fallback `ceil(UTF-8 bytes / 4)` with explicit uncertainty. Reports identify whether each value is measured, declared, or fallback-estimated. This provides stable local gates; it is not an exact tokenizer and must not be advertised as one.

Soft-target pressure creates warnings. Hard limits block planning, checkpoints, output validation, or delivery. Never silently truncate generated prose.

## Activation simulations

The budget gate always records seven representative simulations:

1. Major character.
2. Major location.
3. Faction.
4. Era keyword.
5. Common ambiguous term.
6. Relationship cluster.
7. Worst-case recursion path.

Simulations include constant entries, follow the frozen activation graph to the profile's bounded depth, and report activated UIDs, estimated tokens, target, hard limit, and pressure status. Optional edges are included in the worst-case path.

## Generation enforcement

Every assignment slice carries:

- `budget_plan_sha256`.
- Exact UID-scoped `budget_context`.
- Profile and estimator identity.
- Per-entry soft target and hard limit.
- Layer, era, priority, constant status, protected categories, and pruning eligibility.

Once research completes for a UID, `entry_cycle_gate.py` additionally computes `source_tokens` from the evidence just gathered, `compression_ratio` from the detail axis (absent on Maximum; see Profiles), and resolves `retention_ladder` for that UID. `target = clamp(source_tokens * compression_ratio, floor, ceiling)`; when the raw value would exceed ceiling, that is a split signal, never a truncation instruction. Workers must read the budget row before writing. `entry_cycle_gate.py` measures the actual checkpoint content before allowing the next UID. The phase gate requires the matching budget-plan hash and checkpoint evidence. Final-output validation repeats the checks against generated bytes and reruns the activation simulations with actual content estimates.

Content cut to fit is routed, never deleted: a validated overflow record (`source_uid`, `tier`, `claim_ids`, a one-line `descriptor`) points back into the evidence ledger. `phase_gate.py` aggregates overflow across a merge and reports how many entries had material scoped out.

## Approved deviations

An activation check exceeding headroom is a planning preference overage, not a spec or compatibility error. `analyze_manifest`/`analyze_output` offer structural options (deepen the graph, add inclusion groups, tighten keywords, raise the window or detail axis, or accept and record) before blocking. An explicit, human-attributed acceptance is recorded into the frozen plan (`record_approved_deviation`), never a runtime override, and covers only the measured value actually approved; a worse regression than what was approved is not silently waved through. Pruning receipts surface which deviations, if any, were in effect for that operation.

## Pruning contract

Prune in this order when justified:

1. Duplicate facts.
2. Repeated aliases.
3. Redundant anchors.
4. Broad keywords.
5. Low-value optional edges.
6. Repeated invariant prose.

Every pruning operation must produce a receipt that binds:

- Before and after paths and SHA-256 hashes.
- Before and after token estimates.
- Token and keyword deltas.
- Every affected UID.
- A reason, activation impact, and era impact for each change.
- Protected-removal approval when applicable.
- The current manifest and budget-plan hashes.

Preserve stable IDs and non-pruning settings. Do not quietly add entries, alter placement/runtime settings, or change unrelated entries while calling the operation pruning.

## Protected architecture

Never remove automatically:

- World invariants.
- Era isolation and future-prohibition content.
- Knowledge boundaries.
- Status changes.
- Identity-state distinctions.
- Required relationships.
- Required activation paths or graph-driving trigger terms.

A protected removal requires explicit human approval, a specific reason, and `protected_removal_approved: true` in that UID's declared change. Auditors must verify that scope, chronology, knowledge, identity, and required graph behavior survive.

## Commands

```bash
python3 scripts/budget_contract.py --build-state /path/to/build-state.json --stage planning
python3 scripts/budget_contract.py --build-state /path/to/build-state.json --stage output --output /path/to/final.json
python3 scripts/pruning_receipt.py \
  --build-state /path/to/build-state.json \
  --before /path/to/before.json \
  --after /path/to/after.json \
  --changes /path/to/pruning-changes.json
```

Use `lineage_invalidate.py --from-stage budget` before changing a frozen plan.

## Limitations

Local estimates do not prove exact model-tokenizer or live SillyTavern context behavior. Runtime-target-specific accounting and live prompt inspection remain later approved batches. Batch 7 owns target-neutral planning, generation pressure, protected pruning, receipts, and drift detection only.

## Dynamic-state preservation during pruning

Pruning must retain the dynamic-state plan hash and cannot silently remove a group member, greeting binding, filter target, automation/outlet binding, or protected deterministic entry. Any change to dynamic operations requires a new reviewed plan, invalidated downstream receipts, rerun activation/budget simulations, and a pruning receipt that states the semantic effect.

## Auto context-window checkpoint
Selecting `[auto]` is measurement-first, not a larger hidden fixed profile. `budget_plan.json` records `context_window_mode: auto` and `generation_unconstrained: true`; per-entry and activation ceilings are measurement-only during planning/generation. After merge, `merge_phases.py` freezes an immutable `context_budget_before` snapshot and records `merge_complete`, then stops before entry-name normalization.

Run `context_budget_review.py --build-state <state> report` to show the measured entry count, total authored tokens, constant/permanent/opening cost, and worst-case activation cost. The user may keep the result or set/refine a target. If pruning is requested, use the existing Analyze -> Select -> Apply -> Prove machinery in `prune_workflow.py`; do not invent a second pruning implementation. Frozen `pruning_objectives` may add a soft preservation adjustment to candidate review order using those same activation simulations, but never manufacture projected savings or change runtime drop order. Pass the chosen Detail profile into drop-order scoring: Compact favors smaller entries among otherwise-equal runtime priority; Maximum Detail favors richer entries; runtime/default behavior preserves SillyTavern's weight/order/UID sort.

Record the decision with `context_budget_review.py ... record --decision keep` or `--decision prune --target-tokens N`. The script freezes an immutable `context_budget_after` snapshot and advances the skippable `context_budget_review` stage. Only then normalize entry names and run the post-generation audit. Fixed/legacy context-window builds auto-record this stage as `not_required`.

For an `auto` review decision of `prune`, do not hand-edit and merely claim success. Run the existing `prune_workflow.py` Analyze -> Select -> Apply -> Prove flow, save its `worldbuilder-prune-prove-v1` proof inside the build workspace, then record the checkpoint with `context_budget_review.py ... record --decision prune --target-tokens <n> --prune-proof <path>`. A `keep` decision is accepted only while the working merged artifact still matches the immutable pre-review snapshot.
