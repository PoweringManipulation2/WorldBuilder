# Info Mode
## Navigation
- [Purpose](#purpose)
- [Info home contract](#info-home-contract)
- [Available tabs](#available-tabs)
- [Tab routing](#tab-routing)
- [Tab content requirements](#tab-content-requirements)
- [Special questions](#special-questions)
- [Source policy](#source-policy)
## Purpose
Provide a menu-guided documentation hub for WorldBuilder. Info Mode explains how to begin, what each feature does, how the pipelines work, where files are stored, how SearXNG recovery works, and how to troubleshoot common problems. Do not generate an artifact unless the user explicitly asks to leave Info Mode and begin a build.
## Info home contract
When the user selects `Info`, `Help`, `Documentation`, or an equivalent request without naming a topic, display this complete menu and end with `Any special questions?`.
```text
📚 WORLDBUILDER INFO
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
1. 🚀 Where to Start
2. 🧭 Build Modes
3. 🪟 Card Fields & Routing
4. 🧍 Character Architecture
5. 🕰️ Eras & Timeline Isolation
6. 🗝️ Keywords & Filters
7. 🕸️ Activation & Recursion
8. 📍 Placement & Influence
9. 📊 Budgets & Pruning
10. 🌀 Dynamic State & Variation
11. 📦 Output Formats & Compatibility
12. 🧰 Troubleshooting
13. 🧠 Design Decisions & Why
14. 📖 Glossary
Say the number or tab name. Say “Info Home” or “Back” to return here.
Any special questions?
```
Do not replace this menu with an open-ended explanation or dump every tab at once.
## Available tabs
### Where to Start
Explain first-time setup, the approved WorldBuilder workspace, Config & Models, optional SearXNG/WARP research preflight, paged settings, planning, per-UID research, generation, audit, target conversion, ordered pipeline-stage receipts, delivery, and Batch 10 integration acceptance. Mention Workspace & Build Files and explain where `config.json`, `build-state.json`, `artifacts/`, `creations/`, and `.work/` live. End with `Any special questions?`.
### Build Modes
Document Character, World, Lorebook, Group Chat, Persona, Soul Extractor, Audit, Behavioral Test-drive, Prune, Iteration, Update/Merge, Image Prompts, Quick Build, Full Detail, Multi-era, and resume/recovery. Cover the four source kinds, including `existing-lorebook`: an additive build imports at `unverified` confidence, enters blast-radius verification triage, and generates only the delta. Explain that importing verifies nothing, so imported material is never trusted by default. Explain which modes create artifacts and which are utilities. Include the former Workers, Batching & Recovery topics: bird labels, the health-gated adaptive discovery ramp (tested defaults 4 → 10 → 20), the configurable 1-50 generation ceiling (15 by default), workload-aware partitioning, independent or consolidated four-lens audits, interleaved research/write checkpoints, targeted recovery, and `continue [name]`. End with `Any special questions?`.
Iteration, Update/Merge, and Audit share one toolkit rather than each growing its own: `capability_tiers.py` reports an artifact's tier (Unbound/Legacy-bound/Bound) up front; `artifact_edit.py` is the sanctioned way to change it (set-field, add-entry, remove-entry, move-depth, retag-keys); `artifact_diff.py` proves what actually changed, structurally, against a baseline; `change_set.py` and `manifest_amendment.py` extend the same discipline to Update/Merge's manifest changes specifically. Unbound is not a degraded starting point: structural edit, diff proof, format validation, and import probe all work on a hand-made or third-party lorebook with no WorldBuilder history at all; capability only grows from a live, verified workspace match, never from a marker's own claim. Since Batch 11, these five tool modes plus Convert and Art are grouped under one Tools entry point (`settings-menu.md` § Tools submenu) rather than scattered across the greeting individually; each card states its needed tier up front, verified against `capability_tiers.py`'s own `TIER_CAPABILITIES` (Audit/Prune/Iterate/Convert/Art need only Unbound; Update/Merge needs Legacy-bound, since folding in material without losing IDs requires a prior tracked ID set an Unbound artifact does not have).
Explain the two routes into operation modes (DR-055): an unambiguous request routes straight to its mode, while a vague one lands on the grouped operations entry that lists what exists. The grouped entry is a discovery and decline surface, not a mode with its own gates, and the direct rows are not redundant with it. Explain that artifact modification runs only through registered operations (DR-056): an undefined request is mapped to the nearest registered operation with that stated, or declined with the available list, and is never improvised into a procedure no contract covers.
Preserve the per-entry generation cycle: `research one UID → validate → write/checkpoint`. Do not postpone every checkpoint until the end of an assignment.
For Guided Mode decisions, explain that `artifacts/decision-log.json` is append-only build metadata for transforms, accepted merges, rejected concepts, renames, canon deviations, and exclusions. Repeated requests consult exact normalized identities before re-deriving a choice; the bookkeeping never becomes model-facing content. Batch 23 `transformation-map.json` files are migration input only. Load `custom-pipeline-mode.md` for the executable flow.
For Behavioral Test-drive, load `behavioral-testdrive.md`. Explain that it reuses the synthetic runtime predictor, freezes only predicted active context, requires a real model response plus independent voice/knowledge-boundary lens, and can report `technically_valid_but_behaviorally_poor` without becoming an audit, delivery, or live-runtime pass.
For build dashboards, load `dashboard-artifacts.md`; explain that all four JSON files are renderer-neutral projections and never workflow authority.
### Card Fields & Routing
Load `card-shell-routing.md`. Explain mode-specific ownership for Description, Personality, Scenario, First Message, alternate and group-only greetings (`group_only_greetings`), example messages, Creator Notes, System Prompt, Post-History Instructions, `tags`, `creator`, `character_version`, `nickname`, `creator_notes_multilingual`, `source`, `creation_date`, `modification_date`, and `assets`; `open`, `guided`, and explicitly approved `fixed`; duplication checks; the compact fallback behavior kernel that protects World identity when retrieval misses; and permanent-token pressure. End with `Any special questions?`.
### Character Architecture
This final tab consolidates the former **Character Identity & Relationships** material. Load `character-template.md` and `character-identity-system.md`. Explain canonical identity, behavior, state, directed relationships, knowledge boundaries, state splitting, Character sets, required VITALS/voice/CURRENT/CONNECTIONS terms, assignment slices, and checkpoints. End with `Any special questions?`.
Explain the core and era state split (DR-059) for multi-era characters: a `core_invariant` entry carries voice, invariant vitals, and base appearance, while per-era states carry timeline, mutable vitals, connections, backstory, and current situation. Two rules matter. The core never joins the variant inclusion group, because the group holds mutually exclusive states and the core must co-occur with the winner. And the core carries AND ANY over exactly the tokens of the eras its subject exists in, so it no longer fires where the character is unborn or long dead; it must be status-free, because it can span a promotion or a change of allegiance, and `check_core_contamination` rejects rank, allegiance, location, relationship, knowledge, and life-status claims in it. BACKSTORY stays with the state because it is accretive, not invariant. Product default at three or more eras, with `[self-contained]` as the opt-out.
### Eras & Timeline Isolation
This final tab consolidates the former **Eras & Character Architecture** material. Load `era-system.md`. Lead with the routing choice: `root_toggle` (the 4.0 default, era signal lives in a constant root entry inside the lorebook) versus legacy `scenario` (era signal lives in an `Era: ...` line in the card Scenario field). Explain that `scenario` is supported, not deprecated, and is the right choice when era selection should be visible in the card body or the target runtime lacks the native cascade fields.
For `root_toggle`, explain the three enforcement layers in order of how late each catches a mistake: the AND ALL token gate before activation, staged recursion levels during activation, and inclusion groups after activation. Say plainly that inclusion groups are required rather than advisory because they are the only layer that still holds when the other two have a hole.
Explain era tokens (one alphanumeric word, no substring collisions, never used as visible labels), cascade roles and levels, why absence rosters and knowledge ceilings live in the constant root rather than in per-character entries, how the user switches era by enabling exactly one root, and the `automationId` route for scripting the switch from a Quick Reply.
**Always state the runtime settings dependency in this tab.** The cascade needs Recursive Scan ON, Max Recursion Steps at or above the cascade depth plus one, and Min Activations at 0. Load `sillytavern-runtime-settings.md` when the user asks how to set or verify them. Explain the graceful degradation: because the root is constant, a misconfigured host yields the era frame only, thinner than intended, never wrong.
**Always state the portability boundary.** Era isolation under `root_toggle` is a profile-dependent guarantee. A portable `lorebook_v3` export keeps the content and loses the entire enforcement layer. Never let a user leave this tab believing eras are safe in every format.

Also cover: approved boundaries; World Invariants; Era Context positive and negative space; active-entity edges; event reach; conflicting-era detection; and era-bleed checks. For legacy `scenario` builds, explain canonical `Era: ...` lines normalized for case and whitespace, token-boundary aliases, and the copyable Creator Notes template. End with `Any special questions?`.
### Keywords & Filters
Explain primary and secondary keys, selective logic, scenario matching, aliases, emitted trigger terms, case/regex choices, matching sources, character/tag filters, generation triggers, and the distinction between deterministic activation filters and optional dynamic behavior. Load `entry-naming.md` when the question concerns visible lorebook names: labels and model-facing entry content stay semantic/in-world while source provenance stays in evidence and metadata. Collection & Research belongs here when the question concerns source-derived aliases or entity terms. End with `Any special questions?`.
### Activation & Recursion
This final tab replaces the former **Activation & Recursion Map** label. Load `activation-map.md`. Explain build list versus manifest authority versus readable recursion map, field registry/default profile, blank-as-inherit semantics, roots/anchors/details/leaves, direct and recursive activation, exact edges, fan-out budgets, assignment map slices, and dead/overactive entry checks. End with `Any special questions?`.
Render the cascade when explaining recursion, because the ordering is the whole point:

```text
  pass 0   constant only        Era root enters, token now in buffer
     │
  pass 1   recursion_level 1    Era context      (delay_until_recursion)
     │
  pass 2   recursion_level 2    Entity states    (AND ALL on era token)
     │
  pass 3   recursion_level 3    Detail entries
```

A break at any level darkens everything beneath it, so report the highest broken node
rather than every orphaned descendant. If only the root appears in the activation log,
Recursive Scan is off or Max Recursion Steps is too low.
### Placement & Influence
Load `prompt-placement.md`. Explain semantic position, order, priority, constant pressure, direct versus recursive influence, depth/role, named outlets, target mappings, and why placement follows purpose rather than a universal ladder. End with `Any special questions?`.
Show where an entry lands relative to the generation point, since placement is the part
users reason about worst:

```text
  system prompt ─── description ─── lorebook ─── chat history ─── PHI ─── [model writes]
       far from generation  ◄──────────────────────────────►  near
```

Steering instructions decay with distance. A prose guide belongs near the generation
point; permanent world framing belongs far from it and costs tokens every turn.
### Budgets & Pruning
Load `context-budget-pruning.md`. Explain the two independent axes: context window (user-declared: 8k/16k/32k/128k/200k+ or an exact count) sets the total token budget for the permanent shell plus active lorebook entries at their worst case; detail (Compact/Recommended/Maximum) changes only how that same total is distributed (entry count versus per-entry richness, and simulation depth), never the total itself. Explain permanent, opening, non-prompt, constant, direct, recursive, layer, era, entry, and total costs, and that only permanent cost is hard-capped, opening cost is soft-warned, and non-prompt cost (Creator Notes) is reported only; seven mandatory baseline activation simulations plus declared project-specific scenarios; measured, declared, and fallback token-count sources; soft warnings and hard blocks; protected categories; before/after estimates; and pruning receipts.
Explain that corpus size (total authored lore across the whole book) is reported and never compared against an activation budget; storage is not a runtime cost, only `worst_case_recursion_path` is. After planning, a predicted drop-order report shows exactly what a given runtime `token_budget` would keep and drop, in SillyTavern's own weight-then-order-then-uid sort, and confirms no protected entry ever falls below the line; Creator Notes carries the resulting recommended `token_budget`, measured against this specific build rather than a generic default. When an activation check is exceeded, explain that this is a planning preference overage, not a spec error: structural options (deepen the graph, add inclusion groups, tighten keywords, raise the window or detail, or accept and record) are offered before any block, and an accepted overage is recorded into the frozen plan as an approved deviation, never a silent runtime override. When content must shrink to fit, explain the retention ladder (Tier 0 never cut; Tier 1 cut last; Tier 2 before Tier 1; Tier 3 first) and that cut material is routed into an overflow record, never deleted; the parent reports "N entries had material scoped out" at merge. End with `Any special questions?`.
Cover verification triage: entries are ranked by blast radius: activation likelihood,
dependent count, and falsifiable claim density. The budget is spent top-down.
Activation dominates because an entry that cannot fire cannot break immersion however
wrong it is. Explain that cost is projected in units before a plan freezes and capped
there, never mid-generation, and that whatever the budget does not reach is labeled
`unverified` and handled by the user's de-risk policy. Load `verification_triage.py`
output when asked for specifics.
### Dynamic State & Variation
Load `dynamic-state-variation.md`. Explain opt-in groups, weights, scoring, priority selection, probability, sticky/cooldown/delay, matching sources, character/tag filters, triggers, greeting variants, approved automation IDs, and named outlets. Emphasize deterministic Simple Mode defaults and protected control/era/identity/knowledge/relationship entries. End with `Any special questions?`.
Cover the soul profile: it is hash-bound into the manifest and passed into generation
assignments, so workers write to an approved voice rather than inferring one. Its runtime
guide ships with the artifact to keep creator voice when the model reaches a scene the
lorebook never defined. Output is checked for corpus-wide prose failures (cross-entry
repetition, opener monotony, sentence-rhythm collapse), because those are what a
model-driven editor structurally cannot see, never holding every entry at once. Declared
anti-patterns are errors; corpus metrics are warnings that enter the audit patch loop.
### Output Formats & Compatibility
This tab absorbs the former Flags & Output Formats topic. Load `runtime-target-adapter.md`. Explain JSON, Schema 1, CCv3 embedded `character_book`, portable standalone `lorebook_v3`, direct native World Info, CHARX, group packages, persona+lorebook, semantic IR, portable versus named runtime profiles, direct-import compatibility versus active-setting compatibility, compatibility/loss reports, unknown extension preservation, asset/tag maps, strict BOM-free UTF-8, the exact SillyTavern import probe, and reopened round trips. Explain that portable output is the intentional default and that direct-import readiness is an explicit target/profile choice, except for a standalone lorebook (no card at all), where DR-051 is narrowed by Batch 13: the default resolves directly to the native, SillyTavern-importable shape, since a bare `lorebook_v3` file was confirmed, against SillyTavern's real source, to be actively misrouted into its character importer rather than merely awaiting an explicit conversion step; an explicit `lorebook_v3` request is unaffected and still produces the portable wrapper. This tab also absorbs SillyTavern plugin support: load `sillytavern-plugins.md` and lead with the naming collision, since `card-extensions-field.md` governs the CCv3 `extensions` JSON namespace while plugins are a separate thing sharing the word. Cover `[detect]` and what it does not claim, the expression set bridging Image Prompts and `assets`, why trackers are declined by scope rather than overlooked, and how `extension-adapters.md` source-pins Quick Reply, Regex, Vector Storage, Timed Effects, MVU, and EJS output instead of guessing formats. State plainly that the expression label set is unverified and replaceable. WorldBuilder generates images through the host runtime's `image_generate` tool (DR-075 supersedes the prior never-images position). It never manages providers, keys, or models itself; load `image-prompts.md` for the generation branch, cost confirmation, and content-safety-before-provider rules. Load `sillytavern-import-contract.md` for vectorized state, secondary logic, regex translation, scan depth, character filters, or embedded import questions. Explain the three representations a runtime semantic (depth, role, activation timing) can take: the neutral envelope (WorldBuilder's own round-trip preservation), native extension fields (the named SillyTavern profile), and CCv3 decorators (`@@depth`, `@@role`, `@@activate_only_after`: the spec's own portable emission form, `scripts/decorators.py`). Each semantic has exactly one owner per target, never both: decorator for portable, native key for the named profile. End with `Any special questions?`.
### Troubleshooting
This tab absorbs Collection & Research, Workers, Batching & Recovery, Audits & Validation, Workspace & Build Files, SearXNG Setup & “SearXNG Down”, and Config & Models troubleshooting routes.
```text
🧰 TROUBLESHOOTING
1. SearXNG or WARP is down
2. A bird worker failed or timed out
3. Discovery found too few entries
4. Build files are missing
5. Audit, adapter, integration, stage-chain, or delivery gate failed
6. JSON/CHARX will not import
7. Era entries are not firing, or the wrong era is active
8. The session lost earlier context partway through a build
9. Resume an interrupted build
10. Model or Config failed
11. Other problem
Any special questions?
```
For questions about why a gate blocked, load `anticipating-gate-blocks.md`. State the split plainly: mechanical failures are the model's to fix, while anything that changes what the artifact covers belongs to the user. Never infer from another build's manifest or receipts what will pass in this one.
For repeated activation-map failures, run `activation_map_gate.py --diagnose` before fixing anything. It reports every manifest problem at once with a suggested fix per finding, instead of stopping at the first. Fixing one, re-running, and discovering the next is the expensive loop this replaces. `planning_gate.py --diagnose` does the same for planning checks.
For a stale entry-cycle receipt, run `entry_cycle_gate.py --stage rebase` before regenerating anything. Receipts bind to their slice, not the whole manifest, so a change elsewhere no longer expires them; when one does go stale, rebase keeps every completed UID whose own hash is unchanged and names the ones that moved. Never restart an assignment that rebase can salvage.

For model reliability questions, run `gate_telemetry.py report` against the build ledger. It gives first-attempt pass rate and mean attempts to pass, per gate and per model. Say plainly that this measures convergence cost and not output quality: the gates guarantee validity regardless of model, so a low rate means the same correct artifact cost more attempts. Builds may freeze different discovery/generation/audit models; cost projection samples telemetry by both work kind and that role's frozen model rather than treating `models.subagent` as universal. For build-cost questions, `verification_triage.py project --build-state <path>` uses current discovery/generation/audit structure plus measured convergence when available; token counters are optional, missing research-token history stays explicitly unmodeled, and `reconcile` compares the saved estimate with final observed usage without turning variance into a gate.

For lost session context, load `openclaw-session-context.md`. Check the Context Profile first (Settings → Context Profile; Code Agent is the right setting for long builds, and Team Bot or Minimal skip follow-up reinjection). Explain the compaction/pruning distinction, state that build state lives on disk rather than in the conversation, and route to `pipeline_stage_gate.py --next` to re-derive the current step. Never rebuild from conversation memory and never restart a build that has a valid ledger.

For era cascade problems, run `sillytavern_install.py preflight` first: it reads the real settings instead of asking the user to check them, and reports each as ok, problem, or unknown. If no install is found, load `sillytavern-runtime-settings.md` and walk the manual verification procedure: enable exactly one root, send one message, read the World Info activation log. Root only means Recursive Scan is off or Max Recursion Steps is too low. Two roots means two eras are unlocked at once. Nothing at all means no root is enabled. Do not start by rewriting entries.

For SearXNG recovery: run `ensure_research_stack.py`, **Check WARP exact state**, inspect the configured backend, then run `searxng_preflight.py` with a real query. **Do not silently switch** providers. For interrupted work, read `runtime-recovery.md`, inspect `pipeline-stage-ledger.json`, run `pipeline_stage_gate.py --verify`, and then run the integration resume gate. Preserve successful work and avoid destructive cleanup without approval.

For "a feature isn't working" that traces back to a missing capability (no parallel dispatch, no image output, a text menu instead of an interactive one): run `capability_probe.py` and report its `available`/`unavailable`/`unknown` finding for the relevant tool plainly, along with what it degrades to. Never claim a capability is present because it usually is on this kind of host, and never claim one is absent just because it was not reported; unreported is `unknown`, not `unavailable`. Only python3 being unavailable is a hard stop; everything else is a degraded feature, not a blocked build.
### Design Decisions & Why
Load `design-rationale.md`. **Lead with the philosophy section, not with a DR number.**
Someone asking why WorldBuilder works this way wants the reasoning, and a numbered list of
sixty-one rulings reads as a changelog. Give the two or three principles that actually
generate their question, then offer the specific DR as detail.

```text
  PHILOSOPHY          the nine principles that generate the rulings
       │
       ├── invariants  contract-registry.md, enforced by gates
       │
       └── DR entries  individual rulings, with class and tradeoffs
```

For example: "why is everything in one lorebook instead of one per era?" is principle 1
(one artifact, not many) plus principle 2 (enforce in the runtime), and only then DR-049
and invariant 23. Answering with DR numbers first is technically complete and useless.

When asked about a specific decision, identify the decision class first: invariant, product default, heuristic, target-specific policy, or temporary compatibility policy. Present the relevant DR entry as Decision, Status when the entry carries one, Why it exists, Known tradeoffs, Evidence/owner when recorded, What would be a regression, Review triggers, and When it may be changed. An entry marked `Status: planned` is an approved commitment, not a description of current behavior; say so plainly rather than implying the capability exists. Say `not yet recorded` for missing legacy fields. Auditors must preserve documented contracts while still allowing evidence-based challenges involving cost, latency, usability, maintenance, or fragility. End with `Any special questions?`.
### Glossary
Define setup draft, card-shell plan, character plan, era plan, era root, era token, cascade level, inclusion group, field registry, default profile, semantic entry label, activation edge, recursion role, map slice, placement plan, budget plan, dynamic-state plan, transformation map, semantic IR, runtime profile, compatibility report, integration plan, acceptance matrix, pipeline stage receipt, stage ledger, UID, phase, evidence ledger, receipt, audit seal, CHARX, `character_book`, native World Info, World Invariants, Era Context, and temporal leakage. End with `Any special questions?`.
## Tab routing
- Accept a tab number, exact tab name, common shorthand, or a natural-language question matching a tab.
- `start`, `begin`, or `new user` routes to **Where to Start**.
- `modes`, `character`, `world`, or `lorebook features` routes to **Build Modes** unless the user clearly requests an actual build.
- `searxng down`, `warp down`, or `search broken` routes directly to the SearXNG repair flow.
- `design decisions`, `why`, `rationale`, or `architecture reasons` routes to **Design Decisions & Why**.
- `what can you do`, `menu`, `available operations`, or a request WorldBuilder does not define routes to **Build Modes**, which lists the operations that exist. Decline an undefined request against that list rather than improvising a procedure. DR-055's grouped operations entry will own this route once built; until then Build Modes is the capability surface.
- `eras`, `multi-era`, `era bleed`, `dead characters alive`, `era root`, `era token`, or `era switch` routes to **Eras & Timeline Isolation**.
- `extensions`, `plugins`, `expressions`, `sprites`, `quick replies`, `regex`, or `trackers` routes to **Output Formats & Compatibility**.
- `stuck`, `keeps failing`, `loop`, or `burning tokens` routes to **Troubleshooting** and uses `repair_loop_guard.py status`, which shows which gate halted and whether any attempt made progress.
- `debug log`, `capture the error`, `reproduce`, or `report a bug` routes to **Troubleshooting** and uses `debug_log.py`.
- `public diagnostics`, `support bundle`, or `share diagnostics` routes to **Troubleshooting** and uses `diagnostics_bundle.py`; default export is metadata/hashes plus scrubbed gate output, while generated content requires explicit opt-in.
- `gate blocked`, `why did it fail`, `consent`, `autonomy`, or `self-approve` routes to **Troubleshooting** and loads `anticipating-gate-blocks.md`.
- `context`, `compact`, `truncated`, `lost context`, `context profile`, or `context window` routes to **Troubleshooting** and loads `openclaw-session-context.md`.
- `how reliable is my model`, `retry rate`, `first attempt`, or `which gate costs most` routes to **Troubleshooting**, which runs `gate_telemetry.py report` against the build's ledger. Convergence is a cost signal; the gates guarantee validity regardless of model, so never present it as output quality.
- `capture fixtures`, `verify against a real install`, or `runtime evidence` routes to **Troubleshooting** and runs `sillytavern_install.py capture-fixtures`, which takes settings and world files only and never chats.
- `leftover pages`, `unreviewed sources`, or `discovery exclusions` routes to **Troubleshooting** and uses `discovery_exclusions.py` to record a governed approval rather than silently dropping terminal leftovers.
- `find my sillytavern`, `read my settings`, `keyword collision`, `already have a lorebook`, or `what extensions do I have` routes to **Troubleshooting** and uses `sillytavern_install.py`.
- `recursive scan`, `max recursion steps`, `min activations`, `era not firing`, or `required settings` routes to **Troubleshooting** and loads `sillytavern-runtime-settings.md`.
- `character identity`, `character format`, `character template`, `behavior model`, `relationship graph`, `character plan`, `knowledge boundary`, `secrets known`, or `state split` routes to **Character Architecture**; field-specific template questions may route to **Card Fields & Routing**.
- `card fields`, `card shell`, `scenario field`, `first message`, `alternate greetings`, `creator notes`, `system prompt`, or `post-history instructions` routes to **Card Fields & Routing**.
- `entry name`, `entry label`, `Source from`, `RULE:`, `ITEM:`, or `naming scheme` routes to **Keywords & Filters** and loads `entry-naming.md`.
- `activation map`, `recursion map`, `keywords as edges`, `map slice`, `constant`, `vectorized`, or `recursion graph` routes to **Activation & Recursion**.
- `placement`, `insertion order`, `priority`, `author's note`, `chat depth`, `role`, `outlet`, or `influence` routes to **Placement & Influence**.
- `dynamic state`, `probability`, `inclusion group`, `group scoring`, `sticky`, `cooldown`, `delay`, `character filter`, `generation trigger`, `automation`, or `named outlet` routes to **Dynamic State & Variation**.
- `output format`, `semantic IR`, `runtime target`, `compatibility`, `lossy`, `native World Info`, `CHARX`, or `round trip` routes to **Output Formats & Compatibility**.
- `skipped step`, `pipeline stage`, `stage ledger`, `delivery gate`, or `why did delivery block` routes to **Troubleshooting** and loads `pipeline-stage-gates.md`.
- `junk links`, `metadata pages`, `why was this page skipped`, or `discovery filter` routes to **Keywords & Filters**.
- `back`, `info home`, `documentation`, or `tabs` returns to the Info home menu.
- After answering a special question, remain in Info Mode and offer the most relevant tab plus `Info Home`.
- Never force the user to remember numbers; names and ordinary language must work.
## Tab content requirements
Each tab response must:
1. Start with the tab title.
2. Answer only that documentation area unless the user asks for more.
3. Prefer compact examples and diagrams over a wall of prose.
4. Include commands only when useful and label any command requiring approval.
5. Distinguish documentation from an action. Ask before making configuration or installation changes.
6. End with exactly:
```text
Any special questions?
```
## Special questions
Treat the bottom prompt as an invitation to ask anything about WorldBuilder, not as a requirement to select a tab. Answer the question directly, then end with `Any special questions?` while remaining in Info Mode.
## What WorldBuilder reads from your SillyTavern folder

Install access is read-only and opt-in. There is no write path: WorldBuilder never
modifies a SillyTavern installation.

When a task needs it, `sillytavern_install.py` proposes candidate install roots with the
evidence for each and waits for confirmation. It never picks one silently, even when only
one plausible match exists.

| Read | Why |
|---|---|
| `settings.json` | verify World Info activation settings instead of instructing the user |
| `worlds/*.json` | detect keyword collisions with books already installed |
| `extensions/` | answer `[detect]` without asking the user to self-report |

**Chats are never read.** Chat logs are personal correspondence, they are not evidence
about activation behavior, and no flag enables reading them. Fixture capture copies
settings and world files only, and states in its manifest what it excluded and why.

Nothing read from an install is passed to research workers.
## Source policy
Use the build/request source stance. Research is not mandatory for user-canonical original material. For current OpenClaw, SillyTavern, SearXNG, MediaWiki, or format behavior, use current official documentation when an answer requires fresh or exact technical details.
For Fandom/MediaWiki pages, prefer documented API representations such as `action=parse` and revision wikitext before normal decorative HTML. Never describe an API endpoint as a guaranteed access-control bypass.
## Runtime Reliability & Recovery
WorldBuilder treats worker execution as a verified transaction rather than trusting a completion message.
- Parent dispatch cards and receipts use absolute build-workspace paths. Staged manuals intentionally use relative links inside the versioned worker kit and resolve them from the build-root `cwd`; neither contract points into the mutable skill installation.
- The parent registers each run before dispatch. Superseded run IDs are abandoned in the worker-run ledger; late completion events are quarantined and cannot mutate the build.
- A discovery worker writes a candidate JSON file. `commit_worker_result.py` validates one-result JSON, exact URL ownership, exclusion reason codes, fetch records, taxonomy, and lineage before atomically committing the final result.
- Repeated path, contract, or output-format failures trigger a wave circuit breaker. WorldBuilder repairs the shared cause before spawning more birds.
- Recovery appends new assignments to an immutable discovery plan. It never rewrites assignments that already have outputs or runtime receipts.
- `sessions_spawn` remains preferred. A parent-observed `exec` run with an explicit work directory is a legitimate fallback and receives a distinct, truthful runtime receipt.
### Bounded source-set coverage states
- `complete`: bounded source-set coverage and saturation both passed normally.
- `passed_with_exclusions`: all remaining URLs were classified with registered reason codes, the user approved any nontrivial exclusions, and the gate bound that approval by hash.
- `recovery_required`: valid but incomplete; exit code 2.
- `circuit_breaker`: shared runtime failure; stop dispatch and repair the backend or contract.
### Stable identity and planning
Entity UIDs come from a persistent canonical-identity registry. Reclassifying an entity from `character` to `species`, changing display order, or adding aliases must not renumber it. The planning gate binds the discovery receipt, identity registry, manifest, build list, recursion map, and build fingerprint before generation assignments may exist.
Any special questions?
