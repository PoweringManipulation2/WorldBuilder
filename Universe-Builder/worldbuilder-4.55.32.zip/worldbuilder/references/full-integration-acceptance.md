# Full Integration and Acceptance

<!-- phase-contract --> Exit contract: run `python3 {baseDir}/scripts/phase_contract.py --build-state <build-state> --stage <one of: output_contracts, integration_output>` before this stage's gate; rendered copies ship in the build's worker kit under `exit-contracts/`.
Batch 10 uses `worldbuilder-full-integration-v1`. Every build freezes `artifacts/pipeline-registry.json` and `artifacts/integration-plan.json`; `build-state.json.integration` binds both by SHA-256. Do not infer that separate receipts form a coherent pipeline: run `scripts/integration_acceptance.py` at planning, resume, and output boundaries.

## Pipeline coverage

The registry covers Character, World, Lorebook, Group, Persona, Audit, Prune, Quick, Full Detail, Multi-era, and Resume/Recovery. Each route freezes only its applicable systems. Quick changes depth, not safety; Full Detail expands supported coverage within hard budgets; Prune preserves era, knowledge, identity, relationship, activation, dynamic, placement, and target semantics; Resume revalidates completed receipts before continuing.

## Auditor coverage

- **Compass:** card routing, field registry, target compatibility, era-plan fidelity, settings, and scope lineage.
- **Weaver:** activation graph, recursion, placement, groups, token pressure, dynamic operations, and pruning effects.
- **Scout:** source/entity-state coverage, missing eras, missing relationship states, exclusions, and deferred scope.
- **Warden:** IDs, chronology, knowledge state, relationships, temporal leakage, containment, and graph integrity.

The frozen auditor matrix must match `audit_plan.py` exactly.

## Acceptance matrix

The thirteen required scenarios are single-era World, multi-era World, character card, character era set, standalone lorebook, group build, large wiki build, interrupted generation, native World Info export, CCv3/CHARX round trips, Unicode corruption, era bleed, and recursion fan-out. Every row names a concrete bundled test owner; documentation labels alone are not proof.

## Build gates

```bash
python3 {baseDir}/scripts/integration_acceptance.py validate --build-state /path/build-state.json --stage planning
python3 {baseDir}/scripts/integration_acceptance.py validate --build-state /path/build-state.json --stage resume
python3 {baseDir}/scripts/integration_acceptance.py validate --build-state /path/build-state.json --stage output --target /path/final.json
```

The gates write `integration-planning-gate.json`, `integration-resume-gate.json`, and `integration-output-gate.json`. Delivery displays Full Integration and Acceptance as stage 8 of 9. When an upstream artifact changes, use `lineage_invalidate.py`; never edit receipt hashes manually.

## Release acceptance

Run the complete tests, emit the matrix, compile Python, parse reference JSON, scan UTF-8/mojibake, verify manifest hashes, inspect ZIP paths, extract the package, and repeat the suite from extracted bytes.

```bash
python3 {baseDir}/scripts/integration_acceptance.py matrix --output /path/release-acceptance-matrix.json
```

Report pass, fail, skipped, and untested boundaries. Deterministic fixtures do not prove every live SillyTavern version, extension, OpenClaw host, model, network, or user configuration; claim only named targets represented by current evidence.

## Entry-label acceptance

Lorebook-bearing scenarios must prove semantic labels, preserved prior-label metadata, and no source boilerplate before post-generation audit and delivery.

**Source-provenance boundary:** URLs, source-site/wiki labels, article wrappers, and retrieval notes belong in evidence or structured source metadata, not visible `name`/`comment` labels or model-facing entry `content`. Existing content matches are warnings for review; never silently rewrite substantive prose with the label normalizer.
