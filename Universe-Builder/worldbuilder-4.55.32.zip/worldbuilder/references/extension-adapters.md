# Extension adapters

Use `scripts/extension_adapter.py` for Batch 23 item 7. Its `worldbuilder-extension-adapter-v1` envelope is an internal WorldBuilder representation, not a universal extension schema. All rows below were checked against current source on **2026-09-04**; re-check the named upstream source before changing a target or compatibility claim.

| Extension | Verified source | Target(s) | Hard boundary |
|---|---|---|---|
| Quick Replies | SillyTavern `release`: `QuickReply.js`, `QuickReplySet.js`, loader | `quick_reply_set_v2` | Exact `QuickReplySet.toJSON()` / `QuickReply.toJSON()` names; non-empty automation IDs are not wired. |
| Regex | SillyTavern `release`: `char-data.js`, regex `engine.js` | `regex_script_v1`, `character_regex_scripts` | Current `RegexScriptData`; placements 1/2/3/5/6 only. 0 is deprecated, 4 is legacy. |
| Vector Storage | SillyTavern `release`: vectors `index.js`, `world-info.js` | `world_info_native`, `ccv3_extensions`, `settings_patch` | Entry marker is `vectorized`; global settings are `recommendation-only` and all values must be explicit. |
| Timed Effects | SillyTavern `release`: `world-info.js`, World Info docs | `world_info_native`, `ccv3_extensions` | Only positive `sticky`, `cooldown`, `delay` are emitted; zero means no effect. |
| MVU | MagVarUpdate `beta`: `doc/tutorial.md`, `src/variable_def.ts` | `world_info_initvar` | Emits a disabled-safe `[InitVar]` entry with hierarchical JSON leaves `[initial]` or `[initial, condition]`; does not install MVU. |
| EJS | ST-Prompt-Template `main`: `manifest.json`, `docs/features.md` | `template_text`, `world_info_entry` | Preserves template text; memo prefix is limited to `[GENERATE:BEFORE]`, `[GENERATE:AFTER]`, `[RENDER:BEFORE]`, `[RENDER:AFTER]`, or `[InitialVariables]`. |

Input shape:
```json
{"contract":"worldbuilder-extension-adapter-v1","extension":"regex","payload":{"name":"Hide state","find_regex":"/<state>[\\s\\S]*?<\\/state>/g","placements":["ai_output"]}}
```
Run `python scripts/extension_adapter.py capabilities` for the machine-readable source matrix, or `python scripts/extension_adapter.py serialize --input extension.json --target regex_script_v1 --output out.json` to serialize.

Vector Storage has two distinct surfaces: the per-entry `vectorized` field and application-global `enabled_world_info`, `enabled_for_all`, `max_entries`. A `settings_patch` is advisory metadata, never an automatic settings mutation. Timed Effects remain normal World Info semantics owned by the existing runtime target adapter for real build delivery; ST-Prompt-Template explicitly does not implement sticky/cooldown/delay in its injection layer.

MVU initializes from World Info memo names containing `[InitVar]`, even when the entry is disabled. EJS `template_text` returns the string unchanged; `world_info_entry` only adds a verified memo prefix. Neither serializer proves the third-party extension is installed or enabled.

Before expanding any adapter, update the source baseline, permanent regression, and compatibility text together. This local refresh rule does not substitute for Batch 24 item 42's separately specified compatibility-refresh automation.
