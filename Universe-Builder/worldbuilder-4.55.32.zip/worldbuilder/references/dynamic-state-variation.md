# Dynamic State and Variation
## Contract
Batch 8 freezes optional behavior under `worldbuilder-dynamic-state-v1` before generation. The plan is target-neutral: it records intent and exact per-UID semantics without assuming that every runtime spells or stores those fields the same way. Exact CCv3/SillyTavern serialization is performed by the Batch 9 parent-owned runtime adapter.
## Safety defaults
New builds are deterministic unless an Advanced Mode user opts in:
- probability `100`;
- no inclusion groups or random selection;
- sticky, cooldown, and delay `0`;
- chat as the ordinary matching source;
- no character/tag filters or generation-trigger restrictions;
- no automation IDs;
- no named outlets.
Constant roots, World Invariants, era controls, knowledge boundaries, identity/state ownership, required relationships, and required activation paths are protected. Do not randomize, delay, filter, or hide them.
## Advanced submenu
`off` keeps the safety defaults. `review` lets WorldBuilder propose candidates and pauses before freezing them. `custom` accepts explicit user-authored policies. `preserve` is for edits where supplied behavior must survive unchanged through import into semantic IR and reviewed target mapping.
The submenu covers inclusion groups, group weights, group scoring, priority selection, probability, sticky/cooldown/delay, additional matching sources, character/tag filters, generation triggers, automation IDs, named outlets, and greeting-bound variants.
## Planning and lineage
Write `artifacts/dynamic-state-plan.json`, bind its SHA-256 into the manifest, planning receipt, assignment map slices, evidence receipts, entry-cycle receipts, phase metadata, audit inputs, output receipt, and final audit seal. Workers receive only their exact UID slice.
Generation workers emit non-default behavior only under `extensions.worldbuilder_dynamic`. They must not invent target-native field names. The delivery gate compares every entry with the frozen plan and blocks missing, extra, or altered behavior.
## Groups
Every group declares an exact name, at least two members, a reason, and one selection mode:
- `weighted_random` uses positive per-member weights and may enable group scoring;
- `priority` selects by planned insertion order and requires distinct member orders.
Protected entries may use a deterministic priority group only when architecture requires collision protection. They may not use random selection.
## Timed effects and filters
Sticky, cooldown, and delay are non-negative message-count semantics. Apply them only to optional state or event entries. Character filters use explicit include/exclude mode with names and/or tags. Human-readable character names are planning labels only: native SillyTavern export requires an explicit map to the character/avatar filename stem used by the runtime, and tag labels require an explicit map to runtime tag IDs. Generation triggers use only declared supported trigger names; reject `regenerate` for Group Chat builds because group regeneration uses Normal-generation messages. Era Context policies must include Scenario matching.
## Automation and outlets
Automation IDs require an approved registry row, explicit user intent, an action, and a reason. Named outlets require an exact consumer name, approval, macro capability, and a reason. Do not infer either from prose.

Outlet names are case-sensitive; leading or trailing whitespace breaks matching, so names must be whitespace-exact. Outlet macros cannot nest and cannot be nested, placed inside World Info entries, expanded from character-card fields, or resolved inside the Author's Note editor. Use them only from a documented macro-capable prompt consumer and test that consumer in the named runtime.
## Audit responsibilities
- Compass checks selected policy, plan hash, scope, and explicit approval.
- Weaver checks groups, probability, timed effects, matching sources, filters, triggers, and protected-entry safety.
- Scout checks that optional dynamic uses do not substitute for missing factual coverage.
- Warden checks era/form exclusivity, greeting bindings, and survival of protected distinctions.

## Runtime serialization

After post-generation audit and patching, read `runtime-target-adapter.md`. Portable outputs retain only the neutral envelope. A named SillyTavern profile may mirror supported semantics into tested runtime fields while keeping the neutral envelope for reverse import. Unsupported greeting scopes, missing tag-ID maps, incompatible multi-group settings, or lossy conversions block unless the user explicitly accepts a neutral-only or lossy result.
