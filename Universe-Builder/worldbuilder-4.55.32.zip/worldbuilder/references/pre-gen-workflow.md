# Pre-Generation Workflow

<!-- phase-contract --> Exit contract: run `python3 {baseDir}/scripts/phase_contract.py --build-state <build-state> --stage <one of: planning_validated, generation_ready>` before this stage's gate; rendered copies ship in the build's worker kit under `exit-contracts/`.
## Navigation

- [Guided settings gate](#guided-settings-gate)
- [Create build state](#create-build-state)
- [Lock decisions](#lock-decisions)
- [Known-property breadth discovery](#known-property-breadth-discovery)
- [Era planning checkpoint](#era-planning-checkpoint)
- [Authoritative planning artifacts](#authoritative-planning-artifacts)
- [Architecture and pre-generation gates](#architecture-and-pre-generation-gates)
- [Generation assignments](#generation-assignments)
- [Phase gates](#phase-gates)

## Guided settings gate

Show the exact first greeting for a bare invocation, then the mode-filtered paged settings flow. Parse details and flags already supplied. Do not initialize a build until material settings are resolved.

Timeframe is material. Record `single`, `multi`, or Character `set`, plus `strict` or `balanced` isolation where applicable.

## Create build state

Initialize a unique build inside the approved WorldBuilder workspace:

```bash
python3 {baseDir}/scripts/init_build.py "PROJECT" \
  --workspace "~/Desktop/WorldBuilder" \
  --artifact-type lorebook \
  --schema 3 \
  --source-kind known-property \
  --source-stance source-canonical \
  --pipeline parallel \
  --era-mode multi \
  --era-isolation strict
```

Source kinds: `original` (invented), `known-property` (requires the parallel breadth sweep), `provided-corpus` (user-supplied material), and `existing-lorebook` (build on an artifact the user already has).

An `existing-lorebook` build is additive. Imported entries are recorded at `unverified` confidence, because importing verifies nothing and treating imported material as verified smuggles an unaudited claim into a build that otherwise tracks provenance. They enter the same blast-radius triage as generated entries: rank with `verification_triage.py rank`, spend the approved budget top-down, and apply the approved de-risk policy to whatever the budget did not reach. Do not verify an imported book uniformly; that costs about what regenerating it costs, which is the reason additive builds stall.

Assignment slices carry every plan context a worker needs: character, era, placement, budget, dynamic state, and soul voice. A setting that is enforced by a gate but absent from the slice makes a worker infer what it was told not to infer, so check the slice rather than assuming the binding is enough.

Partition generation batches with `gate_telemetry.py partition --manifest <path> --max-batch <configured size>` rather than slicing by a flat number. Isolated entries take the full configured size; interdependent entries take smaller batches. On a resumed/rework path where validated evidence already exists, `--evidence-ledger <path>` may conservatively shrink batches further for low-confidence or conflicted UIDs. Never require this evidence signal on the initial generation pass because the evidence does not exist yet.

Record every gate attempt to the build's telemetry ledger so convergence is measurable per model:

```bash
python3 {baseDir}/scripts/gate_telemetry.py record --ledger <build>/.work/gate-attempts.jsonl \
  --gate validate_output --model <model id> --attempt 1 --outcome pass --scope <uid>
```

Convergence is a cost signal, not a quality signal. The gates guarantee validity regardless of model, so a low first-attempt rate means the same correct artifact cost more attempts. When the host exposes stable model usage, also record `--work-kind` plus exact `--input-tokens`/`--output-tokens` (and cache counters when available); never guess missing counters. Never block a release on telemetry.

Generate only what the delta plan says is missing. Never regenerate an entry that already exists and verifies.

`build-state.json` is the only path authority. The installed skill remains immutable. Parent-only planners, runtime recorders, and gates run from `{baseDir}/scripts`; child workers receive staged manuals, references, and direct-execution helpers.

## Lock decisions

Record at minimum:

- Mode and output format.
- Source stance.
- Locked timeframe or multi-era intent.
- Era isolation profile and boundary-selection method.
- Detail level and quick/full-detail behavior.
- Lorebook structure and embedded/standalone choice.
- Extension and probability preferences.
- Character fixed-Scenario approval, if any.
- Character identity/behavior planning policy and relationship review policy.
- Character split policy, including any user-required or user-forbidden state splits.
- Soul Extractor profile when used.

Changing timeframe, era boundaries, character format, or state-splitting after planning invalidates the manifest and all downstream artifacts.

## Known-property breadth discovery

For known properties, run the complete additive collection pipeline before writing the build list:

```text
source_probe.py
  -> discovery_page_filter.py
  -> discovery_plan.py
  -> bird-named workers
  -> record_discovery_runtime.py per child
  -> discovery_gate.py
  -> discovery_recovery.py and repeat while incomplete
```

Discovery remains broad, while deterministic filtering keeps navigation, production metadata, discussion pages, and other junk out of expensive model workloads.

## Era planning checkpoint

For `multi` or Character `set`, pause after discovery/source synthesis and before manifest creation.

1. Identify state-change boundaries from deaths, revelations, role changes, faction changes, transformations, wars, location destruction, and other canon transitions.
2. Propose an ordered era list and exact copyable `Era: ...` Scenario phrases.
3. Show active characters, factions, and locations per era.
4. Show `WHAT IS ALREADY PAST` and `KNOWLEDGE LIMITS THIS ERA` summaries per era. State what an era does not contain as a boundary, for example "Nothing after the Siege has occurred", never as a list of events that have not happened.
5. Show each era's start/end boundary, world-state summary, state assertions, and prohibited state terms.
6. Identify every entity requiring a state split and explain why, including required and forbidden state terms.
7. Show event origin and later-history reach.
8. Ask the user to approve or edit the plan. For `root_toggle` routing, explain that each era owns one constant
   root entry and exactly one ships enabled; disclose the required SillyTavern settings here rather than at
   delivery. For legacy `scenario` routing, explain that exactly one `Era: ...` line belongs in Scenario.
9. Write the era plan only after confirmation, with `user_approved: true`:
   - `root_toggle` → `artifacts/era-root-plan.json` under `worldbuilder-era-root-v1`;
   - `scenario` → `artifacts/era-plan.json` as era-plan v2 under `worldbuilder-era-router-v1`.
   Never write both. The two routings are mutually exclusive within one build.

Read `era-system.md`. Do not infer approval from silence or from the initial `multi-era` flag.

## Authoritative planning artifacts

Only after discovery and any required era confirmation pass, write:

```text
artifacts/era-plan.json             scenario multi-era only
artifacts/character-plan.json         whenever generated character entries exist
artifacts/field-registry.json        frozen planning field meanings
artifacts/default-profile.json       frozen build/layer defaults
artifacts/placement-plan.json        frozen purpose/position/influence policy
artifacts/build-list.md
artifacts/manifest.json              machine authority
artifacts/recursion-map.md           validated readable projection
artifacts/build-id.json
```

The manifest is authoritative. It must bind the frozen planning contract and include the activation graph:

```json
{
  "planning_contract": {
    "kind": "worldbuilder-planning-authority",
    "version": 1,
    "field_registry_sha256": "<hash>",
    "default_profile_sha256": "<hash>"
  },
  "activation_graph": {
    "contract": "worldbuilder-activation-graph-v1",
    "graph_version": 1,
    "edges": []
  },
  "architecture": {
    "contract": "worldbuilder-content-architecture-v1",
    "character_format": "canonical-v1",
    "character_system": {
      "contract": "worldbuilder-character-system-v1",
      "plan_sha256": "<hash when characters exist>"
    },
    "era": {"mode": "single", "isolation": "strict"},
    "placement": {"contract": "worldbuilder-placement-influence-v1", "plan_sha256": "<hash>"},
    "canon_precedence": ["primary_source", "official_wiki", "secondary_source"]
  }
}
```

`architecture.canon_precedence` is optional. When present, it is an ordered list of normalized evidence `source_type` values used only to resolve already-declared source conflicts; omitting it leaves conflicts unresolved for review rather than inventing precedence.

For multi-era builds, set mode to `multi` and bind the era contract that matches the selected routing. Under `root_toggle` (the 4.0 default): add `era_root_plan_sha256`, set `architecture.era.routing` to `root_toggle`, and bind `architecture.era_root` to `worldbuilder-era-root-v1`. Under legacy `scenario` routing: add `era_plan_sha256`, set `architecture.era.routing` to `scenario`, bind `architecture.era_router` to `worldbuilder-era-router-v1`, and require era-plan v2. Whenever generated character entries exist, add `character_plan_sha256`, bind `architecture.character_system`, and write `artifacts/character-plan.json` before rendering the activation map. Every lorebook-bearing build also binds `placement_plan_sha256` and `architecture.placement` to the frozen `worldbuilder-placement-influence-v1` plan. When a soul profile was approved, bind `soul_profile_sha256` and `architecture.soul_voice` to `worldbuilder-soul-voice-v1`, and set `generation.soul_voice_bound: true` on every prose-bearing entry so its worker receives the approved voice instead of inferring one. If that profile declares `runtime_guide.placement: world_core_entry`, the manifest must also plan the runtime guide as a real lorebook entry with `architecture.layer: world_core` and `activation.strategy: constant`; this is the materialization rule for the placement, not a second soul-contract verifier.

Every character manifest record declares `canonical-v1`, its role (`card_star` or `lorebook_character`), the exact required section order, `character_id`, `character_state_id`, `identity_model: structured-v1`, and `behavior_model: structured-v1`. Every generated character UID belongs to exactly one planned state. The character plan owns stable identity, behavior, era/state facts, knowledge boundaries, split rationale, required/forbidden terms, and directed relationship state. Every lore-bearing build has exactly one `world_core` or `world_invariants` root. Every era-state entry declares entity identity, era IDs, and activation settings. Under `root_toggle` it also declares its cascade role, recursion level, era token gate, and inclusion group; under `scenario` routing it declares Scenario matching instead.

The build list groups entries by root/control, era, layer, dependency, research topics, and generation batch. Every entry also declares `activation.strategy`, `activation.recursion_role`, exact graph-driving `emits`, and `forbidden_emits` in the manifest. Character build-list rows reference their planned character/state IDs rather than carrying a second freeform biography.

Render `recursion-map.md` from the manifest rather than authoring it independently:

```bash
python3 {baseDir}/scripts/activation_map_gate.py --build-state /absolute/path/build-state.json --render
python3 {baseDir}/scripts/activation_map_gate.py --build-state /absolute/path/build-state.json
```

The map contains a complete entry activation ledger plus an edge ledger. Blank optional settings inherit from `default-profile.json`; only non-default special operations are printed. Read `activation-map.md`.

## Entry naming authority

Read `entry-naming.md`. Planning must be able to derive one concise semantic label for every manifest UID. `planning_gate.py` writes the naming-planning receipt before the four pre-generation auditors run.

## Budget planning authority

Before generation, bind `artifacts/budget-plan.json` into the manifest and run `budget_contract.py --stage planning`. The gate records permanent card cost, constant cost, direct and recursive activation estimates, layer and era allocation, total authored lore, and all seven representative activation simulations. When `preserve_main_plot` is frozen, mark only confirmed main-plot entries with `architecture.pruning_tags: ["main_plot"]`; do not infer the tag from generic event type or prominence.

Every version-3 generation assignment carries `budget_plan_sha256` and exact UID-scoped `budget_context`. The worker reads this alongside the map, character, era, and placement slices. The per-entry cycle measures checkpoint bytes before the worker advances. Soft limits create warnings; hard limits fail closed.

## Dynamic-state planning authority

For every lorebook-bearing build, bind `artifacts/dynamic-state-plan.json` into the manifest and run `dynamic_state_contract.py --stage planning`. Simple Mode freezes the `off` policy and deterministic defaults. Advanced Mode may review or customize exact inclusion groups, probability, timed effects, matching sources, filters, triggers, greeting variants, approved automation IDs, and approved outlets. Every version-3 generation assignment carries `dynamic_state_plan_sha256` plus an exact UID-scoped `dynamic_state_context`; no worker may invent or expand operations outside that slice.

## Architecture and pre-generation gates

Run stable identity allocation, then the planning contracts in dependency order, then the gate:

```bash
python3 {baseDir}/scripts/manifest_identity.py --build-state /absolute/path/build-state.json
python3 {baseDir}/scripts/era_router_contract.py --build-state /absolute/path/build-state.json --stage planning
python3 {baseDir}/scripts/architecture_gate.py --build-state /absolute/path/build-state.json --stage planning
python3 {baseDir}/scripts/activation_map_gate.py --build-state /absolute/path/build-state.json
python3 {baseDir}/scripts/placement_contract.py --build-state /absolute/path/build-state.json --stage planning
python3 {baseDir}/scripts/terminology_dictionary.py build --manifest /absolute/path/artifacts/manifest.json --output /absolute/path/artifacts/terminology-dictionary.json
python3 {baseDir}/scripts/entry_naming.py --build-state /absolute/path/build-state.json --stage planning
python3 {baseDir}/scripts/budget_contract.py --build-state /absolute/path/build-state.json --stage planning
python3 {baseDir}/scripts/dynamic_state_contract.py --build-state /absolute/path/build-state.json --stage planning
python3 {baseDir}/scripts/soul_contract.py planning --build-state /absolute/path/build-state.json
python3 {baseDir}/scripts/planning_gate.py --build-state /absolute/path/build-state.json
```

The dictionary, naming, budget, dynamic-state, and soul steps depend on the build's shape: the dictionary needs a manifest, the soul binding needs an approved profile, and the budget and dynamic-state contracts need their plans bound into the manifest first. Character and card-shell plans are validated inside `architecture_gate.py` through `character_contract.py` and `card_shell_contract.py`; neither is a separate command. `planning_gate.py` invokes the architecture gate and binds its receipt.

Lorebook-bearing, World, and Group builds then require four pre-generation auditors. Compass checks format/scope, Weaver checks activation/era recursion, Scout checks coverage, and Warden checks identities, chronology, relationships, and state matrices.

Pre-generation audit intentionally remains **full-scope**, including after a manifest amendment: it validates planning authority (activation topology, coverage, identities, frozen settings, and cross-entry relationships), so a UID-only `changed` slice would prove the wrong contract. If manifest bytes change, regenerate all four pre-generation lenses; `phase_gate.py --stage pre-dispatch` refuses stale audit-plan/assignment bindings before dispatch.

Canonical pre-generation findings paths:

```text
.work/findings/pre-generation/compass-findings.json
.work/findings/pre-generation/weaver-findings.json
.work/findings/pre-generation/scout-findings.json
.work/findings/pre-generation/warden-findings.json
```

```bash
python3 {baseDir}/scripts/audit_plan.py --build-state /absolute/path/build-state.json --stage pre-generation
python3 {baseDir}/scripts/audit_gate.py --build-state /absolute/path/build-state.json --stage pre-generation
python3 {baseDir}/scripts/phase_gate.py --stage pre-generation --build-state /absolute/path/build-state.json
```

No generation assignment may exist before the current planning and required audit receipts pass.

## Generation assignments

Partition stable UIDs by dependency, era, and estimated research/token cost. Closely coupled entries remain together, but every worker receives 1-50 entries.

Multi-era ordering:

1. World Invariants and all Era Contexts.
2. Era 1 entries.
3. Era 2 entries.
4. Continue in era order.
5. Shared invariant details.

Do not mix many eras in one worker merely to balance counts. State locality is more important than equal batch size.

Every version-3 generation assignment embeds the exact deterministic `map_slice` for its UIDs. Create it with `assignment_map_slice.py`; include the returned activation-map, field-registry, and default-profile hashes. Character-bearing assignments also include `character_plan_sha256` and the exact `character_context` slice. Multi-era assignments include `era_plan_sha256` and the exact `era_router_context` slice. Placement-aware assignments additionally bind `placement_plan_sha256` and carry resolved `placement_context` for every UID. Together these slices supply incoming/outgoing edges, neighbor summaries, required emitted terms, forbidden terms, non-default special operations, stable identity, behavior, selected state, approved boundaries, canonical Scenario keyword, world state, knowledge limits, state assertions, prohibited state terms, split rationale, directed relationships, purpose, position, order, priority, depth/role, outlet, influence class, and target mapping.

Every UID follows:

```text
read manifest + map slice + placement context + character and era-router context when applicable
-> research one UID against its selected state and knowledge boundary
-> validate
-> write/checkpoint with canonical character sections, required graph/identity terms, and no forbidden triggers or future knowledge
-> validate identity, behavior, CURRENT state, relationships, and activation edges
-> next UID
```

User-canonical projects use provided sources as evidence rather than bypassing research.

## Phase gates

Before dispatch:

```bash
python3 {baseDir}/scripts/phase_gate.py --stage pre-dispatch --build-state /path/build-state.json
```

Before merge:

```bash
python3 {baseDir}/scripts/phase_gate.py --stage pre-merge --build-state /path/build-state.json
```

After merge and post-generation audit, `delivery_gate.py` automatically runs the output architecture and era-router checks. It blocks release on missing Era Context sections, missing knowledge limits, conflicting routing, missing active-entity edges, future-event leakage, prohibited state terms, character-format drift, character-plan/manifest mismatch, missing required identity/voice/current-state terms, omitted planned relationships, knowledge-boundary violations, star/lorebook routing errors, or an unapproved fixed Character Scenario.
