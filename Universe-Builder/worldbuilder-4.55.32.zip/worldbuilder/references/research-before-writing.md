# Research Before Writing Contract
## Navigation
- [Purpose](#purpose)
- [Assignment version 3](#assignment-version-3)
- [Evidence ledger](#evidence-ledger)
- [Evidence gate](#evidence-gate)
- [Writing from evidence](#writing-from-evidence)
- [Parent acceptance](#parent-acceptance)
## Purpose
Every generation batch must use interleaved per-entry cycles. Research one assigned UID, validate it, write/checkpoint that entry, then proceed to the next UID. Researching the entire batch before writing is forbidden. A global research pass may inform planning, but it does not replace per-entry evidence.
The required order is:
```text
assigned UIDs in declared order
  -> research UID 1
  -> validate UID 1 evidence
  -> write and validate UID 1 checkpoint
  -> research UID 2
  -> write and validate UID 2 checkpoint
  -> repeat through the batch
  -> run aggregate evidence gate
  -> assemble phase from validated checkpoints
  -> bind phase to evidence + entry-cycle receipts
  -> pre-merge consistency check
```
## Interleaved entry-cycle contract
The batch size may be 1-50, but the active context unit is always one UID. The evidence ledger grows only by the current UID, and `.work/entry-checkpoints/` receives one validated checkpoint before the next UID is researched. `entry_cycle_gate.py` rejects future-UID evidence, out-of-order writes, missing checkpoints, unknown claim IDs, and attempts to finalize before every cycle is complete.
This ordering is intentional: facts for an early entry should be converted into final entry content while they remain salient, rather than being buried beneath research for fourteen later entries.
## Assignment version 3

Every generation assignment must use `assignment_version: 3` and include:

```json
{
  "assignment_version": 3,
  "assignment_id": "wb-sample-raven-phase-0002",
  "build_id": "...",
  "manifest_sha256": "...",
  "role": "generation",
  "worker": "raven",
  "schema": 3,
  "research_mode": "public_web",
  "entries": [
    {
      "uid": 7,
      "name": "Example Character",
      "research_topics": [
        "identity",
        "appearance",
        "personality",
        "relationships",
        "abilities",
        "history"
      ]
    }
  ],
  "evidence_output": "artifacts/discoveries/phase-0002-evidence.json",
  "evidence_receipt": ".work/evidence-receipts/phase-0002-evidence-receipt.json",
  "output": ".work/phases/phase-0002.json",
  "end_delimiter": "END WORLDBUILDER GENERATION REPORT"
}
```

Allowed research modes:

- `public_web`: research through the preflighted SearXNG stack. Record the actual queries and HTTP(S) sources.
- `provided_sources`: research user-provided files, notes, URLs, or canonical material. Record each source locator and hash or URL when available.
- `mixed`: combine provided and public-web sources.

There is no `none` mode. For original or user-canonical material, researching means carefully extracting and reconciling the user-provided canon before writing.

### Generation image analysis
When `build-state.json.settings.effective_image_mode` is true and the current UID includes the `appearance` research topic, inspect only the entity's own relevant primary/infobox image reachable from its approved source material. Do not sweep galleries or unrelated page art. Record visual observations in evidence with the same source/provenance discipline as written claims, then write the supported visual details naturally into content. Never put a source URL, wiki name, image locator, or phrases such as "per the image" into model-facing entry content. If the image fetch fails transiently (a timeout or connection error), retry it once after a short delay before falling back to text-only. A retry is not owed for a confirmed absence of a usable image or a genuinely disabled setting, only for a fetch that failed to complete; the evidence ledger records the outcome either way. When the setting is false, unavailable, or unknown, use text-only research and do not infer unseen visual facts. This behavior is generation-only; it does not expand discovery scope.

## Evidence ledger

Write one evidence record for every assigned UID. Never research an entry only indirectly through another entry's page.

```json
{
  "evidence_version": 1,
  "_worldbuilder": {
    "build_id": "...",
    "assignment_id": "wb-sample-raven-phase-0002",
    "assignment_sha256": "...",
    "manifest_sha256": "...",
    "research_mode": "public_web",
    "worker": "raven"
  },
  "entries": [
    {
      "uid": 7,
      "name": "Example Character",
      "research_status": "complete",
      "searches": ["Example Character official wiki history abilities"],
      "sources": [
        {
          "source_id": "S7-1",
          "locator": "https://example.invalid/source",
          "title": "Example source",
          "accessed_at": "2026-07-11T00:00:00Z",
          "source_type": "official"
        }
      ],
      "topics": [
        {"topic": "identity", "status": "supported"},
        {"topic": "appearance", "status": "supported"},
        {"topic": "personality", "status": "supported"},
        {"topic": "relationships", "status": "not_found"},
        {"topic": "abilities", "status": "supported"},
        {"topic": "history", "status": "conflicted"}
      ],
      "claims": [
        {
          "claim_id": "U7-C001",
          "topic": "identity",
          "text": "Concise supported fact.",
          "kind": "direct",
          "confidence": "high",
          "source_refs": ["S7-1"]
        }
      ],
      "conflicts": [],
      "unknowns": ["Relationship detail was not found in allowed sources."]
    }
  ]
}
```

Use `research_status` as follows:

- `complete`: supported evidence was found.
- `user_canonical`: claims were extracted from user-provided canon.
- `not_found`: the worker completed the required searches/inspection but found no support. Required topics must then be explicitly `not_found` or `not_applicable`.

Do not convert absence of evidence into invented facts. Record conflicts and unknowns explicitly. When a required topic is genuinely contradicted by two or more supported claims, mark that topic `conflicted` and preserve each competing claim with its own `source_refs`. The deterministic evidence gate materializes the structured conflict record from that declared topic state; it does not guess semantic contradiction from arbitrary prose. Optional `architecture.source_type_weights` scales the existing claim-confidence signal by cited source type and can supply conflict-ranking tiers when no explicit `architecture.canon_precedence` exists; equal weights remain tied, unconfigured source types are neutral, and an explicit precedence list always wins.
## Evidence gate

After writing the evidence ledger and before writing the phase, run:

```bash
python3 .work/worker-kit/scripts/evidence_gate.py \
  --build-state build-state.json \
  --assignment .work/assignments/wb_r1_raven.json
```

The parent may instead run the command after the evidence file appears and then instruct the worker to continue. In either arrangement, no phase may be accepted without the resulting evidence receipt.

The gate rejects:

- Missing or duplicate assigned UIDs, or an assigned UID absent from the authoritative manifest.
- Missing required research topics.
- Unsupported source references.
- Public-web evidence without recorded SearXNG queries and HTTP(S) sources.
- Evidence bound to another assignment, manifest, or build.
- A `complete` record with no supported claims.
## Writing from evidence

After the evidence receipt exists:

1. Write each assigned entry from the validated claims only.
2. Preserve explicit conflicts and uncertainty instead of selecting a convenient unsupported answer.
3. Do not add factual details because they are plausible, genre-typical, or remembered from model training.
4. When a required fact is `not_found`, omit it or state uncertainty in a way appropriate to the artifact; do not fill the gap.
5. Keep creator-facing citations in the evidence ledger unless the user asked for citations in the final prompt content.
6. When a character has a genuine opinion about a lore-bearing topic, pair the factual description with one short in-voice reaction showing how they actually talk about it.
7. For character builds, put situational voice that matters only on a topic into a keyword-triggered lorebook entry instead of expanding permanent `mes_example`; use `writing_quality.py situational-voice`/its contract so the entry is non-constant and topic-scoped.
8. Generated dialogue examples and in-voice snippets must pass the maintained cliché check in `writing_quality.py`; never teach known stock phrases through the examples the model is most likely to imitate.
9. A trivial-depth fact that does not justify its own entry may be compressed as a parenthetical association such as `Bluudale(metropolis)` on the related entry rather than dropped or expanded into a full entry.
10. Behavioral world-core redirection uses a named strategy: `avoid` redirects without acknowledging the off-topic input; `ignore-question` turns the exchange back to the player with a question. Record the chosen strategy rather than improvising one at generation time.
11. Phrase a behavioral rule positively wherever the meaning allows: pair or replace a prohibition ("never X") with the positive form ("always Y unless Z"). A rule the model can follow is stronger than one it must remember not to break; keep the prohibition only as the paired fallback.
12. Apply the per-fact test to every detail before it earns a place in a card-shell field: does this ever change how a character or the world responds? A detail that never changes a response belongs in the evidence ledger or nowhere, not in a shell field.
13. Where a build declares named behavioral rules (world-core entries, Soul Extractor runtime guides), check the generated first message against them for direct contradiction before shipping. A model takes style and precedent from the first message more than from any stated rule, so `writing_quality.py check-rule-consistency` reports the candidates for review; it never auto-rewrites.

The phase `_worldbuilder` metadata must include:

```json
{
  "assignment_id": "wb-sample-raven-phase-0002",
  "assignment_sha256": "...",
  "evidence_sha256": "...",
  "evidence_receipt_sha256": "...",
  "evidence_claims": {
    "7": ["U7-C001"]
  },
  "unsupported_claims": []
}
```

`evidence_claims` must include every assigned UID exactly. Every listed claim ID must exist in that UID's validated evidence record. A UID may have an empty list only when its evidence status is `not_found`.
## Parent acceptance

The parent must reject a phase unless:

1. The child runtime completed.
2. The assignment and evidence ledger still hash to the receipt values.
3. Every assigned UID has evidence coverage.
4. The phase contains every assigned UID once and no others.
5. The phase cites only valid evidence claim IDs.
6. `unsupported_claims` is an empty list.
7. The phase otherwise validates and the exact completion delimiter is present.

The post-generation audit must still compare factual content against the evidence ledger. The deterministic gate proves coverage and lineage; the semantic audit checks whether the prose accurately reflects the claims.
## Discovery-result integrity

Breadth discovery and per-UID research have different outputs, but both follow the same rule: write to a candidate/checkpoint path, validate, then commit atomically. A malformed or partially encoded file is incomplete. Use `repair_discovery_result.py` only as an explicit migration; retain its before/after receipt and revalidate lineage afterward.
## Budget-bound writing

Research coverage remains independent from context pressure. Do not mark a topic unsupported or omit an entity merely to meet a token target. After evidence passes, write to the UID's soft target where practical, never exceed its hard limit, and preserve all required activation, identity, era, relationship, and knowledge terms. `entry_cycle_gate.py` records the checkpoint estimate in the entry-cycle receipt.

When content must shrink to fit, cut in retention-ladder order (Tier 0 never cut; Tier 1 cut last; Tier 2 before Tier 1; Tier 3 first; see `prompts/generation-worker.md`), and route what Tier 2/3 material is cut, never delete it. Overflow is evidence that did not fit this entry, not evidence that was lost: write an overflow record (`source_uid`, `tier`, `claim_ids`, a one-line `descriptor` under 200 characters) pointing back into the evidence ledger, which already holds the full text. `write_stage` validates the record's shape; `phase_gate.py` aggregates overflow across the whole merge and reports "N entries had material scoped out; run a detail pass" rather than the material silently vanishing. A worker cannot allocate a new UID to hold overflow itself; that is a planning decision, surfaced once at merge, not a loop back to the worker that cut it.

## Dynamic-state-bound writing

Read `dynamic_state_plan_sha256` and the exact `dynamic_state_context` before writing each UID. Preserve probability, groups, weights, scoring, priority behavior, timed effects, matching sources, character/tag filters, generation triggers, greeting scope, automation ID, and outlet exactly. Emit only the target-neutral `extensions.worldbuilder_dynamic` envelope for non-default behavior. Do not write guessed SillyTavern-native fields; the parent-owned runtime adapter owns target mapping.
