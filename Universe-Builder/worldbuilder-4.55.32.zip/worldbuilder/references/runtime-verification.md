# SillyTavern runtime verification

Runtime verification has two evidence levels and must never conflate them.

- **Observed:** a host/bridge supplies real activation data from SillyTavern. The currently verified WorldInfoInfo extension surface is `/wi-triggered`, which returns the entries active in the last generation. It supports closure-membership comparison; it does not expose recursion-round depth, so depth must be reported as unobserved.
- **Synthetic fallback:** when a live bridge/introspection capability is unavailable, `runtime_verification.py` predicts direct key seeds plus the planned activation-graph closure. It reads both historical output-like `key`/`keys` fixtures and the authoritative manifest `emit.keys` / `emit.constant` semantics through `budget_semantics`. This is useful but is never described as observed SillyTavern behavior.

Batch 23 item 9's behavioral test-drive deliberately reuses this same synthetic predictor before assembling test context. Do not create a second activation engine for behavioral testing. A generated behavioral response plus lens verdict is stronger evidence about model behavior than a schema-only check, but the activation set is still predicted rather than observed. Batch 24 item 10's representative activation corpus also reuses this predictor, but freezes only authored `should_activate` / `should_not_activate` expectations; its persistent corpus is a regression oracle, not a behavioral-quality verdict, and intentional expectation changes require explicit replacement.

A divergence produces a review finding (unexpected/missed UIDs). Do not silently rewrite or prune entries from runtime telemetry.
