# Revision history and rollback

Every successful delivery seal records a content-hash-bound snapshot under `artifacts/revisions/` and appends it to `artifacts/revision-history.json`.

Rollback restores an already-sealed snapshot and **resets amendment depth to zero**. It is a fresh baseline, not another forward amendment. If a lock was applied after the target revision and rollback would change/remove that locked entry, stop and require explicit lock-conflict approval.

Use `revision_history.py --build-state ... list`, `rollback --revision rev-NNNN`, or `cherry-pick --revision ... --uid ...`. Cherry-pick prepares the existing selective-regeneration path rather than inventing a second patch/audit mechanism.
