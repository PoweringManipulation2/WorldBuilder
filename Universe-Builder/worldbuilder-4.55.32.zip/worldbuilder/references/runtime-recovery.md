# Resume and Recovery
## Navigation
- [Split worker ledger entries](#split-worker-ledger-entries)
- [Restamp a stage instead of invalidating the pipeline](#restamp-a-stage-instead-of-invalidating-the-pipeline)
- [Rebase instead of restarting](#rebase-instead-of-restarting)
- [Naming-stage recovery](#naming-stage-recovery)
Resume only from a user-owned build workspace containing `build-state.json` and `.worldbuilder-owner.json`. Read the state and frozen plans before deciding what remains.

First verify the ordered stage ledger, then run the integration resume gate:

```bash
python3 {baseDir}/scripts/pipeline_stage_gate.py \
  --build-state /absolute/path/to/build-state.json \
  --verify

python3 {baseDir}/scripts/integration_acceptance.py validate \
  --build-state /absolute/path/to/build-state.json \
  --stage resume
```

The stage gate rejects skipped, reordered, or stale transitions. The resume gate rejects a completed status whose required receipt is missing or stale. Keep successful phases, stable UIDs, assignments, evidence, and receipts intact. Use `lineage_invalidate.py` from the earliest changed stage, rebuild only invalidated outputs, and rerun every downstream gate.

Do not lower expected phase or entry counts to hide an interrupted worker.
## Split worker ledger entries
One worker is observed under several identities: the parent registers it by
`assignment_id`, the runtime observer records completion under the spawn `runId`, and an
event id may match neither. A completion arriving under an unfamiliar identifier now
resolves to the existing assignment and is recorded as an alias, so no duplicate entry is
created.

For a ledger already split by both conventions:

```bash
python3 {baseDir}/scripts/worker_run_ledger.py --build-state <path> --action reconcile
```

The completed record wins and absorbs the other's aliases and events. An `active` entry
whose assignment has a completed sibling is the parent's copy of a worker that finished;
the work happened, only the bookkeeping was doubled. Unrelated assignments are never
merged.

Do not delete a stuck `active` entry by hand: reconcile records what it absorbed, and a
manual edit loses the events attached to it.
## Restamp a stage instead of invalidating the pipeline
A stage receipt records the SHA of every evidence file, so correcting one artifact made
that stage stale and the only recovery discarded every downstream stage too. One receipt
fix therefore cost a full pipeline re-run.

```bash
python3 {baseDir}/scripts/pipeline_stage_gate.py --build-state <path> --restamp <stage>
```

Restamp re-collects the stage's evidence, which re-runs its own contract checks, and
re-records the result. It is not `--force`: a stage whose gate would now fail cannot be
restamped into looking valid, and a stage that is no longer applicable or was never
recorded is refused.

Downstream receipts keep their recorded values. Run `--verify` afterwards: anything that
genuinely depended on what changed still reports stale and is caught rather than papered
over. Use `--invalidate-from` when the change was semantic.

When a recorded repair rewrote a target after a producer ran, re-run the producer's own
command first (for example `entry_naming.py --stage normalize-output`, which rewrites its
receipt to the live hash and normalizes idempotently), then run the producer's restamp.
`--restamp ... --cascade` re-links downstream receipts, but it refuses as soon as a
consumer's own evidence is stale; the working order is consumer evidence first, then the
producer restamp. The refusal text says the same.

If a phase receipt was re-recorded after the wave (for example to clear a stale phase_1
binding) and a phase now reads as older than dispatch, repair the receipt instead of the
phases: `phase_gate.py --restamp pre-dispatch` refreshes its bindings while preserving the
recorded dispatch instant, and `--preserve-created-at <unix>` re-pins an instant the
ledger itself recorded earlier. A phase whose own `generated_at_unix` is a placeholder
from before the build cannot be repaired by any receipt edit: its own metadata is wrong.
## Rebase instead of restarting
An entry-cycle receipt is bound to its **slice** (the assignment's own rows, the edges
touching them, and its neighbours), not to the whole manifest. A change elsewhere in the
build no longer expires it, so twenty workers no longer restart because one entry moved.

When a receipt does go stale, rebase before regenerating anything:

```bash
python3 {baseDir}/scripts/entry_cycle_gate.py --build-state <path> \
  --assignment <assignment.json> --stage rebase
```

Rebase keeps every completed UID whose own hash is unchanged, resets and names the ones
that moved, and reports `kept_uids`, `reset_uids`, and the next action. A UID with no
recorded hash is reset rather than trusted: no baseline means no evidence the work is
still valid. A neighbour change resets the whole assignment, because slices embed
neighbour context and prose may have referenced it.

Rebase refuses when the assignment itself changed. That is a genuine regeneration, and
salvaging progress across it would carry a stale map slice forward.

A single stale checkpoint inside an otherwise complete cycle no longer costs the cycle:
`entry_cycle_gate.py --stage refresh --uid <uid> --checkpoint <file>` re-validates that one
checkpoint against the same contract the write stage enforced and refreshes its recorded
hash in place. It never adds, removes, or reorders UIDs, and a checkpoint whose evidence
binding changed still requires a normal write.

Do not reuse an expired assignment after the era plan, placement plan, budget plan,
dynamic plan, target choice, or integration plan changes.

Read `full-integration-acceptance.md` before resuming any Character, World, Lorebook, Group, Persona, Audit, Prune, Quick, Full Detail, or Multi-era pipeline.
## Naming-stage recovery

If the stage ledger stops at `merge_complete`, run the naming normalizer against the current merge output and advance `entry_names_normalized`; do not jump directly to post-generation audit.

If a later repair rewrote the naming target, the recorded naming receipt is stale: re-run
`entry_naming.py --stage normalize-output` against the current target, then restamp the
stage and repair its chain links once every consumer's own evidence is current.
