# Four-Lens Audit Proof Pipeline
<!-- phase-contract --> Exit contract: run `python3 {baseDir}/scripts/phase_contract.py --build-state <build-state> --stage <pre_generation_audit>` before this stage's gate; rendered copies ship in the build's worker kit under `exit-contracts/`.
## Navigation
- [Purpose](#purpose)
- [Fixed lenses](#fixed-lenses)
- [Plan](#plan)
- [Dispatch](#dispatch)
- [Structured result](#structured-result)
- [Parent runtime proof](#parent-runtime-proof)
- [Audit gate](#audit-gate)
- [Patching and rerun](#patching-and-rerun)
- [Proof boundary](#proof-boundary)
## Purpose
Require four hash-bound audit lenses for every applicable pre-generation or post-generation audit. Independent execution is the default. Consolidated execution is allowed when explicitly planned, but it must still produce four separate assignments, outputs, expected-check sets, terminal delimiters, and parent-observed runtime receipts. A combined summary cannot substitute for lens-specific proof.
## Fixed lenses
- **Compass** - card routing, field registry, target compatibility, era-plan fidelity, locked settings, source stance, schema routing, plan lineage, manifest, and requested-scope compliance.
- **Weaver** - activation graph, recursion, placement, groups, token pressure, keys, directed relationship triggers, required emitted terms, resolved order/priority/depth/role/outlet, influence classes, target mappings, and always-on pressure. Before judging any `selectiveLogic` value, read the build's era routing. Under
`scenario` the secondary keys are an era phrase plus its aliases and AND ANY (`0`) is
required; under `root_toggle` they are a single machine token and AND ALL (`3`) is
required. Reporting AND ANY as a leak on a `scenario` build is a false finding: the
architecture gate requires that value, so the report cannot be acted on. On era-root
builds Weaver also walks the cascade as a tree: every gated entry carries its era token with AND ALL logic, cascade levels strictly increase, `delay_until_recursion` is set below the root, no entry above the detail level sets `prevent_recursion`, and every multi-era subject shares an inclusion group with `group_override`. A break anywhere in that chain silently disconnects the subtree beneath it, so report the highest broken node rather than every orphaned descendant.
- **Scout** - source and entity-state coverage, missing eras, missing relationship states, discovery receipt, inventory breadth, aliases/forms, and omitted or deferred material.
- **Warden** - IDs, chronology, knowledge state, relationships, temporal leakage, aliases, character/state ownership, containment, dangling references, contradictions, and graph integrity. Warden also owns core content on builds using the character core/state split: a `core_invariant` entry spans every era its subject exists in,
so any status, rank, allegiance, location, relationship, or knowledge claim in it leaks across all of them. `character_contract.suggest_core_review` supplies candidate passages, but it is keyword matching and is wrong in both directions; read the entry rather than trusting or dismissing its list. On era-root builds Warden owns token integrity: exactly one root ships enabled, no root emits another era's token, no non-root entry contains two era tokens, no token is a substring of another, and every planned absent entity appears in its era root's roster. Absence belongs in the constant root because a keyword-triggered correction only fires after the model has already used the name.
Shipped-state encoding for those checks: the default root carries `"emit": {"constant": true, "enabled": true}` + `"activation": {"strategy": "constant"}`; each other root carries `"emit": {"constant": true, "enabled": false}` + `"activation": {"strategy": "disabled"}`; the fields move together.

In `independent` mode, one child session, run ID, or completion event cannot satisfy more than one lens. In `consolidated` mode, the same observed run may execute all four assignments, but every lens retains a separate result and receipt.
## Plan
Create the run from the parent using the immutable skill script:

```bash
python3 {baseDir}/scripts/audit_plan.py \
  --build-state /absolute/path/to/build-state.json \
  --stage pre-generation \
  --execution-mode independent
```

Use `--stage post-generation` for the final artifact. The plan originates one `audit_run_id`, hashes the target and manifest, inventories every UID/path, lists exact supporting artifacts (including the bound field registry, integration plan, character plan, era plan, placement plan, and current planning receipts whenever present), and writes four assignments:

```text
.work/audit-assignments/<stage>/compass.json
.work/audit-assignments/<stage>/weaver.json
.work/audit-assignments/<stage>/scout.json
.work/audit-assignments/<stage>/warden.json
```

Results and runtime receipts have distinct paths. For pre-generation the four exact result paths are:

```text
.work/findings/pre-generation/compass-findings.json
.work/findings/pre-generation/weaver-findings.json
.work/findings/pre-generation/scout-findings.json
.work/findings/pre-generation/warden-findings.json
```

Post-generation uses the same filenames under `.work/findings/post-generation/`. Runtime receipts use `.work/audit-runtime/<stage>/<lens>-runtime.json`.

**Scoped re-audit (Batch 12).** Add `--scope changed --change-set <path>` (a `change_set.py` output) to limit all four lenses to the change set's `changed_uids` plus `neighbour_affected_uids`; a neighbour-only change counts the same as a directly-changed one, never treated more leniently. Every assignment's `entries` list is filtered to exactly that scope, and the plan's own `scope_mode`/`change_set_sha256`/`full_entry_count` fields record which mode ran and against how much of the full manifest, without needing to open an individual lens assignment to find out. `audit_gate.py` needs no scope-aware logic at all: it already derives its expected UID coverage from the assignment's own `entries`, which is already the narrowed set. This flag only ever affects the four LLM lenses; `soul_contract.py`'s prose metrics and `budget_contract.py`'s seven simulations have no `--scope` argument and always run against the full artifact, since they are script passes, not child agents, and scoping them would not save the cost this flag exists to save.
**Iteration ledger and ceiling (Batch 59).** `audit_plan.py` stamps `iteration` (1-based) and `max_iterations` on the plan and every assignment; the iteration is derived from the plans on disk (the canonical plan plus its `roundN/` archives), never from a stored counter. When the next iteration would exceed the ceiling, planning refuses without writing a plan, names the outstanding findings from the last run, and writes `audit-<stage>-ceiling.json`; `delivery_gate.py` then blocks delivery while those findings remain outstanding. Raise `--audit-max-iterations` or resolve the findings to continue. A default `--scope auto` re-audit plans iteration 1 as `full` and later iterations as `changed`, deriving the delta from the patch log with the same fail-safe posture: whenever a delta cannot be derived the run falls back to `full` and records `scope_fallback_reason` in the plan. On a `changed` run every assignment also carries `prior_findings` (each with its severity and the status claimed by the fix), `verify_ids`, and `regression_uids` (changed UIDs plus their immediate graph neighbours); every `verify_ids` entry must be confirmed resolved or still open in the result's `verifications` array, and a still-open finding must remain re-reported, or `audit_gate.py` rejects the run.
## Dispatch

For `independent` mode, spawn each assignment with `prompts/audit-worker.md`, a stable `taskName`, human-readable Compass/Weaver/Scout/Warden label, and `cwd` set to the build root. Use isolated context unless a lens genuinely needs transcript state. Pass the assignment's stamped `run_timeout_seconds` as `sessions_spawn`'s `runTimeoutSeconds` argument (DR-064). If a lens times out, record it with `record_audit_runtime.py --status timed_out` (never `--status failed`), then re-dispatch the same lens per `repair_loop_guard.py`'s `retry_with_longer_timeout` verdict. Yield for completion events rather than polling.

For `consolidated` mode, one child may execute the four assignments sequentially, but must write four distinct result files and exact delimiters. Each lens must inspect every assigned UID and every lens-specific supporting artifact. The child cannot write or invoke the parent runtime recorder.
## Structured result

Each result is `worldbuilder-audit-result` version 2 and must include:

- Exact assignment/build/run/stage/lens/auditor/task/target/manifest/scope binding.
- Exact assigned and reviewed UID coverage.
- `artifacts_inspected` matching every required path and SHA-256 exactly.
- `reviewed_entries` matching every assigned UID and JSON Pointer path exactly, each with a substantive note.
- Every expected check exactly once with a substantive note and valid status.
- Structured findings with unique IDs, severity, category, JSON Pointer or null, summary, evidence claim IDs, and recommended action; file evidence must cite durable `artifacts/`, `input/`, `creations/`, or `.work/findings/<lens>-evidence/` paths, never scratch/temp paths.
- A substantive summary.
- An exact terminal delimiter as the final non-empty line.

A generic "no issues" paragraph, a missing lens, a short placeholder, or a self-declared runtime receipt fails.
## Parent runtime proof

After OpenClaw delivers a child completion event, the parent records it:

```bash
python3 {baseDir}/scripts/record_audit_runtime.py \
  --build-state /absolute/path/to/build-state.json \
  --stage pre-generation \
  --lens compass \
  --child-session-id "<actual child session>" \
  --run-id "<actual sessions_spawn run id>" \
  --runtime-event-id "<actual completion event id>" \
  --status completed \
  --spawned-at "<parent-observed timestamp>" \
  --completed-at "<parent-observed timestamp>" \
  --parent-session-id "<parent session>"
```

Repeat for all four lenses. The recorder verifies the current assignment and result hash before writing a receipt. Runtime recorder and audit gate scripts remain parent-only under `{baseDir}/scripts`; they are not staged into `.work/worker-kit/`.
## Audit gate

Run:

```bash
python3 {baseDir}/scripts/audit_gate.py \
  --build-state /absolute/path/to/build-state.json \
  --stage pre-generation
```

The gate reads the plan-declared execution mode itself; there is no
`--execution-mode` flag on the gate.

The gate recomputes every proof and requires:

- Exactly four required lenses.
- One current assignment and one structured result per lens.
- One current parent-observed runtime receipt per lens.
- Four distinct child session IDs, run IDs, and completion event IDs in `independent` mode; one shared observed run is permitted in `consolidated` mode.
- One shared parent session and one shared `audit_run_id`.
- The plan-declared execution mode and four separately validated lens proofs.
- Exact target, manifest, scope, UID, artifact, check, delimiter, and file-hash binding.

It writes one content-bound audit-gate receipt. `phase_gate.py` and `delivery_gate.py` recompute the proof rather than trusting the receipt by shape alone.
## Patching and rerun

Reconcile duplicate or conflicting findings before patching. Apply only authorized JSON Pointer operations, record exact before/after hashes, and run deterministic validators.

Any patch that changes the audited target invalidates the post-generation audit. Create a new post-generation audit plan, run all four audit lenses again on the corrected bytes, pass `audit_gate.py`, then seal and deliver.
## Proof boundary

This is a parent-observed OpenClaw proof contract, not cryptographic remote attestation. It prevents report-only bypasses, stale files, duplicated sessions, and child self-certification within the intended workflow. A host administrator with unrestricted filesystem control can still alter local files; preserve workspace permissions and logs accordingly.

## Model selection

Audit assignments freeze `requested_model` from `models.audit`, falling back to `models.subagent`. Before each OpenClaw spawn, run `model_routing.py route --assignment <path>`; pass a non-null `sessions_spawn_model` exactly and omit the override for inherit. Verify the accepted spawn with `model_routing.py verify --assignment <path> --resolved-model <resolvedModel>`. Stop the wave on invalid routing or a mismatch.

## Naming prerequisite

Post-generation audit dispatch is blocked until the semantic entry-label receipt is current. Source-derived labels are a Compass/Scout finding, not an acceptable editor-facing convention.
