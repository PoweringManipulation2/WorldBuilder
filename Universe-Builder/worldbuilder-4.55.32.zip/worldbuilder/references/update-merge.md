# Update and Merge Mode
## Navigation

- [Goal](#goal)
- [Conflict policy](#conflict-policy)
- [Targeted-change checkpoint](#targeted-change-checkpoint)
- [Procedure](#procedure)
- [Validation](#validation)
## Goal

Merge new facts or entries into an existing card/lorebook without losing metadata, stable identifiers, or target-specific settings.
## Conflict policy

Before editing, set one policy:

- Existing artifact wins.
- New material wins.
- Source stance decides.
- Report conflicts for user choice.

Never resolve meaningful conflicts by silently concatenating contradictory text.
## Targeted-change checkpoint

If the request is confined to named existing UIDs/fields and does not add a source pass or alter frozen planning structure, start with `selective_regeneration.py plan`; see `references/iterating-existing-lorebook.md`. Let `pipeline_stage_gate.py --next` guide the remaining scoped path. Locked requested entries are reported by name/reason and excluded before proceeding.
## Procedure

1. Follow `references/batch-pipeline.md` for build/phase contracts.
2. Validate and inventory the existing artifact. A `.png` upload is a card container: extract via `png_card.py` (`ccv3` preferred over `chara`) before inventory begins; the merge itself operates on the extracted JSON.
3. Run the intake diagnostic once, upfront, before matching anything: `scripts/update_merge_intake.py --input <artifact>` with `references/update-merge-intake-checklist.md`. It itemizes provenance, schema fit, keywording, recursion safety, writing quality, and sizing, so the real scope of the merge is visible before work starts. It is a diagnostic, never a gate, and never a mandate to fix everything it reports.
4. Match entries by stable identity first, then explicit user-approved title/key mapping.
5. Preserve IDs for existing entries.
6. Allocate IDs only for genuinely new entries.
7. Preserve unknown top-level and extension metadata.
8. Apply the amendment through `manifest_amendment.py`; never a direct file write. It computes the change set (`change_set.py`) between the live manifest and the proposed merge first: a structural change (registry, default profile, era/character/placement/budget/dynamic-state plan, or discovery receipt) is refused outright with no exceptions, and must go through full re-baseline instead (`lineage_invalidate.py --from-stage manifest`, whole-stage, then re-plan). A genuine, entry-level amendment writes the manifest, selectively invalidates only the phases/evidence/findings the change set identifies as affected (`lineage_invalidate.py --from-stage manifest --change-set <path>`), and produces a permanent, auditable receipt; the change set itself is written to disk before the manifest, never a disposable intermediate.
9. Produce an exact added/changed/removed report.

Do not rewrite all IDs or generate simultaneous V1/V2/V3 mirrors unless a tested target explicitly requires them.
## Validation

Use `verify_patches.py` for exact byte-level change evidence and the mode-appropriate release gate. A missing or ambiguous identity is a conflict to resolve, not permission to overwrite another entry.

## Dynamic-state merge rules

Preserve unknown and neutral dynamic extensions. Reconcile group membership, greeting scope, automation registries, and outlet consumers against stable UIDs before merge. Conflicting policies are not last-write-wins; stop for review. A frozen plan (era, character, placement, budget, or dynamic-state) is a structural artifact: `manifest_amendment.py`'s change-set check refuses to touch it as part of an amendment; changing one is not a merge, it is a re-plan (`lineage_invalidate.py --from-stage manifest`, whole-stage, then rerun planning/output gates).
