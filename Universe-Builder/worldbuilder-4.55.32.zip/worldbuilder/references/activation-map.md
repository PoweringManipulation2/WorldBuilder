# Activation and Recursion Map
## Navigation
- [Authority](#authority)
- [Frozen defaults](#frozen-defaults)
- [Manifest contract](#manifest-contract)
- [Map ledgers](#map-ledgers)
- [Assignment slices](#assignment-slices)
- [Commands](#commands)
- [Placement projection](#placement-projection)
- [Diagnosing a failing manifest](#diagnosing-a-failing-manifest)
## Authority
Use coordinated artifacts:
```text
build-list.md    scope, purpose, research topics, era, tier, batch
manifest.json    machine-authoritative settings and graph edges
recursion-map.md exact readable projection of the manifest
```
Never hand-author map settings independently. Edit the manifest, render the map, and fail planning on any mismatch.
## Frozen defaults
Every build freezes `artifacts/field-registry.json` and `artifacts/default-profile.json`. The registry defines names, aliases, types, owners, and map paths. The profile defines build/layer defaults.
```text
blank/omitted = inherit frozen default
None          = explicitly disabled
unsupported   = target cannot represent it
explicit      = intentional override
```
Sparse rows are deterministic because the profile hash is bound into planning lineage.
## Manifest contract
The manifest binds both frozen hashes and owns `activation_graph` under contract `worldbuilder-activation-graph-v1`. Every entry declares:

```json
{"activation":{"strategy":"keyword","recursion_role":"intermediary","emits":["Target Name"],"forbidden_emits":[]}}
```

Strategies: `constant`, `keyword`, `hybrid`, `vector-only`, `manual`, `disabled`.
Roles: `root`, `seed`, `anchor`, `intermediary`, `leaf`, `blocked`.
`emits` contains exact graph-driving terms that must occur naturally; `forbidden_emits` blocks dangerous cross-era/state triggers.
### Era-root cascade fields
Under `worldbuilder-era-root-v1` (`root_toggle` routing only; `scenario` routing uses AND ANY and no cascade), entries carry a second set of declarations. Build them here, at planning time; the era gate validates the cascade but does not teach it, so a manifest built without these fails late instead of never being built wrong.

**Two role axes, not one.** `activation.recursion_role` is graph topology: how an entry sits in the fan-out. `architecture.era_cascade_role` is era-gate stage: when in the cascade it may fire. They are independent and both are required. An era context is typically `recursion_role: "seed"` and `era_cascade_role: "context"`. The shared word `root` means different things on each axis and must not be conflated: a cascade root is the constant era entry, while a graph root is the fan-out origin.

This shape applies to `root_toggle` routing only; under `scenario` there is no cascade and era-scoped entries use `selective_logic: 0` (AND ANY); see `era-system.md`.

```json
{
  "activation": {"strategy": "keyword", "recursion_role": "seed", "emits": ["Aeron"], "forbidden_emits": []},
  "architecture": {"era_cascade_role": "context", "era_ids": ["age-of-ash"], "subject_id": "aeron"},
  "emit": {
    "keys": ["Aeron"], "secondary_keys": ["EraAgeOfAshActive"], "selective": true,
    "extensions": {"selective_logic": 3, "delay_until_recursion": true, "recursion_level": 1,
                   "group": "wb.aeron", "group_override": true}
  }
}
```

Rules the manifest must satisfy before generation under `root_toggle` routing:

- The era root is `constant`, not selective, declares `architecture.emits_token`, and sits at cascade level 0.
- Every other era-scoped entry is selective with `selective_logic: 3` (AND ALL) under this `root_toggle` routing and carries its era's token in `secondary_keys`. AND ANY leaks the moment an alias is added.
- Cascade levels strictly increase root → context → state → detail, and every non-root entry sets `delay_until_recursion`.
- `prevent_recursion` is forbidden on root, context, and state; `exclude_recursion` is forbidden anywhere below the root.
- Any `subject_id` appearing in more than one era shares an inclusion group with `group_override: true`.
- `selectiveLogic`/`selective_logic` resolution order: the first present key wins even when its value is an explicit `null`: `emit` level, then `emit.extensions`, then the layer default from `default-profile.json`; only absence falls through.

Read `era-system.md` before building a multi-era manifest. `era_root_contract.py planning` enforces all of the above.
## Map ledgers
Every UID appears once with identity, layer, eras, strategy, primary/secondary keys, filter logic, recursion role, emitted/forbidden terms, edge counts, and sparse special operations. Era-root builds add cascade role, era token, cascade level, and inclusion group to every row, so the tree is legible in the readable map and not only in the manifest. Character rows also include `character_id` and `character_state_id`, binding the activation graph to `character-plan.json`. Strategy is always explicit; `Special` is blank when the profile supplies all optional settings.

Every edge records source/target UID, source trigger, matched target primary key, literal/regex mode, recursion level, required/optional status, era scope, fan-out cost, and reason. Literal triggers must equal a target key after case folding; regex edges require a tested sample.

The gate rejects unknown UIDs, missing emits, unmatched keys, leaf/blocked fan-out, recursion-setting conflicts, vector-only critical controls, keyed vector-only entries, keyless keyword/hybrid entries, undeclared matching emits, stale hashes, and map tampering. For era-root builds it also rejects a broken cascade: a missing or non-constant era root, an entry lacking its era token, AND ANY logic on a gated entry, non-increasing or wrong cascade levels, a missing `delay_until_recursion`, `prevent_recursion` above the detail level, and a multi-era subject without a shared inclusion group.
## Assignment slices
Generation assignment v3 embeds an exact `map_slice`: assigned rows, incoming/outgoing edges, neighbors, required/forbidden emitted terms, and overrides. Character-bearing slices also include the exact `character_plan_sha256` and a `character_context` section with identity, behavior, selected state, split rationale, required/forbidden terms, and directed relationships.

```bash
python3 {baseDir}/scripts/assignment_map_slice.py --build-state /absolute/path/build-state.json --uids 17 18 19
```

Copy the slice plus activation-map, registry, and profile hashes into the assignment. Evidence and entry-cycle gates reject edits or stale lineage. Workers emit required terms, avoid forbidden terms, never invent graph-driving keys, and inherit blank settings.
## Commands
```bash
python3 {baseDir}/scripts/activation_map_gate.py --build-state /absolute/path/build-state.json --render
python3 {baseDir}/scripts/activation_map_gate.py --build-state /absolute/path/build-state.json
python3 {baseDir}/scripts/planning_gate.py --build-state /absolute/path/build-state.json
```

Planning binds discovery, identity, manifest, registry, profile, activation map, architecture, build list, and build fingerprint before generation.
## Placement projection
For lorebook-bearing builds, the activation ledger also projects the frozen `worldbuilder-placement-influence-v1` result. Default position/order values may remain blank in the readable map because `default-profile.json` owns them; `assignment_map_slice.py` resolves them into `placement_context` for workers.

Each assigned UID receives purpose, influence class, semantic position, order, priority, depth/role, outlet, activation path, target mapping, and any approved override reason. The map gate and placement gate are complementary: the activation gate proves graph executability, while `placement_contract.py` proves prompt location and influence intent. Do not encode placement as a recursion edge or use a later position to compensate for a missing activation path.
## Diagnosing a failing manifest
```bash
python3 {baseDir}/scripts/activation_map_gate.py --build-state <path> --diagnose
```

Read-only. Reports every activation problem in one pass with a suggested fix per finding:
duplicate UIDs, malformed or misleveled edges, edges referencing missing entries, `prevent_recursion` on an entry with outgoing edges, and emitted terms not declared in `activation.emits`.

Later findings can echo an earlier cause, so fix the first and re-run. Once it reports
zero, run `--render` and then the gate.
