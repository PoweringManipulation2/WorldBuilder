# Lorebook Architecture
## Navigation
- [Mandatory architecture](#mandatory-architecture)
- [The world index](#the-world-index)
- [Single-era layers](#single-era-layers)
- [Multi-era architecture](#multi-era-architecture)
- [Activation and recursion map](#activation-and-recursion-map)
- [Entry selection and budget](#entry-selection-and-budget)
- [Character entries](#character-entries)
- [Testing](#testing)
## Mandatory architecture
WorldBuilder lore-bearing builds use a deliberate retrieval architecture. The four-layer vocabulary is not a JSON schema, but the manifest must assign every entry a functional layer and activation path. Do not replace it with an unstructured list of wiki summaries.

Every World, standalone Lorebook, and shared Group lorebook requires exactly one root control entry:

- `world_core` for a single-era build;
- `world_invariants` for a multi-era build.

The root is constant, concise, and prevents recursion. Entries labeled root/always-on must actually be emitted as constant.
## The world index
Retrieval only inserts an entry the chat text already triggered, so an entry whose name never appears in chat is unreachable for the whole session. One optional `world_index` entry closes that: a constant, `before_char` roster of the canonical names the book can answer for. The model reads a name, writes it, and the real entry arms on the **next** turn from the ordinary depth buffer.

It therefore reaches entries through the model's output, never through recursion, and `prevent_recursion: true` is mandatory; a roster that fed the recurse buffer would arm everything it names on every turn. Role is `blocked`, `activation.emits` is empty, and it owns no graph edges. Render it with `world_index.py render`; never hand-write it, because a roster name that is not one of that entry's own primary keys can never arm anything. It is constant, so it is budgeted against the permanent constant meter (`world_index.index_budget`), and overflow is a split signal: drop members with `architecture.index_member: false`, never truncate.

Multi-era builds carry one index per era, each owning exactly one era id and gated on that era's own token at cascade level 1 (DR-129): the era root keeps the token and the negative-state guards, the index keeps the roster. A single-era build carries at most one, constant.

```bash
python3 {baseDir}/scripts/world_index.py render --manifest artifacts/manifest.json
python3 {baseDir}/scripts/world_index.py validate --manifest artifacts/manifest.json --budget-plan artifacts/budget-plan.json
```
## Single-era layers
```text
LAYER 0: WORLD INDEX (optional)
constant; blocked; prevents recursion; rendered from the manifest
canonical names only, so the model can name what it cannot yet see

LAYER 1: WORLD CORE
constant; concise; prevents recursion
hard setting laws, stable premise, selected timeframe

LAYER 2: CATEGORY / FACTION / CAST ANCHORS
constant only when concise and necessary; otherwise keyword-triggered
names intentional child entries and seeds controlled retrieval

LAYER 3: CHARACTERS
keyword-triggered; canonical-v1 character format
relationship and location names provide intentional edges

LAYER 4: LOCATIONS / EVENTS / OBJECTS / CONCEPTS
keyword-triggered leaves or controlled cross-links
```

Large builds should not make every anchor constant. Keep the permanent layer small and use exact activation paths.
## Multi-era architecture
Read `era-system.md` in full. Multi-era changes the structure rather than merely adding era words to ordinary entries:

```text
WORLD INVARIANTS
ERA CONTEXT entries
ERA-FILTERED anchors
ERA-FILTERED characters
ERA-FILTERED locations and changing concepts
TEMPORALLY REACHABLE events
TRULY INVARIANT shared details
```

The approved era plan and manifest architecture are deterministic authorities. Both routings require explicit boundaries and world state, state assertions, prohibited state terms, and knowledge restrictions. `worldbuilder-era-root-v1` additionally requires one constant root per era emitting a unique single-word token, an AND ALL token gate on every era-scoped entry, strictly increasing cascade levels, and inclusion groups for multi-era subjects. Legacy `worldbuilder-era-router-v1` instead requires exactly one canonical `Era: ...` phrase per era, Scenario conflict detection, and Scenario matching connected to those keywords. Every Era Context includes known past, prohibited future facts, and `KNOWLEDGE LIMITS THIS ERA`.
## Activation and recursion map
The manifest owns activation settings and graph edges. `recursion-map.md` is rendered from it and validated byte-for-byte at the semantic level. Read `activation-map.md`.

Each ledger row records strategy, keys, secondary filters, recursion role, era, edge counts, emitted/forbidden trigger terms, and only non-default special operations. Strategy is always explicit; blank optional settings inherit from the frozen profile.

```text
root/control -> anchor
Era Context -> active anchor/entity (every active name is a declared emitted term and validated edge)
anchor -> character/location
character -> relationship/location/object
```

Every edge records source UID, target UID, exact trigger emitted by the source, exact target key, level, required/optional status, era scope, reason, and fan-out cost. Keywords are graph edges: a target key is not useful recursively unless the source content is planned to emit it.

Root entries normally block outgoing recursion unless the manifest intentionally assigns a different control pattern. Era Context entries are seeds because their active-entity lists drive selected-state retrieval. Leaves and blocked entries cannot have outgoing edges. Critical control/era entries cannot be vector-only.
## Entry selection and budget
An entry earns a place when it changes behavior, prevents contradiction, supplies reusable facts, supports an intentional activation edge, or needs a distinct era/priority/trigger.

Do not merge facts that require different era filters or current states. Do not split facts merely to increase count.

Budget permanent and conditional content separately:

1. Keep root and Era Context entries concise.
2. Preserve contradiction-prevention and current-state information.
3. Remove duplicated prose before removing factual coverage.
4. Merge only entries with identical activation, era, placement, and recursion needs.
5. Never prune era-state duplication when it is the mechanism preventing leakage.
## Character entries
Read `character-template.md`. Every lorebook character uses the canonical labeled order. In multi-era builds, meaningful state changes create separate entries with secondary era keys and Scenario matching.
## Testing
Test systems, not only fields:

- root entry is truly constant;
- direct character/location activation;
- one and only one Era Scenario phrase selects the correct Era Context;
- conflicting Scenario phrases fail rather than choosing silently;
- only the selected character state activates;
- future event does not appear in an earlier-era ordinary entry;
- event activates in its own and later eras, never earlier;
- recursion stops at intended leaves;
- permanent budget remains bounded;
- canonical character headings and order pass.

`planning_gate.py` invokes the architecture planning gate. `delivery_gate.py` invokes the output architecture gate.
## Context-pressure architecture
Design the activation graph and placement plan together with the frozen context budget. Constant roots consume permanent lore budget; direct keyword/vector matches and recursive edges consume separate activation targets; optional fan-out is included in the worst-case simulation. Prefer narrower activation and deduplicated prose over deleting supported entities or temporal safeguards.
## Dynamic state and variation
Use `worldbuilder-dynamic-state-v1` only when optional behavior is intentional: mutually exclusive eras or forms, random encounter pools, persistent scene state, cooldown ambient events, delayed later-story events, greeting variants, or shared-lore character filters. Required world facts and control paths remain deterministic. Plan groups and filters alongside activation, placement, and budget so no optional operation hides required coverage or breaks era isolation.
