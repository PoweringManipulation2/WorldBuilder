# Audit Mode
## Navigation
- [Scope](#scope)
- [Procedure](#procedure)
- [Severity](#severity)
- [Patching](#patching)
- [Output](#output)
## Scope
Audit an existing JSON, PNG card, CHARX, or persona against its declared format, SillyTavern compatibility, and optional WorldBuilder profile. Do not assume the file was produced by WorldBuilder. Call `capability_tiers.detect_tier` first and state the result up front (Unbound/Legacy-bound/Bound). Unbound is not a degraded starting point; format validation, structural checks, and the diff/patch machinery below all work on a hand-made or third-party artifact with no WorldBuilder history at all (DR-072).
## Procedure
1. Copy and hash the input. A `.png` is a card container: extract via `png_card.py` (`ccv3` preferred over `chara`); the audit runs against the extracted JSON, never against raw image bytes.
2. Detect format structurally.
3. Run the correct deterministic validator.
4. Inspect activation, prompt placement, IDs, assets, and target-specific settings.
5. When WorldBuilder architecture metadata is present, inspect canonical character routing, `character-plan.json` lineage, character/state UID ownership, required identity/voice/current terms, directed relationships, knowledge boundaries, World Invariants, Era Context coverage, Scenario matching, secondary-era filters, event reach, life/death state, and future leakage. Treat an intentional blank World Scenario and compact World Description as design contracts, not omissions.
6. Separate true errors from compatibility warnings and editorial advice.
7. Offer patches; never apply destructive changes without authorization.
8. Revalidate patched bytes and rerun the architecture gate when applicable.
## Severity
- Critical: data loss, wrong format, unsafe archive, audit bypass, or unrecoverable pipeline corruption.
- High: import/runtime failure or material behavior error.
- Medium: compatibility/reliability weakness.
- Low: maintainability, documentation, or optional style issue.
## Patching
Use JSON Lines with exact JSON Pointer paths. Verify every changed value against current output with `verify_patches.py`. Pass `--before` with the pre-patch snapshot to also check for collateral damage (unknown-field loss, extension-namespace loss, or a whole entry disappearing) that no patch record itself authorized; without it, verification is patch-log-only, confirming only that each declared target changed correctly, exactly as before this flag existed. Duplicate identities or ambiguous targets block automatic patching.
## Output
Return:

- Format/profile tested.
- Findings with evidence and severity.
- Safe fixes applied, if authorized.
- Remaining warnings.
- Validation commands/results.
- Live-test limitations.

The era-router audit verifies canonical Scenario keywords, conflict rejection, boundaries, world-state summaries, active-entity edges, knowledge limits, state assertions, prohibited terms, and origin-plus-later event reach.
## Budget and pruning audit
When a current WorldBuilder budget plan is present, verify its hash lineage, profile, permanent and constant pressure, seven activation simulations, per-entry hard limits, final-output estimates, and every pruning receipt. A pruning receipt now proves either worst-case activation pressure or total content tokens genuinely decreased, not tokens alone (DR-073). Confirm the receipt's `before_worst_case_pressure`/`after_worst_case_pressure` and `before_token_estimate`/`after_token_estimate` are both present and at least one improved. Confirm that pruning did not conceal missing source scope or remove world invariants, era isolation, knowledge boundaries, status changes, identity states, required relationships, required activation paths, or dynamic-state membership (inclusion group, sticky/cooldown/delay, greeting-bound) without an explicit `protected_removal_approved` declaration.

Before release, read `full-integration-acceptance.md`; require the frozen route-specific integration plan and current receipts, skipping only systems marked not applicable.
