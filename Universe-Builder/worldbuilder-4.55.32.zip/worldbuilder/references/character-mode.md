# Character Mode

## Navigation

- [Output](#output)
- [Timeframe choice](#timeframe-choice)
- [Workflow](#workflow)
- [Canonical field routing](#canonical-field-routing)
- [Identity, behavior, and relationships](#identity-behavior-and-relationships)
- [Supporting lore](#supporting-lore)
- [Validation and delivery](#validation-and-delivery)

## Output

Default: one Character Card V3 Schema 1 JSON, optionally packaged as CHARX. Read `card-shell-routing.md` and freeze one card-shell plan per output card.

Timeframe options:

- `single`: one card for one confirmed timeframe.
- `set`: one Schema 1 card per approved era when the character changes meaningfully.
- A requested single card with an embedded multi-era lorebook is a Schema 2 hybrid and must route through the World/embedded-lorebook pipeline instead of pretending Schema 1 can hold the system.

## Timeframe choice

Character Mode must ask for the character's timeframe. Do not silently blend all canon eras into one Description and Personality.

When `set` is selected:

1. Perform one shared source synthesis and propose era boundaries using the character's role, relationships, knowledge, form, allegiance, and life status.
2. Ask the user to confirm the era plan before any card manifest is created.
3. Fan out one independent Schema 1 child build per approved era. Each child is initialized as `--era-mode single`, locks one `selected_era_id`, and receives the approved parent era-plan hash.
4. Reuse source snapshots, but research, write, validate, audit, and seal each era card independently so one card cannot inherit another era's facts.
5. Deliver the cards with stable era-qualified filenames plus a human-readable set index. Do not merge them into one always-loaded card.

## Workflow

1. Complete the paged settings flow and lock source stance, timeframe, opening style, greeting policy, dialogue policy, and content boundaries.
2. For `single`, initialize one `card` build with schema 1 and `--era-mode single`.
3. For `set`, complete shared source synthesis and approve the parent era plan first, then initialize one independent single-era child build per era as described above.
4. Build and bind `artifacts/character-plan.json` from the approved research and era scope.
5. Research one character state, validate evidence, then write that state.
6. Use `character-template.md` and `character-identity-system.md` exactly.
7. Draft greetings and examples after the profile is stable.
8. Run architecture and schema validation, revise, and export every child separately.

For original characters, the user is normally the authority. For canonical characters, use the selected source stance.

## Canonical field routing

`personality`:

- contains only PERSONALITY & VOICE prose;
- no heading;
- no duplicated appearance, biography, or current-state block.

`description`:

```text
TIMELINE:
VITALS:
CONNECTIONS:
APPEARANCE:
BACKSTORY:
CURRENT:
EXTRA: (optional)
```

`scenario`:

- blank by default;
- populated only when the named `fixed` setup was selected and the exact approved text is stored in the card-shell plan;
- filled only after explicit user approval of a fixed premise;
- never decides `{{user}}`'s identity or actions without approval.

`first_mes` and `alternate_greetings` create playable scenes without turning those scenes into permanent profile facts. `single` permits an empty alternate list; `varied`, `custom`, `era-specific`, and `shared-style` require useful alternates.

`mes_example` uses `<START>` between examples and teaches voice/behavior rather than introducing unsupported facts.

## Identity, behavior, and relationships

The planner must separate stable identity from mutable state. Record canonical name, aliases, titles, species, pronouns, age state, occupations, rank, factions, location, life status, and physical form. Record behavior independently: speech, vocabulary, emotional regulation, drives, fears, values, habits, conflict behavior, relationship-specific behavior, capabilities, limitations, and knowledge boundaries.

For every state, freeze exact current role/location/goals, known and unknown secrets, required output terms, and forbidden later knowledge. Record relationships as directed era-specific links; one side's knowledge and behavior may differ from the other side's.

Simple Mode only asks for the timeframe choice and normal content conditions. Advanced Mode may ask whether identity/state and relationship plans should be automatic, reviewed, or custom. The user is never required to fill raw JSON fields.

## Supporting lore

If the user selects a compact supporting lorebook:

- route to Schema 2;
- keep the star's canonical card routing;
- use the full canonical character format for supporting NPC entries;
- apply `era-system.md` when more than one timeframe is selectable.

## Validation and delivery

```bash
python3 {baseDir}/scripts/architecture_gate.py --build-state /path/build-state.json --stage planning
python3 {baseDir}/scripts/validate_output.py /path/to/card.json --profile sillytavern
python3 {baseDir}/scripts/architecture_gate.py --build-state /path/build-state.json --stage output --artifact /path/to/card.json
python3 {baseDir}/scripts/delivery_gate.py /path/to/card.json --no-post-gen-audit
```

A Schema 1 direct-delivery path is allowed only after the artifact is inspected and the canonical character architecture passes.

Before release, read `full-integration-acceptance.md`; require the frozen route-specific integration plan and current receipts, skipping only systems marked not applicable.
