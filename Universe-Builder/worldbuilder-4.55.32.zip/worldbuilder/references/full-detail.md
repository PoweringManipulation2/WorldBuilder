# Full Detail Profile
## Navigation

- [Meaning](#meaning)
- [Selection test](#selection-test)
- [Depth without bloat](#depth-without-bloat)
- [Exit criteria](#exit-criteria)
## Meaning

Full Detail maps to the Maximum Detail context profile and asks for richer treatment of relevant material. It does not mean one entry per noun, exhaustive web scraping, or unlimited token use.
## Selection test

Create or expand an entry when at least one is true:

- It changes roleplay behavior.
- It recurs across scenes.
- It resolves a likely ambiguity.
- It is explicitly important to the user.
- It has clear retrieval value: it enables a useful retrieval path or prevents a likely failure.

Do not create an entry for every named entity. Record excluded named entities and the reason when bounded coverage matters.
## Depth without bloat

For important entities, cover:

- Function in the world/story.
- Observable traits.
- Relationships and tensions.
- Capabilities and constraints.
- Relevant history.
- Scene hooks.

Avoid repeating the same biography in anchors, detail entries, character description, and creator notes.

Full Detail does not change the architecture contract. Characters still use the canonical section order. Multi-era builds may create more state entries because source-backed differences in status, relationships, knowledge, allegiance, form, location, or goals deserve separate retrieval units; never replace those splits with one long blended biography.
## Exit criteria

Full Detail is complete when planned scenarios retrieve enough accurate information and the frozen hard budgets pass, not when a fixed entry quota is met. Use the manifest, dependency map, token estimate, and scenario tests to decide.

## Dynamic-state rule

Maximum detail increases supported coverage within hard budgets; it does not opt into randomization, timed effects, filters, automation, or outlets. Dynamic behavior remains a separate Advanced Mode decision with its own frozen plan and gates.

Before release, read `full-integration-acceptance.md`; require the frozen route-specific integration plan and current receipts, skipping only systems marked not applicable.
