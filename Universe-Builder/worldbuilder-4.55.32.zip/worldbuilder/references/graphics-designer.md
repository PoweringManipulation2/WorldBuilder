# Graphics Designer
## Navigation
- [Scope](#scope)
- [Regex](#regex)
- [Tracker state](#tracker-state)
- [Greeting HTML](#greeting-html)
- [Audit and delivery](#audit-and-delivery)
## Scope
Use Graphics Designer for character-scoped Regex, MVU-compatible tracker state, or HTML/CSS in `first_mes`. Reuse `extension_adapter.py` for serialization; do not invent global Regex or a second tracker renderer.
## Regex
1. Translate the requested transformation into a character-scoped Regex payload.
2. Build representative `matching` cases with exact expected output, `nonmatching` cases that must remain byte-for-byte unchanged, and at least one pathological/adversarial string.
3. Run `graphics_designer.py verify-regex`; it compiles and executes the real expression and bounds the adversarial run. Static diagnostics also flag greedy repeated-delimiter spans and nested/stacked quantifiers. A timeout or failed sample is not verified.
4. Show the person the transformation and verification result. Character-scoped Regex changes every message for the life of the chat, so explicit approval is mandatory before `bundle-regex`; never infer approval or silently retry with a broader pattern.
5. Bundle only through the existing Regex extension adapter. Scope remains character-local, never global.
## Tracker state
Describe the requested variables as structured initial state and run `graphics_designer.py author-tracker`. WorldBuilder emits the source-pinned MVU `[InitVar]` World Info state contract an existing compatible tracker can read. It does not author competing display HTML; recommend an existing tracker template, and treat custom display HTML as a separate manual task.
## Greeting HTML
Generate HTML/CSS only in the supported `first_mes` surface. Run `graphics_designer.py verify-html` before bundling: malformed nesting, unclosed tags, `<script>`, and inline event handlers block. Verified greeting markup may ship without a second Regex-style approval because it is reviewed as the greeting itself.
## Audit and delivery
Weaver must reproduce the deterministic Regex report and surface each `regex_greedy_quantifier_risk`, `regex_catastrophic_backtracking_risk`, or `regex_unverified_pattern` finding individually; findings recommend review and never auto-rewrite the pattern. `delivery_gate.py` enforces approval + verification only for Regex marked as WorldBuilder-authored, so imported third-party scripts are not retroactively blocked by this authoring contract. HTML metadata must still bind the exact current `first_mes` bytes.
