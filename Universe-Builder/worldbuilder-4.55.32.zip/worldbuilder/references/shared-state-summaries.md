# Phase-boundary shared-state summaries

Parallel workers remain isolated. Before dispatch, the parent may freeze one read-only summary generated only from already-completed phase outputs. The summary contains neutral named facts (UID, canonical name, layer, aliases), never sibling prose/reasoning or in-progress output.

`phase_gate.py --stage pre-dispatch` stamps `shared_state_summary` and its SHA-256 into generation assignments. Once an assignment has a summary, it is immutable: an early-finishing sibling cannot cause the summary to refresh mid-phase. New assignments at a later phase boundary may receive a new snapshot.
