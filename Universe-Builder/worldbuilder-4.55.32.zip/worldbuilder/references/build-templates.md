# Reusable Build Templates
Reusable build templates are guided-setup defaults, not build authority, and solve a different problem from `settings_preset.json`.

- Apply a template through `setup_state.py` before Page 1 is shown.
- It prefills the ordinary mode-filtered settings pages but never marks a page complete, removes a question, starts planning, initializes a build, or bypasses confirmation.
- Every prefilled answer remains individually overridable.
- `recommended` accepts displayed template defaults on that page; explicit answers in the same submission win.
- `recommended all` is still an explicit user action. It accepts remaining displayed defaults while preserving the full page/question structure in the draft.
## Contract
Template files use `worldbuilder-build-template-v1`:
```json
{
  "kind": "worldbuilder-build-template",
  "contract": "worldbuilder-build-template-v1",
  "template_version": 1,
  "name": "Wiki Deep Dive",
  "artifact_types": ["world", "lorebook"],
  "interface_modes": ["simple", "advanced"],
  "defaults": {
    "project_canon": {"selection": "existing"},
    "source_material": {"selection": "no"},
    "retrieval": {"selection": "hybrid"},
    "era_architecture": {"selection": "single"},
    "detail_level": {"selection": "full detail"}
  }
}
```
The schema can name only real `settings-menu.md` setting IDs, and each default can contain only a `selection` string. Host paths, models, audit switches, arbitrary `init_build.py` flags, and hidden execution controls have no representation.

A template may cover several artifact/interface combinations. Defaults valid for the template overall but not visible in the selected flow are not applied; the draft records them under `inapplicable_setting_ids` instead of silently pretending they applied.
## Apply and export
```bash
python scripts/setup_state.py init --workspace /path/to/workspace --name "My World" \
  --artifact-type world --interface-mode simple --template /path/to/world-template.json
```
The returned page includes `setting_ids` and `prefill`; the UI still renders every setting. Prefill is presentation state until that page is explicitly saved. Template lineage stores only the template name, hashes, and applied/inapplicable IDs, never the external template path.

After ordinary setup is finalized, export its answer selections:
```bash
python scripts/build_template.py export --settings /path/to/finalized-build-settings.json \
  --name "Wiki Deep Dive" --output /path/to/wiki-deep-dive.json
python scripts/build_template.py validate --template /path/to/wiki-deep-dive.json
```
Export stores selections only; it does not copy project name, workspace path, source files, models, or execution receipts.
## Relationship to `settings_preset.json`
`settings_preset.json` is Batch 23's shareable post-menu build-setting subset consumed by `init_build.py`. A build template is Batch 24's pre-menu UX default layer consumed by `setup_state.py`. Do not silently convert one into the other or apply both as competing authorities. Confirmed guided answers remain the source used to construct the eventual `init_build.py` invocation, and explicit current-build answers always win.
