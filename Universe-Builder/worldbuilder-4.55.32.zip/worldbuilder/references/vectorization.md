# Vector Storage and World Info
## Current behavior
SillyTavern Vector Storage provides an alternative way to satisfy keyword matching; probability/trigger%, character filters, groups, and other filters still apply after retrieval.

Vectorization does not disable ordinary keys. With keys present, keyword and vector retrieval are parallel activation paths; remove keys only for intentional vector-only behavior. Vector matching uses its own query-message configuration rather than World Info scan depth, and embedding retrieval is nondeterministic and inherently unpredictable.

Vector retrieval is a dynamic prompt source and can restructure the prompt prefix between calls, causing prompt caching misses. **Minimize the number of vectorized entries**: use the smallest set that genuinely benefits from semantic retrieval, then use trigger% as a final dampener rather than as a substitute for candidate selection.

## Activation patterns
Use one explicit pattern per entry and record it in the manifest: **Keyword-first** (deterministic keys, vector off), **Hybrid** (specific keys plus vector eligibility), or **Vector-only** (no ordinary keys, vector eligibility on). Keep safety rules, identity facts, and instructions that must always fire on deterministic paths.

## Candidate selection
The primary axis is **keyword-friendly versus keyword-hostile content**, not leaf versus hub. A named character, item, faction, location, or system with a clean trigger is keyword-friendly; diffuse, thematic, descriptive, or conceptual material that can be referenced many ways without one dependable term is keyword-hostile. Leaf/hub position is a separate blast-radius concern: a mis-fired hub can fan out farther, but graph position does not prove vectorization is useful.

For an existing book, use `scripts/ground_truth_graph.py` on generated content rather than trusting the declared graph. Narrow to content-derived orphans, judge which of those are genuinely keyword-hostile, and recommend vectorization only for **orphan AND keyword-hostile**. An orphan with a clean specific name can still activate when the player types that name and is not automatically a vector candidate.

`recommend_vectorization_candidates(entries, edges, keyword_hostile_uids)` composes that rule after the human/agent judgment supplies the keyword-hostile UID set. `find_circular_chains()` adds a secondary risk flag for a candidate inside a real strongly-connected component; cycle membership alone is never a reason to vectorize.

## Secondary-signal discipline
On the confirmed keyword path, use SillyTavern selective/secondary-key logic when a broad primary term needs contextual narrowing, e.g. `Rose` plus `guild` or `spymaster`. For hybrid entries this tightens the keyword path without proving the vector path is equally constrained.

Do **not** claim native selective/secondary-key logic constrains pure vector-triggered activation until tested on a live SillyTavern instance. **Current package status: unresolved** for that specific runtime interaction; do not make build logic assume either result. Record the observed behavior here only after a real deployment-level test.

## Runtime verification and future telemetry
A future `/wi-report`-style runtime log is intentionally **not implemented by this batch**. Its proposed purpose is to record real vector-triggered fires and confidence scores so over-firing can be reviewed from play data rather than guessed.

## Audit checklist
- Confirm the Vector Storage extension rather than assuming it.
- Prefer keyword-hostile content; do not select entries merely because they are leaves or orphans.
- Minimize the candidate set before trigger% tuning; for existing books use the content-derived graph and the orphan AND keyword-hostile rule.
- Ensure vector-only entries intentionally have no ordinary keys; keep hybrid keys specific and apply secondary signals where the keyword path needs them.
- Treat cycle membership as secondary blast-radius evidence, never a standalone vectorization reason.
- Keep deterministic critical information outside vector-only paths and document nondeterminism plus prompt caching cost.
- Mark selective behavior on vector-triggered activation unresolved unless a live SillyTavern test proves it.
