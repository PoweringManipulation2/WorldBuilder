# Soul Extraction
## Navigation

- [Purpose](#purpose)
- [Target routing](#target-routing)
- [Evidence categories](#evidence-categories)
- [Procedure](#procedure)
- [Mode integration](#mode-integration)
- [Output](#output)
## Purpose

Extract the smallest evidence-grounded set of patterns that makes a **world, character, authorial style, or supplied text** recognizable without copying large source passages. Soul Extractor is not character-only.
## Target routing

Classify the target before research or extraction. Do not silently use the character lens for every request.

| User names or supplies | Extraction lens | Primary result |
|---|---|---|
| A fictional world, franchise, setting, era, campaign, or location | World/setting soul | Tone, atmosphere, themes, narrative rules, social logic, institutions, aesthetic grammar, conflict patterns, and boundaries |
| A specific character or persona | Character soul | Drives, contradictions, voice, behavior under pressure, relationship modes, habits, limits, and decision patterns |
| An author, director, studio, game line, or body of work | Authorial/style soul | Prose or presentation patterns, pacing, imagery, thematic habits, scene construction, dialogue tendencies, and structural preferences |
| Pasted text or uploaded material | Infer from content and user intent | A world, character, or authorial profile; ask one concise question only when the intended target is materially ambiguous |
| A world plus named characters | Split extraction | One world-soul profile plus separate character-soul profiles; never blend character quirks into global setting rules |

When the user invokes Soul Extractor from **World Mode**, default to the world/setting lens unless they explicitly name a character as the extraction target. When they name a specific character, use the character lens even if the character belongs to a larger world.
## Evidence categories
### World/setting soul

- Emotional tone and atmosphere.
- Recurring themes, moral tensions, and taboos.
- Narrative promises: what kinds of stories naturally happen here.
- Reality rules, metaphysics, technology, magic, or institutional constraints.
- Social logic: status, power, law, customs, economics, and everyday life.
- Conflict grammar: common pressures, escalation patterns, and costs.
- Aesthetic grammar: imagery, sensory palette, architecture, fashion, and environmental motifs.
- Humor, horror, romance, violence, and hope boundaries.
- Canon contradictions, era differences, and confidence notes.
- Anti-patterns: elements that would make the setting feel generically adjacent but wrong.
### Character soul

- Goals and fears.
- Repeated choices under pressure.
- Social masks versus private behavior.
- Speech rhythm and recurring rhetorical habits.
- Boundaries, blind spots, and contradictions.
- Relationship-specific behavior.
- Physical/action habits that affect narration.
### Authorial/style soul

- Sentence and paragraph rhythm.
- Point of view, narrative distance, and information withholding.
- Dialogue density and subtext habits.
- Scene openings, transitions, escalation, and endings.
- Recurrent imagery, motifs, and sensory emphasis.
- Humor, sentiment, violence, and exposition patterns.
- Structural habits across representative samples.
- Traits that are distinctive versus generic to the genre.
## Procedure

1. Classify the target and record `target_type` as `world`, `character`, `authorial`, or `mixed`.
2. Set source stance and allowed sources.
3. Gather representative evidence across multiple moments, locations, episodes, chapters, or entries, not one convenient example.
4. Separate direct evidence, repeated pattern, inference, and uncertainty.
5. Cluster only patterns supported by more than one representative example, unless a single example is explicitly foundational.
6. Convert clusters into concise, operational instructions.
7. Test the profile against situations or samples not used during extraction.
8. Remove generic genre traits that do not distinguish the target.
9. Record anti-patterns and known exceptions so downstream generation does not overgeneralize.
10. Bind the finished profile to its source ledger and pass it into the selected build mode as a creator-facing planning artifact.

Do not reproduce extensive copyrighted dialogue or prose. Paraphrase patterns and use only short examples where necessary.
## Mode integration

- **World Mode:** use the world soul to guide the brief card description, greeting atmosphere, metadata guide, lorebook selection, entry voice, setting logic, and recursion architecture. Do not use it to prefill World Mode Scenario; Scenario remains a user-controlled settings field by default. It supplements factual research; it never substitutes for per-UID evidence.
- **Lorebook Mode:** use the world soul as a global editorial and architectural constraint across entries, while keeping each UID fact-bound to its own research ledger.
- **Character Mode:** use the character soul to guide description, personality, scenario, first message, alternate greetings, example dialogue, and relationship behavior.
- **Group Chat:** keep one shared world soul plus separate character souls for each participant. Shared tone does not erase individual voices.
- **Persona:** use the character/persona lens unless the user specifically requests an authorial presentation style.

Store the profile under the build workspace as `artifacts/soul-profile.json`, hash it into build lineage, and reference it from assignments. `scripts/soul_contract.py` enforces this: a profile that is not hash-bound, or a prose-bearing entry whose assignment lacks `generation.soul_voice_bound`, fails the planning gate.

The profile carries two things with different jobs:

- `runtime_guide` ships with the artifact and keeps creator voice when the model reaches a scene the lorebook never defined. Declare its `placement` (`post_history_instructions`, `depth_entry`, `description`, `system_prompt`, or `world_core_entry`) and a `placement_rationale`. Placement is not cosmetic: a prose guide steers generation, and the fields differ in distance from the generation point, so `worldbuilder-placement-influence-v1` owns the decision rather than a fixed default.
- `voice_rules`, `anti_patterns`, and `required_markers` constrain WorldBuilder's own generation and are checked at output by `soul_contract.py output`.

Output checks are corpus-wide by design: cross-entry n-gram repetition, opener diversity, and sentence-rhythm collapse. These are the failures a model-driven editor cannot catch, because it never holds every entry at once. Declared anti-patterns and missing required markers are errors; the corpus metrics are warnings, because editorial preference must not become a schema error. Do not place citations or research notes inside user-facing character prose unless requested.
## Output

Every Soul Extractor result must identify the target and extraction lens.
### World/setting profile

- Core tone and emotional range.
- Themes and moral tensions.
- Narrative promises.
- Setting and social rules.
- Conflict and consequence patterns.
- Aesthetic/sensory grammar.
- Dialogue and narration expectations, where applicable.
- Anti-patterns and exceptions.
- Confidence/source notes.
### Character profile

- Core drives.
- Contradictions.
- Stress behavior.
- Voice rules.
- Relationship modes.
- Non-negotiable limits.
- Confidence/source notes.
### Authorial/style profile

- Voice and rhythm.
- Point of view and narrative distance.
- Dialogue and exposition patterns.
- Scene architecture and pacing.
- Imagery and thematic habits.
- Anti-patterns and exceptions.
- Confidence/source notes.

Place model-facing instructions in the relevant character, world, lorebook, group, or persona planning artifacts; keep evidence citations in research/creator-facing artifacts.

### Permanent world-core runtime guide
A world/setting soul may choose `runtime_guide.placement: world_core_entry`. When chosen, generation must materialize the guide as a real lorebook entry with `architecture.layer: world_core` and `activation.strategy: constant`; it is not shorthand for a card-shell field. This placement uses the same declared-rationale trust model as the other runtime-guide placements.
