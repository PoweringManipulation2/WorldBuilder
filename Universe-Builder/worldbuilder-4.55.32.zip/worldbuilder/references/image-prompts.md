# Image Prompt Guide
## Navigation

- [Purpose](#purpose)
- [Prompt structure](#prompt-structure)
- [Consistency](#consistency)
- [Safety and rights](#safety-and-rights)
- [Generation](#generation)
## Purpose

Create optional portrait, background, expression, or scene prompts. Image generation is separate from card validity.
## Prompt structure

Describe:

- Subject and age category.
- Stable physical features.
- Clothing/props.
- Pose and expression.
- Environment.
- Camera/framing.
- Lighting and medium.
- Exclusions needed for consistency.

Avoid stuffing lore prose into visual prompts.
## Consistency

Keep a reusable visual anchor for recurring features. Change only the intended expression, outfit, or scene. Record aspect ratio and crop needs for the target UI.
## Safety and rights

Follow the active image tool's safety rules. Do not claim ownership or licensing that has not been established. When using user assets, preserve originals and document transformations.
## Generation

`--generate` renders a prompt through `image_generate` (DR-075 supersedes the prior never-images position). This tool is host-provided. WorldBuilder never manages providers, keys, or model registries; it only constructs the prompt and reports the result. The tool appears only when at least one provider is configured; `capability_probe.py` already gates this. Call `action: "list"` and populate model choice from that response, never a hardcoded provider name.

Before the first call: project the number of images and their estimated cost, and get explicit confirmation; `scripts/image_generation_gate.py`'s `cost_confirmation_gate` requires this explicitly and never fabricates a price it wasn't given. Never default to generating more than one image per request without asking; cost is user-owned (`global-rules.md` philosophy point 9), and a silent `n: 4` spends someone else's money on an assumption.

Optimize phrasing against `references/image-model-profiles.json`, keyed by the model `action: "list"` actually reports. An unrecognized model uses the file's own `unknown` entry (a neutral, natural-language prompt) and says so plainly rather than guessing at a convention. This lookup is version-pinned, never a live research call; refreshing the profiles file is a separate, explicit maintenance action.

Content rules apply to the prompt before it reaches the provider, not after: no real-person likenesses, nothing sexualizing minors, and `global-rules.md` safety generally. Run `image_generation_gate.py`'s `prompt_safety_signals` against the constructed prompt text before calling `image_generate`; it flags a structural signal (a full name pattern) for review, never an automatic block, so a flagged prompt still needs a human decision, not silent passage or silent rejection. Do not rely on the provider's own safety filter as the only check, since a rejected call after the fact is a worse experience than catching it here, and some providers may not reject at all.

The call is asynchronous: it records a background task, returns a task id, and wakes the agent on completion; yield, do not poll, the same pattern as subagent dispatch. Reference-image edit mode accepts up to 14 references (the expression-set base portrait plus any prior expressions currently in progress). Mirror `details.normalization`'s requested-versus-applied translation into whatever loss/compatibility reporting the current mode already produces; an ignored hint is real information, not silently dropped.

