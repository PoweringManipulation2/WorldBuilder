# Iteration Mode
## Navigation

- [Intake](#intake)
- [Tier reported up front](#tier-reported-up-front)
- [Change contract](#change-contract)
- [Targeted-change checkpoint](#targeted-change-checkpoint)
- [Procedure](#procedure)
- [Release](#release)
## Intake

Resolve the uploaded/tool-visible file, copy it into the build workspace, hash it, and detect its actual format. Never ask for a Downloads/Desktop path before checking inbound media. A `.png` upload is a card container, not an image to generate: `png_card.py` reads its `chara`/`ccv3` tEXt chunk (`ccv3` preferred). Pass the copied path to `init_build.py --source-file`, which stamps `lineage.input` and fails immediately if the PNG has no readable chunk, rather than letting a broken upload reach planning.
## Tier reported up front

Call `capability_tiers.detect_tier` before anything else, not discovered three steps into the procedure as a gate error. Unbound (no WorldBuilder lineage, or its workspace is gone) is not a degraded starting point: structural edit, derived activation graph, diff proof, format validation, and import probe all work on a hand-made or third-party artifact with no WorldBuilder history at all. State the detected tier and its capabilities before asking about scope; a Legacy-bound or Bound artifact additionally supports lineage reading, entry-naming normalization, and migration, but none of that is required to start (DR-072).
## Change contract

Clarify only material scope:

- Content edits.
- Settings edits.
- Format conversion.
- Legacy compatibility target.
- Whether identifiers must remain externally stable.

Default to preserving format, unknown fields, asset references, and stable IDs.
## Targeted-change checkpoint

For a request limited to specific existing UIDs/fields, with no new source pass or structural re-plan, start with `selective_regeneration.py plan`; see `references/iterating-existing-lorebook.md`. Then follow `pipeline_stage_gate.py --next` for the remaining scoped steps instead of memorizing internal script names. Requested locked entries are excluded and reported by name/reason before work proceeds; never silently skip or override them.
## Procedure

1. Validate the input without repairing it silently.
2. Record baseline issues.
3. Apply requested changes to a working copy, exclusively through `artifact_edit.py` (`set-field`, `add-entry`, `remove-entry`, `move-depth`, `retag-keys`); never a bare rewrite of the file (DR-071). `add-entry` allocates its own UID from the same authority `merge_phases.py` uses; never hand-pick one. `remove-entry` requires an identity check (`expected_name`) matching what the caller believes it is deleting, not a bare UID. `move-depth` requires a non-empty `receipt_bound_reason`; it loosens an invariant every other caller in the codebase is held to, and never does so silently. For legacy lorebooks, run `entry_naming.py` when labels contain source boilerplate or lack semantic prefixes; record every renamed label.
4. Prove what actually changed with `artifact_diff.py` against the pre-edit snapshot: added/removed/changed UIDs, unknown-field loss, extension-namespace loss, key-order changes, moved entries. This is the baseline every modifying mode proves its change against (DR-071); do not skip it because the edit felt small.
5. Use exact JSON Pointer paths in patch/change logs.
6. Revalidate and compare semantic fields, including the entry-naming receipt for lorebook-bearing artifacts and the `artifact_diff.py` proof from step 4.
7. Package CHARX only after JSON passes.

Do not add optional extension defaults merely because they are absent.

**Rollback lock conflicts:** `revision_history.py --approve-lock-conflicts` is never an agent convenience flag. Stop, identify the exact user-locked fields that would be overwritten, explain the rollback consequence, and ask the person. Only after explicit approval may the agent pass both `--approve-lock-conflicts` and `--lock-conflict-user-confirmation "<their answer>"`; the script rejects the approval flag without that confirmation.
## Release

Return the complete updated artifact plus a change report, including the tier the artifact was worked at and the `artifact_diff.py` proof of what changed. For lorebook-bearing output, run full audit/seal/delivery. For Schema 1/persona, use the appropriate direct gate.

**Source-provenance boundary:** URLs, source-site/wiki labels, article wrappers, and retrieval notes belong in evidence or structured source metadata, not visible `name`/`comment` labels or model-facing entry `content`. Existing content matches are warnings for review; never silently rewrite substantive prose with the label normalizer.
