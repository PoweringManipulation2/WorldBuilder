# SillyTavern 1.18 JSON Import Contract

<!-- phase-contract --> Exit contract: run `python3 {baseDir}/scripts/phase_contract.py --build-state <build-state> --stage <runtime_adapter>` before this stage's gate; rendered copies ship in the build's worker kit under `exit-contracts/`.
## Quick navigation

- [Scope and encoding](#scope-and-encoding)
- [Direct-import routes](#direct-import-routes)
- [Embedded field mapping](#embedded-field-mapping)
- [Inactive or global-only fields](#inactive-or-global-only-fields)
- [Regex and activation](#regex-and-activation)
- [Filters, labels, and checks](#filters-labels-and-checks)

## Scope and encoding

Use this reference when WorldBuilder emits, repairs, or audits an embedded lorebook or native World Info file for `sillytavern-1.18.0`. It is an application-compatibility contract, not a universal Character Card V3 rule.

SillyTavern parses uploaded character JSON as UTF-8 JSON. Deliver strict UTF-8 without a BOM or leading U+FEFF, exactly one JSON value, and reopen it through `sillytavern_import_probe.py`. Repair may read legacy BOM input, but must rewrite clean output.

## Direct-import routes

SillyTavern 1.18.0 has two relevant JSON routes:

1. Character Card V3 with `data.character_book`, handled by character import and `convertCharacterBook`.
2. Native World Info with top-level `entries`, handled by World Info import.

A standalone `{ "spec": "lorebook_v3", "data": { ... } }` wrapper is portable/spec-valid interchange, not a direct World Info import shape. Convert it to native World Info first. Emit generated native entries as a UID-keyed object for runtime/editor-safe addressing.

## Embedded field mapping

`convertCharacterBook` reads the core fields `keys`, `secondary_keys`, `comment`, `content`, `constant`, `selective`, `insertion_order`, `enabled`, and `position`.

For the tested profile it also reads these exact entry `extensions` keys:

`position`, `exclude_recursion`, `prevent_recursion`, `delay_until_recursion`, `display_index`, `probability`, `useProbability`, `depth`, `selectiveLogic`, `outlet_name`, `group`, `group_override`, `group_weight`, `scan_depth`, `case_sensitive`, `match_whole_words`, `use_group_scoring`, `automation_id`, `role`, `vectorized`, `sticky`, `cooldown`, `delay`, `match_persona_description`, `match_character_description`, `match_character_personality`, `match_character_depth_prompt`, `match_scenario`, `match_creator_notes`, `triggers`, and `ignore_budget`.

Do not substitute near-miss spellings: `use_probability` is not `useProbability`; top-level `selectiveLogic` does not replace `extensions.selectiveLogic`; `preventRecursion` does not replace embedded `extensions.prevent_recursion`.

## Inactive or global-only fields

- `use_regex` is not read by the embedded converter. Raw patterns become ordinary keywords unless translated to SillyTavern slash-delimited regex keys.
- Embedded `extensions.character_filter` is preserved but not promoted to active native `characterFilter`; use native World Info for an active character/tag filter.
- CCv3 entry `priority` is preserved metadata with no active importer mapping.
- Book-level `scan_depth`, `token_budget`, and `recursive_scanning` remain portable metadata; the tested runtime uses global World Info controls.

The probe reports these as inactive or lossy instead of equating syntactic JSON acceptance with runtime compatibility.

## Regex and activation

SillyTavern recognizes slash-delimited JavaScript-regex strings in keyword arrays, such as `/foo\\s+bar/i`. For the named profile, translate CCv3 `use_regex: true` primary patterns to that syntax and retain the original `keys`, `secondary_keys`, `constant`, `selective`, and `use_regex` values in `extensions.worldbuilder_sillytavern_regex` for reversal. CCv3 regex mode activates from primary regex patterns and ignores `secondary_keys` and `constant`, so clear those runtime paths while retaining their source values only in the recovery envelope.

Constant entries activate unconditionally. `vectorized: true` is an entry state consumed by the Vector Storage extension, not a gate in the 1.18.0 keyword scan loop: keyword scanning still applies to any entry with primary keys, including vectorized ones, so a vectorized entry that retains primary keys is intentionally hybrid and may activate through either retrieval path. (The constant/vectorized/normal tri-state in the World Info editor is a UI state selector, not the runtime activation order.) Secondary keys apply only when `selective: true`. Native `selectiveLogic` is `0` AND ANY, `1` NOT ALL, `2` NOT ANY, or `3` AND ALL. Per-entry `scan_depth` affects keyword scanning; vector retrieval uses Vector Storage query settings. Do not put critical era, identity, status, knowledge, or world invariants behind vector-only retrieval.

## Filters, labels, and checks

Native World Info uses active `characterFilter`. Resolve semantic character names to filename stems and tags to tag IDs through approved maps. Embedded output must fail closed or preserve the filter as explicitly approved neutral-only metadata.

SillyTavern displays `comment` as the World Info editor label. Write the same concise semantic label to `name` and `comment`, such as `RULE: No future knowledge` or `LOCATION: Amberfield`. Keep citations and synthesis notes in provenance extensions, evidence ledgers, and source metadata.

```bash
python3 {baseDir}/scripts/validate_output.py card.json --profile spec
python3 {baseDir}/scripts/sillytavern_import_probe.py card.json
python3 {baseDir}/scripts/sillytavern_import_probe.py native-world-info.json
python3 {baseDir}/scripts/sillytavern_import_probe.py portable-lorebook-v3.json
```

The probe distinguishes direct-import compatibility, field preservation, and active-setting compatibility. Passing it demonstrates strict encoding and a source-mirrored import-facing shape; it does not replace a live GUI import acceptance test.
