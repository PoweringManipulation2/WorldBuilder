# Placement and Influence Architecture
## Navigation
- [Purpose](#purpose)
- [Frozen placement plan](#frozen-placement-plan)
- [Semantic positions](#semantic-positions)
- [Purpose-based defaults](#purpose-based-defaults)
- [Influence model](#influence-model)
- [Sparse manifest behavior](#sparse-manifest-behavior)
- [Overrides](#overrides)
- [Target compatibility](#target-compatibility)
- [Generation and audit](#generation-and-audit)
## Purpose
Placement determines where an activated lorebook entry enters the prompt. Influence is the combined effect of placement, insertion order, priority, constant status, direct versus recursive activation, and depth/role. Do not treat `position` or `order` as isolated decoration.

WorldBuilder freezes this behavior before generation under:

```text
artifacts/placement-plan.json
contract: worldbuilder-placement-influence-v1
```

The manifest remains authoritative for emitted entry settings. The placement plan defines the purpose of each layer, allowed positions, approved overrides, and target-compatibility expectations.
## Frozen placement plan
The plan records:

- Selected policy: `automatic`, `review`, or `custom`.
- Bound default-profile hash.
- Supported semantic positions.
- Purpose and influence class for each layer.
- Allowed and recommended positions.
- Optional custom layer or UID overrides.
- Approved named outlet consumers.
- Validation rules.

The manifest must bind the exact plan SHA-256 at both:

```text
placement_plan_sha256
architecture.placement.plan_sha256
```

Changing the placement plan invalidates the manifest, map, assignments, evidence, phases, audits, and delivery lineage.
## Semantic positions
WorldBuilder uses one internal vocabulary:

```text
before_char
    Before Character Definitions

after_char
    After Character Definitions

before_examples
    Before Example Messages

after_examples
    After Example Messages

authors_note_top
    Top of Author's Note

authors_note_bottom
    Bottom of Author's Note

depth
    At chat depth; requires depth and role

outlet
    Named outlet; requires an approved consumer
```

`before_char` and `after_char` are portable CCv3 core positions. The other positions require a tested SillyTavern-native or extension mapping. Record this as `extension_mapped`; do not pretend it is portable core behavior.
## Purpose-based defaults
Use the frozen profile rather than inventing per-entry values.

| Layer | Purpose | Default position | Typical order |
|---|---|---|---:|
| `world_index` | Names what the book can answer for | `before_char` | 115 |
| `world_core` | Stable world foundation | `before_char` | 100 |
| `world_invariants` | Cross-era immutable foundation | `before_char` | 100 |
| `era_context` | Authoritative temporal context | `before_char` | 120 |
| `anchor` | Retrieval and recursion routing | `after_char` | 90 |
| `character` | Identity, behavior, and current state | `after_char` | 110 |
| `relationship` | Relationship state and behavior | `after_char` | 115 |
| `location` / `faction` / `organization` | Contextual world state | `after_char` | 100 |
| `event` | Chronology and event context | `after_char` | 105 |
| `scene_reminder` | Immediate scene state | `depth`, role `system`, depth 2 | 130 |
| `correction` | High-priority runtime correction | `depth`, role `system`, depth 1 | 140 |
| `dialogue_example` | Dialogue demonstration | `after_examples` | 100 |
| `outlet_module` | Prompt-manager module | `outlet` | 100 |

These are architecture defaults, not universal SillyTavern requirements. Custom placement is allowed only when approved and documented.

World Invariants and World Core must remain before character definitions. Era Context also remains before character definitions and uses a later order than World Invariants so the selected era state has stronger local influence without overwriting immutable laws.

Character and relationship state normally follow character definitions. Do not place them before character definitions merely because they are important.
## Influence model
For each entry, the placement gate records:

```text
purpose
influence class
semantic position
insertion order
priority
constant status
incoming recursion count
activation path
chat depth and role
outlet
estimated influence score
runtime target mapping
```

The score is an audit aid, not a claim about exact model attention. It helps compare entries consistently and identify obviously weak or overly strong placement.

Interpret the factors together:

- **Position:** later prompt locations usually have more immediate influence.
- **Order:** within the same position, higher order is inserted later.
- **Priority:** controls retention when the lorebook budget is exceeded where the target supports it.
- **Constant:** creates permanent prompt pressure and should be rare.
- **Activation path:** direct activation is generally more reliable than a deep recursive chain.
- **Depth/role:** at-depth system text is strong and must be reserved for deliberate immediate state or corrections.

Do not move a weak entry to Author's Note or depth as a substitute for fixing its activation path.
## Sparse manifest behavior
The map and manifest should not print unnecessary defaults.

```text
blank          = inherit frozen default-profile value
None           = explicitly disabled
unsupported    = selected target cannot represent the setting
explicit value = intentional override
```

The placement assignment slice resolves inherited values for the worker, so the worker never guesses whether blank means forgotten.
## Overrides
Automatic and review policies use frozen profile values. Custom policy may define layer or UID overrides.

Every UID-level deviation requires:

```json
{
  "architecture": {
    "placement_override": {
      "reason": "Why this entry must depart from its layer profile."
    }
  }
}
```

The value must also exactly match the approved `placement-plan.json` override. A prose reason alone does not authorize arbitrary settings.

Reject:

- A World Core, World Invariants, or world index entry outside `before_char`.
- An Era Context outside `before_char`.
- A character or relationship entry before character definitions without an approved custom rule.
- Depth placement without both `depth` and `role`.
- Depth or outlet placement on a constant entry.
- Outlet placement without a named approved consumer.
- Extended placement represented as CCv3 core without a tested mapping.
- Output settings that differ from the frozen manifest/profile resolution.
## Target compatibility
The placement plan classifies each entry as:

```text
core
    Portable before/after-character placement.

extension_mapped
    Requires a tested SillyTavern-native or application extension field.

unsupported
    Cannot be represented by the selected target and must block planning.

not_applicable
    Card-field or persona content rather than a lorebook entry.
```

Batch 6 validates semantic intent and target warnings. `runtime_target_adapter.py` owns exact version-specific field emission and round-trip compatibility.
## Generation and audit
Generation assignments include:

```text
placement_plan_sha256
map_slice.placement_context
```

For every assigned UID, the worker receives the exact resolved position, order, priority, depth, role, outlet, purpose, influence class, activation path, and target mapping.

Workers must copy those settings exactly. They may not strengthen an entry by moving it later, raising its order, adding an Author's Note position, or creating an outlet.

The planning gate runs the placement contract before assignments exist. The delivery gate compares emitted output against the same plan. Weaver audits entry order, placement, influence, constant pressure, and target compatibility. Compass verifies plan lineage and selected policy.
