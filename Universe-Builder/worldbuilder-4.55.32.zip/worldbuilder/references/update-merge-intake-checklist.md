# Update/Merge Intake Checklist
## Navigation
- [Why this exists](#why-this-exists)
- [A. Provenance](#a-provenance)
- [B. Schema and structural fit](#b-schema-and-structural-fit)
- [C. Keywording quality](#c-keywording-quality)
- [D. Activation and recursion safety](#d-activation-and-recursion-safety)
- [E. Writing quality](#e-writing-quality)
- [F. Optimization and architecture parity](#f-optimization-and-architecture-parity)
- [G. Budget and context sizing](#g-budget-and-context-sizing)
- [How this feeds the merge](#how-this-feeds-the-merge)

Run this once, upfront: after `update-merge.md`'s Procedure step 2, before step 3. `scripts/update_merge_intake.py` takes `--input <artifact>` and computes every item that names a tool, returning them as a report; the remaining items are named checks you perform by reading the file. It is a diagnostic, never a gate.
## Why this exists
Update/Merge historically assumed the incoming book was a known quantity. It may instead be a WorldBuilder book from any point in this skill's history, a book from another tool, or hand-authored content. Without this pass the model cannot tell "bring this up to date with a few additions" from "this predates work already done and needs far more". Scope stays a judgment call; this makes it visible.
## A. Provenance
1. Does the book carry WorldBuilder's own markers (the `worldbuilder_entry_naming` extension, `era_branch_of` fields, the "-- Core" convention, semantic `PREFIX: Subject` labels)? Yes: WorldBuilder-authored. No: treat it as external and go straight to a fuller structural assessment rather than assuming partial conventions apply.
2. If WorldBuilder-authored, does it show connectivity-tiered order/weight (Batch 49/53), or scattered per-cluster defaults from before that fix? This places the book in time against this skill's own history.
3. If external, which convention does it resemble: a bare SillyTavern export with no semantic prefixes, another generator's scheme, or hand-authored content with no consistent structure? That decides translation versus reconstruction.
## B. Schema and structural fit
4. CCv3 (`chara_card_v3`), CCv2, or a standalone World Info JSON with no card wrapper? The report's `schema.shape` names it.
5. What are the real field names in use: `uid` or `id`, `keys` or `key`, `secondary_keys` or `keysecondary`? These genuinely vary between valid exports; never assume one without checking.
6. Where does `selectiveLogic` live: emit level (the canonical path) or nested under `extensions`? Both are tolerated by the resolver, but new entries must match what the book already uses.
## C. Keywording quality
7. Do major or highly-referenced entries carry only a bare single-word name, or also a distinctive multi-word key (a title, epithet, or fuller name)? Reuses the character-cascade finding: bare-name-only keying on a high in-degree entry is a measured cascade risk, not a style preference.
8. Where secondary keys and AND_ALL gate era or state, are they genuinely present and correctly configured, or does the book rely on primary keys alone for content that should be state-gated?
## D. Activation and recursion safety
9. Run `ground_truth_graph.py`'s orphan and cycle detection against the real file. Are there genuine orphans? Cycles that are legitimate (`era_branch_of`-marked, intentional mutual pairing) or unplanned tangles?
10. Do foundational, widely-referenced entries carry `prevent_recursion` per Batch 55, or is that safeguard missing entirely?
11. Run `st_activation_scanner.py` against representative, ordinary messages. Does a single message activate a disproportionate fraction of the book? That is the empirical form of "is this book actually safe to use", not a proxy for it.
## E. Writing quality
12. Run `find_cliches()` and the trait-adjective detector against a sample of the book's entries. A bare adjective list with no concrete behavior is a real generation-quality signal, regardless of origin.
13. Does the `description` field use third-person in-world framing, or human-facing marketing copy (the pattern Batch 45 fixed)?
## F. Optimization and architecture parity
14. If this is a multi-era book, does it use the confirmed era-tree pattern (shared primary key between character and era-branch, AND_ALL-gated, order set to `character_order - 1`), or an older, different, or absent mechanism?
15. Are root and branch entries distinguishable by name (the `(Root)`/`(Branch)` convention from Batch 49), or does the book carry the undifferentiated-naming gap that batch fixed?
## G. Budget and context sizing
16. Run `budget_contract.py`'s worst-case estimate against the book's real size and a stated target window. Is the worst case within a reasonable ceiling, or does it carry the unmeasured risk Batch 55's investigation found on the real card?
## How this feeds the merge
The output is an itemized list of what genuinely needs doing: not a pass/fail gate, and not a mandate to fix everything found. Some incoming books need one or two items addressed; older or externally-authored ones may need substantially more. The checklist makes that scope visible and explicit before work starts; deciding the scope stays a judgment call informed by what it surfaces.
