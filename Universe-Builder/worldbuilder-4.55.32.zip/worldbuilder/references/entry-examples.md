# Architecture Entry Examples
## Navigation
- [World Invariants](#world-invariants)
- [Era Context](#era-context)
- [Era-state character](#era-state-character)
- [Schema 1 star](#schema-1-star)
- [Decorators on the portable path](#decorators-on-the-portable-path)
## World Invariants
```text
RULE: Souls retain their essential identity after death.
RULE: Passage between realms requires a portal, summoning, or authorized gate.
```

Keep only truths valid in every selected era. Do not mention current rulers, living characters, faction membership, or later destruction.

State a behavioral rule positively where the meaning allows: `Passage between realms requires a portal` rather than `Nothing crosses between realms without a portal`. A prohibition is the fallback form, paired with or replaced by the positive rule it implies, because a rule the model can follow is stronger than one it must remember not to break.
## Era Context
```text
CURRENT ERA: Season 1

WORLD STATE THIS ERA:
The hotel is still struggling to prove redemption is possible...

ACTIVE FACTIONS THIS ERA:
• Wayfarer Hotel: ...

ACTIVE CHARACTERS THIS ERA:
• Mira (alive, hotel founder, Meridian)

ACTIVE LOCATIONS THIS ERA:
• Wayfarer Hotel (operational)

WHAT IS ALREADY PAST:
• <earlier event>: characters may know it as history.

KNOWLEDGE LIMITS THIS ERA:
• Nothing after the Season 1 finale has occurred.
• Name no later event, here or anywhere: the boundary is the whole statement (DR-038).
```
## Era-state character
```text
TIMELINE: Season 1 only. Alive and operating the Wayfarer Hotel in Meridian.

VITALS: ...

PERSONALITY & VOICE: ...

CONNECTIONS:
- Halcyon: ...

APPEARANCE: ...

BACKSTORY: Only events already past by Season 1.

CURRENT: Current role, knowledge, goals, location, and stakes.
```

Do not add “she will later...” or name future revelations.
## Schema 1 star
`personality`:

```text
Direct personality and voice prose only; no heading.
```

`description`:

```text
TIMELINE: ...
VITALS: ...
CONNECTIONS: ...
APPEARANCE: ...
BACKSTORY: ...
CURRENT: ...
```

`scenario` is blank unless the user explicitly selected a fixed premise.
## Decorators on the portable path
```text
@@depth 5
@@role assistant

Marisol only speaks once the party has been traveling together for at least five exchanges; she is guarded around strangers.
```

The decorator block is a contiguous run of `@@name value` lines at the very start of `content`, blank-line separated from the actual prose that follows. Content never repeats the decorator's meaning in prose form ("this activates at depth 5"); the decorator is the single, authoritative statement of that fact.

A bare, valueless decorator:

```text
@@dont_activate

An entry force-disabled for this build without deleting it; content stays intact for a future re-enable.
```

Never hand-author `extensions.depth` alongside a `@@depth` line on the same entry for a portable target; that is the double-emission Batch 9 exists to prevent. Pick one form per target, never both.

