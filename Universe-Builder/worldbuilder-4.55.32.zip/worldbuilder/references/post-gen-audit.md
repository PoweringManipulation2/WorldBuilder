# Post-Generation Audit
<!-- phase-contract --> Exit contract: run `python3 {baseDir}/scripts/phase_contract.py --build-state <build-state> --stage <post_generation_audit>` before this stage's gate; rendered copies ship in the build's worker kit under `exit-contracts/`.
## Navigation
- [Applicability](#applicability)
- [Prepare the target](#prepare-the-target)
- [Deterministic validation](#deterministic-validation)
- [Four-lens review](#four-lens-review)
- [Finding reconciliation](#finding-reconciliation)
- [Patch verification](#patch-verification)
- [Re-audit and seal](#re-audit-and-seal)
## Applicability
Require the content-bound post-generation audit for Schema 2 cards, standalone lorebooks, native World Info, World builds, and Group builds with shared lore. A Schema 1 card or plain persona may skip it only after target inspection proves no lorebook-bearing structure exists.
## Prepare the target
Finish deterministic merge into `paths.merge_input`, validate it, and produce the final artifact at `paths.final_output` (copy the validated merge, or render the target format). Do not audit a moving file. Record its SHA-256 and manifest hash in build state.
Make the card final in this exact order, because the audit, the adapter receipt, and delivery all bind these bytes:
1. Render or copy the final artifact to `paths.final_output`.
2. Refresh the Creator Notes stats block on that artifact: `creator_notes_stats.py --input <final> --budget-receipt <paths.budget_output_receipt> --placement-receipt <paths.placement_output_receipt> --write`. This is the last write to the card; a later write invalidates [4/11] and [6/11] at delivery.
3. Run `runtime_target_adapter.py export` and `validate` when adaptation is required.
4. Plan the post-generation audit against `paths.final_output` (the default once the adapter has rendered it), run the four lenses, pass `audit_gate.py`, then seal and deliver.
Planning the audit re-normalizes the target once if it was not already normalized; if that changes bytes after an adapter receipt exists, the planner refuses and names the re-export command rather than stranding [4/11].
## Deterministic validation
Run the appropriate structural and compatibility validators before model review:
```bash
python3 {baseDir}/scripts/validate_output.py /path/to/creations/final.json --profile spec
python3 {baseDir}/scripts/validate_output.py /path/to/creations/final.json --profile sillytavern
```
Treat specification errors, SillyTavern compatibility warnings, and WorldBuilder editorial advice as separate classes.
## Four-lens review
Create a post-generation audit plan:
```bash
python3 {baseDir}/scripts/audit_plan.py \
  --build-state /absolute/path/to/build-state.json \
  --stage post-generation
```
Spawn Compass, Weaver, Scout, and Warden from their exact assignments. After each OpenClaw completion, record the parent-observed runtime receipt with `record_audit_runtime.py`. Then run:
```bash
python3 {baseDir}/scripts/audit_gate.py \
  --build-state /absolute/path/to/build-state.json \
  --stage post-generation
```
The gate requires exact target bytes, exact UID and artifact coverage, all expected checks, structured findings, exact delimiters, and four completed lens proofs under the plan-declared execution topology.
For architecture-contract builds, Compass, Warden, and Weaver additionally prove: every character UID is owned by exactly one planned identity/state; every character uses the canonical field/section routing; required VITALS, voice, and CURRENT terms are present; forbidden future/knowledge terms are absent; directed relationship targets and activation triggers match the plan; every selected era has one valid Era Context; active lists seed real entries; state variants match Scenario through secondary-era filters; events reach their own and all later eras only; and earlier entries contain no future deaths, revelations, relationships, roles, or events. Scout checks that source-backed character states, relationships, and knowledge boundaries were not omitted. Compass also verifies placement-plan lineage and policy. Weaver verifies each UID's resolved position, order, priority, depth/role, outlet, activation path, influence class, constant pressure, and target mapping; it rejects output that strengthens or moves an entry beyond the frozen plan.
## Finding reconciliation
Group findings by UID, JSON Pointer, category, and proposed operation. Merge duplicates, preserve compatible evidence, and surface conflicting replacements for parent or user judgment. Do not apply two incompatible patches in sequence.
Canon findings must cite evidence claim IDs when those claims exist. Activation findings must distinguish configurable SillyTavern behavior from WorldBuilder profile preferences.
Findings you deliberately do not patch are recorded as durable `deferred` records in `paths.patch_log`: one JSON object per finding with `type: "deferred"`, `file` (the target alias), `hard_error` (the finding id), `finding_ref`, `severity`, `category`, `disposition`, and a single-line `reason`. `verify_patches.py` counts deferrals in its accounting, so an acceptance is verifiable, not a silent skip. `decision_log.py` serves Guided/custom builds only.
Recorded patch rounds are immutable history: `verify_patches.py` re-verifies every record in the log, so a later fix that reverses a recorded, verified operation fails verification by design. When a new recommendation conflicts with a recorded repair, use one of the two sanctioned outcomes: accept it as a deferral whose `disposition` names the conflict (for example `blocked_by_recorded_repair`), so the build ships without pretending the reversal happened; or re-baseline so the change lands in a fresh recorded round through the amendment and change-set flow. Editing the log to hide the conflict is never a path.
## Patch verification
Write exact operations to `paths.patch_log`, apply them to a copy, and verify current bytes:
```bash
python3 {baseDir}/scripts/verify_patches.py \
  --patch-log /path/to/.work/patch-log.jsonl \
  --target output=/path/to/creations/final.json \
  --findings /path/to/artifacts/audit-log.md
```
Re-run structural, compatibility, identity, and semantic checks after every patch set. Preserve unknown fields and stable IDs.
## Re-audit and seal
A changed target invalidates the prior audit receipt. If patches changed final bytes, the normal path is scoped, not full: reviewing only what the patches actually touched, the same principle Batch 12's post-seal amendment mechanism already established one stage later in the pipeline:
1. Verify the patch log with the change-set flag, giving every `--target` alias the patch log's own records actually reference:
   ```bash
   python3 {baseDir}/scripts/verify_patches.py --patch-log <path> --target output=<final path> --target manifest=<path> [--target <alias>=<path> ...] --hard-errors <n> --write-change-set /path/to/change-set.json
   ```
   This only writes the change set when the patch gate genuinely passes; an incomplete or failing verification writes nothing, by design. A patch log that touched only entry-level fields produces `structural: false` with the specific `changed_uids`/`neighbour_affected_uids` the patches and their activation-graph neighbours actually cover; a patch log that touched any non-entry path (an `/architecture/...` change, for instance) correctly reports `structural: true`.
2. If `structural: true`, fall back to the full five-step path below: a structural change is not scopeable, the same rule `change_set.py`'s own comparison enforces ("structural forces full invalidation, no exceptions").
3. Otherwise, re-plan and re-run the four lenses scoped to just that change set:
   ```bash
   python3 {baseDir}/scripts/audit_plan.py --build-state /absolute/path/to/build-state.json --stage post-generation --scope changed --change-set /path/to/change-set.json
   ```
4. Pass `audit_gate.py` again, then continue to the runtime-adapter validation and seal steps below.
**Full re-audit (fallback for a structural change, or when no change set is available):**
1. Create a new post-generation audit plan.
2. Spawn all four audit lenses on the corrected target.
3. Record four new parent-observed runtime receipts.
4. Pass `audit_gate.py` again.
5. Replace the old seal atomically.
For a named output target, run and validate the parent-owned runtime adapter against the corrected `paths.final_output` bytes before sealing:
```bash
python3 {baseDir}/scripts/runtime_target_adapter.py export --build-state /absolute/path/to/build-state.json
python3 {baseDir}/scripts/runtime_target_adapter.py validate --build-state /absolute/path/to/build-state.json
```
Seal and release:
```bash
python3 {baseDir}/scripts/delivery_gate.py \
  --build-state /absolute/path/to/build-state.json \
  --seal
python3 {baseDir}/scripts/delivery_gate.py \
  --build-state /absolute/path/to/build-state.json
```
The v3 seal binds the final target hash, merge input, post-generation audit run ID, audit-gate receipt, all four auditor result/runtime hashes, and the current runtime-adapter receipt/output hashes when adaptation is required. Keep exactly one current seal.
**Amending a sealed build instead of a full re-audit (Batch 12).** Editing a small number of entries in an already-`delivery_permitted` build does not require repeating all five steps above wholesale. Compute a change set first (`change_set.py`), then:
1. `audit_plan.py --stage post-generation --scope changed --change-set <path>`; the four lenses review only the changed UIDs plus their neighbours, not the full artifact.
2. Spawn the four lenses on that narrowed assignment, same as a full audit; `audit_gate.py` needs no different handling, since it already derives its expected coverage from the assignment's own (already-scoped) entry list.
3. Run `delivery_gate.py --build-state <path> --seal`; when an additive amendment is pending it writes `seal_version: 4`, automatically binding `amends` to the previous seal and `change_set_sha256` to the current change set without restamping the immutable base chain.
4. For every affected stage, record `re_proven` or `carried_forward: slice_unaffected` in a decisions JSON and run `pipeline_stage_gate.py --record-amendment --change-set <path> --decisions-file <json>`, then run the ordinary delivery gate. The amendment sub-ledger, not mutated historical receipts, proves what was re-used.
Two guards force the full five-step re-audit above instead: an amendment depth cap of 3 (a fourth amendment on the same lineage forces re-baseline), and a 20%-of-entries-touched cap (`changed_uids` and `neighbour_affected_uids` counted together). `soul_contract.py`'s prose metrics and `budget_contract.py`'s seven simulations always run in full regardless; they are script passes, not child agents, so scoping them would not save the cost this path exists to save.
The era-router audit verifies canonical Scenario keywords, conflict rejection, boundaries, world-state summaries, active-entity edges, knowledge limits, state assertions, prohibited terms, and origin-plus-later event reach. The placement audit verifies purpose-based defaults, approved override reasons, depth/role completeness, outlet consumers, target compatibility, and exact output equality with the resolved plan.
## Dynamic-state audit
Compass verifies plan policy and lineage. Weaver verifies exact groups, weights, scoring, priority selection, probability, timed effects, matching sources, filters, triggers, automation, outlets, and neutral envelopes. Scout checks that dynamic restrictions did not hide required source coverage. Warden proves protected control, era, identity, knowledge, relationship, and required activation entries remain deterministic. Seal only after `dynamic_state_contract.py --stage output` binds the final bytes.
## Entry-label checkpoint
The merged artifact must pass `entry_naming.py --stage validate-output` before post-generation auditor assignments are created. Auditors review the exact normalized labels and target bytes.
