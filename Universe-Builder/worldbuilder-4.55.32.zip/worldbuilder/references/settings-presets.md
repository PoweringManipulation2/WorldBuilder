# Settings Presets
Use a settings preset when the user wants to reuse or share project-level WorldBuilder choices without copying a build workspace or Home Config.
## Contract
`settings_preset.json` uses `worldbuilder-settings-preset-v1`. It is an allowlisted WorldBuilder configuration artifact, not a SillyTavern file and not an OpenClaw configuration file.
A preset may contain only these normal build settings:
- `source_stance`, `source_kind`
- `retrieval`, `recursion`
- `era_mode`, `era_isolation`
- `placement_policy` (`automatic` or `review` only)
- `budget_profile`, `budget_policy` (`automatic` or `review` only)
- `pruning_objectives`
- `dynamic_policy` (`off`, `review`, or `preserve` only)
- `runtime_target`, `runtime_format`
- `audit_max_iterations` (1-5, default 3; bounds the audit loop, never a bypass; adjustable on an existing build with `settings_preset.py set`)
The schema is intentionally narrow. Unknown fields fail closed. A new `init_build.py` option does not become presettable merely because it exists.
## Never serialize
Do not put workspace/build/export paths, source-file paths, model names, batching/timeouts, interface mode, autonomy, debug settings, unverified-entry policy, context-window sizing, execution pipeline, custom-pipeline consent, audit bypasses, delivery controls, or arbitrary placement/budget/dynamic override blobs in a preset.
In particular, a preset can never express `--no-pre-gen-audit`, `skip audit`, `skip delivery`, or an equivalent bypass. Those are outside the contract rather than values that can be enabled or disabled.
Custom file-backed placement, budget, or dynamic policies are not portable in v1. Export must fail rather than silently drop the custom data.
## Export from a frozen build
```bash
python3 {baseDir}/scripts/settings_preset.py export \
  --build-state /absolute/path/to/build-state.json \
  --output /desired/path/settings_preset.json
```
The exported file contains no build ID or source path. Validate a shared file before use:
```bash
python3 {baseDir}/scripts/settings_preset.py validate \
  --preset /path/to/settings_preset.json
```

## Apply to a new build

Pass the preset to normal build initialization:

```bash
python3 {baseDir}/scripts/init_build.py "PROJECT NAME" \
  --artifact-type lorebook --schema 3 \
  --settings-preset /path/to/settings_preset.json
```

Preset values become defaults before the ordinary planning contracts are frozen. An explicit CLI/build-menu choice wins over the preset. A repeated explicit `--pruning-objective` list replaces the preset's objective list rather than merging silently.

Existing validation remains authoritative after import. For example, a preset requesting Dynamic State still requires Advanced Mode, and a lorebook build still cannot disable its required pre-generation audit.

## Reproducibility receipt

When a preset is used, `init_build.py` writes `artifacts/settings-preset-receipt.json`. It records the source-file hash, normalized preset hash, applied field names, explicitly overridden field names, and the normalized safe preset. It deliberately does not record the external preset path.

`build-state.json.settings_preset` and `artifacts/effective-config.json.settings_preset` bind that receipt. Home `config.json` is never mutated by applying a project preset.

## Build templates are a different layer

Reusable build templates are handled before initialization by `setup_state.py`; see `build-templates.md`. They prefill the visible guided settings pages and cannot complete or skip those pages. `settings_preset.json` remains the narrower post-menu default bundle consumed by `init_build.py`. Confirmed current-build answers must not be silently replaced by either mechanism.
