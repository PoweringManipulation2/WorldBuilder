# Entry Settings and Architecture Profiles
## Navigation
- [Principle](#principle)
- [World index entries](#world-index-entries)
- [Root entries](#root-entries)
- [Era Context entries](#era-context-entries)
- [Era-state entries](#era-state-entries)
- [Character entries](#character-entries)
- [Event entries](#event-entries)
- [Entry naming](#entry-naming)
- [Target mapping](#target-mapping)
## Principle
The manifest owns activation and architecture. Generation workers copy the declared settings exactly; they do not improvise constants, keys, filters, positions, recursion, or era reach.

These are WorldBuilder content profiles, not Character Card V3 validity rules.
## World index entries
Optional; at most one per build. Rendered by `world_index.py`, never authored by a worker. Read `lorebook-architecture.md`.

```json
{
  "architecture": {"layer": "world_index"},
  "activation": {"strategy": "constant", "recursion_role": "blocked", "emits": [], "forbidden_emits": []},
  "emit": {
    "constant": true,
    "keys": [],
    "position": "before_char",
    "insertion_order": 115,
    "extensions": {"prevent_recursion": true}
  }
}
```

`emits` stays empty and `prevent_recursion` stays true: the roster reaches entries through the model's next message, not through the recurse buffer. Exclude a subject with `architecture.index_member: false`; add an optional identifier of at most six words with `architecture.index_gloss`.
## Root entries
Single-era lore-bearing build:

```json
{
  "architecture": {"layer": "world_core", "era_scope": "single"},
  "activation": {
    "strategy": "constant",
    "recursion_role": "root",
    "emits": [],
    "forbidden_emits": []
  },
  "emit": {
    "constant": true,
    "keys": [],
    "selective": false,
    "position": "before_char",
    "extensions": {"prevent_recursion": true}
  }
}
```

Multi-era lore-bearing build uses `world_invariants` instead. Exactly one root entry is allowed.

The frozen profile resolves `prevent_recursion: true` for this layer, and `activation_map_gate.py` rejects an entry that both prevents recursion and owns outgoing edges. A root therefore declares no `emits` by default; Layer 2 anchors seed retrieval. A root that must seed it directly needs an explicit `prevent_recursion: false` override (the "different control pattern" `lorebook-architecture.md` allows), and both fields have to move together.
## Era Context entries
```json
{
  "architecture": {
    "layer": "era_context",
    "era_scope": "context",
    "era_ids": ["season-1"],
    "era_group": "worldbuilder-era-context"
  },
  "activation": {
    "strategy": "keyword",
    "recursion_role": "seed",
    "emits": ["Mira", "Halcyon", "Wayfarer Hotel"],
    "forbidden_emits": []
  },
  "emit": {
    "constant": false,
    "keys": ["Era: Season 1", "Season 1"],
    "secondary_keys": [],
    "selective": false,
    "position": "before_char",
    "insertion_order": 100,
    "extensions": {
      "prevent_recursion": false,
      "match_scenario": true
    }
  }
}
```

The target adapter emits the tested SillyTavern spelling for Scenario matching. Do not leave this false while relying on Scenario keywords. Every active entity named in the approved era plan must appear in `activation.emits` and have a same-era activation edge. The semantic `era_group` is mapped to a target-specific exclusivity mechanism only by the runtime adapter.
## Era-state entries
```json
{
  "architecture": {
    "layer": "character",
    "era_scope": "state",
    "era_ids": ["season-1"],
    "entity_key": "mira"
  },
  "emit": {
    "constant": false,
    "keys": ["Mira"],
    "secondary_keys": ["Era: Season 1", "Season 1"],
    "selective": true,
    "selectiveLogic": 0,
    "position": "after_char",
    "extensions": {
      "match_scenario": true,
      "prevent_recursion": false
    }
  }
}
```

`selectiveLogic: 0` is the canonical internal AND_ANY profile for the tested SillyTavern target. Never use vector-only retrieval for life/death, era, or canon-isolation rules.
## Character entries
All lorebook characters use `character_format: canonical-v1` and the complete required section list from `character-template.md`.

Tier A/B characters may allow intentional recursion through CONNECTIONS. Tier C characters normally prevent further recursion unless the recursion map records a required edge.

Schema 1 stars use card fields rather than lorebook entry settings.
## Event entries
Events declare:

```json
{
  "architecture": {
    "layer": "event",
    "era_scope": "event",
    "origin_era_id": "finale",
    "era_ids": ["finale", "post-finale"]
  }
}
```

Their secondary keys include only the origin and later eras. The architecture gate rejects backward reach.
## Inclusion groups
Use inclusion groups only for mutually exclusive candidates. **Weighted** selection uses group weight after activation. **Prioritize Inclusion** instead chooses the activated candidate with the highest Order; group scoring may narrow candidates by matched-key strength first. Era isolation must not rely on inclusion groups alone: Scenario matching and selective secondary-era keys remain authoritative.
## Placement and influence
Read `prompt-placement.md`. The frozen `placement-plan.json` assigns each lorebook layer a purpose, influence class, recommended/allowed semantic positions, and target mapping. Ordinary position and order values inherit from `default-profile.json` and may remain omitted in the readable map; generation assignments receive resolved values.

Use `before_char` for World Core, World Invariants, and Era Contexts. Use `after_char` for normal character, relationship, location, faction, organization, event, object, and concept state. Reserve `depth` for explicitly planned immediate scene reminders or corrections and require both depth and role. Reserve `outlet` for a named approved consumer. A UID-level deviation requires an exact plan override and `architecture.placement_override.reason`.

Placement does not replace activation. Fix missing keys, filters, or recursion edges instead of moving an entry to a stronger prompt location.
## Entry naming
Read `entry-naming.md`. The manifest keeps a canonical subject in `name` and may freeze a visible `display_name`. Emitted lorebook labels use concise semantic prefixes such as `RULE:`, `ITEM:`, `CHARACTER:`, `LOCATION:`, and `EVENT:`. Source titles, URLs, and retrieval prose belong in source/evidence metadata, never the visible entry label. The merge and delivery gates verify the naming receipt before post-generation audit and release.
## Target mapping
Use one internal meaning, then emit for the selected target:

| Meaning | CCv3 core/app extension | ST-native |
|---|---|---|
| Primary keys | `keys` | `key` |
| Secondary keys | `secondary_keys` | `keysecondary` |
| Order | `insertion_order` | `order` |
| Enabled | `enabled` | inverse `disable` |
| Scenario matching | tested app extension | tested native field |
| Prevent recursion | tested app extension | `preventRecursion` |
| Stable identity | `id` | `uid` |

Do not emit both naming styles unless a tested compatibility mode requires mirrors. Unknown extension data remains preserved.
## Manifest activation authority
Every lorebook entry declares a separate `activation` object in addition to target emission settings:

```json
{
  "activation": {
    "strategy": "keyword",
    "recursion_role": "intermediary",
    "emits": ["Related Entry Key"],
    "forbidden_emits": []
  }
}
```

The strategy must agree with `emit`: constant entries use `constant`, vectorized keyed entries use `hybrid`, keyless vectorized entries use `vector-only`, ordinary keyed entries use `keyword`, disabled entries use `disabled`, and intentionally external/manual entries use `manual`. Critical world/era controls cannot be vector-only.

`emits` contains only exact terms intentionally used as recursion edges. Every matching term requires an edge in `manifest.activation_graph.edges`. `leaf` and `blocked` entries cannot emit graph terms or own outgoing edges.

The frozen `default-profile.json` supplies ordinary values. Omit default settings from the readable map; do not generate unnecessary explicit fields. Strategy, recursion role, keys, and graph edges remain explicit. Read `activation-map.md`.
## Budget and pruning settings
Budget profile, per-entry targets, layer allocation, and pruning eligibility are WorldBuilder planning fields, not CCv3 entry fields. Keep them in `budget-plan.json`, assignment `budget_context`, receipts, and audit lineage. Do not serialize them into arbitrary target extensions.

Entry priority, placement, direct-versus-recursive activation, and constant status are inputs to simulations. Protected categories override ordinary pruning eligibility. Activation hygiene defaults (connectivity tiering, `non_recursable` dampening, `prevent_further_recursion` leaves, and the pre-ship activation scan) are in `references/activation-hygiene.md`; connectivity tiering applies `connectivity_tiering.py` at merge (weight floors plus Batch 49 type-aware order bands; `--reassign-orders` repairs an existing book's order scatter; entry labels cap at 48 characters with universal `PREFIX:` and era `(Root)`/`(Branch)` markers; see `entry-naming.md`).

The hub threshold is a density choice, not a constant: `connectivity_tiering.py --hub-threshold` defaults to 2, and denser books raise it so `hub` needs more inbound connections to qualify (on a real 108-entry book, moving 2 -> 3 moved ten entries from hub to ordinary; measure the tier counts before trusting the default).
## Dynamic state and variation
Read `dynamic-state-variation.md`. The manifest and frozen `dynamic-state-plan.json` own optional groups, probability, timed effects, extra matching sources, character/tag filters, generation triggers, greeting variants, automation IDs, and outlets. Defaults are deterministic. Keep these semantics out of arbitrary target keys; generation emits only the neutral envelope and the parent runs `runtime_target_adapter.py` after audited final bytes exist.
