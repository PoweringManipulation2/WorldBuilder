# Character Identity, Behavior, and Relationship System

## Navigation

- [Purpose](#purpose)
- [Planning artifact](#planning-artifact)
- [Stable identity](#stable-identity)
- [Behavior model](#behavior-model)
- [Era-specific states](#era-specific-states)
- [Split decisions](#split-decisions)
- [Relationship graph](#relationship-graph)
- [Manifest binding](#manifest-binding)
- [Generation assignments](#generation-assignments)
- [Validation](#validation)

## Purpose

Treat a character as a planned identity with one or more explicit states, not as an unstructured biography. Freeze the plan before generation so names, voice, knowledge, relationships, and current circumstances cannot drift between workers or eras.

Every build with generated character entries requires:

```text
artifacts/character-plan.json
```

The contract is `worldbuilder-character-system-v1`. The manifest binds the exact plan SHA-256, and every character manifest entry binds one `character_id` plus one `character_state_id`.

## Planning artifact

The top level contains:

```json
{
  "kind": "worldbuilder-character-plan",
  "plan_version": 1,
  "contract": "worldbuilder-character-system-v1",
  "build_id": "...",
  "timeframe_mode": "single",
  "characters": [],
  "relationships": []
}
```

`timeframe_mode` is `single`, `multi`, or `set`.

- `single`: one locked state per generated character unless a supporting lorebook intentionally contains more.
- `multi`: state entries are filtered through the approved era router.
- `set`: a parent character-card set plan may describe multiple states, but each delivered Schema 1 child card remains a separately validated single-era build.

## Stable identity

Keep facts that identify the same person across states under `identity`:

```text
canonical_name
aliases
titles
species
pronouns
age_state
occupations
rank
factions
location
life_status
physical_form
```

The identity block is a planning record, not prose to paste verbatim. Mutable values are repeated or overridden in the selected state. Never merge two distinct people because they share a title, role, species, or translated name.

Canonical names and aliases must not collide across planned characters. Titles may be shared and do not establish identity by themselves.

Activation keys are part of identity, not an afterthought. A high in-degree character (one many entries reference) must carry at least one distinctive multi-word activation key (a title, epithet, or fuller name already among its own `titles`/`aliases`) beside its bare single-word name. A character keyed only by its bare first name arms the whole book from an incidental name-drop inside another entry's content; a direct in-chat mention of the bare name still fires normally, but recursion reaches such an entry only through the multi-word key. `prevent_recursion_candidates.py` with `--character-risks` reports the entries that need one.

## Behavior model

Track behavior separately from biography:

```text
speech_patterns
vocabulary
emotional_regulation
drives
fears
values
habits
conflict_behavior
relationship_behavior
capabilities
limitations
knowledge_boundaries
secrets_known
secrets_unknown
```

Use evidence-backed observations. Do not fill every array for its own sake. At least one meaningful voice, motive, value, or conflict-behavior signal is required so the plan is not an empty shell.

The model supplies the `PERSONALITY & VOICE` field/section and helps greetings and examples remain behaviorally consistent. It must not authorize facts unavailable in the selected state.

## Era-specific states

Each state records:

```text
state_id
era_id
manifest_uids
life_status
role
rank
occupations
factions
location
physical_form
goals
knowledge_boundaries
secrets_known
secrets_unknown
required_vitals_terms
required_voice_terms
required_current_terms
forbidden_knowledge_terms
```

`manifest_uids` binds generated lorebook entries or the Schema 1 star record to this state. A research-only person may use `reference_only: true` with no generated UID.

The required-term arrays are small deterministic checks, not prose templates:

- `required_vitals_terms`: identity facts that must appear in `VITALS`.
- `required_voice_terms`: behavior signals that must appear in `PERSONALITY & VOICE` or the card Personality field.
- `required_current_terms`: state facts that must appear in `CURRENT`.

Every generated state requires at least one value in each of those three arrays. Reference-only states may leave them empty.
- `forbidden_knowledge_terms`: later facts, secrets, deaths, relationships, forms, titles, or events that must not appear anywhere in this state.

Keep these lists precise. Do not add broad words likely to produce false positives.

## Split decisions

Every character records:

```json
{
  "split": {
    "required": true,
    "reasons": ["knowledge", "role"],
    "state_ids": ["hero-early", "hero-late"]
  }
}
```

Split when one or more of these changes materially:

```text
life_status
role
rank
allegiance
location
relationships
knowledge
physical_form
capabilities
goals
reputation
equipment
```

Multiple planned states require `split.required: true` and at least one reason. A single state cannot be marked as a required split.

Do not split only because a date advances. Do split when combining states would cause contradictory behavior, impossible knowledge, or future leakage.

## Relationship graph

Record relationships as directed, era-specific behavioral links:

```text
relationship_id
source_character_id
source_state_id
target_name
target_character_id / target_state_id when generated
era_id
relationship_type
public_state
private_state
knowledge_state
behavioral_consequences
activation_trigger / activation_target_uid when recursive
required_in_connections
required_connection_terms
```

A relationship is directed because each side may know, feel, or behave differently. Create the reverse record when the other side is also generated and needs its own behavior.

`required_in_connections: true` requires the source character's `CONNECTIONS` section to name the target. Optional `required_connection_terms` provide a small deterministic vocabulary check for the planned public/private state or behavioral consequence; leave them empty when exact wording would be brittle. When an `activation_target_uid` is present:

1. `activation_trigger` must match a primary keyword on the target entry.
2. Every generated source-state entry must declare that exact term in `activation.emits`.
3. The activation map must contain the corresponding source-to-target edge.

This makes relationship names deliberate recursion seeds instead of accidental prose.

## Manifest binding

Every generated character entry declares:

```json
{
  "architecture": {
    "character_format": "canonical-v1",
    "character_role": "lorebook_character",
    "character_id": "hero",
    "character_state_id": "hero-early",
    "identity_model": "structured-v1",
    "behavior_model": "structured-v1",
    "required_sections": [
      "TIMELINE", "VITALS", "PERSONALITY & VOICE",
      "CONNECTIONS", "APPEARANCE", "BACKSTORY", "CURRENT"
    ]
  }
}
```

The manifest top level binds `character_plan_sha256`; `architecture.character_system` binds the same hash and contract. Every generated character UID must appear in exactly one planned state, and every non-reference planned UID must exist in the manifest.

## Generation assignments

Assignment map slices include `character_context` and `character_plan_sha256`. For each selected character state, workers receive:

- canonical name, aliases, and titles;
- stable identity;
- behavior model;
- exact state record;
- split reasons and sibling states;
- incoming/outgoing relationship records;
- required and forbidden terms;
- the activation-map neighbors and emitted terms from Batch 2.

Workers must research and write one UID at a time. They may not infer later knowledge from sibling states or replace the structured plan with a blended biography.

## Validation

Planning rejects:

- duplicate character IDs, state IDs, or generated UID ownership;
- canonical-name/alias collisions;
- empty behavior models;
- multiple states without a justified split;
- unknown eras or split reasons;
- relationship endpoints that do not exist;
- relationship triggers that cannot activate their target;
- character manifest rows not bound to the plan.

Per-entry checkpoint validation rejects:

- missing or reordered canonical sections;
- missing required identity, voice, current-state, or relationship terms;
- forbidden future/knowledge terms;
- a checkpoint that belongs to another planned state.

Final output validation repeats those checks, validates Schema 1 Name and field routing, and binds the receipt to the exact character plan bytes.
