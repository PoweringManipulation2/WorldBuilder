# Entry Naming and Source Provenance
<!-- phase-contract --> Exit contract: run `python3 {baseDir}/scripts/phase_contract.py --build-state <build-state> --stage <entry_names_normalized>` before this stage's gate; rendered copies ship in the build's worker kit under `exit-contracts/`.
## Contract
Visible lorebook labels use `PREFIX: Subject` with the type prefix as the first visible characters, remain at most 48 characters, and never contain URLs, wiki names, article provenance, retrieval notes, or `Source from ...` boilerplate. Model-facing entry `content` follows the same provenance boundary: citations and retrieval boilerplate belong in evidence/metadata, not injected prose; suspicious content is flagged for review and is never silently rewritten.
Approved prefixes:
- `INDEX`: the single world index roster; `WORLD`: world-level framing above the rules.
- `RULE`: invariants, controls, hard constraints, safety/canon rules.
- `ITEM`: objects, artifacts, tools, weapons, possessions.
- `CHARACTER`: individual people or beings.
- `LOCATION`: places, regions, buildings, realms.
- `FACTION` or `ORGANIZATION`: social, political, military, or institutional groups.
- `SPECIES`: biological, supernatural, or taxonomic kinds.
- `EVENT`: incidents, battles, ceremonies, history.
- `ERA`: Era Context entries; era roots end `(Root)`, non-root era entries carry `(Branch)` or their era qualifier.
- `RELATIONSHIP`: relationship-state entries.
- `ABILITY`: powers, techniques, capabilities.
- `SYSTEM`: mechanics, laws, economies, magic, structured processes.
- `CONCEPT`: terminology or other concepts; `EPISODE`: installments of a serialized work.
Examples: `RULE: No future knowledge`, `ITEM: Thingimajig`, `CHARACTER: Mira`, `LOCATION: Wayfarer Hotel`.
## Ownership and lifecycle
The manifest's `entries[].name` is the canonical planning subject. During the planning gate, `entry_naming.py` materializes `artifacts/terminology-dictionary.json`, freezing project-wide canonical spellings/capitalization plus explicit `aliases` and `titles`. `entries[].canonical_name` overrides `name` for dictionary canon when present. Canonical names and aliases resolve uniquely; shared titles may remain ambiguous and never establish identity by themselves. Activation keys are not rewritten or automatically treated as naming aliases. `entries[].display_name` may freeze a compliant visible label; otherwise WorldBuilder derives one from type/layer plus the dictionary-resolved subject. Generation workers consult the frozen dictionary before inventing a spelling/title variant.
Keep provenance in manifest sources, per-UID evidence, source metadata, and access dates. When normalizing an import, write the semantic label to both `name` and SillyTavern-visible `comment`. Preserve replaced labels in `extensions.worldbuilder_entry_naming.previous_labels` and source/synthesis prose in `extensions.worldbuilder_provenance`; moving provenance out of the visible label never deletes it.
Normalize a legacy file with:
```bash
python3 {baseDir}/scripts/entry_naming.py --input old.json --output renamed.json
```
Add `--manifest artifacts/manifest.json` when available. A custom label may set `{"naming":{"preserve_label":true}}`, but it must still use an approved prefix.
