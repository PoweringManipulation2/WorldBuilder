# Error Blacklist
## Navigation

- [Release blockers](#release-blockers)
- [Compatibility warnings](#compatibility-warnings)
- [Editorial warnings](#editorial-warnings)
- [Worker failures](#worker-failures)
## Release blockers

Block delivery for:

- Invalid JSON or wrong declared format.
- `chara_card_v2` presented as V3.
- Missing required V3 fields or wrong field types.
- Duplicate/conflicting stable identities.
- Manifest-declared output missing or mismatched.
- Unsafe CHARX path or invalid archive.
- Persona emitted as JSON.
- Lorebook pipeline missing receipts, audit passes, merge lineage, or valid seal.
- Patch log that does not match current bytes.
- Missing worker output, invalid worker output, non-completed runtime status, or missing end delimiter.
- Multi-era build without one constant World Invariants entry and one Scenario-matched Era Context per approved era.
- Era-state entry that is constant, lacks secondary era keys, omits Scenario matching, or does not use selective AND_ANY.
- Event entry visible before its origin era or missing a later era where it must remain available as history.
- Earlier-era content that reveals a future death, secret, transformation, allegiance, relationship, role, destruction, or event.
- Lorebook character missing or reordering TIMELINE, VITALS, PERSONALITY & VOICE, CONNECTIONS, APPEARANCE, BACKSTORY, or CURRENT.
- Schema 1 star with personality duplicated into Description, missing canonical Description sections, or an unapproved fixed Scenario.
- Malformed known decorator value: `@@depth`/`@@instruct_depth`/`@@scan_depth`/`@@activate_only_after`/`@@is_greeting` with a non-numeric value, or `@@role` outside assistant/system/user. An unrecognized decorator name is a warning, not a blocker; it is preserved through round-trip, not rejected.
## Compatibility warnings

Warn or request confirmation for:

- Optional application settings not supported by the named target.
- Extended insertion placement without target-version mapping.
- Critical rule stored only in creator notes.
- Vector-only critical information.
- Native World Info being converted to V3 with lossy fields.
- Legacy aliases that may drift.
## Editorial warnings

These are not schema failures:

- Fewer than three tags.
- No rating tag.
- `name` and `comment` differ.
- Personality field routing differs from a WorldBuilder template.
- Talkativeness values repeat.
- Layer order differs from a profile preset.
- A valid entry omits optional extension settings.
- Every entry in a set compressed to roughly the same length regardless of source density; a uniform per-entry token target applied without regard to `source_tokens` or the retention ladder is a truncation pattern wearing a compression ratio's clothes; dense, heavily-obligated entries need `compute_entry_target`'s split signal, not a smaller uniform cap.
## Worker failures

Never accept:

- A truncated report.
- A report without its exact end delimiter.
- Output bound to another build ID or manifest hash.
- A child saying success when the expected file is absent.
- A timed-out/failed/unknown runtime result.
- A phase file older than the parallel pre-dispatch receipt.
- An exit criterion that requires infrastructure the agent cannot provision; separate executable checks from explicitly blocked external acceptance instead of treating unlimited effort as a remedy.
Repair or respawn with a smaller assignment. Do not reinterpret missing evidence as success.

## Dynamic-state release blockers

- Probability below 100 without an approved purpose.
- Random or timed behavior on protected control, era, identity, knowledge, relationship, or required activation entries.
- Group members missing reciprocal membership, non-positive weights, or tied priority order.
- Era Context entries that omit Scenario matching.
- Automation IDs or outlets without approved registries.
- Assignment, phase, output envelope, receipt, or seal hashes that disagree with the frozen dynamic-state plan.
- Runtime-specific field guesses presented as portable Batch 8 output.
