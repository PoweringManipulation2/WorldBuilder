# Widget: Tools submenu

Rendered only when `show_widget` is available. Call `show_widget` with the HTML below as `widget_code` and `Tools` as `title`, then send exactly one line of chat text under it: `Pick a tool, or upload the file you want to work on.`

Adapted from the `wb-menu-lab` prototype's `tools.md`. Tier badges are verified against `capability_tiers.py`'s own `TIER_CAPABILITIES` (`settings-menu.md` § Tools submenu), not copied from the prototype without checking; the prototype's own README discloses every number in it is fake, so the badges below were confirmed against the real implementation before being written here.

```html
<style>
 .wb{font-family:var(--font-body);color:var(--text);line-height:1.4}
 .wb-head{display:flex;align-items:baseline;justify-content:space-between;gap:.75rem;margin-bottom:.2rem}
 .wb-h1{margin:0;font-size:1.1rem;font-weight:650;color:var(--text-strong)}
 .wb-sub{margin:0 0 1rem;font-size:.82rem;color:var(--muted)}
 .wb-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(215px,1fr));gap:.6rem}
 .wb-opt{display:flex;flex-direction:column;align-items:flex-start;gap:.25rem;text-align:left;
   width:100%;padding:.75rem .85rem;background:var(--card);border:1px solid var(--border);
   border-radius:var(--radius);cursor:pointer;font:inherit;color:inherit}
 .wb-opt:hover{border-color:var(--accent)}
 .wb-top{display:flex;align-items:center;gap:.4rem;width:100%}
 .wb-opt b{color:var(--text-strong);font-size:.94rem;font-weight:600;flex:1}
 .wb-opt span{color:var(--muted);font-size:.78rem}
 .wb-tier{font-family:var(--font-mono);font-size:.66rem;text-transform:uppercase;
   letter-spacing:.04em;color:var(--muted);border:1px solid var(--border);
   border-radius:calc(var(--radius) / 2);padding:.05rem .3rem;white-space:nowrap}
 .wb-sep{height:1px;background:var(--border);margin:1rem 0 .85rem}
 .wb-foot{font-size:.78rem;color:var(--muted);margin:0 0 .8rem}
 .wb-back{background:none;border:none;color:var(--accent);cursor:pointer;font:inherit;
   font-size:.8rem;padding:0}
</style>
<div class="wb">
  <div class="wb-head">
    <h1 class="wb-h1">🛠️ Tools</h1>
  </div>
  <p class="wb-sub">Work on an artifact that already exists.</p>

  <div class="wb-grid">
    <button class="wb-opt" onclick="sendPrompt('audit')">
      <div class="wb-top"><b>🔍 Audit</b><span class="wb-tier">unbound</span></div>
      <span>Errors, drift, contradictions, import safety</span>
    </button>
    <button class="wb-opt" onclick="sendPrompt('prune')">
      <div class="wb-top"><b>✂️ Prune</b><span class="wb-tier">unbound</span></div>
      <span>Cut what can co-fire, without losing lore</span>
    </button>
    <button class="wb-opt" onclick="sendPrompt('iterate')">
      <div class="wb-top"><b>✏️ Iterate</b><span class="wb-tier">unbound</span></div>
      <span>Revise entries, keys, or card fields</span>
    </button>
    <button class="wb-opt" onclick="sendPrompt('update merge')">
      <div class="wb-top"><b>🔀 Update / Merge</b><span class="wb-tier">legacy</span></div>
      <span>Fold new material in without losing IDs</span>
    </button>
    <button class="wb-opt" onclick="sendPrompt('convert')">
      <div class="wb-top"><b>📦 Convert</b><span class="wb-tier">unbound</span></div>
      <span>Between JSON, native World Info, CHARX, PNG</span>
    </button>
    <button class="wb-opt" onclick="sendPrompt('art')">
      <div class="wb-top"><b>🖼️ Art &amp; Expressions</b><span class="wb-tier">unbound</span></div>
      <span>Prompts always; rendered images need image_generate</span>
    </button>
  </div>

  <div class="wb-sep"></div>
  <p class="wb-foot">
    <b>unbound</b> works on any lorebook, including hand-made ones ·
    <b>legacy</b> also reads older WorldBuilder output ·
    <b>bound</b> needs a current WorldBuilder build
  </p>
  <button class="wb-back" onclick="sendPrompt('home')">← Home</button>
</div>
```

The tier shown on each card is the minimum the tool needs, never a claim about the specific artifact the person is about to upload; selecting a tool routes to that tool's own intake, which resolves the real artifact and reports its actual tier via `capability_tiers.detect_tier`.
