# Widget: Greeting / Home

Rendered only when `show_widget` is available (`greeting.md` § Tier detection). Call `show_widget` with the HTML below as `widget_code` and `WorldBuilder` as `title`, then send exactly one line of chat text under it: `Pick a lane, or just tell me what you want to build.`

Adapted from the `wb-menu-lab` prototype's `home.md`, with one deliberate structural difference: the prototype's own demo omits Soul Extractor from its home screen entirely (folding it into a build-select screen instead), but the real, established WorldBuilder greeting gives Soul Extractor its own prominent placement above the four main categories. That is preserved here rather than adopted away, since it reflects a real product choice this batch was not asked to change.

```html
<style>
 .wb{font-family:var(--font-body);color:var(--text);line-height:1.4}
 .wb-head{display:flex;align-items:baseline;justify-content:space-between;gap:.75rem;margin-bottom:.2rem}
 .wb-h1{margin:0;font-size:1.15rem;font-weight:650;color:var(--text-strong);letter-spacing:.01em}
 .wb-sub{margin:0 0 1rem;font-size:.82rem;color:var(--muted)}
 .wb-soul{display:flex;flex-direction:column;align-items:flex-start;gap:.2rem;text-align:left;
   width:100%;padding:.75rem .85rem;background:var(--accent-subtle);border:1px solid var(--accent);
   border-radius:var(--radius);cursor:pointer;font:inherit;color:inherit;margin-bottom:.7rem}
 .wb-soul b{color:var(--text-strong);font-size:.95rem;font-weight:600}
 .wb-soul span{color:var(--muted);font-size:.79rem}
 .wb-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:.6rem}
 .wb-opt{display:flex;flex-direction:column;align-items:flex-start;gap:.2rem;text-align:left;
   width:100%;padding:.75rem .85rem;background:var(--card);border:1px solid var(--border);
   border-radius:var(--radius);cursor:pointer;font:inherit;color:inherit}
 .wb-opt:hover{border-color:var(--accent)}
 .wb-opt b{color:var(--text-strong);font-size:.95rem;font-weight:600}
 .wb-opt span{color:var(--muted);font-size:.79rem}
 .wb-sep{height:1px;background:var(--border);margin:1rem 0 .85rem}
 .wb-foot{font-size:.78rem;color:var(--muted)}
 .wb-foot code{font-family:var(--font-mono);font-size:.75rem;background:var(--card);
   padding:.08rem .3rem;border-radius:calc(var(--radius) / 2)}
</style>
<div class="wb">
  <div class="wb-head">
    <h1 class="wb-h1">✍️ WorldBuilder</h1>
  </div>
  <p class="wb-sub">Build and maintain SillyTavern cards, lorebooks, and personas.</p>

  <button class="wb-soul" onclick="sendPrompt('soul extractor')">
    <b>🔮 Soul Extractor</b><span>Paste text or name an author → style guide</span>
  </button>

  <div class="wb-grid">
    <button class="wb-opt" onclick="sendPrompt('build')">
      <b>🧱 Build</b><span>Character, World, Lorebook, Group, Persona</span>
    </button>
    <button class="wb-opt" onclick="sendPrompt('tools')">
      <b>🛠️ Tools</b><span>Audit, Prune, Iterate, Update/Merge, Convert, Art</span>
    </button>
    <button class="wb-opt" onclick="sendPrompt('config')">
      <b>⚙️ Config</b><span>Interface, models, batching, image provider</span>
    </button>
    <button class="wb-opt" onclick="sendPrompt('info')">
      <b>📚 Info</b><span>How everything works, and why</span>
    </button>
  </div>

  <div class="wb-sep"></div>
  <p class="wb-foot">
    Or describe the job and it routes straight there: <code>prune my Skyward Reach book</code>,
    <code>full detail multi-era World</code>, <code>continue Amberfield</code>.
    Drop in a card or lorebook to work on an existing one.
  </p>
</div>
```

Every `sendPrompt` argument above (`soul extractor`, `build`, `tools`, `config`, `info`) is a mode name the text-tier contract also defines (`greeting.md`); a person on the widget tier and a person on the text tier who pick the equivalent option land in identical routing, which is exactly what `SKILL.md`'s widget-tier hard-requirement check verifies.
