# World Mode
## Navigation

- [Purpose](#purpose)
- [Output](#output)
- [Hard invariants](#hard-invariants)
- [Field architecture](#field-architecture)
- [Planning questions](#planning-questions)
- [Lorebook responsibilities](#lorebook-responsibilities)
- [Workflow](#workflow)
- [Design rationale](#design-rationale)
- [Release](#release)
## Purpose

Create a setting-first, user-directed experience. World Mode is not a character card with extra lore and must not require a central protagonist, fixed point of view, narrator persona, mandatory user identity, or predetermined plot.

A world may emphasize an ensemble cast, era, location, faction, or conflict when the user requests it. Emphasis never makes one character the owner of the card or the lens through which all lore must pass.

The user must remain free to:

- play an original or canon character;
- begin in any supported era or location;
- join, oppose, or ignore any faction;
- follow canon, alter history, or create a custom timeline;
- pursue any compatible genre or activity;
- move beyond the initial scene without artificial restrictions.
## Output

Create one Character Card V3 Schema 2 JSON containing `data.character_book`. CHARX is optional. Read `card-shell-routing.md` and freeze `artifacts/card-shell-plan.json` before manifest approval.

Schema 2 is only the delivery container. It does not imply that World Mode needs a character-shaped creative center.
## Hard invariants

World Mode must satisfy all of the following unless the user explicitly requests otherwise:

1. Do not ask who the central character is.
2. Do not ask whose POV the lorebook hangs on.
3. Do not make a protagonist, narrator, observer, chronicler, or guide the owner of the world.
4. Do not assign the user a fixed identity, allegiance, relationship, starting location, or goal.
5. Do not place the bulk of world knowledge in card fields.
6. Keep the card shell compact and setting-level.
7. Keep `scenario` blank by default so the user can use it as a settings page.
8. Put era routing, custom-history handling, characters, locations, factions, systems, events, and relationships in the embedded lorebook.
9. Treat major protagonists as an ensemble or priority group when useful, never as mandatory viewpoint anchors.
10. Preserve open-ended play even when an era, location, faction, or ensemble receives emphasis.

A World build fails review when its experience depends on one selected character speaking for, owning, or filtering the setting without an explicit user request.
## Field architecture
### Name

Use the setting or experience name, not a person.

Examples:

- `Skyward Reach`
- `The World of Skyward Reach`
- `Skyward Reach & Skyward Legacy World`
### Description

Keep `description` brief. It contains only:

- the setting's core identity;
- a concise statement of scope;
- broad atmosphere and themes;
- Soul Extractor tone, prose, and presentation guidance when available;
- a brief, third-person statement that the world has no fixed protagonist; NPCs, factions, and events respond to whichever role, history, and actions a participant brings.

The description is model-facing: write it as a compact world-core statement of identity, scope, atmosphere, and themes, never marketing copy addressed to a reader explaining why they should be interested in the setting. It must not address a reader in the second person ("you", "your") outside legitimately quoted example text; `writing_quality.py`'s description-voice check (`check-description`) flags it for review, never auto-rewrite. Do not turn `description` into a cast encyclopedia, chronology, rules dump, or protagonist profile. The embedded lorebook performs the heavy lifting.
### Personality and other character-shaped shell fields

`personality` must be blank. Do not invent a character personality for the world shell. When the schema or frontend exposes character-shaped fields, use only compact setting-level simulation guidance that cannot be placed more appropriately in the lorebook. Leave optional fields empty when that produces the cleaner result.

Never create an omniscient guide, chronicler, narrator, or mascot merely to fill a field.
### Scenario

Leave `scenario` blank by default. Populate it only when the user selected the named `fixed` card setup and approved the exact premise text recorded in the card-shell plan.

Treat it as a user-controlled settings page where the user may define any combination of:

- era or season;
- starting location;
- user identity or role;
- custom history;
- alternate-canon changes;
- pre-existing relationships;
- special conditions;
- tone or genre preferences.

Do not prefill a fixed scene, relationship, protagonist, or plot. A visible settings template may be included only when the user asks for one; otherwise keep the field empty.

Example user-authored Scenario content:

```text
Era: After Season 1
Starting location: Meridian
User role: Newly arrived sinner
Custom history: The Reckoning was delayed
Special condition: Mira already knows the user
```
### Metadata and creator notes

Use human-facing metadata/creator notes as the usage guide. Include:

- supported eras or timeline modes;
- exact scenario keywords or phrases that activate era-specific lore;
- examples of custom-history and condition syntax;
- additional usage notes;
- WorldBuilder attribution;
- the configured WorldBuilder/GitHub link.

Do not hide model-critical runtime instructions only in human-facing metadata. The lorebook must contain the actual era-routing and custom-history behavior.

A typical guide should explain phrases such as:

```text
Era: pre-series
Era: season 1
Era: post-reckoning
Era: current canon
Custom history: the founder survived
Canon changes: the refuge failed
```
### First message

Use an open, neutral entry into the setting. It may:

- establish atmosphere;
- present several optional starting doors;
- ask who the user is, where they are, or what they do;
- offer a custom-start option.

It must not speak as a selected canon character, force a predefined user role, or make one location mandatory unless the user requested that framing.
### Lorebook

The embedded lorebook is the world engine and carries nearly all substantive content.
## Planning questions

After discovery, ask about the experience rather than a central character.

Preferred menu:

```text
🌍 WORLD EXPERIENCE

How should this world be framed?

1. Open World
   No central protagonist. The user may be anyone and begin anywhere.

2. Ensemble Emphasis
   Keep the world open while giving selected protagonists or groups stronger coverage.

3. Era Emphasis
   Center activation around a season, arc, date, or timeline without fixing a protagonist.

4. Location Emphasis
   Give a location stronger initial prominence while preserving freedom to leave.

5. Faction Emphasis
   Give one or more factions stronger initial prominence without fixing allegiance.

6. Custom Experience
   Describe any emphasis, starting conditions, or alternate history.

7. Fully Automatic
   Build a broad open-world experience from the discovery corpus.
```

Default to `Open World` when the user does not choose an emphasis.

The user must be able to answer: `No emphasis. Make the whole world accessible.`
## Lorebook responsibilities

The lorebook should contain the operational and factual layers required by the setting, including as applicable:

- world operation rules;
- user freedom and identity handling;
- era detection and activation;
- scenario-keyword routing;
- custom-history and canon-override precedence;
- timeline and chronology;
- cosmology and setting systems;
- locations and travel relationships;
- factions, institutions, and social rules;
- characters and ensemble relationships;
- events, conflicts, objects, species, and concepts;
- conditional activation and recursion;
- alternate-state or multi-era variants.

Use retrieval-driven entries rather than an entry for every discovered name. Core/anchor/detail layers are planning aids, not schema constraints.
## Workflow

1. Complete the paged settings flow, freeze the card-shell choices, and initialize a `world` build with schema 2.
2. Lock source stance, target scope, optional era emphasis, and user deviations.
3. Run exhaustive discovery before asking experience-framing questions.
4. Ask only about open-world emphasis, era/location/faction priorities, custom history, and output preferences.
5. For multi-era, propose and obtain approval for `era-plan.json` with exact Scenario phrases before creating the manifest.
6. Bind the manifest to `card-shell-plan.json`, build the authoritative manifest and retrieval map, then run the architecture planning gate.
7. Generate the compact card shell plus World Invariants and all Era Context entries before chronological era-state phases.
8. Generate lorebook entries in canonical phase files through interleaved research/write entry cycles, grouping state work by era.
9. Merge while preserving shell metadata and stable IDs.
10. Audit for central-character leakage, fixed-user assumptions, Scenario prefill, omitted era-guide keywords, temporal leakage, character-format drift, and lore misplaced into shell fields.
11. Run exact patch verification, architecture output gate, seal, and delivery gate.
## Design rationale

The field architecture and open-world constraints are intentional product contracts. Read `design-rationale.md`, especially DR-001 through DR-004, before auditing or changing World Mode. A blank Scenario, compact Description, human-facing metadata guide, and lorebook-heavy implementation are not missing content by themselves.
## Release

```bash
python3 {baseDir}/scripts/phase_gate.py --stage pre-merge --build-state /path/to/build-state.json
python3 {baseDir}/scripts/merge_phases.py --build-state /path/to/build-state.json --schema 2
# audit and copy corrected bytes to paths.final_output
# for a named target: runtime_target_adapter.py export --build-state /path/to/build-state.json
# then validate the adapter receipt before sealing
python3 {baseDir}/scripts/delivery_gate.py --build-state /path/to/build-state.json --seal
python3 {baseDir}/scripts/delivery_gate.py --build-state /path/to/build-state.json
```

## Era and character architecture

World Mode supports one locked timeframe or an approved multi-era picker. For multi-era builds, read `era-system.md`, propose and confirm era boundaries after discovery, write `artifacts/era-plan.json`, and use World Invariants + one executable Era Context per era + filtered state entries. Scenario remains the user's settings page and Creator Notes supplies exact `Era: ...` phrases.

Every character inside the embedded lorebook follows `character-template.md` and `character-identity-system.md`. Bind all generated character UIDs through `character-plan.json`; meaningful changes in life status, role, allegiance, location, relationships, knowledge, form, capabilities, or goals create separate era-state entries. The world card itself remains setting-first and has no star character.

For multi-era builds, the era router owns exact Scenario phrases, boundaries, world state, active-entity graph seeds, past/future events, knowledge restrictions, state assertions, and prohibited state terms. Exactly one era line may be active in Scenario.

Before release, read `full-integration-acceptance.md`; require the frozen route-specific integration plan and current receipts, skipping only systems marked not applicable.
