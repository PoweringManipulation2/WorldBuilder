# Runtime Target Adapter

## Contract

`worldbuilder-runtime-target-adapter-v2` freezes one `worldbuilder-semantic-ir` representation and makes the parent agent, not generation workers, the authority that spells target fields. IR v2 owns card fields, lorebook metadata and entries, activation, recursion, placement, budget flags, dynamic operations, assets, provenance, and preserved unknown extensions.

Run `scripts/runtime_target_adapter.py` only after corrected post-audit bytes exist. Every export:

1. imports sparse optional metadata without inventing defaults;
2. separates portable interchange from a named application profile;
3. writes application-specific CCv3 data only under `extensions` or to native World Info fields;
4. passes the emitted target through its target validator and the SillyTavern import probe when applicable;
5. reopens strict UTF-8 bytes or `card.json` inside CHARX;
6. compares the represented semantic projection with the source IR; and
7. records source, IR, target, report, approval, and output hashes in a receipt.

Delivery blocks stale, unsupported, unapproved-lossy, invalid, or semantically drifting receipts. An explicitly approved lossy receipt may pass, but it remains marked `lossy: true` and `lossy_approved: true` in delivery lineage and reports.

## Supported target families

- **Schema 1 Character** - CCv3 without lore; dropping an existing lorebook requires explicit loss approval.
- **CCv3 embedded** - CCv3 with `data.character_book`; directly importable as a character card when emitted with the named SillyTavern profile.
- **Standalone `lorebook_v3`** - portable CCv3 lorebook interchange. SillyTavern 1.18.0 does not consume this wrapper as a direct World Info import.
- **SillyTavern native** - direct World Info import shape with top-level `entries`; explicit conversion emits a UID-keyed object while preserve-mode updates retain the imported container style.
- **CHARX** - reopened CCv3 `card.json` plus explicitly mapped embedded assets.
- **Group set** - Schema 1 cards plus one shared lorebook. The named SillyTavern profile emits the shared lorebook as native World Info.
- **Persona with optional lorebook** - UTF-8 persona text plus an optional native World Info lorebook for the named SillyTavern profile.
- **Preserve** - detect and retain the supplied format, then validate the detected target rather than the literal word `preserve`.

## Direct-import boundary

Treat `JSON accepted` and `settings active` as different claims.

| Output | SillyTavern 1.18 direct route | Setting behavior |
|---|---|---|
| CCv3 card with embedded `character_book` | Character import | `convertCharacterBook` maps its tested core and extension fields |
| Native World Info with top-level `entries` | World Info import | Native fields are active; explicit conversion uses UID-keyed entries |
| Standalone `lorebook_v3` wrapper | No direct World Info route | Portable/spec-valid only; convert before import |
| Portable CCv3 neutral envelopes | May remain valid JSON | `worldbuilder_dynamic` and `worldbuilder_runtime` are preservation data, not SillyTavern runtime settings |

Simple Mode intentionally defaults to a portable, mode-appropriate target. Select the named `sillytavern-1.18.0` profile and a direct-import target when active SillyTavern behavior is the user's goal. Portability and runtime compatibility remain separate choices.

## Compatibility and preservation

Portable CCv3 keeps neutral `worldbuilder_dynamic` and `worldbuilder_runtime` envelopes under entry extensions. The named SillyTavern profile mirrors only source-verified runtime fields into the exact embedded extension or native locations. Unknown wrapper, card, book, and entry fields are relocated to preservation envelopes rather than leaked into undeclared CCv3 keys.

Probability value and enablement are separate semantics. Extended insertion position, vectorization, recursion prevention/exclusion, delayed-recursion level, depth, role, entry scan depth, matching controls, and ignore-budget behavior are first-class runtime semantics.

Important target limits:

- CCv3 `use_regex` is not read by SillyTavern's embedded-book converter. For the named profile, the adapter converts primary patterns to SillyTavern slash-delimited JavaScript-regex key strings and preserves the original CCv3 fields in `extensions.worldbuilder_sillytavern_regex`. Because CCv3 regex mode ignores `secondary_keys` and `constant`, the runtime projection clears those activation paths while retaining them for round-trip recovery.
- Embedded `extensions.character_filter` is preserved but is not activated by `convertCharacterBook`. The adapter fails closed for an active embedded filter unless neutral-only preservation is explicitly approved. Native output maps it to active `characterFilter`.
- Lorebook-level `scan_depth`, `token_budget`, and `recursive_scanning` are portable metadata. SillyTavern 1.18.0 controls those behaviors through global World Info settings rather than per imported book.
- CCv3 entry `priority` is preserved but has no active mapping in the tested SillyTavern importer.
- Character filters require explicit maps from planning labels to runtime character/avatar filename stems and tag IDs unless imported values are already marked runtime IDs. Outlets require exact approved consumers. Greeting-specific activation remains neutral-only when the tested target has no enforceable field.

## Metadata lifecycle

Omitted optional CCv3 metadata remains omitted. Preserve imported creator, version, nickname, multilingual notes, sources, timestamps, and assets unless an explicit edit owns the change. Set `creation_date` for a newly created artifact; change `modification_date` only when releasing changed content, not when merely repackaging identical bytes.

## Commands

```text
python3 scripts/runtime_target_adapter.py import SOURCE.json semantic-ir.json
python3 scripts/runtime_target_adapter.py export SOURCE.json OUTPUT.json --target lorebook-v3
python3 scripts/runtime_target_adapter.py export SOURCE.json OUTPUT.json --target sillytavern-native --runtime-profile sillytavern-1.18.0 --character-map character-map.json --tag-map tag-map.json
python3 scripts/runtime_target_adapter.py export SOURCE.json OUTPUT.json --target ccv3-embedded --runtime-profile sillytavern-1.18.0
python3 scripts/runtime_target_adapter.py export --build-state /path/to/build-state.json
python3 scripts/runtime_target_adapter.py validate --build-state /path/to/build-state.json
python3 scripts/runtime_target_adapter.py roundtrip SOURCE.json --target sillytavern-native --runtime-profile sillytavern-1.18.0
```

Prefer build-state mode because it binds source, IR, report, output, target/profile, optional loss approval, and receipt into release lineage.

## User interface boundary

Simple Mode asks only for a readable output choice and resolves an import-ready target automatically: native World Info for standalone lorebooks and the named embedded profile for World cards. Advanced Mode may select portable `lorebook_v3`, inspect target mappings, preservation envelopes, runtime identity maps, exact losses, and round-trip results.

## Optional post-delivery runtime bundle

The normal adapter export remains the default. After delivery is permitted, an
opt-in runtime bundle can package the exact delivered/runtime-adapter bytes with
validated convenience components and `recommended_settings.json`:

```bash
python scripts/runtime_target_adapter.py bundle --build-state /absolute/path/to/build-state.json
python scripts/runtime_target_adapter.py validate-bundle --build-state /absolute/path/to/build-state.json
```

`recommended_settings.json` is recommendation-only metadata derived from the
existing frozen budget and placement plans. It is not an executable
SillyTavern settings import. A setting the build did not actually decide stays
unset instead of being guessed. Bundling must not regenerate, re-audit, reseal,
or rewrite the delivered source artifact; the bundle receipt binds identical
source hashes before and after packaging.
