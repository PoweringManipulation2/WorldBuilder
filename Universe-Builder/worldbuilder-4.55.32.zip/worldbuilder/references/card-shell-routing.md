# Card-Shell Routing
## Navigation
- [Contract](#contract)
- [World card](#world-card)
- [Character card](#character-card)
- [Group cards](#group-cards)
- [Persona](#persona)
- [Validation](#validation)
## Contract
Use `worldbuilder-card-shell-v1` for every new build. The card shell is a deliberately small delivery surface around the character or world engine. Freeze the user's choices in `artifacts/card-shell-plan.json` before manifest approval, bind the manifest to that file by SHA-256, and run the architecture gate at planning and output.

The plan defines every supported prose, runtime, metadata, provenance, timestamp, and asset field even when the correct value is blank or omitted. Blank is a deliberate prose route; omitted optional metadata is preserved as omission rather than invented.
## World card
A thin shell still carries a compact fallback behavior kernel in System Prompt and/or Post-History Instructions unless both fields were explicitly disabled. The kernel states the world-simulation role, handles unknown starting state without inventing contradictory canon, and directs retrieval or clarification when lore is absent. It is not an encyclopedia and must remain within the plan-owned compact range.

| Field | Route |
|---|---|
| `name` | World or setting identity |
| `description` | Compact world core, scope, atmosphere, themes, and optional Soul Extractor prose guidance |
| `personality` | Blank; a world is not a character persona |
| `scenario` | Blank user-controlled settings page unless a fixed premise was explicitly approved |
| `first_mes` | Open, guided, or approved fixed entrance into the world |
| `alternate_greetings` | Optional alternate locations, eras, or entry situations |
| `mes_example` | Blank by default; use only for an explicitly designed world-response demonstration |
| `creator_notes` | Human prose (usage, custom-history examples, format notes) plus the generated block from `creator_notes_stats.py`. The block owns attribution, lorebook version and scheme, entry and era stats, recommended SillyTavern settings, format compatibility, the verification procedure, and deferred scope. It is delimited and upserted, so regenerating replaces rather than appends. Under `root_toggle` routing name the era roots to toggle; exact `Era: ...` Scenario phrases apply only to legacy `scenario` routing. |
| `system_prompt` | Stable world-simulation behavior only |
| `post_history_instructions` | Short high-priority simulation or user-autonomy constraints only |

The embedded lorebook remains the world engine. Do not move encyclopedic lore into Description or Scenario.
## Character card
| Field | Route |
|---|---|
| `name` | Character identity |
| `description` | `TIMELINE`, `VITALS`, `CONNECTIONS`, `APPEARANCE`, `BACKSTORY`, `CURRENT`, optional `EXTRA` |
| `personality` | `PERSONALITY & VOICE` prose only, without the heading |
| `scenario` | Blank and reusable unless a fixed premise was explicitly approved |
| `first_mes` | Playable opening scene demonstrating voice and behavior |
| `alternate_greetings` | Optional alternate meetings, moods, eras, or relationship contexts |
| `mes_example` | Voice and behavior demonstrations separated with `<START>` |
| `creator_notes` | Human prose (usage, timeframe, variants, source stance) plus the generated block from `creator_notes_stats.py` when a lorebook is embedded. See the World row for what the block owns. |
| `system_prompt` | Stable character-role behavior only |
| `post_history_instructions` | Short high-priority behavior constraints only |

Do not duplicate Personality prose in Description. Greetings establish mutable scenes and must not be treated as permanent biography.
## Metadata, provenance, and assets
These fields are owned even though most are not prose-generation surfaces:

| Field | Ownership and lifecycle |
|---|---|
| `group_only_greetings` | Author only for Group Chat openings that must not appear in solo chat. Keep separate from `first_mes` and `alternate_greetings`. |
| `tags` | Preserve user tags; normalize only whitespace/casing duplicates; add discovery tags only when supported by the source or requested. |
| `creator` | Preserve attribution. Set only from explicit user/project identity; never infer a legal name. |
| `character_version` | Preserve on import. Increment only for an intentional release, using the scheme in `creator_notes_stats.py`: MAJOR for architecture, format, or era-routing changes and removed entries; MINOR for added content; PATCH for corrections and repairs. New artifacts start at 1.0.0. Record the change in the generated block. |
| `nickname` | Optional runtime display name. Explain that it may affect `{{char}}` substitution; preserve unless the user requests a change. |
| `creator_notes_multilingual` | Object keyed by lowercase ISO 639-1 language codes. Preserve existing translations; generate translations only on request. |
| `source` | Append-only provenance IDs or HTTP(S) URLs. Preserve user sources; do not remove them during conversion or pruning. |
| `creation_date` | Non-negative Unix seconds. Preserve an imported value; set only when creating a new artifact. |
| `modification_date` | Non-negative Unix seconds. Update only when releasing changed content, not merely repackaging identical bytes. |
| `assets` | Preserve valid descriptors and embedded URIs. Validate type, URI, name, extension, main icon/background cardinality, and CHARX member mapping. |

Optional metadata must remain omitted when no valid value exists. Never fill an absent object, timestamp, source, or asset field with a placeholder of the wrong type.
## Other modes
- **Standalone Lorebook:** no card-shell questions or synthetic card fields.
- **Group Chat:** plan shared versus character-specific openings; each member card still follows Character routing.
- **Persona:** use the persona text architecture; no synthetic card shell unless the user explicitly requests a card conversion.
- **Character set:** use one independent card-shell plan per era child. `era-specific` greetings are the default.
- **Convert/Audit:** preserve supplied field content unless conversion or repair explicitly changes it; report every lossy move.
## Opening choices
### World
- `open`: blank Scenario, neutral first message, no forced role.
- `guided`: blank Scenario, first message suggests a place or situation without fixing identity.
- `fixed`: exact approved Scenario text and matching opening premise.

### Character

- `open`: reusable blank Scenario.
- `guided`: greeting establishes a scene while Scenario remains blank.
- `fixed`: exact approved Scenario text.

### Greetings

- `single`: only `first_mes`; alternate list may be empty.
- `varied`: at least one useful alternate greeting.
- `custom`: follow the requested opening categories.
- `era-specific`: one or more openings appropriate to distinct era cards.
- `shared-style`: same basic opening concept adapted across a card set.

## Dialogue choices

- `recommended`: Character cards require useful examples and `<START>` delimiters.
- `none`: `mes_example` must be blank.
- `custom`: examples must satisfy the requested situations and still use `<START>`.

World and Lorebook builds default to `none`. Character builds default to `recommended`.

## Prompt-field policies

In SillyTavern, card `system_prompt` and `post_history_instructions` are applied only when the corresponding **Prefer Character Prompt** and **Prefer Character Instructions** settings are enabled. When replacing rather than discarding the configured global prompt, include `{{original}}` at the intended insertion point. Document these runtime prerequisites in Creator Notes or the delivery README when either field is populated.

`automatic` does not mean “always populate.” It means use the field only when its prompt position is the correct home for stable behavior.

- `none`: field must be blank.
- `automatic`: may be blank or concise.
- `custom`: must contain the approved custom behavior.

Creator Notes are human-facing. Never rely on them as the only location for required model behavior. Because they never enter the prompt, they never count toward the permanent card token budget either; see `context-budget-pruning.md`.

## Shell slot priority

The shell is the fallback that must hold when retrieval misses. When it must shrink to fit `permanent_card_hard` (a share of the declared context window, by artifact shape; see `context-budget-pruning.md`), it shrinks in a fixed order, never arbitrarily. `card_shell_contract.py`'s `SLOT_PRIORITY` resolves this against each plan's own routing, so the order below is always checked against what is actually active, not assumed:

1. **Identity kernel** (`name`, `description`, `personality`): never cut. Who this is, stated plainly; the shell's entire reason to exist.
2. **Interaction contract** (`system_prompt`, `post_history_instructions`): never cut. The stable behavioral contract: role, boundaries, constraints.
3. **Voice sample** (`mes_example`): cut last. Demonstrated voice and behavior, not just facts about the character.
4. **Situation anchor** (`scenario`): cuttable if a constant lorebook root or Scenario itself already covers the same premise.
5. **Appearance and details**: first to move into the lorebook. Physical description and flavor beyond identity, drawn from within `description`'s own prose rather than a separate field.

Slots 1 and 5 both draw on `description`, which carries both kinds of content. Distinguishing an identity fact from a flavor detail within one field's own prose is a content judgment for whoever writes it. This table resolves at the field level; it does not split a paragraph for you.

## Validation

The card-shell gate checks:

1. Manifest and plan lineage.
2. Every field route exists exactly once.
3. Required Name, Description, First Message, Personality, and Creator Notes by mode.
4. World Personality is blank.
5. Scenario follows the approved blank/fixed policy exactly.
6. Greeting count follows the selected policy.
7. Dialogue examples follow the selected policy and delimiter format.
8. `none` prompt policies remain blank.
9. Description and Personality do not duplicate substantial prose.
10. World Description does not contain character-template sections.
11. Permanent prompt fields remain below the hard pressure limit; soft pressure is reported in the receipt.

## Generation contract

Before drafting the shell, the generation parent and relevant worker must read:

- `artifacts/card-shell-plan.json`
- the manifest architecture block;
- `character-template.md` for Character cards;
- `world-mode.md` for World cards;
- the approved era plan when present.

Generate the lorebook and character state first. Draft greetings and examples only after the stable identity/state content exists. Validate the final serialized output again after merge.

Creator Notes are primarily for humans. Put model-critical runtime behavior in an enabled World Info entry or another prompt-visible field; never hide the only operational rule in metadata.
