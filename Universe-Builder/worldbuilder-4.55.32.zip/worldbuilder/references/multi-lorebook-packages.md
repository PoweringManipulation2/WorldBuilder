# Multi-lorebook packages

Single-artifact output remains the portable default. An explicitly selected optimized package may split one discovered source plan into several cooperating books.

`package_plan.py` owns the parent `package-plan.json` and `package-dependencies.json`. Each decided book is materialized as an **independent WorldBuilder build** with its own `build-state.json`, manifest, seal, and unchanged pipeline-stage ledger. Cross-book references live only in the parent dependency registry; never teach `pipeline_stage_gate.py` about multiple manifests inside one build.

Validate dependencies before delivery. A dependency names the target book and stable UID (plus expected name when useful); removal/rename must report a broken dependency.
