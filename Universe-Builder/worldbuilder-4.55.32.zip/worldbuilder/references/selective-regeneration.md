# Selective regeneration

Use selective regeneration when the user asks to rewrite only specific UIDs, a manifest layer/category, everything supported by one source locator, or to increase detail for a named UID set.

1. Run `selective_regeneration.py plan`. The resolver produces an exact UID set, reports every author-locked exclusion, and computes activation neighbours for the later scoped audit.
2. Regenerate **only** `resolved_uids` through the existing generation contract. Normal scopes repeat research → evidence gate → write/checkpoint. `--detail-uid` scopes are write-only because the facts are intentionally unchanged.
3. Assemble a JSON payload containing exactly the regenerated UIDs and run `selective_regeneration.py apply`. It replaces only those entries in the frozen baseline and mechanically proves every other entry hash stayed identical.
4. Run `audit_plan.py --scope changed --change-set <plan change-set>` and continue through the ordinary audit, validation, runtime-target, integration, and delivery gates. Neighbours are audited, not regenerated unless independently selected.

A lock exclusion is never silent. If a requested UID is locked, report its name/reason and leave it unchanged. If every requested UID is locked, block the operation.
