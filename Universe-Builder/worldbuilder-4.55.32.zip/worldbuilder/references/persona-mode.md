# Persona Mode
## Navigation

- [Output contract](#output-contract)
- [Simple mode](#simple-mode)
- [Split mode](#split-mode)
- [Placement and control](#placement-and-control)
- [Validation](#validation)
## Output contract

The persona description is plain UTF-8 `.txt`. Do not wrap it in JSON. SillyTavern users paste/select persona text through persona management.

An optional deep-lore file is a separate Schema 3 lorebook and follows the full lorebook audit path.
## Simple mode

Use one text description when the persona has modest stable information. Include the details the user wants always available: identity, appearance, voice, behavior, capabilities/limits, and default situation.

Do not invent missing personal details. Ask targeted questions only when an omission prevents the requested result.
## Split mode

Use a lean core text plus separate lorebook for extensive backstory, NPCs, factions, items, or episodic history.

WorldBuilder's default split-core profile warns at 280 words and blocks above 300 words. This is a token-cost profile, not a SillyTavern import rule; the thresholds are configurable in `validate_persona.py`.
## Placement and control

Persona placement is user-configurable in SillyTavern. Do not assume one fixed prompt position.

WorldBuilder recommends an explicit line such as:

> The AI may describe visible reactions but must not decide `{{user}}`'s actions, choices, feelings, or internal thoughts.

This is editorial guidance and is warning-only unless the user makes it a hard requirement.
## Validation

```bash
python3 {baseDir}/scripts/validate_persona.py persona.txt --mode simple
python3 {baseDir}/scripts/delivery_gate.py persona.txt --artifact-type persona
```

For split mode, validate and release the persona text separately, then run the full Schema 3 pipeline for its lorebook.

## Setup pagination and shell applicability

Persona setup participates in the paged settings flow but uses only the named `compact`, `detailed`, or `custom` persona-detail choice. A plain-text Persona has no synthetic card shell; `card-shell-plan.json` records `persona-text` applicability so card fields are not fabricated.

Before release, read `full-integration-acceptance.md`; require the frozen route-specific integration plan and current receipts, skipping only systems marked not applicable.
