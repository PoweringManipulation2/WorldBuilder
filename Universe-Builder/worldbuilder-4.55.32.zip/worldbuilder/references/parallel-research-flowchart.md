# Additive Wiki Sweep - Flowchart

```text
LOCKED SETTINGS
      |
      v
SearXNG + WARP preflight
      |
      v
PARENT SOURCE PROBE
  + MediaWiki statistics
  + AllPages and redirects
  + AllLinks
  + Special:AllPages strata
  + robots and recursive sitemaps
  + categories and subcategories
  + SearXNG site harvest
  + internal links and bounded BFS
  + random/category verification seeds
      |
      v
ADDITIVE CANONICAL UNION
  preserve provenance, aliases, failures,
  lower bounds, and source-family overlap
      |
      v
COST-BALANCED BIRD ASSIGNMENTS
  Raven | Magpie | Wren | Finch | ...
  exact URL ownership + exact output paths
      |
      v
sessions_spawn wave 1: up to 4 birds
      |
validate fetch methods, URL ownership, and runtime receipts
      |
sessions_spawn wave 2: up to 10 birds
      |
validate again
      |
sessions_spawn later waves: up to 20 birds
      |
      v
PARENT-OBSERVED RUNTIME RECEIPTS
      |
      v
DISCOVERY GATE
  - exact ownership coverage
  - no cross-worker claims
  - independent lower-bound check
  - source-family reconciliation
  - random/category verification rounds
  - marginal URL/entity yield
  - saturation diagnostic
      |
      +---------------- incomplete ----------------+
      |                                             |
      v                                             |
TARGETED RECOVERY PLAN                              |
  failed URLs, uncovered lower bound,               |
  new orphan URLs, extra verification               |
      |                                             |
      +------------ spawn recovery birds -----------+
      |
      v
PASSED DISCOVERY RECEIPT + INDEX
      |
      v
BUILD LIST + RECURSION MAP + MANIFEST
      |
      v
PER-UID DEEP RESEARCH BEFORE WRITING
```

A fresh sitemap is one additive channel, never the exclusive authority. Worker completion proves work on assigned URLs; independent bounded-coverage and saturation checks show whether the assignment corpus was broad enough.
## Runtime-failure branch

```text
canary wave
→ validate path access + contract + fetch records
   ├─ healthy → unlock next ramp wave
   ├─ isolated network/URL failure → targeted recovery
   └─ 2 matching path/contract/output failures → circuit breaker
        → abandon affected run IDs
        → repair shared cause
        → use truthful exec/workdir fallback when needed
        → repeat canary
```

Recovery plans append assignments and preserve every prior assignment hash.
