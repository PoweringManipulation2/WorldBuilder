# SillyTavern Plugins

Not to be confused with `card-extensions-field.md`, which governs the CCv3 `extensions` JSON namespace. This file is about SillyTavern extensions/plugins.

## Detection

Settings option `[7] 🧩 SILLYTAVERN EXTENSIONS` accepts `[none]`, `[choose]`, or `[detect]`. `[detect]` runs `python3 {baseDir}/scripts/sillytavern_install.py extensions --root <confirmed root>` and reports only presence on disk (`user` or `bundled`), never enablement. If no install is found, degrade to `[choose]`.

## Produced surfaces

WorldBuilder emits artifacts/descriptors; it does not install, enable, or write into a SillyTavern installation.

| Area | Status | Produced |
|---|---|---|
| Expressions | supported | prompt set + `emotion` asset descriptors |
| Vector Storage | supported | vector eligibility; item 7 can emit source-pinned marker/settings recommendations |
| Quick Replies | supported, source-pinned | Quick Reply Set v2 JSON |
| Regex | supported, source-pinned | `RegexScriptData` / character extension fragment |
| Timed Effects | supported, source-pinned | World Info field fragment |
| MVU | supported, third-party source-pinned | `[InitVar]` World Info entry |
| EJS | supported, third-party source-pinned | template text / World Info entry |
| Trackers | declined | runtime-session state, not artifact configuration |

## Expressions

`expression_assets.py` bridges Image Prompts and CCv3 `assets`. Descriptor structure is spec-level and validated. **Blocked on runtime evidence:** the default emotion label set remains implementation-level and unverified. Replace it with `--labels` or a real-install fixture when available. WorldBuilder generates images through the host image tool, but extension detection/configuration remains separate.

## Source-pinned extension assets

Read `extension-adapters.md`. Batch 23 item 7 verifies each supported serializer against current source instead of guessing. The common WorldBuilder envelope is internal only. Quick Replies/Regex use current SillyTavern release shapes; Vector Storage/Timed Effects reuse current World Info semantics; MVU/EJS target documented third-party World Info/template conventions.

The adapter never installs or enables extensions. Vector Storage global settings are recommendation-only. Item 7 does not synthesize automation IDs or outlets. MVU/EJS runtime behavior still requires those extensions to be installed and enabled.

## Declined scope

**Deliberately not supported:** Trackers accumulate live location/time/world state during a chat. This is a scope decision, not an oversight. WorldBuilder's dynamic-state layer governs what an artifact declares, not mutable session state. Revisit only if a tracker format becomes an artifact-level contract that can be source-verified and tested.
