# WorldBuilder Design Decisions — Compact Release Contract
## Navigation
- All 130 decision records, DR-001 through DR-130, in order.
- Release copy keeps only each record's class, binding decision, and regression boundary; historical rationale and amendment narrative are development-only.
## DR-001: World Mode is setting-first
**Class:** Product default
**Decision:** World Mode has no mandatory central character, fixed point of view, narrator shell, or predefined user identity.
**What would be a regression:** Asking who owns the card, choosing a protagonist whose POV controls the lorebook, speaking as an invented chronicler, or forcing a user role.
## DR-002: The World card shell is intentionally thin
**Class:** Product default
**Decision:** Description stays brief and setting-level; the embedded lorebook carries most substantive knowledge and behavior.
**What would be a regression:** Moving the cast encyclopedia, chronology, faction rules, or world systems into always-on card fields because the shell appears “too sparse.”
## DR-003: Scenario is blank by default in World Mode
**Class:** Product default
**Decision:** The Scenario field is intentionally left blank unless the user asks for a template. It functions as the user's settings page for era, starting location, identity, custom history, canon changes, relationships, and special conditions.
**What would be a regression:** Treating a blank Scenario as missing content, filling it with a canon scene, or assigning a mandatory relationship or plot.
## DR-004: Metadata is a human-facing usage guide
**Class:** Product default
**Decision:** Metadata or creator notes contain era guidance, exact scenario trigger phrases, custom-history examples, additional usage notes, attribution, the configured WorldBuilder/GitHub link, and, whenever the artifact embeds a lorebook, the generated lorebook stats & recommended context settings block (`creator_notes_stats.py`), enforced at the output gate.
**What would be a regression:** Removing the guide as “nonessential metadata,” hiding trigger phrases only in internal documentation, placing model-critical runtime behavior only in human-facing notes, or shipping a lorebook-bearing card whose Creator Notes lack or contradict the generated stats block.
## DR-005: Discovery and generation are separate research layers
**Class:** Invariant
**Decision:** Breadth discovery determines what exists and belongs in scope; per-UID research determines what is true before writing.
**What would be a regression:** Starting generation from a few obvious pages, treating discovery snippets as sufficient evidence, or skipping per-UID research because the corpus was already crawled.
## DR-006: Collection is additive and bounded
**Class:** Invariant
**Decision:** Collection claims are bounded to an explicitly enumerated source set, namespaces/categories, source families, date, and exclusions.
**What would be a regression:** Claiming the whole web or an evolving wiki is complete; hiding exclusions; or reporting saturation without the enumerated scope.
## DR-007: Fandom retrieval is API-first
**Class:** Target-specific policy
**Decision:** For Fandom/MediaWiki, prefer documented API representations such as `action=parse` and revision wikitext before decorative article HTML.
**What would be a regression:** Treating normal article HTML as the only valid source, marking a page failed before API transports are tried, or claiming the API guarantees bypassing protections.
## DR-008: Worker concurrency ramps 4 → 10 → 20
**Class:** Heuristic
**Decision:** Discovery uses health-gated waves with tested defaults of 4, then 10, then the configured runtime cap (normally 20). The actual schedule may be tuned before dispatch and is recorded.
**What would be a regression:** Treating 4 → 10 → 20 as a compatibility law; increasing concurrency without health evidence; or failing to record the actual waves.
## DR-009: Exact ownership and targeted recovery
**Class:** Invariant
**Decision:** Each worker owns exact URLs or UIDs. Successful outputs remain valid, and interrupted work is recovered only for missing, failed, or invalid assignments.
**What would be a regression:** Accepting unaccounted items, allowing cross-worker claims without delegation, or discarding completed phases because one sibling failed.
## DR-010: Config is frozen per build
**Class:** Invariant
**Decision:** Global main-agent and subagent model settings resolve into an immutable `effective-config.json` when a build starts.
**What would be a regression:** Silently changing the model for later phases of an active build after a global config edit.
## DR-011: Four audit lenses remain distinct
**Class:** Invariant
**Decision:** Compass, Weaver, Scout, and Warden remain four distinct audit lenses with separate assignments, expected checks, results, and proof. Execution topology may be independent (default) or consolidated.
**What would be a regression:** Dropping a lens, merging check sets into one undifferentiated report, or treating one summary as four proofs.
## DR-012: Quick mode does not weaken collection correctness
**Class:** Product default
**Decision:** Quick mode may reduce generated scope and detail, but it must not manufacture completeness by shrinking or skipping the discovery standard without disclosure.
**What would be a regression:** Calling a shallow sample exhaustive or bypassing omission checks while still reporting full coverage.
## DR-013: Worker paths are absolute and dispatch is backend-neutral
**Class:** Target-specific policy
**Decision:** Worker task cards carry authoritative paths and dispatch remains backend-neutral; use absolute host paths only where the selected OpenClaw execution backend requires them.
**What would be a regression:** Hard-coding installation paths in portable worker kits, or assuming `cwd` alone proves visibility.
## DR-014: Discovery plans are immutable after materialization
**Class:** Invariant
**Decision:** Materialized plans are immutable snapshots. A correction creates a successor snapshot, normally a new build, or a numbered in-build revision only where that planner explicitly supports revision lineage, and invalidates only affected downstream artifacts.
**What would be a regression:** Mutating a completed snapshot in place, silently reusing stale descendants, or claiming generic in-build revision support where none exists.
## DR-015: Generation batches are capped at 15 entries
**Class:** Heuristic
**Decision:** Generation batches default to a maximum of 15 entries and may be configured from 1 to 50 before build start. `gate_telemetry.py partition` derives an effective size per batch from dependency density: isolated entries use the full configured size, lightly linked entries two thirds, densely linked entries two fifths, and hub clusters one fifth, with a floor of one. When validated per-UID evidence already exists on a resumed/rework path, low confidence or an unresolved conflict may conservatively shrink the same density-derived batch; the initial generation pass remains density-only because its evidence cannot exist yet. Runtime health and user budget remain parent judgement rather than invented pre-generation inputs.
**What would be a regression:** Treating 15 as a schema rule, exceeding the frozen configured ceiling, or ignoring tightly linked entries when partitioning.
## DR-016: Generation interleaves research and writing per entry
**Class:** Invariant
**Decision:** Within every 1-50 entry generation assignment, process UIDs strictly in assignment order: research one UID, validate its evidence, write and validate its single-entry checkpoint, then begin the next UID.
## DR-017: Absolute worker paths are a compatibility boundary
**Class:** Target-specific policy
**Decision:** Absolute paths are an OpenClaw host/worker compatibility boundary, not a portable artifact format. Build-state paths remain authoritative and worker-kit references remain relative when staged inside the workspace.
**What would be a regression:** Persisting desktop or installation paths into portable prompts, manifests, cards, or lorebooks.
## DR-018: Exec fallback receipts are legitimate but distinct
**Class:** Temporary compatibility policy
**Decision:** Parent-observed `exec` with an explicit work directory may satisfy worker execution when `sessions_spawn` is unhealthy, but its receipt must truthfully identify the exec backend.
## DR-019: Recovery appends instead of rebasing lineage
**Class:** Invariant
**Decision:** Recovery and delta probes append assignments and accounting records to the frozen plan rather than regenerating prior assignments.
## DR-020: Low-value exclusions remain explicit accounting
**Class:** Invariant
**Decision:** Junk, broken, and intentionally out-of-scope URLs receive registered reason codes and remain visible in completeness metrics.
## DR-021: Entity identity is independent of taxonomy and order
**Class:** Invariant
**Decision:** Stable entity identity survives reordering, alias additions, and corrections such as `character` to `species`.
## DR-022: Worker results commit atomically
**Class:** Invariant
**Decision:** Workers write candidates; a deterministic helper validates and atomically commits the final result.
## DR-023: Shared failures trigger a circuit breaker
**Class:** Invariant
**Decision:** Repeated path, contract, or output-format failures stop wave expansion until the shared cause is repaired.
## DR-024: Broad collection and expensive extraction are separate
**Class:** Heuristic
**Decision:** Collect URLs additively for recall, then use deterministic metadata and post-fetch classification before allocating model context. Pages become `content`, `index_only`, `reference_only`, `alias_only`, or `excluded`.
## DR-025: Multi-era is a retrieval architecture, not a keyword decoration
**Class:** Invariant
**Decision:** A multi-era build requires an approved era plan, one World Invariants root, one Era Context per era, Scenario matching, selective era-state entries, temporal event reach, and an explicit negative-state boundary (DR-038).
## DR-026: Character content uses one canonical format
**Class:** Product default
**Decision:** Lorebook characters use TIMELINE, VITALS, PERSONALITY & VOICE, CONNECTIONS, APPEARANCE, BACKSTORY, CURRENT, and optional EXTRA in that order. Schema 1 stars route PERSONALITY & VOICE into `personality` and the remaining sections into `description`.
## DR-027: Era boundaries require explicit user confirmation
**Class:** Product default
**Decision:** For multi-era lorebooks and Character card sets, WorldBuilder proposes era boundaries after source synthesis and pauses for user confirmation before manifest creation.
## DR-028: Persistent interface mode without double menus
**Class:** Product default
**Decision:** Store `interface.mode` in the user-owned workspace config. Simple Mode shows one compact named-choice menu. Advanced Mode shows one comprehensive menu containing both ordinary and expert choices; it never follows the Simple menu as a second page.
## DR-029: The manifest owns activation; the map is a validated projection
**Class:** Invariant
**Decision:** Store every entry strategy, recursion role, emitted/forbidden trigger term, and recursion edge in `manifest.json`. Render `recursion-map.md` from that authority and reject any semantic mismatch.
## DR-030: Defaults stay sparse, but worker graph context is explicit
**Class:** Invariant
**Decision:** Freeze a field registry and build/layer default profile. Blank optional map fields inherit from that profile. Generation assignments embed an exact hash-bound map slice with required and forbidden emitted terms, incoming/outgoing edges, neighbors, and special overrides.
## DR-031: Settings are paged and resumable
**Class:** Product default
**Decision:** Show no more than ten numbered setting blocks per page, save each submitted page in the user-owned workspace, and use one unified Advanced flow rather than a Simple-then-Advanced funnel.
## DR-032: Card fields have mode-specific owners
**Class:** Product default
**Decision:** Freeze a card-shell plan that assigns every supported card field to a mode-specific purpose. World Personality remains blank; Character Personality owns only voice/behavior; Scenario remains blank unless exact fixed text was approved, or it is deliberately used as the user-controlled settings page for era, location, identity/self-insert, custom history, canon changes, relationships, or special conditions per DR-003; greetings and examples remain mutable scene demonstrations rather than permanent biography.
## DR-033: Character identity and state are planned before prose
**Class:** Invariant
**Decision:** Whenever generated character entries exist, freeze one `character-plan.json` that separates stable identity/behavior from state-specific facts and binds every generated character UID to exactly one `character_id` and `character_state_id`.
## DR-034: Split characters only for meaningful contradiction boundaries
**Class:** Product default
**Decision:** Create separate character states when life status, role, rank, allegiance, location, relationships, knowledge, physical form, capabilities, goals, reputation, or equipment changes enough that one active entry would contradict the selected timeframe. Record the exact reasons. Do not duplicate a character merely because multiple eras exist.
## DR-035: Relationships are directed, stateful, and knowledge-aware
**Class:** Invariant
**Decision:** Model each relationship from a source character/state toward a target, with era, public state, private state, what each side knows, behavioral consequences, and any activation trigger. Do not infer symmetry unless the reverse direction is separately planned.
## DR-036: Era selection is an explicit router
**Class:** Invariant
Multi-era builds use one canonical `Era: ...` Scenario phrase per era. Multiple matched eras fail instead of being resolved heuristically. This prevents stale Scenario text from activating contradictory contexts.
## DR-037: Era Contexts are executable graph seeds
**Class:** Invariant
Active-character, faction, and location lists are not decorative summaries. Their canonical names must be declared emitted terms and backed by activation edges to same-era entries.
## DR-038: Negative state is a boundary, not an enumeration
**Class:** Invariant
**Decision:** An era states what it does not contain as a **boundary** ("Nothing after the Siege has occurred") and never as a list of the specific things that have not happened yet. Absence rosters remain, and remain required: an entity that existed earlier and is now gone is legitimate in-era memory, so `ABSENT THIS ERA:` keeps the name and drops any causal clause that names a later or unknown event. Knowledge restrictions, state assertions, prohibited state terms, and per-state required/forbidden terms are unchanged; auditors must still not blend them into one chronology. `era_root_contract.FUTURE_ENUMERATION_RE` rejects a `WHAT HAS NOT HAPPENED YET`-style block in a `root_toggle` era root. Legacy `scenario` routing is unchanged.
**What would be a regression:** Re-introducing an enumerated future block under any heading; an absence roster whose reason clause names an event the era cannot reach; treating a boundary line as optional on a multi-era root; or extending the enumeration ban to absence rosters, which are in-era memory rather than a leak.
## DR-039: Placement is purpose-based and frozen before generation
**Class:** Invariant
**Decision:** Every lorebook-bearing build freezes `placement-plan.json` under `worldbuilder-placement-influence-v1`. World Core, World Invariants, Era Contexts, characters, relationships, scene reminders, corrections, examples, and outlet modules receive placement from their semantic purpose rather than from ad hoc importance judgments.
## DR-040: Sparse placement defaults resolve to explicit worker context
**Class:** Invariant
**Decision:** Keep default placement fields blank in the readable map and manifest when they inherit from the frozen profile, but resolve every assigned UID to an explicit position, order, priority, depth, role, outlet, purpose, influence class, and target mapping in its generation assignment.
## DR-041: Extended placement requires an honest runtime mapping
**Class:** Target-specific policy
**Decision:** Treat `before_char` and `after_char` as portable core placement. Author's Note, example-message positions, at-depth insertion, and named outlets are semantic WorldBuilder positions that require a tested SillyTavern-native or extension mapping. Mark them `extension_mapped`; block unsupported targets and never serialize them as if CCv3 core guaranteed them.
## DR-042: Coverage and active-context pressure are separate
**Class:** Invariant
Collect and plan the complete supported inventory before optimizing context. Compact profiles may shorten entries and reduce simultaneous activation, but they must not weaken source discovery, era isolation, identity/state coverage, required relationships, or required activation paths. This prevents a smaller artifact from being misreported as a more complete or better-budgeted artifact.
## DR-043: Budgets are frozen, simulated, and enforced at multiple stages
**Class:** Heuristic
**Decision:** Freeze one `worldbuilder-budget-pruning-v1` policy per build. Prefer an approved target-model or frontend measurement, then a declared estimate, and otherwise use deterministic `ceil(UTF-8 bytes / 4)` fallback with explicit uncertainty. Run seven mandatory baseline simulations plus declared target-, era-, or project-specific scenarios. Pass exact UID budgets to workers, check checkpoints, and repeat validation against final bytes.
**What would be a regression:** Advertising bytes/4 as exact, blocking measured-safe output because a fallback estimate is larger, omitting the count source, replacing baseline simulations, silently truncating content, or any consumer gate blocking a measured-safe row on its recorded `hard_limit` while the plan's `context_window_mode` is `auto`.
## DR-044: Pruning is a receipt-bound change operation
**Class:** Invariant
Pruning must compare explicit before/after artifacts and record affected UIDs, reasons, activation and era impacts, hashes, token deltas, and keyword deltas. Preserve stable IDs and unrelated settings. World invariants, era isolation, knowledge boundaries, status changes, identity states, required relationships, and required activation paths are never removed automatically. Protected removals require explicit human approval and auditor review.
## DR-045: Dynamic behavior is opt-in and purpose-bound
**Class:** Invariant
Keep deterministic world content at probability 100 with no timed effects, random groups, automation, or outlets. Every non-default operation requires an approved purpose in the frozen dynamic-state plan. Protected control, era, identity, knowledge, relationship, and required activation entries cannot be randomized, delayed, filtered, or hidden.
## DR-046: Workers emit neutral semantics, not guessed runtime keys
**Class:** Invariant
Generation workers receive an exact UID-scoped dynamic context and may emit only the canonical `extensions.worldbuilder_dynamic` envelope. Batch 8 validates intent and drift; the Batch 9 parent-owned adapter performs tested target-specific serialization. This prevents an isolated worker from inventing extension spellings or claiming unsupported compatibility.
## DR-047: Automation and outlets require explicit consumers
**Class:** Invariant
Automation IDs require explicit user intent plus an approved action registry. Named outlets require an approved macro-capable consumer and whitespace-exact name. Missing registries block planning rather than producing inert or surprising runtime behavior.
## DR-048: Convert through one semantic intermediate representation
**Class:** Invariant
**Decision:** Import supported artifacts into `worldbuilder-semantic-ir` after audit, then export the selected target. Generation workers stay target-neutral.
## DR-049: Portable format and runtime profile are separate choices
**Class:** Target-specific policy
**Decision:** Portable CCv3 keeps neutral WorldBuilder semantics; application fields require a named tested runtime profile.
## DR-050: Compatibility is proven from reopened bytes
**Class:** Invariant
**Decision:** Report compatibility, reopen output, check UTF-8/mojibake and semantic equality, then seal source/IR/report/output hashes. Unsupported or unapproved loss fails closed.
## DR-051: Portable-first defaults are intentional, narrowed for standalone lorebooks by Batch 13
**Class:** Product default
**Decision:** Simple Mode defaults to the mode-appropriate portable format and neutral runtime profile. Direct SillyTavern import is an explicit output/profile choice, not an automatic replacement for portability. Preserve-format updates retain the imported container style unless the user requests conversion. **Batch 13 narrows this for one specific case, and only this case:** a standalone lorebook with no card at all (`ir["card"] is None`, `ir["lorebook"]` present) whose `"preserve"`-resolved format is `lorebook-v3` now upgrades to `sillytavern-native` by default (`runtime_target_adapter.py`'s `resolve_preserve_target`). An explicit, non-`"preserve"` request for `lorebook-v3` is untouched by this narrowing and still produces the original portable wrapper exactly as before. Every other artifact shape this decision governs (card-bearing, group, persona) keeps the original, unnarrowed portable-first default.
**What would be a regression:** Calling portable-first behavior unsafe by itself; silently changing card-bearing, group, or persona output from a portable format to a named native one without the same direct evidence this narrowing required; normalizing preserved native containers without an explicit conversion request; widening this narrowing to any artifact shape beyond the one it names, without its own equally direct confirmation against real target behavior; removing `delivery_gate.py`'s `check_direct_import_compatible` enforcement gate on the reasoning that the default fix alone is sufficient. Compatibility reports must warn when portable output is not directly import-ready or when settings are preservation-only, but warnings do not by themselves authorize changing a default; direct, reproduced evidence of active misrouting does, and is what this narrowing is built on.
## DR-052: Ordered pipeline stage receipts
**Class:** Invariant
**Decision:** Record every applicable transition in one invalidation-aware SHA-256 chain.
## DR-053: Visible labels are semantic, not provenance strings
**Class:** Product default
**Decision:** Display lorebook entries as short `PREFIX: Subject` labels and keep model-facing `content` semantic/in-world. Keep article titles, URLs, source names, retrieval notes, and prior legacy labels in evidence or structured metadata. Label normalization may rewrite labels; content provenance detection only warns and never silently rewrites substantive prose. **Batch 22 narrow lifetime amendment:** `artifacts/source-lineage.json` may persist post-delivery page/revision identifiers and claim-to-UID provenance pointers so source synchronization can work later; it contains pointers/metadata only, never raw evidence prose, and is never model-facing content.
## DR-054: Gate errors name commands, and a step driver replaces protocol memory
**Class:** Product default
**Decision:** Every pipeline-stage block names the exact recording command and required reading; `pipeline_stage_gate.py --next` reports the single next required command; successful transitions print the next step and reading to stderr; manual `--stage` use prints the normal recorder.
## DR-055: Operation modes route directly and are also grouped for discovery
**Class:** Product default
**Decision:** Operations on existing artifacts (Iteration, Update/Merge, Prune, Audit, Soul Extractor, Diagnose) keep their individual intent rows in the mode table *and* appear together under one grouped entry. An unambiguous request routes straight to its mode; a vague request lands on the grouped menu.
**What would be a regression:** Removing the direct intent rows and forcing every request through the menu; removing the grouped entry on the grounds that it duplicates existing rows; or treating the grouped entry as a mode with its own gates, which it is not.
## DR-056: Artifact modification happens only through registered operations
**Class:** Invariant
**Decision:** Every operation that modifies an existing artifact is named in an operation registry with a definition, a declared blast radius, a contract, and a gate. The delivery gate accepts only artifacts produced by a registered operation. A request that maps to no registered operation is mapped to the nearest one with that stated, or declined with the available list shown. It is never improvised.
**What would be a regression:** Downgrading the registry to advisory documentation; delivering an artifact from an unregistered procedure; adding a capability in any phase of the roadmap without registering it first; or treating "the model behaved well in testing" as equivalent to enforcement.
## DR-057: Reading the SillyTavern install is infrastructure, not a mode
**Class:** Product default
**Decision:** Locating and reading the SillyTavern installation is a shared capability exposed as one script that any mode may call. It is a fourth input class alongside user description, uploaded files, and web research. It is read-only by default, proposes the resolved path for confirmation rather than guessing, and never blocks a build when the install is absent.
**What would be a regression:** Promoting it to a mode; reading chat logs for a task that does not require them; transmitting install contents to research workers; writing to the install without explicit plan-then-apply consent; or making a build fail because the install could not be found.
## DR-058: Prose checks measure the corpus, never score the writing
**Class:** Heuristic
**Decision:** `soul_contract.py` checks only properties measurable exactly across the whole corpus: cross-entry n-gram repetition, opener diversity, and sentence-length collapse, plus creator-declared anti-patterns and required markers. Declared constraints are errors; corpus metrics are warnings. Thresholds are tunable per profile. No check produces a quality score.
**What would be a regression:** Adding a quality or readability score; promoting corpus warnings to errors; scoring individual entries in isolation, which discards the only advantage this approach has over an LLM editor; or lowering the minimum sample so small builds start emitting noise.
## DR-059: Character invariants are hoisted out of era states
**Class:** Product default
**Decision:** For three or more eras, a character is split into a `core_invariant` entry carrying voice, invariant vitals, and base appearance, plus per-era state entries carrying timeline, mutable vitals, connections, backstory, and current situation. The core carries AND ANY over exactly the tokens of the eras its subject exists in; it never joins the variant inclusion group. Two-era builds with thin variation may keep self-sufficient states.
**What would be a regression:** Placing the core in the variant inclusion group; allowing status, rank, allegiance, location, relationship, or knowledge claims into core content; moving BACKSTORY into the core on the grounds that it "feels stable"; or applying the split by default to two-era builds where it costs complexity for no consistency gain.
## DR-060: Verification is triaged by blast radius, and cost is capped by scope
**Class:** Heuristic
**Decision:** Rank entries by `0.5 x activation likelihood + 0.3 x normalized dependent count + 0.2 x falsifiable claim density`, verify top-down until the approved budget is exhausted, and label everything below the line `unverified`. Report projected scope in units before freezing a plan; never cap spend mid-generation.
**What would be a regression:** Capping spend mid-generation, which yields an unpredictable partial artifact rather than a smaller approved one; defaulting unreached entries to `verified`, since absence of a contradiction is not evidence; hard-coding model prices, which go stale and are worse than no price; or verifying an imported book uniformly instead of triaging it.
## DR-061: Gate telemetry measures convergence, not quality
**Class:** Product default
**Decision:** Record every gate attempt with gate, model, scope, attempt number, outcome, and error class. Report first-attempt pass rate, mean and maximum attempts to pass, gates that never passed, and the most common error classes. Report per gate and per model, never as a single quality score.
**What would be a regression:** Presenting first-attempt rate as an output-quality measure; collapsing per-gate figures into one model score; recording attempts without the model, which makes the whole ledger uncomparable; or gating a release on a convergence threshold, since validity is already guaranteed and convergence is a cost signal.
## DR-062: Scripts check structure; auditors judge meaning
**Class:** Invariant
**Decision:** Gates verify procedure: that required steps ran, in order, with their receipts. Validation scripts verify structure: schema shape, field types, hash bindings, cardinality, enum membership. Auditor lenses verify semantics: era coherence, contradiction, whether prose says something it should not. A script may surface candidate passages for an auditor, and may never block on a judgement about what prose means.
**What would be a regression:** Any script raising on the meaning of prose; a gate enforcing a semantic contract; moving an auditor responsibility into a validator because it is faster; or a "temporary" keyword check added to a gate while an auditor lens is unavailable.
## DR-063: Permanent, opening, and non-prompt card cost are three different meters
**Class:** Compatibility issue
**Decision:** Permanent card cost is `description`, `personality`, `scenario`, `system_prompt`, and `post_history_instructions` only, capped against `permanent_card_target`/`permanent_card_hard`. Opening cost is `first_mes` plus the single active `alternate_greetings` entry (never the sum) plus `mes_example`, reported and soft-warned against the same target but never blocking. Non-prompt cost is `creator_notes`, reported only and never capped or warned.
**What would be a regression:** Summing every `alternate_greetings` entry instead of taking the maximum; capping opening or non-prompt cost against the permanent-card hard limit; or folding `creator_notes` back into a blocked total.
## DR-064: Timeouts are computed liveness bounds, not work estimates
**Class:** Product default
**Decision:** `run_timeout_seconds = per_unit_seconds * unit_count * safety_multiplier + fixed_slack_seconds`, floored at a minimum. The model reads this stamped value from its assignment and passes it as `sessions_spawn`'s `runTimeoutSeconds` argument; it never estimates or invents the number itself. `safety_multiplier` defaults to 3, `fixed_slack_seconds` to 300, and the floor to 900s. `per_unit_seconds` (`per_uid_seconds` for generation, `per_page_seconds` for discovery) is seeded from config and frozen into the build at creation, meant to be recalibrated over time from `gate_telemetry.py`'s mean-attempts-to-pass data rather than re-guessed each release. Separately, `gate_telemetry.py stagger` may adapt only the delay between independent child starts from observed timeout history, bounded to 10-60 seconds with a 20-second no-history baseline; this pacing signal never changes the stamped timeout itself.
**What would be a regression:** A worker or prompt inventing its own timeout value instead of reading the stamped one; treating a `timed_out` status as equivalent to `completed` anywhere, including writing it to a `runtime_receipt` path; or reintroducing an unbounded spawn call.
## DR-065: Host config is read, diffed, and merged, never regenerated
**Class:** Product default
**Decision:** Every OpenClaw host-config write goes through one path: resolve the live config path via `openclaw config file --json` (never assumed; `OPENCLAW_CONFIG_PATH` and `--profile` can move it away from the `~/.openclaw/openclaw.json` default), back up that exact file, read each key's current value before proposing a change, write only the changed keys one at a time through `openclaw config set` (never a wholesale rewrite), run `openclaw config validate`, and restore the backup automatically on failure. Keys are refused outright unless they start with `agents.defaults.`, `plugins.entries.searxng.`, or `tools.web.search.`; another agent's `agents.entries.*` section is never in scope, checked in code rather than left as a convention. The gateway is never restarted automatically, on any outcome; OpenClaw hot-reloads most config changes on its own, and a restart is reported as guidance for the operator to run themselves when ready, never executed on their behalf.
**What would be a regression:** Writing the whole config file instead of setting individual keys; skipping the backup or the pre-write diff; restarting the gateway automatically under any condition; or widening the in-scope key prefixes without the same explicit flagging this entry itself models.
## DR-066: Context window and detail level are independent axes
**Class:** Invariant
**Decision:** `context_window` (Axis 1, user-declared) sets the total static budget; `detail` (Axis 2: Compact/Recommended/Maximum) sets distribution only (entry count vs. per-entry richness, and simulation depth) and never changes the total. `derive_profile()` computes `permanent_card_hard` directly from the artifact's shell share of `available_for_static` (DR-068), derives `worst_case_hard` as the remainder, and rescales every other profile field by that ratio against the existing profile's own tuned internal relationships, rather than replacing them.
**What would be a regression:** A detail-level change altering the *sum* of `permanent_card_hard + worst_case_hard` at a fixed window; any hardcoded absolute token number reappearing in the derivation path.
## DR-067: Corpus size is reported; activation pressure is budgeted
**Class:** Invariant
**Decision:** `corpus_authored_tokens` (total authored lore volume) is reported and never compared to, or blocked by, an activation budget. Only `worst_case_recursion_path` (measured activation pressure) is budgeted and can block.
**What would be a regression:** Any code path comparing `corpus_authored_tokens` against a hard or target limit, under any name.
## DR-068: Card shell is sized by retrieval coverage, allocated by slot priority
**Class:** Product default
**Decision:** `permanent_card_hard` is sized as a share of `available_for_static` by artifact shape (`SHELL_SHARE_BY_ARTIFACT_TYPE`: 60-70% bookless card, 25-35% card with book, 10-15% World, 20-30% group). When the shell must shrink to fit, `SLOT_PRIORITY` gives a mechanical cut order: identity kernel and interaction contract are never cut; voice sample is cut last; the situation anchor is cuttable if a constant root or Scenario already covers it; appearance and detail move to the lorebook first.
**What would be a regression:** Cutting identity-kernel or interaction-contract content under any budget pressure; cutting appearance-and-details material after voice sample or the situation anchor rather than before.
## DR-069: Budget overage is an approved deviation, not a spec error
**Class:** Product default
**Decision:** A worst-case activation estimate exceeding headroom is a planning *preference* overage, not a spec or compatibility error, and gets structural remediation options (`propose_deviation_options`) rather than a bare block. An explicit, human-attributed choice to ship anyway is recorded into the frozen plan at approval time (`record_approved_deviation`), never as a runtime override, and `deviation_covers` only ever covers a measured value up to what was actually approved; never a worse regression waved through by an old approval.
**What would be a regression:** An approved deviation silently covering an overage larger than what was actually approved; any code path achieving the same effect as an approval without writing it into the frozen plan.
## DR-070: Entries are budgeted by graph obligation, not uniform compression
**Class:** Invariant
**Decision:** `target = clamp(source_tokens * compression_ratio, floor, ceiling)`. When the raw computed value would exceed ceiling, that is a split signal (stratify by depth, summary shallow and detail one recursion level deeper), never a truncation instruction. Maximum Detail has no ratio at all: `entry_hard` is a structural, planning-time split trigger, applied once written length is known, never a trim instruction, never a block. A Tier 0 retention-ladder breach (`RETENTION_LADDER`) is likewise always a split signal, never a cut, regardless of detail level.
**What would be a regression:** Truncating a dense entry instead of emitting a split signal; applying any compression ratio on Maximum Detail; treating `entry_hard` as a trim instruction rather than a split trigger there; an overflow record carrying prose instead of claim-ID pointers.
## DR-071: Editing is a tool operation, not a rewrite
**Class:** Invariant
**Decision:** Every modifying mode proves its change against a baseline. `artifact_edit.py`'s five operations are the only sanctioned way to change an existing artifact; `artifact_diff.py` is the proof mechanism, and `verify_patches.py --before` applies the same principle to patch verification specifically, checking a target's JSON for collateral damage the patch log itself never authorized. The prune workflow's `apply_selection` follows the identical discipline: it goes through `artifact_edit.py` exclusively, never a parallel, ad-hoc mutation path, and `prove()` binds a real before/after comparison into the receipt rather than asserting improvement.
**What would be a regression:** A new editing operation that produces no before/after comparison at all; a "rewrite" mode that replaces an entry wholesale without going through `artifact_edit.py`; widening `SET_FIELD_ALLOWED` or `ALLOWED_MUTABLE_FIELDS` to force an activation-strategy field through casually, rather than as its own deliberate decision.
## DR-072: Capability follows lineage, not the reverse
**Class:** Product default
**Decision:** `capability_tiers.py`'s three tiers (Unbound, Legacy-bound, Bound) invert the old assumption that WorldBuilder lineage is required before an artifact can be worked with at all. Unbound is the default, and it is already capable: structural edit, derived activation graph, diff proof, format validation, and import probe all work on any lorebook, hand-made or third-party, with no WorldBuilder history whatsoever. Capability only grows from there, and only when lineage is verified against a live, matching workspace; a `worldbuilder_provenance` marker's own claim is never sufficient for Bound by itself.
**What would be a regression:** A new mode that refuses to operate on an artifact without an associated build-state; treating a provenance marker's own claim as sufficient for Bound without checking it against a live workspace's current `build_id` and `manifest_sha256`; silently upgrading a tier based on anything other than that live check.
## DR-073: Prune is measured in activation pressure, not corpus size
**Class:** Invariant
**Decision:** `worst_case_after_pruning`'s `max_pressure` (the maximum `estimated_tokens` across every simulation, not just `worst_case_recursion_path`) replaces total content-token reduction as prune's primary proof of improvement. A prune is accepted if either activation pressure or content tokens genuinely decreases; corpus size alone remains sufficient (unchanged from before) but is no longer the only accepted proof.
**What would be a regression:** Reverting to a single-metric, tokens-only acceptance check; comparing only one simulation instead of the maximum across all of them; a prune-adjacent check that fabricates a projected pressure number instead of computing it by actually running the simulation.
## DR-074: Decorators are the portable emission form; native keys are the profile form
**Class:** Invariant
**Decision:** A runtime semantic that both a CCv3 decorator and a native SillyTavern extension field can express, namely `depth`/`role` (`placement_context`) and activation timing (`dynamic_state`'s `delay`, as `@@activate_only_after`), has exactly one owner per export target. The portable path (`ccv3-embedded`, standalone `lorebook_v3`) emits the spec's own `@@name value` decorator; the named SillyTavern profile emits the native extension key. Never both from the same export. `scripts/decorators.py` is the single, shared parser every consumer uses rather than reimplementing; `runtime_target_adapter.py`'s `_ccv3_entry` is where the single-owner choice is actually enforced, popping a semantic out of what would become a native extension field before emitting it as a decorator instead. One owner is not the same as one meaning, amended in place by Batch 58 / A09: `depth` and `role` express the same thing in both forms, but activation timing does not. `@@activate_only_after` counts assistant messages while SillyTavern's native `delay` counts total chat messages, so carrying an equal integer across them is not a proven equivalent and `runtime_target_adapter.py` now marks that conversion lossy (with a warning naming the two domains) rather than certifying it lossless.
**What would be a regression:** A portable export that writes both a decorator and the matching native extension key for the same semantic; guessing at a numeric-to-string decorator value translation without a confirmed source; a new decorator-adjacent field skipping `scripts/decorators.py` and reimplementing parsing independently.
## DR-075: WorldBuilder generates images through the host runtime's provider, never its own
**Class:** Approved redesign
**Decision:** WorldBuilder constructs image prompts and calls the host runtime's `image_generate` tool (`references/image-prompts.md`'s `--generate` branch, `expression_assets.py`'s `generation_sequence`); it never implements, selects, or manages a provider, API key, or model registry of its own. This reverses the prior documented position ("emits prompts and descriptors, never images") in `image-prompts.md` and `info-mode.md`. `capability_probe.py`'s existing `image_generate` gating (added ahead of this batch, during Batch 4) already controls whether the generation branch is offered at all; no new detection mechanism was needed.
**What would be a regression:** Building provider plumbing, key management, or a model registry inside WorldBuilder itself; defaulting to more than one generated image per request without explicit confirmation (cost is user-owned, philosophy point 9); applying content-safety rules only after a provider call rather than at prompt construction; treating `image-model-profiles.json` as a live, self-updating source instead of a version-pinned reference requiring deliberate refresh.
## DR-076: Menus are tiered by host capability; the text tier is first-class
**Class:** Product default
**Decision:** Two menu tiers, detected the same way as the `sessions_spawn` and `image_generate` preflights (`capability_probe.py`): a widget tier (`show_widget` HTML screens with `sendPrompt` buttons) when available, and a single-column text tier otherwise, rewritten so no alignment depends on emoji column width, which is inconsistent across fonts. The text tier is the default and is designed as first-class, not a degraded fallback: when `show_widget` is absent, nothing in the response mentions that a richer version exists or suggests installing a newer or beta host to get it.
**What would be a regression:** Telling a user to install a beta host, or update their client, to access the widget tier; a text-tier layout that reintroduces two independently-meaningful columns paired by row position (where misaligned emoji width could pair a label with the wrong row's content, not just look cosmetically ragged); a widget screen using a hardcoded color instead of a host theme token; treating the text tier's design as secondary to the widget tier's.
## DR-077: Amendments are slice-scoped and seal-chained
**Class:** Invariant
**Decision:** Editing a sealed (`delivery_permitted`) build never rolls back to a fixed stage via `invalidate_from`. `pipeline_stage_gate.py`'s `record_amendment` appends an `amendment_N` entry to the same ledger: every stage from `first_amendable_stage` onward (`pre_generation_audit` for a non-structural change, `planning_validated` for a structural one, per `change_set.py`'s own `structural` flag) is either `re_proven` (a fresh receipt) or `carried_forward: slice_unaffected` (justified by the change set's own hash), decided per stage, never all-or-nothing, and the sealed chain's original receipts are never touched, removed, or replaced. `audit_plan.py --scope changed` narrows the four LLM lenses to the change set's `changed_uids` plus `neighbour_affected_uids` (a neighbour-only touch counts the same as a direct one); `soul_contract.py` and `budget_contract.py` have no scoping mechanism at all and always run full. `delivery_gate.py` binds an amended seal at `seal_version: 4` with `amends`/`change_set_sha256`, while re-verifying target bytes, entry count, and merge input from disk exactly as it does for a fresh seal.
**What would be a regression:** Calling `invalidate_from` for an amendment scenario instead of `record_amendment`; a `carried_forward` decision for a stage with no prior sealed receipt to justify carrying; `delivery_gate.py` skipping its target/merge/entry-count re-verification because a seal is being amended rather than freshly sealed; treating a neighbour-only-affected UID as unchanged for either the audit scope or the amendment caps.
## DR-078: Debug capture happens at the point of failure, not reconstructed at delivery
**Class:** Invariant
**Decision:** Every gate-invoking command, in both the parent's own operations (`SKILL.md`) and a dispatched generation worker's own operations (`prompts/generation-worker.md`), is wrapped in `debug_log.py capture -- <command>` rather than invoked directly. `capture` runs the wrapped command exactly as given either way and, only on failure, mechanically records the exact reproduction argv, current pipeline stage, and truncated failure detail, by construction, at the instant the failure happens, never something an agent has to remember to do afterward. `debug_log.py` is staged into the worker kit specifically so a dispatched worker's own commands (`entry_cycle_gate.py` at each of research/write/finalize) can be wrapped the same way; `{baseDir}`, where the parent's own copy lives, is not reachable from a worker's own execution.
**What would be a regression:** A worker or the parent invoking a gate script directly, unwrapped, when debug logging is available; reconstructing debug-log entries after the fact from memory, in any form, including a well-intentioned backfill script; instructing `capture` conditionally on debug logging being enabled rather than unconditionally.
## DR-079: Pre-seal patch-and-rerun is scoped by default, the same principle as post-seal amendment
**Class:** Invariant
**Decision:** `verify_patches.py --write-change-set <path>` derives a `change_set.py`-contract change set directly from a patch log's own recorded operations against the single, current target, once (and only once) the patch gate genuinely passes; an incomplete or failing verification writes nothing. `references/post-gen-audit.md`'s "Re-audit and seal" now documents this scoped path as the normal case: verify with `--write-change-set`, and if the result is not structural, re-plan and re-run the four lenses with `audit_plan.py --scope changed --change-set <path>` rather than the full five-step re-audit. A structural change (any patch touching a path that never resolves through an entry, such as a top-level `/architecture/...` edit) still falls back to the full re-audit, with no exception, matching `change_set.py`'s own rule for the post-seal case exactly.
**What would be a regression:** Treating a patch log with any non-entry-path patch as scopeable; assuming a JSON Pointer's numeric segment is the touched entry's UID without resolving it against the actual document; writing a change set when the patch gate has not genuinely, fully passed; scoping the four LLM lenses without also scoping the corpus-wide deterministic checks' own documented exemption (`soul_contract.py`'s prose metrics and `budget_contract.py`'s seven simulations still always run full, unchanged from the post-seal case; this was never proposed to change here either).
## DR-080: Dynamic-pipeline content production is free; validation and delivery are not
**Class:** Invariant
**Decision:** A mode that produces planning or generation content by a mechanism other than the standard structured menus/worker sequence must still produce the same applicable planning artifacts and final output contracts. `pipeline_stage_gate.py`, the four-lens audit, `validate_output.py`, architecture/integration gates, and `delivery_gate.py` are not modified, bypassed, or given a lighter parallel path for custom production.
## DR-081: Architecture validation honors frozen profile inheritance
**Class:** Invariant
**Decision:** Architecture checks resolve entry settings with the same frozen default-profile and layer-override inheritance used by the activation-map gate. An explicit entry-level value still wins over the inherited default.
**What would be a regression:** Reading only raw `emit` fields for a setting whose contract permits profile inheritance, or allowing an inherited default to override an explicit entry value.
## DR-082: Diagnose reports only checks it can actually prove
**Class:** Invariant
**Decision:** A read-only diagnostic sweep marks a check `skipped` when that check necessarily depends on a receipt the sweep deliberately does not write, and skipped checks do not count as failures.
**What would be a regression:** Reporting integration as failed during the read-only sweep solely because its prerequisite receipt was intentionally not written, or counting `skipped` rows in `failed_count`.
## DR-083: Downstream gates honor an upstream gate's sanctioned acceptance paths
**Class:** Invariant
**Decision:** When a gate consumes another gate's receipt, it honors the producing gate's documented acceptance conclusion rather than re-deriving a narrower one from a single subordinate field. Discovery completeness therefore accepts either direct `saturation_proven` or `effective_saturation_accepted`, which already incorporates sanctioned terminal-stop and frontier-closure paths.
**What would be a regression:** Requiring `saturation_proven=true` after `discovery_gate.py` has legitimately recorded `effective_saturation_accepted=true`.
## DR-084: Dispatch evidence uses host-neutral semantics
**Class:** Invariant
**Decision:** Runtime receipts express what the parent actually observed using host-neutral methods (`parent_observed_child_run` or `parent_observed_exec`). OpenClaw-specific mechanics such as `sessions_spawn` are mapped to those semantics at the host boundary and documented separately; gates consume the neutral contract, never the provider/tool name. `wb_operations.py` exposes high-level deterministic operations but does not pretend to intercept agent dispatch that does not exist in Python control flow.
**What would be a regression:** Reintroducing an OpenClaw/provider-specific tool name as a required receipt semantic; adding a fake dispatch abstraction to `wb_operations.py`; allowing a child to self-certify completion; or changing one receipt producer without every consumer of that semantic.
## DR-085: Author locks are one explicit mutation authority
**Class:** Invariant
**Decision:** Author locks and ownership live on the entry at `architecture.lock` and are interpreted only by `lock_contract.py`. Whole-entry locks (`fields: null`) and field locks block automated mutation in structured generation, Guided/custom generation, pruning, editing, selective regeneration, and future sync. Audits may still report problems; they cannot remove or bypass a lock. Unlocking is an explicit operation.
**What would be a regression:** Any mutating subsystem re-implementing lock semantics instead of importing `lock_contract.py`; pruning or generation silently skipping a locked target without reporting it; an audit suppressing findings merely because an entry is locked; or another operation implicitly unlocking content.
## DR-086: Selective regeneration proves untouched entries stayed untouched
**Class:** Invariant
**Decision:** Selective regeneration resolves a request to an exact UID set, filters author locks, applies replacements only for those UIDs, and proves every other entry's canonical binding hash is unchanged. Neighbour UIDs expand audit scope only, not regeneration scope. Normal selective regeneration reuses scoped lineage invalidation and re-runs research→write; detail-only regeneration preserves validated evidence and re-runs write only. The ordinary changed-scope audit/validation/delivery contracts remain authoritative afterward.
**What would be a regression:** Accepting replacement UIDs outside the resolved set; modifying an untouched entry without failing the hash proof; silently regenerating neighbours merely because they are audit-affected; discarding evidence on a declared write-only detail pass; or bypassing the normal scoped audit after application.
## DR-087: Persistent source lineage stores pointers, not prompt content
**Class:** Invariant
**Decision:** A sealed source-backed build may persist `artifacts/source-lineage.json` containing source page/revision identifiers and claim-to-UID pointers. Raw evidence text stays in build scratch; the lineage artifact is never injected into model-facing entry content. Source updates require a review report and explicit approval before selective regeneration is prepared.
**What would be a regression:** Persisting raw scraped evidence wholesale; copying provenance strings into `content`; regenerating from a changed source before approval; or giving sync a bypass around author locks/selective-regeneration scope.
## DR-088: Rollback restores a sealed baseline and resets amendment depth
**Class:** Invariant
**Decision:** Rollback restores an earlier already-sealed snapshot as a fresh baseline and resets the amendment chain depth to zero. It never appends rollback as another forward amendment. Locks applied after the target snapshot surface as explicit conflicts before restoration.
**What would be a regression:** Preserving the old amendment count after rollback; restoring unsealed bytes; silently deleting a later author lock; or inventing a second unrelated hash system.
## DR-089: Multi-book output is an explicit package of independent builds
**Class:** Product default
**Decision:** Single-artifact output remains the portable default. When the user explicitly chooses an optimized multi-book package, planning creates multiple independent WorldBuilder builds sharing one parent package plan; each child keeps its own ordinary stage ledger, manifest, audits, and seal. Cross-book dependencies live in a parent registry.
**What would be a regression:** Silently splitting a normal build; weakening the single-book portable default; modifying `pipeline_stage_gate.py` merely to hold parallel manifests; or leaving cross-book UID dependencies untracked.
## DR-090: Cross-worker shared state is immutable phase-boundary facts
**Class:** Invariant
**Decision:** Parallel workers may receive one read-only summary frozen before dispatch from already-completed phases only. It contains neutral named facts, never sibling prose/reasoning or in-progress output, and never changes for an assignment mid-phase.
**What would be a regression:** Refreshing an assignment's summary after dispatch; allowing workers to write it; including unreviewed sibling prose; or treating it as authority over frozen plans.
## DR-091: Runtime verification labels observed and synthetic evidence separately
**Class:** Invariant
**Decision:** Runtime verification records whether activation evidence was observed from a live SillyTavern runtime or predicted synthetically. Missing live introspection degrades to prediction; it never upgrades prediction into an observed claim. Divergences are review findings, not silent auto-repairs.
**What would be a regression:** Calling synthetic closure observed; hard-depending on one third-party extension without fallback; claiming recursion-depth agreement from data that does not expose recursion rounds; or silently changing content from telemetry.
## DR-092: Shared semantics are public contracts, not private imports
**Class:** Invariant
**Decision:** When more than one script consumes the same semantic helper, that helper lives behind an explicit public module/function name. Cross-module imports of underscore-prefixed implementation helpers are forbidden. CLI entrypoints with substantial argument setup separate parser construction, cross-argument validation, orchestration, and a thin `main()` so future capability work extends the relevant layer instead of growing one monolith. Compatibility aliases may remain inside the original owner module, but another module must not depend on them.
**What would be a regression:** A script importing another script's underscore-prefixed helper; duplicating shared budget/activation/placement semantics instead of using the public contract; re-growing parser/validation logic inside the thin `main()`; or changing CLI/output behavior under the guise of this organizational rule.
## DR-093: Canon conflicts are explicit evidence, precedence is deterministic
**Class:** Invariant
**Decision:** A generation worker marks a required topic `conflicted` only when it has at least two competing supported claims with their own source references. The deterministic evidence gate materializes the structured conflict object from that declared semantic state; it never attempts to infer contradiction from arbitrary prose. Optional manifest-level `architecture.canon_precedence` ranks evidence `source_type` values. A conflict auto-resolves only when exactly one competing claim is traceable to the uniquely highest available tier; ties, missing tiers, or untraceable claims remain unresolved.
**What would be a regression:** Selecting a winner without a recorded conflict; using freeform text similarity as canon authority; resolving a tie; leaking conflict reasoning or citations into model-facing entry content; or allowing a precedence list to contain duplicate/blank tiers.
## DR-094: Cross-source entity resolution requires shared identity evidence
**Class:** Invariant
**Decision:** Discovery resolves two separately discovered entities into one canonical entity only when they share at least one canonicalized source page and their normalized name/alias sets overlap, with compatible taxonomy. Resolution runs after ordinary discovery collection/reconciliation, preserves alternate names as aliases, and chooses the shortest deterministic canonical discovered name. Fuzzy name similarity alone is not identity proof.
**What would be a regression:** Merging solely on fuzzy names; merging incompatible known entity types; dropping an alternate discovered name instead of preserving it as an alias; or changing existing coverage-reconciliation semantics to perform identity merging.
## DR-095: Phase-boundary quality checks detect but never repair
**Class:** Invariant
**Decision:** After completed generation phases validate at pre-merge, WorldBuilder runs a cheap cross-phase scan for high-overlap near-duplicates and conservative explicit-negation contradictions. The scan writes non-authoritative findings for the later audit and never merges, rewrites, deletes, or resolves entries itself.
**What would be a regression:** Auto-merging or rewriting from this detector, treating its findings as audit verdicts, blocking independent non-conflicting entries on weak similarity, or removing the later four-lens audit because this intermediate scan exists.
## DR-096: Guided transformations are append-only reproducible build metadata
**Class:** Invariant
**Decision:** Historical Batch 23 contract, superseded by DR-105. When Guided Mode adapts a source concept into a target concept, WorldBuilder resolves the normalized `(source_concept, target_concept, transformation_type)` key against `artifacts/transformation-map.json` before drafting. The first confirmed use records a non-empty rationale; later exact normalized-key matches reuse the same immutable mapping instead of re-deriving it. Generation receipts bind the mapping IDs and exact map hash when mappings were used. The map is build metadata and never model-facing content.
**What would be a regression:** Re-deriving an existing exact mapping from scratch; silently changing a recorded rationale; using fuzzy similarity as transformation identity authority; injecting transformation bookkeeping into delivered content; or accepting a generation receipt that names mapping IDs absent from the recorded map.
## DR-097: Runtime bundles preserve sealed bytes and keep settings advisory
**Class:** Invariant
**Decision:** A runtime bundle is an explicit post-delivery packaging operation. It embeds the exact already-delivered/runtime-adapter bytes unchanged, may add validated convenience components, and may add `recommended_settings.json` only as recommendation-only metadata derived from settings already frozen by the build. Packaging does not regenerate, re-audit, reseal, or mutate the delivered source, and does not create a second runtime-target serializer.
**What would be a regression:** Rewriting the delivered artifact during bundling; creating a bundle before delivery is permitted; treating `recommended_settings.json` as an executable SillyTavern settings import; inferring scan depth or recursive scanning without a frozen decision; or adding a second target-mapping path outside `runtime_target_adapter.py`.
## DR-098: Extension adapters are source-pinned and target-specific
**Class:** Target-specific policy
**Decision:** WorldBuilder extension adapters use one stable internal envelope but never pretend that unrelated SillyTavern or third-party extensions share one external schema. Each extension exposes only target formats verified against named current source. Existing runtime-target serialization remains authoritative for World Info fields it already owns. Application-global settings are recommendation-only unless a future target provides a separately verified mutation/import API. Unsupported targets, deprecated field values, and out-of-scope automation wiring fail closed.
**What would be a regression:** Adding a serializer from memory instead of current source; silently accepting an unknown target; treating recommendation-only global settings as an executable import; duplicating `runtime_target_adapter.py` ownership for normal build delivery; accepting deprecated Regex placement 0 or legacy placement 4 as current; or claiming MVU/EJS runtime behavior without the extension.
## DR-099: Behavioral test-drives are diagnostic, hash-bound, and non-authoritative
**Class:** Invariant
**Decision:** A behavioral test-drive reuses the same synthetic activation predictor as runtime verification, freezes the exact final-artifact, manifest, context, response, and behavioral-lens bytes by hash, and separates deterministic technical validation from model-judged voice/knowledge behavior. The generated response must come from the model under test using only the frozen persistent and predicted-active context. A separate reviewer judges exactly `voice_consistency` and `knowledge_boundary`. The resulting report is diagnostic: it never satisfies the four-lens audit, delivery seal, or live-runtime acceptance and never auto-edits the artifact.
**What would be a regression:** Creating a second activation engine; generating fixture prose inside deterministic code and calling it model behavior; letting the test model browse or read unactivated build context; treating a behavioral pass as an audit/delivery/live-runtime pass; accepting a lens verdict not bound to the current response; or automatically patching an artifact from a poor behavioral verdict.
## DR-100: Persistent source traceability records used-claim ancestry without promoting it to proof
**Class:** Invariant
**Decision:** Extend the existing persistent source-lineage artifact with pointers and hashes that distinguish all researched claims from the narrower claim IDs actually cited by hash-verified merged phases. Bind those used claims to generated-entry and sealed-entry hashes, but persist no raw evidence or entry prose. A content-preserving deterministic metadata rewrite may be labeled `model_facing_content_exact`; changed sealed prose must be labeled `post_generation_content_changed`; missing or stale merged-phase provenance degrades to `evidence_only` rather than guessing.
**What would be a regression:** Persisting raw claim/entry prose in source lineage; treating every researched claim as used; silently carrying an exact-support label across changed sealed content; narrowing source-sync invalidation to only previously used claims; creating a second provenance database; or claiming that pointers and hashes alone prove semantic correctness.
## DR-101: Semantic pruning objectives are soft WCSA-derived review biases
**Class:** Heuristic
**Decision:** Freeze optional named pruning objectives in the existing budget plan and derive their advisory candidate-order adjustment from the exact activation sets already produced by WCSA simulations. `preserve_factions` recognizes existing faction/organization semantics; `preserve_main_plot` recognizes only explicit `architecture.pruning_tags: ["main_plot"]`. Each matched objective subtracts one preservation point from an otherwise eligible candidate's review score. Author locks exclude candidates before scoring, exact projected savings remain a separate measured field, and SillyTavern runtime drop order is untouched.
**What would be a regression:** Treating an objective as an undeclared lock; inventing a second WCSA/runtime activation model; changing `predict_drop_order()` from an editorial objective; calling co-fire exposure projected token savings; inferring every event as main plot; scoring a UID that an applicable author lock already excluded; or silently changing a frozen objective weight.
## DR-102: Shared presets are allowlisted defaults, never authority
**Class:** Invariant
**Decision:** A shareable settings preset contains only explicitly allowlisted, non-secret, non-build-specific choices already exposed by the normal build settings flow. It is applied before existing planning contracts freeze, explicit current-build choices override it, and imported values still traverse the ordinary placement, budget, dynamic-state, runtime, audit, and delivery validation paths. Home Config, host/model settings, paths, source files, arbitrary custom override blobs, and audit/delivery bypass controls are outside the preset schema rather than representable switches.
**What would be a regression:** Ignoring unknown preset fields; serializing workspace/source paths or secrets; letting a preset disable required audits or delivery checks; mutating Home Config when a preset is applied; allowing preset data to override an explicit current-build choice; silently dropping custom override data during export; or validating preset values instead of passing them through the existing build contracts.
## DR-103: Public runtime release is a stripped projection, not a second product
**Class:** Invariant
**Decision:** Derive the public release from a verified development tree, but ship only the runtime skill: operational scripts, prompts, references, UI metadata, version markers, and the compact design-decision contract. Omit tests, fixtures, engineering history, maintainer packaging/integrity machinery, and other development-only evidence. Never treat the stripped release as a reconstructible development source tree.
**What would be a regression:** Shipping development/test history or maintainer packaging machinery in the public runtime; omitting runtime-required scripts, prompts, compatibility data, or the compact design-decision contract; or representing the stripped release as a complete development source tree.
## DR-104: Source quality scales evidence confidence without becoming hidden canon
**Class:** Heuristic
**Decision:** Accept optional manifest-level `architecture.source_type_weights` as normalized 0..1 trust multipliers. The evidence gate derives `_worldbuilder_weighted_confidence` from the existing high/medium/low claim label and cited source types; unconfigured types remain neutral. When explicit `canon_precedence` is absent, the same weights may rank conflicting source types, but equal weights remain tied and explicit precedence always wins.
**What would be a regression:** Inventing default trust values without configuration; letting a weak weight silently override an explicit `canon_precedence`; assigning arbitrary order to equal weights; trusting a worker-supplied derived confidence instead of recomputing it; or creating a parallel confidence scale disconnected from existing evidence consumers.
## DR-105: Guided decisions are one append-only log with legacy transform migration
**Class:** Invariant
**Decision:** `artifacts/decision-log.json` is the canonical append-only Guided Mode decision artifact for transforms, accepted merges, rejected concepts, renames, canon deviations, and exclusions. Exact normalized kind-specific identity may reuse a prior immutable decision; fuzzy similarity is not identity authority. Batch 23 `transformation-map.json` is migration input only: migration preserves every `tm-*` ID/rationale, records the legacy hash, and never rewrites the old file. The transform CLI remains a compatibility facade and generation receipts bind the canonical decision-log hash.
**What would be a regression:** Writing new decisions to both files; renumbering legacy `tm-*` IDs; mutating a migrated legacy map; changing an existing rationale in place; using fuzzy matching as decision identity; failing to surface an exact-normalized prior rejection before re-proposing it; or leaking decision rationale into model-facing content.
## DR-106: Canonical terminology is frozen project metadata, not activation authority
**Class:** Invariant
**Decision:** Materialize `artifacts/terminology-dictionary.json` from the planned manifest before generation. Freeze each normalized canonical term's first established spelling/capitalization, explicit aliases, explicit titles, and contributing UIDs. `entry_naming.py` resolves visible subjects through this dictionary and generation workers consult the same hash-bound artifact before inventing variants. Canonical names and aliases must resolve uniquely; shared titles may remain ambiguous and never establish identity by themselves. Activation keys remain untouched and are not automatically promoted into naming aliases.
**What would be a regression:** Treating every activation key as a naming alias; resolving a shared title as identity proof; silently accepting one alias for two different canonical terms; rewriting trigger keys to match preferred spelling; letting workers use an unbound/stale dictionary; or adding a second canonical-name owner outside the entry-naming/terminology contract.
## DR-107: Facet inference proposes structured source signals but confirmation remains authoritative
**Class:** Invariant
**Decision:** Extend source-facet discovery beyond literal MediaWiki categories by deriving candidate signals from current page structure: exact categories, facet-matching infobox templates, and facet-matching navigation templates. `facet_inference.py` may rank/propose these signals but never applies them. Template-based filtering requires a user-confirmed candidate artifact; `discovery_plan.py` hash-binds that artifact and `run_discovery_worker.py` accepts a page only when one confirmed category or template matches exactly after normalization.
**What would be a regression:** Auto-confirming an inferred mapping; treating every transcluded template as facet evidence; matching an unproposed template supplied only at planning time; replacing exact confirmed matching with fuzzy runtime inclusion; dropping legacy category-only behavior; or letting structural inference widen a facet-scoped request into general franchise discovery.
## DR-108: Representative activation expectations persist across graph changes
**Class:** Invariant
**Decision:** Optional manifest `activation_tests` freeze authored positive/negative UID expectations into `artifacts/activation-test-corpus.json`. Checks reuse `runtime_verification.predict()` and compare only required-present and forbidden-present membership. The frozen corpus survives manifest invalidation; only its derived gate receipt is invalidated. A changed declaration cannot silently rewrite the corpus, and intentional expectation changes require the explicit replace operation.
**What would be a regression:** Reimplementing keyword/closure semantics inside the corpus checker; overwriting expectations automatically when the manifest changes; deleting the corpus during lineage invalidation; treating unspecified extra activations as failures; accepting a missing/unknown referenced UID silently; or presenting a corpus pass as behavioral quality or live-runtime evidence.
## DR-109: Cost projections separate measured structure, historical signals, and explicit fallbacks
**Class:** Heuristic
**Decision:** `verification_triage.py project` remains the one pre-freeze cost owner. Build-aware projections count discovery assignments/waves from the existing discovery plan, generation workers through `gate_telemetry.partition`, and required four-lens audit calls from frozen build state. Gate telemetry may scale expected attempts from measured convergence and may supply token means only when token counters were explicitly recorded. Missing token history uses the existing static generation/audit heuristic and leaves discovery-token cost unmodeled rather than inventing it. `reconcile` preserves the original estimate beside final observed receipts/ledgers; neither projection nor variance is a release gate.
**What would be a regression:** Adding a second cost calculator; hard-coding provider prices; using `run_timeout_seconds` as predicted work duration; presenting convergence as quality; inventing discovery tokens without observed history; overwriting a saved projection without an explicit replacement; rewriting it during reconciliation; or blocking planning/delivery because actual usage differs from an estimate.
## DR-110: Worker model routing is frozen by role and never guessed
**Class:** Product default
**Decision:** `models.subagent` remains the backward-compatible fallback. Optional discovery, generation/recovery, and audit routes resolve at build creation, with explicit role values overriding `cheap`, `standard`, or `maximum-quality` routing presets. Presets use only the user's configured main/subagent references and never embed provider/model names. Every child assignment freezes `requested_model`; OpenClaw dispatch passes a concrete value exactly or omits the override for `inherit`, then verifies the parent-observed `resolvedModel` with `model_routing.py`. Cost projection samples telemetry by both work kind and the role's frozen model.
**What would be a regression:** Removing the legacy subagent fallback; hard-coding provider/model names into a strategy; silently treating an unresolved `default` coordinator as a concrete quality model; dispatching from mutable global config instead of the assignment's frozen `requested_model`; accepting a concrete `resolvedModel` mismatch; or pooling telemetry across work kinds/models after role routing is enabled.
## DR-111: Build templates are visible setup defaults, never hidden answers
**Class:** Product default
**Decision:** Reusable build templates belong to the guided setup layer, before build initialization. A template is a named, hash-bound bundle of `settings-menu.md` answer selections. `setup_state.py` keeps the normal mode-filtered page/question structure unchanged, exposes applicable template values as `prefill`, and leaves every page pending until the user explicitly saves it or explicitly uses `recommended`/`recommended all`. Explicit page answers win. Template files cannot represent host paths, models, audit/delivery bypasses, or arbitrary init flags. `settings_preset.json` remains the separate post-menu portable init-setting subset; neither layer may become a competing authority over confirmed current-build answers.
**What would be a regression:** Marking templated pages complete at initialization; removing questions because a template supplied a value; letting a template start planning or `init_build.py` directly; allowing hidden execution/safety controls in the template schema; silently ignoring inapplicable defaults without recording them; persisting the external template path; letting a template override an explicit page answer; or merging templates and `settings_preset.json` into two competing sources of truth.
## DR-112: Dashboard artifacts are projections, never authority
**Class:** Invariant
**Decision:** `artifacts/dashboard/*.json` may join and reshape existing build contracts for renderer consumption, but `manifest.activation_graph.edges` remains the only activation-edge authority and no dashboard field becomes planning, audit, or delivery input.
**What would be a regression:** Computing an opaque aggregate score; fabricating relationship/era/source edge tables as manifest authority; letting dashboard JSON drive generation or gates; or hiding unavailable dimensions behind guessed values.
## DR-113: Compatibility refresh detects drift but never certifies
**Class:** Invariant
**Decision:** `references/compatibility-baseline.json` freezes claim-level checks for the named SillyTavern profile and `compatibility_check.py` compares both upstream source and WorldBuilder's local claims against that baseline. Results are only `clean`, `drift`, or `error`; the checker never rewrites the baseline and always emits `compatibility_certified: false`. A new SillyTavern version requires explicit fixture acceptance plus a deliberate profile/baseline update.
**What would be a regression:** Hashing whole upstream files as the compatibility contract; silently updating expected values from fetched source; treating a network error as compatibility drift; declaring a new version supported because checks are clean; or allowing local docs/constants to diverge from the same frozen claim without reporting it.
## DR-114: Public diagnostics export metadata by default, never private content
**Class:** Invariant
**Decision:** `diagnostics_bundle.py` is export-only. Its default public ZIP contains build-state structure plus a small allowlisted summary, receipt/gate metadata and exact hashes rather than raw receipts, a path/URL/email/quoted-value-scrubbed excerpt of one explicitly supplied failing-gate output, and a detail-stripped `probe_capabilities()` projection. It never includes raw input, research/evidence corpora, or generated prose by default. `--include-generated-content` is an explicit opt-in limited to final/merged/phase generated bytes; input/research/evidence remain excluded even then.
**What would be a regression:** Copying raw `build-state.json` or raw receipts by default; including any `input/`, research, evidence ledger, or source corpus; including generated content without explicit opt-in; exposing workspace/home paths, URLs, emails, or quoted gate payloads in the public excerpt; treating the diagnostics ZIP as a gate receipt or delivery artifact; or mutating build state while exporting.
## DR-115: Property tests replay real invariants with explicit seeds
**Class:** Invariant
**Decision:** Compiler-core property/fuzz tests use deterministic integer seeds and exercise the existing stable-identity registry, activation-map validator, semantic target adapter, and pruning/lock owners directly. Failure output must identify the replay seed, and mutation sentinels must prove the same real oracles reject deliberately broken states; a second validator/compiler or a new runtime dependency is not introduced merely to make fuzzing possible.
## DR-116: Accepted free-form build conditions require a named trace to consumption
**Class:** Invariant
**Decision:** The accepted settings-menu `[3] Conditions & Modifications` value is frozen verbatim at `build-state.settings.conditions`, copied verbatim during planning to `manifest.architecture.build_conditions`, and consulted by generation before scope/exclusion decisions. `planning_gate.py` proves exact presence/equality when the frozen value is non-empty; it does not pretend to judge whether free-form prose was semantically applied correctly.
## DR-117: Agent-reported capabilities are re-checked at their effect boundary
**Class:** Invariant
**Decision:** A capability that changes generation behavior is reported by the current agent/host rather than inferred from a model name, and is re-checked immediately before the behavior takes effect. Vision therefore re-resolves against the actual generation model before dispatch and after a route change. A text-only-to-vision flip after generation work exists cannot silently rewrite or strand earlier work; the user chooses `rerun_all`, `new_work_only`, or `stay_text_only` before dispatch continues.
## DR-118: Frozen sparse defaults are materialized before merged output leaves the compiler
**Class:** Invariant
**Decision:** When a portable lorebook entry omits a field whose frozen planning contract says omission inherits a default, `merge_phases.py` materializes the resolved value before writing merged output. Manifest-owned emission wins, then frozen layer override, then frozen profile default, then frozen field-registry default; explicit values are never overwritten and runtime-only semantics remain adapter-owned.
## DR-119: Probe receipts bind results to the exact bytes that were probed
**Class:** Invariant
**Decision:** Runtime adapter receipts keep source lineage separate from import-probe attribution. `source`/`source_sha256` identify the pre-adapter input; `probed_path`/`probed_sha256` identify the exact emitted bytes inspected by the SillyTavern import probe, including `card.json` inside CHARX when applicable, and receipt validation recomputes that binding.
## DR-120: Metadata-only amendments preserve prose and the immutable base chain
**Class:** Invariant
**Decision:** A non-structural change set may use `selective_regeneration.py metadata-reemit` to resolve only declared activation/runtime metadata for its changed UIDs. Existing entry content hashes must remain unchanged, `phase-0001.json` is retained/rebound, prior delivered bytes are copied to `creations/history/`, and the original 15-stage receipts stay immutable. The changed slice receives a scoped post-generation audit, a seal_version 4 amendment seal, then an additive amendment sub-ledger before ordinary delivery.
## DR-121: Receipt-chain repair may repair links, never evidence
**Class:** Invariant
**Decision:** `pipeline_stage_gate.py --restamp ... --cascade` may rewrite only downstream `previous_receipt_sha256` links after re-validating each downstream stage against its own current evidence. A downstream contract/evidence mismatch stops the cascade and requires normal invalidation/re-proof.
## DR-122: Declared recursion terminals must resolve to runtime recursion prevention
**Class:** Invariant
**Decision:** An entry declaring `recursion_role` `leaf` or `blocked` must resolve `prevent_recursion: true` after manifest, layer, and profile inheritance. A contradictory resolved state blocks activation-map validation and is surfaced by diagnostics; layer defaults cannot silently defeat entry-level terminal intent.
## DR-123: Consequential overrides require explicit person confirmation; environment choices are frozen
**Class:** Invariant
**Decision:** A rollback that overwrites a user lock requires both the explicit override flag and recorded person confirmation. Discovery waivers use their hash-bound approval files and stated eligibility criteria. SillyTavern extension selection/detection is frozen as raw requested/detected/resolved values with no claim that detected means enabled. Public-web readiness is owned solely by `searxng_preflight.py`, not a decorative capability snapshot.
## DR-124: WorldBuilder-authored Regex is verified, character-scoped, and approval-gated
**Class:** Invariant
**Decision:** Graphics Designer Regex must pass real matching, non-matching, and bounded adversarial execution before serialization; deterministic diagnostics flag greedy repeated-delimiter spans, catastrophic-backtracking shapes, and missing/stale verification. WorldBuilder bundles only character-scoped scripts through `extension_adapter.py`, and explicit person approval is required before a generated Regex may be delivered. Imported third-party Regex remains outside this authoring receipt unless WorldBuilder adopts it.
## DR-125: Tracker authoring owns state schema, not a competing renderer
**Class:** Invariant
**Decision:** Graphics Designer tracker requests compile into the existing MVU-compatible `[InitVar]` World Info state contract through `extension_adapter.py`. WorldBuilder may recommend an existing compatible display template but does not invent tracker HTML; a custom display is a separate manual task.
## DR-126: Verified greeting HTML may ship without a second approval gate
**Class:** Invariant
**Decision:** HTML/CSS authored for `first_mes` must pass structural parsing and reject script elements/inline event handlers before bundling. Its verification binds the exact greeting bytes. Unlike generated Regex, verified greeting markup does not require a separate approval receipt because it is already the user-visible first message reviewed with the card.
## DR-127: Model-facing fields address the world, never a reader
**Class:** Product default
**Decision:** `description` states facts about the world in the third person: no fixed protagonist exists, and NPCs, factions, and events respond to whichever role, history, and actions a participant brings. Model-facing fields never address a reader with "you/your" and never read as catalog or back-of-cover marketing copy. `writing_quality.py`'s description-voice check (`validate_description_voice`; CLI `check-description`) flags second-person address outside legitimately quoted example text for review, never auto-rewrite.
## DR-128: The world index is a rendered roster that never recurses
**Class:** Product default
**Decision:** A lore-bearing build may carry one optional `world_index` entry: a constant, `before_char` roster of canonical subject names, rendered from the manifest by `scripts/world_index.py` and never authored by a generation worker. It declares `recursion_role: blocked`, an empty `activation.emits`, no graph edges, and `prevent_recursion: true`. A roster name must be one of that entry's own primary keys. Membership is opt-out via `architecture.index_member: false`; an optional `architecture.index_gloss` adds at most six words. Multi-era builds carry one index per era, each scoped to a single era id, gated on that era's own token with AND ALL at cascade level 1, and listing only subjects that exist in that era (era-scoped subjects of that era, plus subjects with no era scope). The index is budgeted against the frozen profile's constant meter, and overflow is a split signal, never a trim.
**What would be a regression:** Letting the index emit graph terms or resolve `prevent_recursion: false`; a worker writing or editing roster content; a roster name that is not a primary key of the entry it advertises; listing era-scoped subjects under multi-era routing; truncating an oversized roster instead of reducing membership; budgeting it against corpus size (DR-067); or letting it drift into reader-facing catalog voice (DR-127), which `world_index.check_voice` blocks.
## DR-129: The era root carries the token; the era index carries the roster
**Class:** Approved redesign
**Decision:** An era root is constant and carries only its token, `CURRENT ERA`, `WORLD STATE THIS ERA`, `ABSENT THIS ERA`, and `KNOWLEDGE LIMITS THIS ERA`. The `ACTIVE ...` rosters move to a separate per-era index entry (layer `world_index`, cascade role `context`, level 1) gated on that era's token and carrying `prevent_recursion: true`. `core_invariant` entries are no longer ungated: `UNGATED_ROLES` is empty and a core now carries AND ANY over exactly the tokens of the eras its subject exists in, so nothing in a multi-era book can activate without an era linked to it.
**What would be a regression:** Returning the `ACTIVE ...` rosters to the era root; an era index that is constant, ungated, or recursion-feeding; a core with no era tokens, with AND ALL logic, or with secondary keys that are not era tokens; or more than one index owning a single era.
## DR-130: A vision-budget handoff stops only at a validated write boundary
**Class:** Product default
**Decision:** A generation session that accumulates images may stop early only immediately after a write checkpoint validates. `entry_cycle_gate.py` returns `continue`, `handoff_after_this_uid`, or `handoff_now` from the write stage. A handoff receipt is partial (`status: partial_handoff`), never a completion, and `phase_gate.py --stage pre-merge` refuses a phase carrying an unresolved partial handoff. `session_images` restarts for each replacement worker while `total_images_consumed` carries the build-level total, and `verify_image_coverage` reconciles that total against the assignment's expected per-UID counts. A single UID that cannot fit one whole session is a hard error naming the UID, never a handoff loop, and missing or stale researched limits refuse image-bearing dispatch rather than defaulting.
**What would be a regression:** A handoff allowed anywhere but a validated write boundary; a partial receipt that passes for a complete one or merges at pre-merge; per-session counters that reset without the build-level total surviving; coverage skipped while images were expected; or a guessed session limit where research is absent.
