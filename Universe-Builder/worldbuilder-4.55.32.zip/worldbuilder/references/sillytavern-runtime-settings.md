# SillyTavern Runtime Settings

## Navigation

- [Why this file exists](#why-this-file-exists)
- [Settings the era cascade requires](#settings-the-era-cascade-requires)
- [Graceful degradation](#graceful-degradation)
- [Where the block is delivered](#where-the-block-is-delivered)
- [Verification procedure](#verification-procedure)
- [Do not change these silently](#do-not-change-these-silently)

## Why this file exists

Some WorldBuilder architectures depend on host settings WorldBuilder cannot set. A
lorebook can declare `constant`, `selective`, and `delayUntilRecursion` on its own
entries, but it cannot turn on Recursive Scan or raise Max Recursion Steps; those
live in the user's World Info activation settings.

Never assume the defaults. State the requirement, deliver it with the artifact, and
tell the user how to confirm it worked.

## Settings the era cascade requires

Applies to every `worldbuilder-era-root-v1` build. Generate the exact block with:

```bash
python3 {baseDir}/scripts/era_root_contract.py settings \
  --era-root-plan /absolute/path/to/artifacts/era-root-plan.json
```

| Setting | Required value | Why |
|---|---|---|
| Recursive Scan | ON | The cascade below the root is recursion-activated. Off means nothing below level 0 fires. |
| Max Recursion Steps | ≥ deepest cascade level + 1 | A four-level tree with steps set to 2 dies at level 2. Default profiles use 4. |
| Min Activations | 0 | SillyTavern documents Min Activations and Max Recursion Steps as mutually exclusive. A non-zero value disables the recursion budget the cascade depends on. |

`era_root_contract.py` blocks planning when the declared `runtime_requirements` do
not satisfy all three, so a build cannot reach delivery advertising a cascade its
own settings contract forbids.

## Graceful degradation

The era root is `constant`, so it loads even when recursion is off. The user still
gets the era frame, the absence roster, and the knowledge ceiling; correct content,
much thinner than intended. This is deliberate: a misconfigured host produces a
weaker book, never a wrong one.

Say this plainly in the delivered notes. A user who sees only the frame should be
able to diagnose it themselves rather than concluding the book is broken.

## Where the block is delivered

Every era-root build carries the settings block in **Creator Notes**. That field
travels with the card and with a standalone lorebook export, and SillyTavern shows
it on import.

Do not put it in the System Prompt, Post-History Instructions, or a lorebook entry.
Those are model-facing prompt surfaces; this is a human instruction. Sending setup
directions to the model wastes context and can leak into prose.

The delivery gate rejects an era-root build whose Creator Notes lack the block.

## Verify automatically when the install is readable

```bash
python3 {baseDir}/scripts/sillytavern_install.py locate
python3 {baseDir}/scripts/sillytavern_install.py preflight --root <confirmed root> \
  --required-recursion-steps <cascade depth + 1>
```

Each setting is reported as `ok`, `problem`, or `unknown`. `unknown` means the key was
not found under a name this reader recognizes: SillyTavern's `settings.json` schema has
not been verified against a running instance, so an unrecognized key is reported rather
than assumed. Fall back to the manual procedure below in that case.

Findings are advisory. Never fail a build because the reader could not locate or parse an
install; every build works without one.

## Verification procedure (manual)

Give the user a check they can run in under a minute:

1. Enable exactly one `Era: ...` root entry; disable the others.
2. Send one message.
3. Open the World Info activation log.

Expected: the era root plus its era context, and any subject entries whose keywords
appeared. Root only means Recursive Scan is off or Max Recursion Steps is too low.
Two roots means two eras are unlocked at once; disable one.

## Do not change these silently

The required values come from the cascade depth in the approved era-root plan. If a
build genuinely needs a different depth, change the plan and let the contract
recompute the requirement. Never hand-edit the block to match a user's current
settings; that inverts the dependency and ships a book whose gates do not hold.

If a user cannot or will not change their settings, say so directly and offer the
single-era route instead. A single-era build needs none of these settings.
