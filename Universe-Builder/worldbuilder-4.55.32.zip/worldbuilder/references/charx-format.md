# CHARX Packaging
## Navigation
- [Contract](#contract)
- [Assets](#assets)
- [Portable paths](#portable-paths)
- [Build command](#build-command)
- [Validation](#validation)
## Contract
A CHARX file is an unencrypted ZIP with `card.json` at the archive root. `card.json` must pass the complete Character Card V3 validator before packaging and after reopening the archive.
## Assets
Describe each embedded asset in `data.assets` with `type`, `uri`, `name`, and lowercase `ext` without a leading dot.

Use standard CCv3 types (`icon`, `background`, `emotion`, `user_icon`, or `other`). Application-specific types require an `x_` prefix. Generic audio and unknown files default to `other`; do not invent a `voice` or `asset` type. Preserve imported valid descriptors.

Embedded descriptors use `embeded://<safe-archive-member>`. Multiple icon or background assets require exactly one descriptor named `main`. Remote/default assets may use a supported HTTP(S), data, or `ccdefault:` URI and are not silently downloaded.
## Portable paths
Every archive member path component uses portable ASCII, `/` separators, and no traversal components. Reject absolute paths, `.`/`..`, control characters, Windows-reserved names, non-ASCII parent directories, symlinks, and case-insensitive duplicate names.
## Build command
Package complete asset and module directories:

```bash
python3 {baseDir}/scripts/build_charx.py \
  --card card.json \
  --output card.charx \
  --assets ./assets \
  --modules ./modules
```

The legacy positional card path also works:

```bash
python3 {baseDir}/scripts/build_charx.py card.json --output card.charx
```

Use only readable local files. The builder preserves existing creation/modification timestamps; update `modification_date` only when the card content itself is intentionally released as changed.

For runtime-adapter CHARX conversion, provide an explicit JSON object mapping every embedded descriptor URI to one readable source file:

```json
{
  "embeded://assets/icon.png": "/absolute/path/to/icon.png"
}
```

Pass it with `runtime_target_adapter.py export ... --target charx --asset-map asset-map.json`, or place it at the build-state `runtime_asset_map` path. Missing, unused, duplicate, unsafe, or unreadable mappings block packaging.
## Validation
After building:
1. Reopen the ZIP and verify safe member names.
2. Confirm `card.json` exists exactly once and decodes as strict UTF-8.
3. Run the complete CCv3 validator on reopened `card.json`.
4. Verify each embedded descriptor points to a packaged member.
5. Confirm archive CRC/integrity and semantic round-trip receipts.
6. Test actual import in a named runtime before claiming live compatibility.
