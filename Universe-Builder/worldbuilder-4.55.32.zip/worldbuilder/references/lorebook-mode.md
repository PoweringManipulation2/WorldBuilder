# Lorebook Mode
## Navigation

- [Choose the target](#choose-the-target)
- [Workflow](#workflow)
- [Activation design](#activation-design)
- [Validation](#validation)
## Choose the target

Select one explicit output:

1. **CCv3 standalone lorebook** - `{ "spec": "lorebook_v3", "data": { ... } }`. This is the portable Simple Mode target, not a direct SillyTavern 1.18 World Info import.
2. **SillyTavern-native World Info** - top-level native export fields. Choose this explicitly for direct World Info import.

Do not mix the two shapes or call one the other. Preserve an imported native container style during a preserve-format update. An explicit conversion to `sillytavern-native` may normalize entries to a UID-keyed object.
## Workflow

1. Initialize a `lorebook` build with schema 3 and the selected era mode.
2. Lock source stance and target serialization.
3. Complete discovery/source synthesis. For multi-era, propose and obtain approval for `era-plan.json` before manifest creation.
4. When characters are present, build and bind `character-plan.json`; freeze `placement-plan.json`; then build the manifest, build list, and recursion map and run the architecture and placement planning gates.
5. Run the pre-generation gate and four-lens audit.
6. Generate World Invariants and Era Contexts first, then chronological era-state phases; every worker uses interleaved research/write entry cycles.
7. Run pre-merge gate and deterministic merge.
8. Validate using `spec` for portable `lorebook_v3` or `sillytavern` for native World Info, then run `sillytavern_import_probe.py` to distinguish direct import from preservation-only output.
9. Audit, verify patches, run the architecture output gate, seal, and release.
## Activation design

Specify per entry:

- Direct keys/regex or vector-only intent.
- Optional filters and logic.
- Constant status.
- Purpose-based placement/order resolved through the frozen placement plan.
- Recursion behavior.
- Probability/groups/timed effects when relevant.
- Character/persona filters when relevant; active character filters require native World Info because the embedded card converter does not map `extensions.character_filter`.
- Regex intent; the named SillyTavern profile translates CCv3 regex mode to slash-delimited regex keys.

These settings are configurable. WorldBuilder presets are starting points only. Book-level scan depth, token budget, and recursive scanning remain portable metadata because SillyTavern 1.18 controls them globally.
## Placement and influence

Simple Mode uses automatic purpose-based placement. Advanced Mode may review or customize it. World Core, World Invariants, and Era Contexts remain before character definitions; ordinary entity state follows character definitions. At-depth and outlet placement require explicit target support and additional fields. Read `prompt-placement.md`.

## Era and character architecture

Ask whether the lorebook is single-era or multi-era. Multi-era builds require an approved era-plan v2, World Invariants, one executable Era Context per era, Scenario-matched selective state entries, temporal event reach, and architecture-gate receipts. Read `era-system.md`.

All character entries use `character-template.md` and `character-identity-system.md`; source depth changes length, not section semantics. Every generated character UID belongs to one planned state, and directed relationship records control required `CONNECTIONS` names and any deliberate recursion edges.

## Validation

```bash
python3 {baseDir}/scripts/validate_output.py lorebook.json --profile spec
# or for ST-native World Info
python3 {baseDir}/scripts/validate_output.py world-info.json --profile sillytavern
```

A lorebook-bearing release must use `delivery_gate.py --build-state`; the audit bypass is not eligible.

For multi-era builds, the era router owns exact Scenario phrases, boundaries, world state, active-entity graph seeds, past/future events, knowledge restrictions, state assertions, and prohibited state terms. Exactly one era line may be active in Scenario.

Before release, read `full-integration-acceptance.md`; require the frozen route-specific integration plan and current receipts, skipping only systems marked not applicable.
