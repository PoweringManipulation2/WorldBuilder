# Config Mode
## Navigation
- [Purpose](#purpose)
- [Home Config menu](#home-config-menu)
- [Interface behavior](#interface-behavior)
- [Rules](#rules)
- [Build freezing](#build-freezing)
## Purpose
Open Config Mode when the user says `config`, `settings`, `configuration`, `model settings`, `advanced mode`, `simple mode`, or selects **Config** from the greeting.
During an active build, ask whether the user means:
1. Current build settings
2. Global WorldBuilder config
Global Config is stored in the approved WorldBuilder workspace `config.json`. It persists between sessions. Existing builds keep their frozen settings unless explicitly migrated.
Shareable project defaults are separate from Home Config. Read `references/settings-presets.md` when the user wants to export, import, or share a `settings_preset.json`; applying one never mutates `config.json`.
Reusable guided build templates are also separate from Home Config. Read `references/build-templates.md`; they prefill the normal setup pages before build initialization and never mutate `config.json`.
## Home Config menu
```text
⚙️ WORLDBUILDER CONFIG
[1] 🧭 INTERFACE MODE
    Controls which build-settings menu appears in future sessions.
    [simple] Compact guided menu with safe named choices
    [advanced] One comprehensive menu containing both standard
               and expert settings
    Default: simple
    Current: <simple | advanced>
[2] 🧠 MAIN AGENT MODEL
    Coordinator model used by new or unpinned OpenClaw sessions.
    Enter provider/model, or [default].
[3] 🐦 CHILD WORKER MODELS
    `subagent` is the backward-compatible default for every child worker.
    Optional role overrides: discovery, generation/recovery, and audit.
    Optional strategy: cheap, standard, or maximum-quality. Strategies route
    only between your configured main/subagent models; they never invent a model.
    Enter provider/model for a role, or [inherit].
[4] 📦 GENERATION BATCH SIZE
    Maximum entries assigned to one generation worker.
    Choose 1-50. Default: 15.
    Ordering remains research one → write one → next (the fixed research-one/write-one cycle).
[5] 🔁 DISCOVERY RETRY LIMIT
    Independent recovery-worker attempts on a stubborn URL before it is
    confirmed dead and routed to exclusion approval instead of another retry.
    Choose 0-5. Default: 2. A build's own settings ([9] on Advanced Page 1)
    may override this default for that build only.
[6] 🤖 AUTONOMY
    How far the model may proceed without asking you.
    [consent-required] Every discovery stop and exclusion needs your words
    [evidence-bounded] The model may self-approve only where the build's own
                       evidence proves closure: frontier closed, all expected
                       URLs accounted for, all exclusions classified non-content
    Default: consent-required
    Scope decisions are never self-approvable under either setting. A
    self-approval is recorded as AUTOMATIC, with its reason, in the audit trail.
[7] 🐞 DEBUG LOG
    Record failing commands with their exact reproduction steps.
    [off] No problem log
    [on] Every failing command is recorded, auto-classified by cause and
         tagged with the pipeline stage it happened in
    Default: off
    Export a shareable report with `debug_log.py export`; workspace and home
    paths are masked. Chats and artifact content are never read.
[8] 🏷️ UNVERIFIED ENTRY POLICY
    Default handling for entries the verification budget does not reach.
    [disable] Ship them disabled; enable knowingly
    [deprioritize] Verified entries win the budget when both match
    [despecify] Strip falsifiable specifics, keep atmosphere
    [ship_labeled] Ship as-is with confidence stated in the report
    Default: deprioritize. A build may override this for that build only.
[9] 🎨 IMAGE GENERATION MODEL
    Populated live from image_generate's action:"list", never a hardcoded
    provider name, since availability changes independently of this skill's
    own version. Only shown when image_generate is available at all
    (capability_probe.py gates this; the item is absent, not disabled,
    otherwise).
    Enter a listed model, or [primary] to use image_generate's own default.
    Optional: a fallback order (comma-separated, tried in sequence if the
    primary model errors), and a per-call timeout in ms.
    Default: [primary], no fallbacks, image_generate's own default timeout.
[9A] 🖼️ IMAGE ANALYSIS MODE
    Should generation workers inspect relevant wiki images during appearance research?
    [on] Analyze the entry's primary/infobox image when vision is reported available; research and record the model's real image limits first (vision_parameters.py)
    [off] Text-only research
    Default: on. If vision is unavailable or unreported, the effective build setting
    automatically degrades to off; WorldBuilder never guesses capability from model names.
    Optional: cap concurrent image-analysis subagents for cost or rate limits; dispatch math otherwise uses the model's real image-per-request limit alone (`vision_parameters.py plan --max-concurrent-subagents N`).
    Session budget: a generation worker tracks a researched per-session image limit; at the soft threshold it finishes its current UID and hands off, and a replacement resumes the same assignment with a fresh session budget. Set the soft percent or an optional cap from Advanced Page 3 settings [20B] and [20C]. Missing research refuses image-bearing dispatch instead of defaulting it.
[10] 👁️ VIEW CURRENT SETTINGS
[11] 💾 SAVE AND VALIDATE
[12] ❌ CANCEL
Reply with a number, label, model reference, or batch size.
```
## Interface behavior
- `simple` is the default.
- `advanced` is a persistent professional-user toggle, not a per-build temporary submenu.
- In Advanced Mode, do not show the Simple build menu first. Show the single Advanced build flow from `settings-menu.md`; it already includes all standard choices.
- Changing interface mode affects future settings flows and new builds.
- Freeze the resolved mode into `artifacts/effective-config.json` and `build-state.json` when a build begins.
- Existing builds continue using their frozen mode unless the user explicitly migrates them.
- If no approved workspace exists, selecting Config must first establish/confirm the user-owned workspace, then save the toggle there. Never save it inside the installed skill.
## Rules
- Accept `simple`, `advanced`, and natural aliases such as `basic`, `normal`, `pro`, or `expert`.
- Normalize `basic`/`normal` to `simple`; normalize `pro`/`expert` to `advanced`.
- Accept only `provider/model`, `default`, or `inherit` model values.
- Accept only an integer from 1 through 50 for generation batch size.
- Accept only an integer from 0 through 5 for discovery retry limit.
- Treat batch size as a hard ceiling; dependency/token pressure may assign fewer entries.
- Show proposed changes before applying them.
- Require explicit confirmation before changing OpenClaw model configuration.
- Run `scripts/config_models.py` against the approved WorldBuilder workspace.
- Preserve every unrelated key in `config.json`.
- Use `--apply-openclaw` only after confirmation.
- Run OpenClaw config validation after applying model changes.
- Explain that changing the persistent main model does not rewrite an existing session pin. `/model default` clears a current pin.
Example interface-only change:
```bash
python3 {baseDir}/scripts/config_models.py \
  --workspace "~/Desktop/WorldBuilder" \
  --interface-mode advanced
```
Record values under:
```text
interface.mode
models.main
models.subagent
models.discovery
models.generation
models.audit
models.strategy
autonomy.mode
debug.log_problems
verification.unverified_policy
batching.generation_entries_per_worker
discovery.confirmed_dead_after_rounds; image_analysis.mode
```
## Build-level overrides
`autonomy.mode`, `debug.log_problems`, and `verification.unverified_policy` are
persistent preferences. `init_build.py` accepts `--autonomy`, `--debug-log`, and the
de-risk policy for a single build, and an explicit flag overrides the saved value for
that build only.

Never re-ask a persisted preference in the per-build settings pages. Read it from the
workspace config, apply it, and mention it only if the user asks or a build overrides it.

## Build freezing

At build creation, copy resolved values into `artifacts/effective-config.json` and `build-state.json`.

- `interface.mode` records `simple` or `advanced`.
- `interface.build_menu` records the menu contract selected for the build.
- `models.main` records the requested coordinator default.
- `models.subagent` remains the backward-compatible child-worker fallback.
- `models.discovery`, `models.generation`, and `models.audit` freeze the effective role routes after explicit overrides/strategy resolution; `models.strategy`, when selected, records the routing preset.
- `batching.generation_entries_per_worker` records the configurable 1-50 ceiling (15 by default); `image_analysis.mode` records on/off and freezes with current-session vision into `settings.effective_image_mode`.
- `discovery.confirmed_dead_after_rounds` records the configurable 0-5 retry limit (2 by default); a build's `[9]` setting may override it for that build only.
- Every discovery, generation, and audit assignment freezes `requested_model`; the legacy fallback is `models.subagent`.
- Run `model_routing.py route --assignment <path>` before an OpenClaw spawn: `inherit` means omit `sessions_spawn.model`, while a concrete value is passed exactly.
- After an accepted spawn, run `model_routing.py verify --assignment <path> --resolved-model <resolvedModel>`; a mismatch blocks that worker/wave.
- `--apply-openclaw` changes only host-level main/subagent defaults. Per-role routes remain WorldBuilder assignment-level overrides.
## Budget profile defaults

The per-build **Detail & Context Profile** is selected in the build settings rather than silently inherited from a global model/config choice. Simple Mode exposes Compact, Recommended, and Maximum Detail. Advanced Mode may choose automatic, review, or custom budget policy and may supply exact token/layer overrides.

Freeze the resolved values in `build-state.json.budget`, `artifacts/effective-config.json`, and `artifacts/budget-plan.json`. Editing global Config never mutates an existing build's frozen budget authority.
