# Prune Mode
## Navigation

- [Goal](#goal)
- [Tier reported up front](#tier-reported-up-front)
- [Replacement priority order](#replacement-priority-order)
- [Four-phase workflow](#four-phase-workflow)
- [Additional detectors](#additional-detectors)
- [Rewording guards](#rewording-guards)
- [Receipt gate](#receipt-gate)
- [Deliverables](#deliverables)
## Goal

Reduce worst-case simultaneous activation pressure, not corpus size. Total content tokens is storage, not runtime cost: a keyword-only tightening measurably reduces co-activation risk without changing a single character of content, and a prune that reduces tokens while activation pressure stays flat or grows has not actually helped. A prune is accepted when either worst-case activation pressure or total content tokens genuinely decreases; corpus-size reduction alone remains sufficient, but it is no longer the only accepted proof (DR-073). Optional frozen `pruning_objectives` (`preserve_factions`, `preserve_main_plot`) only bias review order among already-eligible candidates: they are a soft preference, not a lock, never alter SillyTavern runtime drop order, and `preserve_main_plot` matches only explicit `architecture.pruning_tags: ["main_plot"]` rather than guessing that every event is main plot.
## Tier reported up front

Call `capability_tiers.py` before anything else. A `.png` input is a card container: extract via `png_card.py` first; prune operates on the extracted JSON, and re-export (Phase B) preserves the original image bytes untouched, only the text chunk changes. Unbound (no WorldBuilder lineage, or its workspace is gone) defaults to Tier 0 and Tier 1 operations only: no declared protected set exists to check a removal against, so a heuristic could delete something critical it does not recognize (an era root, an identity kernel) without knowing it was protected. `prune_workflow.select()` enforces this against `capability_tiers.UNBOUND_MAX_PRUNE_TIER` directly; anything more destructive on an Unbound artifact requires per-UID confirmation outside this workflow, not a silent pass.
## Replacement priority order

Four tiers, most conservative first. Do not reach for a higher tier when a lower one covers the same opportunity.

**Tier 0: provably lossless, no content change:** keyword collision tightening (`tier_zero_detectors.keyword_collision_candidates`) · depth restratification (`depth_restratification_candidates`) · constant demotion (`constant_demotion_candidates`, reported only; `constant` is outside both `artifact_edit.py`'s and this module's mutable-field allowlists, deliberately, so this strategy is not executable through the automated workflow; act on it directly) · inclusion grouping (not yet detected automatically: "these entries serve the same purpose" is closer to a content judgment than the other three Tier 0 items, and a structural proxy for it would be guessing at meaning; identify candidates by hand and apply through `artifact_edit.py`).

**Tier 1: provably lossless within the graph:** ancestor-redundancy removal (dominator-proven: `ancestor_redundancy.ancestor_redundancy_candidates`) · card-shell redundancy removal (`card_shell_redundancy_targets`). Both report which UIDs are structurally guaranteed present alongside a candidate; content the candidate repeats from one of them is a safe, provable cut. Neither function detects the actual repeated content; that reading-comprehension step is an auditor's job. Ancestor redundancy only holds for an entry marked `delay_until_recursion` (proof it cannot fire outside the graph path) and excludes `vectorized` entries entirely (a path the graph does not model).

**Tier 2: judgment required:** co-activation redundancy (assign an owner rather than cutting both) · rewording under claim/term preservation · merging entries with identical activation purpose. No automated detector exists for this tier; an auditor identifies the opportunity and executes it through `artifact_edit.py`, with `rewording_guards.rewording_hard_gate` as the deterministic half of that check.

**Tier 3: real loss, needs approval:** low-value entry removal with an impact note.
## Four-phase workflow

`prune_workflow.py` implements Tier 0's automated strategies end to end.

1. **Analyze** (`analyze`) runs every built detector across the whole book: all three Tier 0 detectors, both Tier 1 checks. Keyword-collision candidates get a real, simulated projected WCSA impact (constructs the hypothetical after-state, re-runs the same simulation `worst_case_after_pruning` uses); constant-demotion and depth-restratification's `projected_savings` are explicitly `None` rather than a fabricated number, since their actual impact depends on runtime activation probability this codebase does not yet model well enough to project honestly. After current lock filters, active objectives annotate Tier 0 candidates with `objective_priority`: `wcsa_cofire_score` is the exact count of other UIDs co-fired across the existing WCSA simulations, and objective adjustment is separate advisory ordering metadata, never projected token savings. Paginated (`page`, `page_size`) on the keyword-collision projection list, the one detector output expected to grow large on a real book.
   The returned `ancestor_redundancy_engine` must name `dominator_analysis` with `executed: true`; this is the real graph-dominator pass already used by ancestor redundancy, not a second heuristic.

2. **Select** (`select`) validates a user's strategy choices against what Analyze actually found; never accepts a selection Analyze did not itself identify as a candidate. Vetoes narrow a chosen strategy down by UID. When objectives are active, their adjusted score may reorder selected Tier 0 candidates for review but does not remove, approve, or mutate any candidate. Enforces the Unbound tier ceiling when `artifact_tier` is given.
3. **Apply** (`apply_selection`) executes the validated selection against a deep copy of the artifact, exclusively through `artifact_edit.py`'s operations (`op_retag_keys` for keyword tightening, `op_move_depth` with a receipt-bound reason for depth restratification). The caller's own object is never mutated.
4. **Prove** (`prove`) binds real before/after simulations into a receipt, per-scenario (not a single blended number): each of the seven baseline simulations reports its own before/after/delta, since `worst_case_recursion_path` itself is purely graph-structural and does not move for a keyword-only change; only `common_ambiguous_term` does, and the maximum across every simulation is what makes that improvement detectable at all. Also runs the Batch 5.5 drop-order prediction (`predict_drop_order`) at the same token budget on both sides, so the proof includes whether the change alters what a real deployment would actually keep or drop.
## Additional detectors

`tier_zero_detectors.dead_entry_candidates` reports entries that never activate in any of the seven baseline simulations, split by a mechanical signal (do the entry's own declared keys appear anywhere in its own content) rather than deciding delete-vs-repair itself. `False` signals the keys may not match what the entry is actually about (a repair candidate); `True` or `None` (no keys declared) does not rule out either case. Deleting a "good entry, wrong keys" candidate by mistake is the classic prune error this split exists to prevent; the detector reports the signal, never the verdict.

`overactive_entry_candidates` reports entries activating in most simulations (default threshold: half), excluding anything already constant. Reported as worth reconsidering (constant instead of keyword-triggered, or the keys are simply too broad); neither decision is made here.
## Rewording guards

Per DR-062, scripts check structure and auditors judge meaning. `rewording_guards.rewording_hard_gate` is the deterministic half only: required emitted terms (`activation.emits`) survive, forbidden terms (`activation.forbidden_emits`) stay absent, and no number or capitalized (likely-proper-noun) token present before is missing after without being explicitly declared removed. A passing hard gate is not a claim that a rewording is faithful: whether every claim ID the original text cited is still supported by the reworded text is a reading-comprehension question for an auditor, and this function does not attempt it.
## Receipt gate

Use `pruning_receipt.py` with explicit before/after artifacts and a change declaration. Every affected UID requires a reason, activation impact, and era impact. A declared `merge_absorbs` list exempts a survivor's per-UID content growth from the otherwise-blocking check, but only for UIDs genuinely being removed in the same operation, never a blanket exemption. The receipt binds hashes, token delta, worst-case pressure delta, keyword delta, manifest, and budget plan. Protected removals, including dynamic-state membership (inclusion group, sticky/cooldown/delay, greeting-bound; read from the entry's own `worldbuilder_dynamic` extension envelope, never re-derived), are blocked unless a human explicitly approves the exact UID and reason.
## Deliverables

Return the pruned artifact and a report listing worst-case pressure change, token change, merged/removed entries, preserved critical behavior, and any known tradeoffs.
## Dynamic-state preservation

Preserve `worldbuilder_dynamic` envelopes and the frozen plan by default. Removing or merging a grouped, filtered, timed, greeting-bound, automated, or outlet-bound UID changes behavior and requires explicit review, plan regeneration, lineage invalidation, and a receipt describing the lost or replaced operation.

Before release, read `full-integration-acceptance.md`; require the frozen route-specific integration plan and current receipts, skipping only systems marked not applicable.
