# OpenClaw host adapter

This file contains host-specific dispatch instructions. Core WorldBuilder contracts use host-neutral parent-observation semantics; OpenClaw's `sessions_spawn` is one adapter that produces those receipts.

## Discovery dispatch

For each unlocked discovery assignment, call `model_routing.py route --assignment <path>` and pass its non-null `sessions_spawn_model` as `model`; null means inherit/omit. Then call `sessions_spawn` with the assignment's task, stable `taskName`, human-readable bird label, and build root as `cwd`. Pass the stamped `run_timeout_seconds` as `runTimeoutSeconds`; if this specific host rejects that parameter, record the discrepancy and use the host default. Verify the accepted spawn's parent-observed `resolvedModel` with `model_routing.py verify --assignment <path> --resolved-model <value>` before treating the run as valid. After completion, call `record_discovery_runtime.py --runtime-source sessions_spawn` with the actual child session ID, run ID, event ID, timestamps, and parent session ID. The recorder translates this host event into the host-neutral `parent_observed_child_run` receipt contract.

## Generation dispatch

For each generation assignment, resolve its frozen `requested_model` with `model_routing.py route --assignment <path>`; pass the returned non-null model exactly, or omit the override for inherit. Call `sessions_spawn` with the exact task, stable `taskName`, human-readable label, and build root as `cwd`, substituting the absolute build root into every task path and using the stamped timeout when supported. Verify the parent-observed `resolvedModel` with `model_routing.py verify` before accepting the run. Record completion through the existing parent-owned runtime recorder/ledger path. Never let a child self-certify its completion.

## Audit dispatch

Dispatch Compass, Weaver, Scout, and Warden as distinct `sessions_spawn` child runs. Before the wave, run `gate_telemetry.py stagger --ledger <build>/.work/gate-attempts.jsonl` (optionally scoped to the active provider) and start them in that order with the returned **10-60 second** spacing; with no usable history it returns the original 20-second baseline. Do not wait for one to finish before starting the next. This adaptive spacing changes start pressure only and never changes the assignment's stamped timeout. For each assignment, use `model_routing.py route` to obtain its frozen audit model, pass a concrete result exactly, and verify the accepted spawn's `resolvedModel` with `model_routing.py verify`. Use each assignment's exact `taskName`, label, stamped timeout, and build root. After each completion event, call `record_audit_runtime.py` with the actual child session ID, run ID, event ID, timestamps, and parent session ID. The recorder emits the same host-neutral `parent_observed_child_run` semantics used by every gate.

## Host capability mapping

- OpenClaw `sessions_spawn` completion observed by the parent -> `parent_observed_child_run`
- Parent-owned local process completion -> `parent_observed_exec`

The strings above are WorldBuilder semantics, not OpenClaw API names. Gates must validate these semantic values and never require an OpenClaw product-specific receipt vocabulary.
