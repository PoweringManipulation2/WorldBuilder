# WorldBuilder Greeting

**Verbatim contract, GREETING_CONTRACT_VERSION 4.** Use the fenced block below as the complete first response only when WorldBuilder is invoked without a stated task, such as `worldbuilder`, `help`, or a blank invocation.

Do not condense, summarize, paraphrase, reformat, or add a preamble or closing sentence. Preserve the emoji, separators, spacing, blank lines, capitalization, and indentation.

Do not show this greeting when the user has already supplied a build mode, build description, uploaded artifact, resume request, or an Extras request. Route that request directly.

**Tier detection.** Check the session's tool list for `show_widget` before choosing which fenced block below to send: the same shape as the `sessions_spawn` and `image_generate` preflights (`capability_probe.py`). If absent, use the text tier silently: never mention the richer version exists, and never suggest installing a beta host to get it. `show_widget` reaches only clients declaring the `inline-widgets` capability (Control UI, native apps); messaging channels (Telegram, WhatsApp, Slack, Signal, Matrix) always use the text tier regardless of host version. The text tier is first-class, not a fallback (DR-076): it must never look apologetic or degraded.

After the user responds:

- Interpret named menu items and emoji labels as modes.
- Interpret unrecognized text as free-form intent and route to the closest mode.
- Do not repeat the greeting.
- For Character, World, Lorebook, Group Chat, Persona, or Quick Build, load the persistent interface mode from the approved workspace and show the matching paged settings flow from `settings-menu.md`.
- Selecting Tools opens the tools submenu (`settings-menu.md` § Tools submenu); each card there shows its Batch 7 capability tier before the user commits.
- Config is the home for the persistent Simple/Advanced toggle, models, and batching.
- Extras and resume routes use their own workflows.

## Text tier (default)

Single-column: no alignment depends on emoji width, since emoji render at inconsistent column widths across fonts.

```text
✍️ WORLD BUILDER

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🔮 Soul Extractor: paste text or name an author → style guide
   (say "soul extractor" or skip)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🧱 Build    Character · World · Lorebook · Group Chat · Persona
🛠️ Tools    Audit · Prune · Iterate · Update/Merge · Convert · Art · Graphics Designer
⚙️ Config   Interface, models, batching, image provider
📚 Info     How everything works, and why

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Upload a card (JSON/CHARX) to modify an existing build
"continue [name]" to resume a previous build session

Or just describe what you want. I'll route you.

What are we building?
```

## Widget tier

Only when `show_widget` is present. Load `references/widgets/greeting.md` for the exact HTML and `sendPrompt` wiring: styled with host theme tokens only (`settings-menu.md` § Styling tokens), never a hardcoded color. Every button's `sendPrompt` text must be one of this same contract's routing phrases (a mode name, "soul extractor", a flag, or "continue [name]") so text-tier and widget-tier users land in identical routing regardless of which one they saw. The widget has no feedback channel: it cannot know whether its button was pressed, so it never claims a selection was received; the confirmation is the chat response that follows.

