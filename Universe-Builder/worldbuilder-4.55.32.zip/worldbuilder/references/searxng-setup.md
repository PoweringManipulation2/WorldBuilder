# Mandatory SearXNG + WARP Research Stack
## Navigation

- [Purpose](#purpose)
- [Consent-gated first run](#consent-gated-first-run)
- [Backend selection](#backend-selection)
- [OpenClaw configuration](#openclaw-configuration)
- [Startup recovery](#startup-recovery)
- [Preflight before research](#preflight-before-research)
- [Failure handling](#failure-handling)
## Purpose

Canon-heavy WorldBuilder builds can issue many discovery queries. SearXNG is the mandatory public-web research provider so workers can share one controlled metasearch endpoint. Cloudflare WARP is the default anti-blocking egress layer. An administrator-approved replacement is allowed only when documented and validated by the same preflight policy.

Never install system software, alter OpenClaw configuration, or register startup tasks without explicit user approval.
## Consent-gated first run

First produce a side-effect-free plan:

```bash
python3 {baseDir}/scripts/first_time_setup.py \
  --workspace <approved-worldbuilder-root> \
  --backend auto
```

The plan detects the operating system, Docker Compose, Python, git, WARP, OpenClaw, and supported package managers. It reports the selected backend, paths, prerequisites, startup method, and next steps. It does not create the workspace or write configuration until `--apply` is supplied.

After the user approves the plan:

```bash
python3 {baseDir}/scripts/first_time_setup.py \
  --workspace <approved-worldbuilder-root> \
  --backend auto \
  --apply \
  --install-prerequisites \
  --install-warp
```

Use only the flags the user approved. The installer:

1. Preserves existing `config.json` keys with a deep merge.
2. Creates a timestamped backup before changing an existing config.
3. Rolls the config back when setup fails after writing it.
4. Keeps all mutable stack data under `<approved-worldbuilder-root>/research-stack/`.
5. Binds SearXNG to loopback only.
6. Enables JSON output.
7. Resolves the chosen Docker image to a digest or the native repository ref to an exact commit and records it.
8. Configures and validates the OpenClaw SearXNG provider unless explicitly skipped.
9. Registers the approved startup mechanism unless explicitly skipped.
10. Starts the stack and requires a real preflight before marking setup verified.
## Backend selection
### Docker Compose (preferred)

Use:

```bash
python3 {baseDir}/scripts/first_time_setup.py \
  --workspace <approved-worldbuilder-root> \
  --backend docker \
  --apply
```

The installer pulls the requested official SearXNG image, resolves its repository digest, rewrites the Compose file to that digest, stores persistent config/cache in the WorldBuilder workspace, binds the host port to `127.0.0.1`, and uses:

```yaml
restart: unless-stopped
```

On Linux it enables the Docker service when permitted. On Windows and macOS the WorldBuilder login launcher attempts to start Docker Desktop before restoring the Compose stack.
### Native Python/source (Docker-incompatible machines

Use:

```bash
python3 {baseDir}/scripts/first_time_setup.py \
  --workspace <approved-worldbuilder-root> \
  --backend python \
  --apply \
  --install-prerequisites
```

The installer does not treat SearXNG as a standalone PyPI package. It:

- Installs or verifies supported platform build prerequisites after approval.
- The installer clones the official SearXNG repository into the workspace and installs the official SearXNG source.
- Resolves the requested ref to an exact commit.
- Creates an isolated virtual environment.
- Installs build tooling and the checked-out source.
- Writes a loopback-only settings file.
- Starts `python3 -m searx.webapp` from the isolated environment.
- Stores PID metadata and logs in the workspace.

This is a local single-user fallback, not a public production deployment.
## OpenClaw configuration

The documented plugin command is:

```bash
openclaw plugins install @openclaw/searxng-plugin
```

Configure the SearXNG base URL as `http://127.0.0.1:8888` (or the approved private endpoint) and select `searxng` as the web-search provider. When OpenClaw integration is not skipped, setup must succeed at all of the following:

1. Install or verify `@openclaw/searxng-plugin`.
2. Verify the plugin appears in `openclaw plugins list`.
3. Set the web-search provider to `searxng`.
4. Set the plugin base URL to the local endpoint.
5. Write `SEARXNG_BASE_URL` to the OpenClaw environment file.
6. Set `agents.defaults.subagents.maxChildrenPerAgent` to `20`.
7. Set `agents.defaults.subagents.maxConcurrent` to `20`.
8. Run `openclaw config validate`.
9. Attempt a gateway restart and record its result.

WorldBuilder does not immediately use all twenty slots. Discovery ramps through 4, then 10, then at most 20 concurrent bird workers after health gates pass.

Plugin installation or configuration failure blocks setup. `--skip-openclaw` is an explicit user choice, not a silent fallback.
## Startup recovery

The installer stages immutable copies of the repair scripts inside:

```text
<approved-worldbuilder-root>/research-stack/bin/
```

Startup never points back into the installed skill directory. The staged tree also carries the release `VERSION` file one level above `bin/`, so the copied scripts resolve their release version without reading the installed skill.

The platform registration is:

| Platform | Startup mechanism |
|---|---|
| Windows | Task Scheduler at user logon |
| macOS | User LaunchAgent with `RunAtLoad` |
| Linux | `systemd --user` service |

The launcher runs:

```bash
python3 <workspace>/research-stack/bin/ensure_research_stack.py \
  --config <approved-worldbuilder-root>/config.json \
  --start \
  --preflight
```

For Docker, it verifies the daemon and runs `docker compose up -d`. For the native backend, it verifies both PID identity and endpoint health before reusing a process, starts a new process when necessary, and waits with bounded health polling rather than a single fixed sleep.
## Preflight before research

Every public-web build runs `capability_probe.py` first (see SKILL.md's Capability preflight section) to report, not assume, whether `sessions_spawn`, `image_generate`, and `show_widget` are available in this session, alongside the empirical python3/SearXNG checks below. None of these block a build except python3; each missing capability degrades one specific feature and is reported honestly, never silently swapped for a guess.

Every public-web build also runs:

```bash
python3 <workspace>/research-stack/bin/ensure_research_stack.py \
  --config <approved-worldbuilder-root>/config.json \
  --start \
  --preflight
```
The low-level endpoint/egress check remains available for diagnostics. The OpenClaw host must be version `2026.6.9` or newer for the documented SearXNG plugin contract. Because host WARP health does not prove the egress of a containerized or remote SearXNG service, provide either an explicit colocation assertion or a SearXNG-host egress receipt:

```bash
python3 <workspace>/research-stack/bin/searxng_preflight.py \
  --base-url http://127.0.0.1:8888 \
  --egress warp \
  --searxng-colocated

# Remote/container service with independently produced evidence
python3 <workspace>/research-stack/bin/searxng_preflight.py \
  --base-url https://approved-search.example \
  --egress warp \
  --searxng-egress-receipt /path/to/searxng-egress.json
```

The health path:

- Parses exact WARP states; `Disconnected`, `Connecting`, `Paused`, and error states never count as connected.
- Requests WARP reconnect when permitted.
- Verifies the selected SearXNG backend is alive.
- Requires valid JSON search output and a non-empty real result set.
- Checks the OpenClaw minimum host version.
- Binds endpoint health to the actual SearXNG upstream egress by explicit colocation or a matching host-side receipt.
- Writes a diagnostic report.

A successful first-time setup does not waive per-build preflight.

Already have SearXNG running outside this skill's own install flow? Skip the full `ensure_research_stack.py` ceremony: verify directly and record a receipt in one step with `searxng_preflight.py --base-url <url> --build-state <build-state.json> ...`. A passing run writes `.work/searxng-preflight-receipt.json`; a failing run writes nothing. `ensure_research_stack.py --config` remains the right path when the skill should install and manage SearXNG/WARP itself.
## Failure handling

On failure:

1. Identify the failed layer: prerequisites, WARP, Docker/native backend, startup registration, SearXNG JSON, OpenClaw plugin/configuration, or network policy.
2. Preserve logs and the previous config backup.
3. Do not switch silently to another search provider.
4. Permit offline or user-canonical work only when public verification is genuinely unnecessary and label it accordingly.
5. Resume public-web research only after the complete preflight passes.

## Already have SearXNG working

Agent settings and research provisioning are separate concerns with different
prerequisites and different blast radius. When SearXNG already works and only the
OpenClaw settings need applying:

```bash
python3 {baseDir}/scripts/first_time_setup.py --settings-only            # plan
python3 {baseDir}/scripts/first_time_setup.py --settings-only --apply    # write
```

This touches no containers, no workspace config, and no research stack. It needs no
`--workspace`. Use it after an OpenClaw upgrade, when moving to a new machine with an
existing stack, or whenever the tuning table changes.

## No virtualization available

The Docker CLI and `docker compose version` both answer on a machine whose daemon
cannot run, which is what an environment without working virtualization looks like.
Setup probes `docker info` as well, so `--backend auto` falls back to the native
Python backend instead of failing later at image pull.

Force it explicitly with `--backend python`. That backend needs `git` plus build
prerequisites and runs SearXNG directly, with no containers. If neither backend is
usable, the error names which half failed rather than reporting a generic failure.
