# Lazy Setup and Workspace Choice
## Navigation

- [Default behavior](#default-behavior)
- [Questions to ask](#questions-to-ask)
- [Desktop and custom paths](#desktop-and-custom-paths)
- [First-time research-stack setup](#first-time-research-stack-setup)
- [Capability probe](#capability-probe)
- [Long-build session advisory](#long-build-session-advisory)
## Default behavior

Understand the requested mode first, then require one approved WorldBuilder workspace before creating build files. The user's chosen folder is the actual working root, not merely an export destination. A common default is:

```text
~/Desktop/WorldBuilder/
  config.json
  research-stack/
  builds/
```

All mutable configuration, planning artifacts, research discoveries, temporary phases, receipts, extracted files, and final creations stay beneath this root. Nothing is written into the installed OpenClaw or skill directories.
## Questions to ask

Ask only settings that change the selected mode, such as:

- Target artifact/serialization.
- Source stance.
- User content boundaries.
- Simple versus split persona.
- Optional export destination.
- Whether public-web research is required. When required, verify the mandatory SearXNG + WARP research stack before continuing.

Do not ask about vectors, child agents, or SearXNG when the requested task does not need public-web research. For canon research, treat SearXNG + WARP as a setup requirement, not an optional preference.
## Desktop and custom paths

Desktop is a valid and recommended user-selected WorldBuilder workspace when child tools can access it. Once approved, use that same root for internal build data and final creations so the user can watch artifacts appear during the build.

If the user selects an external directory:

1. Create a probe build directory.
2. Write a small probe file.
3. Spawn a child with that directory as `cwd` when parallelism is needed.
4. Confirm the child can read and write there.
5. If the probe fails, ask the user to choose another dedicated WorldBuilder workspace; do not silently move work into the OpenClaw installation.

Never scatter files across the Desktop root. Everything belongs inside the selected `WorldBuilder/` folder and a unique `builds/<build-id>/` child.
## First-time research-stack setup

Two entry points. Full setup provisions the research stack and applies agent settings.
`--settings-only` applies just the agent settings and touches no containers. Offer it
when the user already has a working SearXNG. If Docker's daemon is unreachable, setup
falls back to the native Python backend automatically; say so rather than reporting a
Docker failure.

After the user selects an approved workspace and confirms that public-web research is needed:

1. Read `references/searxng-setup.md`.
2. Run `scripts/first_time_setup.py --workspace <exact-approved-WorldBuilder-root>` without `--apply` to produce a plan. Do not append or substitute an OpenClaw installation path.
3. Explain the selected Docker or native-Python backend and any administrator prompts.
4. Obtain explicit approval before using `--apply`.
5. Apply setup, register automatic startup unless the user opts out, and configure OpenClaw.
6. Run `scripts/ensure_research_stack.py --config <config> --start --preflight`.
7. Store the successful configuration and preflight path in build state.

If Docker is unsupported, select the native Python/source backend. Do not tell the user that Docker is mandatory, and do not use a nonexistent one-command PyPI package installation.
## Capability probe

Inspect effective tools and route gracefully:

- File/Python only → sequential/offline.
- Child tools available → optional parallel workflow.
- SearXNG + WARP preflight passes → public-web source research is available.
- Preflight fails → no high-volume public-web research; use only genuine user-canonical/offline mode or stop for setup repair.
- Sandbox path inaccessible → stage inputs/worker kit inside the visible workspace.

## Long-build session advisory

Before starting a full multi-phase build on OpenClaw, raise the session-context
advisory once. Setup applies the CLI-settable OpenClaw tuning itself; the user only
has to set Settings → Context Profile to **Code Agent**. Also suggest the largest
context window the model offers, `/compact` before starting, and `/status`. Read
`openclaw-session-context.md`.

Raise it before generation, not during. Skip it entirely for single-entry edits,
audits of a supplied file, and Info Mode. It is advice, not a prerequisite: never
block a build on it.
