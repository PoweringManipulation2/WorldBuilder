# Global Rules
## Navigation

- [Authority levels](#authority-levels)
- [Source stance](#source-stance)
- [Evidence and uncertainty](#evidence-and-uncertainty)
- [Writing rules](#writing-rules)
- [Data safety](#data-safety)
- [Release discipline](#release-discipline)
## Authority levels

Keep three rule classes separate:

1. **Specification requirement**: failure makes the artifact structurally invalid for the declared format.
2. **SillyTavern compatibility behavior**: depends on a current SillyTavern feature or setting.
3. **WorldBuilder profile advice**: a tunable authoring preference; warn by default and permit overrides.

Never relabel a profile preference as a Character Card V3 requirement.
## Source stance

Read `build-state.json.source.stance` before research or correction.

- `user-canonical`: preserve user facts. Ask rather than overwrite missing details.
- `source-canonical`: favor primary or official sources and report conflicts.
- `hybrid`: preserve explicit user changes and verify everything else.

Do not require online research when the user is the sole authority for an original setting. Do not silently convert fan interpretation into canon.
## Evidence and uncertainty

For factual research:

- Prefer primary/official material, then high-quality secondary sources.
- Record URL/title/access date in the research artifact.
- Distinguish direct source facts, reasonable inference, and creative bridge text.
- Probe APIs before depending on them; honor failures, rate limits, robots, and licenses.
- Do not call an endpoint an anti-bot bypass.
- Preserve unresolved conflicts in an explicit notes section.

For user uploads:

- Resolve tool-visible attachments or inbound media first.
- Copy input into the build workspace and hash it.
- Never edit the only copy.
## Writing rules

- Write entries for activation value, not merely because a proper noun exists.
- Keep one entry focused on one retrieval purpose.
- State durable facts directly; avoid speculative padding.
- Use `{{char}}` and `{{user}}` where portability benefits from macros.
- Keep model-facing instructions out of human-only metadata.
- Use concrete behavioral cues instead of adjective lists.
- Keep greetings playable: establish location, immediate situation, and an opening for user action without deciding the user's response.
- Use `<START>` to separate example-dialogue blocks in `mes_example`; do not prepend it to first or alternate greetings.
## Data safety

- Treat the skill directory as read-only.
- Use one unique build directory and ownership marker per build.
- Resolve every mutable path through `build-state.json`.
- Reject path traversal, archive-name collisions, duplicate identifiers, and identity-mirror disagreement.
- Preserve unknown data when reading and writing supported JSON.
- Place app-specific fields under the correct `extensions` object.
- Generate legacy mirrors only when explicitly requested.
## Release discipline

A build is not complete because an agent says it is complete.

Require deterministic checks:

- JSON/persona validation.
- Manifest cross-check when a manifest exists.
- Receipt chain for lorebook pipelines.
- Exact patch verification.
- Content-bound audit seal for Schema 2/3.
- Final `delivery_gate.py` exit code zero.

A worker result is usable only when runtime status, output file, role validator, build binding, and end delimiter all pass. Missing evidence fails closed.
## Runtime and lineage invariants

- Never rewrite a dispatched discovery assignment or manually edit its hash, delimiter, task name, result metadata, or runtime receipt.
- Never fabricate a `sessions_spawn` receipt for exec work. Record the actual parent-observed backend.
- Never continue to planning from `recovery_required` without either completing recovery or producing a governed `passed_with_exclusions` receipt.
- Never renumber stable entity UIDs because taxonomy or ordering changed.
- Never write a discovery result directly to its final path; validate and commit atomically.
