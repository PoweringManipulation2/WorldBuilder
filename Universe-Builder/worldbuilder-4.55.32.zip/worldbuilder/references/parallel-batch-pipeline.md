# Parallel Batch Pipeline
<!-- phase-contract --> Exit contract: run `python3 {baseDir}/scripts/phase_contract.py --build-state <build-state> --stage <generation_dispatched>` before this stage's gate; rendered copies ship in the build's worker kit under `exit-contracts/`.
## Navigation
- [Eligibility](#eligibility)
- [Capacity](#capacity)
- [Partitioning](#partitioning)
- [Research-before-writing contract](#research-before-writing-contract)
- [Dispatch](#dispatch)
- [Completion checks](#completion-checks)
- [Merge and recovery](#merge-and-recovery)
## Eligibility
Use parallel generation only when independent work outweighs child startup/context cost and all children can access the build workspace.

Required capabilities:

- `sessions_spawn` in the effective tool policy.
- A child-visible build root.
- Sufficient per-parent/global capacity.
- `sessions_yield` or completion-event handling without polling loops.

Otherwise use `batch-pipeline.md`.
## Capacity
Determine usable capacity from actual runtime data:

```text
usable = min(global concurrency, per-parent children, allowed agents,
             independent batches, explicit cost/rate budget)
```

The minimum usable value is one. Never turn a real cap of three into a floor of four. The documented maximum is a ceiling, not a recommendation.

Each generation assignment carries a stamped `run_timeout_seconds`, a computed liveness bound (DR-064), never a flat global default. Pass it as `sessions_spawn`'s `runTimeoutSeconds` argument for that dispatch. If a worker times out, run `entry_cycle_gate.py --stage status --assignment <path>` for a paste-ready resume dispatch card naming the kept and remaining UIDs, then re-dispatch the identical assignment_id with the raised multiplier `repair_loop_guard.py` suggests. Completed checkpoints for kept UIDs are never redone.
## Partitioning
Partition by dependency and estimated token volume within the configured hard ceiling of 1-50 entries per generation worker.

Good partitions:

- Independent locations/factions.
- Character clusters with limited cross-links.
- Source ranges with separate evidence.

Keep tightly linked entries together when they fit within the ceiling. Never exceed `batching.generation_entries_per_worker`; split oversized clusters into linked phases. Reserve phase 1 shell/core work for the parent (exact `evidence_output`, claim kinds, and `map_slice` placement; see `batch-pipeline.md`).

For each child, write `.work/assignments/<taskName>.json`:

```json
{
  "assignment_version": 3,
  "assignment_id": "wb-sample-raven-phase-0002",
  "build_id": "...",
  "manifest_sha256": "...",
  "activation_map_sha256": "...",
  "field_registry_sha256": "...",
  "default_profile_sha256": "...",
  "character_plan_sha256": "... when characters are assigned",
  "map_slice": {"slice_version": 2, "entries": [], "edges": [], "character_context": {}},
  "role": "generation",
  "worker": "raven",
  "schema": 3,
  "research_mode": "public_web",
  "entries": [
    {
      "uid": 7,
      "name": "Example",
      "research_topics": ["identity", "appearance", "personality", "relationships", "history"]
    }
  ],
  "evidence_output": "artifacts/discoveries/phase-0002-evidence.json",
  "evidence_receipt": ".work/evidence-receipts/phase-0002-evidence-receipt.json",
  "output": ".work/phases/phase-0002.json",
  "end_delimiter": "END WORLDBUILDER GENERATION REPORT"
}
```

Before writing assignments, read `artifacts/effective-config.json`. The configured `batching.generation_entries_per_worker` must be an integer from 1 to 50 and is a hard maximum, not a target. Assign at least one entry to every generation child.
## Research-before-writing contract
Every generation child processes its assignment in manifest order as isolated entry cycles:

```text
research UID 1 → validate UID 1 → write/checkpoint UID 1 → validate checkpoint
research UID 2 → validate UID 2 → write/checkpoint UID 2 → validate checkpoint
…
```

Researching the whole assignment before writing is forbidden. Each cycle covers every declared `research_topics` value, records conflicts and unknowns, and runs `entry_cycle_gate.py` for research and write stages. After all 1-50 cycles pass, run the aggregate `evidence_gate.py` and assemble the phase only from validated checkpoints. The receipts bind assignment, manifest, build, UID coverage, sources, claim IDs, checkpoint hashes, and execution order. Global planning research never waives this per-entry contract.

For multi-era lore-bearing builds, generate in this dependency order:

1. World Invariants and every Era Context.
2. Era 1 state entries.
3. Era 2 state entries, continuing chronologically.
4. Truly invariant shared detail entries.

Do not mix unrelated eras inside one worker assignment merely to fill the 15-entry ceiling. For character UIDs, keep each UID bound to its exact `character_id`/`character_state_id`; the map slice supplies identity, behavior, state, knowledge, split, and directed-relationship context.
## Dispatch
Stage the worker kit with `init_build.py`, create phase 1, and run the pre-dispatch gate.

The child task is intentionally small:

```text
Read .work/worker-kit/prompts/generation-worker.md in full.
Read .work/assignments/wb_r1_raven.json and execute it exactly.
Resolve relative paths from the supplied working directory.
```

Prefer `sessions_spawn`. Put absolute parent-owned assignment, prompt, output, runtime-receipt, worker-kit, and cache paths in every task. The supplied `cwd` is still required for staged-manual relative links inside the copied worker kit; it is not a substitute for absolute artifact identity. If a child cannot resolve those absolute paths or the runtime ignores them, fall back to parent-observed `exec` with an explicit absolute `workdir`. Normalize both backends into receipt v2; never fabricate a sessions_spawn receipt for an exec worker.

After spawning all required children, use `sessions_yield` when available. Do not poll status or sleep in a loop.
## Completion checks
For each child require:

1. Runtime status exactly completed.
2. Evidence ledger covers every assigned UID and required topic.
3. Evidence receipt matches current assignment, manifest, build, and evidence bytes.
4. Expected phase file exists.
5. Phase metadata matches build ID, manifest, activation-map, registry/profile, character-plan when applicable, phase number, assignment, evidence, and receipt hashes.
6. Entry identities match the assignment; no extras or omissions.
7. Every UID cites only its own validated claim IDs and `unsupported_claims` is empty.
8. Phase JSON validates for the selected schema/target.
9. Final child text contains the exact end delimiter.

Missing delimiter means incomplete. A failure token is additional evidence, not the only way to detect failure.
## Merge and recovery
Run pre-merge gate only after all assigned phases pass. It validates the same phase set that `merge_phases.py` consumes.

On failure:

- Retry only failed assignments.
- Reduce assignment size when context/time caused truncation.
- Preserve phase number and output path.
- Re-run pre-merge gate after replacements.
- Never accept a child's prose as a substitute for its required file.
## Worker naming

Assign workers from this stable pool in order: **Raven, Magpie, Wren, Finch, Sparrow, Robin, Heron, Lark, Swift, Owl, Hawk, Falcon, Crow, Jay, Kestrel**. Use the same readable name in `worker`, `taskName`, label, assignment ID, and filename slug. Never use opaque UUID-like worker labels in user-visible logs. If more than fifteen workers are needed, reuse the pool with an explicit round suffix such as `Raven R2` and slug `raven-r2`. Recovery workers keep the next available bird name or a clear suffix such as `Wren Recovery 1`.

## Model selection

Generation assignments freeze `requested_model` from `models.generation`, falling back to `models.subagent`. Before each OpenClaw spawn, run `model_routing.py route --assignment <path>`; pass a non-null `sessions_spawn_model` exactly and omit the override for inherit. Verify the accepted spawn with `model_routing.py verify --assignment <path> --resolved-model <resolvedModel>`. Stop the wave on invalid routing or a mismatch.

## Abandoned worker events

Record superseded `sessions_spawn` run IDs in `.work/abandoned-workers.json`. Ignore later completion events from those exact IDs after verifying they are listed. Do not let stale events mutate outputs, receipts, wave health, or build state. Cancel workers through the runtime when supported; otherwise quarantine their events by run ID.

Multi-era generation assignments must carry `era_plan_sha256` and a UID-scoped `era_router_context`. Do not combine entries from unrelated eras merely to fill a batch.

## Budget-bound assignment slices

Every current generation assignment includes `budget_plan_sha256` and UID-scoped `budget_context`. Workers must not trade budget between UIDs, silently truncate content, or weaken required graph/era/relationship terms. The entry-cycle gate blocks a checkpoint above its hard limit before the next UID starts.

## Dynamic-state assignment slices

Every lorebook-bearing generation assignment includes `dynamic_state_plan_sha256` and UID-scoped `dynamic_state_context`, including only groups, greeting scopes, automation registry rows, and outlet consumers needed by those UIDs. Phase metadata repeats the plan hash. A worker may not add probability, timed effects, filters, triggers, automation, outlets, or group membership that is absent from its slice.
