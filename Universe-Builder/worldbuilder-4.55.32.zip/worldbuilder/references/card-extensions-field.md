# Card `extensions` Field
## Navigation
- [Principle](#principle)
- [Supported categories](#supported-categories)
- [Field mapping](#field-mapping)
- [Repair policy](#repair-policy)
- [Testing](#testing)
## Not SillyTavern extensions
This file governs the CCv3 `extensions` **field**: the JSON namespace where target
applications keep their own settings (`selectiveLogic`, `position`, `depth`, `group`).
SillyTavern **extensions** in the plugin sense (Expressions, Regex, Quick Replies,
Trackers) are a different thing that happens to share the word. Read
`sillytavern-plugins.md` for those.
## Principle
SillyTavern-specific settings are application extensions, not automatically Character Card V3 requirements. Preserve unknown extension data and validate only fields that are present.
## Supported categories
WorldBuilder can preserve or author target-version fields for:
- Entry strategy and optional filters.
- Extended insertion position, depth, and role.
- Recursion controls.
- Probability and inclusion groups.
- Character/persona filters.
- Timed effects.
- Vector Storage eligibility.
- Automation IDs, outlets, and target-specific metadata.
Availability and exact serialization may change by SillyTavern version. Record the tested version in `COMPATIBILITY.md` and the build report.
## Field mapping
Use one canonical internal meaning, then emit for the selected target:
| Meaning | CCv3 core | ST-native/app-specific |
|---|---|---|
| Enabled | `enabled` | inverse of `disable` where used |
| Primary keys | `keys` | `key` |
| Secondary keys | `secondary_keys` | `keysecondary` |
| Order | `insertion_order` | `order` |
| Core placement | `position` = before/after char | numeric/string extended placement |
| Stable identity | optional `id` | `uid` where supported |
Do not add both naming styles unless compatibility mode explicitly requests mirrors. If mirrors exist, they must agree.
## Exact SillyTavern 1.18 import profile
Read `sillytavern-import-contract.md` before emitting an embedded `character_book`. The named profile uses the exact application keys consumed by SillyTavern's `convertCharacterBook`; similar camelCase/snake_case fields are not interchangeable. Every JSON card must be strict UTF-8 without a BOM and pass `sillytavern_import_probe.py`. A vectorized entry with keys is intentionally hybrid, not vector-only.
## Repair policy
`repair_extensions.py` is conservative:
1. Preserve unknown fields.
2. Normalize obvious safe types only.
3. Keep CCv3 core position inside its two-value union.
4. Move extended placement into application extension data.
5. Avoid inventing optional settings.
6. Reject conflicting identity mirrors.
7. Back up in-place edits.
Use `--legacy-mirrors` only for a tested target that needs aliases.
## Testing
For every claimed target:
- Import a fixture.
- Export it again.
- Compare semantic settings.
- Verify unknown fields survive.
- Test disabled, constant, vectorized, grouped, depth-position, and recursive entries.
Without a round-trip fixture, describe compatibility as unverified rather than guaranteed.
## WorldBuilder dynamic semantic envelope
`extensions.worldbuilder_dynamic` is WorldBuilder's target-neutral Batch 8 envelope, not a SillyTavern-native compatibility claim. Preserve it losslessly during generation, merge, audit, edit, and prune. Do not mirror it into guessed application fields. Only `runtime_target_adapter.py` may map it through a named versioned profile. Portable CCv3 keeps the envelope neutral; a named target writes a compatibility report, blocks unsupported/lossy operations, and round-trips the result.
## Batch 9 adapter boundary
Read `runtime-target-adapter.md`. Semantic format and runtime profile are separate choices. `ccv3-embedded` and `lorebook-v3` are portable by default; they receive SillyTavern extension spellings only when the named `sillytavern-1.18.0` profile is selected. Native World Info always uses that profile. Generation, sweep, and audit workers do not author target-native fields.
