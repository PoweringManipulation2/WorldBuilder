# Activation Hygiene

Apply these defaults to every lorebook unless an explicit plan overrides them.

## Connectivity tiering

After merge, `ground_truth_graph.py` measures real content-key connectivity. `connectivity_tiering.py` may use that structure to assign conservative placement floors while preserving explicit authored values. Connectivity is structural importance, not scene relevance, and never replaces keyword-driven relevance.

## Direct-only cascade dampening

Use `exclude_recursion` for entries that should still activate from direct chat text but should not be armed merely because another entry mentions them. Typical examples are minor NPCs, incidental items, holidays, or other names that appear passingly in broad prose. The activation scanner calls this behavior `non_recursable`; the runtime field remains `exclude_recursion`.

Do not apply this mechanically to protected architecture roles. Era root/context/state behavior follows the era contracts and any role-aware cascade policy in the current manifest.

## Leaf recursion stop

Use `prevent_further_recursion` for genuine terminal entries whose content should not feed another recursion round. It does not block the entry itself from activating.

## Pre-ship activation scan

Use `st_activation_scanner.py` as the deterministic pre-ship diagnostic over ordinary innocuous messages and the planned era/root scenarios. Record activation counts and fan-out. High fan-out is review evidence, not by itself permission to rewrite keys or architecture.

When the build carries a planned runtime fan-out ceiling or role-aware cascade budget, the applicable architecture/delivery gate owns enforcement; the scanner provides the measured activation set used by that gate.
