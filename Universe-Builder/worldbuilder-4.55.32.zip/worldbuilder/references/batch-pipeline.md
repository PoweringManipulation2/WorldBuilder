# Sequential Batch Pipeline
<!-- phase-contract --> Exit contract: run `python3 {baseDir}/scripts/phase_contract.py --build-state <build-state> --stage <one of: generation_complete, merge_complete>` before this stage's gate; rendered copies ship in the build's worker kit under `exit-contracts/`.
## Navigation
- [When to use](#when-to-use)
- [Contract](#contract)
- [Procedure](#procedure)
- [Recovery](#recovery)
## When to use
Use sequential batching when child tools are unavailable, workload is small, dependencies are dense, rate limits require serialization, or one continuous authorial voice is preferable.

Do not switch to parallel solely because a fixed entry count was crossed.
## Contract
- `build-state.json` owns paths.
- `manifest.json` remains authoritative.
- Phases use `phase-NNNN.json` and numeric order.
- Phase 1 contains the full output shell.
- Every phase is bound to build ID and manifest SHA-256.
- Stable IDs are preserved.
## Procedure
1. Complete `pre-gen-workflow.md`.
2. Run the pre-generation gate.
3. Create a version-3 generation assignment with a validated map slice for every phase that will emit entries, including phase 1 when the parent writes entries. Character-bearing assignments also carry the bound character-plan hash and exact state/relationship context.
4. For each assignment, process each assigned UID as research → validate → write/checkpoint before the next UID, write its evidence ledger, and run `evidence_gate.py` before writing the phase.
5. Write `phase-0001.json` with shell plus only its assigned, researched entries. The parent owns this control phase: its evidence ledger must be the assignment's exact `evidence_output` (never a guessed filename), claim `kind` is limited to `direct|inference|user_canonical`, and placement comes from the assignment's `map_slice`, never a scratch copy.
6. Write additional phases in dependency-aware batches of 1 through the frozen configured maximum, which may never exceed 15 entries per generation worker. For multi-era builds, finish World Invariants and all Era Context entries first, then process one era at a time in chronological order; do not combine unrelated eras just to fill a batch.
7. Validate every phase's JSON, assignment coverage, evidence hashes, architecture receipt, activation-map lineage, character-plan lineage when applicable, and metadata immediately.
8. Run the pre-merge gate.
9. Merge:

```bash
python3 {baseDir}/scripts/merge_phases.py \
  --build-state /path/to/build-state.json \
  --schema auto
```

10. Validate the merged artifact against the manifest and evidence ledgers.
11. Run post-generation audit, verified patches, seal, and delivery gate.

The merger may read legacy `group-N-*.json` only for migration. New production writes canonical phase names.
## Recovery
If one phase fails:

- Leave successful phases untouched.
- Rewrite only the failed phase with the same phase number.
- Re-run pre-merge gate so receipts bind the new bytes.
- Re-merge and re-audit.

Never hide a missing phase by lowering an expected count after generation began.
## Dispatch-failure policy
Classify failures before retrying:

- path or stale-workspace failure: abandon run and switch to absolute-path exec fallback;
- contract mismatch: regenerate only the undispatched assignment with the current contract;
- network failure: retry with backoff, then delegate exact URLs;
- empty output: reject immediately and split or replace the worker;
- malformed JSON: keep the candidate, repair through the audited repair tool, and never modify hashes by hand.

The 4 → 10 → 20 ramp applies to primary discovery, verification, and recovery waves.

Multi-era generation assignments must carry `era_plan_sha256` and a UID-scoped `era_router_context`. Do not combine entries from unrelated eras merely to fill a batch.
## Placement-aware generation
Before dispatching a lorebook-bearing phase, require a current placement planning receipt. Every version-3 assignment carries `placement_plan_sha256` and a resolved `placement_context` for its UIDs. Workers copy those values exactly; the parent does not rebalance prompt influence by changing position or order during batching.
## Budget-aware generation and pruning
Require a current budget planning receipt before dispatch. Every generation assignment binds `budget_plan_sha256` and one exact budget row per assigned UID. Do not rebalance by silently shortening unrelated entries, lowering discovery scope, or changing graph settings during generation.

Pruning is a separate before/after operation. Run `pruning_receipt.py`, preserve stable UIDs and unrelated settings, rerun placement and budget validation, and require explicit human approval before removing any protected temporal, knowledge, identity, relationship, or activation-path content.
## Full integration
After planning, on resume, and before final delivery, run `integration_acceptance.py` as described in `full-integration-acceptance.md`. Sequential execution does not reduce the required route-level systems or acceptance lineage.
## Merge-to-audit naming transition
After merge, normalize and receipt visible labels using `entry-naming.md`; then dispatch the four post-generation auditors. This ordered transition is part of the pipeline stage chain.
