# Quick Build Mode
## Navigation

- [Purpose](#purpose)
- [Boundaries](#boundaries)
- [Artifact branches](#artifact-branches)
- [Delivery](#delivery)
## Purpose

Produce a smaller, faster artifact using the Compact Detail & Context Profile while retaining correct format and release checks.
## Boundaries

Quick Build may reduce generated depth and optional editorial polish, but additive discovery and supported inventory accounting remain intact. It may not weaken source correctness, canonical character sections, era-state splits, Era Context absence rosters and knowledge limits, format validation, stable IDs, or a required lorebook audit. A quick multi-era build may omit low-value optional entities, but it must never merge contradictory era states.
## Artifact branches

- Schema 1 card → JSON validator and direct inspected delivery path.
- Persona → plaintext persona validator and persona delivery path.
- Schema 2/3 → compact planning/generation, but still full phase receipts, audit, seal, and delivery gate.

Do not send persona text to `validate_output.py`.
## Delivery

```bash
python3 {baseDir}/scripts/validate_persona.py persona.txt --mode simple
# or
python3 {baseDir}/scripts/validate_output.py card.json --profile sillytavern

python3 {baseDir}/scripts/delivery_gate.py /path/to/output --no-post-gen-audit
```

For Schema 2/3, use `delivery_gate.py --build-state` and do not pass the bypass flag.

## Dynamic-state rule

Quick Build uses deterministic safety defaults and does not silently enable dynamic behavior. Honor an already explicit Advanced Mode request, but never invent probability, groups, timed effects, filters, automation, or outlets to make a small build feel varied.

Before release, read `full-integration-acceptance.md`; require the frozen route-specific integration plan and current receipts, skipping only systems marked not applicable.
