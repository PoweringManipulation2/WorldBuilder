# Canonical Character Format
## Navigation
- [Purpose](#purpose)
- [Canonical order](#canonical-order)
- [Section rules](#section-rules)
- [Structured character plan](#structured-character-plan)
- [Schema 1 star routing](#schema-1-star-routing)
- [Lorebook character routing](#lorebook-character-routing)
- [Scenario policy](#scenario-policy)
- [Tier and source depth](#tier-and-source-depth)
- [Multi-era characters](#multi-era-characters)
- [Validation](#validation)
## Purpose
Use one stable character structure across Character, World, Lorebook, and Group pipelines. The structure is designed for scene generation and retrieval rather than wiki-style reading. Labels provide reliable internal landmarks; prose inside each section remains natural.

Do not invent facts to fill a heading. Use the build's chosen missing-data convention consistently: omit unsupported optional detail or write `Unknown.`. Never pad a thin source.

Read `character-identity-system.md` for every generated character. The canonical prose format is the output layer of a structured identity, behavior, state, and relationship plan; it is not a substitute for that plan.
## Core and era state split
**Product default for three or more eras; opt-out available.** For two eras with thin
variation, one self-sufficient state per era is simpler and the duplication costs little.

Under the old Scenario router only one variant fired, so every era state carried all
seven sections. Voice, species, and base appearance were written once per era and could
drift between them. The cascade lets a core entry co-occur with whichever state won, so
invariant material is written once.

| Entry | Sections | Gating |
|---|---|---|
| `<Name>` core entry | VITALS (invariant subset), PERSONALITY & VOICE, APPEARANCE (base) | AND ANY over exactly the tokens of the eras its subject exists in; `era_cascade_role: core_invariant` |
| `<Name>` era state entries | TIMELINE, VITALS (mutable), CONNECTIONS, BACKSTORY, CURRENT | era token gate, level 2, in the variant group |

Two rules, and the second is the one that bites:

1. **The core is never in the variant inclusion group.** The group holds mutually
   exclusive era states; the core must co-occur with whichever state won. Putting it in
   the group drops either the voice or the situation. `era_root_contract.py` rejects it.
2. **The core must be true in every era it is gated to, and is therefore status-free
   and tense-careful.** Since Batch 58 it carries AND ANY over exactly the tokens of the
   eras its subject exists in, so it no longer fires where the character is unborn or
   long dead, but the gated subset can still span a promotion or a change of
   allegiance. "Speaks in short declaratives" is safe. "Is Warden of the North" is still
   wrong if any gated era predates the appointment.

BACKSTORY stays with the state despite feeling stable: it is *accretive*, not invariant.
Era 3's backstory contains era 1 as history, so it differs per era.

`character_contract.check_core_contamination` runs at the per-entry checkpoint and scans
core content for status, rank, allegiance, location, relationship, and knowledge claims,
the categories the World Invariants rule already forbids at world scope. This failure was
structurally impossible under the old design because everything was era-scoped; hoisting
invariants creates the place to put a wrong permanent claim.
## Canonical order
Lorebook character entries use this order:

```text
TIMELINE
VITALS
PERSONALITY & VOICE
CONNECTIONS
APPEARANCE
BACKSTORY
CURRENT
EXTRA (optional)
```

Why:

1. `TIMELINE` determines whether this state applies.
2. `VITALS` locks identity and role.
3. `PERSONALITY & VOICE` controls behavior and dialogue.
4. `CONNECTIONS` controls relationship behavior and supplies intentional recursion seeds.
5. `APPEARANCE` supports narration.
6. `BACKSTORY` explains motives without replacing current behavior.
7. `CURRENT` fixes location, goals, knowledge, and stakes for the selected timeframe.
8. `EXTRA` holds source-backed material that does not fit elsewhere.
## Section rules
### TIMELINE
State the exact timeframe, life status, applicable era, and location/availability. In a single-era build, say that it applies throughout the locked timeframe. In a multi-era build, name only the current era and do not foreshadow later changes.
### VITALS
Age or apparent age when known, species, pronouns, role, rank, and concise identity facts. Avoid mutable later-era ranks in an earlier state.
### PERSONALITY & VOICE
Behavior under pressure, contradictions, coping style, speech rhythm, vocabulary, emotional tells, boundaries, blind spots, humor, and what changes their demeanor. Demonstrate voice with a short source-grounded example when useful; do not turn this into unsupported quotation.
### CONNECTIONS
Name relationships and their state in this timeframe. Include family, allies, rivals, authority figures, romantic ties, faction connections, and unresolved tensions. Use canonical names because these are deliberate activation/recursion seeds.
### APPEARANCE
Narratively useful body, face, marks, clothing, equipment, movement, and presence. Keep era-specific forms and outfits in the correct state entry.
### BACKSTORY
Only events already past from the selected timeframe. Do not include future biography in earlier-era entries.
### CURRENT
Current location, role, goals, fears, conflicts, knowledge, available resources, and what is at stake now.
### EXTRA
Optional source-backed forms, gear, habits, contextual appearances, abilities, limitations, or other details. Omit when unnecessary.
## Structured character plan
Before manifest finalization, create and bind `artifacts/character-plan.json` under `worldbuilder-character-system-v1`.

Every character separates:

- stable identity and aliases;
- behavior and voice;
- one or more era/timeframe states;
- explicit split reasons;
- directed relationship records;
- required `VITALS`, voice, and `CURRENT` terms;
- forbidden future/knowledge terms.

Every generated character UID belongs to exactly one state. A multi-state character must be marked as a justified split. Workers receive only the relevant state plus the relationship slice and may not blend sibling-state facts.
## Schema 1 star routing
The Character card's star splits the format across standard card fields.

`personality` contains only the content of `PERSONALITY & VOICE`, without the heading.

`description` contains these headings in order:

```text
TIMELINE:
VITALS:
CONNECTIONS:
APPEARANCE:
BACKSTORY:
CURRENT:
EXTRA: (optional)
```

Do not repeat `PERSONALITY & VOICE` in Description. Do not copy the whole Description into Personality.

The manifest marks the star with:

```json
{
  "architecture": {
    "character_format": "canonical-v1",
    "character_role": "card_star",
    "character_id": "hero",
    "character_state_id": "hero-single",
    "identity_model": "structured-v1",
    "behavior_model": "structured-v1",
    "required_sections": [
      "TIMELINE", "VITALS", "CONNECTIONS",
      "APPEARANCE", "BACKSTORY", "CURRENT"
    ]
  }
}
```
## Lorebook character routing
Supporting and world characters have no dedicated card-level personality field. Their `content` contains the complete labeled format, including `PERSONALITY & VOICE`.

The manifest marks each one with:

```json
{
  "type": "character",
  "architecture": {
    "layer": "character",
    "character_format": "canonical-v1",
    "character_role": "lorebook_character",
    "character_id": "hero",
    "character_state_id": "hero-early",
    "identity_model": "structured-v1",
    "behavior_model": "structured-v1",
    "required_sections": [
      "TIMELINE", "VITALS", "PERSONALITY & VOICE",
      "CONNECTIONS", "APPEARANCE", "BACKSTORY", "CURRENT"
    ]
  }
}
```

Tier changes depth, not section meaning.
## Scenario policy
Character Mode keeps `scenario` blank by default. Greetings establish mutable starting situations without making them permanent facts.

Fill Scenario only when the user explicitly requests a fixed premise, relationship, location, or role. Record `architecture.fixed_scenario: true` in the manifest. Never decide `{{user}}`'s identity, thoughts, actions, or relationship without approval.

World Mode Scenario remains a user settings page and follows `world-mode.md` and `era-system.md`.
## Tier and source depth
- Tier A: rich personality, relationship texture, appearance, history, and current stakes.
- Tier B: all core sections with moderate detail.
- Tier C: concise sections supported by the source.
- Full Detail: source-backed length, not padding or arbitrary quotas.

A lower tier does not authorize removing timeline, voice, connections, or current-state reasoning when those facts are available.
## Multi-era characters
Read `era-system.md` in full.

Split when life status, role, allegiance, location, relationships, knowledge, form, equipment, goals, or political position changes meaningfully. Each state entry:

- uses the full canonical format;
- pins `TIMELINE` and `CURRENT` to one era;
- contains only past events and knowledge available in that era;
- uses entity primary keys plus era secondary keys;
- matches Scenario;
- uses selective AND_ANY;
- never says what will happen later.

For a Character Mode card set, create one Schema 1 card per confirmed era. Do not merge incompatible state descriptions into one always-loaded Description/Personality pair.
## Validation
`architecture_gate.py` checks:

- canonical headings and order;
- star versus lorebook routing;
- non-empty star Personality;
- blank Character Scenario unless fixed;
- multi-era future leakage using the approved era plan;
- per-era manifest coverage.

`character_contract.py` and the same architecture gate also check:

- exact character-plan/manifest UID ownership;
- stable identity and alias collisions;
- non-empty behavior models;
- justified state splitting;
- directed relationship records;
- required identity/voice/current-state terms;
- forbidden knowledge and future facts;
- relationship names in `CONNECTIONS`;
- per-entry checkpoints before a worker may continue.

These are WorldBuilder content-contract errors, not Character Card V3 schema errors.
