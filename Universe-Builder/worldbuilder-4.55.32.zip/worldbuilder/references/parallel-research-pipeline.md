# Additive Breadth-Discovery Pipeline
<!-- phase-contract --> Exit contract: run `python3 {baseDir}/scripts/phase_contract.py --build-state <build-state> --stage <research_discovery>` before this stage's gate; rendered copies ship in the build's worker kit under `exit-contracts/`.
## Navigation
- [Purpose](#purpose)
- [Hard requirements](#hard-requirements)
- [Parent probe](#parent-probe)
- [Additive source channels](#additive-source-channels)
- [Deterministic page filtering](#deterministic-page-filtering)
- [Fandom and MediaWiki page transport](#fandom-and-mediawiki-page-transport)
- [Planning and bird-named ownership](#planning-and-bird-named-ownership)
- [Worker result contract](#worker-result-contract)
- [Independent bounded coverage](#independent-bounded-coverage)
- [Saturation](#saturation)
- [Recovery loop](#recovery-loop)
- [Planning handoff](#planning-handoff)
## Purpose
Use breadth discovery to answer **what should exist in the build** before allocating UIDs. Per-UID research later answers **what is true about each selected entry**. Neither stage replaces the other.
For a known property, maximize recall first. Preserve every plausible character, alias, form, location, faction, species, item, event, system, concept, relationship, and era. Classification and priority decisions happen after collection.
## Hard requirements
- Run SearXNG/WARP preflight before public-web collection.
- Use `source_probe.py`; do not hand-author `source-probe.json` for a live build.
- Treat every usable source channel as additive. Never let a fresh but incomplete sitemap suppress AllPages, categories, search, or link discovery.
- Spawn actual breadth workers with exact URL ownership. Manual parent-agent browsing does not replace this phase. Parent inline browsing does not count as the known-property sweep.
- Record the OpenClaw completion event separately from worker output.
- Continue recovery until bounded source-set coverage and saturation both pass; for enumerable corpora a closed frontier (every expected URL accounted, zero candidates, denominators green) proves saturation directly (`saturation_policy.closure_saturates`, default true), and a deadlocked plan lists sanctioned `decision_options` instead of demanding rounds that do not exist.
- Keep every probe, assignment, result, receipt, and recovery artifact inside the build workspace.
- Respect source rate limits with bounded concurrency, shared query deduplication, jittered pacing, caching, and retry backoff.
If `sessions_spawn` is unavailable or its path resolution is broken, use the deterministic exec dispatch adapter with an explicit absolute workdir and parent-observed exec receipt. Manual ad hoc browsing does not replace assigned worker execution.
Honor source rate limits, robots rules, retry guidance, and bounded concurrency. A high-recall sweep may be broad, but it must not become an uncontrolled request flood.
## Parent probe
Run from the parent/orchestrator using the immutable installed skill:
```bash
python3 {baseDir}/scripts/source_probe.py \
  --build-state /absolute/path/to/build-state.json \
  --base-url "https://example-wiki.invalid/" \
  --searxng-base-url "http://127.0.0.1:8888"
```

The probe records source status, errors, page-count estimates, currentness, truncation, and URL provenance. Network failures remain visible; they are not converted into empty-success signals. The SearXNG harvest (~57 independent site:/term/letter queries) and BFS traversal (same-depth pages are independent of each other) fetch concurrently by default (`--search-concurrency 4`, `--bfs-concurrency 6`); raise both for a self-hosted SearXNG/wiki that can take it, lower to 1 for a shared or rate-limited target; concurrency changes wall-clock time only, never which URLs are discovered.
## Additive source channels

`source_probe.py` unions all available channels:

1. **MediaWiki site information and statistics** for an independent article-count estimate.
2. **API AllPages** for namespace-0 non-redirect pages.
3. **API redirect enumeration** so aliases and alternate titles are not lost.
4. **API AllLinks** for pages referenced from the corpus but missed by enumeration.
5. **Special:AllPages fallback** with numeric and alphabetical strata when API enumeration is absent or truncated.
6. **robots.txt and recursive sitemap indexes**, including compressed sitemap files and per-document freshness metadata.
7. **Category and subcategory traversal**, preserving category pages as traversal seeds while filtering maintenance-only categories from the final article corpus.
8. **SearXNG site-restricted harvest** using broad entity queries plus A-Z and 0-9 gap queries.
9. **Internal-link, navigation, and bounded BFS discovery** from strong seeds.
10. **Random-page and category spot-check rounds** for independent verification and orphan discovery.

A source may be stale, partial, blocked, or redundant and still contribute unique URLs. Sitemap freshness affects confidence and verification requirements; it never makes the sitemap exclusive.

Every canonical URL stores its contributing source families. Redirect titles and aliases remain evidence even when they resolve to a canonical page.
## Deterministic page filtering

High recall does not mean every discovered URL deserves an LLM summary. `source_probe.py` first preserves the complete additive URL union, then batches MediaWiki metadata requests through `discovery_page_filter.py` before assignments are created.

Pages are classified as:

- `content`: assign to a bird for entity extraction;
- `index_only`: harvest namespace-0 links deterministically, then account for the index without creating an entity;
- `reference_only`: retain as later evidence but do not create a standalone lore entry, including transcripts by default;
- `alias_only`: preserve the redirect title against its canonical target without creating duplicate work;
- `excluded`: account for discussion, Message Wall, maintenance, gallery-only, production, broken, and infrastructure pages with registered reason codes.

Canon episodes, songs, comics, and shorts remain eligible by default. Cast, crew, dubbing, localization, staff, and studio metadata are excluded unless the user explicitly enables production pages. The post-fetch classifier runs again inside each worker so stale or incomplete metadata cannot force junk into the manifest.

The plan keeps all URLs in bounded source-set coverage accounting, records `prefilter_accounting`, stores reference-only URLs and alias maps, and assigns only `worker_urls`. This preserves discovery recall while reducing model context, requests for full page bodies, and junk entities.
## Fandom and MediaWiki page transport

Treat the canonical article URL as identity, not as the only transport. Fandom's normal page HTML can be challenged while the documented MediaWiki Action API remains readable. Every MediaWiki assignment therefore uses this order:

1. `api.php?action=parse&page=<title>&prop=text|wikitext|links|categories|templates|tocdata`
2. `action=query&prop=revisions` for current wikitext
3. normal article HTML only as the last fallback

The staged child command is:

```bash
python3 .work/worker-kit/scripts/wiki_fetch.py \
  --url "<owned URL>" \
  --api-url "<assignment.fetch_policy.api_url>" \
  --cache-dir .work/page-cache \
  --output ".work/page-cache/records/<bird>/<page>.json"
```

`action=parse` provides rendered HTML with template expansion as well as links, categories, templates, and wikitext. Record the successful transport for every URL. Cache successful fetches so interrupted assignments can resume without repeating the network work. Stay on the exact source host by default; language-wiki expansion requires an explicit setting.

The collector still honors status codes, rate limits, and access controls. API-first retrieval is a supported representation, not a claim that every block can or should be bypassed.
## Health-gated worker ramp

The first discovery wave contains at most four bird workers. This can expose a bad API endpoint, blocked transport, incorrect host scope, oversized pages, or malformed worker output at low cost. After all four outputs and parent runtime receipts validate, run `discovery_wave_gate.py --wave 1`.

A passing wave unlocks up to ten assignments in wave 2. A second pass unlocks up to twenty assignments per later wave. The gate checks exact ownership, terminal failure/delegation ratio, runtime proof, and recorded fetch methods. It never unlocks a larger wave merely because the children returned prose.

For 1,051 pages at the default target of 75 pages per worker, planning creates roughly fifteen primary assignments rather than seven oversized assignments. They normally dispatch as four workers, then ten, then the small remainder plus independent verification work. Very large corpora may require additional waves of at most twenty concurrent workers.
## Planning and bird-named ownership

Create the plan after the probe:

```bash
python3 {baseDir}/scripts/discovery_plan.py \
  --build-state /absolute/path/to/build-state.json \
  --probe /absolute/path/to/artifacts/discoveries/source-probe.json \
  --max-concurrent 20 \
  --target-pages-per-worker 75 \
  --minimum-verification-rounds 2
```

The plan uses `method: additive_hybrid`, creates a canonical union, records independent lower bounds, and cost-balances exact URL partitions. It does not simply split by equal URL count when estimated page cost differs.

Assignments use version 7 and readable identities from this pool:

```text
Raven, Magpie, Wren, Finch, Sparrow, Robin, Heron, Lark,
Swift, Owl, Hawk, Falcon, Crow, Jay, Kestrel
```

Reuse names only with explicit round suffixes such as `Raven R2`. Use the same readable identity in `worker`, `taskName`, label, assignment ID, and filename slug. Never expose opaque random task names to the user.

Each assignment includes:

- Build ID and immutable assignment hash.
- Corpus hash and pass number.
- Exact owned `page_urls`.
- Source provenance and scope.
- Exact result path and parent-runtime-receipt path.
- Exact end delimiter and terminal delimiter value.
## Worker result contract

The worker reads `prompts/sweep-worker.md` and its assignment. For every owned URL it must place the URL into exactly one terminal bucket:

- `visited_urls`
- `failed_urls`
- `excluded_urls`
- `delegated_urls`

A worker may not claim another worker's URL. Every entity source URL must be one the worker actually visited. Discovered follow-up URLs go into `discovered_urls`; they do not silently change the current assignment.

The result records structured entities, aliases, concepts, relationships, source URLs, failures, unresolved items, build/corpus/assignment binding, and the exact final delimiter.

After OpenClaw reports the child completion to the parent, the parent records runtime proof:

```bash
python3 {baseDir}/scripts/record_discovery_runtime.py \
  --build-state /absolute/path/to/build-state.json \
  --assignment /absolute/path/to/.work/assignments/<bird>.json \
  --child-session-id "<actual child session>" \
  --run-id "<actual sessions_spawn run id>" \
  --runtime-event-id "<actual completion event id>" \
  --status completed \
  --spawned-at "<parent-observed timestamp>" \
  --completed-at "<parent-observed timestamp>" \
  --parent-session-id "<parent session>"
```

The recorder is parent-only and is not staged into the worker kit. A result cannot certify its own runtime.
## Independent bounded coverage

Run the gate:

```bash
python3 {baseDir}/scripts/discovery_gate.py \
  --build-state /absolute/path/to/build-state.json
```

The gate measures several independent signals:

- Exact owned-URL partition coverage.
- Visit success versus explicit failure/exclusion/delegation.
- Canonical-union coverage.
- MediaWiki-reported article lower bound when available.
- Agreement and disagreement among independent source families.
- Mandatory random/category verification rounds.
- New URLs and new entities found outside the primary corpus.
- Duplicate/redirect consolidation without discarding aliases or source evidence.

`visited / selected` is never accepted as proof that the selected corpus represents the site. A one-page sitemap visited perfectly cannot report complete coverage when AllPages or site statistics show hundreds of pages.

The gate writes visible progress and, only when all checks pass, a content-bound discovery receipt and deduplicated discovery index.
## Saturation

Bounded coverage estimates whether the planned corpus covers its declared source set. Saturation estimates whether additional search passes are still finding meaningful new material; only pure re-verification rounds (no newly covered URLs, `verification_first_contact_allowance`) count toward the low-yield chain, Chao1 stays diagnostic-only, and terminal-stop thresholds are tunable (`terminal_stop_entity_ratio`, `terminal_stop_new_url_count`).

The gate records:

- Marginal new URL yield by pass.
- Marginal new entity yield by pass.
- Source-family overlap.
- A capture-recapture/Chao1 diagnostic when overlap supports it.
- Consecutive low-yield verification passes.

A build is saturated only after the configured number of independent verification rounds complete and consecutive rounds stay below the low-yield threshold. Chao1 is diagnostic rather than sole authority. Any meaningful new entity class, unresolved alphabetical/category gap, failed owned URL, or lower-bound shortfall keeps discovery open.

The round economics are a person-facing choice, not a fixed cost: `discovery_plan.py --saturation-profile fast|standard|thorough` bundles the minimum verification rounds, consecutive low-yield proof, and confirmed-dead threshold (`standard` matches the defaults described here; `thorough` deepens the proof for large books; `fast` suits small, simple worlds). Explicit `--minimum-verification-rounds`, `--consecutive-low-yield-rounds`, and `--confirmed-dead-after-rounds` still override the preset.
## Recovery loop

A gate exit code of `2` means the run is valid but incomplete. It writes `discovery-recovery-plan.json` with exact gap URLs, required re-probes, and additional verification work.

Materialize the next assignments:

```bash
python3 {baseDir}/scripts/discovery_recovery.py \
  --build-state /absolute/path/to/build-state.json \
  --runtime-cap 5
```

Then:

1. Spawn only the new bird-named recovery assignments in a health-gated wave of at most 20.
2. Record parent-observed runtime receipts.
3. Re-run `discovery_gate.py`. For saturated small sources, a single-round waiver can satisfy the round requirement: schema, required process, and the construction helper are in `references/discovery-approvals.md`; never hand-author the approval file.
4. Repeat until the gate passes or a source remains impossible to access.

Do not erase prior successful results. Do not rerun the whole corpus merely because a few pages failed. If an independent lower bound exceeds the current union, re-probe source channels and create targeted gap work rather than declaring 100 percent coverage.
## Planning handoff

Only a passed discovery gate may feed planning. Generate:

- `artifacts/build-list.md`
- `artifacts/recursion-map.md`
- `artifacts/manifest.json`

Each artifact must bind the current `discovery_receipt_sha256`. Preserve discovered-but-deferred items with reasons instead of deleting them from the collection record. Quick mode may generate fewer entries, but it must not pretend the source contained fewer entities.

## Model selection

Discovery assignments freeze `requested_model` from `models.discovery`, falling back to `models.subagent`. Before each OpenClaw spawn, run `model_routing.py route --assignment <path>`; pass a non-null `sessions_spawn_model` exactly and omit the override for inherit. Verify the accepted spawn with `model_routing.py verify --assignment <path> --resolved-model <resolvedModel>`. Stop the wave on invalid routing or a mismatch.
## Runtime adapter and circuit breaker

Register each bird run in `.work/worker-runs.json` before dispatch. Prefer `sessions_spawn` and use absolute parent-owned artifact paths in the task text. Relative links are permitted only inside the staged worker kit and resolve from the supplied build-root `cwd`. Pass the assignment's stamped `run_timeout_seconds` as `sessions_spawn`'s `runTimeoutSeconds` argument, a computed liveness bound (DR-064), never a flat global default. If a worker times out, record it with `record_discovery_runtime.py --status timed_out` (never `--status failed`) and re-dispatch the identical assignment_id with the raised multiplier `repair_loop_guard.py` suggests; the page cache skips URLs already fetched, so no completed work repeats. If the canary wave proves that worker path resolution is broken, abandon those run IDs, cancel them where supported, and use the deterministic exec fallback with an explicit work directory. Record the actual backend in receipt version 3.

Never retry a shared failure blindly. Two matching path, contract, or output-format failures trip the circuit breaker. Repair and re-run the canary before unlocking larger waves.

## Terminal leftovers

Discovery can end with pages that were never resolved. Dropping them silently makes a
build look complete when its coverage was capped by exhaustion rather than by scope.

Record a governed approval instead:

```bash
python3 {baseDir}/scripts/discovery_exclusions.py --build-state <path> --approve
```

The approval is what lets the build report `passed_with_exclusions` honestly, and it
supplies the deferred-scope list the creator notes block prints under
"Deliberately not covered".

## Saturation on small corpora

The saturation threshold is `max(minimum_new_entities_floor, floor(entity_count * low_yield_entity_ratio))`.
The ratio is tuned for large wikis; the floor is what keeps it survivable below roughly
500 entities, where the ratio alone rounds to zero and a single first-contact entity in a
verification round fails an otherwise fully covered sweep.

Both defaults now match the gate's own (`floor: 2`, `ratio: 0.002`). Raise the floor for a
genuinely small catch-all wiki rather than loosening the ratio, which would weaken large
sweeps too. Never edit a discovery receipt to work around a saturation failure: the stage
ledger hashes it, and the edit invalidates the pipeline.

## Dead links and the retry limit

`discovery.confirmed_dead_after_rounds`, the DISCOVERY RETRY LIMIT in Home Config,
bounds how many independent recovery rounds a failing URL gets. A URL that reaches it is
tagged `confirmed_dead_pending_exclusion` **and** `retry_budget_exhausted`, and is dropped
from `recovery_actionable`, so no further recovery worker targets it.

Exhausting that limit does not need a separate approval. Choosing not to fetch a URL
removes possible canon and is the user's decision; a URL that cannot be fetched after the
number of attempts the user configured contains nothing to remove. Setting the limit is
the consent, and `closure_is_proven` treats those exclusions as pre-authorised.

Every other exclusion class still requires approval. A URL classified as content is
withheld canon regardless of how the build reached that decision.

## Reading the page filter split

The filter classifies by **structure**: namespace, redirect status, gallery/transcript
shape, production scope. It does not judge article quality, and a maintenance or cleanup
tag never excludes a page: those categories are full of real articles, and on wikis that
tag most stubs, excluding on them silently removes primary content.

Quality-tagged pages are kept and marked `quality_flag`, listed in
`quality_flagged_content` so an auditor can see which articles are thin.

Check `review_flags` before dispatching workers. It fires when content falls below a
quarter of all pages, or when any single exclusion reason (other than broken redirects
and aliases) accounts for more than fifteen percent. A filter that drops most of a wiki
is far more likely to be misclassifying than to have found a wiki that is mostly junk.

Spot-check the dominant exclusion bucket by opening two or three of its URLs. Recovering
misfiled pages later needs a supplemental discovery pass; catching them here costs one
minute.
