# Splitting Workflow
## Navigation

- [When to split](#when-to-split)
- [How to split](#how-to-split)
- [Cross-file rules](#cross-file-rules)
- [Validation](#validation)
## When to split

Split an artifact when independent usage, import limits, maintenance boundaries, or token budgets justify separate files. Do not split merely because a fixed entry count was exceeded.
## How to split

Partition by retrieval/ownership boundary, for example:

- Core world versus optional region packs.
- Shared group lore versus character-private lore.
- Persona core versus conditional deep lore.
- Canon material versus user AU additions.
## Cross-file rules

- Preserve stable IDs within each file; document any namespace changes.
- Avoid duplicate constant rules across every file.
- Record dependencies and required load order.
- Ensure each file has an independent valid wrapper.
- Keep app-specific settings for the target file.
## Validation

Validate each file independently, then test the intended combined load. Use a manifest that records file ownership for every entry.
