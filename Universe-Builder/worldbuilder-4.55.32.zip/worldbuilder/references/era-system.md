# Era Router and Temporal Isolation
## Navigation
- [Purpose](#purpose)
- [Two routing architectures](#two-routing-architectures)
- [Why v4 moved the era signal](#why-v4-moved-the-era-signal)
- [The three enforcement layers](#the-three-enforcement-layers)
- [Era-root plan contract](#era-root-plan-contract)
- [Cascade roles and levels](#cascade-roles-and-levels)
- [Era root content format](#era-root-content-format)
- [Era index](#era-index)
- [Era token rules](#era-token-rules)
- [Inclusion groups](#inclusion-groups)
- [Runtime settings dependency](#runtime-settings-dependency)
- [Portability boundary](#portability-boundary)
- [Legacy Scenario routing](#legacy-scenario-routing)
- [Entity state splitting](#entity-state-splitting)
- [Event reach](#event-reach)
- [Collision protection](#collision-protection)
- [Generation order](#generation-order)
- [Gates](#gates)
## Purpose
Use this system whenever one lorebook must support more than one canon period. It
prevents life/death, knowledge, relationship, rank, allegiance, location, form,
political, and event-state leakage.
Multi-era behavior is a routing contract, not a prose suggestion.
## Two routing architectures
| Routing | Contract | Era signal lives in | Default since |
|---|---|---|---|
| `root_toggle` | `worldbuilder-era-root-v1` | A constant root entry inside the lorebook | 4.0 |
| `scenario` | `worldbuilder-era-router-v1` | An `Era: ...` line in the card Scenario field | 3.x, still supported |
`root_toggle` is the default for new multi-era builds and is validated end to end: the
architecture gate branches on `architecture.era.routing`, and `era_root_contract.py` runs
at both planning and delivery. Before 4.19.4 the chain implemented only the Scenario
shape, so a build on the documented default could not pass planning. `scenario` remains valid and
is not deprecated: it is the correct choice when the user wants era selection to be
visible in the card body, or when the target runtime lacks the native fields the
cascade needs. Single-era builds use neither.
Both are enforced. Never mix them in one build.
## Why v4 moved the era signal
Three problems with Scenario routing, in order of severity:
**The Scenario field is not always available.** A Schema 3 standalone lorebook has no
card, so it has no Scenario, so it had no era router at all. Era isolation only
worked in card-bearing modes.
**It contradicts the card-shell contract.** `worldbuilder-card-shell-v1` keeps
Scenario blank unless an exact fixed premise was approved. Era routing required the
opposite. Both could not be the default.
**`AND ANY` leaks once aliases exist.** The v3 era gate set `selective: true` with the
era keyword in secondary keys but left `selectiveLogic` at its default of `0`
(AND ANY). With exactly one secondary key that is equivalent to AND ALL and holds
fine. The moment an era declares aliases (and the v3 plan schema encourages them
via `keywords`), AND ANY means *any one* alias satisfies the gate, and an entry can
activate on a partial match. v4 requires `selectiveLogic: 3` explicitly.

Resolution order for `selectiveLogic`/`selective_logic`: the first present key wins even when its value is an explicit `null`: `emit.selectiveLogic` first, then `emit.extensions.selective_logic`, then the layer default from `default-profile.json`. Only absence falls through.
A fourth issue: v3 declared the semantic group `worldbuilder-era-context` without ever emitting a runtime inclusion-group field, so two era variants of one subject could both enter the prompt.
## The three enforcement layers
Ordered by how late they catch a mistake. Later layers exist precisely because
earlier layers can be wrong.

1. **Token gate: before activation.** Every era-scoped entry requires the active
   era's token through AND ALL logic. A subject keyword typed in chat cannot pull an
   out-of-era entry, because the token is also required and only the enabled root
   emits it.
2. **Recursion levels: during activation.** Entries below the root set
   `delayUntilRecursion` with an explicit recursion level, so the cascade is staged:
   context cannot fire before the root, states cannot fire before context.
Cores are inside these layers too. A `core_invariant` entry is gated with AND ANY over exactly the tokens of the eras its subject exists in, so nothing activates with no era linked to it; it still never joins the variant group, because it must co-occur with whichever state won.
3. **Inclusion groups: after activation.** All era variants of one subject share an
   inclusion group with `groupOverride: true`. SillyTavern inserts at most one. This
   is the only layer that still holds when layers 1 and 2 both have a hole, which is
   why it is required rather than advisory.
## Era-root plan contract
```json
{
  "kind": "worldbuilder-era-root-plan",
  "plan_version": 1,
  "contract": "worldbuilder-era-root-v1",
  "build_id": "<build id>",
  "user_approved": true,
  "routing": {
    "mode": "root_toggle",
    "cascade_levels": { "root": 0, "context": 1, "state": 2, "detail": 3 }
  },
  "runtime_requirements": {
    "recursive_scan": true,
    "min_recursion_steps": 4,
    "min_activations": 0
  },
  "eras": [
    {
      "id": "age-of-ash",
      "name": "Age of Ash",
      "order": 2,
      "token": "EraAgeOfAshActive",
      "root_uid": "wb-era-root-ash",
      "enabled_by_default": true,
      "absent_entities": [{ "name": "Aeron", "reason": "dead at the Siege" }],
      "knowledge_ceiling": ["the northern route"],
      "context_uids": ["..."],
      "state_uids": ["..."],
      "detail_uids": ["..."]
    }
  ],
  "variant_groups": [
    { "group": "wb.aeron", "subject": "Aeron", "uids_by_era": { "long-peace": "...", "age-of-ash": "..." } }
  ]
}
```

`absent_entities` and `knowledge_ceiling` must be present even when empty. An empty
list is a reviewed statement that nothing is absent; a missing key is an oversight,
and the contract rejects it.

Exactly one era sets `enabled_by_default`.

The shipped encoding: the default root's entry carries "emit": {"constant": true, "enabled": true} with "activation": {"strategy": "constant", "recursion_role": "root"}; every other root carries "emit": {"constant": true, "enabled": false} with "activation": {"strategy": "disabled", "recursion_role": "root"}; the two fields move together (a shipped-disabled root needs both).

A note on the `min_activations: 0` above: SillyTavern's Minimum Activations check deliberately excludes the recursion buffer (entries reached only via recursive chaining do not count toward it), confirmed from the real activation mechanics. A non-zero value needs enough direct, non-recursive candidates to actually be satisfiable; recursion cannot satisfy it.
## Cascade roles and levels
Every era-scoped manifest entry declares `architecture.era_cascade_role`:

| Role | Level | Strategy | Gate |
|---|---|---|---|
| `root` | 0 | constant | none; it is the token source |
| `context` | 1 | keyword + delay until recursion | AND ALL on the era token |
| `state` | 2 | keyword + delay until recursion | AND ALL on the era token |
| `detail` | 3 | keyword + delay until recursion | AND ALL on the era token |

Levels must strictly increase. `prevent_recursion` is forbidden on `root`, `context`,
and `state` (it would stop the token reaching the next level) and permitted on
`detail`, which has nothing below it. `exclude_recursion` is forbidden everywhere
below the root, since recursion is the only thing that activates those entries.
## Era root content format
```text
<EraToken>

CURRENT ERA:
WORLD STATE THIS ERA:
ABSENT THIS ERA:
KNOWLEDGE LIMITS THIS ERA:
WHAT IS ALREADY PAST:
```
The `ACTIVE ...` rosters are **not** here. They live in the era's own index entry (DR-129), because the root must feed the recurse buffer to deliver its token and a roster in that position arms every entity it names on every turn. Root and index are separate entries with opposite recursion settings on purpose.
No block may enumerate what has not happened yet. Naming a future event in order to forbid it still puts that event in context, and the token gate already makes it unreachable from this era. State the boundary instead, inside `KNOWLEDGE LIMITS THIS ERA:`, for example "Nothing after the Siege has occurred." `FUTURE_ENUMERATION_RE` rejects the old block (DR-038).
`ABSENT THIS ERA:` stays, and stays required. Someone who existed earlier and is gone is in-era memory, not a leak. Keep the name; drop a reason clause that names a later or unknown event.

`ABSENT THIS ERA:` and `KNOWLEDGE LIMITS THIS ERA:` are required, validated against
the plan, and belong in the constant root: a keyword-triggered "Aeron is dead" entry
only fires after the model writes Aeron, when the leak has already shipped; a permanent roster prevents rather than corrects.
## Era index
One per era, and only the enabled era's index is ever reachable. Layer `world_index`, cascade role `context`, level 1, gated on its era token with AND ALL, `prevent_recursion: true`, rendered by `world_index.py` from the manifest. It carries the `ACTIVE FACTIONS / CHARACTERS / LOCATIONS THIS ERA` rosters and nothing else, so the model knows every subject this era contains and loads only the ones the conversation actually names.
```bash
python3 {baseDir}/scripts/world_index.py render --manifest artifacts/manifest.json \
  --era-mode multi --era-id age-of-ash --era-root-plan artifacts/era-root-plan.json
```
A subject with no era scope exists in every era and appears in every index. A subject scoped to one era appears only in that one, which is what makes it impossible for a roster to name someone the active era says is absent.

Keep the roster terse: name and one-clause reason. It is a permanent token cost.

The era index is a recursion sink, not a seed: it declares no `activation.emits` and owns no edges. Entities arm from real chat text plus their era token; entity-to-entity edges below the index are unchanged.
## Era token rules
- One alphanumeric word, 8 to 48 characters, starting with a letter. Spaces and
  punctuation break whole-word matching.
- No token may be a substring of another. SillyTavern matches substrings, so
  `EraAsh` would also unlock `EraAshFall`.
- A root emits only its own token. No entry may contain two era tokens.
- Tokens are machine sentinels, not prose. Do not use them as visible labels.
## Inclusion groups
Any subject with entries in more than one era must share an inclusion group named
`wb.<subject-id>`, with `groupOverride: true` so the winner is chosen deterministically
by insertion order rather than by a random group-weight roll.

The planning gate rejects ungrouped multi-era subjects by name: the check that closes the gap v3 deferred.
## Runtime settings dependency
The cascade below level 0 requires host settings WorldBuilder cannot set. Read
`sillytavern-runtime-settings.md`. Every era-root build delivers the generated
settings block in Creator Notes, and the delivery gate requires it.

Because the root is constant, a misconfigured host degrades to the era frame alone, thinner than intended, never wrong.
## Portability boundary
`group`, `groupOverride`, `selectiveLogic`, `delayUntilRecursion`, and
`recursionLevel` are SillyTavern-native fields. They are not part of CCv3.

Era isolation is therefore a **profile-dependent guarantee**. Under a portable
`lorebook_v3` export the content survives and the entire enforcement layer does not.
Workers emit neutral `extensions.worldbuilder_dynamic` semantics; the parent-owned adapter emits runtime fields under a named profile; the compatibility report declares the loss.
Say so to the user rather than implying eras are safe everywhere.

Never claim era isolation holds in a portable export.
## Legacy Scenario routing
`worldbuilder-era-router-v1` remains supported and is validated by
`era_router_contract.py`. When a build selects `routing.mode: "scenario"`:

- Creator Notes lists one exact copyable phrase per era; the user keeps exactly one
  active line in Scenario.
- Entries match it through `match_scenario`.
- Use `selective_logic: 0` (AND ANY). This is required, enforced by `architecture_gate`,
  and correct: the secondary keys are the era phrase *and its aliases*, only one of which
  is ever in Scenario at a time. AND ALL would demand every alias appear simultaneously,
  which is impossible, so it does not tighten the gate; it disables the entry.

**AND ANY here is not the leak it would be under `root_toggle`.** The two routings put
different things in `keysecondary`, so the safe logic differs:

| Routing | Secondary keys hold | Correct logic | Why the other is wrong |
|---|---|---|---|
| `scenario` | one era phrase plus its aliases | `0` AND ANY | AND ALL requires every alias at once; the entry never fires |
| `root_toggle` | exactly one machine token | `3` AND ALL | AND ANY lets any additional secondary key open the gate |

Auditors: an era-scoped entry using AND ANY under `scenario` routing is correct and must
not be reported as a leak. Check the routing before judging the logic value.

```bash
python3 scripts/era_router_contract.py --era-plan /path/era-plan.json --scenario-text "Era: Season 1"
```

The router reports `selected`, `unselected`, or `conflict`. It does not silently
choose between multiple era phrases.
## Entity state splitting
Split when any of these changes enough to cause contradiction:

- life status;
- role, rank, occupation, or authority;
- faction allegiance or membership;
- location or availability;
- relationships;
- known secrets and beliefs;
- physical form, transformation, disability, or equipment;
- goals, loyalties, or current conflict;
- reputation, ownership, leadership, composition, or strength.

Do not split merely because time passed. In balanced mode, invariant material may be shared only when it is safe in every selected era.

Every state records:

```text
state_id
manifest_uids
required_terms
forbidden_terms
knowledge_boundaries
relationships
goals
```

Generation assignments receive only the selected states and eras.
## Event reach
For an event with origin era N:

```text
visible_in_eras = N and every later approved era
```

No earlier era may include the event as known history, and no earlier era may name it at all. The token gate already makes it unreachable; naming it to forbid it would re-supply the fact the gate exists to withhold (DR-038).
## Collision protection
Every Era Context declares the semantic group `worldbuilder-era-context`. This does not yet force a target-specific inclusion-group field; the runtime adapter will map it later. The authoritative protection is:

- unique keywords;
- one active Scenario phrase;
- conflict detection;
- Scenario matching;
- era secondary filters;
- graph edges scoped to the same era;
- output leakage checks.
## Generation order
1. World Invariants.
2. Every Era Context.
3. Earliest era anchors and states.
4. Continue chronologically.
5. Shared invariant detail entries.

Within a worker: research one UID, validate, write/checkpoint, validate, then continue. Do not research every era first.
## Gates
Planning fails for `root_toggle` builds when:

- the era-root plan is missing, unapproved, or not bound by hash;
- two era tokens collide by substring, or a token is not a single alphanumeric word;
- more or fewer than one era sets `enabled_by_default`;
- `absent_entities` or `knowledge_ceiling` is undeclared for any era;
- any era-scoped entry omits the token gate or uses logic other than AND ALL;
- cascade levels do not strictly increase, or an entry sits at the wrong level;
- `prevent_recursion` appears on a root, context, or state entry;
- `exclude_recursion` appears anywhere below the root;
- a subject exists in more than one era without a shared inclusion group;
- `group_override` is not true on a grouped entry;
- declared runtime requirements cannot drive the planned cascade depth.

Output fails for `root_toggle` builds when:

- a root omits `ABSENT THIS ERA:` or `KNOWLEDGE LIMITS THIS ERA:`;
- a root omits a planned absent entity from its roster;
- more or fewer than one root ships enabled, or the enabled root is not the approved default;
- any root emits a token belonging to another era;
- any non-root entry contains more than one era token;
- Creator Notes lack the generated runtime settings block.

Planning also fails for:

- missing, stale, unapproved, or pre-v2 plans on new builds;
- duplicate or overlapping era keywords;
- missing boundaries, world state, or knowledge restrictions fields;
- missing Era Contexts;
- contexts that are constant, selective, vector-only, or do not match Scenario;
- contexts missing semantic era-group ownership;
- active entities without era-scoped entries or recursion edges;
- invalid event reach;
- entity-state UIDs not scoped to their planned era.

Output fails for:

- missing required Era Context blocks;
- missing active entities, past/future events, state assertions, or knowledge restrictions;
- future-event leakage;
- prohibited state terms;
- missing required state terms;
- forbidden state terms;
- missing planned era-state outputs;
- Creator Notes missing exact Scenario phrases.

Before release, read `full-integration-acceptance.md`; require the frozen route-specific integration plan and current receipts, skipping only systems marked not applicable.
