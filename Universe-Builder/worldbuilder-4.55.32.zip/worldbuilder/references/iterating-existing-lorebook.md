# Iterating on an existing lorebook

Use this decision point before starting an edit, Guided iteration, or Update/Merge on existing lorebook content.

## Targeted change

Use this path when the request identifies specific existing UIDs/fields and does not require a new source pass or frozen structural re-plan. A useful fast test is: does this only change how existing entries are tagged/positioned, rather than changing what the world structure or source plan means? Start with `selective_regeneration.py plan`, then obey `pipeline_stage_gate.py --next`; the state machine names every remaining scoped step.

Requested locked entries are never silently skipped or overridden. The plan reports each exclusion in `locked_exclusions` with the entry name and lock reason before work continues; if every requested UID is locked, the operation blocks.

### Amendment safety cap

A targeted edit must pass **both** tests: it must be non-structural **and**, for an already sealed build, the changed-plus-neighbour scope must fit the amendment safety cap. One amendment may touch at most 20% of manifest entries, with neighbours counting 1:1. The amendment chain is capped at three entries. `selective_regeneration.py plan` reports the exact changed/neighbour arithmetic before it copies a baseline or invalidates lineage.

This matters especially for broad recursion-graph corrections: a fix can be purely metadata-level yet still force a full re-baseline when one terminal change fans out to many neighbours. If the plan says the scope exceeds 20%, do not finish the change set and hope `--record-amendment` accepts it. Split only when the resulting independent scopes genuinely fit; otherwise re-baseline.

## Structural change

Use the full manifest-amendment/re-baseline path when the request changes the source pass or frozen registry/default-profile/era/character/placement/budget/dynamic-state planning structure. Structural changes invalidate broadly because their downstream assumptions genuinely changed.

The two paths are intentionally different: targeted changes preserve unaffected generation/audit history, while structural changes re-prove the affected pipeline from the appropriate baseline.
