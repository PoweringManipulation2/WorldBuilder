# OpenClaw Session Context

Not to be confused with `context-budget-pruning.md`, which governs the token cost of
the *artifact* inside SillyTavern. This file is about the *session* WorldBuilder runs
in, and applies only when the host is OpenClaw.

## Navigation

- [Why WorldBuilder is exposed](#why-worldbuilder-is-exposed)
- [Advise this before a long build](#advise-this-before-a-long-build)
- [What actually gets lost](#what-actually-gets-lost)
- [Recovery is resume, not restart](#recovery-is-resume-not-restart)
- [Inspecting pressure](#inspecting-pressure)

## Why WorldBuilder is exposed

A full build runs discovery, planning, approval, several generation phases, audit,
and delivery. That is a long session with many large tool results. OpenClaw counts
tool calls and results against the model window alongside the system prompt and
conversation history, so a large build can reach compaction or pruning partway
through.

Single-entry edits, audits of a supplied file, and Info Mode do not need any of this.

## Advise this before a long build

Raise these once, before generation starts, not after the session is already under
pressure:

**`first_time_setup.py` applies the CLI-settable tuning itself**: cache retention,
mid-turn precheck, transcript rotation, worker timeout, and the subagent concurrency
caps. Those are `agents.defaults.*` keys and apply to every agent on the gateway, so
they are shown in the plan and only written under `--apply`. Settings that could change
what a build produces (`contextPruning`, `toolResultMaxChars`, `sandbox`) are reported
as advisory and never set automatically.

The Context Profile is the one step left to the user, because it cannot be set from
the CLI.

1. **Set the Context Profile to Code Agent.** Settings → Context Profile. Verified
   against OpenClaw v2026.7.1-2.

   | Profile | Per file | Total | Follow-up reinjection |
   |---|---|---|---|
   | Personal Assistant | 20,000 | 150,000 | Every turn |
   | **Code Agent** | **50,000** | **300,000** | **Every turn** |
   | Team Bot | 10,000 | 80,000 | Skip safe follow-ups |
   | Minimal | 5,000 | 30,000 | Skip safe follow-ups |

   Know what this does and does not do, because the difference decides how to
   troubleshoot later. Profiles change bootstrap injection size and follow-up
   reinjection only, never the model, tools, or channels. They therefore do **not**
   enlarge the model's context window and do not prevent conversation history from
   being compacted. A larger bootstrap budget in fact consumes more of the window.

   The reason Code Agent is still the right pick for a long build is the reinjection
   column: Team Bot and Minimal skip reinjection on safe follow-ups, so during a
   multi-turn build the workspace framing can quietly stop being re-sent. Code Agent
   reinjects every turn and raises the per-file cap enough that a large `AGENTS.md`
   or `TOOLS.md` is not truncated.
2. **Use the largest context window your model offers.** This is the change that
   actually affects conversation truncation, and it is separate from the profile.
3. **Run `/compact` before starting**, not in the middle. Compaction summarizes older
   history into the transcript and keeps recent messages intact; doing it at a phase
   boundary loses far less than doing it mid-phase.
4. **Check `/status`** for current window usage before committing to a large build.
5. **Let workers do the heavy reading.** WorldBuilder already delegates research and
   generation to subagent workers for this reason. Do not pull worker output into the
   main session beyond what the ledger needs.

Do not present this as a prerequisite. A build still completes under pressure; it
just costs more re-reads.

## What actually gets lost

OpenClaw distinguishes two mechanisms, and the difference decides how worried to be:

- **Compaction** writes a summary into the transcript and keeps recent messages.
  Detail is lost; continuity is not.
- **Pruning** drops old tool results from the in-memory prompt only. The session
  transcript on disk is not rewritten and remains inspectable.

Neither deletes anything WorldBuilder depends on. Build state, manifests, plans,
receipts, and phase files all live in the user's workspace on disk, not in the
conversation.

## Recovery is resume, not restart

If earlier turns are gone and the current step is unclear, do not reconstruct the
build from conversation memory and do not start over. Run:

```bash
python3 {baseDir}/scripts/pipeline_stage_gate.py --build-state <path> --next
```

It reports the next step and the file to re-read first, derived from the ledger
rather than from context. Re-read the named reference and continue. This is the same
path used after an interrupted session.

## Inspecting pressure

- `/status`: how full the window is.
- `/context list`: what is injected, with per-file sizes and any `TRUNCATED` marks.
- `/context detail`: per-tool schema sizes and compactable message counts.
- `/compact`: summarize older history to free space.

The Context Profile sets `agents.defaults.bootstrapMaxChars` and
`bootstrapTotalMaxChars`, which govern injected workspace files such as `AGENTS.md`.
They do not govern WorldBuilder's own references, which are read on demand and are
not bootstrap files.

## Per-agent model routing

Long-horizon instruction following and short-horizon structured output are different
capabilities, and OpenClaw can route them separately through `agents.entries.*`. The
parent holds a twelve-phase protocol across a long session; workers emit one valid
entry and stop.

WorldBuilder can now freeze separate discovery, generation, and audit routes per build.
The legacy `models.subagent` remains the fallback, and optional `cheap`, `standard`, and
`maximum-quality` strategies route only between the user's configured main/subagent
models; they never hard-code or discover a provider/model. Explicit role values win.

OpenClaw's per-spawn `model` is a strict request. Each assignment therefore records
`requested_model`; `model_routing.py route` decides whether to pass it, and `verify`
checks the parent-observed `resolvedModel`. Measure before tuning: cost projections and
gate telemetry sample discovery/generation/audit history by the role's frozen model.
