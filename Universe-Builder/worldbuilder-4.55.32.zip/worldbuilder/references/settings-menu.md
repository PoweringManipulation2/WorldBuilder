# Guided Build Settings Menus
## Navigation
- [Contract](#contract)
- [Page navigation](#page-navigation)
- [Simple Mode](#simple-mode)
- [Advanced Mode](#advanced-mode)
- [Mode filtering](#mode-filtering)
- [Build template prefill](#build-template-prefill)
- [Flag prefill](#flag-prefill)
- [Confirmation](#confirmation)
- [Tools submenu](#tools-submenu)
- [Styling tokens](#styling-tokens)
## Contract
After routing to Character, World, Lorebook, Group Chat, Persona, or Quick Build, load `interface.mode` from the approved workspace `config.json`.
- `simple` uses the compact paged flow.
- `advanced` uses one comprehensive paged flow containing the standard and expert settings together.
- Never show Simple first and append Advanced.
- Never show more than **10 numbered setting blocks on one page**.
- Remove mode-inapplicable settings instead of showing placeholders.
- Prefill facts and flags already supplied by the user.
- Freeze resolved choices into the build state and relevant planning artifacts.
The overall guided flow is titled `── 📖 BUILD SETTINGS ──`; individual responses add the current page number.
Use `scripts/setup_state.py` when setup must survive interruption. Drafts live under the user-owned workspace `.setup-drafts/`, never under the installed skill. Each submitted page is saved immediately. Generation cannot begin from an incomplete draft.
## Page navigation
Every page accepts numbers, labels, or normal sentences. Show these commands at the bottom:
```text
recommended      accept displayed defaults for this page
recommended all  accept defaults for this and every remaining page
back             return to the previous page
change <number>  reopen a previously answered setting
status           show choices saved so far
cancel           leave setup without starting a build
```
After a valid page submission, respond with `✅ Page N saved.` and show the next page. Do not repeat earlier pages unless asked. After the final page, show one complete summary and require Start/Change/Cancel confirmation.
## Simple Mode
Use this menu when `interface.mode` is `simple`.
### Page 1: Build fundamentals
```text
── 📖 BUILD SETTINGS: PAGE 1 OF <N> ──
Reply with option labels, numbers, or normal sentences.
Already supplied choices and flags are pre-filled; correct anything wrong.
Reply “recommended” to accept the displayed defaults on this page.
[1] 🌍 PROJECT & CANON
    What world, franchise, character, persona, or project are we building?
    [existing] Source-canonical research
    [original] User-provided material is canon
    [hybrid] Preserve user changes; verify everything else
    Default: ask when unclear
[2] 📚 SOURCE MATERIAL
    Do you have cards, JSON/CHARX files, notes, excerpts,
    URLs, or wiki pages that must be treated as source material?
    [yes] Upload, paste, or identify them
    [no] Research approved public sources or use conversation evidence
    [extend] Build on a lorebook you already have
    Default: no
    [extend] is additive and differs from [yes]: [yes] treats your material as
    research input, while [extend] keeps the existing entries and generates only
    what is missing. Imported entries are labeled `unverified` and enter
    verification triage rather than being trusted or re-researched.
[2A] 🧭 GUIDED MODE
    Would you like to enter guided mode to make heavy changes? Guided mode
    trades the normal structured menus for an open-ended, conversational
    build: you describe what you want directly, and the agent figures out
    how to get there.
    [no] Use the normal, structured pipeline
    [yes] Enter guided mode
    Default: yes if [1]=original and [2]=no; no otherwise. Always shown and
    always explicitly confirmable either way, never silently assumed from
    [1]/[2] alone.
[3] ✏️ CONDITIONS & MODIFICATIONS
    Add a timeframe, continuity, exclusions, custom canon,
    tone, content limits, or other conditions.
    Write them normally, or reply [none].
    Default: none
    At Start, pass the accepted text verbatim to `init_build.py --conditions`; `[none]` maps to the empty string.
[4] 🔎 LOREBOOK RETRIEVAL  [World / Lorebook / Group / embedded lorebook]
    [keyword] Keyword recursion tree: vectorization off
    [hybrid] Keywords plus safe automatic vectorization
    [hybrid-custom] Hybrid, specify vectorized entry categories
    [vector-first] Mostly vector retrieval; critical entries stay deterministic
    [auto] Let WorldBuilder choose from project needs
    Default: auto
[5] 🕰️ ERA ARCHITECTURE
    Character:
      [single] One card for one confirmed timeframe
      [set] Separate cards for incompatible eras
    World / Lorebook / Group:
      [single] One locked timeframe
      [multi] Multiple eras with strict knowledge isolation
    [explain] Explain count, complexity, and leakage tradeoffs
[4C] 💰 COST & VERIFICATION  [shown at plan freeze]
    Projected scope is an estimate, never a guarantee: entries, discovery
    assignments/waves, generation workers, audit calls, attempts, tokens, and
    a price only when the user supplies a rate. Run `verification_triage.py project --build-state <path>` once to freeze it; replacement requires explicit `--replace-projection`. After delivery, `reconcile` shows that estimate beside observed usage.
    [approve] Freeze this scope
    [narrow] Reduce scope or detail level
    [budget N] Verify the top N entries by blast radius
    Verification budget default: all entries for original builds; for
    `existing-lorebook` builds the user chooses, because verifying an
    imported book uniformly costs about what regenerating it costs.
    De-risk policy for entries the budget does not reach:
    [disable] ship disabled; the user enables them knowingly
    [deprioritize] verified entries win the budget when both match
    [despecify] strip falsifiable specifics, keep atmosphere
    [ship_labeled] ship as-is with confidence stated in the report
    Default: deprioritize, or the value saved in Home Config [9]
    Never cap spend mid-generation. A cap that trips during a build yields
    an unpredictable partial artifact; cap scope at plan time instead.
[5A] 🧱 ERA ISOLATION
        This is a nested part of Era Architecture, not another top-level page block.
        Multi-era and Character-set builds use strict state and knowledge isolation.
    [5B] 🧭 ERA ROUTING  [multi only]
        [root] Era roots inside the lorebook; switch by enabling one entry (default)
        [scenario] An `Era: ...` line in the card Scenario field (legacy, card modes only)
        Default: root
    [5C] 🗓️ ERA BOUNDARIES
        This is approved at the focused checkpoint after discovery.
    Default: single
[6] 🔁 RECURSION PROFILE  [lore-bearing modes]
    [off] No entry-to-entry activation
    [controlled] Planned roots and anchors recurse; leaves stop
    [expansive] Broader recursion with fan-out safeguards
    [custom] Specify recursion behavior
    Default: controlled
[7] 🧩 SILLYTAVERN EXTENSIONS
    [none] No extension-specific behavior
    [choose] Select installed extensions
    [detect] Read the installed list from your SillyTavern folder
    Default: none
    `[detect]` runs `sillytavern_install.py extensions` against a confirmed install
    root. It reports presence on disk only; enablement is not asserted. When no
    install is found, `[detect]` degrades to `[choose]` rather than failing.
[8A] 📏 CONTEXT WINDOW
    [8k] 8,000 tokens
    [16k] 16,000 tokens
    [32k] 32,000 tokens
    [128k] 128,000 tokens
    [200k] 200,000 tokens or more
    [custom N] Specify an exact token count
    [auto] Generate without a guessed ceiling, report measured post-merge context stats, then keep or prune toward a target you choose
    Default: 32k
    The model or frontend you will actually run this card in sets the total
    token budget for the permanent shell plus active lorebook entries at their
    worst case. Not a detail preference; a 128k window at Compact still gets a
    128k-sized budget (see [8B]).
[8B] 📊 DETAIL PROFILE
    [recommended] Balanced entry count and per-entry richness within [8A]'s window
    [compact] More, leaner entries within the same window (alias: quick)
    [maximum] Fewer, richer entries within the same window (alias: full detail)
    Default: recommended
    Changes how the window from [8A] is distributed, never its total. Choosing
    Compact for leanness on a large window does not shrink the window; it only
    changes how that window's budget is spent. Generation-time cost is separate:
    Compact/Recommended use compressed per-entry drafting targets, while Maximum
    removes the source-compression ratio and tells workers to write exhaustively
    until structure should split. Maximum can therefore require more model effort
    per rich entry, but it does not mechanically add workers, sources, or research
    calls, so there is no fixed or guaranteed generation-cost multiplier.
```
When fewer than ten blocks apply, end the page at the last applicable block. Do not pad it.
### ERA BOUNDARIES / ROUTER checkpoint
After discovery/source synthesis for `multi` or `set`, show a focused checkpoint rather than consuming a normal page slot:
```text
🗓️ ERA ROUTER & BOUNDARIES
[auto] Review proposed boundaries, world states, exact `Era: ...` phrases, active entities, past/future events, and knowledge limits
[custom] Supply or revise the era routing plan
Default: auto
```
For `root` routing the review explains that each era gets one constant root entry, exactly one ships enabled, and switching eras means enabling one root and disabling the rest. For `scenario` routing it explains that exactly one `Era: ...` line belongs in Scenario and that switching replaces the old line. Manifest creation waits for explicit approval.
**Disclose the runtime settings dependency at this checkpoint, not at delivery.** A user who learns after the build that their World Info settings must change has been told too late. State it once, plainly:
```text
⚙️ REQUIRED SILLYTAVERN SETTINGS  [root routing]
Multi-era root routing needs three World Info activation settings:
  Recursive Scan .............. ON
  Max Recursion Steps ......... 4 or more
  Min Activations ............. 0   (mutually exclusive with Max Recursion Steps)
Without them you get the era frame only; correct, but much thinner.
[check] Read my SillyTavern settings and verify these for me
[ok] Understood, continue
[scenario] Use legacy Scenario routing instead
[single] Build one era instead
```
`[check]` runs `sillytavern_install.py locate`, proposes the resolved install root for
confirmation, then runs `preflight --required-recursion-steps <cascade depth + 1>` and
reports each setting as ok, problem, or unknown. Findings are **advisory**: report them
and let the user decide. Never block a build because the reader could not find or parse
an install; every build works without it.
Never auto-continue past this block. If the user cannot change those settings, route to `scenario` or `single` rather than shipping a cascade that cannot fire. Read `sillytavern-runtime-settings.md`.
### Page 2: Output and card experience
Show only the applicable blocks.
```text
── 🪟 BUILD SETTINGS: PAGE 2 OF <N> ──
[11] 📎 EMBED LOREBOOK  [Character only]
    [yes] Attach a compact supporting lorebook
    [no] Character card only
    Default: no
[12] 📦 OUTPUT FORMAT  [not shown for plain-text Persona]
    [json] Plain JSON using the mode-appropriate portable schema
    [charx] CHARX bundle
    [both] JSON and CHARX
    Default: json
    Simple Mode asks only for this readable output format. The parent adapter
    resolves the correct semantic target and reports any lossy conversion. Portable output remains the Simple Mode default; choose a named SillyTavern profile when direct import and active application settings are required. For a standalone lorebook specifically, DR-051 is narrowed by Batch 13: the default resolves directly to the native, directly-importable shape, since a bare `lorebook_v3` file is actively misrouted by SillyTavern's own import, not merely preservation-only; an explicit `lorebook_v3` request still produces the portable wrapper unchanged.
[13] 🪟 WORLD CARD SETUP  [World only]
    [open] Blank Scenario, neutral entrance, user chooses their role
    [guided] Blank Scenario, greeting suggests a place or situation
    [fixed] Explicitly approved permanent premise
    Default: open
[13] 🎬 CHARACTER STARTING SETUP  [Character only]
    [open] Reusable blank Scenario
    [guided] Greeting establishes a scene; Scenario remains blank
    [fixed] Explicitly approved permanent Scenario premise
    Default: open
[13] 👥 GROUP OPENING STYLE  [Group only]
    [shared] One shared group opening
    [individual] Character-specific openings
    [both] Shared and character-specific openings
    Default: shared
[13] 🎭 PERSONA DETAIL  [Persona only]
    [compact] Identity and role
    [detailed] Identity, appearance, history, and behavior cues
    [custom] Specify the structure
    Default: compact
[14] 👋 OPENING VARIETY  [Character / World / Group]
    [single] One primary greeting
    [varied] Add useful alternate openings
    [custom] Describe the openings wanted
    Character set only:
      [era-specific] Different opening appropriate to each era
      [shared-style] Same basic scene adapted to each era
    Default: single; Character set default: era-specific
[15] 💬 DIALOGUE EXAMPLES  [Character only]
    [recommended] Add enough examples to establish voice and behavior
    [none] Leave example dialogue blank
    [custom] Specify the situations to demonstrate
    Default: recommended
```
Selecting any `fixed` option triggers one focused follow-up for the exact premise. Store that text in the card-shell plan and require an exact match at output. Do not ask the user to configure raw card fields.
## Advanced Mode
```text
── ⚙️ ADVANCED BUILD SETTINGS ──
Paged flow; no page contains more than ten numbered setting blocks.
```
Use this menu when `interface.mode` is `advanced`. It replaces the Simple menu; it does not follow it. This is the one comprehensive Advanced build menu, presented as a paged flow.
Advanced Mode is one paged setup flow. It includes all standard choices; it does not send the user through Simple Mode first.
### Page 1: Foundations and activation
The advanced page labels setting `[4]` as `[4] 🔎 RETRIEVAL & VECTORIZATION`.
Use settings `[1]` through `[8]` from Simple Page 1. Advanced Mode may expand retrieval, keywords, activation, and recursion into guided subcontrols, but it does not expose dynamic operations on this page.
```text
[7A] 🗝️ KEYWORDS & OPTIONAL FILTERS
    [automatic] Generate aliases, secondary keys, and safe filter logic
    [review] Generate and pause for review
    [custom] User supplies category or entry-level rules
    Default: automatic
[8A] 🧭 ACTIVATION OVERRIDES
    [automatic] Use the selected retrieval and recursion profile
    [review] Review constant, keyword, hybrid, vector-only, and disabled assignments
    [custom] Specify entry-type overrides
    Default: automatic
[9] 🔁 DISCOVERY RETRY LIMIT  [existing-canon builds only]
    Override this build's independent recovery-worker attempts on a stubborn
    URL before it is confirmed dead and routed to exclusion approval.
    Enter 0-5; 0 skips dedicated retries and asks for exclusion on first
    failure. Passed to discovery_plan.py as --confirmed-dead-after-rounds.
    Default: inherit (the global Config Mode `[5]` value, itself default 2)
```
### Page 2: Character architecture
Show this page for Character, World, Lorebook, and Group builds. Simple Mode still resolves these automatically; only Advanced Mode asks whether the user wants to review or customize them.
```text
── 🧍 ADVANCED BUILD SETTINGS: PAGE 2 OF <N> ──
[11] 🪪 IDENTITY & BEHAVIOR PLAN
    [automatic] Build stable identity, voice, motives, limits, and knowledge boundaries
    [review] Pause on the proposed structured character plan
    [custom] Supply project-specific identity or behavior rules
    Default: automatic
[12] 🤝 RELATIONSHIP STATE PLAN
    [automatic] Plan directed, era-specific public/private relationships
    [review] Review relationship states, knowledge, and behavior consequences
    [custom] Supply required relationships or private-knowledge rules
    Default: automatic
[13] 🧬 CHARACTER SPLIT POLICY
    [automatic] Split only when state changes would cause contradiction or leakage
    [review] Review proposed single-state versus multi-state decisions
    [custom] Require or forbid specified state splits
    [self-contained] One complete entry per era; no shared core
    Default: automatic
    Automatic uses a core/state split at three or more eras (DR-059): a shared
    core entry holds voice, invariant vitals, and base appearance, while per-era
    states hold timeline, connections, backstory, and current situation. The core
    spans every era its subject exists in and must be status-free;
    `check_core_contamination` enforces that.
```
These choices control `character-plan.json`; they do not ask the user to fill raw fields. The focused era-router checkpoint still owns exact eras.
For multi-era or Character-set builds, add:
```text
[14] 🕰️ ERA ROUTER & TEMPORAL ISOLATION
    [automatic] Build exact Scenario routing, active-entity edges, past/future limits, and state checks
    [review] Pause on the complete era-router plan
    [custom] Supply routing aliases, boundaries, or isolation rules
    Default: automatic
```
### Page 3: Context behavior
```text
── ⚙️ ADVANCED BUILD SETTINGS: PAGE 3 OF <N> ──
[15] 📍 PLACEMENT & INFLUENCE
    [automatic] Purpose-based position, order, priority, depth, and role
        World foundations and Era Contexts stay before character definitions.
        Character/relationship state stays after character definitions.
    [review] Show the proposed placement plan before generation
        Display purpose, semantic position, order, influence class, and target mapping.
    [custom] Guided per-layer or per-entry overrides
        Every override requires a reason and target-compatibility check.
    Default: automatic
[16] 📏 CONTEXT BUDGET & PRUNING
    [automatic] Use the frozen Detail & Context Profile
    [review] Show permanent, constant, layer, era, entry, and activation targets
    [custom] Set exact targets and layer allocations; every override is validated
    Default: automatic
[17] 🧩 SILLYTAVERN EXTENSIONS
    [none] No extension-specific behavior
    [choose] Select installed extensions
    [detect] Use only confirmed extensions
    Default: none
[18] 🌀 DYNAMIC STATE & VARIATION  [lore-bearing modes]
    [off] Deterministic safety defaults; no optional dynamic behavior
    [review] Show proposed optional candidates before freezing the plan
    [custom] Open the separate Dynamic State & Variation submenu
    [preserve] Preserve supplied behavior during an edit
    Default: off for new builds; preserve only for compatible edits
    The submenu covers:
      • inclusion groups, weights, group scoring, and priority selection
      • probability
      • sticky, cooldown, and delay
      • additional matching sources
      • character/tag include or exclude filters
      • generation triggers
      • approved automation IDs
      • approved named outlets
    Safety defaults remain probability 100, no timed effects, no random groups,
    no automation, and no outlets. Protected factual/control entries cannot be
    randomized, delayed, filtered, or hidden.
[19] 🔍 DETAIL LEVEL
    [recommended] Source-matched depth
    [full detail] Maximum supported coverage
    [quick] Smaller, faster build
    Default: recommended
[20] 📎 EMBED LOREBOOK  [Character only]
    [yes] Attach a supporting lorebook
    [no] Character card only
    Default: no
[20A] 🔂 AUDIT ITERATION CEILING
    Maximum audit rounds for this build before an unclean loop escalates to
    you with its outstanding findings listed. Enter 1-5; a build that reaches
    the ceiling with findings still open cannot reach delivery.
    Passed to init_build.py as --audit-max-iterations; an existing build can
    change it later with `settings_preset.py set`.
    Default: 3
[20B] 🔂 VISION SOFT THRESHOLD
    Hand a generation worker off once this percent of its researched session
    image budget is spent. Enter 10-100.
    Passed to init_build.py as --vision-soft-percent.
    Default: 75
[20C] 🔂 VISION SESSION CAP
    Optional ceiling on the researched per-session image limit. Enter 1-1000,
    or leave unset to use the researched limit alone.
    Passed to init_build.py as --vision-session-cap.
    Default: unset
```
Dynamic State & Variation is an executable target-neutral planning contract. Batch 9 maps the frozen semantics only through `references/runtime-target-adapter.md` and its versioned parent-owned adapter. Simple Mode does not expose this submenu and always freezes deterministic safety defaults.
Simple Mode does not ask a separate placement question. It uses the frozen purpose-based profile and shows the resolved placement summary at confirmation only when a non-default or target-specific mapping matters. Advanced `review` pauses on a compact table; `custom` opens named choices for layer, position, order, depth/role, and outlet consumer rather than raw JSON.
The placement page must explain that `before_char`/`after_char` are portable core positions while Example Messages, Author's Note, depth, and outlet placements require a tested SillyTavern mapping. Do not offer an outlet unless an approved consumer exists.
The budget page must explain the two independent axes: a fixed Context Window [8A] sets the total token budget for the permanent shell plus active lorebook entries at their worst case; `[auto]` instead defers the ceiling until the real merged size is measured and the user reviews it. Detail [8B] changes how a fixed total is distributed, and in auto mode also biases pruning tie-breaks so Compact prefers smaller equal-priority entries while Maximum Detail prefers richer ones. Optional per-build `--pruning-objective preserve_factions` and `--pruning-objective preserve_main_plot` choices are soft preservation biases, not locks; main-plot preservation applies only to entries explicitly marked with `architecture.pruning_tags: ["main_plot"]`. Show soft versus hard limits, the seven baseline activation simulations plus declared project-specific scenarios, protected categories, measured-versus-declared-versus-fallback token counts, and the uncertain `ceil(UTF-8 bytes / 4)` fallback. After planning, a predicted drop-order report and a recommended runtime `token_budget` are available, measured against this specific build rather than a generic default. Corpus size (total authored lore across the whole book) is reported separately and is never compared against an activation budget; storage is not a runtime cost. Custom exact targets require Advanced Mode.
### Page 4: Card shell and target
```text
── 🪟 ADVANCED BUILD SETTINGS: PAGE 4 OF <N> ──
[21] 📦 OUTPUT & TARGET
    [schema1] Schema 1 Character
    [embedded] CCv3 embedded character_book
    [lorebook] Portable standalone lorebook_v3 (not direct SillyTavern World Info import)
    [native] SillyTavern-native World Info using a named tested profile
    [charx] CHARX bundle
    [group] Character set with one shared lorebook
    [persona] Persona with an optional lorebook
    [preserve] Preserve the imported artifact format
    [review] Show compatibility before choosing
    Default: mode-appropriate portable target
[22] 🧪 TARGET MAPPING REVIEW
    [automatic] Apply the tested semantic target mapping
    [report] Show unsupported fields, lossy warnings, and preserved unknown data
    [custom] Review target-field handling and any required tag/outlet mappings
    Default: automatic
[23] 🪟 CARD STARTING SETUP  [Character / World]
    [open] Reusable blank Scenario and open entrance
    [guided] Blank Scenario with a guided opening
    [fixed] Exact approved permanent premise
    Default: open
[24] 👋 OPENING VARIETY  [Character / World / Group]
    [single] Primary greeting only
    [varied] Useful alternate openings
    [era-specific] Era-specific openings for card sets
    [shared-style] Shared concept adapted across a set
    [custom] Specify
    Default: single
[25] 💬 DIALOGUE EXAMPLES  [Character]
    [recommended] Voice and behavior examples with `<START>`
    [none] Blank
    [custom] Specify
    Default: recommended
[26] 🧭 SYSTEM PROMPT
    [automatic] Use only when stable global behavior belongs here
    [none] Leave blank
    [custom] Supply approved behavior
    Default: automatic
[27] 📌 POST-HISTORY INSTRUCTIONS
    [automatic] Use only short high-priority constraints
    [none] Leave blank
    [custom] Supply approved behavior
    Default: automatic
[28] 📝 CREATOR NOTES
    [automatic] Usage, timeframe/era guidance, variants, and attribution
    [review] Review planned sections
    [custom] Add requested human-facing notes
    Default: automatic
[29] 📐 PERMANENT PROMPT LIMITS
    [automatic] Use tested soft/hard pressure checks
    [review] Show projected permanent prompt cost
    [custom] Set project-specific limits
    Default: automatic
[30] 🧹 FIELD DUPLICATION POLICY
    [strict] Reject substantial Description/Personality duplication
    [review] Report overlaps before generation
    [custom] Specify exceptions
    Default: strict
```
If more target-specific controls are needed later, place them on Page 5 rather than exceeding ten blocks.
## Mode filtering
| Setting family | Character | World | Lorebook | Group | Persona | Quick Build |
|---|---:|---:|---:|---:|---:|---:|
| Project, source, guided mode, conditions | yes | yes | yes | yes | yes | yes |
| Retrieval/vectorization | embedded lorebook only | yes | yes | yes | split lorebook only | when lore-bearing |
| Era architecture | single/set | single/multi | single/multi | single/multi | no | when lore-bearing |
| Identity/behavior/relationship planning | automatic; review in Advanced | automatic; review in Advanced | when characters exist | automatic; review in Advanced | no | by artifact |
| Recursion | embedded lorebook only | yes | yes | yes | split lorebook only | when lore-bearing |
| Dynamic State & Variation submenu | no | Advanced only | Advanced only | Advanced only | no | Advanced lore-bearing only |
| Card starting setup | yes | yes | no | group variant | persona variant | by artifact |
| Opening variety | yes | yes | no | yes | no | by artifact |
| Dialogue examples | yes | no | no | per card | no | Character only |
| Output/target | yes | yes | yes | yes | no for plain text | unless Persona |
## Settings that are not on these pages
Autonomy, debug logging, the default unverified-entry policy, and the image generation
model choice are persistent preferences and live in the Home Config menu (`config-mode.md`),
not here. These pages ask what is true of *this artifact*; Home Config holds what is true
of *this workspace*.
A build may override a persisted preference through an `init_build.py` flag, but the
per-build pages never re-ask for one.
## Build template prefill
When the user selects a reusable build template, read `references/build-templates.md` and pass it to `scripts/setup_state.py init --template <path>` before showing Page 1. Render the ordinary mode-filtered `setting_ids` exactly as usual and use the returned `prefill` values as the displayed defaults. A template never marks a page complete, never removes a question, and never bypasses the final Start/Change/Cancel confirmation. Explicit page answers override template prefills. `recommended` accepts the displayed template/default values; `recommended all` remains an explicit bulk-accept action, not a reason to omit the pages from the persisted draft.

Build templates are not `settings_preset.json`: templates affect the guided setup UI before initialization; settings presets are the narrower portable `init_build.py` default bundle described in `references/settings-presets.md`. Never let the two become competing authorities.

## Flag prefill
Recognize these flags anywhere in the request:
- `full detail` → detail `full detail`.
- `quick` → detail `quick`.
- `128k` or `200k` or an explicit token count → context window `[8A]` to the matching or nearest option.
- `charx` → output `charx`.
- `multi-era` → `multi` for lore-bearing modes or `set` for Character.
- Source answers derive `init_build.py --source-kind`, which is never asked separately:
  `[1] existing` → `known-property`; `[1] original` or `[1] hybrid` → `original`;
  `[2] yes` → `provided-corpus`; `[2] extend` → `existing-lorebook`.
  When `[1] existing` and `[2] yes` are both chosen, the supplied corpus wins and the
  breadth sweep still runs, because supplied material narrows research rather than
  replacing it. `[2] extend` outranks both: an additive build starts from the existing
  artifact regardless of how its canon was sourced.
- Guided routing comes only from the explicit `[2A]` answer. Pass both the answer
  and its displayed default to `init_build.py` as `--guided-mode-answer` and
  `--guided-mode-default`; `[2A] yes` additionally selects `--custom-pipeline`
  and records `--custom-trigger-reason`. Never derive this from `[1]`/`[2]`.
- `keyword only` → retrieval `keyword`.
- `hybrid` → retrieval `hybrid` unless another meaning is explicit.
- `vector-first` or `pure vector` → retrieval `vector-first`.
- `no recursion` → recursion `off`.
- `open world` → World card setup `open`.
- `fixed scenario` → setup `fixed`, then request exact text.
- `alternate greetings` → opening variety `varied` unless details are supplied.
Explicit later answers override flags. Show every prefilled value for correction.
## Confirmation
```text
── ✅ BUILD SETTINGS SUMMARY ──
🌍 Project: <name>
📚 Canon stance: <existing | original | hybrid>
🧭 Guided mode: <yes | no> (<default accepted | overridden>)
✏️ Modifications: <summary>
🔎 Retrieval: <keyword | hybrid | vector-first | auto>
🧭 Vectorization: <off | safe automatic | specified | broad>
🕰️ Era architecture: <single | multi | character set>
🔁 Recursion: <off | controlled | expansive | custom>
🪟 Card setup: <open | guided | fixed | not applicable>
👋 Greetings: <single | varied | era-specific | custom>
💬 Dialogue examples: <recommended | none | custom | not applicable>
🧭 System Prompt: <automatic | none | custom>
📌 Post-History Instructions: <automatic | none | custom>
📏 Context window: <8k | 16k | 32k | 128k | 200k | custom | auto>
🔍 Detail: <recommended | full detail | quick>
📦 Output: <format>
🌀 Dynamic state: <off | review | custom | preserve>  [Advanced lore-bearing only]
⚙️ Interface: <Simple | Advanced>
[1] Start build
[2] Review a page
[3] Change a setting
[4] Cancel
```
Do not declare settings complete while canon stance, artifact type, required era approval, fixed Scenario text, or output target remains materially unresolved.

## Tools submenu

Reached from the greeting's `🛠️ Tools` line. Unlike Build, Tools operates on an artifact that already exists; each card states the Batch 7 capability tier it needs, so the tier is visible before anything runs rather than surfacing three steps in as a gate error. Verified against `capability_tiers.py`'s own `TIER_CAPABILITIES`, not asserted: Audit, Prune, Iterate, Convert, Art, and Graphics Designer need only `unbound`-level capabilities (structural edit, derived activation graph, diff proof, format validation, import probe) and work on a hand-made or third-party artifact with no WorldBuilder history at all; Update/Merge needs `entry_naming_normalization` and `worldbuilder_lineage_reading`, both exclusive to `legacy_bound` and above, since folding in new material without losing IDs requires reading a prior, tracked ID set an Unbound artifact does not have.

Art's tier is orthogonal to a separate, real prerequisite: `capability_probe.py`'s existing `image_generate` gate. The Art card always appears: prompts and descriptors without rendered images are still real, usable output when `image_generate` is unavailable, the same distinction `first_time_setup.py`'s `image_generation_status` already draws. But check that gate before rendering the card's subtitle, so the wording itself says which mode applies rather than leaving the person to discover the limit only after selecting Art and committing to a request.

Text tier:

```text
🛠️ TOOLS

  🔍 Audit          errors, drift, contradictions, import safety     tier: unbound
  ✂️ Prune          cut what can co-fire, without losing lore        tier: unbound
  ✏️ Iterate        revise entries, keys, or card fields             tier: unbound
  🔀 Update/Merge   fold new material in without losing IDs          tier: legacy
  📦 Convert        between JSON, native World Info, CHARX, PNG      tier: unbound
  🖼️ Art            prompts, card art, expression sets               tier: unbound
  🎨 Graphics Designer  Regex, tracker state, greeting HTML/CSS       tier: unbound
                    (rendered images need image_generate; prompts/descriptors always work)

  unbound  works on any lorebook, including hand-made ones
  legacy   also reads older WorldBuilder output
  bound    needs a current WorldBuilder build

Say a tool name, or "home" to go back.
```

Widget tier: one card per tool, each showing name, one-line purpose, and a tier badge (`references/widgets/tools.md`). Selecting a tool routes to that tool's own intake, which resolves the actual artifact and reports its real tier via `capability_tiers.detect_tier`: the submenu's tier label is what the tool needs at minimum, never a claim about the specific artifact the person is about to upload. The Art card's subtitle in the widget names the same image_generate dependency, checked via the same `capability_probe.py` preflight before the card renders.

## Styling tokens

Widget-tier screens use host theme tokens exclusively; never a hardcoded color, hex value, or named CSS color, since any of those will clash with whatever theme the person's client runs. Available tokens (verified against docs.openclaw.ai/tools/show-widget): `--surface`, `--card`, `--elevated`, `--text`, `--text-strong`, `--muted`, `--border`, `--border-strong`, `--accent`, `--accent-fill`, `--accent-fg`, `--ok`, `--warn`, `--danger`, `--info`, `--radius`, `--font-body`, `--font-mono`, plus the derived translucent backgrounds `--accent-subtle`, `--ok-subtle`, `--warn-subtle`, `--danger-subtle`, `--info-subtle`. Helper classes: `.card`, `.badge` (plus `.ok`/`.warn`/`.danger`/`.info`), `.metric`, `.muted`, `.row`, `button.primary`. Page background stays transparent. At most one `--accent-fill` primary action per screen; more than one and nothing reads as the recommended next step.

Widget code stays under 262,144 characters inline (48 KiB on Discord specifically) and renders at a clamped height of 48-1200px. Every `sendPrompt` call needs a real, non-empty click-triggered call, under 4,000 characters, and cannot start with `/`; auto-firing on load does nothing, and a widget is rate-limited to 10 prompts per rolling minute. Widgets have no return channel: a widget cannot read its own reply, so state lives in the conversation, not the widget, and each page after the first is a fresh widget emitted once the previous selection returns through chat. A session keeps at most 32 widgets before evicting the oldest; a long Advanced settings flow plus a build can reach that.
