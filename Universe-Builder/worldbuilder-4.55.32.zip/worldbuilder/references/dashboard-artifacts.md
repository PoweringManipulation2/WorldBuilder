# Dashboard Artifacts
WorldBuilder emits renderer-neutral projections only; a host may render them, but the JSON never becomes planning or release authority.
- Run `python scripts/dashboard_artifacts.py --build-state <build-state.json>` after planning to write all four files under `artifacts/dashboard/`.
- `build_health.json` reports measurable dimensions only: trigger coverage, orphans, recursion/budget pressure, phase quality, source coverage, conflicts, and knowledge-boundary findings. There is no aggregate score.
- `activation_graph.json` keeps `manifest.activation_graph.edges` as the sole authoritative edge table; relationships, eras, sources, factions, and protection are labeled derived views.
- `source_coverage.json` preserves discovery accounting as included/filtered/merged/ignored/unsupported; builds without discovery report `not_applicable`.
- `build_progress.json` consolidates the existing stage ledger and discovery/planning/generation/audit/budget state without creating a second workflow state machine.
