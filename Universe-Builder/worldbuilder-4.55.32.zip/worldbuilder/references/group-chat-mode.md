# Group Chat Mode
## Navigation

- [Output](#output)
- [Shared versus private knowledge](#shared-versus-private-knowledge)
- [Talkativeness](#talkativeness)
- [Workflow](#workflow)
## Output

Produce:

- One Schema 1 V3 card per participant.
- One optional shared Schema 3 lorebook.
- A setup/readme describing the intended group and user settings.

Do not embed identical shared lore in every card unless the user explicitly wants self-contained duplicates.
## Shared versus private knowledge

Put common setting, factions, locations, and events in the shared lorebook. Keep character-private motivations and secrets in the relevant card or filtered entry.

Use character filters only when the selected SillyTavern target supports and preserves them.
## Talkativeness

Talkativeness represents a 0-100% speaking probability in group chat; SillyTavern commonly defaults to 50%. Repeated values are valid. WorldBuilder may recommend role-based tuning, but diversity quotas are not compatibility requirements.

Group-only greetings may be used for group-specific openings. Alternate greetings remain ordinary first-message swipes.
## Workflow

1. Define roster, relationships, shared/private boundaries, and timeframe mode.
2. Complete shared source synthesis. If multiple eras are selectable, confirm the era plan before any card or shared-lore manifest is created.
3. Create one shared `character-plan.json` (or an explicitly linked family of child plans) covering stable identities, per-era states, directed relationships, private knowledge, and card/lorebook UID ownership.
4. Build and validate each Schema 1 card with canonical character routing and the correct selected-era state.
5. Build the shared lorebook through the Schema 3 architecture: World Invariants/World Core, Era Contexts when applicable, then chronological state phases.
6. Run architecture, schema, audit, and delivery gates for every card and the shared lorebook.
7. Test group turn behavior with the user's actual group settings.
8. Release cards and lorebook with a concise import README and exact era-selection instructions.

```bash
python3 {baseDir}/scripts/validate_output.py shared-lorebook.json --profile sillytavern
```

## Era and character architecture

Each group card is its own star and uses the Schema 1 canonical character routing. The shared lorebook uses the mandatory lorebook architecture. If multiple eras are selectable, confirm an era plan and filter shared characters, factions, locations, and events through `era-system.md`; do not let one card's current state leak into another era.

Read `character-identity-system.md`. Relationship records are directed and state-specific. Keep private motives and secrets out of shared entries unless the selected target has an explicit filtered route for them.

## Card-shell routing

Read `card-shell-routing.md`. Freeze whether the opening is `shared`, `individual`, or `both`, plus the greeting policy, in `card-shell-plan.json`. Each member card still follows Character field routing. Do not duplicate shared lore into card Description or Personality.

For multi-era builds, the era router owns exact Scenario phrases, boundaries, world state, active-entity graph seeds, past/future events, knowledge restrictions, state assertions, and prohibited state terms. Exactly one era line may be active in Scenario.

Before release, read `full-integration-acceptance.md`; require the frozen route-specific integration plan and current receipts, skipping only systems marked not applicable.
