# Schemas and Serialization
## Navigation
- [Format selection](#format-selection)
- [Character Card V3](#character-card-v3)
- [Schema 1](#schema-1)
- [Schema 2](#schema-2)
- [Schema 3](#schema-3)
- [CCv3 lorebook entries](#ccv3-lorebook-entries)
- [Decorators](#decorators)
- [SillyTavern-native World Info](#sillytavern-native-world-info)
- [Application extensions](#application-extensions)
- [Persona text](#persona-text)
- [CHARX](#charx)
- [PNG card](#png-card)
- [Conversion rules](#conversion-rules)
## Format selection
WorldBuilder uses the following internal labels:
- **Schema 1**: `chara_card_v3` without `data.character_book`.
- **Schema 2**: `chara_card_v3` with `data.character_book`, including an empty entries array.
- **Schema 3**: a standalone lorebook, either the CCv3 `lorebook_v3` wrapper or a declared SillyTavern-native World Info export.
- **Persona**: plain UTF-8 text, not JSON.
The schema numbers are WorldBuilder routing labels. They do not replace each format's own `spec` discriminator.
## Character Card V3
Use the exact top-level discriminator:
```json
{
  "spec": "chara_card_v3",
  "spec_version": "3.0",
  "data": {}
}
```
Do not accept `chara_card_v2` as V3. Convert it explicitly and record the conversion.
A V3 card's `data` object carries the Tavern-style character fields, V3 additions, and an `extensions` object. Keep unknown fields when round-tripping. Current validation expects correctly typed values for the declared V3 fields, including arrays such as `alternate_greetings`, `tags`, and `group_only_greetings`.
Character name is the essential SillyTavern authoring field, but a serialized V3 object still follows its format contract. Do not confuse UI minimalism with a partial JSON schema.
## Schema 1
Schema 1 has no embedded lorebook:
```json
{
  "spec": "chara_card_v3",
  "spec_version": "3.0",
  "data": {
    "name": "Example",
    "description": "...",
    "personality": "",
    "scenario": "...",
    "first_mes": "...",
    "mes_example": "<START>\n{{user}}: ...\n{{char}}: ...",
    "creator_notes": "...",
    "system_prompt": "",
    "post_history_instructions": "",
    "alternate_greetings": [],
    "group_only_greetings": [],
    "tags": [],
    "creator": "",
    "character_version": "1.0",
    "extensions": {}
  }
}
```
Empty strings and arrays may be legitimate. WorldBuilder profile suggestions such as a minimum tag count or rating label are not schema requirements.
Alternate greetings are first-message swipes. They do not require `<START>`.
Optional V3 metadata is sparse and lifecycle-owned:
- `nickname` is optional and may change `{{char}}` substitution behavior.
- `creator_notes_multilingual` is an object keyed by lowercase ISO 639-1 codes.
- `source` is an array of provenance IDs or HTTP(S) URLs and is preserved append-only.
- `creation_date` and `modification_date` are non-negative Unix seconds; preserve imported values and never substitute empty strings.
- `assets` contains validated descriptors. Standard types are `icon`, `background`, `emotion`, `user_icon`, and `other`; custom types use `x_`.
When `system_prompt` or `post_history_instructions` is non-empty, SillyTavern users must enable **Prefer Character Prompt** or **Prefer Character Instructions** respectively. Use `{{original}}` when the character field should include rather than replace the configured global prompt.
## Schema 2
Schema 2 adds a Lorebook object at `data.character_book`:
```json
{
  "spec": "chara_card_v3",
  "spec_version": "3.0",
  "data": {
    "name": "Example",
    "description": "...",
    "personality": "",
    "scenario": "...",
    "first_mes": "...",
    "mes_example": "",
    "creator_notes": "...",
    "system_prompt": "",
    "post_history_instructions": "",
    "alternate_greetings": [],
    "group_only_greetings": [],
    "tags": [],
    "creator": "",
    "character_version": "1.0",
    "extensions": {},
    "character_book": {
      "name": "Example lore",
      "description": "",
      "scan_depth": 4,
      "token_budget": 2048,
      "recursive_scanning": true,
      "extensions": {},
      "entries": []
    }
  }
}
```
`name`, `description`, `scan_depth`, `token_budget`, and `recursive_scanning` are optional Lorebook fields. `extensions` and `entries` are format fields; `entries` may be empty. In SillyTavern 1.18, the three book-level control values are not activated per imported book; the application uses global World Info settings.
Detect Schema 2 by structural presence of `data.character_book`, not by whether entries is non-empty.
## Schema 3
### CCv3 standalone wrapper
```json
{
  "spec": "lorebook_v3",
  "data": {
    "name": "Example lore",
    "extensions": {},
    "entries": []
  }
}
```
This is the V3 portable standalone form. Optional Lorebook fields may be omitted. SillyTavern 1.18 does not consume this wrapper as a direct World Info import; convert it to the native target before import.
### SillyTavern-native World Info
SillyTavern World Info imports use a top-level `entries` collection and app-specific field names. Treat this as a distinct target, not as a malformed `lorebook_v3` wrapper. Declare the target in build state and use the `sillytavern` validation profile.
For JSON character-card import, write strict UTF-8 without a BOM. Read `sillytavern-import-contract.md`; the named SillyTavern profile must place application settings under each embedded entry's `extensions` object using the exact importer spellings.
Native entries may be a list or keyed object depending on the export path/version. Preserve the container style for preserve-format updates; an explicit native conversion may normalize to a UID-keyed object.
## CCv3 lorebook entries
Core required shape:
```json
{
  "keys": ["primary trigger"],
  "content": "Text inserted when the entry activates.",
  "extensions": {},
  "enabled": true,
  "insertion_order": 100,
  "use_regex": false
}
```
Optional fields include `name`, `id`, `comment`, `priority`, `case_sensitive`, `constant`, `selective`, `secondary_keys`, and core `position`. `use_regex` is part of the portable entry model, but SillyTavern's embedded-book converter does not read that flag. The named profile translates regex patterns to slash-delimited SillyTavern key strings and preserves the source values in a recovery extension. `priority` is preserved but has no active mapping in the tested importer.
Core `position`, when present, is only:
- `before_char`
- `after_char`
SillyTavern supports additional insertion locations. Store those in the tested SillyTavern extension representation or native World Info fields; do not manufacture unsupported core position values.
For CCv3 embedded and standalone lorebook entries, use the optional top-level `id` field as the stable identity. Do **not** emit a top-level `uid`; CCv3 does not define it. When an application-specific UID must be preserved, store it under `extensions` and keep it consistent with the canonical `id` only as an application policy, not as a format requirement. SillyTavern-native World Info uses top-level `uid` instead. Do not require `name == comment` or `extensions.uid == id` as a universal format rule.
## Decorators
A third representation of runtime semantics, alongside the neutral envelope and native extension fields: decorators are the spec's own portable emission form. `scripts/decorators.py` parses them; the single-owner rule (DR-074) means each semantic picks exactly one form, never both: decorator for the portable path, native extension key for the named SillyTavern profile.
Grammar: `@@name value` or bare `@@name`, one per line, forming a contiguous leading block at the start of `content`, not scattered mid-prose. `@@@name value` (three `@`) is a fallback for an application that does not recognize the primary decorator immediately above it, not an independent second decorator. Recognized names this codebase resolves ownership for: `depth`, `role`, `activate_only_after` (`placement_context`/`dynamic_state`'s canonical values); many others exist in the spec and round-trip through unrecognized but preserved.
Trimming: the leading decorator block, and the blank line(s) separating it from prose, are removed before the content is prompted or counted as tokens; they were never real content. A line starting with `@@` that does not match `NAME [VALUE]` shape ends the block; everything from there is ordinary prose.
## SillyTavern-native World Info
Typical native entry fields include:
```json
{
  "uid": 7,
  "key": ["trigger"],
  "keysecondary": [],
  "comment": "Editor memo",
  "content": "...",
  "constant": false,
  "vectorized": false,
  "selective": false,
  "selectiveLogic": 0,
  "order": 100,
  "position": 0,
  "disable": false,
  "probability": 100,
  "useProbability": true,
  "preventRecursion": false
}
```
These fields are application data, not CCv3 core. Missing optional SillyTavern settings should use application defaults rather than trigger a V3 schema error. Validate the type and internal consistency of any field that is present.
Insertion position, recursion, per-entry scan depth, probability, groups, timed effects, vector behavior, and active `characterFilter` are application data. WorldBuilder defaults are profile advice only. Embedded `extensions.character_filter` is preservation-only because the character-book converter does not map it.
## Application extensions
Every extension mapping is versioned application behavior. Keep app-specific keys inside `extensions`, preserve unknown keys, and never assert that camelCase or snake_case is universally required by CCv3.
WorldBuilder's conservative repair script:
- Fixes only safe type/placement problems.
- Leaves optional settings absent.
- Moves extended placement out of the CCv3 core `position` field.
- Adds legacy aliases only with `--legacy-mirrors`.
## WorldBuilder semantic intermediate representation
`worldbuilder-semantic-ir` is a parent-owned conversion model, not an import format. It carries card/lorebook content, activation/recursion, placement, budgets, dynamic semantics, assets, source metadata, and unknown data without choosing target spelling early.
After audit, `runtime_target_adapter.py` imports corrected bytes and emits Schema 1, embedded CCv3, standalone `lorebook_v3`, native World Info, CHARX, group-set, or persona-plus-lorebook output. Portable targets keep neutral semantics; a named profile owns application fields. Every export reports compatibility, reopens bytes, compares semantics, and writes a receipt. See `runtime-target-adapter.md`.
## Persona text
A SillyTavern user persona description is plain UTF-8 text. It is not a card and has no `spec`, `data`, or JSON wrapper.
Use a separate Schema 3 lorebook when a persona needs deep conditional lore.
## CHARX
A CHARX file is an unencrypted ZIP containing `card.json` at archive root and optional embedded assets. Use `/` separators and portable ASCII names for every path component. Validate duplicate names case-insensitively.
Asset descriptors require `type`, `uri`, `name`, and lowercase extension text without a leading dot. Audio assets should use an appropriate voice/audio application type rather than being forced into a generic asset bucket.
## PNG card
The dominant real-world card distribution format. The PNG is a container; the character JSON lives inside a `tEXt` chunk, base64-encoded. `scripts/png_card.py` reads and writes it, pure stdlib; it avoids Pillow, which would change the skill's own declared `anyBins` contract.
Chunk layout: signature (`\x89PNG\r\n\x1a\n`), then a sequence of length(4)/type(4)/data(length)/CRC32(4) chunks ending at `IEND`. `tEXt` chunk data is `keyword` + `\x00` + `text`; the keyword is `chara` (V2) or `ccv3` (V3), `ccv3` preferred when both are present. `text` is base64-encoded UTF-8 JSON, not raw text; `tEXt`'s own text portion is technically Latin-1, so base64 is the safe encoding for arbitrary JSON bytes.
Writing replaces every existing `chara`/`ccv3` chunk with exactly one fresh `ccv3` chunk, placed where the first old one was or immediately before the first `IDAT` if none existed. Every other chunk (the actual image) is copied byte-for-byte, never re-encoded; this is a chunk-boundary operation, not an image decode.
## Conversion rules
- Preserve unknown fields and application namespaces.
- Preserve stable identifiers and reject duplicate identities.
- Generate V1/V2 mirrors only when the user selects a tested legacy target.
- Record source format, target format, and any lossy mapping.
- Never silently label native World Info as CCv3 or vice versa.
