# Subagent Dispatch Contract
## Navigation

- [Worker kit](#worker-kit)
- [Assignment file](#assignment-file)
- [Spawn call](#spawn-call)
- [Generation order](#generation-order)
- [Completion](#completion)
- [Recovery](#recovery)
## Worker kit

`init_build.py` stages:

```text
.work/worker-kit/
  bundle.json
  prompts/
  references/
  scripts/
    evidence_gate.py
    entry_cycle_gate.py
    character_contract.py
    wb_common.py
```

Manuals use relative links such as `../references/schemas.md`. Do not rewrite them with an absolute skill-installation path. The bundle contains hashes so stale copies can be detected.
## Assignment file

Keep variable data in JSON, not a giant generated prompt. Generation assignments use version 3 and include a deterministic activation-map slice:

```json
{
  "assignment_version": 3,
  "assignment_id": "wb-sample-raven-phase-0002",
  "build_id": "...",
  "manifest_sha256": "...",
  "activation_map_sha256": "...",
  "field_registry_sha256": "...",
  "default_profile_sha256": "...",
  "character_plan_sha256": "... when characters are assigned",
  "map_slice": {"slice_version": 2, "entries": [], "edges": [], "character_context": {}},
  "role": "generation",
  "worker": "raven",
  "schema": 3,
  "research_mode": "public_web",
  "entries": [
    {
      "uid": 7,
      "name": "Example",
      "research_topics": ["identity", "appearance", "history"]
    }
  ],
  "evidence_output": "artifacts/discoveries/phase-0002-evidence.json",
  "evidence_receipt": ".work/evidence-receipts/phase-0002-evidence-receipt.json",
  "output": ".work/phases/phase-0002.json",
  "end_delimiter": "END WORLDBUILDER GENERATION REPORT"
}
```

Validate paths are relative to the build root and cannot escape it. Audit and research-only assignments may use their own role-specific versions; do not reuse a generation assignment without its research fields.
## Spawn call

Use a short task that points to the manual and assignment. Set:

- `task`
- stable `taskName`
- human-readable `label`
- `cwd` = build root
- `context` = isolated unless transcript context is truly needed
- optional `cleanup`

Normal workers use the native subagent runtime. Do not add channel-delivery fields. Pass the assignment's stamped `run_timeout_seconds` as `sessions_spawn`'s `runTimeoutSeconds` argument, a computed liveness bound (DR-064), never a value this task estimates itself. If the child times out, record it with `--status timed_out` (never `--status failed`) on the matching recorder, then re-dispatch the identical assignment_id with the raised multiplier `repair_loop_guard.py` suggests; completed checkpoints or cached fetches are never repeated.

After fan-out, yield for completion events when supported. Do not poll in loops.
## Generation order

A generation worker performs one bounded two-stage job:

```text
process each assigned UID as research → validate → write/checkpoint before the next UID
  -> write evidence ledger
  -> run evidence_gate.py
  -> generate entries from validated claim IDs
  -> write bound phase output
```

A global research summary does not replace the UID-level evidence ledger. Character workers must use only the exact identity/state/relationship context in the map slice. The phase is rejected unless current assignment, manifest, activation-map, registry/profile, character-plan when applicable, evidence, and receipt hashes are recorded in phase metadata.
## Completion

The parent validates all channels of evidence:

1. OpenClaw runtime status is completed.
2. Evidence ledger exists and covers every assigned UID and topic.
3. Evidence receipt matches current assignment, manifest, activation map, registry/profile, character plan when applicable, evidence, and build.
4. Expected phase file exists.
5. Phase identities match assignment exactly.
6. Phase claim IDs belong to the corresponding UID's evidence record.
7. `unsupported_claims` is empty and the role-specific validator passes.
8. Exact end delimiter appears in the child report.

The result text is evidence, not authority. A missing delimiter is incomplete even when no failure token appears.
## Recovery

For failed, timed-out, truncated, or evidence-incomplete work:

- Inspect the run once for diagnosis.
- Fix capability, path, assignment, or source failures.
- Split oversized assignments while keeping stable UIDs and output phase numbers.
- Rerun research for the affected assignment; do not reuse a receipt after assignment or evidence bytes change.
- Reuse the intended output and phase number only after replacing invalid bytes.
- Re-run all gates that bind changed files.

## Worker naming

Assign workers from this stable pool in order: **Raven, Magpie, Wren, Finch, Sparrow, Robin, Heron, Lark, Swift, Owl, Hawk, Falcon, Crow, Jay, Kestrel**. Use the same readable name in `worker`, `taskName`, label, assignment ID, and filename slug. Never use opaque UUID-like worker labels in user-visible logs. If more than fifteen workers are needed, reuse the pool with an explicit round suffix such as `Raven R2` and slug `raven-r2`. Recovery workers keep the next available bird name or a clear suffix such as `Wren Recovery 1`.
## Absolute-path task card

Every discovery task card must name the bird and provide absolute paths for the worker prompt, assignment, candidate, commit helper, cache, final output, and runtime receipt. When a card's page carries images, it also states the researched per-model image limits, the computed subagent count for that page, and the processed-image-count receipt the worker must return so the parent can verify page coverage (vision_parameters.py). Register the run before dispatch. Do not use `cwd` alone as artifact identity; use it only to resolve staged worker-kit relative links. The parent must abandon a failed run ID before switching backends, and late events from abandoned IDs are quarantined.
