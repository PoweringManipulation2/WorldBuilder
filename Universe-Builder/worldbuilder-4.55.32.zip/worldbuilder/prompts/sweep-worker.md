# Research Sweep Worker Manual
## Navigation
- [Role](#role)
- [Mandatory reads](#mandatory-reads)
- [Assignment validation](#assignment-validation)
- [Exact URL ownership](#exact-url-ownership)
- [Fandom and MediaWiki transport](#fandom-and-mediawiki-transport)
- [Research procedure](#research-procedure)
- [Discovery output](#discovery-output)
- [Completion contract](#completion-contract)
## Non-negotiable runtime contract (v7)
- Require `assignment_version: 7`, `contract.contract_version: 3`, `fetch_policy`, and `dispatch_wave` before fetching any page.
- Use only the absolute paths in the assignment. Never resolve `.work/...` relative to `sessions_spawn.cwd`; OpenClaw may bootstrap a different workspace.
- Copy the assignment `contract` block unchanged into `_worldbuilder.contract` and emit `result_version: 2`.
- Account for every owned URL exactly once as visited, failed, excluded, or delegated.
- Give every excluded URL a registered `code` plus a substantive reason. Valid codes are documented in `scripts/discovery_contract.py`.
- Emit exactly one fetch record per owned URL, including excluded and failed URLs.
- Write the candidate JSON only to `candidate_abs`, then run `commit_worker_result_abs --assignment <assignment_abs> --candidate <candidate_abs>`. Never write directly to `output_abs`. The commit helper validates the contract, taxonomy, URL ownership, and JSON before atomically renaming the final result.
- Classify collective pages deliberately: species, population, rank, faction, and organization are not interchangeable with character. Preserve categories and lead text so the deterministic taxonomy pass can verify the choice.
- If assignment, prompt, script, cache, or output access fails, stop immediately with a path-access failure. Do not respawn the same task in the same stale session.
## Role
Research only the exact URLs assigned to this bird-named worker.
Dynamic-state and target boundary: you may recommend candidate optional behavior with a reason, but do not write probability, groups, timed effects, filters, triggers, automation IDs, outlets, target-native fields, compatibility reports, or conversion receipts. The parent must freeze semantics first and owns every Batch 9 runtime-target conversion.
 Produce breadth evidence for the parent to synthesize into the build list, recursion map, and manifest. Do not edit planning artifacts or final outputs.
## Mandatory reads
1. Read the assignment JSON in full.
2. Read `<build_root>/.work/worker-kit/references/global-rules.md`.
3. Read `<build_root>/.work/worker-kit/references/info-mode.md`.
4. Read `<build_root>/.work/worker-kit/references/parallel-research-pipeline.md`.
5. Read any mode/source reference named by the assignment.
Use the absolute paths embedded in the assignment. Do not assume `sessions_spawn.cwd` is honored. Relative paths are convenience aliases only.
The kit's complete tool list is `<build_root>/.work/worker-kit/TOOLS.md`; read it before doing a tool's work by hand.
## Assignment validation
Require all of the following before fetching a page:
- `assignment_version` is exactly `7`.
- `role` is `research`.
- `stage` is `breadth_discovery`, `breadth_recovery`, or `breadth_verification`.
- Build ID, corpus SHA-256, pass number, worker bird name, `taskName`, exact `page_urls`, output path, and end delimiter are present.
- Output is under `<build_root>/artifacts/discoveries/`.
- The current assignment file hash is available for output metadata.
- Every assigned URL is an absolute HTTP(S) URL.
- `fetch_policy` is present for MediaWiki/Fandom assignments and names the exact allowed host, API endpoint, transport order, and cache directory.
- `fetch_policy.content_filter_policy` is present. It controls media/production scope and the deterministic post-fetch page classifier.
- `dispatch_wave` identifies the health-gated ramp wave. Do not run a locked wave.
Fail without the success delimiter when any condition is false.
## Exact URL ownership
Treat `page_urls` as an exact ownership ledger for this pass.
- Attempt every assigned URL exactly once.
- Do not claim a URL assigned to another worker.
- Classify each assigned URL into exactly one of `visited_urls`, `failed_urls`, `excluded_urls`, or `delegated_urls`.
- Include a substantive reason for every excluded or delegated URL. The reason is free
  text and must be **at least five characters**: `"junk"` is rejected, `"wiki policy
  page"` is accepted.
- Every entry in `excluded_urls` also needs a `code` from the list below. An unlisted
  code is rejected, so pick the closest match rather than inventing one; use
  `manual_scope_exclusion` when nothing else fits.
- A URL appears in **exactly one** of `visited_urls`, `failed_urls`, `excluded_urls`, or
  `delegated_urls`. Listing the same URL in two of them is rejected, and every assigned
  URL must appear in one of them.
### Valid exclusion codes
| `broken_redirect` | - |
| `disambiguation_or_index` | - |
| `duplicate_canonical` | - |
| `empty_or_blank_page` | - |
| `empty_page` | - |
| `facet_filter_mismatch` | User-confirmed source facet does not match this page's MediaWiki categories/templates |
| `gallery_or_media_only` | - |
| `http_terminal_failure` | - |
| `index_or_navigation` | - |
| `maintenance_page` | - |
| `manual_scope_exclusion` | - |
| `message_wall` | - |
| `non_content_namespace` | - |
| `optional_media` | - |
| `out_of_scope_language` | - |
| `production_metadata` | - |
| `redirect_alias` | - |
| `redirect_loop` | - |
| `reference_only` | - |
| `robots_or_access_denied` | - |
| `unsupported_media` | - |
| `user_discussion` | - |
Never exclude a page for being low quality, a stub, or tagged for cleanup. Those are
signals about how good an article is, not about whether it is one.
- Record newly found same-site content URLs only in `discovered_urls`; do not silently crawl them unless the assignment explicitly owns them.
- Let the parent create targeted recovery assignments for failures, delegations, and newly discovered URLs.
- Never use a shared mutable visited file.
## Fandom and MediaWiki transport
For every MediaWiki/Fandom article, use the staged adapter rather than opening the normal article page first:
```bash
python3 "<assignment.worker_kit_root>/scripts/wiki_fetch.py" \
  --url "<owned article URL>" \
  --api-url "<assignment.fetch_policy.api_url>" \
  --cache-dir "<assignment.fetch_policy.cache_directory_abs>" \
  --output ".work/page-cache/records/<worker>/<stable-name>.json"
```
The enforced order is:
1. `api.php?action=parse` rendered HTML plus wikitext, links, categories, templates, and table-of-contents data.
2. MediaWiki revision wikitext.
3. Normal page HTML only as a last resort.
This is not an anti-bot bypass claim. It is the wiki's documented API representation and must still respect rate limits, access controls, and errors. If normal Fandom HTML is challenged but `action=parse` succeeds, record the page as visited with method `mediawiki_action_parse`. Do not launch a browser retry merely because the decorative article page was blocked.
Stay on `fetch_policy.allowed_host` unless the assignment explicitly enables another language or host. Language links are discovery candidates, not permission to sweep every localization wiki.
Record one `fetch_records` row per attempted owned URL with `url`, terminal `status`, successful `method` when any, and concise failed transport attempts. Persist cache records as work proceeds so an interrupted bird can resume without refetching successful pages.
## Page filtering before extraction
The additive collector deliberately finds more URLs than should become lore entities. Do not spend model context summarizing every URL.
1. Trust the parent prefilter for URLs that were removed before assignment; they are not owned by this worker.
2. For every owned URL, fetch the compact API record first, then run the staged deterministic classifier:
```bash
python3 "<assignment.worker_kit_root>/scripts/discovery_page_filter.py" \
  --fetch-json "<cached fetch record>.json" \
  --source-url "<owned article URL>" \
  --assignment "<assignment_abs>" \
  --output "<classification record>.json"
```
Run this before loading the full rendered HTML or wikitext into model context. The exec fallback calls the same classifier automatically.
Classify pages as follows:
- `content`: extract candidate entities normally.
- `index_only`: harvest namespace-0 links, record an exclusion such as `index_or_navigation` or `disambiguation_or_index`, and do not create an entity for the index itself.
- `reference_only`: retain the URL for later evidence, but do not create a lore entity. Transcripts default to this class.
- `alias_only`: preserve the redirect title as an alias for the canonical target; do not create a duplicate entity.
- `excluded`: record the registered reason code and stop processing the body.
Production metadata (cast, crew, dubbing, localization, staff, studios) is excluded by default. Canon episodes, songs, comics, and shorts remain eligible unless the build policy disables media pages. Gallery, maintenance, discussion, Message Wall, history/diff, and wiki-infrastructure pages never consume full extraction context.
This filter is recall-preserving: index pages may contribute links, redirects contribute aliases, and reference-only pages remain available for later per-UID evidence. Filtering removes expensive entity extraction, not source accounting.
## Research procedure
1. Validate that the current assignment belongs to an unlocked dispatch wave.
2. Probe one representative page through `wiki_fetch.py`. If the adapter or assignment is wrong, fail the small wave so the parent repairs it before ramping.
3. Respect bounded pacing, robots directives, and the assigned partition.
4. Follow redirects and record redirect titles as aliases when relevant.
5. Run the page classification gate before full reading. Only `content` pages receive normal extraction; index/reference/excluded pages are accounted without entity prose.
6. For `content` pages, inspect titles, lead text, infoboxes, categories, relationship links, and internal links, then extract candidates broadly: characters, aliases/forms, locations, factions, organizations, species, objects, abilities, systems, events, eras, terminology, and relationships. Classify collective biological/supernatural kinds, populations, ranks presented as peoples, and taxonomic groups such as Demons, Angels, Sinners, Exorcists, Imps, Hellhounds, and Humans as `species`, not `character`; preserve political orders such as Ars Goetia as `faction` unless the source explicitly treats them as a species.
7. Preserve source URLs for every entity.
8. Record concise paraphrases; do not copy long passages.
9. Distinguish direct source facts from inferences and unresolved conflicts.
10. Do not treat the breadth sweep as deep factual research. Later generation workers must independently research every assigned UID.
11. Record concrete fetch failures rather than hiding them.
## Discovery output
Write one UTF-8 JSON file at `assignment.output`:
```json
{
  "_worldbuilder": {
    "kind": "breadth-discovery",
    "build_id": "...",
    "assignment_id": "...",
    "assignment_sha256": "...",
    "corpus_sha256": "...",
    "worker": "Raven",
    "taskName": "discovery_p01_raven",
    "pass_number": 1,
    "completed": true,
    "runtime_status": "completed",
    "contract": {
      "contract_version": 3,
      "assignment_schema_version": 7,
      "result_schema_version": 2,
      "runtime_receipt_version": 3,
      "worker_prompt_version": 7,
      "page_filter_version": 1,
      "gate_receipt_version": 4
    },
    "child_session_id": "optional: echo only when OpenClaw exposes it to you; otherwise omit",
    "end_delimiter": "WORLDBUILDER_DISCOVERY_COMPLETE:..."
  },
  "covered_scope": ["exact URL ownership: 80 page(s)"],
  "entities": [
    {
      "name": "...",
      "type": "character|location|faction|species|concept|event|system|object|ability|other",
      "aliases": [],
      "concepts": [],
      "relationships": [],
      "source_urls": ["https://..."]
    }
  ],
  "visited_urls": ["https://..."],
  "fetch_records": [
    {
      "url": "https://...",
      "status": "visited",
      "method": "mediawiki_action_parse",
      "attempts": []
    }
  ],
  "failed_urls": [],
  "excluded_urls": [{"url": "https://...", "code": "non_content_namespace", "reason": "wiki policy page, not world content"}],
  "delegated_urls": [],
  "discovered_urls": ["https://..."],
  "unresolved": [],
  "no_results": false
}
```
Requirements:
- Make metadata match the assignment exactly.
- Do not invent a child session ID. Echo it only when OpenClaw exposes it inside the child; otherwise omit that optional metadata field. The parent records the authoritative session ID separately.
- Ground every entity in at least one URL the worker actually visited; a merely discovered URL is a recovery candidate, not factual evidence.
- Include exactly one `fetch_records` row for every assigned URL and make its terminal status agree with the ownership outcome arrays.
- For MediaWiki/Fandom assignments, successful visited pages should normally use `mediawiki_action_parse` or `mediawiki_revision_wikitext`; `normal_page_html` is the last fallback.
- Account for every assigned URL exactly once across the four outcome arrays.
- Use `no_results: true` only when the entire owned scope was processed and yielded no relevant entities.
- Preserve aliases and source evidence when the same entity appears on multiple pages.
## Completion contract
On success, report the bird name, output path, assigned/visited/failed/excluded/delegated counts, entity count, newly discovered URL count, and exact assignment delimiter as the final non-empty line.
On failure, omit the delimiter. A missing delimiter, missing file, wrong ownership, stale corpus binding, incomplete runtime, or unaccounted URL is incomplete and must be recovered.
## Budget boundary
Bounded source-set discovery coverage is independent of context budgets. Do not omit supported URLs or entities to satisfy Compact/Recommended/Maximum Detail targets. Record the full inventory; later planning and pruning control active context with receipts.
## Full-integration boundary
The parent owns `worldbuilder-full-integration-v1`. Read only the exact assignment slices supplied to you; do not create, edit, or self-certify pipeline-registry, integration-plan, integration-gate, audit-runtime, adapter, or delivery receipts.
