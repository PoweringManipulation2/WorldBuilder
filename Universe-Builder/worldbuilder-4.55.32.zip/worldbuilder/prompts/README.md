# WorldBuilder Worker Manuals

These manuals are immutable source inside the skill. `scripts/init_build.py` copies them and `references/` into each build's private `.work/worker-kit/` and writes `bundle.json` with file hashes.

Workers run with the build root as `cwd` and read relative paths:

```text
.work/worker-kit/prompts/<role>-worker.md
.work/worker-kit/references/*.md
.work/assignments/<taskName>.json
```

Do not deploy a shared prompt directory, substitute an absolute skill path, or edit the installed copies. A new build receives a fresh versioned kit automatically.

Parent dispatch tasks should contain only:

```text
Read .work/worker-kit/prompts/generation-worker.md in full.
Read .work/assignments/wb_r1_raven.json and execute it exactly.
Resolve relative paths from the supplied working directory.
```

Generation assignment JSON carries exact UIDs, required research topics, evidence and phase paths, build/manifest/activation-map binding, a deterministic map slice, character identity/state/relationship context, era-router context, resolved placement/influence context when applicable, and the end delimiter. A generation worker must process one UID as research → gate → write/checkpoint → gate before opening the next UID, then pass the aggregate `scripts/evidence_gate.py` and assemble only validated checkpoints. The parent accepts work only when OpenClaw reports completed status, evidence and phase lineage validate, assignment coverage is exact, unsupported claims are empty, and the exact end delimiter is present.
## Parent-only proof tools

`source_probe.py`, `discovery_plan.py`, `discovery_wave_gate.py`, `record_discovery_runtime.py`, `discovery_gate.py`, `discovery_recovery.py`, `audit_plan.py`, `record_audit_runtime.py`, and `audit_gate.py` are intentionally **not** staged into the child worker kit. The parent runs them from `{baseDir}/scripts` so discovery and audit workers cannot create their own runtime-completion receipts or approve their own work.

`wiki_fetch.py` and `discovery_page_filter.py` are staged for child workers. The first provides API-first MediaWiki/Fandom retrieval and caching; the second classifies compact fetch records before full page text enters model context. Neither creates runtime receipts or approves work.
