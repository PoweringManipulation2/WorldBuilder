# Compatibility Baseline

This release separates portable Character Card V3 semantics from named application profiles. Compatibility claims are intentionally narrow.

## Named targets

- Character Card V3: portable Schema 1/2/3 structures and CHARX packaging where supported by the bundled validators/adapters.
- SillyTavern: named runtime profile `sillytavern-1.18.0` for the field/import behavior encoded by `references/compatibility-baseline.json` and `scripts/compatibility_check.py`.
- OpenClaw: skill execution, subagent dispatch, workspace operation, and host capability behavior described by `SKILL.md` and the OpenClaw references.
- SearXNG: public-web research uses the configured SearXNG path and required egress/preflight rules rather than silently switching providers.

## Portable versus native output

Portable CCv3/lorebook output is not automatically a native SillyTavern World Info file. The runtime target adapter owns conversion. Named-profile output maps only semantics the target profile can represent and reports unsupported/lossy cases instead of silently claiming equivalence.

The adapter supports Character cards, embedded `character_book`, standalone portable lorebooks, SillyTavern-native World Info, CHARX, character groups with shared lore, and personas with optional lore where the selected route permits them.

## Runtime semantics

Dynamic-state, placement, vectorization, recursion, filters, triggers, groups, probability, timing, and other runtime behavior remain target-neutral until a named adapter owns their serialization. Unknown application metadata is preserved where the selected operation promises preservation.

Activation prediction and live runtime observation are separate evidence classes. Synthetic scanner output is labeled predicted; it never becomes a claim of observed SillyTavern behavior. Live-runtime evidence requires the applicable host/install introspection path.

## Third-party extensions

Quick Replies, Regex, Vector Storage, Timed Effects, MVU, EJS, and other extension integrations use the specific serializers and compatibility notes in `references/extension-adapters.md` and related references. Presence of a serializer does not install, enable, or certify an extension.

## Compatibility drift

`references/compatibility-baseline.json` freezes the claim-level checks for the named SillyTavern profile. `scripts/compatibility_check.py` reports `clean`, `drift`, or `error`; it does not auto-upgrade the profile or certify an unnamed/newer version. Network failures are errors, not evidence of compatibility.

## Not implied

This package does not claim compatibility with unnamed SillyTavern versions or forks, every OpenClaw host configuration, every model/provider, every third-party extension revision, or every operating-system/network environment. A portable artifact also does not imply native-import compatibility unless the corresponding target/profile check passes.

## Primary upstream references

- OpenClaw subagents: https://docs.openclaw.ai/tools/subagents
- OpenClaw skills: https://docs.openclaw.ai/tools/creating-skills
- OpenClaw agent workspace: https://docs.openclaw.ai/concepts/agent-workspace
- SillyTavern Character Design: https://docs.sillytavern.app/usage/core-concepts/characterdesign/
- SillyTavern World Info: https://docs.sillytavern.app/usage/core-concepts/worldinfo/
- Character Card V3 proposal: https://github.com/kwaroran/character-card-spec-v3/blob/main/SPEC_V3.md
- MediaWiki parsing API: https://www.mediawiki.org/wiki/API:Parsing_wikitext
