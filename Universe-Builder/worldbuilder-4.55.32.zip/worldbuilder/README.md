# WorldBuilder 4.55.32

WorldBuilder builds, audits, converts, prunes, and maintains SillyTavern Character Card V3 artifacts, lorebooks, personas, group assets, and related runtime packages.

## Install

```bash
openclaw skills install ./worldbuilder --as worldbuilder
```

Or place the `worldbuilder/` directory in the active OpenClaw skills directory. Python 3.10+ is required.

## Use

Invoke the skill with no task for the guided menu:

```text
/skill worldbuilder
```

Or state the operation directly, for example:

```text
/skill worldbuilder build a lorebook for <setting>
/skill worldbuilder audit this card
/skill worldbuilder convert this to SillyTavern native World Info
```

`📚 Info / Help` is the documentation hub. Design-why questions use `references/design-rationale.md`, which is the compact release contract containing all 130 current design decisions and their regression boundaries.

## Output model

- Character: Schema 1 V3 JSON or CHARX.
- World: Schema 2 V3 JSON or CHARX with a thin setting-first shell and embedded lorebook.
- Lorebook: portable `lorebook_v3` by default, or SillyTavern-native World Info when explicitly selected.
- Group chat: Schema 1 cards plus shared lore.
- Persona: UTF-8 text with optional lorebook.
- Audit, Prune, Iteration, Update/Merge, Quick Build, Full Detail, Soul Extractor, image-prompt/image-generation, and runtime-bundle workflows are routed by `SKILL.md` and the mode references.

## Important behavior

Portable output and named runtime profiles are separate choices. A portable `lorebook_v3` file is not the same shape as SillyTavern-native World Info. Ask for the SillyTavern target when direct import is required.

Validation is layered:

```bash
python3 scripts/validate_output.py artifact.json --profile spec
python3 scripts/validate_output.py artifact.json
python3 scripts/validate_output.py artifact.json --profile worldbuilder
```

WorldBuilder editorial preferences remain warnings unless a documented contract makes them mandatory.

## Runtime package layout

```text
SKILL.md            routing and core contracts
references/         runtime manuals, schemas, compatibility data, compact design decisions
scripts/            deterministic planners, gates, validators, adapters, and utilities
prompts/            subagent worker manuals
agents/openai.yaml  skill UI metadata
VERSION             release version
```

Development history, regression suites, fixtures, maintainer packaging machinery, and engineering evidence are intentionally not included in this public runtime package.

## Security

Treat third-party skills as executable code and review them before enabling. WorldBuilder keeps generated artifacts and scratch state in the selected build workspace rather than its install directory. Host-level setup or repair actions are plan-first and require the explicit apply path described by the relevant reference.
