#!/usr/bin/env python3
"""Create an isolated WorldBuilder build workspace and staged worker kit.

Mutable build data never belongs in the installed skill. By default this script
creates ``<approved WorldBuilder workspace>/builds/<unique build id>`` and copies
immutable prompt/reference sources into that build's private ``.work`` area.
Final deliverables may later be exported to a user-selected Desktop or custom
folder without exporting scratch files.
"""
from __future__ import annotations

import argparse
import ast
import hashlib
import json
import os
import re
import secrets
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from wb_common import AUDIT_LENSES, WORKER_BIRD_NAMES, WorldBuilderError, atomic_write_json, load_build_state, sha256_file
from model_routing import resolve_models
from card_shell_contract import CONTRACT as CARD_SHELL_CONTRACT, build_plan as build_card_shell_plan
from character_contract import CONTRACT as CHARACTER_SYSTEM_CONTRACT
from placement_contract import CONTRACT as PLACEMENT_CONTRACT, build_plan as build_placement_plan
from budget_contract import CONTRACT as BUDGET_CONTRACT, build_plan as build_budget_plan
from pruning_objectives import OBJECTIVE_DEFINITIONS as PRUNING_OBJECTIVE_DEFINITIONS
from design_index import render_index
from settings_preset import CONTRACT as SETTINGS_PRESET_CONTRACT, apply_preset_to_namespace
from dynamic_state_contract import CONTRACT as DYNAMIC_STATE_CONTRACT, build_plan as build_dynamic_state_plan
from integration_acceptance import CONTRACT as INTEGRATION_CONTRACT, build_plan as build_integration_plan, load_registry as load_pipeline_registry
from pipeline_stage_gate import CONTRACT as PIPELINE_STAGE_CONTRACT, advance as advance_pipeline_stage

VERSION = "3.6"

WORKER_SCRIPT_NAMES: tuple[str, ...] = (
    "evidence_gate.py",
    "source_semantics.py",
    "entry_cycle_gate.py",
    "lock_contract.py",
    "activation_map_gate.py",
    "character_contract.py",
    "era_router_contract.py",
    "placement_contract.py",
    "placement_semantics.py",
    "budget_contract.py",
    "budget_semantics.py",
    "pruning_objectives.py",
    "terminology_dictionary.py",
    "facet_inference.py",
    "activation_semantics.py",
    "ground_truth_graph.py",
    "plan_reconciliation.py",
    "st_activation_scanner.py",
    "prevent_recursion_candidates.py",
    "compress_for_vision_model.py",
    "vision_parameters.py",
    "decorators.py",
    "debug_log.py",
    "dynamic_state_contract.py",
    "wiki_fetch.py",
    "discovery_contract.py",
    "discovery_page_filter.py",
    "entity_taxonomy.py",
    "commit_worker_result.py",
    "run_discovery_worker.py",
    "wb_common.py",
)

# Batch 60 E: pipeline-scoped worker tool staging.
#
# WORKER_SCRIPT_NAMES above is the full universe a kit may stage. The tables
# below record, as explicit data, which scripts serve which pipeline systems
# (never a name-similarity guess: "budget" names two scripts and "era_router"
# is not the module name). A kit stages WORKER_KIT_CORE, WORKER_KIT_ERA, the
# scripts of every system in the build's required plus optional sets, and the
# import closure of all of the above.
WORKER_KIT_CORE: tuple[str, ...] = (
    "wb_common.py",
    "debug_log.py",
    "entry_cycle_gate.py",
    "evidence_gate.py",
    "source_semantics.py",
    "terminology_dictionary.py",
    "compress_for_vision_model.py",
    "ground_truth_graph.py",
    "st_activation_scanner.py",
    "prevent_recursion_candidates.py",
)

# Era tooling stages unconditionally: era need is resolved only at the
# post-discovery era checkpoint, after the kit is built, and
# activation_map_gate imports era_router_contract, so every generating kit
# carries it anyway. The alternative is restaging at the checkpoint; the
# 4.55.20 decision is unconditional staging, recorded in the batch 60
# blast-radius note.
WORKER_KIT_ERA: tuple[str, ...] = ("era_router_contract.py",)

WORKER_SYSTEM_SCRIPTS: dict[str, tuple[str, ...]] = {
    "field_registry": ("decorators.py",),
    "card_shell": ("decorators.py",),
    "character_architecture": ("character_contract.py",),
    "target_adapter": (),
    "activation_graph": (
        "activation_map_gate.py",
        "activation_semantics.py",
        "ground_truth_graph.py",
        "st_activation_scanner.py",
        "prevent_recursion_candidates.py",
    ),
    "era_router": ("era_router_contract.py",),
    "placement": ("placement_contract.py", "placement_semantics.py"),
    "budget": (
        "budget_contract.py",
        "budget_semantics.py",
        "plan_reconciliation.py",
        "pruning_objectives.py",
        "decorators.py",
    ),
    "dynamic_state": ("dynamic_state_contract.py",),
    "four_auditor_gate": ("ground_truth_graph.py", "st_activation_scanner.py", "plan_reconciliation.py", "prevent_recursion_candidates.py"),
    "capability_tiers": (),
    "structural_edit": (),
    "diff_proof": ("plan_reconciliation.py",),
    "change_set": (),
    "pruning_receipts": ("pruning_objectives.py",),
    "lineage_invalidation": (),
    "stable_phase_ids": (),
    "receipt_revalidation": (),
    "breadth_discovery": (
        "wiki_fetch.py",
        "discovery_contract.py",
        "discovery_page_filter.py",
        "entity_taxonomy.py",
        "commit_worker_result.py",
        "run_discovery_worker.py",
        "facet_inference.py",
    ),
    "full_detail": (),
}

# The DR-078 capture separator, assembled so this file carries no bare
# separator run for the prose dash lint to flag.
_CAPTURE_SEPARATOR = " " + "-" * 2 + " "

WORKER_TOOL_ROLES: dict[str, str] = {
    "evidence_gate.py": "generation",
    "source_semantics.py": "generation",
    "entry_cycle_gate.py": "generation",
    "lock_contract.py": "generation, audit",
    "activation_map_gate.py": "generation, audit",
    "character_contract.py": "generation, audit",
    "era_router_contract.py": "generation, audit",
    "placement_contract.py": "generation, audit",
    "placement_semantics.py": "generation, audit",
    "budget_contract.py": "generation, audit",
    "budget_semantics.py": "generation, audit",
    "pruning_objectives.py": "audit",
    "terminology_dictionary.py": "generation",
    "facet_inference.py": "research",
    "activation_semantics.py": "generation, audit",
    "ground_truth_graph.py": "audit",
    "plan_reconciliation.py": "audit",
    "st_activation_scanner.py": "audit",
    "prevent_recursion_candidates.py": "audit",
    "compress_for_vision_model.py": "generation, research",
    "vision_parameters.py": "generation, research",
    "decorators.py": "generation, audit",
    "debug_log.py": "all",
    "dynamic_state_contract.py": "generation, audit",
    "wiki_fetch.py": "research",
    "discovery_contract.py": "research",
    "discovery_page_filter.py": "research",
    "entity_taxonomy.py": "research",
    "commit_worker_result.py": "research",
    "run_discovery_worker.py": "research",
    "wb_common.py": "all",
}

WORKER_TOOL_INVOCATION: dict[str, str] = {
    "evidence_gate.py": "python scripts/evidence_gate.py --build-state <state> --assignment <assignment>",
    "source_semantics.py": "import source_semantics",
    "entry_cycle_gate.py": "python scripts/entry_cycle_gate.py --build-state <state> --assignment <assignment> --stage <research|write|refresh|finalize>",
    "lock_contract.py": "python scripts/lock_contract.py lock --build-state <state> --uid <uid>",
    "activation_map_gate.py": "python scripts/activation_map_gate.py --build-state <state>",
    "character_contract.py": "python scripts/character_contract.py --build-state <state>",
    "era_router_contract.py": "python scripts/era_router_contract.py --build-state <state> --stage <stage>",
    "placement_contract.py": "python scripts/placement_contract.py --build-state <state> --stage <stage>",
    "placement_semantics.py": "import placement_semantics",
    "budget_contract.py": "python scripts/budget_contract.py --build-state <state> --stage <stage>",
    "budget_semantics.py": "import budget_semantics",
    "pruning_objectives.py": "import pruning_objectives",
    "terminology_dictionary.py": "python scripts/terminology_dictionary.py validate --dictionary <dictionary> --manifest <manifest>",
    "facet_inference.py": "python scripts/facet_inference.py --build-state <state> --output <path>",
    "activation_semantics.py": "import activation_semantics",
    "ground_truth_graph.py": "python scripts/ground_truth_graph.py --input <phase> --manifest <manifest> --output <report>",
    "plan_reconciliation.py": "python scripts/plan_reconciliation.py --input <phase> --output <report>",
    "st_activation_scanner.py": "import st_activation_scanner",
    "prevent_recursion_candidates.py": "python scripts/prevent_recursion_candidates.py --input <book> --manifest <manifest> --output <report>",
    "compress_for_vision_model.py": "python scripts/compress_for_vision_model.py --input <image> --output <image>",
    "vision_parameters.py": "python scripts/vision_parameters.py plan --image-count <n> --max-images-per-request <n>",
    "decorators.py": "import decorators",
    "debug_log.py": "python scripts/debug_log.py capture --build-state <state>" + _CAPTURE_SEPARATOR + "<command>",
    "dynamic_state_contract.py": "python scripts/dynamic_state_contract.py --build-state <state> --stage <stage>",
    "wiki_fetch.py": "python scripts/wiki_fetch.py --url <page-url> --output <path>",
    "discovery_contract.py": "python scripts/discovery_contract.py --build-state <state>",
    "discovery_page_filter.py": "python scripts/discovery_page_filter.py --urls-json <path> --output <path>",
    "entity_taxonomy.py": "python scripts/entity_taxonomy.py --input <path> --output <path>",
    "commit_worker_result.py": "python scripts/commit_worker_result.py --assignment <assignment> --candidate <candidate>",
    "run_discovery_worker.py": "python scripts/run_discovery_worker.py --assignment <assignment>",
    "wb_common.py": "import wb_common",
}

# Rendered into the kit at staging time from references/design-rationale.md; a
# projection, never a source file, so it is never copied from references/.
GENERATED_WORKER_REFERENCES: tuple[str, ...] = ("design-decisions.md",)


def now_utc() -> datetime:
    return datetime.now(timezone.utc)


def iso_now() -> str:
    return now_utc().replace(microsecond=0).isoformat().replace("+00:00", "Z")


def slugify(value: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", value.casefold()).strip("-")
    return slug[:48] or "build"


def unique_build_id(name: str) -> str:
    stamp = now_utc().strftime("%Y%m%dT%H%M%SZ")
    return f"{slugify(name)}-{stamp}-{secrets.token_hex(3)}"


def atomic_copy_tree(source: Path, target: Path) -> None:
    if not source.is_dir():
        raise WorldBuilderError(f"worker-kit source directory is missing: {source}")
    temporary = target.with_name(f".{target.name}.{secrets.token_hex(4)}.tmp")
    if temporary.exists():
        shutil.rmtree(temporary)
    shutil.copytree(source, temporary)
    os.replace(temporary, target)


def _worker_inventory_ignored(path: Path, root: Path) -> bool:
    rel = path.relative_to(root)
    return "__pycache__" in rel.parts or path.suffix == ".pyc"


def staged_files(root: Path) -> list[dict[str, str]]:
    items: list[dict[str, str]] = []
    for path in sorted(root.rglob("*")):
        if path.is_file() and not _worker_inventory_ignored(path, root):
            items.append(
                {
                    "path": str(path.relative_to(root)).replace(os.sep, "/"),
                    "sha256": sha256_file(path),
                }
            )
    return items


def _worker_reference_names(skill_root: Path, *, full: bool) -> list[str]:
    """Names copied from references/ into the kit; generated references are
    excluded here because stage_worker_kit renders them instead of copying."""
    if full:
        names = sorted(path.name for path in (skill_root / "references").glob("*.md") if path.is_file())
    else:
        named: set[str] = set()
        for manual in sorted((skill_root / "prompts").glob("*.md")):
            named.update(re.findall(r"references/([A-Za-z0-9._-]+\.md)", manual.read_text(encoding="utf-8")))
        names = sorted(named)
    return [name for name in names if name not in GENERATED_WORKER_REFERENCES]


def _skill_release(skill_root: Path) -> str:
    version_file = skill_root / "VERSION"
    if not version_file.is_file():
        raise WorldBuilderError(f"installed skill has no VERSION file: {version_file}")
    release = version_file.read_text(encoding="utf-8").strip()
    if not release:
        raise WorldBuilderError(f"installed skill VERSION is empty: {version_file}")
    return release


def _worker_source_inventory(skill_root: Path, *, full: bool, scripts: tuple[str, ...]) -> list[dict[str, str]]:
    files: list[tuple[str, Path]] = []
    prompts_root = skill_root / "prompts"
    for path in sorted(prompts_root.rglob("*")):
        if path.is_file() and not _worker_inventory_ignored(path, prompts_root):
            files.append((f"prompts/{path.relative_to(prompts_root).as_posix()}", path))
    for name in _worker_reference_names(skill_root, full=full):
        path = skill_root / "references" / name
        if not path.is_file():
            raise WorldBuilderError(f"worker manual names a missing reference: references/{name}")
        files.append((f"references/{name}", path))
    for name in scripts:
        path = skill_root / "scripts" / name
        if not path.is_file():
            raise WorldBuilderError(f"worker-kit child script is missing: scripts/{name}")
        files.append((f"scripts/{name}", path))
    generator = skill_root / "scripts" / "design_index.py"
    if not generator.is_file():
        raise WorldBuilderError("worker-kit design index generator is missing: scripts/design_index.py")
    files.append(("scripts/design_index.py", generator))
    return [{"path": rel, "sha256": sha256_file(path)} for rel, path in sorted(files)]


def _inventory_digest(rows: list[dict[str, str]]) -> str:
    payload = json.dumps(rows, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def _bundle_file_map(bundle: dict[str, Any]) -> dict[str, str]:
    rows = bundle.get("files") if isinstance(bundle.get("files"), list) else []
    return {
        str(row.get("path")): str(row.get("sha256"))
        for row in rows if isinstance(row, dict) and isinstance(row.get("path"), str) and isinstance(row.get("sha256"), str)
    }


def worker_kit_status(build_root: Path, *, skill_root: Path | None = None) -> dict[str, Any]:
    """Compare a staged worker kit with the currently installed skill source."""
    build_root = build_root.resolve()
    skill_root = (skill_root or Path(__file__).resolve().parent.parent).resolve()
    kit = build_root / ".work" / "worker-kit"
    bundle_path = kit / "bundle.json"
    if not bundle_path.is_file():
        return {"status": "stale", "stale": True, "reasons": ["worker-kit bundle.json is missing"], "worker_kit": str(kit)}
    bundle = json.loads(bundle_path.read_text(encoding="utf-8"))
    if not isinstance(bundle, dict):
        raise WorldBuilderError(f"worker-kit bundle has the wrong format: {bundle_path}")
    full = bundle.get("staging_mode") == "full"
    raw_scripts = bundle.get("child_scripts")
    if isinstance(raw_scripts, list) and raw_scripts and all(
        isinstance(name, str) and name in WORKER_SCRIPT_NAMES for name in raw_scripts
    ):
        staged_scripts = tuple(raw_scripts)
    else:
        staged_scripts = WORKER_SCRIPT_NAMES
    current_inventory = _worker_source_inventory(skill_root, full=full, scripts=staged_scripts)
    current_digest = _inventory_digest(current_inventory)
    current_release = _skill_release(skill_root)
    reasons: list[str] = []
    if bundle.get("skill_release") != current_release:
        reasons.append(f"skill_release {bundle.get('skill_release')!r} != installed {current_release!r}")
    if bundle.get("source_digest") != current_digest:
        reasons.append("staging source digest differs from the installed prompts/references/child scripts")
    expected = _bundle_file_map(bundle)
    observed_rows = [row for row in staged_files(kit) if row["path"] != "bundle.json"]
    observed = {row["path"]: row["sha256"] for row in observed_rows}
    if expected != observed:
        added = sorted(set(observed) - set(expected))
        removed = sorted(set(expected) - set(observed))
        updated = sorted(path for path in set(expected) & set(observed) if expected[path] != observed[path])
        reasons.append(f"staged files drifted (added={added}, updated={updated}, removed={removed})")
    return {
        "status": "stale" if reasons else "current",
        "stale": bool(reasons),
        "reasons": reasons,
        "worker_kit": str(kit),
        "bundle": str(bundle_path),
        "skill_release": bundle.get("skill_release"),
        "installed_skill_release": current_release,
        "worker_kit_sha256": bundle.get("source_digest"),
        "installed_source_digest": current_digest,
        "staging_mode": "full" if full else "minimal",
    }


def _intra_kit_imports(source: str) -> set[str]:
    """Names among WORKER_SCRIPT_NAMES that this source imports."""
    universe = set(WORKER_SCRIPT_NAMES)
    deps: set[str] = set()
    for node in ast.walk(ast.parse(source)):
        if isinstance(node, ast.ImportFrom) and node.module:
            name = node.module.split(".")[0] + ".py"
            if name in universe:
                deps.add(name)
        elif isinstance(node, ast.Import):
            for alias in node.names:
                name = alias.name.split(".")[0] + ".py"
                if name in universe:
                    deps.add(name)
    return deps


def _stage_closure(selected: set[str], *, skill_root: Path) -> set[str]:
    """Close a script set over the staged scripts' own intra-kit imports."""
    pending = list(selected)
    while pending:
        name = pending.pop()
        source = (skill_root / "scripts" / name).read_text(encoding="utf-8")
        for dep in _intra_kit_imports(source):
            if dep not in selected:
                selected.add(dep)
                pending.append(dep)
    return selected


def worker_kit_scripts(
    *,
    pipeline: str | None,
    systems: tuple[str, ...] | None,
    skill_root: Path,
) -> tuple[str, ...]:
    """Resolve the Batch 60 E staged script set for one build.

    The set is WORKER_KIT_CORE, WORKER_KIT_ERA, the scripts of every system in
    the build's required plus optional sets, and the import closure of those
    scripts. A missing or unknown system widens to the full universe: an
    over-staged kit costs disk, and an under-staged kit costs a silent worker
    failure."""
    if not systems:
        return WORKER_SCRIPT_NAMES
    registry = load_pipeline_registry(skill_root / "references" / "pipeline-registry.json")
    row = registry["pipelines"].get(pipeline) if pipeline else None
    scope = list(systems)
    if isinstance(row, dict):
        scope.extend(str(name) for name in row.get("optional_systems", []))
    selected: set[str] = set(WORKER_KIT_CORE) | set(WORKER_KIT_ERA)
    for system in scope:
        mapped = WORKER_SYSTEM_SCRIPTS.get(system)
        if mapped is None:
            return WORKER_SCRIPT_NAMES
        selected.update(mapped)
    selected = _stage_closure(selected, skill_root=skill_root)
    return tuple(name for name in WORKER_SCRIPT_NAMES if name in selected)


def _staging_systems(systems: tuple[str, ...] | list[str], *, discovery_required: bool) -> tuple[str, ...]:
    """The staged system set for one build: the build's systems plus breadth
    discovery when discovery is required but the plan predates the flag (the
    custom-pipeline research path). Stage the superset here: an under-staged
    kit costs a silent worker failure."""
    names = [str(name) for name in systems]
    if discovery_required and "breadth_discovery" not in names:
        names.append("breadth_discovery")
    return tuple(names)


def _build_state_kit_scope(build_root: Path) -> tuple[str | None, tuple[str, ...] | None]:
    """The pipeline and systems a restage should reuse from build-state.json."""
    state_path = build_root / "build-state.json"
    if not state_path.is_file():
        return None, None
    try:
        state = json.loads(state_path.read_text(encoding="utf-8-sig"))
    except (OSError, json.JSONDecodeError):
        return None, None
    if not isinstance(state, dict):
        return None, None
    integration = state.get("integration") if isinstance(state.get("integration"), dict) else {}
    pipeline = integration.get("pipeline")
    systems = integration.get("required_systems")
    pipeline = pipeline if isinstance(pipeline, str) and pipeline else None
    if isinstance(systems, list) and systems:
        discovery = state.get("discovery") if isinstance(state.get("discovery"), dict) else {}
        return pipeline, _staging_systems(systems, discovery_required=bool(discovery.get("required")))
    return pipeline, None


def render_tools_manifest(script_names: tuple[str, ...], *, scripts_root: Path) -> str:
    """Render the staged tool manifest for one kit.

    The one-line purpose comes from each script's module docstring; a missing
    docstring fails staging instead of rendering a blank row, because the
    manifest is how a worker learns the tool exists and how to start it."""
    lines = [
        "# Worker Kit Tools",
        "",
        f"This kit stages {len(script_names)} tools. Generated at staging time; restage the kit to refresh.",
        "",
    ]
    for name in script_names:
        source = (scripts_root / name).read_text(encoding="utf-8")
        docstring = ast.get_docstring(ast.parse(source)) or ""
        purpose_parts: list[str] = []
        for raw_line in docstring.strip().splitlines():
            part = " ".join(raw_line.split())
            if not part:
                break
            purpose_parts.append(part)
            if part.endswith((".", "!", "?", ":", ")", "`")):
                break
        purpose = " ".join(purpose_parts)
        if not purpose:
            raise WorldBuilderError(f"worker tool {name} has no module docstring; the tool manifest cannot render")
        invocation = WORKER_TOOL_INVOCATION.get(name)
        roles = WORKER_TOOL_ROLES.get(name)
        if invocation is None or roles is None:
            raise WorldBuilderError(f"worker tool index is missing {name}; the tool manifest cannot render")
        lines.append(f"- `{name}`: {purpose} Invocation: `{invocation}`. Roles: {roles}.")
    return "\n".join(lines) + "\n"


def _render_generated_kit_assets(
    build_root: Path,
    kit_root: Path,
    *,
    script_names: tuple[str, ...],
    scripts_root: Path,
) -> None:
    """Generated kit content that must never be hand-maintained. The phase
    exit contracts and the Batch 60 E tool manifest render through this one
    staging hook."""
    import phase_contract
    state_candidate = build_root / "build-state.json"
    phase_contract.render_workspace_contracts(
        build_root,
        state_candidate if state_candidate.is_file() else None,
        kit_dir=kit_root / "exit-contracts",
    )
    (kit_root / "TOOLS.md").write_text(
        render_tools_manifest(script_names, scripts_root=scripts_root),
        encoding="utf-8",
        newline="\n",
    )


def stage_worker_kit(
    build_root: Path,
    *,
    skill_root: Path | None = None,
    full: bool = False,
    restage: bool = False,
    pipeline: str | None = None,
    systems: tuple[str, ...] | None = None,
) -> dict[str, Any]:
    """Stage or atomically restage the child-worker manuals and scripts.

    The bundle records the *skill release* separately from the internal worker
    contract version and hashes the canonical staging source.  Restaging uses a
    fresh directory, reports added/updated/removed files, then swaps it into
    place so files removed from the child-script/reference set cannot linger.
    """
    build_root = build_root.resolve()
    skill_root = (skill_root or Path(__file__).resolve().parent.parent).resolve()
    # Batch 60 E scope: a restage reuses the build's recorded systems, a fresh
    # stage passes them from the integration plan, and direct calls widen to
    # the full universe.
    if systems is None:
        state_pipeline, state_systems = _build_state_kit_scope(build_root)
        if pipeline is None:
            pipeline = state_pipeline
        if state_systems is not None:
            systems = state_systems
    staged_scripts = worker_kit_scripts(pipeline=pipeline, systems=systems, skill_root=skill_root)
    target = build_root / ".work" / "worker-kit"
    if target.exists() and not restage:
        raise WorldBuilderError(f"worker kit already exists: {target}; use --restage-worker-kit for an existing build")
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_name(f".{target.name}.{secrets.token_hex(4)}.tmp")
    if temporary.exists():
        shutil.rmtree(temporary)
    temporary.mkdir(parents=True)
    try:
        shutil.copytree(skill_root / "prompts", temporary / "prompts")
        refs = temporary / "references"
        refs.mkdir()
        for name in _worker_reference_names(skill_root, full=full):
            source_ref = skill_root / "references" / name
            if not source_ref.is_file():
                raise WorldBuilderError(f"worker manual names a missing reference: references/{name}")
            shutil.copy2(source_ref, refs / name)
        rationale = skill_root / "references" / "design-rationale.md"
        if not rationale.is_file():
            raise WorldBuilderError(f"worker kit needs references/design-rationale.md to render the decision index: {rationale}")
        (refs / "design-decisions.md").write_text(render_index(rationale.read_text(encoding="utf-8")), encoding="utf-8", newline="\n")
        scripts_dir = temporary / "scripts"
        scripts_dir.mkdir()
        for script_name in staged_scripts:
            source = skill_root / "scripts" / script_name
            if not source.is_file():
                raise WorldBuilderError(f"worker-kit child script is missing: scripts/{script_name}")
            shutil.copy2(source, scripts_dir / script_name)

        _render_generated_kit_assets(
            build_root,
            temporary,
            script_names=staged_scripts,
            scripts_root=temporary / "scripts",
        )

        source_inventory = _worker_source_inventory(skill_root, full=full, scripts=staged_scripts)
        source_digest = _inventory_digest(source_inventory)
        # staged_files() is intentionally evaluated before writing bundle.json,
        # so bundle.json can never recursively list/hash itself.
        bundle = {
            "bundle_version": 3,
            "worldbuilder_version": VERSION,
            "skill_release": _skill_release(skill_root),
            "staging_mode": "full" if full else "minimal",
            "pipeline": pipeline or "all",
            "source_digest": source_digest,
            "child_scripts": list(staged_scripts),
            "created_at": iso_now(),
            "files": staged_files(temporary),
        }
        atomic_write_json(temporary / "bundle.json", bundle)

        previous: dict[str, str] = {}
        if target.is_dir():
            # Compare against the bytes actually present, not only the old
            # bundle's expectation. This makes restage report manual drift and
            # obsolete files as updated/removed instead of silently erasing them.
            previous = {row["path"]: row["sha256"] for row in staged_files(target) if row["path"] != "bundle.json"}
        current = _bundle_file_map(bundle)
        added = sorted(set(current) - set(previous))
        removed = sorted(set(previous) - set(current))
        updated = sorted(path for path in set(previous) & set(current) if previous[path] != current[path])

        if target.exists():
            backup = target.with_name(f".{target.name}.{secrets.token_hex(4)}.old")
            os.replace(target, backup)
            try:
                os.replace(temporary, target)
            except Exception:
                os.replace(backup, target)
                raise
            shutil.rmtree(backup, ignore_errors=True)
        else:
            os.replace(temporary, target)
        return {
            "status": "restaged" if restage else "staged",
            "worker_kit": str(target),
            "bundle": str(target / "bundle.json"),
            "skill_release": bundle["skill_release"],
            "worker_kit_sha256": source_digest,
            "staging_mode": bundle["staging_mode"],
            "pipeline": bundle["pipeline"],
            "child_scripts": list(staged_scripts),
            "added": added,
            "updated": updated,
            "removed": removed,
        }
    finally:
        if temporary.exists():
            shutil.rmtree(temporary, ignore_errors=True)


def default_workspace() -> Path:
    """Return the approved WorldBuilder workspace root.

    Prefer WORLDBUILDER_WORKSPACE. OPENCLAW_WORKSPACE is only a compatibility
    fallback and receives a dedicated WorldBuilder child directory so mutable
    files never land in the OpenClaw installation itself.
    """
    explicit = os.environ.get("WORLDBUILDER_WORKSPACE")
    if explicit:
        return Path(explicit).expanduser().resolve()
    # Do not fall back to the process CWD: OpenClaw is commonly launched from
    # its installation/workspace tree, and mutable build artifacts must never be
    # scattered there. Prefer a visible user workspace instead.
    desktop = Path.home() / "Desktop"
    if desktop.is_dir():
        return (desktop / "WorldBuilder").resolve()
    return (Path.home() / "WorldBuilder").resolve()


def _resolve_source_file_lineage(source_file: str) -> dict[str, Any]:
    """Batch 8: the ORIGINAL uploaded file's own SHA-256, computed before
    any modification; for a .png this is the whole file including its
    image bytes, not just the extracted card JSON, since the round-trip
    guarantee is specifically about the original carrier image. A .png
    must actually contain a readable chara/ccv3 chunk or this raises now,
    at init time, rather than letting a broken upload proceed silently
    into planning with nothing to build from."""
    from wb_common import sha256_file
    path = Path(source_file)
    if not path.is_file():
        raise WorldBuilderError(f"--source-file does not exist: {source_file}")
    suffix = path.suffix.lower()
    if suffix not in (".json", ".png"):
        raise WorldBuilderError(f"--source-file must be .json or .png, got {suffix!r}")
    original_sha256 = sha256_file(path)
    result = {"path": str(path), "format": suffix.lstrip("."), "sha256": original_sha256}
    if suffix == ".png":
        from png_card import extract_card_json
        try:
            _card_data, source_chunk = extract_card_json(path.read_bytes())
        except WorldBuilderError as exc:
            raise WorldBuilderError(f"--source-file {source_file!r} is not a readable PNG card: {exc}")
        result["png_source_chunk"] = source_chunk
    return result


def output_suffix(artifact_type: str) -> str:
    return ".txt" if artifact_type == "persona" else ".json"


def implied_schema(artifact_type: str, requested: str) -> int | str:
    expected: dict[str, int | str] = {
        "card": 1,
        "world": 2,
        "lorebook": 3,
        "group": "package",
        "persona": "text",
    }
    routed = expected.get(artifact_type, "auto")
    if requested == "auto":
        return routed
    explicit = int(requested)
    if isinstance(routed, int) and explicit != routed:
        raise WorldBuilderError(
            f"{artifact_type} mode requires WorldBuilder schema {routed}; got explicit schema {explicit}"
        )
    if not isinstance(routed, int):
        raise WorldBuilderError(f"{artifact_type} mode does not accept a numeric schema override")
    return explicit



def create_or_read_config(workspace: Path, export_root: str | None) -> tuple[Path, dict[str, Any]]:
    # ``workspace`` is the exact user-approved WorldBuilder root (for example
    # ~/Desktop/WorldBuilder). Do not append another nested worldbuilder folder.
    workspace.mkdir(parents=True, exist_ok=True)
    config_path = workspace / "config.json"
    legacy_path = workspace / "worldbuilder" / "config.json"
    if not config_path.exists() and legacy_path.exists():
        try:
            legacy = json.loads(legacy_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            raise WorldBuilderError(f"legacy workspace config is invalid JSON: {legacy_path}: {exc}") from exc
        if isinstance(legacy, dict):
            legacy["migrated_from"] = str(legacy_path)
            if legacy.get("builds_directory") == "worldbuilder/builds":
                legacy["builds_directory"] = "builds"
            atomic_write_json(config_path, legacy)
    if config_path.exists():
        try:
            config = json.loads(config_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            raise WorldBuilderError(f"workspace config is invalid JSON: {config_path}: {exc}") from exc
        if not isinstance(config, dict):
            raise WorldBuilderError("workspace config must contain a JSON object")
    else:
        timestamp = iso_now()
        config = {
            "config_version": 6,
            "created_at": timestamp,
            "updated_at": timestamp,
            "builds_directory": "builds",
            "default_export_root": None,
            "keep_work_files_after_success": False,
            "keep_failed_builds": True,
            "models": {"main": "default", "subagent": "inherit"},
            "batching": {"generation_entries_per_worker": 15},
            "discovery": {"confirmed_dead_after_rounds": 2},
            "timeouts": {"per_uid_seconds": 90, "per_page_seconds": 20},
            "interface": {"mode": "simple"},
            "image_analysis": {"mode": "on"},
        }
    models = config.get("models")
    if not isinstance(models, dict):
        models = {}
    models.setdefault("main", "default")
    models.setdefault("subagent", "inherit")
    config["models"] = models
    batching = config.get("batching")
    if not isinstance(batching, dict):
        batching = {}
    batch_size = batching.get("generation_entries_per_worker", 15)
    if not isinstance(batch_size, int) or isinstance(batch_size, bool) or not 1 <= batch_size <= 50:
        raise WorldBuilderError("config batching.generation_entries_per_worker must be an integer from 1 to 50")
    batching["generation_entries_per_worker"] = batch_size
    config["batching"] = batching
    discovery_cfg = config.get("discovery")
    if not isinstance(discovery_cfg, dict):
        discovery_cfg = {}
    confirmed_dead_after_rounds = discovery_cfg.get("confirmed_dead_after_rounds", 2)
    if not isinstance(confirmed_dead_after_rounds, int) or isinstance(confirmed_dead_after_rounds, bool) or not 0 <= confirmed_dead_after_rounds <= 5:
        raise WorldBuilderError("config discovery.confirmed_dead_after_rounds must be an integer from 0 to 5")
    discovery_cfg["confirmed_dead_after_rounds"] = confirmed_dead_after_rounds
    config["discovery"] = discovery_cfg
    timeouts_cfg = config.get("timeouts")
    if not isinstance(timeouts_cfg, dict):
        timeouts_cfg = {}
    per_uid_seconds = timeouts_cfg.get("per_uid_seconds", 90)
    if not isinstance(per_uid_seconds, int) or isinstance(per_uid_seconds, bool) or not 10 <= per_uid_seconds <= 600:
        raise WorldBuilderError("config timeouts.per_uid_seconds must be an integer from 10 to 600")
    timeouts_cfg["per_uid_seconds"] = per_uid_seconds
    per_page_seconds = timeouts_cfg.get("per_page_seconds", 20)
    if not isinstance(per_page_seconds, int) or isinstance(per_page_seconds, bool) or not 5 <= per_page_seconds <= 120:
        raise WorldBuilderError("config timeouts.per_page_seconds must be an integer from 5 to 120")
    timeouts_cfg["per_page_seconds"] = per_page_seconds
    config["timeouts"] = timeouts_cfg
    interface = config.get("interface")
    if not isinstance(interface, dict):
        interface = {}
    interface_mode = str(interface.get("mode", "simple")).strip().casefold()
    if interface_mode not in {"simple", "advanced"}:
        raise WorldBuilderError("config interface.mode must be simple or advanced")
    interface["mode"] = interface_mode
    config["interface"] = interface
    image_analysis_cfg = config.get("image_analysis")
    if not isinstance(image_analysis_cfg, dict):
        image_analysis_cfg = {}
    image_analysis_mode = str(image_analysis_cfg.get("mode", "on")).strip().casefold()
    if image_analysis_mode not in {"on", "off"}:
        raise WorldBuilderError("config image_analysis.mode must be on or off")
    image_analysis_cfg["mode"] = image_analysis_mode
    config["image_analysis"] = image_analysis_cfg
    # Validate model routing while loading the workspace. Legacy configs with
    # only main/subagent remain valid and resolve all child roles to subagent.
    resolve_models(models)
    config["config_version"] = max(6, int(config.get("config_version", 0) or 0))
    if export_root is not None:
        config["default_export_root"] = str(Path(export_root).expanduser())
        config["updated_at"] = iso_now()
    atomic_write_json(config_path, config)
    return config_path, config




def planning_profile_id(artifact_type: str, era_mode: str) -> str:
    if artifact_type == "world":
        return "world-multi-era" if era_mode == "multi" else "world-single-era"
    if artifact_type == "card":
        return "character-single-era"
    if artifact_type == "group":
        return "group-shared-lorebook"
    if artifact_type in {"lorebook", "audit", "convert"}:
        return "standalone-lorebook"
    return "character-single-era"


def freeze_planning_contract(skill_root: Path, build_root: Path, build_id: str, artifact_type: str, era_mode: str, timestamp: str) -> tuple[dict[str, Any], dict[str, Any]]:
    registry_source_path = skill_root / "references" / "field-registry.json"
    profiles_source_path = skill_root / "references" / "default-profiles.json"
    try:
        registry_source = json.loads(registry_source_path.read_text(encoding="utf-8"))
        profiles_source = json.loads(profiles_source_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise WorldBuilderError(f"bundled planning registry/profile JSON is invalid: {exc}") from exc
    if not isinstance(registry_source, dict) or registry_source.get("kind") != "worldbuilder-field-registry-source":
        raise WorldBuilderError("bundled field registry has the wrong format")
    if not isinstance(profiles_source, dict) or profiles_source.get("kind") != "worldbuilder-default-profile-source":
        raise WorldBuilderError("bundled default profiles have the wrong format")
    profile_id = planning_profile_id(artifact_type, era_mode)
    profiles = profiles_source.get("profiles")
    if not isinstance(profiles, dict) or not isinstance(profiles.get(profile_id), dict):
        raise WorldBuilderError(f"bundled default profile is missing: {profile_id}")
    registry = {
        "kind": "worldbuilder-field-registry",
        "registry_version": int(registry_source.get("registry_version", 1)),
        "build_id": build_id,
        "frozen_at": timestamp,
        "source_sha256": sha256_file(registry_source_path),
        "scope": registry_source.get("scope"),
        "blank_semantics": registry_source.get("blank_semantics", {}),
        "fields": registry_source.get("fields", []),
    }
    registry_path = build_root / "artifacts" / "field-registry.json"
    atomic_write_json(registry_path, registry)
    source_profile = profiles[profile_id]
    profile = {
        "kind": "worldbuilder-default-profile",
        "profile_version": int(profiles_source.get("profile_version", 1)),
        "build_id": build_id,
        "profile_id": profile_id,
        "frozen_at": timestamp,
        "source_sha256": sha256_file(profiles_source_path),
        "field_registry_sha256": sha256_file(registry_path),
        "blank_semantics": profiles_source.get("blank_semantics", {}),
        "description": source_profile.get("description", ""),
        "defaults": source_profile.get("defaults", {}),
        "layer_overrides": source_profile.get("layer_overrides", {}),
    }
    profile_path = build_root / "artifacts" / "default-profile.json"
    atomic_write_json(profile_path, profile)
    return registry, profile

def safe_relative(path: Path, root: Path) -> str:
    try:
        return str(path.resolve().relative_to(root.resolve())).replace(os.sep, "/")
    except ValueError:
        return str(path.resolve())


def parse_context_window(value: str | None) -> tuple[str, int | None]:
    if value is None:
        return "legacy", None
    text = value.strip().casefold().replace(",", "")
    if text == "auto":
        return "auto", None
    match = re.fullmatch(r"(\d+)(k)?", text)
    if not match:
        raise WorldBuilderError("--context-window must be auto, an integer token count, or a value such as 32k")
    amount = int(match.group(1)) * (1000 if match.group(2) else 1)
    if amount < 1024:
        raise WorldBuilderError("--context-window must be at least 1024 tokens")
    return "fixed", amount


def build_argument_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Create a unique WorldBuilder build workspace.")
    parser.add_argument("name", help="Human-readable project/build name.")
    parser.add_argument("--workspace", help="Exact approved WorldBuilder workspace root, e.g. ~/Desktop/WorldBuilder.")
    parser.add_argument("--build-dir", help="Explicit new build directory instead of workspace/builds/<id>.")
    parser.add_argument("--artifact-type", choices=["card", "lorebook", "world", "group", "persona", "convert", "audit", "prune", "resume-recovery", "iterate", "update"], default="lorebook")
    parser.add_argument("--schema", choices=["auto", "1", "2", "3"], default="auto")
    parser.add_argument("--persona-mode", choices=["simple", "split"], default="simple")
    parser.add_argument("--source-stance", choices=["user-canonical", "source-canonical", "hybrid"], default="hybrid")
    parser.add_argument("--settings-preset", help="Portable settings_preset.json. Validated allowlisted values become defaults; explicit CLI settings win.")
    parser.add_argument("--conditions", default="", help="Exact accepted [3] Conditions & Modifications text. Stored verbatim in build-state settings.conditions; use an empty value for [none].")
    parser.add_argument("--image-analysis-mode", choices=("on", "off"), default=None, help="Per-build override of Home Config image-analysis mode; defaults to the saved Home Config value.")
    parser.add_argument("--vision-capable", choices=("available", "unavailable"), default=None, help="Current generation-model/session vision capability reported by the calling agent. Omitted means unknown and image analysis degrades off.")
    parser.add_argument(
        "--debug-log", action=argparse.BooleanOptionalAction, default=None,
        help="Record problems and their exact reproduction commands to artifacts/debug-log.jsonl. "
             "Off by default; adds a small overhead per captured command and is the fastest way to "
             "produce a shareable report of what went wrong.",
    )
    parser.add_argument(
        "--autonomy",
        choices=["consent-required", "evidence-bounded"],
        default=None,
        help=(
            "consent-required (default): every discovery stop and exclusion needs the user's own words. "
            "evidence-bounded: the model may self-approve ONLY where the build's own evidence already "
            "proves the closure condition: frontier closed, every expected URL accounted for, and every "
            "exclusion classified non-content. Scope decisions are never self-approvable under either setting."
        ),
    )
    parser.add_argument("--retrieval", choices=["keyword", "hybrid", "vector-first", "auto"], default="auto", help="Retrieval profile from the settings menu. Frozen here so the manifest can be checked against the approved choice.")
    parser.add_argument("--recursion", choices=["off", "controlled", "expansive", "custom"], default="controlled", help="Recursion profile from the settings menu. Frozen here; activation planning must honour it.")
    parser.add_argument("--source-kind", choices=["original", "known-property", "provided-corpus", "existing-lorebook"], default="original", help="Known-property builds require the parallel breadth-discovery sweep before planning. existing-lorebook builds on a supplied artifact: entries default to unverified confidence and enter verification triage rather than being trusted or swept uniformly.")
    parser.add_argument(
        "--source-file",
        help=(
            "Batch 8: path to the uploaded source artifact for an existing-lorebook build, "
            ".json or .png. When given, the ORIGINAL file's own SHA-256 (before any modification) "
            "is stamped into lineage.input. A .png is read via png_card.py's chara/ccv3 tEXt chunk "
            "extraction (ccv3 preferred); the file must actually contain a readable card, or this "
            "fails now rather than letting a broken upload proceed silently into planning."
        ),
    )
    parser.add_argument("--pipeline", choices=["sequential", "parallel"], default="sequential")
    parser.add_argument("--custom-pipeline", action="store_true", help="Use conversational planning/freeform generation after the user explicitly answers [2A] Guided Mode = yes.")
    parser.add_argument("--guided-mode-answer", choices=["yes", "no"], help="Explicit answer to settings question [2A] Guided Mode. A yes answer is the authority for --custom-pipeline.")
    parser.add_argument("--guided-mode-default", choices=["yes", "no"], help="The [2A] default shown to the user, recorded so build-state can prove whether it was accepted or overridden.")
    parser.add_argument("--custom-trigger-reason", help="Auditable note accompanying the explicit [2A] guided-mode routing decision.")
    parser.add_argument("--custom-source-research", choices=["none", "known-property"], default="none", help="Optional established-property research feeding a guided/custom target.")
    parser.add_argument("--era-mode", choices=["single", "multi"], default="single", help="Content architecture timeframe mode.")
    parser.add_argument("--era-isolation", choices=["strict", "balanced"], default="strict", help="Multi-era split policy; strict is the leakage-resistant default.")
    parser.add_argument("--opening-style", choices=["open", "guided", "fixed", "shared", "individual", "both"], default="open", help="Card or group opening architecture chosen in the guided setup.")
    parser.add_argument("--greeting-policy", choices=["single", "varied", "custom", "era-specific", "shared-style"], default="single", help="Primary/alternate greeting policy.")
    parser.add_argument("--dialogue-policy", choices=["recommended", "none", "custom"], help="Example-dialogue policy; defaults to recommended for Character and none otherwise.")
    parser.add_argument("--scenario-policy", choices=["blank", "fixed"], default="blank", help="Keep Scenario reusable/blank or use an explicitly approved fixed premise.")
    parser.add_argument("--fixed-scenario-file", help="UTF-8 file containing the exact approved fixed Scenario text.")
    parser.add_argument("--system-prompt-policy", choices=["automatic", "none", "custom"], default="automatic")
    parser.add_argument("--post-history-policy", choices=["automatic", "none", "custom"], default="automatic")
    parser.add_argument("--creator-notes-policy", choices=["automatic", "review", "custom"], default="automatic")
    parser.add_argument("--persona-detail", choices=["compact", "detailed", "custom"], default="compact")
    parser.add_argument("--placement-policy", choices=["automatic", "review", "custom"], default="automatic", help="Purpose-based prompt placement policy.")
    parser.add_argument("--placement-overrides-file", help="UTF-8 JSON file with custom layer/entry placement overrides; requires --placement-policy custom.")
    parser.add_argument("--budget-profile", choices=["compact", "recommended", "maximum-detail", "quick", "full-detail"], default="recommended", help="Frozen Detail & Context Profile.")
    parser.add_argument("--context-window", help="Fixed context window (for example 32k) or auto for measurement-first post-merge refinement.")
    parser.add_argument("--budget-policy", choices=["automatic", "review", "custom"], default="automatic", help="Context-budget policy; exact overrides require Advanced Mode and custom policy.")
    parser.add_argument("--budget-overrides-file", help="UTF-8 JSON file with custom budget and layer targets; requires --budget-policy custom.")
    parser.add_argument(
        "--pruning-objective", action="append", choices=sorted(PRUNING_OBJECTIVE_DEFINITIONS), default=[],
        help="Optional named semantic preservation objective for prune review. Repeat to activate more than one; this is a soft priority bias, not an author lock.",
    )
    parser.add_argument("--dynamic-policy", choices=["off", "review", "custom", "preserve"], default="off", help="Advanced-only Dynamic State & Variation policy; new builds default to off.")
    parser.add_argument("--dynamic-overrides-file", help="UTF-8 JSON file with entry groups/effects/filters/triggers/automation/outlet policies.")
    parser.add_argument("--runtime-target", choices=["portable", "sillytavern-1.18.0", "preserve"], default="portable", help="Named runtime compatibility profile; Simple Mode normally uses portable.")
    parser.add_argument("--runtime-format", choices=["preserve", "schema1-character", "ccv3-embedded", "lorebook-v3", "sillytavern-native", "charx", "group-set", "persona-lorebook"], default="preserve", help="Parent-owned target adapter output format. preserve resolves to a directly-importable shape for the artifact's declared runtime target: for a standalone lorebook (no character card at all), that is sillytavern-native, not WorldBuilder's own internal lorebook-v3 working format; explicitly requesting lorebook-v3 still produces the portable interchange wrapper unchanged.")
    parser.add_argument("--sillytavern-extensions-mode", choices=("none", "choose", "detect"), default="none", help="Freeze the [7] SillyTavern Extensions decision for this build.")
    parser.add_argument("--sillytavern-extension", action="append", default=[], help="Extension explicitly selected by the person. Repeat for multiple extensions.")
    parser.add_argument("--sillytavern-detected-extension", action="append", default=[], help="Extension name reported by the separate SillyTavern detection step. Detection proves presence/name/scope, not enablement.")
    parser.add_argument("--output-name", help="Final deliverable basename; extension is chosen by artifact type.")
    parser.add_argument("--export-root", help="Optional user-selected clean export directory (Desktop is allowed).")
    parser.add_argument("--no-stage-worker-kit", action="store_true", help="Do not copy prompts/references (sequential parent-only workflows only).")
    parser.add_argument("--full-worker-kit", action="store_true", help="Stage every reference file instead of only those the worker manuals name.")
    parser.add_argument("--no-pre-gen-audit", action="store_true", help="Disable pre-generation audit evidence for this build state.")
    parser.add_argument("--audit-max-iterations", type=int, default=3, help="Audit iteration ceiling for this build (1-5). A build that reaches the ceiling with findings outstanding is escalated and cannot reach delivery.")
    parser.add_argument("--vision-soft-percent", type=int, default=75, help="Vision session-budget soft threshold as a percent of the researched per-session image limit (10-100). At or above it a generation worker finishes its current UID and hands off.")
    parser.add_argument("--vision-session-cap", type=int, default=None, help="Optional ceiling on the researched per-session image limit (1-1000). Unset uses the researched limit alone.")
    return parser


def validate_arguments(args) -> None:
    """Validate cross-argument CLI invariants without performing build I/O."""
    if (args.guided_mode_answer is None) != (args.guided_mode_default is None):
        raise WorldBuilderError("--guided-mode-answer and --guided-mode-default must be supplied together so the explicit [2A] decision is auditable")
    if args.custom_pipeline:
        if args.guided_mode_answer != "yes":
            raise WorldBuilderError("--custom-pipeline requires the explicit --guided-mode-answer yes from settings question [2A]")
        if not isinstance(args.custom_trigger_reason, str) or not args.custom_trigger_reason.strip():
            raise WorldBuilderError("--custom-pipeline requires --custom-trigger-reason so the explicit [2A] routing decision is auditable")
    else:
        if args.guided_mode_answer == "yes":
            raise WorldBuilderError("--guided-mode-answer yes requires --custom-pipeline; [2A] is the routing authority")
        if args.custom_trigger_reason or args.custom_source_research != "none":
            raise WorldBuilderError("custom trigger/research flags require --custom-pipeline")
    audit_max_iterations = getattr(args, "audit_max_iterations", 3)
    if isinstance(audit_max_iterations, bool) or not isinstance(audit_max_iterations, int) or not 1 <= audit_max_iterations <= 5:
        raise WorldBuilderError("--audit-max-iterations must be an integer between 1 and 5")
    vision_soft_percent = getattr(args, "vision_soft_percent", 75)
    if isinstance(vision_soft_percent, bool) or not isinstance(vision_soft_percent, int) or not 10 <= vision_soft_percent <= 100:
        raise WorldBuilderError("--vision-soft-percent must be an integer between 10 and 100")
    vision_session_cap = getattr(args, "vision_session_cap", None)
    if vision_session_cap is not None and (isinstance(vision_session_cap, bool) or not isinstance(vision_session_cap, int) or not 1 <= vision_session_cap <= 1000):
        raise WorldBuilderError("--vision-session-cap must be an integer between 1 and 1000 when provided")


def orchestrate(args) -> int:

    try:
        context_window_mode, context_window = parse_context_window(args.context_window)
        workspace = Path(args.workspace).expanduser().resolve() if args.workspace else default_workspace()
        workspace.mkdir(parents=True, exist_ok=True)
        config_path, config = create_or_read_config(workspace, args.export_root)
        # Home Config preferences apply unless this build explicitly overrides them.
        resolved_autonomy = args.autonomy or str(
            (config.get("autonomy") or {}).get("mode", "consent-required")
        )
        resolved_unverified = str(
            (config.get("verification") or {}).get("unverified_policy", "deprioritize")
        )
        if resolved_unverified not in {"disable", "deprioritize", "despecify", "ship_labeled"}:
            raise WorldBuilderError(
                f"workspace config has an unknown unverified-entry policy {resolved_unverified!r}"
            )
        if resolved_autonomy not in {"consent-required", "evidence-bounded"}:
            raise WorldBuilderError(
                f"workspace config has an unknown autonomy mode {resolved_autonomy!r}"
            )

        build_id = unique_build_id(args.name)
        builds_value = str(config.get("builds_directory", "builds"))
        builds_root = Path(os.path.expandvars(os.path.expanduser(builds_value)))
        if not builds_root.is_absolute():
            builds_root = workspace / builds_root
        builds_root = builds_root.resolve()
        try:
            builds_root.relative_to(workspace)
        except ValueError as exc:
            raise WorldBuilderError(
                "config.json builds_directory must stay inside the approved WorldBuilder workspace"
            ) from exc
        if args.build_dir:
            build_root = Path(args.build_dir).expanduser().resolve()
            try:
                build_root.relative_to(builds_root)
            except ValueError as exc:
                raise WorldBuilderError(
                    "--build-dir must stay inside the approved WorldBuilder workspace builds directory"
                ) from exc
        else:
            build_root = builds_root / build_id
        if build_root.exists():
            raise WorldBuilderError(f"refusing to reuse an existing build directory: {build_root}")

        directories = [
            "input",
            "artifacts/research",
            "artifacts/pruning-receipts",
            "creations",
            ".work/assignments",
            ".work/discovery-runtime",
            ".work/phases",
            ".work/findings/pre-generation",
            ".work/findings/post-generation",
            ".work/audit-assignments/pre-generation",
            ".work/audit-assignments/post-generation",
            ".work/audit-runtime/pre-generation",
            ".work/audit-runtime/post-generation",
            "artifacts/discoveries/results",
            ".work/evidence-receipts",
            ".work/entry-checkpoints",
            ".work/page-cache",
            ".work/discovery-candidates",
            ".work/invalidated",
            ".work/repairs",
            ".work/shared-state",
            "artifacts/revisions",
            "artifacts/dashboard",
        ]
        for relative in directories:
            (build_root / relative).mkdir(parents=True, exist_ok=False)

        skill_root = Path(__file__).resolve().parent.parent
        worker_kit = build_root / ".work" / "worker-kit"
        worker_kit_report = None

        selected_schema = implied_schema(args.artifact_type, args.schema)
        requested_runtime_target = args.runtime_target
        requested_runtime_format = args.runtime_format
        suffix = output_suffix(args.artifact_type)
        requested_name = args.output_name or args.name
        if requested_name.casefold().endswith(suffix.casefold()):
            requested_name = requested_name[: -len(suffix)]
        output_name = slugify(requested_name) + suffix
        export_value = args.export_root if args.export_root is not None else config.get("default_export_root")
        audit_required = selected_schema in {2, 3} or args.artifact_type in {"lorebook", "world", "group"}
        if args.no_pre_gen_audit and audit_required:
            raise WorldBuilderError("--no-pre-gen-audit is forbidden for lorebook-bearing, World, and Group builds")
        pregen_required = bool(audit_required)

        discovery_required = args.source_kind == "known-property" or (args.custom_pipeline and args.custom_source_research == "known-property")
        pipeline_mode = "sequential" if args.custom_pipeline else ("parallel" if args.source_kind == "known-property" else args.pipeline)
        paths: dict[str, Any] = {
            "input": "input",
            "manifest": "artifacts/manifest.json",
            "build_id": "artifacts/build-id.json",
            "build_list": "artifacts/build-list.md",
            "effective_config": "artifacts/effective-config.json",
            "settings_preset_receipt": "artifacts/settings-preset-receipt.json",
            "field_registry": "artifacts/field-registry.json",
            "default_profile": "artifacts/default-profile.json",
            "recursion_map": "artifacts/recursion-map.md",
            "card_shell_plan": "artifacts/card-shell-plan.json",
            "character_plan": "artifacts/character-plan.json",
            "placement_plan": "artifacts/placement-plan.json",
            "placement_planning_receipt": "artifacts/placement-planning-gate.json",
            "placement_output_receipt": "artifacts/placement-output-gate.json",
            "budget_plan": "artifacts/budget-plan.json",
            "budget_planning_receipt": "artifacts/budget-planning-gate.json",
            "budget_output_receipt": "artifacts/budget-output-gate.json",
            "dynamic_state_plan": "artifacts/dynamic-state-plan.json",
            "dynamic_state_planning_receipt": "artifacts/dynamic-state-planning-gate.json",
            "dynamic_state_output_receipt": "artifacts/dynamic-state-output-gate.json",
            "entry_naming_planning_receipt": "artifacts/entry-naming-planning-gate.json",
            "entry_naming_output_receipt": "artifacts/entry-naming-output-gate.json",
            "semantic_ir": "artifacts/semantic-ir.json",
            "compatibility_report": "artifacts/target-compatibility-report.json",
            "runtime_adapter_receipt": "artifacts/runtime-target-adapter-receipt.json",
            "recommended_settings": "artifacts/recommended_settings.json",
            "runtime_bundle_manifest": "artifacts/runtime-bundle-manifest.json",
            "runtime_bundle_receipt": "artifacts/runtime-bundle-receipt.json",
            "runtime_bundle": "creations/runtime-bundle.zip",
            "behavioral_testdrive_work": ".work/behavioral-testdrive",
            "behavioral_testdrive_reports": "artifacts/behavioral-testdrive",
            "activation_test_corpus": "artifacts/activation-test-corpus.json",
            "activation_test_corpus_receipt": "artifacts/activation-test-corpus-gate.json",
            "cost_projection": "artifacts/cost-projection.json",
            "resource_usage": "artifacts/resource-usage.json",
            "dashboard_build_health": "artifacts/dashboard/build_health.json",
            "dashboard_activation_graph": "artifacts/dashboard/activation_graph.json",
            "dashboard_source_coverage": "artifacts/dashboard/source_coverage.json",
            "dashboard_build_progress": "artifacts/dashboard/build_progress.json",
            "public_diagnostics_bundle": "artifacts/public-diagnostics.zip",
            "pipeline_registry": "artifacts/pipeline-registry.json",
            "integration_plan": "artifacts/integration-plan.json",
            "integration_planning_receipt": "artifacts/integration-planning-gate.json",
            "integration_output_receipt": "artifacts/integration-output-gate.json",
            "integration_resume_receipt": "artifacts/integration-resume-gate.json",
            "pipeline_stage_ledger": "artifacts/pipeline-stage-ledger.json",
            "pipeline_stage_receipts": "artifacts/pipeline-stage-receipts",
            "sillytavern_tag_map": "artifacts/sillytavern-tag-map.json",
            "sillytavern_character_map": "artifacts/sillytavern-character-map.json",
            "runtime_asset_map": "artifacts/runtime-asset-map.json",
            "pruning_receipts": "artifacts/pruning-receipts",
            "context_budget_review_receipt": "artifacts/context-budget-review.json",
            "context_budget_before": ".work/context-budget-before.json",
            "context_budget_after": ".work/context-budget-after.json",
            "custom_generation_receipt": "artifacts/custom-generation-receipt.json",
            "decision_log": "artifacts/decision-log.json",
            "terminology_dictionary": "artifacts/terminology-dictionary.json",
            "transformation_map": "artifacts/transformation-map.json",
            "repair_ledger": "artifacts/repair-attempts.json",
            "activation_map_receipt": "artifacts/activation-map-gate.json",
            "era_plan": "artifacts/era-plan.json",
            "era_router_receipt": "artifacts/era-router-gate.json",
            "architecture_planning_receipt": "artifacts/architecture-planning-gate.json",
            "architecture_output_receipt": "artifacts/architecture-output-gate.json",
            "research": "artifacts/research",
            "worker_kit": ".work/worker-kit" if not args.no_stage_worker_kit else None,
            "worker_kit_bundle": ".work/worker-kit/bundle.json" if not args.no_stage_worker_kit else None,
            "assignments": ".work/assignments",
            "discovery_runtime": ".work/discovery-runtime",
            "phases": ".work/phases",
            "findings": ".work/findings",
            "audit_assignments": ".work/audit-assignments",
            "audit_runtime": ".work/audit-runtime",
            "pre_generation_audit_plan": ".work/audit-pre-generation-plan.json",
            "pre_generation_audit_receipt": ".work/audit-pre-generation-gate.json",
            "post_generation_audit_plan": ".work/audit-post-generation-plan.json",
            "post_generation_audit_receipt": ".work/audit-post-generation-gate.json",
            "discoveries": "artifacts/discoveries",
            "discovery_probe": "artifacts/discoveries/source-probe.json",
            "facet_candidates": "artifacts/discoveries/facet-candidates.json",
            "discovery_plan": "artifacts/discoveries/discovery-plan.json",
            "discovery_receipt": "artifacts/discoveries/discovery-gate.json",
            "discovery_index": "artifacts/discoveries/discovery-index.json",
            "discovery_recovery_plan": "artifacts/discoveries/discovery-recovery-plan.json",
            "discovery_exclusion_approval": "artifacts/discoveries/exclusion-approval.json",
            "discovery_wave_state": ".work/discovery-wave-state.json",
            "discovery_progress": "artifacts/discoveries/discovery-progress.json",
            "discovery_pending": "artifacts/discoveries/discovery-pending.json",
            "identity_registry": ".work/entity-identity-registry.json",
            "identity_receipt": "artifacts/identity-receipt.json",
            "planning_receipt": "artifacts/planning-gate.json",
            "worker_run_ledger": ".work/worker-runs.json",
            "evidence_receipts": ".work/evidence-receipts",
            "receipts": ".work/pipeline-receipts.jsonl",
            "patch_log": ".work/patch-log.jsonl",
            "merge_input": ".work/merged.json",
            "adapter_output": "creations/adapter-output.charx" if args.runtime_format == "charx" else "creations/adapter-output.json",
            "audit_log": "artifacts/audit-log.md",
            "source_lineage": "artifacts/source-lineage.json",
            "source_sync_report": "artifacts/source-update-report.json",
            "source_sync_approval": "artifacts/source-update-approval.json",
            "revision_history": "artifacts/revision-history.json",
            "revisions": "artifacts/revisions",
            "final_output": f"creations/{output_name}",
            "export_root": str(Path(str(export_value)).expanduser()) if export_value else None,
        }
        timestamp = iso_now()
        preset_record = getattr(args, "_settings_preset_record", None)
        preset_meta = None
        if preset_record is not None:
            preset_receipt = {
                "kind": "worldbuilder-settings-preset-application",
                "contract": SETTINGS_PRESET_CONTRACT,
                "receipt_version": 1,
                "source_sha256": preset_record["source_sha256"],
                "normalized_sha256": preset_record["normalized_sha256"],
                "applied_fields": preset_record["applied_fields"],
                "overridden_fields": preset_record["overridden_fields"],
                "preset": preset_record["preset"],
            }
            atomic_write_json(build_root / paths["settings_preset_receipt"], preset_receipt)
            preset_meta = {
                "contract": SETTINGS_PRESET_CONTRACT,
                "source_sha256": preset_record["source_sha256"],
                "normalized_sha256": preset_record["normalized_sha256"],
                "receipt_sha256": sha256_file(build_root / paths["settings_preset_receipt"]),
                "applied_fields": preset_record["applied_fields"],
                "overridden_fields": preset_record["overridden_fields"],
            }
        fixed_scenario_text = ""
        if args.fixed_scenario_file:
            fixed_scenario_path = Path(args.fixed_scenario_file).expanduser().resolve()
            fixed_scenario_text = fixed_scenario_path.read_text(encoding="utf-8-sig").strip()
        card_shell_plan = build_card_shell_plan(
            build_id=build_id,
            artifact_type=args.artifact_type,
            schema=selected_schema,
            opening_style=args.opening_style,
            greeting_policy=args.greeting_policy,
            dialogue_policy=args.dialogue_policy,
            scenario_policy=args.scenario_policy,
            fixed_scenario_text=fixed_scenario_text,
            system_prompt_policy=args.system_prompt_policy,
            post_history_policy=args.post_history_policy,
            creator_notes_policy=args.creator_notes_policy,
            persona_detail=args.persona_detail,
        )
        atomic_write_json(build_root / paths["card_shell_plan"], card_shell_plan)
        frozen_registry, frozen_profile = freeze_planning_contract(
            skill_root, build_root, build_id, args.artifact_type, args.era_mode, timestamp
        )
        placement_overrides: dict[str, Any] = {}
        if args.placement_overrides_file:
            if args.placement_policy != "custom":
                raise WorldBuilderError("--placement-overrides-file requires --placement-policy custom")
            override_path = Path(args.placement_overrides_file).expanduser().resolve()
            try:
                placement_overrides = json.loads(override_path.read_text(encoding="utf-8-sig"))
            except json.JSONDecodeError as exc:
                raise WorldBuilderError(f"placement override JSON is invalid: {exc}") from exc
            if not isinstance(placement_overrides, dict):
                raise WorldBuilderError("placement override JSON must be an object")
        placement_plan = build_placement_plan(
            build_id=build_id,
            artifact_type=args.artifact_type,
            schema=selected_schema,
            policy=args.placement_policy,
            profile_id=str(frozen_profile["profile_id"]),
            default_profile_sha256=sha256_file(build_root / paths["default_profile"]),
            custom_overrides=placement_overrides,
        )
        atomic_write_json(build_root / paths["placement_plan"], placement_plan)
        budget_overrides: dict[str, Any] = {}
        if args.budget_overrides_file:
            if args.budget_policy != "custom":
                raise WorldBuilderError("--budget-overrides-file requires --budget-policy custom")
            if str(config.get("interface", {}).get("mode", "simple")) != "advanced":
                raise WorldBuilderError("custom budget overrides require Advanced Mode in Config")
            budget_override_path = Path(args.budget_overrides_file).expanduser().resolve()
            try:
                budget_overrides = json.loads(budget_override_path.read_text(encoding="utf-8-sig"))
            except json.JSONDecodeError as exc:
                raise WorldBuilderError(f"budget override JSON is invalid: {exc}") from exc
            if not isinstance(budget_overrides, dict):
                raise WorldBuilderError("budget override JSON must be an object")
        budget_plan = build_budget_plan(
            build_id=build_id,
            artifact_type=args.artifact_type,
            schema=selected_schema,
            profile_id=args.budget_profile,
            policy=args.budget_policy,
            default_profile_sha256=sha256_file(build_root / paths["default_profile"]),
            custom_overrides=budget_overrides,
            context_window=context_window,
            context_window_mode=context_window_mode,
            pruning_objectives=args.pruning_objective,
        )
        atomic_write_json(build_root / paths["budget_plan"], budget_plan)
        interface_mode = str(config.get("interface", {}).get("mode", "simple"))
        dynamic_overrides: dict[str, Any] = {}
        if args.dynamic_overrides_file:
            if args.dynamic_policy == "off":
                raise WorldBuilderError("--dynamic-overrides-file requires a non-off --dynamic-policy")
            dynamic_override_path = Path(args.dynamic_overrides_file).expanduser().resolve()
            try:
                dynamic_overrides = json.loads(dynamic_override_path.read_text(encoding="utf-8-sig"))
            except json.JSONDecodeError as exc:
                raise WorldBuilderError(f"dynamic-state override JSON is invalid: {exc}") from exc
            if not isinstance(dynamic_overrides, dict):
                raise WorldBuilderError("dynamic-state override JSON must be an object")
        if args.dynamic_policy != "off" and interface_mode != "advanced":
            raise WorldBuilderError("Dynamic State & Variation requires Advanced Mode in Config")
        dynamic_state_plan = build_dynamic_state_plan(
            build_id=build_id,
            artifact_type=args.artifact_type,
            schema=selected_schema,
            policy=args.dynamic_policy,
            interface_mode=interface_mode,
            custom_overrides=dynamic_overrides,
        )
        atomic_write_json(build_root / paths["dynamic_state_plan"], dynamic_state_plan)
        pipeline_registry = load_pipeline_registry(skill_root / "references" / "pipeline-registry.json")
        atomic_write_json(build_root / paths["pipeline_registry"], pipeline_registry)
        runtime_required = args.runtime_format != "preserve" or args.runtime_target == "sillytavern-1.18.0"
        extension_mode = getattr(args, "sillytavern_extensions_mode", "none") or "none"
        requested_extensions = sorted({str(x).strip() for x in getattr(args, "sillytavern_extension", []) if str(x).strip()})
        detected_extensions = sorted({str(x).strip() for x in getattr(args, "sillytavern_detected_extension", []) if str(x).strip()})
        if extension_mode == "none":
            resolved_extensions = []
        elif extension_mode == "choose":
            if not requested_extensions:
                raise WorldBuilderError("--sillytavern-extensions-mode choose requires at least one --sillytavern-extension")
            resolved_extensions = requested_extensions
        elif extension_mode == "detect":
            resolved_extensions = detected_extensions
        else:
            raise WorldBuilderError(f"unknown SillyTavern extension mode {extension_mode!r}")
        frozen_extensions = {
            "mode": extension_mode,
            "requested": requested_extensions,
            "detected": detected_extensions,
            "resolved": resolved_extensions,
            "detection_claim": "presence_name_scope_only" if extension_mode == "detect" else None,
            "enablement_claimed": False,
        }
        integration_plan = build_integration_plan(
            build_id=build_id,
            artifact_type=args.artifact_type,
            schema=selected_schema,
            persona_mode=args.persona_mode if args.artifact_type == "persona" else None,
            era_mode=args.era_mode,
            source_kind=args.source_kind,
            pipeline_mode=pipeline_mode,
            interface_mode=interface_mode,
            budget_profile=budget_plan["profile_id"],
            dynamic_applicable=bool(dynamic_state_plan["applicable"]),
            runtime_required=runtime_required,
            registry_path=build_root / paths["pipeline_registry"],
        )
        atomic_write_json(build_root / paths["integration_plan"], integration_plan)
        if not args.no_stage_worker_kit:
            worker_kit_report = stage_worker_kit(
                build_root,
                skill_root=skill_root,
                full=args.full_worker_kit,
                pipeline=integration_plan["pipeline"],
                systems=_staging_systems(integration_plan["required_systems"], discovery_required=discovery_required),
            )
        guided_default_accepted = (
            args.guided_mode_answer is not None
            and args.guided_mode_default is not None
            and args.guided_mode_answer == args.guided_mode_default
        )
        custom_trigger_reason = None
        if args.custom_pipeline:
            disposition = "accepted default" if guided_default_accepted else "overrode default"
            custom_trigger_reason = (
                f"[2A]={args.guided_mode_answer}; default={args.guided_mode_default}; "
                f"{disposition}; note={args.custom_trigger_reason.strip()}"
            )

        configured_image_analysis_mode = str((config.get("image_analysis") or {}).get("mode", "on")).strip().casefold()
        resolved_image_analysis_mode = args.image_analysis_mode or configured_image_analysis_mode
        vision_capable = args.vision_capable or "unknown"
        effective_image_mode = resolved_image_analysis_mode == "on" and vision_capable == "available"

        state: dict[str, Any] = {
            "state_version": 2,
            "worldbuilder_version": VERSION,
            "build_id": build_id,
            "name": args.name,
            "created_at": timestamp,
            "updated_at": timestamp,
            "workspace": str(workspace),
            "workspace_config": safe_relative(config_path, workspace),
            "artifact": {
                "type": args.artifact_type,
                "schema": selected_schema,
                "persona_mode": args.persona_mode if args.artifact_type == "persona" else None,
            },
            # Frozen at init so the guided menu's choices are auditable later. Without
            # this the menu recorded selections the pipeline never consumed.
            # Persisted Home Config preference unless this build overrides it. An
            # explicit flag wins; absence means "use the saved value", not "use False".
            "debug": {
                "log_problems": (
                    args.debug_log if args.debug_log is not None
                    else bool((config.get("debug") or {}).get("log_problems", False))
                ),
                "source": "flag" if args.debug_log is not None else "workspace_config",
            },
            "autonomy": {
                "mode": resolved_autonomy,
                # A scope decision is the user's regardless of this setting. Only a
                # provable-closure acknowledgement is ever self-approvable, and the
                # approval records that it was automatic.
                "self_approval_permitted": resolved_autonomy == "evidence-bounded",
                "source": "flag" if args.autonomy is not None else "workspace_config",
            },
            "verification": {
                "unverified_policy": resolved_unverified,
                "source": "workspace_config",
            },
            # Carried forward for image_generation_gate.py / expression_assets.py
            # to read from the build-state rather than re-reading config.json
            # directly. No per-build flag overrides this; it is a workspace-
            # level tool preference, same class as autonomy/debug above, just
            # without an init_build.py CLI flag of its own to override it.
            "image_generation": dict(config.get("image_generation") or {}),
            "retrieval": {"profile": args.retrieval},
            "recursion": {"profile": args.recursion},
            "source": {
                "stance": args.source_stance,
                "kind": args.source_kind,
                "research_kind": args.custom_source_research if args.custom_pipeline else args.source_kind,
                # Imported material is not trusted by default. Nothing was verified by
                # the act of importing it, and treating it as verified would smuggle an
                # unaudited claim into a build that otherwise tracks provenance.
                "imported_confidence_default": "unverified" if args.source_kind == "existing-lorebook" else None,
                "additive": args.source_kind == "existing-lorebook",
            },
            "settings_preset": preset_meta,
            "settings": {
                "conditions": args.conditions,
                "audit_max_iterations": args.audit_max_iterations,
                "vision_soft_percent": args.vision_soft_percent,
                "vision_session_cap": args.vision_session_cap,
                "image_analysis_mode": resolved_image_analysis_mode,
                "vision_capable": vision_capable,
                "effective_image_mode": effective_image_mode,
                "runtime_target": args.runtime_target,
                "runtime_format": args.runtime_format,
                "runtime_target_requested": requested_runtime_target,
                "runtime_format_requested": requested_runtime_format,
                "sillytavern_extensions": frozen_extensions,
            },
            "discovery": {
                "required": discovery_required,
                "execution": "parallel_required" if discovery_required else "conditional",
                "status": "pending" if discovery_required else "not_required",
                "confirmed_dead_after_rounds": int(config.get("discovery", {}).get("confirmed_dead_after_rounds", 2)),
            },
            "planning": {
                "required": True,
                "identity_registry_required": True,
                "authority_contract": "worldbuilder-planning-authority-v1",
                "activation_contract": "worldbuilder-activation-graph-v1",
                "generation_assignment_version": 3,
                "map_required": True,
                "profile_id": frozen_profile["profile_id"],
                "field_registry_sha256": sha256_file(build_root / paths["field_registry"]),
                "default_profile_sha256": sha256_file(build_root / paths["default_profile"]),
                "blank_semantics": frozen_profile.get("blank_semantics", {}),
            },
            "content_architecture": {
                "contract": "worldbuilder-content-architecture-v1",
                "character_format": "canonical-v1",
                "character_system_contract": CHARACTER_SYSTEM_CONTRACT,
                "character_plan_policy": "required_when_character_entries_exist",
                "era_mode": args.era_mode,
                "era_isolation": args.era_isolation,
                "era_plan_required": args.era_mode == "multi",
                "era_plan_version": 2 if args.era_mode == "multi" else None,
                "era_router_contract": "worldbuilder-era-router-v1" if args.era_mode == "multi" else None,
                "card_shell_contract": CARD_SHELL_CONTRACT,
                "card_shell_plan_sha256": sha256_file(build_root / paths["card_shell_plan"]),
                "placement_contract": PLACEMENT_CONTRACT,
                "placement_plan_sha256": sha256_file(build_root / paths["placement_plan"]),
                "budget_contract": BUDGET_CONTRACT,
                "budget_plan_sha256": sha256_file(build_root / paths["budget_plan"]),
                "dynamic_state_contract": DYNAMIC_STATE_CONTRACT,
                "dynamic_state_plan_sha256": sha256_file(build_root / paths["dynamic_state_plan"]),
                "runtime_target_adapter_contract": "worldbuilder-runtime-target-adapter-v2",
                "full_integration_contract": INTEGRATION_CONTRACT,
                "pipeline_stage_gate_contract": PIPELINE_STAGE_CONTRACT,
                "integration_plan_sha256": sha256_file(build_root / paths["integration_plan"]),
            },
            "custom_pipeline": {
                "active": bool(args.custom_pipeline),
                "guided_mode_answer": args.guided_mode_answer,
                "guided_mode_default": args.guided_mode_default,
                "guided_mode_default_accepted": guided_default_accepted if args.guided_mode_answer is not None else None,
                "guided_mode_default_overridden": (not guided_default_accepted) if args.guided_mode_answer is not None else None,
                "trigger_reason": custom_trigger_reason,
                "planning_mode": "conversational" if args.custom_pipeline else None,
                "generation_mode": "freeform" if args.custom_pipeline else None,
                "repair_gate": "custom-pipeline-freeform-generation" if args.custom_pipeline else None,
                "source_research": args.custom_source_research if args.custom_pipeline else None,
                "decision_log_contract": "worldbuilder-guided-decision-log-v1" if args.custom_pipeline else None,
                "transformation_map_contract": "worldbuilder-transformation-map-v1" if args.custom_pipeline else None,
                "transformation_map_role": "legacy_migration_and_cli_facade" if args.custom_pipeline else None,
            },
            "pipeline": {
                "mode": pipeline_mode,
                "dispatch_count": 0,
                "expected_phase_count": None,
                "requires_phase_gates": bool(audit_required and not args.custom_pipeline),
            },
            "models": resolve_models(config.get("models", {})),
            "batching": {
                "generation_entries_per_worker": int(config.get("batching", {}).get("generation_entries_per_worker", 15)),
            },
            "timeouts": {
                "per_uid_seconds": int(config.get("timeouts", {}).get("per_uid_seconds", 90)),
                "per_page_seconds": int(config.get("timeouts", {}).get("per_page_seconds", 20)),
            },
            "interface": {
                "mode": str(config.get("interface", {}).get("mode", "simple")),
                "build_menu": "advanced" if str(config.get("interface", {}).get("mode", "simple")) == "advanced" else "simple",
                "max_settings_per_page": 10,
            },
            "image_analysis": {
                "mode": resolved_image_analysis_mode,
                "vision_capable": vision_capable,
                "effective": effective_image_mode,
            },
            "card_shell": {
                "contract": CARD_SHELL_CONTRACT,
                "plan_sha256": sha256_file(build_root / paths["card_shell_plan"]),
                "choices": card_shell_plan["choices"],
            },
            "placement": {
                "contract": PLACEMENT_CONTRACT,
                "plan_sha256": sha256_file(build_root / paths["placement_plan"]),
                "policy": placement_plan["policy"],
                "profile_id": placement_plan["profile_id"],
            },
            "budget": {
                "contract": BUDGET_CONTRACT,
                "plan_sha256": sha256_file(build_root / paths["budget_plan"]),
                "policy": budget_plan["policy"],
                "profile_id": budget_plan["profile_id"],
                "profile_label": budget_plan["profile_label"],
                "applicable": budget_plan["applicable"],
                "context_window_mode": context_window_mode,
                "context_window": context_window,
                "auto_review_required": bool(budget_plan.get("applicable") and context_window_mode == "auto"),
                "pruning_objectives": budget_plan.get("pruning_objectives", []),
            },
            "dynamic_state": {
                "contract": DYNAMIC_STATE_CONTRACT,
                "plan_sha256": sha256_file(build_root / paths["dynamic_state_plan"]),
                "policy": dynamic_state_plan["policy"],
                "applicable": dynamic_state_plan["applicable"],
            },
            "integration": {
                "contract": INTEGRATION_CONTRACT,
                "registry_sha256": sha256_file(build_root / paths["pipeline_registry"]),
                "plan_sha256": sha256_file(build_root / paths["integration_plan"]),
                "pipeline": integration_plan["pipeline"],
                "required_systems": integration_plan["required_systems"],
                "route_variants": integration_plan["route_variants"],
            },
            "audit": {
                "pre_generation_required": pregen_required,
                "pre_generation_lenses": list(AUDIT_LENSES) if pregen_required else [],
                "worker_name_pool": list(WORKER_BIRD_NAMES),
                "post_generation_required": bool(audit_required),
            },
            "paths": paths,
            "pipeline_stage_gate": {
                "contract": PIPELINE_STAGE_CONTRACT,
                "current_stage": None,
            },
            "status": {
                "planning": "pending",
                "pre_generation": "pending" if audit_required else "not_required",
                "generation": "pending",
                "merge": "pending" if audit_required else "not_required",
                "context_budget_review": "pending" if budget_plan.get("applicable") and context_window_mode == "auto" else "not_required",
                "post_generation_audit": "pending" if audit_required else "not_required",
                "dynamic_state_planning": "pending" if dynamic_state_plan["applicable"] else "not_required",
                "dynamic_state_output": "pending" if dynamic_state_plan["applicable"] else "not_required",
                "runtime_adapter": "pending" if runtime_required else "not_required",
                "integration_planning": "pending",
                "integration_output": "pending",
                "integration_resume": "pending",
                "delivery": "pending",
            },
            "lineage": ({"input": _resolve_source_file_lineage(args.source_file)} if args.source_file else {}),
        }
        effective_config = {
            "config_version": int(config.get("config_version", 6)),
            "worldbuilder_version": VERSION,
            "build_id": build_id,
            "frozen_at": timestamp,
            "models": resolve_models(config.get("models", {})),
            "batching": {
                "generation_entries_per_worker": int(config.get("batching", {}).get("generation_entries_per_worker", 15)),
            },
            "discovery": {
                "confirmed_dead_after_rounds": int(config.get("discovery", {}).get("confirmed_dead_after_rounds", 2)),
            },
            "timeouts": {
                "per_uid_seconds": int(config.get("timeouts", {}).get("per_uid_seconds", 90)),
                "per_page_seconds": int(config.get("timeouts", {}).get("per_page_seconds", 20)),
            },
            "interface": {
                "mode": str(config.get("interface", {}).get("mode", "simple")),
                "build_menu": "advanced" if str(config.get("interface", {}).get("mode", "simple")) == "advanced" else "simple",
                "max_settings_per_page": 10,
            },
            "card_shell": {
                "contract": CARD_SHELL_CONTRACT,
                "plan_sha256": sha256_file(build_root / paths["card_shell_plan"]),
                "choices": card_shell_plan["choices"],
            },
            "placement": {
                "contract": PLACEMENT_CONTRACT,
                "plan_sha256": sha256_file(build_root / paths["placement_plan"]),
                "policy": placement_plan["policy"],
                "profile_id": placement_plan["profile_id"],
            },
            "budget": {
                "contract": BUDGET_CONTRACT,
                "plan_sha256": sha256_file(build_root / paths["budget_plan"]),
                "policy": budget_plan["policy"],
                "profile_id": budget_plan["profile_id"],
                "profile_label": budget_plan["profile_label"],
                "applicable": budget_plan["applicable"],
                "targets": budget_plan["targets"],
                "pruning_objectives": budget_plan.get("pruning_objectives", []),
            },
            "dynamic_state": {
                "contract": DYNAMIC_STATE_CONTRACT,
                "plan_sha256": sha256_file(build_root / paths["dynamic_state_plan"]),
                "policy": dynamic_state_plan["policy"],
                "applicable": dynamic_state_plan["applicable"],
                "safety_defaults": dynamic_state_plan["safety_defaults"],
            },
            "integration": {
                "contract": INTEGRATION_CONTRACT,
                "registry_sha256": sha256_file(build_root / paths["pipeline_registry"]),
                "plan_sha256": sha256_file(build_root / paths["integration_plan"]),
                "pipeline": integration_plan["pipeline"],
                "required_systems": integration_plan["required_systems"],
                "route_variants": integration_plan["route_variants"],
            },
            "settings_preset": preset_meta,
            "runtime_target": {
                "contract": "worldbuilder-runtime-target-adapter-v2",
                "profile": args.runtime_target,
                "format": args.runtime_format,
                "requested_profile": requested_runtime_target,
                "requested_format": requested_runtime_format,
                "semantic_ir_version": 2,
            },
            "sillytavern_extensions": frozen_extensions,
            "planning": {
                "authority_contract": "worldbuilder-planning-authority-v1",
                "activation_contract": "worldbuilder-activation-graph-v1",
                "generation_assignment_version": 3,
                "profile_id": frozen_profile["profile_id"],
                "field_registry_sha256": sha256_file(build_root / paths["field_registry"]),
                "default_profile_sha256": sha256_file(build_root / paths["default_profile"]),
                "blank_semantics": frozen_profile.get("blank_semantics", {}),
            },
            "content_architecture": {
                "contract": "worldbuilder-content-architecture-v1",
                "character_format": "canonical-v1",
                "character_system_contract": CHARACTER_SYSTEM_CONTRACT,
                "character_plan_policy": "required_when_character_entries_exist",
                "era_mode": args.era_mode,
                "era_isolation": args.era_isolation,
                "era_plan_version": 2 if args.era_mode == "multi" else None,
                "era_router_contract": "worldbuilder-era-router-v1" if args.era_mode == "multi" else None,
                "card_shell_contract": CARD_SHELL_CONTRACT,
                "card_shell_plan_sha256": sha256_file(build_root / paths["card_shell_plan"]),
                "placement_contract": PLACEMENT_CONTRACT,
                "placement_plan_sha256": sha256_file(build_root / paths["placement_plan"]),
                "budget_contract": BUDGET_CONTRACT,
                "budget_plan_sha256": sha256_file(build_root / paths["budget_plan"]),
                "dynamic_state_contract": DYNAMIC_STATE_CONTRACT,
                "dynamic_state_plan_sha256": sha256_file(build_root / paths["dynamic_state_plan"]),
            },
        }
        atomic_write_json(build_root / paths["effective_config"], effective_config)
        state_path = build_root / "build-state.json"
        owner = {
            "owner": "worldbuilder",
            "worldbuilder_version": VERSION,
            "build_id": build_id,
            "created_at": timestamp,
            "state": "build-state.json",
        }
        atomic_write_json(build_root / ".worldbuilder-owner.json", owner)
        if worker_kit_report is not None:
            state["worker_kit"] = {
                "skill_release": worker_kit_report["skill_release"],
                "worker_kit_sha256": worker_kit_report["worker_kit_sha256"],
                "staging_mode": worker_kit_report["staging_mode"],
                "bundle": str((worker_kit / "bundle.json").relative_to(build_root)).replace(os.sep, "/"),
            }
        atomic_write_json(state_path, state)
        advance_pipeline_stage(state_path, "workspace_initialized")

        print(json.dumps({
            "build_id": build_id,
            "build_root": str(build_root),
            "build_state": str(state_path),
            "worker_kit": str(worker_kit) if not args.no_stage_worker_kit else None,
            "final_output": str(build_root / paths["final_output"]),
            "export_root": paths["export_root"],
        }, ensure_ascii=False, indent=2))
        return 0
    except (WorldBuilderError, OSError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


def restage_worker_kit_cli(raw_argv: list[str]) -> int:
    parser = argparse.ArgumentParser(description="Restage an existing build's worker kit from the installed skill.")
    parser.add_argument("--restage-worker-kit", action="store_true", required=True)
    parser.add_argument("--build-state", required=True)
    try:
        args = parser.parse_args(raw_argv)
        root, state = load_build_state(args.build_state)
        existing_bundle = root / ".work" / "worker-kit" / "bundle.json"
        full = False
        if existing_bundle.is_file():
            old = json.loads(existing_bundle.read_text(encoding="utf-8"))
            full = isinstance(old, dict) and old.get("staging_mode") == "full"
        result = stage_worker_kit(root, full=full, restage=True)
        state["worker_kit"] = {
            "skill_release": result["skill_release"],
            "worker_kit_sha256": result["worker_kit_sha256"],
            "staging_mode": result["staging_mode"],
            "bundle": ".work/worker-kit/bundle.json",
        }
        atomic_write_json(Path(args.build_state).resolve(), state)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (WorldBuilderError, OSError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


def _argument_error(exc: WorldBuilderError) -> int:
    print(f"ERROR: {exc}", file=sys.stderr)
    return 1


def main() -> int:
    raw_argv = sys.argv[1:]
    if "--restage-worker-kit" in raw_argv: return restage_worker_kit_cli(raw_argv)
    parser = build_argument_parser()
    args = parser.parse_args(raw_argv)
    try:
        args._settings_preset_record = apply_preset_to_namespace(args, raw_argv)
        validate_arguments(args)
    except WorldBuilderError as exc: return _argument_error(exc)
    return orchestrate(args)

if __name__ == "__main__":
    raise SystemExit(main())
