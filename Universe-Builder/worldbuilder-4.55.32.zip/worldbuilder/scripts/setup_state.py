#!/usr/bin/env python3
"""Persist paged WorldBuilder setup choices in the user-owned workspace.

The assistant remains responsible for interpreting natural language. This tool
only makes page progression, resumption, and finalization deterministic.
"""
from __future__ import annotations

import argparse
import json
import re
import secrets
import sys
from pathlib import Path
from typing import Any

from wb_common import WorldBuilderError, atomic_write_json, load_json, now_iso, sha256_bytes, sha256_file

KIND = "worldbuilder-setup-draft"
VERSION = 1
MAX_BLOCKS_PER_PAGE = 10
PAGE_BREAK = "__page_break__"

TEMPLATE_KIND = "worldbuilder-build-template"
TEMPLATE_CONTRACT = "worldbuilder-build-template-v1"
TEMPLATE_VERSION = 1
ARTIFACT_TYPES = {"card", "world", "lorebook", "group", "persona"}
INTERFACE_MODES = {"simple", "advanced"}


def slugify(value: str) -> str:
    value = re.sub(r"[^a-zA-Z0-9]+", "-", value.strip()).strip("-").lower()
    return value or "build"


def blocks_for(artifact_type: str, interface_mode: str) -> list[str]:
    """Return the ordered, mode-filtered setup blocks.

    Simple and Advanced are separate presentations of one settings model.
    Advanced includes ordinary choices in the same flow, but it must not add
    card-only or lorebook-only controls to an inapplicable artifact.
    """
    artifact_type = artifact_type.casefold()
    lore_bearing = artifact_type in {"world", "lorebook", "group"}

    if interface_mode == "simple":
        blocks = ["project_canon", "source_material", "guided_mode", "conditions"]
        if lore_bearing:
            blocks += ["retrieval", "era_architecture", "recursion", "probability", "timed_effects", "extensions", "context_budget_pruning"]
        elif artifact_type == "card":
            blocks += ["era_architecture", "extensions"]
        else:
            blocks += ["extensions"]
        blocks += ["detail_level"]
        if artifact_type == "card":
            blocks += ["embed_lorebook", "output_format", "card_starting_setup", "opening_variety", "dialogue_examples"]
        elif artifact_type == "world":
            blocks += ["output_format", "world_card_setup", "opening_variety"]
        elif artifact_type == "group":
            blocks += ["output_format", "group_opening_style", "opening_variety"]
        elif artifact_type == "persona":
            blocks += ["persona_detail"]
        elif artifact_type == "lorebook":
            blocks += ["output_format"]
        return blocks

    # Advanced is one comprehensive flow, not Simple followed by a submenu.
    # Page boundaries follow from this purpose-based order and the 10-block cap.
    blocks = ["project_canon", "source_material", "guided_mode", "conditions"]
    if lore_bearing or artifact_type == "card":
        blocks += [
            "retrieval", "era_architecture", "recursion", "keywords_filters",
            "activation_overrides", "probability", "timed_effects",
        ]
        blocks += [PAGE_BREAK]
        blocks += [
            "character_identity_behavior", "relationship_state_plan",
            "character_split_policy",
        ]
        blocks += [
            "placement_influence", "context_budget_pruning", "extensions",
            "inclusion_groups", "additional_matching_sources",
        ]
        if lore_bearing:
            blocks += ["character_tag_filters"]
        blocks += ["generation_triggers", "outlets_automation", "detail_level"]
        if artifact_type == "card":
            blocks += ["embed_lorebook"]
    else:
        blocks += ["extensions", "detail_level"]

    if artifact_type in {"card", "world", "group", "lorebook"}:
        blocks += [PAGE_BREAK]

    if artifact_type == "card":
        blocks += [
            "output_format", "target_mapping_review", "card_starting_setup",
            "opening_variety", "dialogue_examples", "system_prompt_policy",
            "post_history_policy", "creator_notes_policy",
            "permanent_prompt_limits", "field_duplication_policy",
        ]
    elif artifact_type == "world":
        blocks += [
            "output_format", "target_mapping_review", "world_card_setup",
            "opening_variety", "system_prompt_policy", "post_history_policy",
            "creator_notes_policy", "permanent_prompt_limits",
            "field_duplication_policy",
        ]
    elif artifact_type == "group":
        blocks += [
            "output_format", "target_mapping_review", "group_opening_style",
            "opening_variety", "dialogue_examples", "system_prompt_policy",
            "post_history_policy", "creator_notes_policy",
            "permanent_prompt_limits", "field_duplication_policy",
        ]
    elif artifact_type == "lorebook":
        blocks += ["output_format", "target_mapping_review"]
    elif artifact_type == "persona":
        blocks += ["persona_detail"]
    return blocks


def _canonical_json_bytes(value: dict[str, Any]) -> bytes:
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n").encode("utf-8")


def template_normalized_sha256(value: dict[str, Any]) -> str:
    return sha256_bytes(_canonical_json_bytes(value))


def all_setting_ids() -> set[str]:
    result: set[str] = set()
    for artifact_type in sorted(ARTIFACT_TYPES):
        for interface_mode in sorted(INTERFACE_MODES):
            result.update(blocks_for(artifact_type, interface_mode))
    return result


def validate_template(data: Any) -> dict[str, Any]:
    """Validate a reusable build template without turning it into build authority.

    Templates carry only setup-page defaults. They cannot contain build paths,
    model settings, audit controls, or arbitrary init_build flags because the
    schema has nowhere to represent those concepts.
    """
    if not isinstance(data, dict):
        raise WorldBuilderError("build template must contain one JSON object")
    allowed_top = {
        "kind", "contract", "template_version", "name", "description",
        "artifact_types", "interface_modes", "defaults",
    }
    unknown_top = sorted(set(data) - allowed_top)
    if unknown_top:
        raise WorldBuilderError(f"build template has unknown top-level fields: {', '.join(unknown_top)}")
    if data.get("kind") != TEMPLATE_KIND:
        raise WorldBuilderError(f"build template kind must be {TEMPLATE_KIND!r}")
    if data.get("contract") != TEMPLATE_CONTRACT:
        raise WorldBuilderError(f"build template contract must be {TEMPLATE_CONTRACT!r}")
    if data.get("template_version") != TEMPLATE_VERSION:
        raise WorldBuilderError(f"build template version must be {TEMPLATE_VERSION}")
    name = data.get("name")
    if not isinstance(name, str) or not name.strip():
        raise WorldBuilderError("build template name must be a non-empty string")
    name = name.strip()
    description = data.get("description", "")
    if not isinstance(description, str):
        raise WorldBuilderError("build template description must be a string")

    artifact_types = data.get("artifact_types", sorted(ARTIFACT_TYPES))
    interface_modes = data.get("interface_modes", sorted(INTERFACE_MODES))
    if not isinstance(artifact_types, list) or not artifact_types or any(not isinstance(v, str) for v in artifact_types):
        raise WorldBuilderError("build template artifact_types must be a non-empty list of strings")
    if not isinstance(interface_modes, list) or not interface_modes or any(not isinstance(v, str) for v in interface_modes):
        raise WorldBuilderError("build template interface_modes must be a non-empty list of strings")
    artifact_types = sorted(set(v.strip().casefold() for v in artifact_types if v.strip()))
    interface_modes = sorted(set(v.strip().casefold() for v in interface_modes if v.strip()))
    if not artifact_types:
        raise WorldBuilderError("build template artifact_types must contain at least one supported artifact type")
    if not interface_modes:
        raise WorldBuilderError("build template interface_modes must contain at least one supported interface mode")
    bad_artifacts = sorted(set(artifact_types) - ARTIFACT_TYPES)
    bad_modes = sorted(set(interface_modes) - INTERFACE_MODES)
    if bad_artifacts:
        raise WorldBuilderError(f"build template has unsupported artifact types: {', '.join(bad_artifacts)}")
    if bad_modes:
        raise WorldBuilderError(f"build template has unsupported interface modes: {', '.join(bad_modes)}")

    defaults = data.get("defaults")
    if not isinstance(defaults, dict):
        raise WorldBuilderError("build template defaults must be an object")
    known = all_setting_ids()
    unknown_defaults = sorted(set(defaults) - known)
    if unknown_defaults:
        raise WorldBuilderError(f"build template references unknown setup settings: {', '.join(unknown_defaults)}")

    applicable_somewhere: set[str] = set()
    for artifact_type in artifact_types:
        for interface_mode in interface_modes:
            applicable_somewhere.update(blocks_for(artifact_type, interface_mode))
    impossible = sorted(set(defaults) - applicable_somewhere)
    if impossible:
        raise WorldBuilderError(
            "build template defaults are not applicable to any declared artifact/interface combination: "
            + ", ".join(impossible)
        )

    normalized_defaults: dict[str, dict[str, str]] = {}
    for setting_id in sorted(defaults):
        raw = defaults[setting_id]
        if isinstance(raw, str):
            selection = raw.strip()
        elif isinstance(raw, dict):
            unknown_answer = sorted(set(raw) - {"selection"})
            if unknown_answer:
                raise WorldBuilderError(
                    f"build template default {setting_id} may contain only selection; unsupported fields: {', '.join(unknown_answer)}"
                )
            selection = raw.get("selection")
            if not isinstance(selection, str):
                raise WorldBuilderError(f"build template default {setting_id}.selection must be a string")
            selection = selection.strip()
        else:
            raise WorldBuilderError(f"build template default {setting_id} must be a string or selection object")
        if not selection:
            raise WorldBuilderError(f"build template default {setting_id} selection must not be empty")
        normalized_defaults[setting_id] = {"selection": selection}

    result = {
        "kind": TEMPLATE_KIND,
        "contract": TEMPLATE_CONTRACT,
        "template_version": TEMPLATE_VERSION,
        "name": name,
        "artifact_types": artifact_types,
        "interface_modes": interface_modes,
        "defaults": normalized_defaults,
    }
    if description.strip():
        result["description"] = description.strip()
    return result


def load_template(path: Path) -> tuple[dict[str, Any], str, str]:
    source = path.expanduser().resolve()
    try:
        raw = load_json(source)
    except OSError as exc:
        raise WorldBuilderError(f"cannot read build template {source}: {exc}") from exc
    normalized = validate_template(raw)
    return normalized, sha256_file(source), template_normalized_sha256(normalized)


def template_from_finalized_settings(settings: Any, name: str, description: str = "") -> dict[str, Any]:
    if not isinstance(settings, dict) or settings.get("kind") != "worldbuilder-build-settings":
        raise WorldBuilderError("template export requires finalized worldbuilder-build-settings JSON")
    artifact_type = str(settings.get("artifact_type", "")).strip().casefold()
    interface_mode = str(settings.get("interface_mode", "")).strip().casefold()
    if artifact_type not in ARTIFACT_TYPES or interface_mode not in INTERFACE_MODES:
        raise WorldBuilderError("finalized settings have unsupported artifact_type/interface_mode")
    answers = settings.get("answers")
    if not isinstance(answers, dict):
        raise WorldBuilderError("finalized settings answers must be an object")
    defaults: dict[str, dict[str, str]] = {}
    for setting_id, answer in answers.items():
        if isinstance(answer, dict):
            selection = answer.get("selection")
        else:
            selection = answer
        if isinstance(selection, str) and selection.strip():
            defaults[str(setting_id)] = {"selection": selection.strip()}
    payload: dict[str, Any] = {
        "kind": TEMPLATE_KIND,
        "contract": TEMPLATE_CONTRACT,
        "template_version": TEMPLATE_VERSION,
        "name": name,
        "artifact_types": [artifact_type],
        "interface_modes": [interface_mode],
        "defaults": defaults,
    }
    if description.strip():
        payload["description"] = description.strip()
    return validate_template(payload)


def export_template(settings_path: Path, output: Path, name: str, description: str = "") -> dict[str, Any]:
    settings = load_json(settings_path.expanduser().resolve())
    template = template_from_finalized_settings(settings, name, description)
    target = output.expanduser().resolve()
    atomic_write_json(target, template)
    return {
        "status": "exported",
        "contract": TEMPLATE_CONTRACT,
        "name": template["name"],
        "output": str(target),
        "sha256": sha256_file(target),
        "normalized_sha256": template_normalized_sha256(template),
        "default_count": len(template["defaults"]),
    }


def _selection(answer: Any) -> str | None:
    if isinstance(answer, dict):
        value = answer.get("selection")
    else:
        value = answer
    return str(value).strip().casefold() if isinstance(value, str) else None


def guided_mode_default(answers: dict[str, Any]) -> str:
    """Return the displayed [2A] default from the two preceding answers."""
    return "yes" if (_selection(answers.get("project_canon")) == "original" and
                     _selection(answers.get("source_material")) == "no") else "no"


def annotate_guided_mode_answer(answers: dict[str, Any]) -> None:
    """Persist the explicit [2A] answer plus whether its displayed default was overridden."""
    if "guided_mode" not in answers:
        return
    default = guided_mode_default(answers)
    raw = answers["guided_mode"]
    selection = _selection(raw)
    if selection == "recommended":
        selection = default
    if selection not in {"yes", "no"}:
        raise WorldBuilderError("guided_mode selection must be yes or no")
    row = dict(raw) if isinstance(raw, dict) else {}
    row["selection"] = selection
    row.setdefault("source", "explicit")
    row["default_selection"] = default
    row["default_accepted"] = selection == default
    row["default_overridden"] = selection != default
    answers["guided_mode"] = row


def pages(blocks: list[str]) -> list[list[str]]:
    result: list[list[str]] = []
    current: list[str] = []
    for block in blocks:
        if block == PAGE_BREAK:
            if current:
                result.append(current)
                current = []
            continue
        current.append(block)
        if len(current) == MAX_BLOCKS_PER_PAGE:
            result.append(current)
            current = []
    if current:
        result.append(current)
    return result


def draft_path(workspace: Path, draft_id: str) -> Path:
    root = workspace / ".setup-drafts"
    root.mkdir(parents=True, exist_ok=True)
    return root / f"{draft_id}.json"


def initialize(workspace: Path, name: str, artifact_type: str, interface_mode: str, draft_id: str | None, template_path: Path | None = None) -> dict[str, Any]:
    if interface_mode not in {"simple", "advanced"}:
        raise WorldBuilderError("interface mode must be simple or advanced")
    if artifact_type not in {"card", "world", "lorebook", "group", "persona"}:
        raise WorldBuilderError("unsupported setup artifact type")
    draft_id = draft_id or f"{slugify(name)}-{secrets.token_hex(3)}"
    path = draft_path(workspace, draft_id)
    if path.exists():
        raise WorldBuilderError(f"setup draft already exists: {path}")
    block_list = blocks_for(artifact_type, interface_mode)
    template_meta = None
    template_defaults: dict[str, dict[str, Any]] = {}
    inapplicable_defaults: list[str] = []
    if template_path is not None:
        template, source_sha256, normalized_sha = load_template(template_path)
        if artifact_type not in template["artifact_types"]:
            raise WorldBuilderError(
                f"build template {template['name']!r} does not support artifact type {artifact_type!r}"
            )
        if interface_mode not in template["interface_modes"]:
            raise WorldBuilderError(
                f"build template {template['name']!r} does not support interface mode {interface_mode!r}"
            )
        applicable = set(block_list)
        for setting_id, answer in template["defaults"].items():
            if setting_id in applicable:
                row = dict(answer)
                row["source"] = "template"
                row["template_name"] = template["name"]
                template_defaults[setting_id] = row
            else:
                inapplicable_defaults.append(setting_id)
        template_meta = {
            "contract": TEMPLATE_CONTRACT,
            "name": template["name"],
            "source_sha256": source_sha256,
            "normalized_sha256": normalized_sha,
            "applied_setting_ids": sorted(template_defaults),
            "inapplicable_setting_ids": sorted(inapplicable_defaults),
        }
    page_list = pages(block_list)
    value = {
        "kind": KIND,
        "draft_version": VERSION,
        "draft_id": draft_id,
        "name": name,
        "artifact_type": artifact_type,
        "interface_mode": interface_mode,
        "created_at": now_iso(),
        "updated_at": now_iso(),
        "status": "in_progress",
        "max_blocks_per_page": MAX_BLOCKS_PER_PAGE,
        "template": template_meta,
        "pages": [
            {
                "page": i + 1,
                "setting_ids": page,
                "status": "pending",
                "prefill": {key: template_defaults[key] for key in page if key in template_defaults},
                "answers": {},
            }
            for i, page in enumerate(page_list)
        ],
    }
    atomic_write_json(path, value)
    return {
        "draft": str(path),
        "next_page": 1,
        "page_count": len(value["pages"]),
        "setting_ids": value["pages"][0]["setting_ids"],
        "prefill": value["pages"][0].get("prefill", {}),
        "template": template_meta,
    }


def load_draft(path: Path) -> dict[str, Any]:
    value = load_json(path)
    if not isinstance(value, dict) or value.get("kind") != KIND or value.get("draft_version") != VERSION:
        raise WorldBuilderError("invalid setup draft")
    return value


def save_page(path: Path, page_number: int, answers: dict[str, Any], recommended: bool = False, recommended_all: bool = False) -> dict[str, Any]:
    value = load_draft(path)
    page_rows = value.get("pages")
    if not isinstance(page_rows, list) or not 1 <= page_number <= len(page_rows):
        raise WorldBuilderError("page number is outside this setup flow")
    row = page_rows[page_number - 1]
    allowed = set(row.get("setting_ids", []))
    unknown = sorted(set(answers) - allowed)
    if unknown:
        raise WorldBuilderError(f"answers contain settings not on page {page_number}: {unknown}")
    if recommended or recommended_all:
        prefill = row.get("prefill", {}) if isinstance(row.get("prefill"), dict) else {}
        for setting_id in allowed:
            if setting_id in answers:
                continue
            if setting_id in prefill:
                accepted = dict(prefill[setting_id])
                accepted["accepted_via"] = "recommended"
                answers[setting_id] = accepted
            else:
                answers[setting_id] = {"selection": "recommended", "source": "default"}
    annotate_guided_mode_answer(answers)
    missing = sorted(allowed - set(answers))
    if missing:
        raise WorldBuilderError(f"page {page_number} is incomplete: {missing}")
    row["answers"] = answers
    row["status"] = "complete"
    if recommended_all:
        for later in page_rows[page_number:]:
            later_prefill = later.get("prefill", {}) if isinstance(later.get("prefill"), dict) else {}
            later_answers: dict[str, Any] = {}
            for setting_id in later.get("setting_ids", []):
                if setting_id in later_prefill:
                    accepted = dict(later_prefill[setting_id])
                    accepted["accepted_via"] = "recommended_all"
                    later_answers[setting_id] = accepted
                else:
                    later_answers[setting_id] = {"selection": "recommended", "source": "default"}
            annotate_guided_mode_answer(later_answers)
            later["answers"] = later_answers
            later["status"] = "complete"
    value["updated_at"] = now_iso()
    next_page = next((r["page"] for r in page_rows if r.get("status") != "complete"), None)
    if next_page is None:
        value["status"] = "ready_for_confirmation"
    atomic_write_json(path, value)
    next_row = page_rows[next_page - 1] if next_page is not None else None
    return {
        "status": value["status"], "next_page": next_page, "page_count": len(page_rows),
        "setting_ids": next_row.get("setting_ids", []) if next_row else [],
        "prefill": next_row.get("prefill", {}) if next_row else {},
    }


def reopen(path: Path, setting_id: str) -> dict[str, Any]:
    value = load_draft(path)
    for row in value.get("pages", []):
        if setting_id in row.get("setting_ids", []):
            row["status"] = "pending"
            row.setdefault("answers", {}).pop(setting_id, None)
            value["status"] = "in_progress"
            value["updated_at"] = now_iso()
            atomic_write_json(path, value)
            return {"page": row["page"], "setting_id": setting_id}
    raise WorldBuilderError(f"unknown setting id: {setting_id}")


def status(path: Path) -> dict[str, Any]:
    value = load_draft(path)
    completed = [row["page"] for row in value.get("pages", []) if row.get("status") == "complete"]
    next_page = next((row["page"] for row in value.get("pages", []) if row.get("status") != "complete"), None)
    return {
        "draft_id": value.get("draft_id"), "status": value.get("status"),
        "completed_pages": completed, "next_page": next_page,
        "page_count": len(value.get("pages", [])),
        "template": value.get("template"),
    }


def finalize(path: Path, output: Path) -> dict[str, Any]:
    value = load_draft(path)
    if value.get("status") != "ready_for_confirmation":
        raise WorldBuilderError("setup draft is incomplete")
    answers: dict[str, Any] = {}
    for row in value.get("pages", []):
        answers.update(row.get("answers", {}))
    result = {
        "kind": "worldbuilder-build-settings",
        "settings_version": 1,
        "draft_id": value.get("draft_id"),
        "name": value.get("name"),
        "artifact_type": value.get("artifact_type"),
        "interface_mode": value.get("interface_mode"),
        "confirmed_at": now_iso(),
        "template": value.get("template"),
        "answers": answers,
    }
    atomic_write_json(output, result)
    value["status"] = "finalized"
    value["finalized_output"] = str(output)
    value["updated_at"] = now_iso()
    atomic_write_json(path, value)
    return {"status": "finalized", "output": str(output), "answer_count": len(answers)}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    p = sub.add_parser("init")
    p.add_argument("--workspace", required=True)
    p.add_argument("--name", required=True)
    p.add_argument("--artifact-type", required=True, choices=["card", "world", "lorebook", "group", "persona"])
    p.add_argument("--interface-mode", required=True, choices=["simple", "advanced"])
    p.add_argument("--draft-id")
    p.add_argument("--template", help="Reusable build-template JSON whose values prefill, but never complete, the normal setup pages.")
    p = sub.add_parser("save-page")
    p.add_argument("--draft", required=True)
    p.add_argument("--page", required=True, type=int)
    p.add_argument(
        "--answers-json", "--answers-file", dest="answers_json", metavar="PATH",
        help="PATH to a JSON file (not inline JSON) holding one object per page setting id.",
    )
    p.add_argument("--recommended", action="store_true")
    p.add_argument("--recommended-all", action="store_true")
    p = sub.add_parser("status")
    p.add_argument("--draft", required=True)
    p = sub.add_parser("reopen")
    p.add_argument("--draft", required=True)
    p.add_argument("--setting", required=True)
    p = sub.add_parser("finalize")
    p.add_argument("--draft", required=True)
    p.add_argument("--output", required=True)
    args = parser.parse_args()
    try:
        if args.command == "init":
            result = initialize(
                Path(args.workspace).expanduser().resolve(), args.name, args.artifact_type,
                args.interface_mode, args.draft_id,
                Path(args.template).expanduser().resolve() if args.template else None,
            )
        elif args.command == "save-page":
            answers: dict[str, Any] = {}
            if args.answers_json:
                loaded = load_json(Path(args.answers_json).expanduser().resolve())
                if not isinstance(loaded, dict):
                    raise WorldBuilderError("answers JSON must be an object")
                answers = loaded
            result = save_page(Path(args.draft).expanduser().resolve(), args.page, answers, args.recommended, args.recommended_all)
        elif args.command == "status":
            result = status(Path(args.draft).expanduser().resolve())
        elif args.command == "reopen":
            result = reopen(Path(args.draft).expanduser().resolve(), args.setting)
        else:
            result = finalize(Path(args.draft).expanduser().resolve(), Path(args.output).expanduser().resolve())
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (WorldBuilderError, OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
