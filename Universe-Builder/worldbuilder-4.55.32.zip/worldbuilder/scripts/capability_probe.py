#!/usr/bin/env python3
"""Report WorldBuilder's operating capabilities on this host: available,
unavailable, or unknown for each, and what degrades without it. Report,
do not assume (Batch 4).

sessions_spawn, show_widget, image_generate, and vision_capable are tool-calling
capabilities of the agent running this skill, not something a subprocess
can introspect from the outside: there is no version threshold worth
hardcoding here, since one would go stale within weeks at this project's
release cadence. The calling agent reports what is actually in its own
tool list via the matching flag; an unpassed flag is reported as
"unknown", never guessed as available.

python3 is checked directly. Public-web readiness is intentionally not
re-probed here: searxng_preflight.py is the single live authority for the
SearXNG endpoint, supported OpenClaw host, and approved egress path.
"""
from __future__ import annotations

import argparse
import json
import sys
from typing import Any

from searxng_preflight import openclaw_host_status

CAPABILITIES: dict[str, dict[str, str]] = {
    "sessions_spawn": {
        "needed_for": "parallel discovery, generation, and audit dispatch",
        "degradation": "sequential execution; correct, just slower",
    },
    "image_generate": {
        "needed_for": "card art and expression sets",
        "degradation": "image prompts only; no rendered images",
    },
    "vision_capable": {
        "needed_for": "analyzing relevant wiki images during generation research",
        "degradation": "text-only research; visual details come from written descriptions only",
    },
    "show_widget": {
        "needed_for": "tiered interactive menus (Batch 11)",
        "degradation": "text menus",
    },
    "html_render": {
        "needed_for": "rich graph, diff, and diagnostic presentation",
        "degradation": "structured JSON/text reports remain authoritative",
    },
    "st_bridge": {
        "needed_for": "live SillyTavern runtime verification",
        "degradation": "synthetic activation verification only",
    },
    "wi_introspection": {
        "needed_for": "observed World Info activation capture",
        "degradation": "synthetic activation verification only",
    },
    "python3": {
        "needed_for": "every script in this skill",
        "degradation": "hard stop: nothing in WorldBuilder can run",
    },
}

# README's stated floor. Checked directly against this interpreter's own
# version. If this script is running at all, some python3 exists; the
# only real failure mode this catches is "python3 exists but is too old".
MIN_PYTHON = (3, 10)

def _tri_state(reported: str | None) -> str:
    return reported if reported in {"available", "unavailable"} else "unknown"


def _validate_vision_limits(value: Any) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise ValueError("vision_limits must be an object")
    out: dict[str, Any] = {}
    for key in ("max_images_per_request", "max_image_dimension_px", "max_image_bytes"):
        number = value.get(key)
        if not isinstance(number, int) or isinstance(number, bool) or number < 1:
            raise ValueError(f"vision_limits.{key} must be a positive integer")
        out[key] = number
    session = value.get("max_images_per_session")
    if session is not None:
        if not isinstance(session, int) or isinstance(session, bool) or session < 1:
            raise ValueError("vision_limits.max_images_per_session must be a positive integer when present")
        out["max_images_per_session"] = session
    model = value.get("model")
    if model is not None:
        if not isinstance(model, str) or not model.strip():
            raise ValueError("vision_limits.model must be a non-empty string when present")
        out["model"] = model.strip()
    return out


def probe_python3() -> dict[str, Any]:
    version = sys.version_info[:2]
    ok = version >= MIN_PYTHON
    have = ".".join(str(part) for part in version)
    need = ".".join(str(part) for part in MIN_PYTHON)
    return {
        "status": "available" if ok else "unavailable",
        "detail": f"{have} (need >= {need})",
    }


def probe(
    *,
    sessions_spawn: str | None = None,
    show_widget: str | None = None,
    image_generate: str | None = None,
    vision_capable: str | None = None,
    vision_model: str | None = None,
    vision_limits: dict[str, Any] | None = None,
    html_render: str | None = None,
    st_bridge: str | None = None,
    wi_introspection: str | None = None,
    timeout: float = 10.0,
) -> dict[str, Any]:
    """Report, do not assume. Agent-reported tri-states for tool-calling
    capabilities; empirical checks for everything a subprocess can observe
    directly. Missing capabilities degrade the product; they never block it
    except python3, which is a hard stop."""
    reported = {
        "sessions_spawn": _tri_state(sessions_spawn),
        "show_widget": _tri_state(show_widget),
        "image_generate": _tri_state(image_generate),
        "vision_capable": _tri_state(vision_capable),
        "html_render": _tri_state(html_render),
        "st_bridge": _tri_state(st_bridge),
        "wi_introspection": _tri_state(wi_introspection),
    }
    python_result = probe_python3()
    host = openclaw_host_status(timeout)

    capabilities: dict[str, dict[str, Any]] = {}
    for name, meta in CAPABILITIES.items():
        if name == "python3":
            status, detail = python_result["status"], python_result["detail"]
        else:
            status = reported[name]
            detail = (
                "reported by the calling agent from its own tool list" if status != "unknown"
                else f"not reported; pass --{name.replace('_', '-')} available|unavailable"
            )
        capabilities[name] = {
            "status": status,
            "needed_for": meta["needed_for"],
            "degradation": meta["degradation"],
            "detail": detail,
        }

    if vision_limits is not None:
        validated = _validate_vision_limits(vision_limits)
        capabilities["vision_capable"]["limits"] = validated
        reported_model = vision_model.strip() if isinstance(vision_model, str) and vision_model.strip() else validated.get("model")
        capabilities["vision_capable"]["limits_model"] = reported_model
        capabilities["vision_capable"]["limits_researched"] = True
    elif capabilities["vision_capable"]["status"] == "available":
        capabilities["vision_capable"]["limits"] = None
        capabilities["vision_capable"]["limits_researched"] = False

    hard_stop = capabilities["python3"]["status"] == "unavailable"
    degraded = sorted(name for name, row in capabilities.items() if row["status"] == "unavailable" and name != "python3")
    unknown = sorted(name for name, row in capabilities.items() if row["status"] == "unknown")

    if hard_stop:
        summary = "python3 is unavailable or too old; nothing in WorldBuilder can run."
    elif not degraded and not unknown:
        summary = "All capabilities confirmed available."
    else:
        summary = (
            "WorldBuilder can proceed with reduced functionality. Missing or unreported "
            "capabilities degrade specific features; they never block the product."
        )

    return {
        "schema": "worldbuilder.capability-probe.v1",
        "capabilities": capabilities,
        "openclaw_host": host,
        "hard_stop": hard_stop,
        "degraded": degraded,
        "unknown": unknown,
        "summary": summary,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--sessions-spawn", choices=("available", "unavailable"), default=None,
                         help="Report from the calling agent's own tool list, never guessed.")
    parser.add_argument("--show-widget", choices=("available", "unavailable"), default=None,
                         help="Report from the calling agent's own tool list, never guessed.")
    parser.add_argument("--image-generate", choices=("available", "unavailable"), default=None,
                         help="Report from the calling agent's own tool list, never guessed.")
    parser.add_argument("--vision-capable", choices=("available", "unavailable"), default=None,
                         help="Report whether the generation model/session can inspect images; never guessed from a model-name registry.")
    parser.add_argument("--vision-model", default=None,
                         help="Subagent model whose real, researched image limits are reported alongside --vision-capable.")
    parser.add_argument("--vision-limits", default=None,
                         help="Researched limits JSON: {\"max_images_per_request\": N, \"max_image_dimension_px\": N, \"max_image_bytes\": N, \"max_images_per_session\": N (optional)}. Never guessed.")
    parser.add_argument("--html-render", choices=("available", "unavailable"), default=None,
                         help="Report from the calling host; enables rich presentation only.")
    parser.add_argument("--st-bridge", choices=("available", "unavailable"), default=None,
                         help="Report whether a live SillyTavern bridge is available.")
    parser.add_argument("--wi-introspection", choices=("available", "unavailable"), default=None,
                         help="Report whether live World Info activation introspection is available.")
    parser.add_argument("--timeout", type=float, default=10.0)
    args = parser.parse_args()

    try:
        report = probe(
            sessions_spawn=args.sessions_spawn,
            show_widget=args.show_widget,
            image_generate=args.image_generate,
            vision_capable=args.vision_capable,
            vision_model=args.vision_model,
            vision_limits=json.loads(args.vision_limits) if args.vision_limits else None,
            html_render=args.html_render,
            st_bridge=args.st_bridge,
            wi_introspection=args.wi_introspection,
            timeout=args.timeout,
        )
    except (ValueError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    print(json.dumps(report, indent=2, sort_keys=True))
    return 1 if report["hard_stop"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
