#!/usr/bin/env python3
"""Package a ``chara_card_v3`` JSON object and optional files as CHARX.

The archive is unencrypted, contains ``card.json`` at its root, and validates
all member path components for portable ASCII-only names.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import zipfile
from pathlib import Path
from typing import Iterable

from wb_common import WorldBuilderError, safe_archive_path
from validate_output import validate
from expression_assets import DEFAULT_LABELS

AUDIO_EXTENSIONS = {".wav", ".mp3", ".ogg", ".flac", ".m4a", ".aac", ".opus"}


def guess_asset_type(filename: str) -> str:
    path = Path(filename)
    suffix = path.suffix.lower()  # Inspect before stripping the extension.
    stem = path.stem.lower()
    if suffix in AUDIO_EXTENSIONS:
        return "other"
    if stem in {"icon", "portrait", "avatar"}:
        return "icon"
    if stem in {"background", "bg", "scene"}:
        return "background"
    if stem.startswith(("emotion", "emote-", "emote_")):
        return "emotion"
    # Batch 10: expression_assets.py's own descriptor() names files
    # {label}.{ext} directly (e.g. "joy.png"), not "emotion_joy.png":
    # its actual naming convention, not a prefix. Checking against its
    # real label vocabulary directly (rather than guessing at a prefix
    # that does not match reality) is what actually classifies a
    # generated expression-set image correctly when packaging from a
    # directory via --assets.
    if stem in DEFAULT_LABELS:
        return "emotion"
    if stem.startswith(("user_", "user-")):
        return "user_icon"
    return "other"


def get_ext(filename: str) -> str:
    return Path(filename).suffix.lower().lstrip(".") or "unknown"


def collect_files(source_dir: str | None, archive_root: str) -> list[tuple[str, Path]]:
    if not source_dir:
        return []
    root = Path(source_dir).expanduser().resolve()
    if not root.is_dir():
        raise WorldBuilderError(f"directory does not exist: {root}")
    found: list[tuple[str, Path]] = []
    seen_casefold: set[str] = set()
    for path in sorted(root.rglob("*")):
        if not path.is_file() or path.is_symlink():
            continue
        relative = path.relative_to(root)
        if any(part.startswith((".", "_")) for part in relative.parts):
            continue
        archive_path = safe_archive_path(f"{archive_root}/{relative.as_posix()}")
        folded = archive_path.casefold()
        if folded in seen_casefold:
            raise WorldBuilderError(f"case-insensitive duplicate archive member: {archive_path}")
        seen_casefold.add(folded)
        found.append((archive_path, path))
    return found


def populate_assets(card: dict, asset_files: Iterable[tuple[str, Path]]) -> None:
    payload = card.setdefault("data", {})
    assets = payload.setdefault("assets", [])
    if not isinstance(assets, list):
        raise WorldBuilderError("data.assets must be an array")
    existing = {item.get("uri") for item in assets if isinstance(item, dict)}
    for archive_path, source in asset_files:
        uri = f"embeded://{archive_path}"
        if uri in existing:
            continue
        assets.append(
            {
                "type": guess_asset_type(source.name),
                "uri": uri,
                "name": source.stem,
                "ext": get_ext(source.name),
            }
        )
        existing.add(uri)


def resolve_embedded_members(card: dict, asset_map: dict[str, Path]) -> list[tuple[str, Path]]:
    """The single CHARX member-resolution rule (Batch 58 / A12).

    Every ``embeded://`` descriptor in the card must map to an approved source
    file, every resolved archive member must be a safe, unique path, and every
    entry in the asset map must actually be used. Both this module's packer and
    ``runtime_target_adapter.write_charx`` call this, so neither path can accept
    a descriptor that resolves to nothing (the standalone packer previously did,
    and reported success).
    """
    data = card.get("data") if isinstance(card, dict) else None
    assets = data.get("assets", []) if isinstance(data, dict) else []
    if not isinstance(assets, list):
        raise WorldBuilderError("CHARX card data.assets must be an array")
    members: list[tuple[str, Path]] = []
    seen: set[str] = {"card.json"}
    used: set[str] = set()
    for row in assets:
        if not isinstance(row, dict) or not isinstance(row.get("uri"), str):
            continue
        uri = row["uri"]
        if not uri.startswith("embeded://"):
            continue
        source = asset_map.get(uri)
        if source is None:
            raise WorldBuilderError(f"CHARX embedded asset {uri!r} lacks an approved source-file map")
        member = safe_archive_path(uri[len("embeded://"):])
        if member.casefold() in {item.casefold() for item in seen}:
            raise WorldBuilderError(f"CHARX repeats archive member {member!r}")
        seen.add(member)
        used.add(uri)
        members.append((member, source))
    unused = sorted(set(asset_map) - used)
    if unused:
        raise WorldBuilderError("CHARX asset map contains unused URI(s): " + ", ".join(unused))
    return members


def validate_card(card: object) -> dict:
    if not isinstance(card, dict):
        raise WorldBuilderError("card JSON must be an object")
    if card.get("spec") != "chara_card_v3":
        raise WorldBuilderError("CHARX packaging requires spec='chara_card_v3'")
    if card.get("spec_version") != "3.0":
        raise WorldBuilderError("CHARX packaging requires spec_version='3.0'")
    report, _ = validate(card, profile="spec")
    if report.errors:
        summary = "; ".join(f"{issue.path or '/'}: {issue.message}" for issue in report.errors[:8])
        raise WorldBuilderError(f"card fails Character Card V3 validation: {summary}")
    return card


def build_charx(card_path: str, output_path: str, assets_dir: str | None = None, modules_dir: str | None = None) -> Path:
    source = Path(card_path).expanduser().resolve()
    output = Path(output_path).expanduser().resolve()
    try:
        card = validate_card(json.loads(source.read_text(encoding="utf-8")))
    except json.JSONDecodeError as exc:
        raise WorldBuilderError(f"invalid card JSON: {exc}") from exc

    card = json.loads(json.dumps(card))  # Deep copy without non-JSON values.
    asset_files = collect_files(assets_dir, "assets")
    module_files = collect_files(modules_dir, "modules")
    populate_assets(card, asset_files)
    validate_card(card)
    # Batch 58 / A12: every embedded descriptor the card declares must resolve to
    # a real member before anything is written. The standalone packer used to
    # write the archive and report success with a dangling descriptor.
    resolve_embedded_members(card, {f"embeded://{archive_path}": source for archive_path, source in asset_files})

    safe_archive_path("card.json")
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = output.with_name(f".{output.name}.tmp")
    if temporary.exists():
        temporary.unlink()
    try:
        with zipfile.ZipFile(temporary, "w", compression=zipfile.ZIP_DEFLATED, allowZip64=True) as archive:
            archive.writestr("card.json", json.dumps(card, ensure_ascii=False, indent=2).encode("utf-8"))
            for archive_path, source_path in asset_files + module_files:
                archive.write(source_path, archive_path)
        with zipfile.ZipFile(temporary, "r") as archive:
            if archive.testzip() is not None or "card.json" not in archive.namelist():
                raise WorldBuilderError("archive verification failed")
            for name in archive.namelist():
                safe_archive_path(name)
            reopened = json.loads(archive.read("card.json").decode("utf-8"))
            validate_card(reopened)
        os.replace(temporary, output)
    finally:
        if temporary.exists():
            temporary.unlink()

    print(f"CHARX built: {output}")
    print(f"Assets: {len(asset_files)}; modules: {len(module_files)}; bytes: {output.stat().st_size}")
    return output


def main() -> int:
    parser = argparse.ArgumentParser(description="Package a V3 card JSON and optional assets as CHARX.")
    parser.add_argument("card_positional", nargs="?", help="V3 card JSON path (legacy positional form)")
    parser.add_argument("--card")
    parser.add_argument("--output", required=True)
    parser.add_argument("--assets")
    parser.add_argument("--modules")
    args = parser.parse_args()
    card = args.card or args.card_positional
    if not card:
        parser.error("provide --card PATH or a positional card path")
    output = args.output if args.output.lower().endswith(".charx") else f"{args.output}.charx"
    try:
        build_charx(card, output, args.assets, args.modules)
        return 0
    except (WorldBuilderError, OSError, zipfile.BadZipFile) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
