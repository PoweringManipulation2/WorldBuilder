#!/usr/bin/env python3
"""Renderer-neutral dashboard projections over existing WorldBuilder contracts.

These documents are deliberately derived views. They never become planning,
discovery, generation, audit, or delivery authority; every value points back to
an existing owner or is labeled as a deterministic derivation.
"""
from __future__ import annotations

import argparse
import json
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

import activation_map_gate
import budget_contract
import phase_quality_check
import pipeline_stage_gate
from discovery_plan import canonicalize_url
from wb_common import (
    WorldBuilderError,
    atomic_write_json,
    discover_phase_files,
    load_build_state,
    load_json,
    now_iso,
    resolve_state_path,
    sha256_file,
    uid_label,
)

HEALTH_KIND = "worldbuilder-health-report"
GRAPH_KIND = "worldbuilder-graph"
SOURCE_KIND = "worldbuilder-source-coverage"
PROGRESS_KIND = "worldbuilder-build-progress"
VERSION = 1


def _rel(path: Path | None, root: Path) -> str | None:
    if path is None:
        return None
    try:
        return str(path.relative_to(root)).replace("\\", "/")
    except ValueError:
        return str(path)


def _path(root: Path, state: dict[str, Any], key: str, fallback: str | None = None) -> Path | None:
    value = state.get("paths", {}).get(key)
    if value in (None, ""):
        if fallback is None:
            return None
        return (root / fallback).resolve()
    raw = Path(str(value))
    return (raw if raw.is_absolute() else root / raw).resolve()


def _load_if(path: Path | None) -> Any:
    return load_json(path) if path is not None and path.exists() else None


def _manifest(root: Path, state: dict[str, Any]) -> tuple[dict[str, Any], Path]:
    path = resolve_state_path(root, state, "manifest")
    if path is None or not path.exists():
        raise WorldBuilderError("dashboard graph/health projections require the current planned manifest")
    value = load_json(path)
    if not isinstance(value, dict):
        raise WorldBuilderError("manifest must be a JSON object before dashboard projection")
    return value, path


def _validated_graph(build_state: str | Path, root: Path, state: dict[str, Any], manifest: dict[str, Any]) -> dict[str, Any]:
    # Validate the public map contract first. This catches the stale-manifest /
    # stale-recursion-map case instead of projecting whichever file happens to
    # be newer.
    activation_map_gate.validate(str(build_state), write_receipt=False)
    _registry, _registry_path, profile, _profile_path = activation_map_gate.load_registry_profile(root, state)
    return activation_map_gate.canonical_projection(manifest, profile)


def _required_edge_uids(graph: dict[str, Any]) -> set[str]:
    result: set[str] = set()
    for edge in graph.get("edges", []) if isinstance(graph.get("edges"), list) else []:
        if isinstance(edge, dict) and edge.get("required") is True:
            result.add(uid_label(edge.get("target_uid")))
    return result


def _cycles(graph: dict[str, Any]) -> list[list[str]]:
    adjacency: dict[str, list[str]] = defaultdict(list)
    for edge in graph.get("edges", []) if isinstance(graph.get("edges"), list) else []:
        if not isinstance(edge, dict):
            continue
        source, target = uid_label(edge.get("source_uid")), uid_label(edge.get("target_uid"))
        if source and target:
            adjacency[source].append(target)
    cycles: set[tuple[str, ...]] = set()
    active: list[str] = []
    active_set: set[str] = set()
    visited: set[str] = set()

    def walk(node: str) -> None:
        if node in active_set:
            start = active.index(node)
            cycle = active[start:] + [node]
            core = cycle[:-1]
            if core:
                rotations = [tuple(core[i:] + core[:i]) for i in range(len(core))]
                normalized = min(rotations)
                cycles.add(normalized)
            return
        if node in visited:
            return
        active.append(node)
        active_set.add(node)
        for target in adjacency.get(node, []):
            walk(target)
        active.pop()
        active_set.remove(node)
        visited.add(node)

    for node in sorted(adjacency):
        walk(node)
    return [list(row) for row in sorted(cycles)]


def _character_plan(root: Path, state: dict[str, Any]) -> dict[str, Any] | None:
    value = _load_if(_path(root, state, "character_plan"))
    return value if isinstance(value, dict) else None


def build_graph_document(root: Path, state: dict[str, Any], manifest: dict[str, Any], graph: dict[str, Any], manifest_path: Path) -> dict[str, Any]:
    by_uid = {uid_label(row.get("uid", row.get("id"))): row for row in manifest.get("entries", []) if isinstance(row, dict)}
    required_targets = _required_edge_uids(graph)
    nodes: list[dict[str, Any]] = []
    for ledger in graph.get("entries", []):
        uid = uid_label(ledger.get("uid"))
        source = by_uid.get(uid, {})
        arch = source.get("architecture") if isinstance(source.get("architecture"), dict) else {}
        emit = source.get("emit") if isinstance(source.get("emit"), dict) else {}
        nodes.append({
            **ledger,
            "constant": bool(emit.get("constant", False)),
            "source_urls": list(source.get("source_urls", [])) if isinstance(source.get("source_urls"), list) else [],
            "faction_like": str(arch.get("layer", "")).casefold() in {"faction", "organization"},
            "protected_categories": sorted(budget_contract.protected_categories(source, required_targets)),
        })

    relationships: list[dict[str, Any]] = []
    memberships: list[dict[str, Any]] = []
    char_plan = _character_plan(root, state)
    if char_plan:
        for rel in char_plan.get("relationships", []) if isinstance(char_plan.get("relationships"), list) else []:
            if not isinstance(rel, dict):
                continue
            relationships.append({
                "relationship_id": rel.get("relationship_id"),
                "source_character_id": rel.get("source_character_id"),
                "source_state_id": rel.get("source_state_id"),
                "target_character_id": rel.get("target_character_id"),
                "target_state_id": rel.get("target_state_id"),
                "activation_target_uid": rel.get("activation_target_uid"),
                "era_id": rel.get("era_id"),
                "relationship_type": rel.get("relationship_type"),
                "derivation": "character_plan.relationships join",
            })
        for character in char_plan.get("characters", []) if isinstance(char_plan.get("characters"), list) else []:
            if not isinstance(character, dict):
                continue
            cid = character.get("character_id")
            identity = character.get("identity") if isinstance(character.get("identity"), dict) else {}
            for faction in identity.get("factions", []) if isinstance(identity.get("factions"), list) else []:
                memberships.append({"character_id": cid, "faction": faction, "derivation": "character_plan.identity.factions"})

    cross_era: list[dict[str, Any]] = []
    for edge in graph.get("edges", []) if isinstance(graph.get("edges"), list) else []:
        if not isinstance(edge, dict):
            continue
        source = by_uid.get(uid_label(edge.get("source_uid")), {})
        target = by_uid.get(uid_label(edge.get("target_uid")), {})
        sa = source.get("architecture") if isinstance(source.get("architecture"), dict) else {}
        ta = target.get("architecture") if isinstance(target.get("architecture"), dict) else {}
        source_eras = set(str(x) for x in sa.get("era_ids", []) if str(x)) if isinstance(sa.get("era_ids"), list) else set()
        target_eras = set(str(x) for x in ta.get("era_ids", []) if str(x)) if isinstance(ta.get("era_ids"), list) else set()
        if source_eras and target_eras and source_eras != target_eras:
            cross_era.append({
                "source_uid": edge.get("source_uid"), "target_uid": edge.get("target_uid"),
                "source_era_ids": sorted(source_eras), "target_era_ids": sorted(target_eras),
                "overlap": sorted(source_eras & target_eras),
                "derivation": "manifest entry era_ids join over canonical activation edge",
            })

    source_dependencies = [
        {"source_url": url, "target_uid": row.get("uid", row.get("id")), "derivation": "manifest entry source_urls"}
        for row in manifest.get("entries", []) if isinstance(row, dict)
        for url in (row.get("source_urls", []) if isinstance(row.get("source_urls"), list) else [])
    ]
    protection = [
        {"uid": node.get("uid"), "categories": node.get("protected_categories", []), "derivation": "budget_contract.protected_categories"}
        for node in nodes if node.get("protected_categories")
    ]
    return {
        "kind": GRAPH_KIND,
        "projection_version": VERSION,
        "build_id": state.get("build_id"),
        "generated_at": now_iso(),
        "authoritative": False,
        "authority": {
            "activation_edges": "manifest.activation_graph.edges",
            "note": "Only activation_edges are authoritative graph edges. Every derived_view is a labeled join/projection over another existing owner.",
            "manifest": _rel(manifest_path, root),
            "manifest_sha256": sha256_file(manifest_path),
        },
        "nodes": nodes,
        "activation_edges": graph.get("edges", []),
        "derived_views": {
            "required_relationships": relationships,
            "cross_era_observations": cross_era,
            "source_dependencies": source_dependencies,
            "faction_memberships": memberships,
            "protection_categories": protection,
        },
    }


def _discovery_result_rows(root: Path, state: dict[str, Any]) -> list[tuple[dict[str, Any], dict[str, Any]]]:
    assignments_root = _path(root, state, "assignments", ".work/assignments")
    rows: list[tuple[dict[str, Any], dict[str, Any]]] = []
    if assignments_root is None or not assignments_root.exists():
        return rows
    assignments: list[dict[str, Any]] = []
    for path in sorted(assignments_root.glob("*.json")):
        try:
            value = load_json(path)
        except Exception:
            continue
        if isinstance(value, dict) and (str(value.get("assignment_id", "")).startswith("discovery-") or value.get("role") == "research") and value.get("output"):
            value = dict(value)
            value["__path"] = path
            assignments.append(value)
    assignments.sort(key=lambda row: (int(row.get("pass_number", 0) or 0), str(row.get("assignment_id", ""))))
    for assignment in assignments:
        output = Path(str(assignment.get("output")))
        output = output if output.is_absolute() else root / output
        if output.exists():
            value = load_json(output)
            if isinstance(value, dict):
                rows.append((assignment, value))
    return rows


def build_source_coverage(root: Path, state: dict[str, Any]) -> dict[str, Any]:
    base = {
        "kind": SOURCE_KIND, "projection_version": VERSION, "build_id": state.get("build_id"),
        "generated_at": now_iso(), "authoritative": False,
        "authority": "discovery plan/index and worker accounting",
    }
    if not bool((state.get("discovery") or {}).get("required")):
        return {**base, "status": "not_applicable", "reason": "this build does not require source discovery", "summary": {k: 0 for k in ("included", "filtered", "merged", "ignored", "unsupported")}, "pages": []}
    plan_path = _path(root, state, "discovery_plan")
    plan = _load_if(plan_path)
    if not isinstance(plan, dict):
        return {**base, "status": "pending", "reason": "discovery plan is not materialized yet", "summary": {k: 0 for k in ("included", "filtered", "merged", "ignored", "unsupported")}, "pages": []}

    page_map: dict[str, dict[str, Any]] = {}
    for raw in plan.get("expected_urls", []) if isinstance(plan.get("expected_urls"), list) else []:
        url = canonicalize_url(raw)
        if url:
            page_map[url] = {"url": url, "status": "ignored", "accounting_code": None, "reason": "no terminal discovery accounting recorded yet", "source": "discovery_plan.expected_urls"}
    for row in plan.get("prefilter_accounting", []) if isinstance(plan.get("prefilter_accounting"), list) else []:
        if not isinstance(row, dict):
            continue
        url = canonicalize_url(row.get("url"))
        if not url:
            continue
        page_map[url] = {
            "url": url, "status": "filtered", "accounting_code": row.get("code"), "reason": row.get("reason"),
            "classification": row.get("classification"), "source": "discovery_plan.prefilter_accounting",
        }

    entity_urls: set[str] = set()
    for assignment, result in _discovery_result_rows(root, state):
        for entity in result.get("entities", []) if isinstance(result.get("entities"), list) else []:
            if not isinstance(entity, dict):
                continue
            for raw in entity.get("source_urls", []) if isinstance(entity.get("source_urls"), list) else []:
                raw_url = raw.get("url") if isinstance(raw, dict) else raw
                url = canonicalize_url(raw_url)
                if url:
                    entity_urls.add(url)
        fetch_by_url = {}
        for record in result.get("fetch_records", []) if isinstance(result.get("fetch_records"), list) else []:
            if isinstance(record, dict):
                url = canonicalize_url(record.get("url"))
                if url:
                    fetch_by_url[url] = record
        excluded_reasons: dict[str, str] = {}
        excluded_codes: dict[str, str] = {}
        for row in result.get("excluded_urls", []) if isinstance(result.get("excluded_urls"), list) else []:
            if isinstance(row, dict):
                url = canonicalize_url(row.get("url"))
                if url:
                    excluded_reasons[url] = str(row.get("reason") or "")
                    excluded_codes[url] = str(row.get("code") or "")
        delegated_reasons: dict[str, str] = {}
        for row in result.get("delegated_urls", []) if isinstance(result.get("delegated_urls"), list) else []:
            if isinstance(row, dict):
                url = canonicalize_url(row.get("url"))
                if url:
                    delegated_reasons[url] = str(row.get("reason") or "")
        statuses: dict[str, str] = {}
        for key, status in (("visited_urls", "visited"), ("failed_urls", "failed")):
            for raw in result.get(key, []) if isinstance(result.get(key), list) else []:
                url = canonicalize_url(raw)
                if url:
                    statuses[url] = status
        for url in excluded_reasons:
            statuses[url] = "excluded"
        for url in delegated_reasons:
            statuses[url] = "delegated"
        for url, status in statuses.items():
            record = fetch_by_url.get(url, {})
            if status == "visited":
                cls, reason, code = ("included", "page contributed at least one discovered entity", "entity_source") if url in entity_urls else ("ignored", "page was visited but contributed no retained entity", "no_retained_entity")
            elif status == "excluded":
                cls, reason, code = "filtered", excluded_reasons.get(url) or "worker excluded page", excluded_codes.get(url) or "worker_exclusion"
            elif status == "failed":
                cls, reason, code = "unsupported", str(record.get("error") or record.get("reason") or "fetch failed"), str(record.get("code") or "fetch_failed")
            else:
                cls, reason, code = "ignored", delegated_reasons.get(url) or "delegated for later discovery accounting", "delegated"
            page_map[url] = {
                "url": url, "status": cls, "accounting_code": code, "reason": reason,
                "fetch_status": status, "fetch_method": record.get("method"),
                "assignment_id": assignment.get("assignment_id"), "pass_number": assignment.get("pass_number"),
                "source": "discovery_worker_accounting",
            }

    index = _load_if(_path(root, state, "discovery_index"))
    merged_pages: set[str] = set()
    if isinstance(index, dict):
        metrics = index.get("metrics") if isinstance(index.get("metrics"), dict) else {}
        resolution = metrics.get("entity_resolution") if isinstance(metrics.get("entity_resolution"), dict) else {}
        for group in resolution.get("groups", []) if isinstance(resolution.get("groups"), list) else []:
            if not isinstance(group, dict):
                continue
            for raw in group.get("shared_source_pages", []) if isinstance(group.get("shared_source_pages"), list) else []:
                url = canonicalize_url(raw)
                if url:
                    merged_pages.add(url)
    for url in merged_pages:
        if url in page_map and page_map[url]["status"] == "included":
            page_map[url] = {**page_map[url], "status": "merged", "reason": "page contributed to an entity group merged by deterministic entity resolution", "accounting_code": "entity_resolution_merge"}

    summary = Counter(row["status"] for row in page_map.values())
    for key in ("included", "filtered", "merged", "ignored", "unsupported"):
        summary.setdefault(key, 0)
    return {
        **base,
        "status": "complete" if isinstance(index, dict) and index.get("status") == "complete" else "provisional",
        "plan": _rel(plan_path, root), "plan_sha256": sha256_file(plan_path) if plan_path and plan_path.exists() else None,
        "index": _rel(_path(root, state, "discovery_index"), root),
        "summary": dict(sorted(summary.items())),
        "pages": [page_map[url] for url in sorted(page_map)],
    }


def _phase_quality(root: Path, state: dict[str, Any], build_state: str | Path) -> dict[str, Any]:
    report_path = root / ".work" / "findings" / "phase-quality-pre-merge.json"
    if report_path.exists():
        report = load_json(report_path)
    else:
        phases = _path(root, state, "phases", ".work/phases")
        if phases is None or not phases.exists() or not discover_phase_files(phases):
            return {"status": "not_available", "reason": "no generated phases exist yet"}
        try:
            report = phase_quality_check.analyze_build(str(build_state), write=False)
        except Exception as exc:
            return {"status": "existing_contract_error", "error": str(exc)}
    findings = report.get("findings", []) if isinstance(report, dict) and isinstance(report.get("findings"), list) else []
    counts = Counter(str(row.get("kind")) for row in findings if isinstance(row, dict))
    return {"status": "available", "finding_count": len(findings), "near_duplicates": counts.get("near_duplicate", 0), "possible_contradictions": counts.get("possible_contradiction", 0), "authoritative": False}


def _canon_conflicts(root: Path, state: dict[str, Any]) -> dict[str, Any]:
    research = _path(root, state, "research", "artifacts/research")
    total = unresolved = 0
    files = 0
    if research and research.exists():
        for path in sorted(research.rglob("*.json")):
            try:
                value = load_json(path)
            except Exception:
                continue
            if not isinstance(value, dict) or not isinstance(value.get("entries"), list):
                continue
            files += 1
            for entry in value["entries"]:
                if not isinstance(entry, dict):
                    continue
                for conflict in entry.get("conflicts", []) if isinstance(entry.get("conflicts"), list) else []:
                    if isinstance(conflict, dict) and conflict.get("kind") == "canon_claim_conflict":
                        total += 1
                        if not conflict.get("resolution"):
                            unresolved += 1
    return {"status": "available" if files else "not_available", "conflict_count": total, "unresolved_count": unresolved, "evidence_file_count": files}


def _knowledge_findings(root: Path, state: dict[str, Any]) -> dict[str, Any]:
    findings_root = _path(root, state, "findings", ".work/findings")
    total = 0
    files = 0
    if findings_root and findings_root.exists():
        for path in sorted(findings_root.rglob("*.json")):
            try:
                value = load_json(path)
            except Exception:
                continue
            rows = value.get("findings") if isinstance(value, dict) else None
            if not isinstance(rows, list):
                continue
            files += 1
            for row in rows:
                if not isinstance(row, dict):
                    continue
                text = " ".join(str(row.get(k, "")) for k in ("category", "summary", "recommended_action")).casefold()
                if "knowledge" in text and ("boundary" in text or "future" in text or "leak" in text):
                    total += 1
    return {"status": "available" if files else "not_available", "violation_count": total, "finding_file_count": files}


def build_health(root: Path, state: dict[str, Any], manifest: dict[str, Any], graph: dict[str, Any], source_coverage: dict[str, Any], build_state: str | Path) -> dict[str, Any]:
    entries = graph.get("entries", []) if isinstance(graph.get("entries"), list) else []
    edges = graph.get("edges", []) if isinstance(graph.get("edges"), list) else []
    manifest_by_uid = {uid_label(row.get("uid", row.get("id"))): row for row in manifest.get("entries", []) if isinstance(row, dict)}
    triggerable = 0
    covered = 0
    orphans: list[dict[str, Any]] = []
    for row in entries:
        uid = uid_label(row.get("uid"))
        original = manifest_by_uid.get(uid, {})
        emit = original.get("emit") if isinstance(original.get("emit"), dict) else {}
        role = str(row.get("recursion_role", ""))
        constant = bool(emit.get("constant", False))
        strategy = str(row.get("strategy", ""))
        if not constant:
            triggerable += 1
            if strategy == "vector-only" or row.get("primary_keywords"):
                covered += 1
        if int(row.get("incoming_edges", 0) or 0) == 0 and not constant and role != "root":
            orphans.append({"uid": row.get("uid"), "name": row.get("name"), "recursion_role": role})
    cycles = _cycles(graph)
    max_out = max((int(row.get("outgoing_edges", 0) or 0) for row in entries), default=0)
    max_level = max((int(edge.get("level", 0) or 0) for edge in edges if isinstance(edge, dict)), default=0)

    budget_dimension: dict[str, Any]
    if not bool((state.get("budget") or {}).get("applicable")):
        budget_dimension = {"status": "not_applicable", "reason": "budget contract is not applicable to this build"}
    else:
        try:
            plan, plan_path = budget_contract.load_bound_plan(root, state, manifest)
            analysis = budget_contract.analyze_manifest(plan, manifest)
            worst = next((row for row in analysis.get("simulations", []) if row.get("name") == "worst_case_recursion_path"), None)
            budget_dimension = {"status": "available", "worst_case": worst, "plan": _rel(plan_path, root), "plan_sha256": sha256_file(plan_path)}
        except Exception as exc:
            budget_dimension = {"status": "existing_contract_error", "error": str(exc)}

    return {
        "kind": HEALTH_KIND, "projection_version": VERSION, "build_id": state.get("build_id"),
        "generated_at": now_iso(), "authoritative": False,
        "note": "Dimensioned report only; WorldBuilder does not compute an aggregate health score.",
        "dimensions": {
            "trigger_coverage": {"status": "available", "triggerable_entries": triggerable, "covered_entries": covered, "ratio": round(covered / triggerable, 4) if triggerable else 1.0},
            "orphan_nodes": {"status": "available", "count": len(orphans), "nodes": orphans, "derivation": "zero canonical activation in-edges and neither constant nor root"},
            "recursion_risk": {"status": "available", "edge_count": len(edges), "required_edge_count": sum(1 for e in edges if isinstance(e, dict) and e.get("required") is True), "max_declared_level": max_level, "max_out_degree": max_out, "cycle_count": len(cycles), "cycles": cycles},
            "worst_case_activation": budget_dimension,
            "phase_quality": _phase_quality(root, state, build_state),
            "source_coverage": {"status": source_coverage.get("status"), "summary": source_coverage.get("summary", {})},
            "canon_conflicts": _canon_conflicts(root, state),
            "knowledge_boundaries": _knowledge_findings(root, state),
        },
    }


def _count_json(path: Path | None) -> int:
    return len(list(path.glob("*.json"))) if path and path.exists() else 0


def build_progress(root: Path, state: dict[str, Any]) -> dict[str, Any]:
    ledger = pipeline_stage_gate.load_ledger(root, state)
    stages = ledger.get("stages", []) if isinstance(ledger.get("stages"), list) else []
    recorded = [row.get("stage") for row in stages if isinstance(row, dict) and isinstance(row.get("stage"), str)]
    remaining = [stage for stage in pipeline_stage_gate.STAGES if stage not in recorded]
    discovery_index = _load_if(_path(root, state, "discovery_index"))
    manifest = _load_if(_path(root, state, "manifest"))
    assignments = _path(root, state, "assignments", ".work/assignments")
    evidence = _path(root, state, "evidence_receipts", ".work/evidence-receipts")
    phases = _path(root, state, "phases", ".work/phases")
    audit_assignments = _path(root, state, "audit_assignments", ".work/audit-assignments")
    audit_runtime = _path(root, state, "audit_runtime", ".work/audit-runtime")
    budget_plan = _load_if(_path(root, state, "budget_plan"))
    discovery_metrics = discovery_index.get("metrics", {}) if isinstance(discovery_index, dict) and isinstance(discovery_index.get("metrics"), dict) else {}
    primary = discovery_metrics.get("primary", {}) if isinstance(discovery_metrics.get("primary"), dict) else {}
    saturation = discovery_metrics.get("saturation", {}) if isinstance(discovery_metrics.get("saturation"), dict) else {}
    phase_count = len(discover_phase_files(phases)) if phases and phases.exists() else 0
    assignment_rows = []
    if assignments and assignments.exists():
        for p in assignments.glob("*.json"):
            try:
                row = load_json(p)
            except Exception:
                continue
            if isinstance(row, dict):
                assignment_rows.append(row)
    generation_assignments = [row for row in assignment_rows if str(row.get("role", "")).casefold() in {"generation", "writer"} or str(row.get("assignment_id", "")).startswith("generation-")]
    discovery_assignments = [row for row in assignment_rows if str(row.get("assignment_id", "")).startswith("discovery-")]
    return {
        "kind": PROGRESS_KIND, "projection_version": VERSION, "build_id": state.get("build_id"),
        "generated_at": now_iso(), "authoritative": False,
        "authority": "projection over build-state, stage ledger, receipts, and existing artifacts",
        "stage_ledger": {"recorded": recorded, "recorded_count": len(recorded), "total_count": len(pipeline_stage_gate.STAGES), "current_stage": ledger.get("current_stage"), "remaining_stages": remaining},
        "discovery": {
            "required": bool((state.get("discovery") or {}).get("required")), "state_status": (state.get("discovery") or {}).get("status"),
            "index_status": discovery_index.get("status") if isinstance(discovery_index, dict) else None,
            "pages_expected": primary.get("expected_url_count"), "pages_accounted": primary.get("accounted_url_count"),
            "entities_accepted": discovery_index.get("unique_entity_count") if isinstance(discovery_index, dict) else None,
            "saturated": saturation.get("effective_saturated"), "assignment_count": len(discovery_assignments),
        },
        "planning": {"manifest_present": isinstance(manifest, dict), "entry_count": len(manifest.get("entries", [])) if isinstance(manifest, dict) and isinstance(manifest.get("entries"), list) else None, "planning_receipt_present": bool(_path(root, state, "planning_receipt") and _path(root, state, "planning_receipt").exists())},
        "generation": {"assignment_count": len(generation_assignments), "evidence_receipt_count": _count_json(evidence), "completed_phase_count": phase_count, "expected_phase_count": (state.get("pipeline") or {}).get("expected_phase_count")},
        "audit": {"assignment_count": len(list(audit_assignments.rglob("*.json"))) if audit_assignments and audit_assignments.exists() else 0, "runtime_receipt_count": len(list(audit_runtime.rglob("*.json"))) if audit_runtime and audit_runtime.exists() else 0, "pre_generation_receipt_present": bool(_path(root, state, "pre_generation_audit_receipt") and _path(root, state, "pre_generation_audit_receipt").exists()), "post_generation_receipt_present": bool(_path(root, state, "post_generation_audit_receipt") and _path(root, state, "post_generation_audit_receipt").exists())},
        "budget": {"applicable": bool((state.get("budget") or {}).get("applicable")), "profile_id": (state.get("budget") or {}).get("profile_id"), "plan_present": isinstance(budget_plan, dict), "context_window_mode": (state.get("budget") or {}).get("context_window_mode")},
    }


def _output_paths(root: Path, state: dict[str, Any]) -> dict[str, Path]:
    defaults = {
        "health": "artifacts/dashboard/build_health.json",
        "graph": "artifacts/dashboard/activation_graph.json",
        "source": "artifacts/dashboard/source_coverage.json",
        "progress": "artifacts/dashboard/build_progress.json",
    }
    keys = {
        "health": "dashboard_build_health", "graph": "dashboard_activation_graph",
        "source": "dashboard_source_coverage", "progress": "dashboard_build_progress",
    }
    return {name: _path(root, state, keys[name], fallback) for name, fallback in defaults.items()}  # type: ignore[return-value]


def generate(build_state: str | Path, *, selected: str = "all", write: bool = True) -> dict[str, Any]:
    root, state = load_build_state(build_state)
    selected = selected.casefold().replace("_", "-")
    valid = {"all", "health", "graph", "source", "source-coverage", "progress"}
    if selected not in valid:
        raise WorldBuilderError(f"dashboard artifact must be one of {sorted(valid)}, found {selected!r}")
    want = {"health", "graph", "source", "progress"} if selected == "all" else ({"source"} if selected == "source-coverage" else {selected})
    docs: dict[str, dict[str, Any]] = {}
    source_doc = build_source_coverage(root, state) if ("source" in want or "health" in want) else None
    manifest = graph = manifest_path = None
    if "graph" in want or "health" in want:
        manifest, manifest_path = _manifest(root, state)
        graph = _validated_graph(build_state, root, state, manifest)
    if "graph" in want:
        docs["graph"] = build_graph_document(root, state, manifest, graph, manifest_path)  # type: ignore[arg-type]
    if "source" in want:
        docs["source"] = source_doc  # type: ignore[assignment]
    if "progress" in want:
        docs["progress"] = build_progress(root, state)
    if "health" in want:
        docs["health"] = build_health(root, state, manifest, graph, source_doc or build_source_coverage(root, state), build_state)  # type: ignore[arg-type]
    paths = _output_paths(root, state)
    if write:
        for name, doc in docs.items():
            atomic_write_json(paths[name], doc)
    return {
        "status": "generated" if write else "projected",
        "build_id": state.get("build_id"),
        "artifacts": {name: {"kind": doc.get("kind"), "path": _rel(paths[name], root), "sha256": sha256_file(paths[name]) if write else None} for name, doc in docs.items()},
        "documents": docs,
    }


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Project renderer-neutral WorldBuilder dashboard JSON from existing build contracts.")
    p.add_argument("--build-state", required=True)
    p.add_argument("--artifact", default="all", choices=["all", "health", "graph", "source", "source-coverage", "progress"])
    p.add_argument("--no-write", action="store_true", help="Compute and print the projection without writing artifacts/dashboard/*.json")
    return p


def main() -> int:
    args = parser().parse_args()
    try:
        print(json.dumps(generate(args.build_state, selected=args.artifact, write=not args.no_write), ensure_ascii=False, indent=2))
        return 0
    except (WorldBuilderError, OSError, ValueError) as exc:
        print(f"ERROR: {exc}")
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
