#!/usr/bin/env python3
"""Freeze and validate optional dynamic-state and variation behavior.

This Batch 8 contract is deliberately target-neutral. It plans semantics for
probability, inclusion groups, timed effects, matching sources, character/tag
filters, generation triggers, automation IDs, named outlets, and greeting-bound
variation. Exact SillyTavern-native field serialization belongs to Batch 9.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

from wb_common import (
    ErrorCollector,
    WorldBuilderError,
    atomic_write_json,
    canonical_entry_identity,
    iter_entries,
    load_build_state,
    load_json,
    preflight_report,
    requirement_rows,
    resolve_state_path,
    sha256_file,
    uid_key,
)

CONTRACT = "worldbuilder-dynamic-state-v1"
PLAN_KIND = "worldbuilder-dynamic-state-plan"
PLAN_VERSION = 1
RECEIPT_KIND = "worldbuilder-dynamic-state-gate"
RECEIPT_VERSION = 1
ENVELOPE_KEY = "worldbuilder_dynamic"

POLICIES = {"off", "review", "custom", "preserve"}
GROUP_SELECTIONS = {"weighted_random", "priority"}
MATCHING_SOURCES = {
    "chat",
    "character_description",
    "character_personality",
    "scenario",
    "persona_description",
    "character_note",
    "creator_notes",
}
GENERATION_TRIGGERS = {"normal", "continue", "impersonate", "swipe", "regenerate", "quiet"}
FILTER_MODES = {"include", "exclude"}
GREETING_SCOPES = {"primary", "alternate", "group_only"}
OPTIONAL_PURPOSES = {
    "flavor",
    "random_encounter",
    "ambient_event",
    "character_form",
    "scene_state",
    "late_story_event",
    "shared_lore_filter",
    "era_collision_guard",
    "greeting_variant",
    "user_authored_automation",
    "named_outlet",
}
ALWAYS_PROTECTED_LAYERS = {"world_index", "world_core", "world_invariants"}
TARGET_BOUNDARY = "semantic only; exact runtime serialization is deferred to Batch 9"
SAFETY_DEFAULTS = {
    "probability": 100,
    "timed_effects": {"sticky": 0, "cooldown": 0, "delay": 0},
    "random_group_selection": False,
    "automation": None,
    "outlet": None,
    "matching_sources": ["chat"],
    "character_filter": None,
    "generation_triggers": [],
}
PROTECTED_CATEGORIES = {
    "world_invariants",
    "era_isolation",
    "knowledge_boundary",
    "status_change",
    "identity_state",
    "required_relationship",
    "required_activation_path",
}


def _string_list(value: Any, field: str, *, allowed: set[str] | None = None) -> list[str]:
    if value is None:
        return []
    problems = ErrorCollector()
    if not isinstance(value, list):
        problems.add(f"{field} must be an array")
        problems.raise_if_any()
    result: list[str] = []
    seen: set[str] = set()
    bad_reported = False
    reported: set[str] = set()
    for item in value:
        if not isinstance(item, str) or not item.strip():
            if not bad_reported:
                problems.add(f"{field} must contain non-empty strings")
                bad_reported = True
            continue
        cleaned = item.strip()
        normalized = cleaned.casefold().replace(" ", "_").replace("'", "")
        if allowed is not None and normalized not in allowed:
            if cleaned not in reported:
                problems.add(f"{field} contains unsupported value {cleaned!r}")
                reported.add(cleaned)
            continue
        if normalized in seen:
            if normalized not in reported:
                problems.add(f"{field} contains duplicate value {cleaned!r}")
                reported.add(normalized)
            continue
        seen.add(normalized)
        result.append(normalized if allowed is not None else cleaned)
    problems.raise_if_any()
    return result


def _nonnegative_int(value: Any, field: str) -> int:
    if not isinstance(value, int) or isinstance(value, bool) or value < 0:
        raise WorldBuilderError(f"{field} must be a non-negative integer")
    return value


def _probability(value: Any) -> int:
    if not isinstance(value, int) or isinstance(value, bool) or not 0 <= value <= 100:
        raise WorldBuilderError("probability must be an integer from 0 to 100")
    return value


def _normalize_entry_policy(uid: str, raw: Any) -> dict[str, Any]:
    problems = ErrorCollector()
    if not isinstance(raw, dict):
        problems.add(f"dynamic entry policy {uid} must be an object")
        problems.raise_if_any()
    purpose = str(raw.get("purpose", "")).strip().casefold().replace(" ", "_")
    if not purpose:
        problems.add(f"dynamic entry policy {uid} requires purpose")
    elif purpose not in OPTIONAL_PURPOSES:
        problems.add(f"dynamic entry policy {uid} has unsupported purpose {purpose!r}")
    probability = None
    try:
        probability = _probability(raw.get("probability", 100))
    except WorldBuilderError as exc:
        problems.add(str(exc))
    probability_enabled = raw.get("probability_enabled", True if probability is None else probability != 100)
    if probability is not None and not isinstance(probability_enabled, bool):
        problems.add(f"entry {uid} probability_enabled must be boolean")
    sticky = 0
    try:
        sticky = _nonnegative_int(raw.get("sticky", 0), f"entry {uid} sticky")
    except WorldBuilderError as exc:
        problems.add(str(exc))
    cooldown = 0
    try:
        cooldown = _nonnegative_int(raw.get("cooldown", 0), f"entry {uid} cooldown")
    except WorldBuilderError as exc:
        problems.add(str(exc))
    # Batch 9: delay is the ONLY one of these three timed_effects with a
    # decorator-emission path (@@activate_only_after): sticky and
    # cooldown have no CCv3 decorator equivalent and stay extensions-only
    # on every target, portable or native. On the portable path,
    # runtime_target_adapter.py's _ccv3_entry pops delay out before it
    # would reach extensions.delay and expresses it as a decorator
    # instead (single-owner rule; never both). This file only validates
    # the value's own shape (a non-negative integer needs no further
    # normalization the way placement_contract.py's numeric role
    # shorthand did); ownership of which FORM it takes downstream is
    # resolved entirely at the emission layer, not here.
    delay = 0
    try:
        delay = _nonnegative_int(raw.get("delay", 0), f"entry {uid} delay")
    except WorldBuilderError as exc:
        problems.add(str(exc))
    sources = None
    try:
        sources = _string_list(raw.get("matching_sources", ["chat"]), f"entry {uid} matching_sources", allowed=MATCHING_SOURCES)
    except WorldBuilderError as exc:
        problems.add(str(exc))
    if sources is not None and "chat" not in sources:
        sources.insert(0, "chat")
    triggers = None
    try:
        triggers = _string_list(raw.get("generation_triggers", []), f"entry {uid} generation_triggers", allowed=GENERATION_TRIGGERS)
    except WorldBuilderError as exc:
        problems.add(str(exc))
    groups = None
    try:
        groups = _string_list(raw.get("groups", []), f"entry {uid} groups")
    except WorldBuilderError as exc:
        problems.add(str(exc))
    weights = raw.get("group_weights", {})
    normalized_weights: dict[str, int] = {}
    if not isinstance(weights, dict):
        problems.add(f"entry {uid} group_weights must be an object")
    else:
        for name, weight in weights.items():
            if not isinstance(name, str) or not name.strip():
                problems.add(f"entry {uid} group_weights requires non-empty group names")
                continue
            if not isinstance(weight, int) or isinstance(weight, bool) or weight <= 0:
                problems.add(f"entry {uid} group weight for {name!r} must be a positive integer")
                continue
            normalized_weights[name.strip()] = weight
    if groups is not None and set(normalized_weights) - set(groups):
        problems.add(f"entry {uid} defines a weight for a group it does not join")
    char_filter = raw.get("character_filter")
    normalized_filter = None
    if char_filter is not None:
        filter_ok = True
        if not isinstance(char_filter, dict):
            problems.add(f"entry {uid} character_filter must be an object or null")
            filter_ok = False
        else:
            mode = str(char_filter.get("mode", "include")).strip().casefold()
            if mode not in FILTER_MODES:
                problems.add(f"entry {uid} character_filter mode must be include or exclude")
                filter_ok = False
            names = None
            try:
                names = _string_list(char_filter.get("names", []), f"entry {uid} character_filter.names")
            except WorldBuilderError as exc:
                problems.add(str(exc))
                filter_ok = False
            tags = None
            try:
                tags = _string_list(char_filter.get("tags", []), f"entry {uid} character_filter.tags")
            except WorldBuilderError as exc:
                problems.add(str(exc))
                filter_ok = False
            if names is not None and tags is not None and not names and not tags:
                problems.add(f"entry {uid} character_filter requires at least one name or tag")
                filter_ok = False
            runtime_character_ids = char_filter.get("runtime_character_ids", False)
            runtime_tag_ids = char_filter.get("runtime_tag_ids", False)
            if not isinstance(runtime_character_ids, bool) or not isinstance(runtime_tag_ids, bool):
                problems.add(f"entry {uid} character_filter runtime ID markers must be boolean")
                filter_ok = False
            if filter_ok:
                normalized_filter = {
                    "mode": mode,
                    "names": names,
                    "tags": tags,
                    "runtime_character_ids": runtime_character_ids,
                    "runtime_tag_ids": runtime_tag_ids,
                }
    automation_id = raw.get("automation_id")
    if automation_id is not None:
        if not isinstance(automation_id, str) or not automation_id.strip():
            problems.add(f"entry {uid} automation_id must be a non-empty string or null")
        else:
            automation_id = automation_id.strip()
    outlet = raw.get("outlet")
    if outlet is not None:
        if not isinstance(outlet, str) or not outlet.strip() or outlet != outlet.strip():
            problems.add(f"entry {uid} outlet must be a whitespace-exact non-empty name")
    problems.raise_if_any()
    return {
        "purpose": purpose,
        "probability": probability,
        "probability_enabled": probability_enabled,
        "groups": groups,
        "group_weights": normalized_weights,
        "sticky": sticky,
        "cooldown": cooldown,
        "delay": delay,
        "matching_sources": sources,
        "character_filter": normalized_filter,
        "generation_triggers": triggers,
        "automation_id": automation_id,
        "outlet": outlet,
    }


def _normalize_group(group_id: str, raw: Any) -> dict[str, Any]:
    problems = ErrorCollector()
    if not isinstance(raw, dict):
        problems.add(f"dynamic group {group_id} must be an object")
        problems.raise_if_any()
    if not group_id.strip() or group_id != group_id.strip():
        problems.add("dynamic group names must be whitespace-exact non-empty strings")
    selection = str(raw.get("selection", "weighted_random")).strip().casefold().replace("-", "_")
    if selection not in GROUP_SELECTIONS:
        problems.add(f"dynamic group {group_id} selection must be weighted_random or priority")
    members_raw = raw.get("members")
    members: list[str] = []
    if not isinstance(members_raw, list) or len(members_raw) < 2:
        problems.add(f"dynamic group {group_id} requires at least two members")
    else:
        seen_members: set[str] = set()
        repeated: set[str] = set()
        for value in members_raw:
            try:
                member = uid_key(value)
            except WorldBuilderError as exc:
                problems.add(str(exc))
                continue
            if member in seen_members:
                if member not in repeated:
                    problems.add(f"dynamic group {group_id} repeats a member UID")
                    repeated.add(member)
                continue
            seen_members.add(member)
            members.append(member)
    reason = str(raw.get("reason", "")).strip()
    if not reason:
        problems.add(f"dynamic group {group_id} requires a reason")
    problems.raise_if_any()
    return {
        "group_id": group_id,
        "selection": selection,
        "group_scoring": bool(raw.get("group_scoring", False)),
        "members": members,
        "reason": reason,
    }


def _normalize_registry(value: Any, kind: str) -> dict[str, dict[str, Any]]:
    if value is None:
        return {}
    problems = ErrorCollector()
    if not isinstance(value, dict):
        problems.add(f"{kind} registry must be an object")
        problems.raise_if_any()
    result: dict[str, dict[str, Any]] = {}
    for key, raw in value.items():
        if not isinstance(key, str) or not key.strip() or key != key.strip():
            problems.add(f"{kind} registry names must be whitespace-exact non-empty strings")
            continue
        if not isinstance(raw, dict):
            problems.add(f"{kind} registry entry {key!r} must be an object")
            continue
        approved = raw.get("approved") is True
        reason = str(raw.get("reason", "")).strip()
        if not approved or not reason:
            problems.add(f"{kind} registry entry {key!r} requires approved=true and a reason")
            continue
        row = {"approved": True, "reason": reason}
        if kind == "automation":
            if raw.get("explicit_user_intent") is not True:
                problems.add(f"automation {key!r} requires explicit_user_intent=true")
                continue
            action = str(raw.get("action", "")).strip()
            if not action:
                problems.add(f"automation {key!r} requires an action")
                continue
            row.update({"explicit_user_intent": True, "action": action})
        else:
            if raw.get("macro_capable") is not True:
                problems.add(f"outlet consumer {key!r} requires macro_capable=true")
                continue
            row["macro_capable"] = True
        result[key] = row
    problems.raise_if_any()
    return result


def _normalize_greetings(value: Any) -> list[dict[str, Any]]:
    if value is None:
        return []
    problems = ErrorCollector()
    if not isinstance(value, list):
        problems.add("greeting_variants must be an array")
        problems.raise_if_any()
    result: list[dict[str, Any]] = []
    for index, raw in enumerate(value, start=1):
        if not isinstance(raw, dict):
            problems.add(f"greeting variant {index} must be an object")
            continue
        scope = str(raw.get("scope", "")).strip().casefold().replace("-", "_")
        if scope not in GREETING_SCOPES:
            problems.add(f"greeting variant {index} has unsupported scope")
        uids_raw = raw.get("entry_uids")
        uids: list[str] = []
        if not isinstance(uids_raw, list) or not uids_raw:
            problems.add(f"greeting variant {index} requires entry_uids")
        else:
            seen_uids: set[str] = set()
            repeated: set[str] = set()
            for item in uids_raw:
                try:
                    member = uid_key(item)
                except WorldBuilderError as exc:
                    problems.add(str(exc))
                    continue
                if member in seen_uids:
                    if member not in repeated:
                        problems.add(f"greeting variant {index} repeats an entry UID")
                        repeated.add(member)
                    continue
                seen_uids.add(member)
                uids.append(member)
        group = raw.get("inclusion_group")
        if group is not None and (not isinstance(group, str) or not group.strip()):
            problems.add(f"greeting variant {index} inclusion_group must be a non-empty string or null")
        result.append({
            "variant_id": str(raw.get("variant_id", f"greeting-{index}")).strip() or f"greeting-{index}",
            "scope": scope,
            "entry_uids": uids,
            "inclusion_group": group.strip() if isinstance(group, str) else None,
        })
    problems.raise_if_any()
    return result


def build_plan(
    *,
    build_id: str,
    artifact_type: str,
    schema: int | str,
    policy: str = "off",
    interface_mode: str = "simple",
    custom_overrides: dict[str, Any] | None = None,
) -> dict[str, Any]:
    problems = ErrorCollector()
    policy = str(policy).strip().casefold()
    if policy not in POLICIES:
        problems.add("dynamic-state policy must be off, review, custom, or preserve")
    interface_mode = str(interface_mode).strip().casefold()
    if interface_mode not in {"simple", "advanced"}:
        problems.add("interface mode must be simple or advanced")
    overrides = custom_overrides or {}
    if not isinstance(overrides, dict):
        problems.add("dynamic-state overrides must be an object")
        problems.raise_if_any()
    if policy == "off" and overrides:
        problems.add("dynamic-state overrides require review, custom, or preserve policy")
    if interface_mode != "advanced" and (policy != "off" or overrides):
        problems.add("dynamic state and variation controls require Advanced Mode")
    entries_raw = overrides.get("entries", {})
    groups_raw = overrides.get("groups", {})
    if not isinstance(entries_raw, dict) or not isinstance(groups_raw, dict):
        problems.add("dynamic-state entries and groups must be objects")
        problems.add("dependent checks skipped: per-entry, per-group, registry, and greeting normalization (entries/groups are not objects)")
        problems.raise_if_any()
    entries: dict[str, dict[str, Any]] = {}
    for key, value in entries_raw.items():
        try:
            uid = uid_key(key)
        except WorldBuilderError as exc:
            problems.add(str(exc))
            continue
        try:
            entries[uid] = _normalize_entry_policy(uid, value)
        except WorldBuilderError as exc:
            problems.add(str(exc))
    groups: dict[str, dict[str, Any]] = {}
    for name, raw in groups_raw.items():
        try:
            groups[name] = _normalize_group(name, raw)
        except WorldBuilderError as exc:
            problems.add(str(exc))
    automation: dict[str, dict[str, Any]] = {}
    try:
        automation = _normalize_registry(overrides.get("automation_registry"), "automation")
    except WorldBuilderError as exc:
        problems.add(str(exc))
    outlets: dict[str, dict[str, Any]] = {}
    try:
        outlets = _normalize_registry(overrides.get("outlet_consumers"), "outlet")
    except WorldBuilderError as exc:
        problems.add(str(exc))
    greetings: list[dict[str, Any]] = []
    try:
        greetings = _normalize_greetings(overrides.get("greeting_variants"))
    except WorldBuilderError as exc:
        problems.add(str(exc))
    lore_bearing = artifact_type in {"world", "lorebook", "group"} or schema in {2, 3}
    problems.raise_if_any()
    plan = {
        "kind": PLAN_KIND,
        "plan_version": PLAN_VERSION,
        "contract": CONTRACT,
        "build_id": build_id,
        "applicable": bool(lore_bearing),
        "artifact_type": artifact_type,
        "schema": schema,
        "policy": policy,
        "interface_mode": interface_mode,
        "safety_defaults": SAFETY_DEFAULTS,
        "protected_categories": sorted(PROTECTED_CATEGORIES),
        "entry_policies": entries,
        "groups": groups,
        "automation_registry": automation,
        "outlet_consumers": outlets,
        "greeting_variants": greetings,
        "target_boundary": TARGET_BOUNDARY,
    }
    validate_plan(plan, expected_build_id=build_id)
    return plan


def validate_plan(plan: Any, *, expected_build_id: str | None = None) -> None:
    problems = ErrorCollector()
    if not isinstance(plan, dict) or plan.get("kind") != PLAN_KIND or plan.get("plan_version") != PLAN_VERSION:
        problems.add("dynamic-state plan has the wrong kind/version")
        problems.raise_if_any()
    if plan.get("contract") != CONTRACT:
        problems.add(f"dynamic-state plan contract must be {CONTRACT}")
    if expected_build_id is not None and plan.get("build_id") != expected_build_id:
        problems.add("dynamic-state plan belongs to another build")
    if plan.get("policy") not in POLICIES:
        problems.add("dynamic-state plan policy is invalid")
    if plan.get("interface_mode") not in {"simple", "advanced"}:
        problems.add("dynamic-state plan interface_mode is invalid")
    if plan.get("interface_mode") == "simple" and plan.get("policy") != "off":
        problems.add("Simple Mode cannot expose dynamic-state controls")
    if plan.get("safety_defaults") != SAFETY_DEFAULTS:
        problems.add("dynamic-state safety defaults are missing or non-canonical")
    if plan.get("protected_categories") != sorted(PROTECTED_CATEGORIES):
        problems.add("dynamic-state protected categories are missing or non-canonical")
    if plan.get("target_boundary") != TARGET_BOUNDARY:
        problems.add("dynamic-state target boundary is missing or non-canonical")
    entries = plan.get("entry_policies")
    groups = plan.get("groups")
    if not isinstance(entries, dict) or not isinstance(groups, dict):
        problems.add("dynamic-state plan entries/groups are invalid")
        problems.add("dependent checks skipped: per-entry and per-group canonicality checks (entries/groups are not objects)")
    else:
        for uid, row in entries.items():
            try:
                canonical_entry = _normalize_entry_policy(uid_key(uid), row)
            except WorldBuilderError as exc:
                problems.add(str(exc))
                continue
            if canonical_entry != row:
                problems.add(f"dynamic entry policy {uid} is not canonical")
        for name, row in groups.items():
            try:
                canonical_group = _normalize_group(name, row)
            except WorldBuilderError as exc:
                problems.add(str(exc))
                continue
            if canonical_group != row:
                problems.add(f"dynamic group {name} is not canonical")
    automation_registry = None
    try:
        automation_registry = _normalize_registry(plan.get("automation_registry"), "automation")
    except WorldBuilderError as exc:
        problems.add(str(exc))
    if automation_registry is not None and automation_registry != plan.get("automation_registry"):
        problems.add("automation registry is not canonical")
    outlets = None
    try:
        outlets = _normalize_registry(plan.get("outlet_consumers"), "outlet")
    except WorldBuilderError as exc:
        problems.add(str(exc))
    if outlets is not None and outlets != plan.get("outlet_consumers"):
        problems.add("outlet consumer registry is not canonical")
    greetings = None
    try:
        greetings = _normalize_greetings(plan.get("greeting_variants"))
    except WorldBuilderError as exc:
        problems.add(str(exc))
    if greetings is not None and greetings != plan.get("greeting_variants"):
        problems.add("greeting variants are not canonical")
    if isinstance(entries, dict) and isinstance(groups, dict) and plan.get("policy") == "off" and any(
        (entries, groups, plan.get("automation_registry"), plan.get("outlet_consumers"), plan.get("greeting_variants"))
    ):
        problems.add("off dynamic-state plan cannot contain active operations")
    problems.raise_if_any()


def load_bound_plan(root: Path, state: dict[str, Any], manifest: dict[str, Any], *, required: bool = False) -> tuple[dict[str, Any] | None, Path | None]:
    problems = ErrorCollector()
    path = resolve_state_path(root, state, "dynamic_state_plan", required=False)
    expected = manifest.get("dynamic_state_plan_sha256")
    architecture = manifest.get("architecture") if isinstance(manifest.get("architecture"), dict) else {}
    binding = architecture.get("dynamic_state") if isinstance(architecture.get("dynamic_state"), dict) else None
    bound = isinstance(expected, str) and isinstance(binding, dict)
    if not bound:
        if required:
            problems.add("manifest is not bound to the frozen dynamic-state plan")
            problems.raise_if_any()
        return None, path if path and path.exists() else None
    if path is None or not path.exists():
        problems.add("dynamic-state plan is missing")
        problems.raise_if_any()
    plan = load_json(path)
    try:
        validate_plan(plan, expected_build_id=str(state.get("build_id", "")))
    except WorldBuilderError as exc:
        problems.add(str(exc))
    if expected != sha256_file(path):
        problems.add("manifest dynamic-state plan hash is stale")
    if binding.get("contract") != CONTRACT or binding.get("plan_sha256") != expected:
        problems.add("manifest architecture.dynamic_state binding is missing or stale")
    state_dynamic = state.get("dynamic_state") if isinstance(state.get("dynamic_state"), dict) else {}
    if state_dynamic.get("contract") not in {None, CONTRACT}:
        problems.add("build-state dynamic-state contract is unsupported")
    if state_dynamic.get("plan_sha256") not in {None, expected}:
        problems.add("build-state dynamic-state plan hash is stale")
    if state_dynamic.get("policy") not in {None, plan.get("policy") if isinstance(plan, dict) else None}:
        problems.add("build-state dynamic-state policy disagrees with the frozen plan")
    problems.raise_if_any()
    return plan, path


def _manifest_rows(manifest: dict[str, Any]) -> tuple[dict[str, dict[str, Any]], dict[str, int]]:
    problems = ErrorCollector()
    entries = manifest.get("entries")
    if not isinstance(entries, list) or not entries:
        problems.add("dynamic-state validation requires non-empty manifest entries")
        problems.raise_if_any()
    rows: dict[str, dict[str, Any]] = {}
    orders: dict[str, int] = {}
    for entry in entries:
        if not isinstance(entry, dict):
            problems.add("manifest entries must be objects")
            continue
        try:
            uid = uid_key(entry.get("uid", entry.get("id")))
        except WorldBuilderError as exc:
            problems.add(str(exc))
            continue
        if uid in rows:
            problems.add(f"manifest repeats UID {uid}")
            continue
        rows[uid] = entry
        emit = entry.get("emit") if isinstance(entry.get("emit"), dict) else {}
        order = emit.get("insertion_order", emit.get("order", 100))
        if not isinstance(order, int) or isinstance(order, bool):
            order = 100
        orders[uid] = order
    problems.raise_if_any()
    return rows, orders


def _protected(entry: dict[str, Any], required_edge_uids: set[str]) -> tuple[bool, list[str]]:
    uid = uid_key(entry.get("uid", entry.get("id")))
    arch = entry.get("architecture") if isinstance(entry.get("architecture"), dict) else {}
    layer = str(arch.get("layer", "")).strip()
    emit = entry.get("emit") if isinstance(entry.get("emit"), dict) else {}
    reasons: list[str] = []
    if bool(emit.get("constant")):
        reasons.append("constant")
    if layer in ALWAYS_PROTECTED_LAYERS:
        reasons.append(layer)
    dyn = arch.get("dynamic") if isinstance(arch.get("dynamic"), dict) else {}
    if dyn.get("protected") is True:
        reasons.append("architecture.dynamic.protected")
    budget = arch.get("budget") if isinstance(arch.get("budget"), dict) else {}
    categories = budget.get("protected_categories", [])
    if isinstance(categories, list):
        reasons.extend(sorted({str(item) for item in categories if str(item) in PROTECTED_CATEGORIES}))
    if uid in required_edge_uids:
        reasons.append("required_activation_path")
    return bool(reasons), reasons


def analyze_manifest(plan: dict[str, Any], manifest: dict[str, Any]) -> dict[str, Any]:
    problems = ErrorCollector()
    try:
        validate_plan(plan, expected_build_id=str(manifest.get("build_id", "")))
    except WorldBuilderError as exc:
        problems.add(str(exc))
        problems.add("dependent checks skipped: manifest analysis (the dynamic-state plan is invalid)")
        problems.raise_if_any()
    rows: dict[str, dict[str, Any]] = {}
    orders: dict[str, int] = {}
    try:
        rows, orders = _manifest_rows(manifest)
    except WorldBuilderError as exc:
        problems.add(str(exc))
    if not rows:
        problems.add("dependent checks skipped: manifest analysis (no usable manifest entries)")
        problems.raise_if_any()
    graph = manifest.get("activation_graph") if isinstance(manifest.get("activation_graph"), dict) else {}
    required_edge_uids: set[str] = set()
    for edge in graph.get("edges", []) if isinstance(graph.get("edges"), list) else []:
        if isinstance(edge, dict) and edge.get("required") is True:
            required_edge_uids.add(uid_key(edge.get("source_uid")))
            required_edge_uids.add(uid_key(edge.get("target_uid")))
    policies = plan.get("entry_policies", {})
    unknown = sorted(set(policies) - set(rows))
    if unknown:
        problems.add("dynamic-state plan references unknown UIDs: " + ", ".join(unknown))
    groups = plan.get("groups", {})
    for name, group in groups.items():
        unknown_members = sorted(set(group["members"]) - set(rows))
        if unknown_members:
            problems.add(f"dynamic group {name} references unknown UIDs: {', '.join(unknown_members)}")
        for uid in group["members"]:
            policy = policies.get(uid)
            if not isinstance(policy, dict) or name not in policy.get("groups", []):
                problems.add(f"dynamic group {name} member {uid} lacks matching entry membership")
        if group["selection"] == "priority":
            group_orders = [orders[uid] for uid in group["members"] if uid in orders]
            if len(set(group_orders)) != len(group_orders):
                problems.add(f"priority dynamic group {name} requires distinct insertion orders")
    for uid, policy in policies.items():
        unknown_groups = sorted(set(policy["groups"]) - set(groups))
        if unknown_groups:
            problems.add(f"entry {uid} references unknown dynamic groups: {', '.join(unknown_groups)}")
    automation_registry = plan.get("automation_registry", {})
    outlet_registry = plan.get("outlet_consumers", {})
    result_rows: list[dict[str, Any]] = []
    warnings: list[str] = []
    for uid, entry in rows.items():
        policy = policies.get(uid)
        is_protected, protection_reasons = _protected(entry, required_edge_uids)
        arch = entry.get("architecture") if isinstance(entry.get("architecture"), dict) else {}
        layer = str(arch.get("layer", "")).strip()
        if policy is None:
            sources = ["chat", "scenario"] if layer == "era_context" else ["chat"]
            resolved = {
                "uid": entry.get("uid", entry.get("id")),
                "name": str(entry.get("name", "")).strip(),
                "layer": layer,
                "protected": is_protected,
                "protection_reasons": protection_reasons,
                "purpose": None,
                "probability": 100,
                "probability_enabled": False,
                "groups": [],
                "group_weights": {},
                "sticky": 0,
                "cooldown": 0,
                "delay": 0,
                "matching_sources": sources,
                "character_filter": None,
                "generation_triggers": [],
                "automation_id": None,
                "outlet": None,
                "dynamic": False,
            }
        else:
            resolved = {"uid": entry.get("uid", entry.get("id")), "name": str(entry.get("name", "")).strip(), "layer": layer,
                        "protected": is_protected, "protection_reasons": protection_reasons, **policy, "dynamic": True}
            if policy["probability"] < 100 and is_protected:
                problems.add(f"protected entry {uid} cannot use probability filtering")
            if any(policy[key] > 0 for key in ("sticky", "cooldown", "delay")) and is_protected:
                problems.add(f"protected entry {uid} cannot use timed effects")
            if policy["character_filter"] is not None and is_protected:
                problems.add(f"protected entry {uid} cannot use a character/tag filter")
            if policy["generation_triggers"] and is_protected:
                problems.add(f"protected entry {uid} cannot restrict generation triggers")
            if (
                str(plan.get("artifact_type", "")).strip().casefold() in {"group", "group_chat", "group-chat"}
                and "regenerate" in policy["generation_triggers"]
            ):
                problems.add(
                    f"entry {uid} cannot use the Regenerate trigger in a group build"
                )
            for group_name in policy["groups"]:
                group = groups.get(group_name)
                if not isinstance(group, dict):
                    continue
                if is_protected and group["selection"] == "weighted_random":
                    problems.add(f"protected entry {uid} cannot use random group selection")
                weight = policy["group_weights"].get(group_name, 100)
                if group["selection"] == "weighted_random" and weight <= 0:
                    problems.add(f"entry {uid} group {group_name} requires positive group weight")
            if policy["automation_id"] is not None and policy["automation_id"] not in automation_registry:
                problems.add(f"entry {uid} automation ID is not in the approved explicit-user-intent registry")
            if policy["outlet"] is not None and policy["outlet"] not in outlet_registry:
                problems.add(f"entry {uid} outlet has no approved macro-capable named consumer")
        if layer == "era_context" and "scenario" not in resolved["matching_sources"]:
            problems.add(f"Era Context entry {uid} must include Scenario as a matching source")
        result_rows.append(resolved)
    greeting_rows: list[dict[str, Any]] = []
    for row in plan.get("greeting_variants", []):
        unknown_uids = sorted(set(row["entry_uids"]) - set(rows))
        if unknown_uids:
            problems.add(f"greeting variant {row['variant_id']} references unknown UIDs: {', '.join(unknown_uids)}")
        group_name = row["inclusion_group"]
        if group_name is not None and group_name not in groups:
            problems.add(f"greeting variant {row['variant_id']} references an unknown inclusion group")
        for uid in row["entry_uids"]:
            policy = policies.get(uid)
            if not isinstance(policy, dict) or policy.get("purpose") != "greeting_variant":
                problems.add(f"greeting variant {row['variant_id']} UID {uid} requires greeting_variant purpose")
            elif group_name is not None and group_name not in policy.get("groups", []):
                problems.add(f"greeting variant {row['variant_id']} UID {uid} must join inclusion group {group_name}")
        greeting_rows.append(row)
    problems.raise_if_any()
    return {
        "contract": CONTRACT,
        "policy": plan.get("policy"),
        "entry_count": len(result_rows),
        "dynamic_entry_count": sum(1 for row in result_rows if row["dynamic"]),
        "group_count": len(groups),
        "automation_count": len(automation_registry),
        "outlet_count": len(outlet_registry),
        "entries": result_rows,
        "groups": [groups[name] for name in sorted(groups)],
        "greeting_variants": greeting_rows,
        "warnings": warnings,
    }


def assignment_context(plan: dict[str, Any], detail: dict[str, Any], uids: list[Any]) -> dict[str, Any]:
    wanted = {uid_key(value) for value in uids}
    entries = [row for row in detail.get("entries", []) if uid_key(row.get("uid")) in wanted]
    selected_groups = [group for group in detail.get("groups", []) if any(uid in wanted for uid in group.get("members", []))]
    greetings = [row for row in detail.get("greeting_variants", []) if any(uid in wanted for uid in row.get("entry_uids", []))]
    automation_ids = {row.get("automation_id") for row in entries if row.get("automation_id")}
    outlets = {row.get("outlet") for row in entries if row.get("outlet")}
    return {
        "contract": CONTRACT,
        "policy": plan.get("policy"),
        "entries": entries,
        "groups": selected_groups,
        "greeting_variants": greetings,
        "automation_registry": {key: plan.get("automation_registry", {})[key] for key in sorted(automation_ids)},
        "outlet_consumers": {key: plan.get("outlet_consumers", {})[key] for key in sorted(outlets)},
        "target_boundary": plan.get("target_boundary"),
    }

def _entry_envelope(row: dict[str, Any]) -> dict[str, Any] | None:
    if not row.get("dynamic"):
        return None
    value: dict[str, Any] = {"contract": CONTRACT, "purpose": row.get("purpose")}
    if row.get("probability") != 100 or row.get("probability_enabled"):
        value["probability"] = row.get("probability")
        value["probability_enabled"] = bool(row.get("probability_enabled"))
    if row.get("groups"):
        value["groups"] = [
            {
                "group_id": name,
                "selection": None,
                "weight": row.get("group_weights", {}).get(name, 100),
            }
            for name in row.get("groups", [])
        ]
    timed = {key: row.get(key, 0) for key in ("sticky", "cooldown", "delay") if row.get(key, 0)}
    if timed:
        value["timed_effects"] = timed
    sources = row.get("matching_sources", ["chat"])
    if sources != ["chat"]:
        value["matching_sources"] = sources
    if row.get("character_filter") is not None:
        value["character_filter"] = row.get("character_filter")
    if row.get("generation_triggers"):
        value["generation_triggers"] = row.get("generation_triggers")
    if row.get("automation_id") is not None:
        value["automation_id"] = row.get("automation_id")
    if row.get("outlet") is not None:
        value["named_outlet"] = row.get("outlet")
    return value


def expected_envelopes(detail: dict[str, Any]) -> dict[str, dict[str, Any] | None]:
    groups = {group["group_id"]: group for group in detail.get("groups", [])}
    greetings_by_uid: dict[str, list[dict[str, Any]]] = {}
    for row in detail.get("greeting_variants", []):
        scope_row = {
            "variant_id": row["variant_id"],
            "scope": row["scope"],
            "inclusion_group": row.get("inclusion_group"),
        }
        for uid in row.get("entry_uids", []):
            greetings_by_uid.setdefault(uid, []).append(scope_row)
    result: dict[str, dict[str, Any] | None] = {}
    for row in detail.get("entries", []):
        uid = uid_key(row.get("uid"))
        envelope = _entry_envelope(row)
        if envelope and "groups" in envelope:
            for group_row in envelope["groups"]:
                group = groups[group_row["group_id"]]
                group_row["selection"] = group["selection"]
                group_row["group_scoring"] = group["group_scoring"]
        if uid in greetings_by_uid:
            if envelope is None:
                envelope = {"contract": CONTRACT, "purpose": "greeting_variant"}
            envelope["greeting_variants"] = sorted(greetings_by_uid[uid], key=lambda item: (item["scope"], item["variant_id"]))
        result[uid] = envelope
    return result

def validate_output(detail: dict[str, Any], output: dict[str, Any]) -> None:
    problems = ErrorCollector()
    expected = expected_envelopes(detail)
    observed: dict[str, dict[str, Any]] = {}
    for ref in iter_entries(output):
        identity = canonical_entry_identity(ref.entry)
        if identity is None:
            continue
        observed[uid_key(identity)] = ref.entry
    missing = sorted(set(expected) - set(observed))
    if missing:
        problems.add("dynamic-state output is missing planned UIDs: " + ", ".join(missing))
    for uid, expected_envelope in expected.items():
        entry = observed.get(uid)
        if entry is None:
            continue
        extensions = entry.get("extensions") if isinstance(entry.get("extensions"), dict) else {}
        actual = extensions.get(ENVELOPE_KEY)
        if actual != expected_envelope:
            problems.add(f"dynamic-state output drift for UID {uid}")
    problems.raise_if_any()


def validate(build_state: str, stage: str = "planning", *, write_receipt: bool = True) -> dict[str, Any]:
    problems = ErrorCollector()
    root, state = load_build_state(build_state)
    manifest_path = resolve_state_path(root, state, "manifest")
    manifest = load_json(manifest_path)
    if not isinstance(manifest, dict):
        problems.add("manifest must be an object")
        problems.raise_if_any()
    plan = None
    plan_path = None
    try:
        plan, plan_path = load_bound_plan(root, state, manifest, required=True)
    except WorldBuilderError as exc:
        problems.add(str(exc))
    if plan is None or plan_path is None:
        problems.add("dynamic-state plan is unavailable")
        problems.raise_if_any()
    detail = None
    try:
        detail = analyze_manifest(plan, manifest)
    except WorldBuilderError as exc:
        problems.add(str(exc))
    if detail is None:
        problems.add("dependent checks skipped: receipt generation (the manifest analysis failed)")
        problems.raise_if_any()
    result = {
        "kind": RECEIPT_KIND,
        "receipt_version": RECEIPT_VERSION,
        "contract": CONTRACT,
        "status": "passed",
        "stage": stage,
        "build_id": state.get("build_id"),
        "manifest_sha256": sha256_file(manifest_path),
        "dynamic_state_plan_sha256": sha256_file(plan_path),
        "policy": detail["policy"],
        "entry_count": detail["entry_count"],
        "dynamic_entry_count": detail["dynamic_entry_count"],
        "group_count": detail["group_count"],
        "automation_count": detail["automation_count"],
        "outlet_count": detail["outlet_count"],
        "warnings": detail["warnings"],
    }
    if stage == "output":
        final_path = resolve_state_path(root, state, "final_output")
        if not final_path.exists():
            problems.add("final output is missing")
        else:
            output = load_json(final_path)
            if not isinstance(output, dict):
                problems.add("final output must be a JSON object")
            else:
                try:
                    validate_output(detail, output)
                except WorldBuilderError as exc:
                    problems.add(str(exc))
        problems.raise_if_any()
        result["output"] = str(final_path.relative_to(root)).replace("\\", "/")
        result["output_sha256"] = sha256_file(final_path)
        receipt_key = "dynamic_state_output_receipt"
    elif stage == "planning":
        receipt_key = "dynamic_state_planning_receipt"
    else:
        problems.add("dynamic-state stage must be planning or output")
    problems.raise_if_any()
    if write_receipt:
        receipt_path = resolve_state_path(root, state, receipt_key)
        atomic_write_json(receipt_path, result)
        state.setdefault("lineage", {})[receipt_key + "_sha256"] = sha256_file(receipt_path)
        state["lineage"]["dynamic_state_plan_sha256"] = sha256_file(plan_path)
        state.setdefault("status", {})["dynamic_state_" + stage] = "complete"
        atomic_write_json(Path(build_state).resolve(), state)
        result["receipt"] = str(receipt_path)
    return result


def configure(build_state: str, overrides_path: str, policy: str) -> dict[str, Any]:
    root, state = load_build_state(build_state)
    interface = state.get("interface") if isinstance(state.get("interface"), dict) else {}
    if interface.get("mode") != "advanced":
        raise WorldBuilderError("dynamic-state configuration requires Advanced Mode")
    overrides = load_json(Path(overrides_path).expanduser().resolve())
    if not isinstance(overrides, dict):
        raise WorldBuilderError("dynamic-state override file must contain an object")
    artifact = state.get("artifact") if isinstance(state.get("artifact"), dict) else {}
    plan = build_plan(
        build_id=str(state.get("build_id", "")),
        artifact_type=str(artifact.get("type", "")),
        schema=artifact.get("schema", "auto"),
        policy=policy,
        interface_mode="advanced",
        custom_overrides=overrides,
    )
    path = resolve_state_path(root, state, "dynamic_state_plan")
    atomic_write_json(path, plan)
    digest = sha256_file(path)
    state["dynamic_state"] = {
        "contract": CONTRACT,
        "plan_sha256": digest,
        "policy": policy,
        "applicable": plan["applicable"],
    }
    state.setdefault("content_architecture", {})["dynamic_state_contract"] = CONTRACT
    state["content_architecture"]["dynamic_state_plan_sha256"] = digest
    state.setdefault("lineage", {}).pop("dynamic_state_planning_receipt_sha256", None)
    state["lineage"].pop("dynamic_state_output_receipt_sha256", None)
    state.setdefault("status", {})["planning"] = "pending"
    state["status"]["dynamic_state_planning"] = "pending"
    state["status"]["dynamic_state_output"] = "pending"
    atomic_write_json(Path(build_state).resolve(), state)
    return {"status": "configured", "plan": str(path), "dynamic_state_plan_sha256": digest, "policy": policy}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--build-state", required=True)
    parser.add_argument("--stage", choices=["planning", "output"], default="planning")
    parser.add_argument("--configure", help="JSON overrides file to freeze after UIDs are planned")
    parser.add_argument("--policy", choices=sorted(POLICIES), default="custom")
    parser.add_argument("--no-write-receipt", action="store_true")
    parser.add_argument("--requirements", action="store_true", help="Read-only preflight: print what this gate checks against the current build state.")
    args = parser.parse_args()
    if args.requirements:
        root, state = load_build_state(args.build_state)
        print(json.dumps(preflight_report("dynamic_state_contract", requirement_rows(Path(__file__), root, state)), ensure_ascii=False, indent=2))
        return 0
    try:
        if args.configure:
            result = configure(args.build_state, args.configure, args.policy)
        else:
            result = validate(args.build_state, args.stage, write_receipt=not args.no_write_receipt)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (WorldBuilderError, OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"DYNAMIC STATE GATE BLOCKED: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
