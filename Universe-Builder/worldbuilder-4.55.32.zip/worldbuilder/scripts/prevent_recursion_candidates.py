#!/usr/bin/env python3
"""Detect safe prevent_recursion candidates among a book's foundational entries.

The criterion codified here was derived from a real delivered 390-entry book (see
`references/activation-hygiene.md`): a runaway activation cascade is
usually not caused by one or two hub entries, but by a distributed pattern of
foundational, widely-referenced entries (locations, species, factions, broad setting
concepts, rules, worlds) whose content each seeds a modest amount of further recursion.
Those entries are meant to be referenced everywhere; they rarely need to recursively
seed more content. Character, event, and item entries are deliberately excluded, since
those are the types most likely to legitimately need to keep recursing.

Two entry points. `find_prevent_recursion_candidates(entries, in_degree)` flags
candidates from real downstream counts supplied by the caller (for example from
ground_truth_graph.py or from `compute_downstream_counts` here, which measures the
counts with the real activation mechanics per single-root scenario). This is a
detector, not a fixer: it reports entries for review and never edits the book.
"""
from __future__ import annotations

import argparse
import copy
import json
import re
import sys
from pathlib import Path
from typing import Any

import st_activation_scanner as S

# Semantic types confirmed, empirically, to be safe prevent_recursion candidates
# when also high in-degree. Character/Event/Item are deliberately excluded.
FOUNDATIONAL_TYPES = {"LOCATION", "SPECIES", "FACTION", "CONCEPT", "WORLD", "RULE"}

# Confirmed floor from the real contributors found (4 to 15 range).
MIN_IN_DEGREE_FOR_CANDIDACY = 4

# Era-cascade chain roles whose design forbids a prevent_recursion cap: a capped
# root, context, or state entry could not pass its token or content down the cascade
# (era_root_contract.py flags exactly this). Detail-level entries stay cappable.
PROTECTED_CASCADE_ROLES = ("root", "context", "state")

REPORT_KIND = "worldbuilder-prevent-recursion-candidates"
REPORT_VERSION = 1

# Batch 64 (incoming workplan "Batch 57", Part 1): the character-cascade keywording
# rule. Batch 55 deliberately excluded Character entries from prevent_recursion
# candidacy; this is a different, narrower correction for the same cascade. A high
# in-degree character whose only keys are its bare single-word name rides entirely
# on name-drops inside other entries' prose, so it needs a distinctive multi-word
# key (a title, epithet, or fuller name) before recursion may reach it.
CASCADE_RISK_CHARACTER_TYPES = {"CHARACTER"}
BARE_NAME_RECURSION_KIND = "worldbuilder-bare-name-recursion-report"
# Rule 2 from the same investigation (split a high in-degree character into a full
# direct entry plus a short recursive echo) is deliberately NOT implemented. Its
# measured gain (~120k -> ~64k tokens) landed close to the user's own
# already-truncated 63k figure, so it was not distinguishable from what
# SillyTavern's budget cap already does on its own. It stays a flagged direction
# that needs a real test against the real budget-cap truncation before adoption.


def book_entries(data: Any) -> list[dict[str, Any]]:
    """Entries from a delivered book (card or merged shape), else an empty list."""
    if not isinstance(data, dict):
        return []
    entries = (((data.get("data") or {}).get("character_book") or {}).get("entries"))
    return entries if isinstance(entries, list) else []


def find_prevent_recursion_candidates(
    entries: list[dict[str, Any]],
    in_degree: dict[str, int],
    *,
    exclude_uids: set[str] | None = None,
) -> list[dict[str, Any]]:
    """Real entries, from a real book, that are safe, high-value candidates for
    prevent_recursion. Flagged for review, not auto-applied, matching this codebase's
    own established detector-not-fixer discipline. Requires real in-degree counts
    (for example from ground_truth_graph.py or from `compute_downstream_counts`)
    as input rather than computing them itself, since a genuinely accurate count
    depends on the real activation mechanics, not a simplified approximation.
    `exclude_uids` names entries a caller's design protects; the era cascade's
    root, context, and state roles belong there, since capping them would stop
    their content from reaching the next cascade level."""
    blocked = {str(uid) for uid in exclude_uids or ()}
    candidates: list[dict[str, Any]] = []
    for entry in entries:
        uid = str(entry.get("uid") or entry.get("id"))
        if uid in blocked:
            continue
        label = str(entry.get("comment") or entry.get("name") or "")
        m = re.match(r"([A-Za-z][A-Za-z ]*?):\s", label)
        entry_type = m.group(1).strip().upper() if m else None
        if entry_type not in FOUNDATIONAL_TYPES:
            continue
        degree = in_degree.get(uid, 0)
        if degree < MIN_IN_DEGREE_FOR_CANDIDACY:
            continue
        already_set = bool((entry.get("extensions") or {}).get("prevent_recursion"))
        if already_set:
            continue
        candidates.append({
            "uid": uid,
            "label": label,
            "in_degree": degree,
            "type": entry_type,
        })
    candidates.sort(key=lambda c: -c["in_degree"])
    return candidates


def entry_label(entry: dict[str, Any]) -> str:
    """A real entry's visible label, from `comment` then `name`."""
    return str(entry.get("comment") or entry.get("name") or "")


def entry_type(label: str) -> str | None:
    """The semantic type prefix of a visible entry label (`PREFIX: Subject`)."""
    m = re.match(r"([A-Za-z][A-Za-z ]*?):\s", str(label))
    return m.group(1).strip().upper() if m else None


def find_cascade_keyword_risks(
    entries: list[dict[str, Any]],
    in_degree: dict[str, int],
    *,
    threshold: int = MIN_IN_DEGREE_FOR_CANDIDACY,
) -> list[dict[str, Any]]:
    """High in-degree CHARACTER entries whose only keys are bare single-word names.

    Extends Batch 55's own in-degree measurement past its foundational-type-only
    scope into the character case its investigation found: of the entries reached
    only through recursion, 44 fired purely because a bare single-word name
    appeared somewhere in another entry's content. A detector, not a fixer: it
    reports entries for review and never edits the book.
    """
    risks: list[dict[str, Any]] = []
    for entry in entries:
        uid = str(entry.get("uid") or entry.get("id"))
        label = str(entry.get("comment") or entry.get("name") or "")
        if entry_type(label) not in CASCADE_RISK_CHARACTER_TYPES:
            continue
        degree = in_degree.get(uid, 0)
        if degree < threshold:
            continue
        keys = [str(k) for k in (entry.get("key") or entry.get("keys") or [])]
        if not keys or [k for k in keys if len(k.split()) > 1]:
            continue
        risks.append({
            "uid": uid,
            "label": label,
            "in_degree": degree,
            "single_word_keys": [k for k in keys if len(k.split()) == 1],
        })
    risks.sort(key=lambda r: -r["in_degree"])
    return risks


def _plan_character_index(plan: Any) -> dict[str, dict[str, Any]]:
    """Casefolded name, alias, and title lookup over a character plan."""
    index: dict[str, dict[str, Any]] = {}
    for character in (plan or {}).get("characters") or []:
        if not isinstance(character, dict):
            continue
        names: list[Any] = [character.get("canonical_name")]
        names.extend(character.get("aliases") or [])
        names.extend(character.get("titles") or [])
        for name in names:
            text = str(name or "").strip()
            if text:
                index.setdefault(text.casefold(), character)
    return index


def plan_multi_word_keys(character: dict[str, Any]) -> list[str]:
    """Titles and aliases that satisfy Rule 1's distinctive multi-word key."""
    pool: list[str] = []
    pool.extend(str(name) for name in (character.get("titles") or []))
    pool.extend(str(name) for name in (character.get("aliases") or []))
    pool.append(str(character.get("canonical_name") or ""))
    return sorted({name for name in pool if len(name.split()) > 1})


def cascade_keyword_satisfiability(
    risks: list[dict[str, Any]],
    plan: Any,
) -> list[dict[str, Any]]:
    """Attach each flagged character's own qualifying keys, or mark it unsatisfiable.

    Rule 1 requires the distinctive multi-word key to come from the entry's own
    titles or aliases, and the audit contract forbids auto-rewriting keys, so a
    plan that holds no multi-word title or alias makes the finding unsatisfiable
    and the auditor must not then demand an invented key. This is latent hardening
    rather than a live defect: measured on a real 390-entry card, none of the
    flagged entries fired by recursion across ordinary probe messages. A missing
    plan record is reported as ``plan_record: False`` so an unsatisfiable finding
    stays distinguishable from a character the plan simply does not carry.
    """
    index = _plan_character_index(plan)
    for risk in risks:
        subject = str(risk.get("label") or "")
        if ":" in subject:
            subject = subject.split(":", 1)[1].strip()
        character = index.get(subject.casefold())
        if character is None:
            for key in risk.get("single_word_keys") or []:
                character = index.get(str(key).casefold())
                if character is not None:
                    break
        if character is None:
            risk["plan_record"] = False
            risk["qualifying_keys"] = []
            risk["satisfiable"] = False
            continue
        qualifying = plan_multi_word_keys(character)
        risk["plan_record"] = True
        risk["qualifying_keys"] = qualifying
        risk["satisfiable"] = bool(qualifying)
    return risks


def find_era_state_amplitudes(
    entries: list[dict[str, Any]],
    manifest: Any,
    in_degree: dict[str, int],
) -> list[dict[str, Any]]:
    """Era-cascade state entries: the measured amplifier, and not cappable.

    Measured on a real 390-entry multi-era card, capping the 59 state entries cut
    era fan-out from 594 to 361 across six single-root scenarios, while capping
    the 16 core_invariant entries changed nothing at all. The state layer is
    therefore what seeds the wider world out from an enabled era root. The era
    contract nevertheless forbids prevent_recursion on the state role, and
    FOUNDATIONAL_TYPES excludes CHARACTER, which left this class with no
    sanctioned report anywhere in the tooling. This reports it for visibility. It
    never proposes a cap, and every row carries ``cap_forbidden: True``.
    """
    roles: dict[str, str] = {}
    for row in (manifest or {}).get("entries") or []:
        if isinstance(row, dict):
            role = str((row.get("architecture") or {}).get("era_cascade_role") or "")
            if role:
                roles[str(row.get("uid"))] = role
    amplifiers: list[dict[str, Any]] = []
    for entry in entries:
        uid = str(entry.get("uid") or entry.get("id"))
        if roles.get(uid) != "state":
            continue
        amplifiers.append({
            "uid": uid,
            "label": entry_label(entry),
            "in_degree": in_degree.get(uid, 0),
            "era_cascade_role": "state",
            "cap_forbidden": True,
        })
    amplifiers.sort(key=lambda row: -row["in_degree"])
    return amplifiers


def scan_with_cascade_keyword_rule(
    rows: list[dict[str, Any]],
    message: str,
    *,
    bare_name_uids: set[str],
    depth: int = 8,
) -> dict[str, Any]:
    """Rule 1's semantics, measured with two real scans rather than asserted.

    A flagged high in-degree character keeps direct activation: an in-chat
    mention of its bare name is a deliberate reference. An activation reached
    only through another entry's content (recursion) no longer fires when the
    flagged entry carries no multi-word key that could have matched instead.
    """
    scan_entries = S.entries_from_dicts(rows)
    full = S.scan(scan_entries, message, recursive=True, max_recursion_steps=depth)
    # Direct activation is a real match against the chat message itself. A
    # `recursive=False` scan is not that test: the scanner still seeds constant
    # entries into the recurse buffer before its first round, so a constant
    # would make every name it contains look "direct".
    direct_uids = {
        entry.uid for entry in scan_entries
        if not entry.disable and S.entry_matches(entry, message)
    }
    blocked = sorted(
        uid for uid in full["activated_uids"]
        if uid not in direct_uids and str(uid) in bare_name_uids
    )
    blocked_set = set(blocked)
    return {
        "kind": BARE_NAME_RECURSION_KIND,
        "report_version": 1,
        "message": message,
        "full_activated": full["activated_uids"],
        "direct_activated": sorted(direct_uids),
        "recursion_only_blocked": blocked,
        "kept_under_rule": [uid for uid in full["activated_uids"] if uid not in blocked_set],
    }


def era_root_uids_from_manifest(manifest: Any) -> list[str]:
    """Era-branch root uids as the manifest records them."""
    roots: list[str] = []
    for row in (manifest or {}).get("entries") or []:
        if not isinstance(row, dict):
            continue
        architecture = row.get("architecture") or {}
        if architecture.get("era_cascade_role") == "root":
            roots.append(str(row.get("uid")))
    return roots


def cascade_protected_uids(manifest: Any) -> list[str]:
    """Uids the era contract forbids capping (cascade chain roles root/context/state)."""
    protected: list[str] = []
    for row in (manifest or {}).get("entries") or []:
        if not isinstance(row, dict):
            continue
        role = (row.get("architecture") or {}).get("era_cascade_role")
        if role in PROTECTED_CASCADE_ROLES:
            protected.append(str(row.get("uid")))
    return protected


def _attribute_scan(entries: list[Any], root_uids: set[str], enabled_root: str, *, depth: int, message: str) -> dict[str, int]:
    """One single-root scenario: attribute each activation to every matching buffer source."""
    work = []
    for entry in entries:
        clone = copy.copy(entry)
        if str(clone.uid) in root_uids:
            clone.disable = str(clone.uid) != enabled_root
        work.append(clone)
    result = S.scan(work, message, recursive=True, max_recursion_steps=depth)
    by_uid = {entry.uid: entry for entry in entries}
    rounds: dict[int, list[int]] = {}
    for uid, round_num in result["activation_round"].items():
        rounds.setdefault(round_num, []).append(uid)
    buffer_sources: list[int] = []
    counts: dict[str, int] = {}
    for round_num in sorted(rounds):
        for target_uid in sorted(rounds[round_num]):
            target = by_uid[target_uid]
            if target.constant:
                continue
            matches = [
                source for source in buffer_sources
                if source != target_uid and S.entry_matches(target, by_uid[source].content)
            ]
            for source in matches:
                key = str(source)
                counts[key] = counts.get(key, 0) + 1
        for target_uid in sorted(rounds[round_num]):
            entry = by_uid[target_uid]
            if not entry.prevent_further_recursion and not entry.disable:
                buffer_sources.append(target_uid)
    return counts


def compute_downstream_counts(
    rows: list[dict[str, Any]],
    root_uids: list[str],
    *,
    depth: int = 8,
    message: str = "",
) -> dict[str, int]:
    """Per-source downstream counts measured with the real activation mechanics.

    Runs one scenario per era root with that root enabled alone, attributes each
    activated entry to every buffer source whose content matches it, and keeps each
    source's best contribution across those scenarios. The prevent_further_recursion
    filter is inherent: content of an entry that already prevents recursion never
    enters the recursion buffer, so it can never be counted as a source."""
    scan_entries = S.entries_from_dicts(rows)
    root_set = {str(root) for root in root_uids}
    counts: dict[str, int] = {}
    for root in root_uids:
        per_run = _attribute_scan(scan_entries, root_set, str(root), depth=depth, message=message)
        for uid, value in per_run.items():
            if value > counts.get(uid, 0):
                counts[uid] = value
    return counts


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True, help="Delivered book (card/merged JSON) to scan")
    parser.add_argument("--manifest", help="Manifest JSON whose architecture names the era roots")
    parser.add_argument("--root-uids", help="Comma-separated era root uids when no manifest is given")
    parser.add_argument("--depth", type=int, default=8, help="Recursion depth per scenario (default 8)")
    parser.add_argument("--output", help="Optional JSON report path")
    parser.add_argument("--character-risks", action="store_true", help="Also report high in-degree character entries keyed only by a bare name")
    parser.add_argument("--character-plan", help="character-plan JSON, makes the character-risk rule satisfiability-aware")
    parser.add_argument("--era-state-amplifiers", action="store_true", help="Also report era-cascade state entries (the measured multi-era amplifier, which the era contract forbids capping)")
    args = parser.parse_args()
    data = json.loads(Path(args.input).read_text(encoding="utf-8"))
    manifest = json.loads(Path(args.manifest).read_text(encoding="utf-8")) if args.manifest else None
    rows = book_entries(data)
    protected: list[str] = []
    if manifest is not None:
        roots = era_root_uids_from_manifest(manifest)
        protected = cascade_protected_uids(manifest)
    elif args.root_uids:
        roots = [part.strip() for part in args.root_uids.split(",") if part.strip()]
    else:
        print("pass --manifest or --root-uids so the era roots are known", file=sys.stderr)
        return 2
    counts = compute_downstream_counts(rows, roots, depth=args.depth)
    candidates = find_prevent_recursion_candidates(rows, counts, exclude_uids=protected)
    report = {
        "kind": REPORT_KIND,
        "report_version": REPORT_VERSION,
        "input": args.input,
        "root_uids": roots,
        "excluded_protected": protected,
        "depth": args.depth,
        "entry_count": len(rows),
        "candidate_count": len(candidates),
        "candidates": candidates,
        "counts": counts,
    }
    if args.character_risks:
        risks = find_cascade_keyword_risks(rows, counts)
        if args.character_plan:
            plan = json.loads(Path(args.character_plan).read_text(encoding="utf-8"))
            risks = cascade_keyword_satisfiability(risks, plan)
            report["character_keyword_unsatisfiable_count"] = sum(
                1 for risk in risks if not risk.get("satisfiable")
            )
        report["character_keyword_risks"] = risks
        report["character_keyword_risk_count"] = len(risks)
    if args.era_state_amplifiers:
        report["era_state_amplifiers"] = find_era_state_amplitudes(rows, manifest, counts)
        report["era_state_amplifiers_note"] = (
            "Era-cascade state entries are the measured multi-era amplifier and the era "
            "contract forbids capping them; reported for visibility, never as cap candidates."
        )
    rendered = json.dumps(report, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        Path(args.output).write_text(rendered, encoding="utf-8", newline="\n")
        print(f"wrote {args.output} ({len(candidates)} candidates)")
    else:
        print(rendered)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
