#!/usr/bin/env python3
"""WorldBuilder card-shell routing contract helpers.

The contract freezes high-level user choices before generation and gives the
architecture gate a deterministic description of what belongs in each card
field. It deliberately does not author prose.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any

from wb_common import WorldBuilderError, load_build_state, preflight_report, requirement_rows

CONTRACT = "worldbuilder-card-shell-v1"
PLAN_KIND = "worldbuilder-card-shell-plan"
PLAN_VERSION = 1

CARD_FIELDS = (
    "name",
    "description",
    "personality",
    "scenario",
    "first_mes",
    "alternate_greetings",
    "mes_example",
    "creator_notes",
    "system_prompt",
    "post_history_instructions",
    "group_only_greetings",
    "tags",
    "creator",
    "character_version",
    "nickname",
    "creator_notes_multilingual",
    "source",
    "creation_date",
    "modification_date",
    "assets",
)

# Batch 5, 5.4. Formalizes the "compact fallback behavior kernel" this file
# already gestures at via fallback_kernel: over-budget shrinkage gets a
# mechanical answer: which of the shell's five roles gives first, in what
# order, when it must shrink to fit permanent_card_hard. Some slots map to a
# single dedicated field (voice_sample -> mes_example, situation_anchor ->
# scenario); identity_kernel and appearance_and_details both draw on
# description, which carries both kinds of content; distinguishing them
# within the field's own prose is a content judgment for whoever writes it
# (RETENTION_LADDER's role), not something this schema-level table can
# split further on its own.
SLOT_PRIORITY = (
    {
        "slot": "identity_kernel", "fields": ("name", "description", "personality"),
        "rule": "never_cut",
        "description": "Who this is, stated plainly: the shell's entire reason to exist.",
    },
    {
        "slot": "interaction_contract", "fields": ("system_prompt", "post_history_instructions"),
        "rule": "never_cut",
        "description": "The stable behavioral contract: role, boundaries, constraints.",
    },
    {
        "slot": "voice_sample", "fields": ("mes_example",),
        "rule": "cut_last",
        "description": "Demonstrated voice and behavior: how they talk, not just what they are.",
    },
    {
        "slot": "situation_anchor", "fields": ("scenario",),
        "rule": "cuttable_if_covered",
        "description": "The default premise: cuttable if a constant lorebook root or Scenario already covers it.",
    },
    {
        "slot": "appearance_and_details", "fields": ("description",),
        "rule": "cut_first",
        "description": "Physical description and flavor beyond identity: first to move into the lorebook when the shell must shrink.",
    },
)


def resolve_slot_priority(routing: dict[str, dict[str, Any]]) -> list[dict[str, Any]]:
    """5.4: SLOT_PRIORITY annotated against one plan's actual routing;
    active_fields excludes anything routed must_be_blank for this artifact
    (e.g. personality is always blank for World), so the returned order is
    directly actionable rather than a static, context-free list."""
    resolved = []
    for slot in SLOT_PRIORITY:
        active = [f for f in slot["fields"] if not routing.get(f, {}).get("must_be_blank", False)]
        resolved.append({**slot, "active_fields": active})
    return resolved


def _metadata_routes(*, group: bool = False) -> dict[str, dict[str, Any]]:
    return {
        "group_only_greetings": _route(
            "group_only_openings" if group else "optional_group_chat_openings",
        ),
        "tags": _route("normalized_discovery_tags_preserve_user_tags"),
        "creator": _route("human_attribution_preserve_or_explicitly_set"),
        "character_version": _route("artifact_revision_label_preserve_or_increment_on_release"),
        "nickname": _route("optional_runtime_display_name_with_char_macro_semantics"),
        "creator_notes_multilingual": _route("language_keyed_human_notes_preserve_or_translate_on_request"),
        "source": _route("append_only_provenance_identifiers_and_urls"),
        "creation_date": _route("unix_seconds_preserve_original_or_set_on_first_creation"),
        "modification_date": _route("unix_seconds_update_only_for_content_release"),
        "assets": _route("validated_asset_descriptors_and_embedded_uri_mapping"),
    }


def _sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def _route(route: str, *, required: bool = False, permanent: bool = False, blank: bool = False) -> dict[str, Any]:
    return {
        "route": route,
        "required": required,
        "permanent": permanent,
        "must_be_blank": blank,
    }


def build_plan(
    *,
    build_id: str,
    artifact_type: str,
    schema: int | None,
    opening_style: str = "open",
    greeting_policy: str = "single",
    dialogue_policy: str | None = None,
    scenario_policy: str = "blank",
    fixed_scenario_text: str = "",
    system_prompt_policy: str = "automatic",
    post_history_policy: str = "automatic",
    creator_notes_policy: str = "automatic",
    persona_detail: str = "compact",
) -> dict[str, Any]:
    artifact_type = str(artifact_type).strip().casefold()
    opening_style = str(opening_style).strip().casefold()
    greeting_policy = str(greeting_policy).strip().casefold()
    scenario_policy = str(scenario_policy).strip().casefold()
    system_prompt_policy = str(system_prompt_policy).strip().casefold()
    post_history_policy = str(post_history_policy).strip().casefold()
    creator_notes_policy = str(creator_notes_policy).strip().casefold()
    persona_detail = str(persona_detail).strip().casefold()

    if opening_style not in {"open", "guided", "fixed", "shared", "individual", "both"}:
        raise WorldBuilderError("opening style must be open, guided, fixed, shared, individual, or both")
    if greeting_policy not in {"single", "varied", "custom", "era-specific", "shared-style"}:
        raise WorldBuilderError("greeting policy must be single, varied, custom, era-specific, or shared-style")
    if scenario_policy not in {"blank", "fixed"}:
        raise WorldBuilderError("scenario policy must be blank or fixed")
    if system_prompt_policy not in {"automatic", "none", "custom"}:
        raise WorldBuilderError("system prompt policy must be automatic, none, or custom")
    if post_history_policy not in {"automatic", "none", "custom"}:
        raise WorldBuilderError("post-history policy must be automatic, none, or custom")
    if creator_notes_policy not in {"automatic", "review", "custom"}:
        raise WorldBuilderError("creator notes policy must be automatic, review, or custom")
    if persona_detail not in {"compact", "detailed", "custom"}:
        raise WorldBuilderError("persona detail must be compact, detailed, or custom")
    if scenario_policy == "fixed" and not fixed_scenario_text.strip():
        raise WorldBuilderError("fixed scenario policy requires approved scenario text")
    if scenario_policy == "blank" and fixed_scenario_text.strip():
        raise WorldBuilderError("blank scenario policy cannot carry fixed scenario text")

    if dialogue_policy is None:
        dialogue_policy = "recommended" if artifact_type == "card" else "none"
    dialogue_policy = str(dialogue_policy).strip().casefold()
    if dialogue_policy not in {"recommended", "none", "custom"}:
        raise WorldBuilderError("dialogue policy must be recommended, none, or custom")

    routing: dict[str, dict[str, Any]] = {}
    applicability = "card"
    if artifact_type == "world":
        routing = {
            "name": _route("world_identity", required=True, permanent=True),
            "description": _route("compact_world_core_and_tone", required=True, permanent=True),
            "personality": _route("unused_character_field", permanent=True, blank=True),
            "scenario": _route("user_settings_page" if scenario_policy == "blank" else "approved_fixed_premise", permanent=True, blank=scenario_policy == "blank"),
            "first_mes": _route("open_world_entrance", required=True),
            "alternate_greetings": _route("alternate_starting_locations_eras_or_situations"),
            "mes_example": _route("normally_unused_world_examples", blank=dialogue_policy == "none"),
            "creator_notes": _route("era_usage_custom_history_and_attribution_guide", required=True),
            "system_prompt": _route("stable_world_simulation_behavior_only", permanent=True, blank=system_prompt_policy == "none"),
            "post_history_instructions": _route("short_high_priority_world_constraints_only", permanent=True, blank=post_history_policy == "none"),
            **_metadata_routes(),
        }
    elif artifact_type == "card":
        routing = {
            "name": _route("character_identity", required=True, permanent=True),
            "description": _route("canonical_character_sections_except_personality", required=True, permanent=True),
            "personality": _route("personality_and_voice_only", required=True, permanent=True),
            "scenario": _route("reusable_blank" if scenario_policy == "blank" else "approved_fixed_premise", permanent=True, blank=scenario_policy == "blank"),
            "first_mes": _route("playable_opening_scene_and_voice_demonstration", required=True),
            "alternate_greetings": _route("alternate_meeting_mood_or_relationship_contexts"),
            "mes_example": _route("voice_and_behavior_demonstrations", required=dialogue_policy in {"recommended", "custom"}, blank=dialogue_policy == "none"),
            "creator_notes": _route("usage_timeframe_variant_and_attribution_guide", required=True),
            "system_prompt": _route("stable_character_role_behavior_only", permanent=True, blank=system_prompt_policy == "none"),
            "post_history_instructions": _route("short_high_priority_behavior_constraints_only", permanent=True, blank=post_history_policy == "none"),
            **_metadata_routes(),
        }
    elif artifact_type == "group":
        applicability = "group-set"
        routing = {
            "name": _route("group_or_card_identity", required=True),
            "description": _route("per_character_canonical_routing"),
            "personality": _route("per_character_personality_and_voice"),
            "scenario": _route("shared_or_per_card_premise", blank=scenario_policy == "blank"),
            "first_mes": _route("shared_or_character_specific_group_opening", required=True),
            "alternate_greetings": _route("group_opening_variants"),
            "mes_example": _route("per_character_or_group_dialogue_examples"),
            "creator_notes": _route("group_usage_and_shared_lorebook_guide", required=True),
            "system_prompt": _route("group_behavior_only", blank=system_prompt_policy == "none"),
            "post_history_instructions": _route("short_group_constraints_only", blank=post_history_policy == "none"),
            **_metadata_routes(group=True),
        }
    elif artifact_type == "persona":
        applicability = "persona-text"
        routing = {field: _route("not_applicable", blank=True) for field in CARD_FIELDS}
    elif artifact_type == "lorebook":
        applicability = "standalone-lorebook"
        routing = {field: _route("not_applicable", blank=True) for field in CARD_FIELDS}
    else:
        applicability = "preserve-existing"
        routing = {field: _route("preserve_existing") for field in CARD_FIELDS}

    fixed = fixed_scenario_text.strip()
    plan = {
        "kind": PLAN_KIND,
        "plan_version": PLAN_VERSION,
        "contract": CONTRACT,
        "build_id": build_id,
        "artifact_type": artifact_type,
        "schema": schema,
        "applicability": applicability,
        "choices": {
            "opening_style": opening_style,
            "greeting_policy": greeting_policy,
            "dialogue_policy": dialogue_policy,
            "scenario_policy": scenario_policy,
            "system_prompt_policy": system_prompt_policy,
            "post_history_policy": post_history_policy,
            "creator_notes_policy": creator_notes_policy,
            "persona_detail": persona_detail,
        },
        "fallback_kernel": {
            "required": artifact_type == "world" and not (system_prompt_policy == "none" and post_history_policy == "none"),
            "minimum_chars": 80,
            "maximum_chars": 1600,
            "fields": [field for field, policy in (("system_prompt", system_prompt_policy), ("post_history_instructions", post_history_policy)) if policy != "none"],
            "topics": ["world-simulation role", "unknown-state handling", "canon-conflict avoidance"],
        },
        "fixed_scenario": {
            "approved": scenario_policy == "fixed",
            "text": fixed,
            "sha256": _sha256_text(fixed) if fixed else None,
        },
        "routing": routing,
        "slot_priority": resolve_slot_priority(routing),
        "validation": {
            "require_first_message": artifact_type in {"world", "card", "group"},
            "require_creator_notes": artifact_type in {"world", "card", "group"},
            "require_personality_blank": artifact_type == "world",
            "require_character_examples": artifact_type == "card" and dialogue_policy in {"recommended", "custom"},
            "alternate_greetings_minimum": 1 if greeting_policy in {"varied", "custom", "era-specific", "shared-style"} else 0,
            "description_soft_limit_chars": 4000 if artifact_type == "world" else 12000,
            "permanent_prompt_soft_limit_chars": 16000,
            "permanent_prompt_hard_limit_chars": 30000,
            "duplication_min_chars": 80,
        },
    }
    validate_plan(plan, expected_build_id=build_id)
    return plan


def validate_plan(plan: dict[str, Any], *, expected_build_id: str | None = None) -> None:
    if not isinstance(plan, dict):
        raise WorldBuilderError("card-shell plan must be an object")
    if plan.get("kind") != PLAN_KIND or plan.get("plan_version") != PLAN_VERSION:
        raise WorldBuilderError("card-shell plan has the wrong kind/version")
    if plan.get("contract") != CONTRACT:
        raise WorldBuilderError(f"card-shell plan contract must be {CONTRACT}")
    if expected_build_id is not None and plan.get("build_id") != expected_build_id:
        raise WorldBuilderError("card-shell plan belongs to another build")
    if plan.get("artifact_type") not in {"card", "world", "group", "persona", "lorebook", "convert", "audit"}:
        raise WorldBuilderError("card-shell plan has an unsupported artifact type")
    choices = plan.get("choices")
    routing = plan.get("routing")
    kernel = plan.get("fallback_kernel")
    if plan.get("artifact_type") == "world":
        if not isinstance(kernel, dict):
            raise WorldBuilderError("World card-shell plan needs fallback_kernel policy")
        expected_required = not (choices.get("system_prompt_policy") == "none" and choices.get("post_history_policy") == "none") if isinstance(choices, dict) else True
        if kernel.get("required") is not expected_required:
            raise WorldBuilderError("World fallback-kernel requirement disagrees with permanent behavior policies")
        minimum = kernel.get("minimum_chars")
        maximum = kernel.get("maximum_chars")
        if not isinstance(minimum, int) or not isinstance(maximum, int) or minimum < 1 or maximum < minimum:
            raise WorldBuilderError("World fallback-kernel character range is invalid")
    validation = plan.get("validation")
    fixed = plan.get("fixed_scenario")
    if not isinstance(choices, dict) or not isinstance(routing, dict) or not isinstance(validation, dict) or not isinstance(fixed, dict):
        raise WorldBuilderError("card-shell plan is missing choices, routing, validation, or fixed_scenario")
    if set(routing) != set(CARD_FIELDS):
        raise WorldBuilderError("card-shell routing must define every supported card field exactly once")
    for field, row in routing.items():
        if not isinstance(row, dict) or not isinstance(row.get("route"), str):
            raise WorldBuilderError(f"card-shell route for {field} is invalid")
        for key in ("required", "permanent", "must_be_blank"):
            if not isinstance(row.get(key), bool):
                raise WorldBuilderError(f"card-shell route {field}.{key} must be boolean")
    policy = choices.get("scenario_policy")
    text = fixed.get("text")
    if policy == "fixed":
        if fixed.get("approved") is not True or not isinstance(text, str) or not text.strip():
            raise WorldBuilderError("fixed Scenario requires approved non-empty text")
        if fixed.get("sha256") != _sha256_text(text.strip()):
            raise WorldBuilderError("fixed Scenario hash is stale")
    elif policy == "blank":
        if fixed.get("approved") is not False or text not in {"", None}:
            raise WorldBuilderError("blank Scenario policy cannot contain fixed text")
    else:
        raise WorldBuilderError("card-shell scenario policy must be blank or fixed")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--build-state", help="Build-state path for the read-only --requirements preflight.")
    parser.add_argument("--requirements", action="store_true", help="Read-only preflight: print what this gate checks against the current build state.")
    args = parser.parse_args()
    if not args.requirements:
        parser.error("this module has no standalone run mode; use --requirements for the read-only preflight")
    if not args.build_state:
        parser.error("--requirements needs --build-state")
    root, state = load_build_state(args.build_state)
    print(json.dumps(preflight_report("card_shell_contract", requirement_rows(Path(__file__), root, state)), ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
