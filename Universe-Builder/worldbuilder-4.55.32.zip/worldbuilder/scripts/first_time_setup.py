#!/usr/bin/env python3
"""Plan or apply WorldBuilder's persistent SearXNG/WARP research setup.

The setup is explicit: no privileged or persistent action occurs without
``--apply``. Docker is preferred; an isolated native Python/source deployment is
available when Docker cannot run. Existing WorldBuilder configuration is
preserved with a deep merge and a timestamped backup.
"""
from __future__ import annotations

import argparse
import copy
import json
import os
import platform
import plistlib
import re
import secrets
import shlex
import shutil
import subprocess
import tempfile
import urllib.request
import urllib.parse
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from wb_common import atomic_write_json, atomic_write_text
import capability_probe as cp
import ensure_research_stack as research_runtime

# Read once, dynamically: never hardcoded (see DR-065; a hardcoded copy of
# this string is exactly the staleness Batch 1 already found and fixed once).
VERSION = (Path(__file__).resolve().parent.parent / "VERSION").read_text(encoding="utf-8").strip()

SEARXNG_REPOSITORY = "https://github.com/searxng/searxng.git"
DEFAULT_DOCKER_IMAGE = "docker.io/searxng/searxng:latest"


def now_stamp() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")


def executable_path(name: str) -> str | None:
    found = shutil.which(name)
    if found:
        return found
    if name == "warp-cli":
        candidates: list[Path] = []
        for env_name in ("ProgramFiles", "ProgramFiles(x86)"):
            base = os.environ.get(env_name)
            if base:
                candidates.append(Path(base) / "Cloudflare" / "Cloudflare WARP" / "warp-cli.exe")
        candidates.extend([
            Path("/Applications/Cloudflare WARP.app/Contents/Resources/warp-cli"),
            Path("/opt/homebrew/bin/warp-cli"),
            Path("/usr/local/bin/warp-cli"),
            Path("/usr/bin/warp-cli"),
        ])
        for candidate in candidates:
            if str(candidate) and candidate.is_file():
                return str(candidate)
    return None


def command_exists(name: str) -> bool:
    return executable_path(name) is not None


def _spawnable(cmd: list[str]) -> list[str]:
    """Return an argv that Windows can actually spawn.

    Batch shims (.cmd/.bat, like the npm-global openclaw on Windows) cannot be
    executed by CreateProcess directly; resolve the name the way the shell does
    and wrap it in cmd.exe. Verified against a real Windows install, where the
    unwrapped form failed with WinError 2 before any config work could run.
    Non-shim commands pass through unchanged."""
    if os.name != "nt" or not cmd:
        return cmd
    resolved = shutil.which(cmd[0])
    if resolved and resolved.lower().endswith((".cmd", ".bat")):
        return ["cmd.exe", "/d", "/c", resolved, *cmd[1:]]
    return cmd


def run(cmd: list[str], *, cwd: Path | None = None, check: bool = True, env: dict[str, str] | None = None, timeout: float | None = None) -> subprocess.CompletedProcess[str]:
    proc = subprocess.run(_spawnable(cmd), cwd=cwd, env=env, text=True, capture_output=True, check=False, timeout=timeout)
    if check and proc.returncode != 0:
        raise RuntimeError(f"Command failed ({proc.returncode}): {' '.join(cmd)}\n{proc.stdout}\n{proc.stderr}")
    return proc


def detect() -> dict[str, Any]:
    system = platform.system().lower()
    docker = command_exists("docker")
    compose = docker and run(["docker", "compose", "version"], check=False).returncode == 0
    # `docker` and `docker compose version` both succeed with no running daemon, which
    # is exactly the state of a machine where virtualization is unavailable or off.
    # Only a successful `docker info` proves the backend can actually run containers.
    daemon_probe = run(["docker", "info"], check=False) if docker else None
    daemon = daemon_probe is not None and daemon_probe.returncode == 0
    daemon_detail = ""
    if daemon_probe is not None and not daemon:
        daemon_detail = (daemon_probe.stdout + daemon_probe.stderr).strip()[-400:]
    return {
        "system": system,
        "python": sys.executable,
        "python_version": platform.python_version(),
        "docker": docker,
        "docker_compose": compose,
        "docker_daemon": daemon,
        "docker_daemon_detail": daemon_detail,
        "git": command_exists("git"),
        "warp_cli": command_exists("warp-cli"),
        "warp_cli_path": executable_path("warp-cli"),
        "openclaw": command_exists("openclaw"),
        "winget": command_exists("winget"),
        "brew": command_exists("brew"),
        "apt_get": command_exists("apt-get"),
        "dnf": command_exists("dnf"),
        "pacman": command_exists("pacman"),
    }


def can_install_python_prerequisites(capabilities: dict[str, Any]) -> bool:
    system = capabilities.get("system")
    if system == "windows":
        return bool(capabilities.get("winget"))
    if system == "darwin":
        return bool(capabilities.get("brew"))
    if system == "linux":
        return bool(capabilities.get("apt_get") or capabilities.get("dnf") or capabilities.get("pacman"))
    return False


def choose_backend(
    requested: str,
    capabilities: dict[str, Any],
    *,
    allow_prerequisite_install: bool = False,
) -> str:
    docker_usable = bool(capabilities["docker_compose"]) and bool(capabilities.get("docker_daemon", True))
    if requested == "docker":
        if not capabilities["docker_compose"]:
            raise RuntimeError("Docker Compose is unavailable; choose --backend python or install Docker.")
        if not capabilities.get("docker_daemon", True):
            raise RuntimeError(
                "Docker is installed but its daemon is not reachable, which is what a machine "
                "without working virtualization looks like. Start Docker Desktop or the docker "
                "service, or rerun with --backend python to use the native SearXNG backend "
                "(no containers required).\n"
                + str(capabilities.get("docker_daemon_detail", ""))
            )
        return "docker"
    python_ready = bool(capabilities.get("git"))
    python_installable = allow_prerequisite_install and can_install_python_prerequisites(capabilities)
    if requested == "python":
        if not python_ready and not python_installable:
            raise RuntimeError(
                "The native Python backend requires git and build prerequisites. "
                "Install them first or approve --install-prerequisites."
            )
        return "python"
    if docker_usable:
        return "docker"
    if python_ready or python_installable:
        return "python"
    raise RuntimeError(
        "No usable backend. Docker is "
        + ("installed but its daemon is unreachable (virtualization off or Docker not running)"
           if capabilities["docker_compose"] else "unavailable")
        + ", and the native Python backend needs git plus build prerequisites. "
        "Start Docker, install git, or approve --install-prerequisites on a supported platform."
    )

def deep_merge(existing: Any, updates: Any) -> Any:
    if isinstance(existing, dict) and isinstance(updates, dict):
        merged = copy.deepcopy(existing)
        for key, value in updates.items():
            merged[key] = deep_merge(merged[key], value) if key in merged else copy.deepcopy(value)
        return merged
    return copy.deepcopy(updates)


def load_existing_config(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise RuntimeError(f"Existing config must contain an object: {path}")
    return value


def backup_config(path: Path) -> Path | None:
    if not path.exists():
        return None
    backup = path.with_name(f"{path.name}.bak-{now_stamp()}")
    shutil.copy2(path, backup)
    return backup


def parse_local_base_url(base_url: str) -> tuple[str, int, str]:
    parsed = urllib.parse.urlsplit(base_url)
    if parsed.scheme.casefold() != "http" or not parsed.hostname:
        raise RuntimeError("SearXNG --base-url must be an absolute local http:// URL")
    host = parsed.hostname.casefold()
    if host not in {"127.0.0.1", "localhost", "::1"}:
        raise RuntimeError("SearXNG must bind to a loopback host (127.0.0.1, localhost, or ::1)")
    if parsed.path not in {"", "/"} or parsed.query or parsed.fragment:
        raise RuntimeError("SearXNG --base-url must not contain a path, query, or fragment")
    port = parsed.port or 80
    if not (1 <= port <= 65535):
        raise RuntimeError("SearXNG --base-url has an invalid port")
    normalized = f"http://127.0.0.1:{port}"
    return "127.0.0.1", port, normalized


def settings_yaml(
    secret: str, *, bind_address: str = "127.0.0.1", port: int = 8888, warp_proxy: str | None = None,
) -> str:
    proxy = ""
    if warp_proxy:
        proxy = (
            '  # WorldBuilder: grep for "proxy" will not find the YAML key "proxies" below.\n'
            "  proxies:\n"
            "    all://:\n"
            f'      - "{warp_proxy}"\n'
        )
    return f'''use_default_settings: true

general:
  debug: false
  instance_name: "WorldBuilder SearXNG"

search:
  safe_search: 0
  autocomplete: ""
  formats:
    - html
    - json

server:
  bind_address: "{bind_address}"
  port: {port}
  secret_key: "{secret}"
  limiter: false
  image_proxy: false

outgoing:
  request_timeout: 10.0
  max_request_timeout: 20.0
  pool_connections: 100
  pool_maxsize: 20
{proxy}'''


def compose_text(image: str, *, host_port: int = 8888, base_url: str = "http://127.0.0.1:8888") -> str:
    return f'''services:
  searxng:
    image: {image}
    container_name: worldbuilder-searxng
    restart: unless-stopped
    ports:
      - "127.0.0.1:{host_port}:8080"
    volumes:
      - ./config:/etc/searxng
      - ./data:/var/cache/searxng
    environment:
      - SEARXNG_BASE_URL={base_url.rstrip('/')}/
'''


def prepare_docker(root: Path, secret: str, image: str, base_url: str, *, write: bool, warp_proxy: str | None = None) -> dict[str, str]:
    _, host_port, normalized = parse_local_base_url(base_url)
    stack = root / "research-stack" / "searxng"
    config = stack / "config"
    data = stack / "data"
    if write:
        config.mkdir(parents=True, exist_ok=True)
        data.mkdir(parents=True, exist_ok=True)
        atomic_write_text(config / "settings.yml", settings_yaml(secret, bind_address="0.0.0.0", port=8080, warp_proxy=warp_proxy))
        atomic_write_text(stack / "compose.yml", compose_text(image, host_port=host_port, base_url=normalized))
    return {
        "stack_dir": str(stack),
        "compose_file": str(stack / "compose.yml"),
        "settings_file": str(config / "settings.yml"),
        "requested_image": image,
        "host_port": str(host_port),
        "service_port": "8080",
        "base_url": normalized,
    }


def prepare_python(root: Path, secret: str, requested_ref: str, base_url: str, *, write: bool, warp_proxy: str | None = None) -> dict[str, str]:
    _, host_port, normalized = parse_local_base_url(base_url)
    stack = root / "research-stack" / "searxng-native"
    if write:
        stack.mkdir(parents=True, exist_ok=True)
        atomic_write_text(stack / "settings.yml", settings_yaml(secret, bind_address="127.0.0.1", port=host_port, warp_proxy=warp_proxy))
    return {
        "stack_dir": str(stack),
        "source_dir": str(stack / "searxng-src"),
        "venv_dir": str(stack / "venv"),
        "settings_file": str(stack / "settings.yml"),
        "pid_file": str(stack / "searxng.pid.json"),
        "log_file": str(stack / "searxng.log"),
        "requested_ref": requested_ref,
        "repository": SEARXNG_REPOSITORY,
        "host_port": str(host_port),
        "base_url": normalized,
    }

def platform_prerequisite_command(capabilities: dict[str, Any]) -> list[str] | None:
    system = capabilities.get("system")
    if system == "windows" and capabilities.get("winget"):
        return ["winget", "install", "--id", "Git.Git", "--exact", "--accept-package-agreements", "--accept-source-agreements"]
    if system == "darwin" and capabilities.get("brew"):
        return ["brew", "install", "git", "libxml2", "libxslt", "openssl", "libffi"]
    if system != "linux":
        return None
    if capabilities.get("apt_get"):
        return ["sudo", "apt-get", "install", "-y", "python3-dev", "python3-venv", "git", "build-essential", "libxslt-dev", "zlib1g-dev", "libffi-dev", "libssl-dev"]
    if capabilities.get("dnf"):
        return ["sudo", "dnf", "install", "-y", "python3-devel", "python3-pip", "git", "gcc", "gcc-c++", "make", "libxml2-devel", "libxslt-devel", "openssl-devel", "libffi-devel", "zlib-devel"]
    if capabilities.get("pacman"):
        return ["sudo", "pacman", "-S", "--needed", "--noconfirm", "python", "python-pip", "git", "base-devel", "libxml2", "libxslt", "openssl", "libffi", "zlib"]
    return None

def apply_windows_source_patches(source: Path) -> dict[str, list[str]]:
    """Guarded Windows compatibility fixes for the managed SearXNG clone.

    SearXNG targets POSIX systems: ``searx/valkeydb.py`` imports the Unix-only
    ``pwd`` module and calls it in the valkey error path, which stops the stack
    from starting on Windows. The guards below mirror the long-lived manual patch
    this stack ran with before the setup automated it. Idempotent via a marker;
    applied only on Windows. Verified against a real Windows install."""
    applied: list[str] = []
    skipped: list[str] = []
    valkeydb = source / "searx" / "valkeydb.py"
    if not valkeydb.exists():
        skipped.append("valkeydb.py (not found)")
        return {"applied": applied, "skipped": skipped}
    text = valkeydb.read_text(encoding="utf-8")
    if "guarded for Windows" in text:
        skipped.append("valkeydb.py (already guarded)")
        return {"applied": applied, "skipped": skipped}
    original = text
    text = text.replace(
        "import os\nimport pwd\nimport logging",
        "import os\n\ntry:\n    import pwd  # Unix-only; guarded for Windows\nexcept ImportError:\n    pwd = None\nimport logging",
    )
    text = text.replace(
        "_pw = pwd.getpwuid(os.getuid())",
        "_pw = pwd.getpwuid(os.getuid()) if pwd else None",
    )
    text = text.replace(
        '"[%s (%s)] can\'t connect valkey DB ...", _pw.pw_name, _pw.pw_uid',
        '"[%s (%s)] can\'t connect valkey DB ...", _pw.pw_name if _pw else "?", _pw.pw_uid if _pw else "?"',
    )
    if text == original:
        skipped.append("valkeydb.py (shape not recognized; recheck upstream)")
        return {"applied": applied, "skipped": skipped}
    atomic_write_text(valkeydb, text)
    applied.append("valkeydb.py pwd guard")
    return {"applied": applied, "skipped": skipped}


def install_python_source(paths: dict[str, Any]) -> str:
    source = Path(paths["source_dir"])
    venv = Path(paths["venv_dir"])
    requested_ref = paths.get("requested_ref", "HEAD")
    if not source.exists():
        run(["git", "clone", "--filter=blob:none", "--no-checkout", SEARXNG_REPOSITORY, str(source)])
    if os.name == "nt":
        # Windows git refuses SearXNG's "name:stream" template paths on checkout; with
        # core.protectNTFS=false it stores them as NTFS alternate data streams, the only
        # shape NTFS accepts. Set repo-locally so this checkout and any later maintenance
        # keep working. Verified against a real Windows install.
        run(["git", "config", "core.protectNTFS", "false"], cwd=source)
    run(["git", "fetch", "--depth", "1", "origin", requested_ref], cwd=source)
    run(["git", "checkout", "--detach", "FETCH_HEAD"], cwd=source)
    if os.name == "nt":
        paths["windows_source_patches"] = apply_windows_source_patches(source)
    resolved = run(["git", "rev-parse", "HEAD"], cwd=source).stdout.strip()
    if not resolved:
        raise RuntimeError("Could not resolve a pinned SearXNG commit")
    if not venv.exists():
        run([sys.executable, "-m", "venv", str(venv)])
    py = venv / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
    run([str(py), "-m", "pip", "install", "--upgrade", "pip", "setuptools", "wheel"])
    packages = ["pyyaml", "msgspec", "typing-extensions", "pybind11"]
    if os.name == "nt":
        # Windows ships no system time zone database; tzdata supplies it for zoneinfo.
        packages.append("tzdata")
    run([str(py), "-m", "pip", "install", "--upgrade", *packages])
    run([str(py), "-m", "pip", "install", "--use-pep517", "--no-build-isolation", "-e", str(source)])
    return resolved


def resolve_docker_digest(image: str) -> str:
    run(["docker", "pull", image])
    proc = run(["docker", "image", "inspect", "--format", "{{json .RepoDigests}}", image])
    values = json.loads(proc.stdout.strip() or "[]")
    if not isinstance(values, list) or not values or not isinstance(values[0], str) or "@sha256:" not in values[0]:
        raise RuntimeError(f"Docker did not return a repository digest for {image}")
    return values[0]


def update_env_file(path: Path, key: str, value: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    lines = path.read_text(encoding="utf-8").splitlines() if path.exists() else []
    prefix = key + "="
    rendered = f'{key}="{value}"'
    replaced = False
    out: list[str] = []
    for line in lines:
        if line.strip().startswith(prefix):
            if not replaced:
                out.append(rendered)
                replaced = True
        else:
            out.append(line)
    if not replaced:
        out.append(rendered)
    atomic_write_text(path, "\n".join(out).rstrip() + "\n")


# Required for SearXNG research to function at all. A failure here is fatal.
REQUIRED_OPENCLAW_KEYS: tuple[tuple[str, str, str], ...] = (
    ("tools.web.search.provider", "searxng", "route web search through the local SearXNG instance"),
    ("agents.defaults.subagents.maxChildrenPerAgent", "20", "allow a full discovery wave from one parent session"),
    ("agents.defaults.subagents.maxConcurrent", "20", "allow discovery children to run concurrently"),
)

# Performance tuning for long multi-worker builds. Every entry here is optional:
# an older OpenClaw build may not expose the key, and setup must still succeed.
# Only settings that cannot silently change build output belong in this table.
PERFORMANCE_TUNING: tuple[tuple[str, str, str], ...] = (
    (
        "agents.defaults.params.cacheRetention",
        "long",
        "worker dispatches share large stable prefixes (worker manual, contracts, schemas), "
        "so long cache retention cuts cost without changing behavior",
    ),
    (
        "agents.defaults.compaction.midTurnPrecheck.enabled",
        "true",
        "checks context pressure after tool results are appended and before the next model call, "
        "turning a mid-build context overflow into a recoverable retry instead of a hard failure",
    ),
    (
        "agents.defaults.compaction.truncateAfterCompaction",
        "true",
        "rotates the active transcript after compaction so long builds do not carry unbounded "
        "history; the previous transcript stays archived",
    ),
    (
        "agents.defaults.timeoutSeconds",
        "7200",
        "deep research and generation workers can run long on slower providers or large builds; "
        "raised to 2 hours from the prior 900s value, which still cut off some legitimate long "
        "runs. This applies gateway-wide to every agent, not only WorldBuilder sessions. A "
        "genuinely stuck, unrelated task will now also wait up to 2 hours before OpenClaw gives "
        "up on it, instead of 900 seconds.",
    ),
)

# Settings WorldBuilder deliberately does not touch, reported so the user can decide.
# Each of these can change what a build produces, so they are never set automatically.
ADVISORY_ONLY: tuple[tuple[str, str], ...] = (
    (
        "agents.defaults.contextPruning",
        "Pruning old tool results can remove output a later stage still needs. If you enable it, "
        "add WorldBuilder's commit and validation tools to contextPruning.tools.deny first.",
    ),
    (
        "agents.defaults.contextLimits.toolResultMaxChars",
        "Large phase files and manifests are read through tool calls, and oversized results are "
        "capped. Run 'openclaw doctor --deep' to print the effective cap before overriding it; "
        "the effective value is still limited to roughly 30% of the model context window.",
    ),
    (
        "agents.defaults.maxConcurrent",
        "Caps parallel agent runs across sessions (default 4). WorldBuilder raises the subagent "
        "caps but leaves this one alone, because its interaction with subagent lanes has not been "
        "measured here. Raise it only if discovery waves appear serialized despite maxConcurrent=20.",
    ),
    (
        "agents.defaults.sandbox",
        "Sandbox containers default to network 'none'. If you enable sandboxing, SearXNG research "
        "will fail until the sandbox is given a bridge network.",
    ),
)

# Cannot be set from the CLI; the user has to change it in the Settings UI.
MANUAL_STEPS: tuple[dict[str, str], ...] = (
    {
        "setting": "Context Profile",
        "location": "OpenClaw Settings -> Context Profile",
        "value": "Code Agent",
        "why": "Team Bot and Minimal skip workspace reinjection on safe follow-ups, and carry much "
               "smaller per-file caps. Code Agent reinjects every turn at 50,000 per file and "
               "300,000 total.",
        "note": "This changes bootstrap injection and follow-up reinjection only. It does not enlarge "
                "the model context window and does not stop conversation history being compacted.",
    },
)


def tune_openclaw_performance() -> dict[str, Any]:
    """Apply optional performance settings.

    Unlike the SearXNG keys, nothing here is required for correctness, so a key
    that this OpenClaw build does not recognize is recorded and skipped rather
    than failing setup. Goes through diff_openclaw_config/apply_openclaw_config_diff
    for the full CONFIG SAFETY procedure (backup, surgical per-key write,
    validate, restore-on-failure) rather than writing keys directly.
    """
    changes = [(key, value, why) for key, value, why in PERFORMANCE_TUNING]
    diff = diff_openclaw_config(changes)
    result = apply_openclaw_config_diff(diff)
    applied = [{"key": row["key"], "value": row["new_value"], "why": next(w for k, _, w in PERFORMANCE_TUNING if k == row["key"])}
               for row in result["applied"]]
    applied_keys = {row["key"] for row in result["applied"]}
    skipped = [
        {"key": row["key"], "value": row["new_value"], "why": row["why"],
         "detail": next((f["detail"] for f in result["failed"] if f["key"] == row["key"]), None)}
        for row in diff if row["key"] not in applied_keys and not row["unchanged"]
    ]
    return {
        "applied": [{"key": a["key"], "value": a["value"], "why": a["why"]} for a in applied],
        "skipped": skipped,
        "advisory_only": [{"key": k, "guidance": g} for k, g in ADVISORY_ONLY],
        "manual_steps": list(MANUAL_STEPS),
        "config_backup": result["backup"],
        "config_validated": result["config_validated"],
        "restored_from_backup": result["restored_from_backup"],
        "restart": openclaw_restart_guidance(),
        "scope_note": "These are agents.defaults.* keys and therefore apply to every agent on this "
                      "gateway, not only WorldBuilder builds.",
    }


def settings_only(*, apply_changes: bool) -> int:
    """Apply the OpenClaw agent settings without touching the research stack.

    Separate from research provisioning on purpose: agent config and container
    provisioning have different prerequisites, different blast radius, and different
    reasons to be re-run. Someone whose SearXNG already works should not have to pull
    images and restart a gateway to change a config key.
    """
    if not command_exists("openclaw"):
        print(json.dumps({"status": "error", "error": "OpenClaw CLI is unavailable."}, indent=2))
        return 1

    required = [(k, v, w) for k, v, w in REQUIRED_OPENCLAW_KEYS if k.startswith("agents.")]
    if not apply_changes:
        print(json.dumps({
            "status": "planned",
            "mode": "settings-only",
            "scope_note": "agents.defaults.* keys apply to every agent on this gateway.",
            "would_set": [{"key": k, "value": v, "why": w} for k, v, w in required]
                         + [{"key": k, "value": v, "why": w} for k, v, w in PERFORMANCE_TUNING],
            "advisory_only": [{"key": k, "guidance": g} for k, g in ADVISORY_ONLY],
            "manual_steps": list(MANUAL_STEPS),
            "tool_result_cap": {"status": "not_run", "detail": "the diagnostic runs with --apply"},
            "next": ["Review and rerun with --settings-only --apply to write these."],
        }, indent=2))
        return 0

    diff = diff_openclaw_config(required)
    result = apply_openclaw_config_diff(diff)
    applied = [{"key": row["key"], "value": row["new_value"]} for row in result["applied"]]
    failed = [{"key": row["key"], "value": next(v for k, v, _ in required if k == row["key"]), "detail": row["detail"]}
              for row in result["failed"]]
    tuning = tune_openclaw_performance()
    try:
        tool_result_cap = tool_result_cap_status()
    except (OSError, RuntimeError) as exc:
        tool_result_cap = {"status": "error", "detail": str(exc)}

    if not result["config_validated"]:
        print(json.dumps({
            "status": "error",
            "error": f"OpenClaw rejected the configuration; nothing was restarted "
                     f"(restored from backup: {result['restored_from_backup']}).",
            "detail": result["validation_detail"],
        }, indent=2))
        return 1

    print(json.dumps({
        "status": "applied",
        "mode": "settings-only",
        "concurrency_applied": applied,
        "concurrency_failed": failed,
        "performance_tuning": tuning,
        "tool_result_cap": tool_result_cap,
        "manual_steps": list(MANUAL_STEPS),
        "research_stack": "untouched",
        "config_backup": result["backup"],
        "restart": openclaw_restart_guidance(),
        "next": ["Set OpenClaw Settings -> Context Profile to Code Agent; it cannot be set from the CLI."],
    }, indent=2))
    return 0


# Only these prefixes are ever in scope for an OpenClaw host-config write.
# Step 4 of CONFIG SAFETY: another agent's section is never touched, and this
# is checked in code, not left as a convention someone can forget.
# tools.web.search.provider is a pre-existing required key (REQUIRED_OPENCLAW_KEYS)
# that Batch 4's own config-requirements table does not mention; it is global,
# not agents.defaults.*-scoped, but WorldBuilder has always set it and removing
# it here would silently break the SearXNG provider selection this skill depends
# on. Flagged, not silently widened without comment: like maxConcurrent, this is
# a host-wide setting another agent could also read.
IN_SCOPE_CONFIG_PREFIXES = ("agents.defaults.", "plugins.entries.searxng.", "tools.web.search.")


def openclaw_config_path() -> Path | None:
    """The actual active OpenClaw config path, resolved by OpenClaw itself;
    never assumed. OPENCLAW_CONFIG_PATH, --profile, and OPENCLAW_HOME can all
    move it away from the ~/.openclaw/openclaw.json default; guessing the
    path is exactly the kind of stale-memory mistake this batch exists to
    stop. Returns None when OpenClaw cannot report a path at all (host
    unavailable, or a build too old to expose the command); callers must
    treat that as "cannot safely proceed", not as "no config exists"."""
    proc = run(["openclaw", "config", "file", "--json"], check=False)
    if proc.returncode != 0:
        return None
    try:
        data = json.loads(proc.stdout)
    except json.JSONDecodeError:
        return None
    path = data.get("path")
    return Path(path) if path else None


def backup_openclaw_config() -> Path | None:
    """CONFIG SAFETY step 2: read the whole host config and back it up to a
    timestamped copy before any write. Returns None only when the resolved
    path genuinely has no file yet (OpenClaw boots on safe defaults with no
    config.json present); never when the path itself could not be
    trusted; callers must refuse to write in that case rather than treat a
    failed lookup the same as an empty config."""
    path = openclaw_config_path()
    if path is None or not path.exists():
        return None
    backup = path.with_name(f"{path.name}.worldbuilder-bak-{now_stamp()}")
    shutil.copy2(path, backup)
    return backup


def diff_openclaw_config(changes: list[tuple[str, str, str]]) -> list[dict[str, Any]]:
    """CONFIG SAFETY steps 4 and 5 (the read half): for every proposed key,
    read its CURRENT value through the sanctioned CLI (never assumed)
    and refuse outright if any key falls outside agents.defaults.* or
    WorldBuilder's own searxng plugin keys. Never writes anything; this is
    what gets shown to the user as the diff before any approval."""
    diff: list[dict[str, Any]] = []
    for key, new_value, why in changes:
        if not key.startswith(IN_SCOPE_CONFIG_PREFIXES):
            raise RuntimeError(
                f"refusing to touch {key!r}: outside {IN_SCOPE_CONFIG_PREFIXES}; "
                "another agent's section is never in scope for a WorldBuilder config write"
            )
        proc = run(["openclaw", "config", "get", key], check=False)
        old_value = (proc.stdout + proc.stderr).strip() if proc.returncode == 0 else None
        diff.append({
            "key": key, "old_value": old_value, "new_value": new_value, "why": why,
            "unchanged": old_value == new_value,
        })
    return diff


def apply_openclaw_config_diff(diff: list[dict[str, Any]]) -> dict[str, Any]:
    """CONFIG SAFETY steps 2, 3, 6: back up first, write each changed key
    surgically through 'openclaw config set' (one key at a time, never a
    wholesale rewrite), then validate. If validation fails, restore the
    backup immediately rather than leave a partially-applied host config
    behind. Unchanged keys (diff-approved but already at the target value)
    are skipped, so a rerun is idempotent."""
    backup = backup_openclaw_config()
    applied: list[dict[str, str]] = []
    failed: list[dict[str, str]] = []
    for row in diff:
        if row["unchanged"]:
            continue
        proc = run(["openclaw", "config", "set", row["key"], row["new_value"]], check=False)
        if proc.returncode == 0:
            applied.append({"key": row["key"], "old_value": row["old_value"], "new_value": row["new_value"]})
        else:
            failed.append({"key": row["key"], "detail": (proc.stdout + proc.stderr)[-400:]})

    validate = run(["openclaw", "config", "validate"], check=False)
    valid = validate.returncode == 0
    restored = False
    if not valid and backup is not None:
        live_path = openclaw_config_path()
        if live_path is not None:
            shutil.copy2(backup, live_path)
            restored = True

    return {
        "backup": str(backup) if backup else None,
        "applied": applied,
        "failed": failed,
        "config_validated": valid,
        "validation_detail": None if valid else (validate.stdout + validate.stderr)[-2000:],
        "restored_from_backup": restored,
    }


def openclaw_restart_guidance() -> dict[str, Any]:
    """CONFIG SAFETY step 7: never restarted automatically, under any
    circumstance. OpenClaw's gateway watches its own config file and
    hot-reloads most changes without a restart; where one genuinely is
    needed, that is the operator's deliberate call to make: a restart
    drops the live session, and no unattended setup step gets to do that
    on someone's behalf."""
    return {
        "auto_restarted": False,
        "note": (
            "OpenClaw's gateway hot-reloads most config changes on its own; these settings do not "
            "generally require a restart. If something has not taken effect, run "
            "'openclaw gateway restart' yourself when you are ready; it ends the current session, "
            "so this skill never runs it for you."
        ),
    }


# The advisory for agents.defaults.contextLimits names `openclaw doctor --deep` as the
# place to see the effective tool-result cap. Verified against a real OpenClaw 2026.9.4
# installation: that build prints no effective cap and exposes no toolResultMaxChars
# override path (the runtime derives the cap automatically from the model context
# window). The pattern below is deliberately narrow so a build without a printed value
# reports absence instead of inventing one; only widen it against a real build output
# that actually prints the cap.
TOOL_RESULT_CAP_PATTERN = re.compile(r"tool[- ]results?[^\n]{0,80}?(\d[\d,]{2,})\s*(?:chars|characters)", re.IGNORECASE)


def tool_result_cap_status(*, timeout: float = 300.0) -> dict[str, Any]:
    """Run `openclaw doctor --deep` (read only) and report the effective tool-result cap.

    This changes no configuration value. Setup output includes the result so the person
    does not have to run the diagnostic by hand; when the build does not print a cap,
    the status states that plainly."""
    if not command_exists("openclaw"):
        return {
            "status": "unavailable",
            "detail": "openclaw CLI not found; run `openclaw doctor --deep` manually to inspect context limits.",
        }
    try:
        proc = run(["openclaw", "doctor", "--deep"], check=False, timeout=timeout)
    except (subprocess.TimeoutExpired, OSError) as exc:
        return {
            "status": "timeout" if isinstance(exc, subprocess.TimeoutExpired) else "unavailable",
            "detail": f"`openclaw doctor --deep` could not complete ({exc}); re-run it manually to inspect context limits.",
        }
    output = (proc.stdout or "") + "\n" + (proc.stderr or "")
    match = TOOL_RESULT_CAP_PATTERN.search(output)
    if match:
        return {
            "status": "reported",
            "effective_cap_chars": int(match.group(1).replace(",", "")),
            "source": "openclaw doctor --deep",
        }
    return {
        "status": "not_reported",
        "detail": "this OpenClaw build's `openclaw doctor --deep` output does not print an effective tool-result cap; "
                  "the runtime caps tool results automatically from the model context window",
        "advisory": "agents.defaults.contextLimits.toolResultMaxChars",
    }


def configure_openclaw(base_url: str) -> dict[str, Any]:
    listed_before = run(["openclaw", "plugins", "list"], check=False)
    plugin_present = listed_before.returncode == 0 and "searxng" in (listed_before.stdout + listed_before.stderr).casefold()
    install_output = "already installed"
    if not plugin_present:
        install = run(["openclaw", "plugins", "install", "@openclaw/searxng-plugin"], check=True)
        install_output = (install.stdout + install.stderr)[-2000:]
    listed = run(["openclaw", "plugins", "list"], check=True)
    if "searxng" not in (listed.stdout + listed.stderr).casefold():
        raise RuntimeError("OpenClaw did not list the SearXNG plugin after installation")
    env_file = Path.home() / ".openclaw" / ".env"
    update_env_file(env_file, "SEARXNG_BASE_URL", base_url)

    help_proc = run(["openclaw", "config", "set", "--help"], check=False)
    if help_proc.returncode != 0:
        raise RuntimeError(
            "This OpenClaw build does not expose non-interactive 'config set'. "
            "Run 'openclaw configure --section web', select SearXNG, and rerun setup verification."
        )
    required = [(k, v, f"required for the SearXNG web-search provider ({k})") for k, v, _ in REQUIRED_OPENCLAW_KEYS]
    required.insert(1, (
        "plugins.entries.searxng.config.webSearch.baseUrl", base_url,
        "point the SearXNG plugin at this WorldBuilder-managed instance",
    ))
    diff = diff_openclaw_config(required)
    result = apply_openclaw_config_diff(diff)
    if result["failed"]:
        raise RuntimeError(
            "OpenClaw config set failed for: " + ", ".join(f["key"] for f in result["failed"]) +
            ". Run 'openclaw configure --section web' and select SearXNG.\n"
            + "\n".join(f["detail"] for f in result["failed"])
        )
    if not result["config_validated"]:
        raise RuntimeError(
            f"OpenClaw rejected the SearXNG configuration (restored from backup: "
            f"{result['restored_from_backup']}):\n{result['validation_detail']}"
        )
    details = [f"set {row['key']}" for row in result["applied"]]
    configured = True
    tuning = tune_openclaw_performance()
    return {
        "plugin_install_stdout": install_output,
        "plugin_was_already_present": plugin_present,
        "plugin_list_verified": True,
        "provider_configured": configured,
        "env_file": str(env_file),
        "details": details,
        "config_backup": result["backup"],
        "config_validated": result["config_validated"],
        "restored_from_backup": result["restored_from_backup"],
        "performance_tuning": tuning,
        "restart": openclaw_restart_guidance(),
    }


def image_generation_status(image_generate_available: bool, *, current_primary: str | None = None) -> dict[str, Any]:
    """Batch 10: detect and advise only, never auto-configures. Unlike
    configure_openclaw (which actively installs a plugin and sets
    required config), image generation is optional and user-chosen: which
    provider or model, if any, is the person's call, not a default this
    skill should set on their behalf. image_generate_available comes from
    the calling agent's own tool list (capability_probe.py's existing
    tri-state check), never probed here; this script has no way to ask
    the runtime which tools it exposes.
    """
    if not image_generate_available:
        return {
            "status": "unavailable",
            "advice": (
                "image_generate is not available in this session. Configure a provider through "
                "'openclaw configure --section agents' or by setting agents.defaults.mediaModels.image "
                "directly. WorldBuilder never sets this automatically; it is a cost-incurring, "
                "provider-specific choice for the person, not a default this skill should apply."
            ),
            "degradation": "Image Prompts mode remains fully usable; only the --generate branch is unavailable.",
        }
    return {
        "status": "available",
        "current_primary": current_primary,
        "advice": (
            "image_generate is available. Optional: pick a specific model or fallback order in the "
            "Home Config menu ([9] IMAGE GENERATION MODEL) rather than always using image_generate's "
            "own default; this is a preference, not something setup should decide for the person."
        ),
    }


def linux_codename() -> str:
    os_release = Path("/etc/os-release")
    if os_release.exists():
        values: dict[str, str] = {}
        for line in os_release.read_text(encoding="utf-8", errors="replace").splitlines():
            if "=" in line:
                key, value = line.split("=", 1)
                values[key.strip()] = value.strip().strip('"')
        codename = values.get("VERSION_CODENAME") or values.get("UBUNTU_CODENAME")
        if codename:
            return codename
    if command_exists("lsb_release"):
        proc = run(["lsb_release", "-cs"], check=False)
        if proc.returncode == 0 and proc.stdout.strip():
            return proc.stdout.strip()
    raise RuntimeError("Could not determine the Linux distribution codename for the official Cloudflare APT repository")


def download_to(url: str, path: Path) -> None:
    request = urllib.request.Request(url, headers={"User-Agent": "WorldBuilder-Setup/3.6"})
    with urllib.request.urlopen(request, timeout=45.0) as response:
        data = response.read()
    if not data:
        raise RuntimeError(f"Downloaded an empty file from {url}")
    path.write_bytes(data)


def enable_linux_service(name: str) -> None:
    if not command_exists("systemctl"):
        raise RuntimeError(f"systemctl is unavailable; cannot enable required service {name}")
    run(["sudo", "systemctl", "enable", "--now", name])


def install_warp(capabilities: dict[str, Any]) -> str:
    if capabilities["warp_cli"]:
        return "already installed"
    system = capabilities["system"]
    if system == "windows" and capabilities["winget"]:
        run(["winget", "install", "--id", "Cloudflare.Warp", "--exact", "--accept-package-agreements", "--accept-source-agreements"])
        return "installed with winget"
    if system == "darwin" and capabilities["brew"]:
        run(["brew", "install", "--cask", "cloudflare-warp"])
        return "installed with Homebrew"
    if system == "linux" and capabilities["apt_get"]:
        if not command_exists("gpg"):
            run(["sudo", "apt-get", "update"])
            run(["sudo", "apt-get", "install", "-y", "gnupg", "ca-certificates"])
        with tempfile.TemporaryDirectory(prefix="worldbuilder-warp-") as td:
            temp = Path(td)
            key = temp / "cloudflare-warp-pubkey.gpg"
            repo = temp / "cloudflare-client.list"
            download_to("https://pkg.cloudflareclient.com/pubkey.gpg", key)
            run(["sudo", "gpg", "--yes", "--dearmor", "--output", "/usr/share/keyrings/cloudflare-warp-archive-keyring.gpg", str(key)])
            repo.write_text(
                f"deb [signed-by=/usr/share/keyrings/cloudflare-warp-archive-keyring.gpg] "
                f"https://pkg.cloudflareclient.com/ {linux_codename()} main\n",
                encoding="utf-8",
            )
            run(["sudo", "install", "-m", "0644", str(repo), "/etc/apt/sources.list.d/cloudflare-client.list"])
        run(["sudo", "apt-get", "update"])
        run(["sudo", "apt-get", "install", "-y", "cloudflare-warp"])
        enable_linux_service("warp-svc")
        return "installed from the official Cloudflare APT repository and enabled warp-svc"
    if system == "linux" and capabilities["dnf"]:
        with tempfile.TemporaryDirectory(prefix="worldbuilder-warp-") as td:
            temp = Path(td)
            key = temp / "cloudflare-warp-pubkey.gpg"
            repo = temp / "cloudflare-warp.repo"
            download_to("https://pkg.cloudflareclient.com/pubkey.gpg", key)
            download_to("https://pkg.cloudflareclient.com/cloudflare-warp-ascii.repo", repo)
            run(["sudo", "rpm", "--import", str(key)])
            run(["sudo", "install", "-m", "0644", str(repo), "/etc/yum.repos.d/cloudflare-warp.repo"])
        run(["sudo", "dnf", "install", "-y", "cloudflare-warp"])
        enable_linux_service("warp-svc")
        return "installed from the official Cloudflare RPM repository and enabled warp-svc"
    raise RuntimeError(
        "Cloudflare WARP is not installed and no supported automatic installer is available. "
        "Install the official Cloudflare WARP client for this operating system, then rerun setup."
    )


def stage_runtime_scripts(root: Path, *, write: bool) -> dict[str, str]:
    bin_dir = root / "research-stack" / "bin"
    if write:
        bin_dir.mkdir(parents=True, exist_ok=True)
        source_dir = Path(__file__).resolve().parent
        for name in ("ensure_research_stack.py", "searxng_preflight.py"):
            shutil.copy2(source_dir / name, bin_dir / name)
        # Batch 63: searxng_preflight.py resolves the release as parent.parent / "VERSION"
        # relative to its own folder; stage the file beside bin/ so the staged copy is
        # self-contained. Without it the staged preflight dies on import and the first-time
        # setup rolls its config back at the verification step.
        shutil.copy2(source_dir.parent / "VERSION", bin_dir.parent / "VERSION")
    return {"bin_dir": str(bin_dir), "ensure_script": str(bin_dir / "ensure_research_stack.py"), "preflight_script": str(bin_dir / "searxng_preflight.py")}


def launcher_text(config_path: Path, ensure_script: Path) -> str:
    py = Path(sys.executable).resolve()
    if os.name == "nt":
        return f'@echo off\r\n"{py}" "{ensure_script}" --config "{config_path}" --start --preflight\r\n'
    return f"#!/bin/sh\nexec {shlex.quote(str(py))} {shlex.quote(str(ensure_script))} --config {shlex.quote(str(config_path))} --start --preflight\n"


def register_startup(root: Path, config_path: Path, ensure_script: Path, system: str, *, apply: bool) -> dict[str, Any]:
    startup = root / "research-stack" / "startup"
    launcher = startup / ("start-worldbuilder-research.cmd" if system == "windows" else "start-worldbuilder-research.sh")
    if apply:
        startup.mkdir(parents=True, exist_ok=True)
        atomic_write_text(launcher, launcher_text(config_path, ensure_script))
        if system != "windows":
            launcher.chmod(0o755)
    result: dict[str, Any] = {"launcher": str(launcher), "registered": False}
    if system == "windows":
        command = ["schtasks", "/Create", "/SC", "ONLOGON", "/TN", "WorldBuilder Research Stack", "/TR", f'"{launcher}"', "/F"]
        result["method"] = "Windows Task Scheduler"
    elif system == "darwin":
        plist = Path.home() / "Library" / "LaunchAgents" / "com.worldbuilder.research-stack.plist"
        if apply:
            plist.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "Label": "com.worldbuilder.research-stack",
            "ProgramArguments": [str(launcher)],
            "RunAtLoad": True,
            "KeepAlive": False,
            "StandardOutPath": str(startup / "launch.log"),
            "StandardErrorPath": str(startup / "launch.err.log"),
        }
        if apply:
            with plist.open("wb") as handle:
                plistlib.dump(payload, handle)
        command = ["launchctl", "bootstrap", f"gui/{os.getuid()}", str(plist)]
        result.update({"method": "macOS LaunchAgent", "service_file": str(plist)})
    else:
        service = Path.home() / ".config" / "systemd" / "user" / "worldbuilder-research.service"
        if apply:
            service.parent.mkdir(parents=True, exist_ok=True)
        service_text = f'''[Unit]
Description=WorldBuilder research stack
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
ExecStart={shlex.quote(str(launcher))}
RemainAfterExit=yes

[Install]
WantedBy=default.target
'''
        if apply:
            atomic_write_text(service, service_text)
        command = ["systemctl", "--user", "enable", "--now", "worldbuilder-research.service"]
        result.update({"method": "systemd user service", "service_file": str(service)})
    if apply:
        if system == "darwin":
            run(["launchctl", "bootout", f"gui/{os.getuid()}/com.worldbuilder.research-stack"], check=False)
        if system not in {"windows", "darwin"}:
            run(["systemctl", "--user", "daemon-reload"])
        run(command)
        result["registered"] = True
    return result


def ensure_docker_daemon(capabilities: dict[str, Any], timeout: float = 120.0) -> dict[str, Any]:
    """Start Docker Desktop/Engine when installed but not currently running."""
    initial = run(["docker", "info"], check=False)
    if initial.returncode == 0:
        return {"ready": True, "started": False, "method": "already running"}
    system = capabilities["system"]
    method = ""
    if system == "windows":
        candidates: list[Path] = []
        for env_name in ("ProgramFiles", "ProgramFiles(x86)"):
            base = os.environ.get(env_name)
            if base:
                candidates.append(Path(base) / "Docker" / "Docker" / "Docker Desktop.exe")
        executable = next((candidate for candidate in candidates if candidate.is_file()), None)
        if executable is None:
            raise RuntimeError("Docker CLI is installed but Docker Desktop was not found in standard locations")
        subprocess.Popen([str(executable)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        method = str(executable)
    elif system == "darwin":
        proc = run(["open", "-a", "Docker"], check=False)
        if proc.returncode != 0:
            raise RuntimeError(f"Could not start Docker Desktop: {proc.stdout}\n{proc.stderr}")
        method = "open -a Docker"
    else:
        proc = run(["sudo", "systemctl", "enable", "--now", "docker"], check=False)
        if proc.returncode != 0:
            raise RuntimeError(f"Could not start Docker Engine: {proc.stdout}\n{proc.stderr}")
        method = "systemctl enable --now docker"
    deadline = datetime.now(timezone.utc).timestamp() + timeout
    last = ""
    import time
    while datetime.now(timezone.utc).timestamp() < deadline:
        probe = run(["docker", "info"], check=False)
        if probe.returncode == 0:
            return {"ready": True, "started": True, "method": method}
        last = (probe.stdout + probe.stderr)[-2000:]
        time.sleep(3.0)
    raise RuntimeError(f"Docker did not become ready after startup attempt via {method}:\n{last}")


def enable_docker_startup(capabilities: dict[str, Any]) -> dict[str, Any]:
    system = capabilities["system"]
    if system == "linux":
        if not command_exists("systemctl"):
            raise RuntimeError("Docker backend selected but systemctl is unavailable; enable Docker Engine at boot manually")
        proc = run(["sudo", "systemctl", "enable", "--now", "docker"], check=False)
        if proc.returncode != 0:
            raise RuntimeError(f"Could not enable Docker Engine at boot:\n{proc.stdout}\n{proc.stderr}")
        return {"method": "systemd", "enabled": True}
    # On Windows/macOS the WorldBuilder login launcher starts Docker Desktop if
    # necessary, then the container restart policy restores SearXNG.
    return {"method": "WorldBuilder login launcher + Docker restart policy", "enabled": True}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workspace", help="Exact approved WorldBuilder workspace root (not needed with --settings-only)")
    parser.add_argument("--backend", choices=("auto", "docker", "python"), default="auto")
    parser.add_argument("--base-url", default="http://127.0.0.1:8888")
    parser.add_argument("--searxng-image", default=DEFAULT_DOCKER_IMAGE)
    parser.add_argument("--searxng-ref", default="HEAD", help="Git ref resolved to an exact commit during native setup")
    parser.add_argument("--apply", action="store_true", help="Perform installation after explicit user approval")
    parser.add_argument("--install-prerequisites", action="store_true")
    parser.add_argument("--install-warp", action="store_true")
    parser.add_argument("--skip-startup", action="store_true")
    parser.add_argument("--skip-openclaw", action="store_true")
    parser.add_argument(
        "--settings-only",
        action="store_true",
        help="Apply only the OpenClaw agent settings. Touches no containers, no workspace "
             "config, and no research stack. Use when SearXNG is already working.",
    )
    parser.add_argument("--sessions-spawn", choices=("available", "unavailable"), default=None,
                         help="Report from the calling agent's own tool list, never guessed.")
    parser.add_argument("--show-widget", choices=("available", "unavailable"), default=None,
                         help="Report from the calling agent's own tool list, never guessed.")
    parser.add_argument("--image-generate", choices=("available", "unavailable"), default=None,
                         help="Report from the calling agent's own tool list, never guessed.")
    parser.add_argument("--vision-capable", choices=("available", "unavailable"), default=None,
                         help="Report whether the current generation model/session can inspect images; never guessed.")
    parser.add_argument("--capability-timeout", type=float, default=10.0)
    args = parser.parse_args()

    if args.settings_only:
        return settings_only(apply_changes=args.apply)
    if not args.workspace:
        parser.error("--workspace is required unless --settings-only is used")

    config_path_for_rollback: Path | None = None
    backup_for_rollback: Path | None = None
    config_existed_before = False
    config_written = False
    try:
        root = Path(args.workspace).expanduser().resolve()
        if args.apply:
            root.mkdir(parents=True, exist_ok=True)
        capabilities = detect()
        _, _, normalized_base_url = parse_local_base_url(args.base_url)
        backend = choose_backend(
            args.backend, capabilities, allow_prerequisite_install=args.install_prerequisites
        )
        warp_install_result = None
        if args.apply and args.install_warp:
            warp_install_result = install_warp(capabilities)
            capabilities = detect()
        if args.apply and not capabilities["warp_cli"]:
            raise RuntimeError("Cloudflare WARP is required but warp-cli is unavailable. Use --install-warp or install it first.")

        prerequisite_command = platform_prerequisite_command(capabilities) if backend == "python" else None
        if backend == "python" and args.apply and args.install_prerequisites:
            if prerequisite_command is None and not capabilities.get("git"):
                raise RuntimeError("No supported automatic prerequisite installer is available on this platform")
            if prerequisite_command:
                run(prerequisite_command)
                capabilities = detect()
        elif backend == "python" and args.apply and prerequisite_command:
            raise RuntimeError("Native SearXNG requires build prerequisites; rerun with --install-prerequisites after approval.")
        if backend == "python" and args.apply and not capabilities.get("git"):
            raise RuntimeError("git is still unavailable after prerequisite installation")

        warp_mode = research_runtime.warp_mode_status() if capabilities["warp_cli"] else {
            "available": False, "mode": "unavailable", "proxy_url": None, "detail": "warp-cli not found",
        }
        desired_proxy = research_runtime.desired_proxy_for_backend(warp_mode, backend)
        secret = secrets.token_hex(32)
        paths = (
            prepare_docker(
                root, secret, args.searxng_image, normalized_base_url, write=args.apply,
                warp_proxy=desired_proxy.get("proxy_url"),
            )
            if backend == "docker"
            else prepare_python(
                root, secret, args.searxng_ref, normalized_base_url, write=args.apply,
                warp_proxy=desired_proxy.get("proxy_url"),
            )
        )
        runtime_paths = stage_runtime_scripts(root, write=args.apply)
        config_path = root / "config.json"
        config_path_for_rollback = config_path
        config_existed_before = config_path.exists()
        existing = load_existing_config(config_path)
        existing_interface = existing.get("interface") if isinstance(existing.get("interface"), dict) else {}
        interface_mode = str(existing_interface.get("mode", "simple")).strip().casefold()
        if interface_mode not in {"simple", "advanced"}:
            interface_mode = "simple"
        backup = backup_config(config_path) if args.apply and config_path.exists() else None
        backup_for_rollback = backup
        agent_capabilities = cp.probe(
            sessions_spawn=args.sessions_spawn, show_widget=args.show_widget, image_generate=args.image_generate,
            vision_capable=args.vision_capable, timeout=args.capability_timeout,
        )
        update: dict[str, Any] = {
            "config_version": max(5, int(existing.get("config_version", 0) or 0)),
            "worldbuilder_version": VERSION,
            "workspace": str(root),
            "research": {
                "required_for_public_web": True,
                "backend": backend,
                "base_url": normalized_base_url,
                "egress": "warp",
                "warp_mode_at_setup": warp_mode,
                "warp_proxy_binding": desired_proxy,
                "paths": {**paths, **runtime_paths},
                "setup_verified": False,
            },
            "capabilities_at_setup": capabilities,
            "agent_capabilities": agent_capabilities,
            "interface": {
                "mode": interface_mode,
            },
            "orchestration": {
                "max_subagents": 20,
                "discovery_ramp": [4, 10, 20],
                "health_gate_between_waves": True,
                "target_pages_per_discovery_worker": 75,
            },
        }
        config = deep_merge(existing, update)
        if args.apply:
            atomic_write_json(config_path, config)
            config_written = True

        actions: list[str] = []
        if args.apply:
            if backend == "docker":
                config["research"]["docker_daemon"] = ensure_docker_daemon(capabilities)
                config["research"]["docker_startup"] = enable_docker_startup(capabilities)
                pinned = resolve_docker_digest(args.searxng_image)
                paths["pinned_image"] = pinned
                atomic_write_text(
                    Path(paths["compose_file"]),
                    compose_text(pinned, host_port=int(paths["host_port"]), base_url=normalized_base_url),
                )
                run(["docker", "compose", "-f", paths["compose_file"], "up", "-d"])
                actions.append(f"started SearXNG Docker image pinned to {pinned}")
            else:
                resolved = install_python_source(paths)
                paths["resolved_commit"] = resolved
                actions.append(f"installed SearXNG source at pinned commit {resolved}")
            config["research"]["paths"] = {**paths, **runtime_paths}
            config["research"]["managed_stack_path"] = paths.get("stack_dir") or paths.get("source_dir")

            if not args.skip_openclaw:
                if not capabilities["openclaw"]:
                    raise RuntimeError("OpenClaw CLI is unavailable; rerun after OpenClaw is installed or use --skip-openclaw explicitly.")
                config["research"]["openclaw"] = configure_openclaw(config["research"]["base_url"])
                actions.append("installed and explicitly selected the OpenClaw SearXNG provider")
            else:
                config["research"]["openclaw"] = {"skipped": True}

        startup: dict[str, Any] | None = None
        if not args.skip_startup:
            startup = register_startup(root, config_path, Path(runtime_paths["ensure_script"]), capabilities["system"], apply=args.apply)
            config["research"]["startup"] = startup

        if args.apply:
            atomic_write_json(config_path, config)
            config_written = True
        preflight_report: dict[str, Any] | None = None
        if args.apply:
            ensure = Path(runtime_paths["ensure_script"])
            proc = run([sys.executable, str(ensure), "--config", str(config_path), "--start", "--preflight"], check=False)
            if proc.returncode != 0:
                raise RuntimeError(f"Research stack start/preflight failed:\n{proc.stdout}\n{proc.stderr}")
            try:
                preflight_report = json.loads(proc.stdout)
            except json.JSONDecodeError:
                preflight_report = {"raw": proc.stdout[-4000:]}
            config = load_existing_config(config_path)
            config.setdefault("research", {})["setup_verified"] = True
            config["research"]["verified_at"] = now_stamp()
            atomic_write_json(config_path, config)
            config_written = True

        tool_result_cap: dict[str, Any] = {"status": "not_run", "detail": "the diagnostic runs during setup with --apply"}
        if args.apply and not args.skip_openclaw:
            try:
                tool_result_cap = tool_result_cap_status()
            except (OSError, RuntimeError) as exc:
                tool_result_cap = {"status": "error", "detail": str(exc)}

        output = {
            "status": "applied" if args.apply else "planned",
            "backend": backend,
            "manual_steps": list(MANUAL_STEPS),
            "openclaw_tuning": (
                {"planned": [{"key": k, "value": v, "why": w} for k, v, w in PERFORMANCE_TUNING],
                 "advisory_only": [{"key": k, "guidance": g} for k, g in ADVISORY_ONLY],
                 "scope_note": "agents.defaults.* keys apply to every agent on this gateway."}
                if not args.apply and not args.skip_openclaw else None
            ),
            "config": str(config_path),
            "config_backup": str(backup) if backup else None,
            "startup": startup,
            "actions": ([warp_install_result] if warp_install_result else []) + actions,
            "prerequisite_command": prerequisite_command if backend == "python" else None,
            "preflight": preflight_report,
            "tool_result_cap": tool_result_cap,
            "preserved_config_keys": sorted(set(existing) - set(update)),
            "next": ([
                "Set OpenClaw Settings -> Context Profile to Code Agent; it cannot be set from the CLI.",
            ] if args.apply else [
                "Review this plan and rerun with --apply after approval.",
                "Setup applies OpenClaw performance tuning automatically; Context Profile stays manual.",
                "For the Python backend on Linux, also approve --install-prerequisites.",
                "Use --install-warp only after approving the official WARP client installation.",
            ]),
        }
        print(json.dumps(output, indent=2))
        return 0
    except (OSError, json.JSONDecodeError, RuntimeError, ValueError) as exc:
        rollback = "not-needed"
        if args.apply and config_written and config_path_for_rollback is not None:
            try:
                if backup_for_rollback is not None and backup_for_rollback.exists():
                    shutil.copy2(backup_for_rollback, config_path_for_rollback)
                    rollback = f"restored {backup_for_rollback.name}"
                elif not config_existed_before and config_path_for_rollback.exists():
                    config_path_for_rollback.unlink()
                    rollback = "removed incomplete new config"
            except OSError as rollback_exc:
                rollback = f"rollback failed: {rollback_exc}"
        print(f"ERROR: {exc}\nCONFIG ROLLBACK: {rollback}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
