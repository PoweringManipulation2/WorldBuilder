#!/usr/bin/env python3
"""Validate and export reusable WorldBuilder guided-build templates.

A build template is a named bundle of setup-page defaults. Applying one never
marks a setup page complete and never bypasses the normal confirmation flow.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from setup_state import (
    TEMPLATE_CONTRACT,
    export_template,
    load_template,
)
from wb_common import WorldBuilderError


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    validate = sub.add_parser("validate", help="Validate one reusable build-template JSON file.")
    validate.add_argument("--template", required=True)
    export = sub.add_parser("export", help="Export defaults from finalized setup settings.")
    export.add_argument("--settings", required=True, help="Finalized worldbuilder-build-settings JSON.")
    export.add_argument("--name", required=True)
    export.add_argument("--description", default="")
    export.add_argument("--output", required=True)
    args = parser.parse_args()
    try:
        if args.command == "validate":
            path = Path(args.template).expanduser().resolve()
            template, source_sha, normalized_sha = load_template(path)
            result = {
                "status": "valid",
                "contract": TEMPLATE_CONTRACT,
                "name": template["name"],
                "template": str(path),
                "sha256": source_sha,
                "normalized_sha256": normalized_sha,
                "default_count": len(template["defaults"]),
            }
        else:
            result = export_template(
                Path(args.settings), Path(args.output), args.name, args.description
            )
        print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
        return 0
    except (WorldBuilderError, OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
