#!/usr/bin/env python3
"""Prune revamp: Tier 0 detectors, provably lossless, no content change.

Four Tier 0 opportunities per the plan: keyword collision tightening,
depth restratification, constant demotion, inclusion grouping. This
module builds the first three as mechanical, structural detectors.
Inclusion grouping is deferred: "these entries serve the same purpose"
is closer to a content judgment than the other three, and deserves its
own careful pass rather than a rushed structural proxy.

Every detector here follows the same discipline as ancestor_redundancy.py:
it identifies structural opportunities and reports them, never executes a
change itself (that is artifact_edit.py's job, once a human or auditor
decides) and never judges whether an opportunity is a good idea beyond
what is mechanically checkable.
"""
from __future__ import annotations

from typing import Any


def keyword_collision_candidates(manifest: dict[str, Any]) -> dict[str, list[str]]:
    """Every key shared by two or more entries, and which UIDs share it.
    This is exactly what budget_contract.py's common_ambiguous_term
    simulation already seeds on; reported here as a direct, browsable
    opportunity list rather than only as a single worst-case number.
    Tightening a shared key on one of the listed UIDs (away from the
    collision) is Tier 0: it changes no content, only reduces
    activation-pressure overlap.
    """
    from budget_contract import uid_key
    from budget_semantics import manifest_rows as _manifest_rows, entry_keys as _keys

    key_owners: dict[str, list[str]] = {}
    for row in _manifest_rows(manifest):
        uid = uid_key(row.get("uid", row.get("id")))
        for key in _keys(row):
            key_owners.setdefault(key, []).append(uid)
    return {key: sorted(owners) for key, owners in key_owners.items() if len(owners) > 1}


def dead_entry_candidates(plan: dict[str, Any], manifest: dict[str, Any], before_data: dict[str, Any]) -> list[dict[str, Any]]:
    """Entries that never activate in any of the 7 baseline simulations,
    a structural fact, computed from the same run_simulations machinery
    worst_case_after_pruning already uses.

    The plan itself names the classic prune mistake here: conflating
    "genuinely unwanted" (delete candidate) with "good entry, wrong keys"
    (key-repair candidate) and deleting the second kind by accident. This
    function reports which case is which; it decides neither. Whether
    the entry's own declared keys appear anywhere in its own content is a
    mechanical, string-level proxy, not a judgment about whether the
    content is good: keys_appear_in_own_content=False is a signal the
    keys may not match what this entry is actually about (worth a repair
    look); True does not rule out either case, it just means this
    particular signal did not fire. An auditor reads the signal; this
    function never classifies the entry itself.
    """
    from budget_contract import run_simulations, uid_key
    from budget_semantics import manifest_rows as _manifest_rows, required_edges as _required_edges
    from wb_common import iter_entries, canonical_entry_identity

    rows = _manifest_rows(manifest)
    edges, _required = _required_edges(manifest)
    token_map = {uid_key(row.get("uid", row.get("id"))): 1 for row in rows}  # activation reachability only, not real costs
    simulations = run_simulations(rows, edges, token_map, plan["targets"], plan.get("project_simulations", []))
    ever_activated: set[str] = set()
    for sim in simulations:
        ever_activated.update(str(u) for u in sim.get("activated_uids", []))

    actual_by_uid: dict[str, dict[str, Any]] = {}
    for ref in iter_entries(before_data):
        identity = canonical_entry_identity(ref.entry)
        if identity is not None:
            actual_by_uid[uid_key(identity)] = ref.entry

    candidates: list[dict[str, Any]] = []
    for row in rows:
        uid = uid_key(row.get("uid", row.get("id")))
        if uid in ever_activated:
            continue
        actual = actual_by_uid.get(uid)
        declared_keys = [str(k) for k in (row.get("emit", {}) or {}).get("keys", []) if str(k).strip()]
        content = str(actual.get("content", "")) if actual else ""
        folded_content = content.casefold()
        overlap = any(key.casefold() in folded_content for key in declared_keys) if declared_keys else None
        candidates.append({
            "uid": uid, "declared_keys": declared_keys,
            "keys_appear_in_own_content": overlap,
            "note": (
                "False is a signal the keys may not match this entry's actual content, worth a repair "
                "look before considering deletion. True, or None (no keys declared at all), does not rule "
                "out either case; this is a signal to check, not a verdict."
            ),
        })
    return candidates


def overactive_entry_candidates(plan: dict[str, Any], manifest: dict[str, Any], *, threshold_fraction: float = 0.5) -> list[dict[str, Any]]:
    """Entries activated in most of the 7 baseline simulations, a
    structural, countable fact. Reported as a signal worth reconsidering
    (constant instead of keyword-triggered, or the keys are simply too
    broad). Neither decision is made here; which one, if either, fits
    is left to whoever reviews the candidate.
    """
    from budget_contract import run_simulations, uid_key
    from budget_semantics import manifest_rows as _manifest_rows, required_edges as _required_edges

    rows = _manifest_rows(manifest)
    edges, _required = _required_edges(manifest)
    token_map = {uid_key(row.get("uid", row.get("id"))): 1 for row in rows}
    simulations = run_simulations(rows, edges, token_map, plan["targets"], plan.get("project_simulations", []))
    if not simulations:
        return []

    activation_counts: dict[str, int] = {}
    for sim in simulations:
        for uid in {str(u) for u in sim.get("activated_uids", [])}:
            activation_counts[uid] = activation_counts.get(uid, 0) + 1

    threshold = threshold_fraction * len(simulations)
    candidates: list[dict[str, Any]] = []
    for row in rows:
        uid = uid_key(row.get("uid", row.get("id")))
        if row.get("emit", {}).get("constant"):
            continue  # already constant; "should be constant" does not apply
        count = activation_counts.get(uid, 0)
        if count >= threshold:
            candidates.append({
                "uid": uid, "activated_in_simulations": count, "total_simulations": len(simulations),
            })
    return candidates


def constant_demotion_candidates(manifest: dict[str, Any]) -> list[dict[str, Any]]:
    """Entries marked constant (always active, regardless of keyword
    match) that also declare real keywords of their own, meaning they
    could, in principle, activate the ordinary way instead. Demoting one
    changes no content, only its activation mode; it is Tier 0 only
    because nothing about the entry's prose moves.

    Deliberately excluded from candidacy: entries declaring a protected
    category (protected_categories.py's own set): world_invariants,
    era_isolation, and the rest exist specifically to keep certain content
    unconditionally present, and this detector must not suggest undoing
    that. A candidate here is a structural opportunity to review, not an
    instruction to demote; whether demotion is actually a good idea
    (does the keyword coverage reliably catch every situation the
    constant was covering?) is a judgment call for whoever reviews the
    list, not something this function decides.
    """
    from budget_contract import protected_categories, uid_key
    from budget_semantics import manifest_rows as _manifest_rows, entry_is_constant as _is_constant, entry_keys as _keys, required_edges as _required_edges

    _edges, required_edge_uids = _required_edges(manifest)
    candidates: list[dict[str, Any]] = []
    for row in _manifest_rows(manifest):
        uid = uid_key(row.get("uid", row.get("id")))
        if not _is_constant(row):
            continue
        categories = protected_categories(row, required_edge_uids)
        if categories:
            continue
        keys = _keys(row)
        if keys:
            candidates.append({"uid": uid, "declared_keys": keys})
    return candidates


def depth_restratification_candidates(manifest: dict[str, Any]) -> list[dict[str, Any]]:
    """Entries reachable only via recursion (they have at least one
    incoming activation-graph edge) but not marked delay_until_recursion.
    Marking one is Tier 0: it changes no content, only makes an already-
    true structural fact explicit; and doing so is what makes the entry
    eligible for ancestor_redundancy_candidates' dominator guarantee in
    the first place (see ancestor_redundancy.py: without the marker, an
    entry could in principle also fire directly, so its dominators are
    not actually guaranteed).

    An entry with zero incoming edges is not a candidate: it is not
    reachable via recursion at all in this manifest's current graph, so
    marking it delay_until_recursion would make it unreachable outright
    ; activation_map_gate.py's own validation already rejects exactly
    this combination.
    """
    from budget_contract import uid_key
    from budget_semantics import manifest_rows as _manifest_rows, required_edges as _required_edges

    graph_edges, _required = _required_edges(manifest)
    incoming: dict[str, int] = {}
    for edge in graph_edges:
        target = uid_key(edge.get("target_uid"))
        incoming[target] = incoming.get(target, 0) + 1

    candidates: list[dict[str, Any]] = []
    for row in _manifest_rows(manifest):
        uid = uid_key(row.get("uid", row.get("id")))
        already_marked = bool((row.get("emit") or {}).get("delay_until_recursion"))
        if already_marked:
            continue
        if incoming.get(uid, 0) > 0:
            candidates.append({"uid": uid, "incoming_edge_count": incoming[uid]})
    return candidates
