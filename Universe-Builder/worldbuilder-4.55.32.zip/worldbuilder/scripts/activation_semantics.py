#!/usr/bin/env python3
"""Public activation/default-resolution semantics shared across WorldBuilder gates.

Promoted from ``activation_map_gate.py`` during the Batch 23 maintainability
refactor so dependent modules use an intentional public contract rather than
private implementation helpers. Behavior is intentionally unchanged.
"""
from __future__ import annotations

from typing import Any

from wb_common import WorldBuilderError, uid_key

# Sentinel distinguishing "key absent" from "key present with value None".
_MISSING = object()

ALLOWED_STRATEGIES = {"constant", "keyword", "hybrid", "vector-only", "manual", "disabled"}

ALLOWED_ROLES = {"root", "seed", "anchor", "intermediary", "leaf", "blocked"}

BASE_DEFAULTS: dict[str, Any] = {
    "strategy": "keyword",
    "recursion_role": "leaf",
    "constant": False,
    "enabled": True,
    "vectorized": False,
    "selective": False,
    "secondary_logic": None,
    "match_scenario": False,
    "position": None,
    "insertion_order": None,
    "priority": None,
    "use_probability": False,
    "probability": 100,
    "prevent_recursion": False,
    "exclude_recursion": False,
    "delay_until_recursion": False,
    "sticky": 0,
    "cooldown": 0,
    "delay": 0,
    "depth": None,
    "role": None,
    "group": None,
    "group_weight": 100,
    "group_override": False,
    "group_scoring": False,
    "case_sensitive": False,
    "use_regex": False,
    "character_filter": None,
    "generation_triggers": [],
    "automation_id": None,
    "outlet": None,
}


def list_strings(value: Any, field: str) -> list[str]:
    if value is None:
        return []
    if not isinstance(value, list) or any(not isinstance(item, str) or not item.strip() for item in value):
        raise WorldBuilderError(f"{field} must be an array of non-empty strings, found {value!r}")
    seen: set[str] = set()
    result: list[str] = []
    for item in value:
        cleaned = item.strip()
        folded = cleaned.casefold()
        if folded in seen:
            raise WorldBuilderError(f"{field} contains duplicate term {cleaned!r}")
        seen.add(folded)
        result.append(cleaned)
    return result

def manifest_entries(manifest: dict[str, Any]) -> list[dict[str, Any]]:
    entries = manifest.get("entries")
    if not isinstance(entries, list) or not entries:
        raise WorldBuilderError(f"manifest 'entries' must be a non-empty array, found {entries!r}")
    if any(not isinstance(row, dict) for row in entries):
        raise WorldBuilderError(f"every manifest entry must be a JSON object; found a non-object entry among {[type(row).__name__ for row in entries]}")
    return entries

def emit_config(entry: dict[str, Any]) -> dict[str, Any]:
    value = entry.get("emit")
    if value is None:
        return {}
    if not isinstance(value, dict):
        raise WorldBuilderError(f"manifest entry {uid_key(entry.get('uid', entry.get('id')))}'s 'emit' must be an object, found {type(value).__name__}")
    return value

def extension_config(emit: dict[str, Any]) -> dict[str, Any]:
    value = emit.get("extensions")
    return value if isinstance(value, dict) else {}

def first_value(container: dict[str, Any], names: tuple[str, ...], default: Any = None) -> Any:
    for name in names:
        if name in container:
            return container[name]
    return default

def setting(emit: dict[str, Any], names: tuple[str, ...], default: Any = None) -> Any:
    # Presence is what counts, not the value: the first present key wins even
    # when its value is an explicit None (which genuinely means "set to
    # nothing"), and only an absent key falls through to the next level.
    # Batch 52: the sentinel keeps a present-but-None emit value distinct
    # from a missing one: treating None as "keep looking" silently
    # overrode an explicit emit-level null with the extensions-level or
    # layer default.
    value = first_value(emit, names, _MISSING)
    if value is not _MISSING:
        return value
    return first_value(extension_config(emit), names, default)

def manifest_activation(entry: dict[str, Any]) -> dict[str, Any]:
    value = entry.get("activation")
    if not isinstance(value, dict):
        raise WorldBuilderError(f"manifest entry {uid_key(entry.get('uid', entry.get('id')))} has no 'activation' object: every entry needs one recording its strategy and recursion_role")
    strategy = value.get("strategy")
    role = value.get("recursion_role")
    if strategy not in ALLOWED_STRATEGIES:
        raise WorldBuilderError(f"manifest entry {uid_key(entry.get('uid', entry.get('id')))}'s activation.strategy is {strategy!r}; must be one of {sorted(ALLOWED_STRATEGIES)}")
    if role not in ALLOWED_ROLES:
        raise WorldBuilderError(f"manifest entry {uid_key(entry.get('uid', entry.get('id')))}'s activation.recursion_role is {role!r}; must be one of {sorted(ALLOWED_ROLES)}")
    emits = list_strings(value.get("emits", []), "activation.emits")
    forbidden = list_strings(value.get("forbidden_emits", []), "activation.forbidden_emits")
    overlap = sorted({item.casefold() for item in emits}.intersection(item.casefold() for item in forbidden))
    if overlap:
        raise WorldBuilderError(f"manifest entry {uid_key(entry.get('uid', entry.get('id')))}'s activation.emits and forbidden_emits overlap on: " + ", ".join(overlap) + "; a term cannot be both required and forbidden")
    return {"strategy": strategy, "recursion_role": role, "emits": emits, "forbidden_emits": forbidden}

def profile_defaults(profile: dict[str, Any], layer: str) -> dict[str, Any]:
    defaults = profile.get("defaults")
    if not isinstance(defaults, dict):
        raise WorldBuilderError(f"default-profile.json's 'defaults' must be an object, found {type(defaults).__name__} (checking layer {layer!r})")
    result = dict(BASE_DEFAULTS)
    result.update(defaults)
    overrides = profile.get("layer_overrides")
    if isinstance(overrides, dict) and isinstance(overrides.get(layer), dict):
        result.update(overrides[layer])
    return result

def resolved_emit(entry: dict[str, Any], defaults: dict[str, Any]) -> dict[str, Any]:
    emit = emit_config(entry)
    keys = list_strings(first_value(emit, ("keys", "key"), []), "emit.keys")
    secondary = list_strings(first_value(emit, ("secondary_keys", "keysecondary"), []), "emit.secondary_keys")
    result = {
        "constant": bool(setting(emit, ("constant",), defaults.get("constant", False))),
        "enabled": bool(setting(emit, ("enabled",), defaults.get("enabled", True))),
        "vectorized": bool(setting(emit, ("vectorized",), defaults.get("vectorized", False))),
        "primary_keywords": keys,
        "secondary_keywords": secondary,
        "selective": bool(setting(emit, ("selective",), defaults.get("selective", False))),
        "secondary_logic": setting(emit, ("selectiveLogic", "selective_logic"), defaults.get("secondary_logic")),
        "match_scenario": bool(setting(emit, ("match_scenario", "matchScenario"), defaults.get("match_scenario", False))),
        "position": setting(emit, ("position",), defaults.get("position")),
        "insertion_order": setting(emit, ("insertion_order", "order"), defaults.get("insertion_order")),
        "priority": setting(emit, ("priority",), defaults.get("priority")),
        "use_probability": bool(setting(emit, ("useProbability", "use_probability"), defaults.get("use_probability", False))),
        "probability": setting(emit, ("probability",), defaults.get("probability", 100)),
        "prevent_recursion": bool(setting(emit, ("prevent_recursion", "preventRecursion"), defaults.get("prevent_recursion", False))),
        "exclude_recursion": bool(setting(emit, ("exclude_recursion", "excludeRecursion"), defaults.get("exclude_recursion", False))),
        "delay_until_recursion": bool(setting(emit, ("delay_until_recursion", "delayUntilRecursion"), defaults.get("delay_until_recursion", False))),
        "sticky": setting(emit, ("sticky",), defaults.get("sticky", 0)),
        "cooldown": setting(emit, ("cooldown",), defaults.get("cooldown", 0)),
        "delay": setting(emit, ("delay",), defaults.get("delay", 0)),
        "depth": setting(emit, ("depth",), defaults.get("depth")),
        "role": setting(emit, ("role",), defaults.get("role")),
        "group": setting(emit, ("group",), defaults.get("group")),
        "group_weight": setting(emit, ("group_weight", "groupWeight"), defaults.get("group_weight", 100)),
        "group_override": bool(setting(emit, ("group_override", "groupOverride"), defaults.get("group_override", False))),
        "group_scoring": bool(setting(emit, ("group_scoring", "groupScoring"), defaults.get("group_scoring", False))),
        "case_sensitive": bool(setting(emit, ("case_sensitive",), defaults.get("case_sensitive", False))),
        "use_regex": bool(setting(emit, ("use_regex",), defaults.get("use_regex", False))),
        "character_filter": setting(emit, ("character_filter",), defaults.get("character_filter")),
        "generation_triggers": setting(emit, ("generation_triggers",), defaults.get("generation_triggers", [])),
        "automation_id": setting(emit, ("automation_id", "automationId"), defaults.get("automation_id")),
        "outlet": setting(emit, ("outlet",), defaults.get("outlet")),
    }
    if result["secondary_logic"] is not None and not result["selective"]:
        raise WorldBuilderError(f"manifest entry {uid_key(entry.get('uid', entry.get('id')))} configures secondary_logic ({result['secondary_logic']!r}) but selective is false: secondary_logic only has an effect when selective is true")
    if not isinstance(result["probability"], int) or isinstance(result["probability"], bool) or not 0 <= result["probability"] <= 100:
        raise WorldBuilderError(f"manifest entry {uid_key(entry.get('uid', entry.get('id')))}'s probability must be an integer from 0 to 100, found {result['probability']!r}")
    for field in ("sticky", "cooldown", "delay"):
        if not isinstance(result[field], int) or isinstance(result[field], bool) or result[field] < 0:
            raise WorldBuilderError(f"manifest entry {uid_key(entry.get('uid', entry.get('id')))}'s {field} must be a non-negative integer, found {result[field]!r}")
    if not isinstance(result["generation_triggers"], list):
        raise WorldBuilderError(f"manifest entry {uid_key(entry.get('uid', entry.get('id')))}'s generation_triggers must be an array, found {type(result['generation_triggers']).__name__}")
    return result
