#!/usr/bin/env python3
"""Persist and reuse significant Guided Mode decisions.

`decision-log.json` is the canonical append-only Guided Mode decision artifact.
Batch 23 transformation maps are accepted only as migration input. Exact
normalized identity is used for reuse; fuzzy similarity is never authority.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from pathlib import Path
from typing import Any, Iterable

from wb_common import WorldBuilderError, atomic_write_json, load_build_state, load_json, now_iso, resolve_state_path, sha256_file

CONTRACT = "worldbuilder-guided-decision-log-v1"
KIND = "worldbuilder-guided-decision-log"
LOG_VERSION = 1
LEGACY_CONTRACT = "worldbuilder-transformation-map-v1"
LEGACY_KIND = "worldbuilder-transformation-map"
LEGACY_VERSION = 1

DECISION_KINDS = (
    "transform",
    "accepted_merge",
    "rejected_concept",
    "renamed_entity",
    "canon_deviation",
    "exclusion",
)

_REQUIRED_FIELDS: dict[str, tuple[str, ...]] = {
    "transform": ("source_concept", "target_concept", "transformation_type", "rationale"),
    "accepted_merge": ("canonical_entity", "merged_entities", "rationale"),
    "rejected_concept": ("concept", "rationale"),
    "renamed_entity": ("original_name", "canonical_name", "rationale"),
    "canon_deviation": ("topic", "deviation", "rationale"),
    "exclusion": ("subject", "rationale"),
}

_IDENTITY_FIELDS: dict[str, tuple[str, ...]] = {
    "transform": ("source_concept", "target_concept", "transformation_type"),
    "accepted_merge": ("canonical_entity", "merged_entities"),
    "rejected_concept": ("concept",),
    "renamed_entity": ("original_name", "canonical_name"),
    "canon_deviation": ("topic", "deviation"),
    "exclusion": ("subject",),
}

_PREFIX = {
    "transform": "tm-",
    "accepted_merge": "gd-merge-",
    "rejected_concept": "gd-reject-",
    "renamed_entity": "gd-rename-",
    "canon_deviation": "gd-canon-",
    "exclusion": "gd-exclude-",
}


def normalize_text(value: Any, label: str) -> str:
    text = re.sub(r"\s+", " ", str(value or "").strip())
    if not text:
        raise WorldBuilderError(f"{label} must be non-empty")
    return text.casefold()


def clean_text(value: Any, label: str) -> str:
    text = re.sub(r"\s+", " ", str(value or "").strip())
    if not text:
        raise WorldBuilderError(f"{label} must be non-empty")
    return text


def _normalize_list(value: Any, label: str) -> tuple[str, ...]:
    if not isinstance(value, list) or not value:
        raise WorldBuilderError(f"{label} must be a non-empty list")
    normalized = sorted({normalize_text(item, label) for item in value})
    if not normalized:
        raise WorldBuilderError(f"{label} must contain at least one non-empty value")
    return tuple(normalized)


def normalized_identity(kind: str, payload: dict[str, Any]) -> tuple[Any, ...]:
    if kind not in _IDENTITY_FIELDS:
        raise WorldBuilderError(f"unsupported Guided decision kind: {kind}")
    parts: list[Any] = [kind]
    for field in _IDENTITY_FIELDS[kind]:
        value = payload.get(field)
        if field == "merged_entities":
            parts.append(_normalize_list(value, field))
        else:
            parts.append(normalize_text(value, field))
    return tuple(parts)


def decision_id(kind: str, payload: dict[str, Any]) -> str:
    identity = normalized_identity(kind, payload)
    # Batch 23 shipped tm-* IDs before the umbrella log existed. Preserve that
    # exact hash input (source, target, type) so migration never renumbers a
    # transformation decision. New decision kinds include their kind in the
    # hash input because they have no legacy identifier to preserve.
    hash_identity = identity[1:] if kind == "transform" else identity
    encoded = json.dumps(hash_identity, ensure_ascii=False, separators=(",", ":"))
    return _PREFIX[kind] + hashlib.sha256(encoded.encode("utf-8")).hexdigest()[:16]


def _canonical_payload(kind: str, payload: dict[str, Any]) -> dict[str, Any]:
    if kind not in DECISION_KINDS:
        raise WorldBuilderError(f"unsupported Guided decision kind: {kind}")
    allowed = set(_REQUIRED_FIELDS[kind])
    unexpected = sorted(set(payload) - allowed)
    if unexpected:
        raise WorldBuilderError(f"{kind} decision has unsupported field(s): {', '.join(unexpected)}")
    missing = [field for field in _REQUIRED_FIELDS[kind] if field not in payload]
    if missing:
        raise WorldBuilderError(f"{kind} decision is missing field(s): {', '.join(missing)}")
    clean: dict[str, Any] = {}
    for field in _REQUIRED_FIELDS[kind]:
        value = payload[field]
        if field == "merged_entities":
            if not isinstance(value, list) or not value:
                raise WorldBuilderError("merged_entities must be a non-empty list")
            seen: set[str] = set()
            rows: list[str] = []
            for item in value:
                text = clean_text(item, "merged_entities")
                key = text.casefold()
                if key not in seen:
                    seen.add(key)
                    rows.append(text)
            clean[field] = rows
        else:
            clean[field] = clean_text(value, field)
    return clean


def decision_log_path(root: Path, state: dict[str, Any]) -> Path:
    configured = resolve_state_path(root, state, "decision_log", required=False)
    return configured if configured is not None else root / "artifacts" / "decision-log.json"


def legacy_map_path(root: Path, state: dict[str, Any]) -> Path:
    configured = resolve_state_path(root, state, "transformation_map", required=False)
    return configured if configured is not None else root / "artifacts" / "transformation-map.json"


def empty_log(build_id: str | None) -> dict[str, Any]:
    return {
        "kind": KIND,
        "decision_log_version": LOG_VERSION,
        "contract": CONTRACT,
        "build_id": build_id,
        "entries": [],
    }


def _validate_entry(row: Any, index: int) -> dict[str, Any]:
    if not isinstance(row, dict):
        raise WorldBuilderError(f"decision-log entry {index} must be an object")
    kind = str(row.get("kind") or "")
    if kind not in DECISION_KINDS:
        raise WorldBuilderError(f"decision-log entry {index} has unsupported kind {kind!r}")
    payload = {field: row.get(field) for field in _REQUIRED_FIELDS[kind]}
    clean = _canonical_payload(kind, payload)
    expected = decision_id(kind, clean)
    if row.get("id") != expected:
        raise WorldBuilderError(f"decision-log entry {index} id does not match its normalized identity")
    if not str(row.get("created_at") or "").strip():
        raise WorldBuilderError(f"decision-log entry {index} has no created_at")
    return row


def validate_log(data: Any, *, build_id: str | None = None) -> dict[str, Any]:
    if not isinstance(data, dict):
        raise WorldBuilderError("decision-log.json must be a JSON object")
    if data.get("kind") != KIND or data.get("contract") != CONTRACT or data.get("decision_log_version") != LOG_VERSION:
        raise WorldBuilderError("decision-log.json has an unsupported contract")
    if build_id is not None and data.get("build_id") not in {None, build_id}:
        raise WorldBuilderError("decision-log.json belongs to a different build")
    rows = data.get("entries")
    if not isinstance(rows, list):
        raise WorldBuilderError("decision-log.json entries must be a list")
    seen_ids: set[str] = set()
    seen_identity: set[tuple[Any, ...]] = set()
    for index, row in enumerate(rows):
        _validate_entry(row, index)
        identity = normalized_identity(str(row["kind"]), row)
        if row["id"] in seen_ids or identity in seen_identity:
            raise WorldBuilderError("decision-log.json contains a duplicate normalized decision")
        seen_ids.add(row["id"])
        seen_identity.add(identity)
    migration = data.get("legacy_transformation_map")
    if migration is not None:
        if not isinstance(migration, dict) or migration.get("contract") != LEGACY_CONTRACT:
            raise WorldBuilderError("decision-log legacy transformation-map metadata is invalid")
        if not str(migration.get("path") or "").strip() or not str(migration.get("sha256") or "").strip():
            raise WorldBuilderError("decision-log legacy transformation-map metadata is incomplete")
    return data


def _validate_legacy_map(data: Any, *, build_id: str | None) -> dict[str, Any]:
    if not isinstance(data, dict):
        raise WorldBuilderError("legacy transformation-map.json must be a JSON object")
    if data.get("kind") != LEGACY_KIND or data.get("contract") != LEGACY_CONTRACT or data.get("map_version") != LEGACY_VERSION:
        raise WorldBuilderError("legacy transformation-map.json has an unsupported contract")
    if build_id is not None and data.get("build_id") not in {None, build_id}:
        raise WorldBuilderError("legacy transformation-map.json belongs to a different build")
    rows = data.get("mappings")
    if not isinstance(rows, list):
        raise WorldBuilderError("legacy transformation-map.json mappings must be a list")
    seen: set[str] = set()
    for index, row in enumerate(rows):
        if not isinstance(row, dict):
            raise WorldBuilderError(f"legacy transformation mapping {index} must be an object")
        payload = {
            "source_concept": row.get("source_concept"),
            "target_concept": row.get("target_concept"),
            "transformation_type": row.get("transformation_type"),
            "rationale": row.get("rationale"),
        }
        clean = _canonical_payload("transform", payload)
        expected = decision_id("transform", clean)
        if row.get("id") != expected:
            raise WorldBuilderError(f"legacy transformation mapping {index} id does not match its normalized key")
        if expected in seen:
            raise WorldBuilderError("legacy transformation-map.json contains a duplicate normalized mapping")
        seen.add(expected)
    return data


def _require_guided(state: dict[str, Any]) -> None:
    custom = state.get("custom_pipeline") if isinstance(state.get("custom_pipeline"), dict) else {}
    if custom.get("active") is not True:
        raise WorldBuilderError(
            "Guided decision logging is only valid for an active Guided/custom pipeline build. On an ordinary "
            "build, record audit-finding acceptances as `deferred` records in the patch log (see "
            "references/post-gen-audit.md, Finding reconciliation); verify_patches.py counts them in its "
            "accounting, so a deferral is a durable, verifiable acceptance."
        )


def _verify_recorded_log(root: Path, state: dict[str, Any], path: Path) -> None:
    metadata = (state.get("custom_pipeline") or {}).get("decision_log")
    if isinstance(metadata, dict) and metadata.get("sha256"):
        actual = sha256_file(path)
        if metadata.get("sha256") != actual:
            raise WorldBuilderError(
                "decision-log.json changed outside the recorded decision-log path; "
                "restore the recorded artifact or append a decision through the resolver"
            )


def _write_state_metadata(state_path: Path, root: Path, state: dict[str, Any], path: Path, data: dict[str, Any]) -> str:
    digest = sha256_file(path)
    custom = state.setdefault("custom_pipeline", {})
    custom["decision_log"] = {
        "contract": CONTRACT,
        "path": str(path.relative_to(root)).replace("\\", "/"),
        "sha256": digest,
        "decision_count": len(data.get("entries", [])),
        "append_only": True,
    }
    atomic_write_json(state_path, state)
    return digest


def _legacy_migration(root: Path, state_path: Path, state: dict[str, Any]) -> tuple[dict[str, Any], Path] | None:
    legacy = legacy_map_path(root, state)
    if not legacy.is_file():
        return None
    recorded = (state.get("custom_pipeline") or {}).get("transformation_map")
    if isinstance(recorded, dict) and recorded.get("sha256") and recorded.get("sha256") != sha256_file(legacy):
        raise WorldBuilderError("legacy transformation-map.json changed outside its recorded resolver path; migration refused")
    legacy_data = _validate_legacy_map(load_json(legacy), build_id=state.get("build_id"))
    legacy_digest = sha256_file(legacy)
    data = empty_log(state.get("build_id"))
    for row in legacy_data.get("mappings", []):
        entry = {
            "id": row["id"],
            "kind": "transform",
            "source_concept": clean_text(row.get("source_concept"), "source_concept"),
            "target_concept": clean_text(row.get("target_concept"), "target_concept"),
            "transformation_type": clean_text(row.get("transformation_type"), "transformation_type"),
            "rationale": clean_text(row.get("rationale"), "rationale"),
            "created_at": str(row.get("created_at") or legacy_data.get("updated_at") or now_iso()),
        }
        data["entries"].append(entry)
    data["legacy_transformation_map"] = {
        "contract": LEGACY_CONTRACT,
        "path": str(legacy.relative_to(root)).replace("\\", "/"),
        "sha256": legacy_digest,
        "mapping_count": len(legacy_data.get("mappings", [])),
        "migration_mode": "read-once-preserve-bytes",
    }
    data["updated_at"] = now_iso()
    path = decision_log_path(root, state)
    path.parent.mkdir(parents=True, exist_ok=True)
    atomic_write_json(path, data)
    _write_state_metadata(state_path, root, state, path, data)
    return data, path


def load_decision_log(root: Path, state: dict[str, Any]) -> tuple[dict[str, Any], Path]:
    path = decision_log_path(root, state)
    if not path.is_file():
        return empty_log(state.get("build_id")), path
    _verify_recorded_log(root, state, path)
    return validate_log(load_json(path), build_id=state.get("build_id")), path


def ensure_decision_log(state_path: Path, root: Path, state: dict[str, Any]) -> tuple[dict[str, Any], Path]:
    path = decision_log_path(root, state)
    if path.is_file():
        return load_decision_log(root, state)
    migrated = _legacy_migration(root, state_path, state)
    if migrated is not None:
        return migrated
    return empty_log(state.get("build_id")), path


def record_decision(build_state: str | Path, kind: str, payload: dict[str, Any]) -> dict[str, Any]:
    state_path = Path(build_state).resolve()
    root, state = load_build_state(state_path)
    _require_guided(state)
    clean = _canonical_payload(kind, payload)
    data, path = ensure_decision_log(state_path, root, state)
    identity = normalized_identity(kind, clean)
    for row in data.get("entries", []):
        if normalized_identity(str(row["kind"]), row) != identity:
            continue
        identity_fields = set(_IDENTITY_FIELDS[kind])
        for field in _REQUIRED_FIELDS[kind]:
            if field in identity_fields:
                # Identity fields already matched through normalized_identity();
                # preserve the first recorded spelling/capitalization rather
                # than treating case/whitespace normalization as a rewrite.
                continue
            existing = row.get(field)
            supplied = clean.get(field)
            if clean_text(existing, field) != clean_text(supplied, field):
                raise WorldBuilderError(
                    f"decision {row['id']} already exists with different {field}; "
                    "Guided decisions are immutable, so record a distinct identity when the intent changes"
                )
        if path.is_file() and not isinstance((state.get("custom_pipeline") or {}).get("decision_log"), dict):
            _write_state_metadata(state_path, root, state, path, data)
        return {
            "status": "reused",
            "decision": row,
            "decision_log": str(path.relative_to(root)).replace("\\", "/"),
            "decision_log_sha256": sha256_file(path) if path.is_file() else None,
        }
    entry = {"id": decision_id(kind, clean), "kind": kind, **clean, "created_at": now_iso()}
    data.setdefault("entries", []).append(entry)
    data["updated_at"] = now_iso()
    path.parent.mkdir(parents=True, exist_ok=True)
    atomic_write_json(path, data)
    digest = _write_state_metadata(state_path, root, state, path, data)
    return {
        "status": "recorded",
        "decision": entry,
        "decision_log": str(path.relative_to(root)).replace("\\", "/"),
        "decision_log_sha256": digest,
    }


def resolve_transform(
    build_state: str | Path,
    *,
    source_concept: str,
    target_concept: str,
    transformation_type: str,
    rationale: str | None = None,
) -> dict[str, Any]:
    state_path = Path(build_state).resolve()
    root, state = load_build_state(state_path)
    _require_guided(state)
    probe = {
        "source_concept": source_concept,
        "target_concept": target_concept,
        "transformation_type": transformation_type,
    }
    data, path = ensure_decision_log(state_path, root, state)
    identity = normalized_identity("transform", {**probe, "rationale": rationale or "placeholder"})
    for row in data.get("entries", []):
        if row.get("kind") != "transform" or normalized_identity("transform", row) != identity:
            continue
        if rationale is not None and str(rationale).strip() and clean_text(row["rationale"], "rationale") != clean_text(rationale, "rationale"):
            raise WorldBuilderError(
                f"decision {row['id']} already exists with a different rationale; "
                "Guided decisions are immutable, so use a distinct transformation identity when intent changes"
            )
        return {
            "status": "reused",
            "decision": row,
            "decision_log": str(path.relative_to(root)).replace("\\", "/"),
            "decision_log_sha256": sha256_file(path) if path.is_file() else None,
        }
    if rationale is None or not str(rationale).strip():
        raise WorldBuilderError("no matching transform decision exists; provide --rationale for the first confirmed use")
    return record_decision(build_state, "transform", {**probe, "rationale": rationale})


def consult_decision(build_state: str | Path, kind: str, identity_payload: dict[str, Any]) -> dict[str, Any]:
    state_path = Path(build_state).resolve()
    root, state = load_build_state(state_path)
    _require_guided(state)
    if kind not in DECISION_KINDS:
        raise WorldBuilderError(f"unsupported Guided decision kind: {kind}")
    expected_fields = set(_IDENTITY_FIELDS[kind])
    if set(identity_payload) != expected_fields:
        raise WorldBuilderError(
            f"{kind} consultation requires identity fields exactly: {', '.join(_IDENTITY_FIELDS[kind])}"
        )
    probe = dict(identity_payload)
    if "rationale" not in probe:
        probe["rationale"] = "consultation-placeholder"
    target = normalized_identity(kind, probe)
    data, path = ensure_decision_log(state_path, root, state)
    matches = [row for row in data.get("entries", []) if row.get("kind") == kind and normalized_identity(kind, row) == target]
    return {
        "status": "matched" if matches else "not_found",
        "decision_log": str(path.relative_to(root)).replace("\\", "/"),
        "decision_log_sha256": sha256_file(path) if path.is_file() else None,
        "matches": matches,
    }


def transformation_context(root: Path, state: dict[str, Any], decision_ids: Iterable[str]) -> dict[str, Any]:
    ids: list[str] = []
    for raw in decision_ids:
        value = str(raw or "").strip()
        if value and value not in ids:
            ids.append(value)
    if not ids:
        return {"used": False}
    state_path = root / "build-state.json"
    data, path = ensure_decision_log(state_path, root, state)
    if not path.is_file():
        raise WorldBuilderError("transformation IDs were supplied but decision-log.json does not exist")
    by_id = {str(row.get("id")): row for row in data.get("entries", []) if isinstance(row, dict) and row.get("kind") == "transform"}
    missing = [value for value in ids if value not in by_id]
    if missing:
        raise WorldBuilderError("unknown transformation decision ID(s): " + ", ".join(missing))
    return {
        "used": True,
        "contract": CONTRACT,
        "decision_log": str(path.relative_to(root)).replace("\\", "/"),
        "decision_log_sha256": sha256_file(path),
        # Backward-compatible field names for existing receipt consumers. They
        # point at the canonical decision log, not a newly-written map artifact.
        "map": str(path.relative_to(root)).replace("\\", "/"),
        "map_sha256": sha256_file(path),
        "mapping_ids": ids,
        "mappings": [
            {
                "id": row["id"],
                "source_concept": row["source_concept"],
                "target_concept": row["target_concept"],
                "transformation_type": row["transformation_type"],
            }
            for row in (by_id[value] for value in ids)
        ],
    }


def list_decisions(build_state: str | Path, *, kind: str | None = None) -> dict[str, Any]:
    state_path = Path(build_state).resolve()
    root, state = load_build_state(state_path)
    _require_guided(state)
    data, path = ensure_decision_log(state_path, root, state)
    rows = data.get("entries", [])
    if kind is not None:
        if kind not in DECISION_KINDS:
            raise WorldBuilderError(f"unsupported Guided decision kind: {kind}")
        rows = [row for row in rows if row.get("kind") == kind]
    return {
        "status": "ok",
        "decision_log": str(path.relative_to(root)).replace("\\", "/"),
        "decision_log_sha256": sha256_file(path) if path.is_file() else None,
        "decision_count": len(rows),
        "decisions": rows,
    }


def _json_object(raw: str, label: str) -> dict[str, Any]:
    try:
        value = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise WorldBuilderError(f"{label} must be valid JSON") from exc
    if not isinstance(value, dict):
        raise WorldBuilderError(f"{label} must be a JSON object")
    return value


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--build-state", required=True)
    sub = parser.add_subparsers(dest="command", required=True)
    record = sub.add_parser("record", help="append or reuse one typed Guided Mode decision")
    record.add_argument("--kind", required=True, choices=DECISION_KINDS)
    record.add_argument("--payload-json", required=True, help="JSON object with the exact fields required by the selected kind")
    consult = sub.add_parser("consult", help="look up an exact normalized prior decision identity")
    consult.add_argument("--kind", required=True, choices=DECISION_KINDS)
    consult.add_argument("--identity-json", required=True, help="JSON object containing exactly the selected kind's identity fields")
    listing = sub.add_parser("list", help="list decisions")
    listing.add_argument("--kind", choices=DECISION_KINDS)
    args = parser.parse_args()
    try:
        if args.command == "record":
            result = record_decision(args.build_state, args.kind, _json_object(args.payload_json, "payload-json"))
        elif args.command == "consult":
            result = consult_decision(args.build_state, args.kind, _json_object(args.identity_json, "identity-json"))
        else:
            result = list_decisions(args.build_state, kind=args.kind)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (WorldBuilderError, OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
