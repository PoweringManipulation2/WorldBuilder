#!/usr/bin/env python3
"""Validate the WorldBuilder v4 era-root architecture.

Era selection moves out of the card Scenario field and into the lorebook itself.
Each era owns one constant root entry; exactly one root is enabled at a time. The
enabled root emits a distinctive era token, and every era-scoped entry requires
that token through AND ALL selective logic, so an out-of-era entry cannot be
pulled directly out of the chat buffer by a subject keyword.

Three enforcement layers, in order of how late they catch a mistake:

1. Token gate (before activation): AND ALL on the era token.
2. Recursion levels (during activation): staged cascade, root first.
3. Inclusion groups (after activation): at most one era variant per subject
   reaches the prompt even if layers 1 and 2 both have a hole.

Layer 3 is the one that matters when the others are wrong, which is why it is
required rather than advisory.

Commands:
    plan      validate an era-root plan in isolation
    planning  validate the plan against the manifest
    output    validate emitted bytes
    settings  print the SillyTavern runtime settings this build requires
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any, Iterable

from wb_common import (
    ErrorCollector,
    WorldBuilderError,
    atomic_write_json,
    load_build_state,
    load_json,
    preflight_report,
    raise_error,
    requirement_rows,
    resolve_state_path,
    sha256_file,
    uid_label,
)

KIND = "worldbuilder-era-root-plan"
PLAN_VERSION = 1
CONTRACT = "worldbuilder-era-root-v1"
RECEIPT_KIND = "worldbuilder-era-root-gate"
RECEIPT_VERSION = 1

ROOT_LEVEL = 0
# core_invariant is never in a variant group: the group holds mutually exclusive
# era states, while the core must co-occur with whichever state won. It is no
# longer ungated: an ungated entry can activate with no era linked to it,
# which is the one hole a token gate cannot close. It now carries AND ANY over
# exactly the tokens of the eras its subject exists in, so it is inside the era
# tree while still being written once.
CASCADE_ROLES = ("root", "context", "state", "detail", "core_invariant")
# Roles outside the linear root->context->state->detail chain: they co-occur
# with a winning state rather than following it, so they carry no ordered level.
CO_OCCURRING_ROLES = ("core_invariant",)
UNGATED_ROLES = ()
LOGIC_AND_ANY = 0
# A root may say who is gone. It may not enumerate what has not happened:
# naming a future event to forbid it still puts that event in context, and the
# token gate already makes the event unreachable from this era (DR-038).
FUTURE_ENUMERATION_RE = re.compile(
    r"^\s*(WHAT HAS NOT HAPPENED YET|NOT YET HAPPENED|FUTURE EVENTS|WHAT COMES LATER)\s*:",
    re.IGNORECASE | re.MULTILINE,
)
DEFAULT_LEVELS = {"root": 0, "context": 1, "state": 2, "detail": 3}

# A token must be a single word so "Match whole words" cannot split it, long
# enough not to collide with ordinary prose, and must not be a prefix of another
# token: SillyTavern matches substrings, so EraAsh would also fire EraAshFall.
TOKEN_RE = re.compile(r"^[A-Za-z][A-Za-z0-9]{7,47}$")
GROUP_RE = re.compile(r"^[a-z][a-z0-9]*(?:\.[a-z0-9-]+)+$")

LOGIC_AND_ALL = 3

REQUIRED_ROOT_BLOCKS = ("ABSENT THIS ERA:", "KNOWLEDGE LIMITS THIS ERA:")


def _obj(value: Any, label: str) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise_error(f"{label} must be an object")
    return value


def _seq(value: Any, label: str, *, allow_empty: bool = True) -> list[Any]:
    if not isinstance(value, list):
        raise_error(f"{label} must be a list")
    if not value and not allow_empty:
        raise_error(f"{label} must not be empty")
    return value


def _text(value: Any, label: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise_error(f"{label} must be a non-empty string")
    return value.strip()


# --------------------------------------------------------------------------- plan


def validate_plan(plan: dict[str, Any], *, build_id: str | None = None) -> dict[str, Any]:
    problems = ErrorCollector()
    if not isinstance(plan, dict):
        problems.add("era-root plan must be an object")
        problems.raise_if_any()
    if plan.get("kind") != KIND:
        problems.add(f"era-root plan kind must be {KIND!r}")
    if plan.get("plan_version") != PLAN_VERSION:
        problems.add(f"era-root plan_version must be {PLAN_VERSION}")
    if plan.get("contract") != CONTRACT:
        problems.add(f"era-root plan contract must be {CONTRACT!r}")
    if plan.get("kind") != KIND or plan.get("plan_version") != PLAN_VERSION or plan.get("contract") != CONTRACT:
        problems.add("dependent checks skipped: era-root plan field checks (kind, plan_version, or contract is unusable)")
        problems.raise_if_any()
    if build_id is not None and plan.get("build_id") != build_id:
        problems.add(f"era-root plan build_id {plan.get('build_id')!r} does not match build {build_id!r}")
    if plan.get("user_approved") is not True:
        problems.add("era-root plan requires explicit user approval")

    routing = plan.get("routing")
    if not isinstance(routing, dict):
        problems.add("era-root plan routing must be an object")
        problems.add("dependent checks skipped: routing, era, and variant-group checks (routing is unusable)")
        problems.raise_if_any()
    mode = routing.get("mode")
    if mode not in {"root_toggle", "scenario"}:
        problems.add("routing.mode must be 'root_toggle' or 'scenario'")

    levels = dict(DEFAULT_LEVELS)
    declared = routing.get("cascade_levels")
    if declared is not None:
        if not isinstance(declared, dict):
            problems.add("routing.cascade_levels must be an object")
        else:
            for role, value in declared.items():
                if role not in CASCADE_ROLES:
                    problems.add(f"unknown cascade role {role!r}")
                    continue
                if role in CO_OCCURRING_ROLES:
                    problems.add(f"{role!r} co-occurs with a winning state and has no ordered cascade level")
                    continue
                if not isinstance(value, int) or isinstance(value, bool) or value < 0:
                    problems.add(f"cascade level for {role!r} must be a non-negative integer")
                    continue
                levels[role] = value
    if levels["root"] != ROOT_LEVEL:
        problems.add("the era root must sit at recursion level 0; it is constant, not recursion-gated")
    ordered = [levels[role] for role in CASCADE_ROLES if role not in CO_OCCURRING_ROLES]
    if ordered != sorted(ordered) or len(set(ordered)) != len(ordered):
        problems.add(f"cascade levels must strictly increase root->context->state->detail, got {ordered}")

    eras = plan.get("eras")
    if not isinstance(eras, list):
        problems.add("era-root plan eras must be a list")
        problems.add("dependent checks skipped: era, enabled-default, and variant-group checks (the era table is unusable)")
        problems.raise_if_any()
    if not eras:
        problems.add("era-root plan eras must not be empty")
        problems.add("dependent checks skipped: era, enabled-default, and variant-group checks (the era table is unusable)")
        problems.raise_if_any()
    if mode == "root_toggle" and len(eras) < 2:
        problems.add("root_toggle routing requires at least two eras; use single-era mode otherwise")

    ids: set[str] = set()
    tokens: dict[str, str] = {}
    roots: set[str] = set()
    enabled: list[str] = []
    eras_ok = True
    for index, raw in enumerate(eras):
        if not isinstance(raw, dict):
            problems.add(f"eras[{index}] must be an object")
            eras_ok = False
            continue
        era_id = None
        try:
            era_id = _text(raw.get("id"), f"eras[{index}].id")
        except WorldBuilderError as exc:
            problems.add(str(exc))
        if era_id is None:
            problems.add(f"dependent checks skipped: eras[{index}] field checks (id is unusable)")
            eras_ok = False
            continue
        if era_id in ids:
            problems.add(f"duplicate era id {era_id!r}")
            eras_ok = False
            continue
        ids.add(era_id)
        try:
            _text(raw.get("name"), f"era {era_id} name")
        except WorldBuilderError as exc:
            problems.add(str(exc))
        if not isinstance(raw.get("order"), int) or isinstance(raw.get("order"), bool):
            problems.add(f"era {era_id} order must be an integer")
        token = None
        try:
            token = _text(raw.get("token"), f"era {era_id} token")
        except WorldBuilderError as exc:
            problems.add(str(exc))
        if token is not None:
            if not TOKEN_RE.match(token):
                problems.add(
                    f"era {era_id} token {token!r} must be one alphanumeric word of 8-48 characters; "
                    "spaces and punctuation break whole-word matching"
                )
            else:
                for other_id, other in tokens.items():
                    if token.casefold() in other.casefold() or other.casefold() in token.casefold():
                        problems.add(
                            f"era token {token!r} ({era_id}) collides with {other!r} ({other_id}): "
                            "SillyTavern matches substrings, so one era would unlock the other"
                        )
                tokens[era_id] = token
        root_uid = uid_label(raw.get("root_uid")) or "<unknown>"
        if root_uid == "<unknown>":
            problems.add(f"era {era_id} requires a root_uid")
        elif root_uid in roots:
            problems.add(f"duplicate root_uid {root_uid!r}")
        else:
            roots.add(root_uid)
        if raw.get("enabled_by_default") is True:
            enabled.append(era_id)

        # Absence and knowledge ceiling must be *declared*, even when empty:
        # an empty list is a reviewed statement, a missing key is an oversight.
        absent = raw.get("absent_entities")
        if not isinstance(absent, list):
            problems.add(f"era {era_id} absent_entities must be a list")
        else:
            for position, item in enumerate(absent):
                if not isinstance(item, dict):
                    problems.add(f"era {era_id} absent_entities[{position}] must be an object")
                    continue
                try:
                    _text(item.get("name"), f"era {era_id} absent_entities[{position}].name")
                except WorldBuilderError as exc:
                    problems.add(str(exc))
                try:
                    _text(item.get("reason"), f"era {era_id} absent_entities[{position}].reason")
                except WorldBuilderError as exc:
                    problems.add(str(exc))
        if not isinstance(raw.get("knowledge_ceiling"), list):
            problems.add(f"era {era_id} knowledge_ceiling must be a list")

    groups: list[Any] = []
    if not eras_ok:
        problems.add("dependent checks skipped: enabled-default and variant-group checks (some eras are unusable)")
    else:
        if mode == "root_toggle" and len(enabled) != 1:
            problems.add(f"exactly one era must set enabled_by_default; found {len(enabled)} ({sorted(enabled)})")
        raw_groups = plan.get("variant_groups", [])
        if not isinstance(raw_groups, list):
            problems.add("variant_groups must be a list")
            problems.add("dependent checks skipped: variant-group checks (variant_groups is not a list)")
        else:
            groups = raw_groups
            seen_groups: set[str] = set()
            for index, raw in enumerate(groups):
                if not isinstance(raw, dict):
                    problems.add(f"variant_groups[{index}] must be an object")
                    continue
                name = None
                try:
                    name = _text(raw.get("group"), f"variant_groups[{index}].group")
                except WorldBuilderError as exc:
                    problems.add(str(exc))
                if name is None:
                    problems.add(f"dependent checks skipped: variant_groups[{index}] checks (group name is unusable)")
                    continue
                if not GROUP_RE.match(name):
                    problems.add(f"inclusion group {name!r} must look like 'wb.subject-id'")
                if name in seen_groups:
                    problems.add(f"duplicate inclusion group {name!r}")
                    continue
                seen_groups.add(name)
                by_era = raw.get("uids_by_era")
                if not isinstance(by_era, dict):
                    problems.add(f"variant group {name} uids_by_era must be an object")
                    continue
                if len(by_era) < 2:
                    problems.add(f"variant group {name} needs at least two era variants to be worth grouping")
                unknown = sorted(set(by_era) - ids)
                if unknown:
                    problems.add(f"variant group {name} references unknown eras {unknown}")
                if len({uid_label(v) or "<unknown>" for v in by_era.values()}) != len(by_era):
                    problems.add(f"variant group {name} reuses one uid across eras")

    runtime = None
    try:
        runtime = validate_runtime_requirements(plan.get("runtime_requirements"), levels)
    except WorldBuilderError as exc:
        problems.add(str(exc))
    problems.raise_if_any()
    return {
        "era_count": len(eras),
        "mode": mode,
        "cascade_levels": levels,
        "tokens": tokens,
        "enabled_by_default": enabled[0] if enabled else None,
        "variant_group_count": len(groups),
        "runtime_requirements": runtime,
    }


def validate_runtime_requirements(value: Any, levels: dict[str, int]) -> dict[str, Any]:
    """The cascade is inert unless the host runtime is configured for it."""
    problems = ErrorCollector()
    if not isinstance(value, dict):
        problems.add("runtime_requirements must be an object")
        problems.raise_if_any()
    runtime = value
    if runtime.get("recursive_scan") is not True:
        problems.add("runtime_requirements.recursive_scan must be true; the cascade cannot fire without it")
    needed = max(levels.values()) + 1
    steps = runtime.get("min_recursion_steps")
    if not isinstance(steps, int) or isinstance(steps, bool):
        problems.add("runtime_requirements.min_recursion_steps must be an integer")
    elif steps < needed:
        problems.add(
            f"min_recursion_steps {steps} cannot drive a cascade of depth {max(levels.values())}; "
            f"require at least {needed}"
        )
    # SillyTavern documents Min Activations and Max Recursion Steps as mutually
    # exclusive. Asking for both silently disables the one the user needs.
    activations = runtime.get("min_activations", 0)
    if activations not in (0, None):
        problems.add(
            "runtime_requirements.min_activations must be 0: SillyTavern treats Min Activations and "
            "Max Recursion Steps as mutually exclusive, and the cascade needs recursion steps"
        )
    problems.raise_if_any()
    return {"recursive_scan": True, "min_recursion_steps": steps, "min_activations": 0}


def _entries(manifest: dict[str, Any]) -> list[dict[str, Any]]:
    rows = manifest.get("entries")
    if not isinstance(rows, list):
        raise_error("manifest entries must be a list")
    return [row for row in rows if isinstance(row, dict)]


def _emit(entry: dict[str, Any]) -> dict[str, Any]:
    value = entry.get("emit")
    return value if isinstance(value, dict) else {}


def _ext(entry: dict[str, Any]) -> dict[str, Any]:
    value = _emit(entry).get("extensions")
    return value if isinstance(value, dict) else {}


def _setting(entry: dict[str, Any], *names: str, default: Any = None) -> Any:
    emit, ext = _emit(entry), _ext(entry)
    for name in names:
        if name in emit:
            return emit[name]
        if name in ext:
            return ext[name]
    return default


def _entry_arch(entry: dict[str, Any]) -> dict[str, Any]:
    value = entry.get("architecture")
    return value if isinstance(value, dict) else {}


def _by_uid(manifest: dict[str, Any]) -> dict[str, dict[str, Any]]:
    return {uid_label(row.get("uid", row.get("id"))) or "<unknown>": row for row in _entries(manifest)}


def _cascade_role(entry: dict[str, Any]) -> str | None:
    role = _entry_arch(entry).get("era_cascade_role")
    return role if role in CASCADE_ROLES else None


def validate_manifest(plan: dict[str, Any], manifest: dict[str, Any]) -> dict[str, Any]:
    problems = ErrorCollector()
    detail = None
    try:
        detail = validate_plan(plan)
    except WorldBuilderError as exc:
        problems.add(str(exc))
    if detail is None:
        problems.add("dependent checks skipped: manifest checks (the era-root plan is invalid)")
        problems.raise_if_any()
    levels = detail["cascade_levels"]
    tokens: dict[str, str] = detail["tokens"]
    index = _by_uid(manifest)

    checked = 0
    gated = 0
    for era in plan["eras"]:
        era_id = era["id"]
        token = tokens[era_id]
        root_uid = uid_label(era.get("root_uid")) or "<unknown>"
        root = index.get(root_uid)
        if root is None:
            problems.add(f"era {era_id} root_uid {root_uid} is not in the manifest")
            problems.add(f"dependent checks skipped: era {era_id} root checks (the root entry is missing)")
        else:
            if _cascade_role(root) != "root":
                problems.add(f"era {era_id} root entry {root_uid} must declare architecture.era_cascade_role='root'")
            if _setting(root, "constant") is not True:
                problems.add(f"era {era_id} root {root_uid} must be constant; a keyword root cannot anchor the cascade")
            if _setting(root, "selective", default=False) is True:
                problems.add(f"era {era_id} root {root_uid} must not be selective; it is the source of the token, not a consumer")
            emits = _entry_arch(root).get("emits_token")
            if emits != token:
                problems.add(f"era {era_id} root {root_uid} must declare architecture.emits_token={token!r}, got {emits!r}")
            if _setting(root, "prevent_recursion", "preventRecursion", default=False) is True:
                problems.add(f"era {era_id} root {root_uid} sets prevent_recursion, which stops the token reaching level 1")

        for role in ("context", "state", "detail"):
            role_uids = era.get(f"{role}_uids", [])
            if not isinstance(role_uids, list):
                problems.add(f"era {era_id} {role}_uids must be a list")
                problems.add(f"dependent checks skipped: era {era_id} {role} entry checks ({role}_uids is not a list)")
                continue
            for uid in role_uids:
                key = uid_label(uid) or "<unknown>"
                entry = index.get(key)
                if entry is None:
                    problems.add(f"era {era_id} {role} uid {key} is not in the manifest")
                    continue
                checked += 1
                if _cascade_role(entry) != role:
                    problems.add(f"entry {key} must declare architecture.era_cascade_role={role!r}")
                try:
                    _require_token_gate(entry, key, token, era_id)
                except WorldBuilderError as exc:
                    problems.add(str(exc))
                gated += 1
                try:
                    _require_recursion_level(entry, key, role, levels)
                except WorldBuilderError as exc:
                    problems.add(str(exc))
                if role != "detail" and _setting(entry, "prevent_recursion", "preventRecursion", default=False) is True:
                    problems.add(
                        f"entry {key} sets prevent_recursion at cascade role {role!r}; "
                        "the token would never reach the next level"
                    )
                if _setting(entry, "exclude_recursion", "excludeRecursion", default=False) is True:
                    problems.add(f"entry {key} sets exclude_recursion, so recursion can never activate it")

    core_detail = None
    try:
        core_detail = _validate_cores(plan, index, tokens)
    except WorldBuilderError as exc:
        problems.add(str(exc))
    if core_detail is not None:
        gated += core_detail["gated_cores"]
    group_detail = None
    try:
        group_detail = _validate_groups(plan, index)
    except WorldBuilderError as exc:
        problems.add(str(exc))
    problems.raise_if_any()
    return {
        "era_count": detail["era_count"],
        "cascade_levels": levels,
        "gated_entries": gated,
        "checked_entries": checked,
        "variant_groups": group_detail,
        "core_invariants": core_detail,
        "runtime_requirements": detail["runtime_requirements"],
    }


def _require_token_gate(entry: dict[str, Any], uid: str, token: str, era_id: str) -> None:
    problems = ErrorCollector()
    if _setting(entry, "selective") is not True:
        problems.add(f"entry {uid} must set selective=true to carry the era {era_id} token gate")
    logic = _setting(entry, "selective_logic", "selectiveLogic")
    if logic != LOGIC_AND_ALL:
        problems.add(
            f"entry {uid} must use selective_logic={LOGIC_AND_ALL} (AND ALL), got {logic!r}. "
            "AND ANY leaks as soon as a second secondary key exists"
        )
    secondary = _setting(entry, "secondary_keys", "keysecondary", default=[])
    if not isinstance(secondary, list) or token not in secondary:
        problems.add(f"entry {uid} must list the era {era_id} token {token!r} in its secondary keys")
    else:
        foreign = [item for item in secondary if isinstance(item, str) and item != token and TOKEN_RE.match(item)]
        if foreign:
            problems.add(f"entry {uid} carries foreign era tokens {foreign} alongside {token!r}")
    problems.raise_if_any()


def _require_recursion_level(entry: dict[str, Any], uid: str, role: str, levels: dict[str, int]) -> None:
    problems = ErrorCollector()
    if _setting(entry, "delay_until_recursion", "delayUntilRecursion") is not True:
        problems.add(f"entry {uid} must set delay_until_recursion=true so it cannot fire before the root")
    level = _setting(entry, "recursion_level", "recursionLevel")
    if level != levels[role]:
        problems.add(f"entry {uid} must sit at recursion level {levels[role]} for cascade role {role!r}, got {level!r}")
    problems.raise_if_any()


def _validate_cores(
    plan: dict[str, Any], index: dict[str, dict[str, Any]], tokens: dict[str, str]
) -> dict[str, Any]:
    """A core_invariant entry is written once and co-occurs with whichever era
    state won. It used to be ungated, which meant it could activate with no era
    linked to it: a character firing in eras where they are dead or unborn.
    It is now gated with AND ANY over exactly the tokens of the eras its subject
    exists in: still one entry, but reachable only from inside the era tree.

    AND ANY is correct here and is not the leak it would be on a state entry.
    Exactly one root ships enabled, so exactly one token is ever live; the set
    means "any era this subject exists in", which is the intended semantics.
    """
    problems = ErrorCollector()
    known = {token for token in tokens.values()}
    subject_eras: dict[str, set[str]] = {}
    for group in plan.get("variant_groups", []) or []:
        if not isinstance(group, dict):
            continue
        subject = group.get("subject") or group.get("group")
        by_era = group.get("uids_by_era")
        if subject and isinstance(by_era, dict):
            subject_eras[str(subject)] = {str(era) for era in by_era}
    gated = 0
    checked = 0
    for uid, entry in index.items():
        if _cascade_role(entry) != "core_invariant":
            continue
        checked += 1
        if _setting(entry, "selective") is not True:
            problems.add(f"core entry {uid} must set selective=true; an ungated core can activate outside every era")
        logic = _setting(entry, "selective_logic", "selectiveLogic")
        if logic != LOGIC_AND_ANY:
            problems.add(
                f"core entry {uid} must use selective_logic={LOGIC_AND_ANY} (AND ANY) over its era tokens, "
                f"got {logic!r}. AND ALL would demand every era be active at once, which disables the entry"
            )
        secondary = _setting(entry, "secondary_keys", "keysecondary", default=[])
        secondary = [item for item in secondary if isinstance(item, str)] if isinstance(secondary, list) else []
        if not secondary:
            problems.add(f"core entry {uid} carries no era tokens; it would activate with no era linked to it")
        foreign = sorted(set(secondary) - known) if secondary else []
        if foreign:
            problems.add(f"core entry {uid} carries secondary keys that are not era tokens: {foreign}")
        subject = _entry_arch(entry).get("subject_id")
        if subject and str(subject) in subject_eras:
            expected = {tokens[era] for era in subject_eras[str(subject)] if era in tokens}
            if expected and set(secondary) != expected:
                problems.add(
                    f"core entry {uid} must carry exactly the tokens of the eras {subject!r} exists in "
                    f"({sorted(expected)}), got {sorted(set(secondary))}"
                )
        if _setting(entry, "exclude_recursion", "excludeRecursion", default=False) is True:
            problems.add(f"core entry {uid} sets exclude_recursion, so recursion can never activate it")
        gated += 1
    problems.raise_if_any()
    return {"checked_cores": checked, "gated_cores": gated}


def _validate_groups(plan: dict[str, Any], index: dict[str, dict[str, Any]]) -> dict[str, Any]:
    problems = ErrorCollector()
    groups = plan.get("variant_groups", []) or []
    subjects: dict[str, set[str]] = {}
    for group in groups:
        name = group["group"]
        for era_id, uid in group["uids_by_era"].items():
            key = uid_label(uid) or "<unknown>"
            entry = index.get(key)
            if entry is None:
                problems.add(f"variant group {name} references uid {key}, which is not in the manifest")
                continue
            if _cascade_role(entry) in CO_OCCURRING_ROLES:
                problems.add(
                    f"entry {key} is {_cascade_role(entry)!r} and must not join variant group {name!r}: "
                    "the group holds mutually exclusive era states, and a core entry must co-occur "
                    "with whichever state won rather than compete with it"
                )
                continue
            declared = _setting(entry, "group", "inclusion_group")
            if declared != name:
                problems.add(f"entry {key} must declare inclusion group {name!r}, got {declared!r}")
            if _setting(entry, "group_override", "groupOverride") is not True:
                problems.add(
                    f"entry {key} must set group_override=true so the winner is chosen by order, "
                    "not by a random group-weight roll"
                )
            subjects.setdefault(name, set()).add(era_id)

    # Any subject with entries in more than one era must be grouped. This is the
    # check that would have caught the deferred inclusion-group gap.
    ungrouped: list[str] = []
    grouped_uids = {uid_label(u) or "<unknown>" for g in groups for u in g["uids_by_era"].values()}
    by_subject: dict[str, set[str]] = {}
    for uid, entry in index.items():
        subject = _entry_arch(entry).get("subject_id")
        eras = _entry_arch(entry).get("era_ids")
        if not subject or not isinstance(eras, list) or _cascade_role(entry) not in {"state", "detail"}:
            continue  # core_invariant is intentionally excluded: it is not a variant
        by_subject.setdefault(str(subject), set()).update(str(e) for e in eras)
        if uid not in grouped_uids:
            by_subject.setdefault(str(subject), set())
    for subject, eras in by_subject.items():
        if len(eras) > 1:
            uids = [
                uid for uid, entry in index.items()
                if str(_entry_arch(entry).get("subject_id", "")) == subject and uid not in grouped_uids
            ]
            if uids:
                ungrouped.append(f"{subject}: {sorted(uids)}")
    if ungrouped:
        problems.add(
            "subjects that exist in more than one era must share an inclusion group, "
            f"otherwise two variants can both reach the prompt: {ungrouped}"
        )
    problems.raise_if_any()
    return {"count": len(groups), "subjects": sorted(subjects)}


def _output_entries(data: Any) -> list[dict[str, Any]]:
    container = data
    if isinstance(data, dict) and isinstance(data.get("data"), dict):
        container = data["data"]
    if isinstance(container, dict) and isinstance(container.get("character_book"), dict):
        container = container["character_book"]
    rows = container.get("entries") if isinstance(container, dict) else None
    if isinstance(rows, dict):
        rows = list(rows.values())
    if not isinstance(rows, list):
        raise_error("could not locate lorebook entries in the artifact")
    return [row for row in rows if isinstance(row, dict)]


def validate_output(plan: dict[str, Any], data: Any) -> dict[str, Any]:
    problems = ErrorCollector()
    detail = None
    try:
        detail = validate_plan(plan)
    except WorldBuilderError as exc:
        problems.add(str(exc))
    if detail is None:
        problems.add("dependent checks skipped: era-root output checks (the era-root plan is invalid)")
        problems.raise_if_any()
    tokens: dict[str, str] = detail["tokens"]
    rows = _output_entries(data)

    text_by_token: dict[str, str] = {}
    enabled: list[str] = []
    for era in plan["eras"]:
        era_id = era["id"]
        token = tokens[era_id]
        root = _find_root(rows, token)
        if root is None:
            problems.add(f"era {era_id}: no emitted entry contains the token {token!r}")
            continue
        content = str(root.get("content", ""))
        text_by_token[token] = content
        if FUTURE_ENUMERATION_RE.search(content):
            problems.add(
                f"era {era_id} root enumerates events that have not happened. Naming a future event "
                "in order to forbid it still puts that event in context, and the token gate already "
                "makes it unreachable from this era. State the boundary instead: "
                "'Nothing after <era boundary> has occurred.' (DR-038)"
            )
        missing = [block for block in REQUIRED_ROOT_BLOCKS if block not in content]
        if missing:
            problems.add(
                f"era {era_id} root is missing {missing}. Absence and knowledge limits must live in the "
                "constant root: a keyword-triggered entry only fires after the model has already used the name"
            )
        for item in era.get("absent_entities", []):
            if item["name"] not in content:
                problems.add(f"era {era_id} root omits absent entity {item['name']!r} from its roster")
        if root.get("disable") is not True and root.get("enabled") is not False:
            enabled.append(era_id)

    if detail["mode"] == "root_toggle" and len(enabled) != 1:
        problems.add(f"exactly one era root may ship enabled; found {len(enabled)} ({sorted(enabled)})")
    if enabled and enabled[0] != detail["enabled_by_default"]:
        problems.add(f"enabled root {enabled[0]!r} does not match the approved default {detail['enabled_by_default']!r}")

    leaks = _cross_era_leaks(rows, tokens, text_by_token)
    if leaks:
        problems.add(f"cross-era token leakage: {leaks}")

    problems.raise_if_any()
    return {
        "era_count": detail["era_count"],
        "entry_count": len(rows),
        "enabled_era": enabled[0] if enabled else None,
        "roots_verified": len(text_by_token),
    }


def _find_root(rows: Iterable[dict[str, Any]], token: str) -> dict[str, Any] | None:
    for row in rows:
        if row.get("constant") is True and token in str(row.get("content", "")):
            return row
    return None


def _cross_era_leaks(rows: list[dict[str, Any]], tokens: dict[str, str], roots: dict[str, str]) -> list[str]:
    """A root may emit only its own token; no entry may emit a token it does not own."""
    leaks: list[str] = []
    for era_id, token in tokens.items():
        content = roots.get(token, "")
        for other_id, other in tokens.items():
            if other_id != era_id and other in content:
                leaks.append(f"era {era_id} root emits {other!r} (belongs to {other_id})")
    for row in rows:
        if row.get("constant") is True:
            continue
        content = str(row.get("content", ""))
        present = [t for t in tokens.values() if t in content]
        if len(present) > 1:
            leaks.append(f"entry {row.get('uid', row.get('id'))} emits multiple era tokens {present}")
    return leaks


# -------------------------------------------------------------------- settings


def settings_block(plan: dict[str, Any]) -> str:
    """The exact SillyTavern settings this build needs, for Creator Notes."""
    detail = validate_plan(plan)
    runtime = detail["runtime_requirements"]
    lines = [
        "REQUIRED SILLYTAVERN SETTINGS",
        "",
        "This lorebook uses era roots. Without these settings the era cascade cannot fire,",
        "and you will get the era frame only; correct, but far thinner than intended.",
        "",
        "World Info -> Activation Settings:",
        "  Recursive Scan .............. ON   (required; the cascade is built on recursion)",
        f"  Max Recursion Steps ......... {runtime['min_recursion_steps']} or more",
        "  Min Activations ............. 0    (mutually exclusive with Max Recursion Steps)",
        "",
        "Switching era:",
        "  Open this lorebook, enable exactly one 'Era: ...' root entry, disable the rest.",
        "  Never enable two roots at once; both eras would unlock simultaneously.",
        "",
        "Available eras:",
    ]
    for era in sorted(plan["eras"], key=lambda e: e["order"]):
        mark = "  [x] " if era.get("enabled_by_default") else "  [ ] "
        lines.append(f"{mark}Era: {era['name']}")
    lines += [
        "",
        "Verify: enable a root, send one message, and open the World Info activation log.",
        "You should see the root plus its era context. If only the root appears, recursion is off.",
    ]
    return "\n".join(lines)


# ------------------------------------------------------------------------- cli


def require_settings_block(plan: dict[str, Any], data: Any) -> dict[str, Any]:
    """Delivery check: the runtime settings the build depends on must ship with it.

    The cascade needs host settings WorldBuilder cannot set. Shipping without the
    instruction produces a book that silently underperforms in a way the user
    cannot diagnose, so this is a release blocker rather than a warning.
    """
    problems = ErrorCollector()
    detail = None
    try:
        detail = validate_plan(plan)
    except WorldBuilderError as exc:
        problems.add(str(exc))
    if detail is None:
        problems.add("dependent checks skipped: settings-block checks (the era-root plan is invalid)")
        problems.raise_if_any()
    notes = ""
    if isinstance(data, dict):
        block = data.get("data") if isinstance(data.get("data"), dict) else data
        notes = str(block.get("creator_notes", "") or "")
        multi = block.get("creator_notes_multilingual")
        if isinstance(multi, dict):
            notes = "\n".join([notes, *(str(v) for v in multi.values())])

    needed = ["Recursive Scan", "Max Recursion Steps", "Min Activations"]
    missing = [item for item in needed if item not in notes]
    steps = detail["runtime_requirements"]["min_recursion_steps"]
    if missing:
        problems.add(
            f"Creator Notes must carry the required SillyTavern settings block; missing {missing}. "
            "Generate it with: era_root_contract.py settings --era-root-plan <plan>"
        )
    elif str(steps) not in notes:
        problems.add(f"Creator Notes settings block does not state the required Max Recursion Steps value ({steps})")
    problems.raise_if_any()
    return {"settings_block": "present", "min_recursion_steps": steps}


def load_valid_era_ids(root: Path, state: dict[str, Any], manifest: dict[str, Any]) -> set[str]:
    """The real, root_toggle-specific source of valid era IDs: loaded
    from the actual era-root-plan.json, not the Scenario-plan's
    era_keywords (which stays empty for root_toggle by design, per the
    DR-083-shaped fix). Any downstream check validating a character's or
    entity's era references for a root_toggle manifest should check
    against this set, not against era_keywords, which was never the
    right source of truth for this routing style in the first place."""
    plan, _ = _load_plan_for_build(root, state, manifest)
    return {str(era.get("id")) for era in plan.get("eras", []) if isinstance(era, dict) and era.get("id")}


def load_era_root_plan(root: Path, state: dict[str, Any], manifest: dict[str, Any]) -> tuple[dict[str, Any], Path]:
    """Public accessor for the era-root plan itself, the era ids (see
    load_valid_era_ids) plus the per-era order values that back era
    event-reach validation for root_toggle builds."""
    return _load_plan_for_build(root, state, manifest)


def _load_plan_for_build(root: Path, state: dict[str, Any], manifest: dict[str, Any]) -> tuple[dict[str, Any], Path]:
    problems = ErrorCollector()
    path = resolve_state_path(root, state, "era_root_plan", required=False)
    if path is None or not path.exists():
        path = root / "artifacts" / "era-root-plan.json"
    if not path.exists():
        problems.add(f"era-root plan not found at {path}")
        problems.raise_if_any()
    plan = load_json(path)
    if not isinstance(plan, dict):
        problems.add("era-root plan must be an object")
    bound = manifest.get("era_root_plan_sha256")
    if bound and bound != sha256_file(path):
        problems.add("era-root plan hash does not match the manifest binding; regenerate assignments")
    problems.raise_if_any()
    return plan, path


def _required(manifest: dict[str, Any]) -> bool:
    arch = manifest.get("architecture")
    era = arch.get("era") if isinstance(arch, dict) else None
    if not isinstance(era, dict):
        return False
    return era.get("mode") == "multi" and era.get("routing", "root_toggle") == "root_toggle"


def run(build_state: str, stage: str, artifact: str | None, *, write_receipt: bool = True) -> dict[str, Any]:
    problems = ErrorCollector()
    root, state = load_build_state(build_state)
    manifest_path = resolve_state_path(root, state, "manifest")
    manifest = load_json(manifest_path)
    if not isinstance(manifest, dict):
        problems.add("manifest must be an object")
        problems.raise_if_any()

    if not _required(manifest):
        return {
            "kind": RECEIPT_KIND, "receipt_version": RECEIPT_VERSION, "contract": CONTRACT,
            "status": "not_required", "stage": stage, "build_id": state.get("build_id"),
        }

    plan = None
    plan_path = None
    try:
        plan, plan_path = _load_plan_for_build(root, state, manifest)
    except WorldBuilderError as exc:
        problems.add(str(exc))
        problems.raise_if_any()
    if stage == "planning":
        detail = None
        try:
            detail = validate_manifest(plan, manifest)
        except WorldBuilderError as exc:
            problems.add(str(exc))
        if detail is None:
            problems.add("dependent checks skipped: era-root receipt generation (the manifest check failed)")
            problems.raise_if_any()
        target_sha = sha256_file(manifest_path)
    else:
        target = Path(artifact).resolve() if artifact else resolve_state_path(root, state, "final_output")
        data = load_json(target)
        detail = None
        try:
            detail = validate_output(plan, data)
        except WorldBuilderError as exc:
            problems.add(str(exc))
        if detail is None:
            problems.add("dependent checks skipped: era-root receipt generation (the output check failed)")
            problems.raise_if_any()
        try:
            detail.update(require_settings_block(plan, data))
        except WorldBuilderError as exc:
            problems.add(str(exc))
        problems.raise_if_any()
        target_sha = sha256_file(target)

    receipt = {
        "kind": RECEIPT_KIND, "receipt_version": RECEIPT_VERSION, "contract": CONTRACT,
        "status": "passed", "stage": stage, "build_id": state.get("build_id"),
        "era_root_plan_sha256": sha256_file(plan_path), "target_sha256": target_sha,
        "detail": detail,
    }
    if write_receipt:
        out = root / "artifacts" / f"era-root-gate-{stage}.json"
        out.parent.mkdir(parents=True, exist_ok=True)
        atomic_write_json(out, receipt)
        receipt["receipt_path"] = str(out)
    return receipt


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate the WorldBuilder v4 era-root architecture.")
    parser.add_argument("--build-state", help="Build-state path for the read-only --requirements preflight.")
    parser.add_argument("--requirements", action="store_true", help="Read-only preflight: print what this gate checks against the current build state.")
    sub = parser.add_subparsers(dest="command")

    p_plan = sub.add_parser("plan", help="validate an era-root plan in isolation")
    p_plan.add_argument("--era-root-plan", required=True)
    p_plan.add_argument("--build-id")

    for name, helptext in (("planning", "validate the plan against the manifest"),
                           ("output", "validate emitted bytes")):
        stage = sub.add_parser(name, help=helptext)
        stage.add_argument("--build-state", required=True)
        stage.add_argument("--artifact")
        stage.add_argument("--no-write-receipt", action="store_true")

    p_set = sub.add_parser("settings", help="print the required SillyTavern settings")
    p_set.add_argument("--era-root-plan", required=True)

    args = parser.parse_args()
    if args.requirements:
        if not args.build_state:
            parser.error("--requirements needs --build-state")
        root, state = load_build_state(args.build_state)
        print(json.dumps(preflight_report("era_root_contract", requirement_rows(Path(__file__), root, state)), ensure_ascii=False, indent=2))
        return 0
    if args.command is None:
        parser.error("a command is required")
    try:
        if args.command == "plan":
            plan = load_json(Path(args.era_root_plan).expanduser().resolve())
            print(json.dumps(validate_plan(plan, build_id=args.build_id), ensure_ascii=False, indent=2))
        elif args.command == "settings":
            plan = load_json(Path(args.era_root_plan).expanduser().resolve())
            print(settings_block(plan))
        else:
            result = run(args.build_state, args.command, args.artifact,
                         write_receipt=not args.no_write_receipt)
            print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (WorldBuilderError, OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
