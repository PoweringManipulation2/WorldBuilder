#!/usr/bin/env python3
"""Construct a valid discovery-gate approval file from structured inputs.

This exists so approval files are never hand-authored against an undocumented
schema (see references/discovery-approvals.md). It computes plan_sha256 and
corpus_sha256 from the real plan file rather than asking the caller to supply
them, which is the field most workarounds got wrong or omitted.

"user-authorized" is not a technical property this script can verify; it
means the human operator, not the model, decided this. --user-confirmation
is mandatory and is embedded verbatim in the approval file's audit trail
specifically so that decision has a written record to point to, the same way
every other consent-gated action in this skill requires an explicit signal
rather than an inferred one. Do not paraphrase agreement into this field;
quote what the person actually said or approved.

Usage:
  write_discovery_approval.py exclusion --build-state B --plan P \\
      --user-confirmation "TEXT" --entry "URL|CODE|REASON" [--entry ...] \\
      [--approve-saturation-stop] --output OUT

  write_discovery_approval.py single-round --build-state B --plan P \\
      --user-confirmation "TEXT" [--max-urls N] --output OUT
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

from discovery_contract import EXCLUSION_CODES, canonicalize_url, saturation_accepted
from wb_common import WorldBuilderError, load_build_state, load_json, now_iso, resolve_state_path, sha256_file, step_driver_pointer


DISCOVERY_APPROVAL_VERSION = 1


def _plan_hashes(plan_path: Path) -> tuple[str, str]:
    plan = load_json(plan_path)
    if not isinstance(plan, dict) or "corpus_sha256" not in plan:
        raise WorldBuilderError(f"{plan_path} does not look like a discovery plan (no corpus_sha256)")
    return sha256_file(plan_path), str(plan["corpus_sha256"])


def _parse_entry(raw: str, index: int) -> dict[str, str]:
    parts = raw.split("|", 2)
    if len(parts) != 3:
        raise WorldBuilderError(f"--entry {index} must be 'URL|CODE|REASON', got {raw!r}")
    url_raw, code, reason = (part.strip() for part in parts)
    url = canonicalize_url(url_raw)
    if not url:
        raise WorldBuilderError(f"--entry {index} has an unparseable URL: {url_raw!r}")
    if code not in EXCLUSION_CODES:
        raise WorldBuilderError(
            f"--entry {index} uses unknown code {code!r}; valid codes: " + ", ".join(sorted(EXCLUSION_CODES))
        )
    if len(reason) < 5:
        raise WorldBuilderError(f"--entry {index} reason is too short to be a real justification: {reason!r}")
    return {"url": url, "code": code, "reason": reason}


def build_exclusion(args: argparse.Namespace, build_id: str, plan_sha256: str, corpus_sha256: str) -> dict[str, Any]:
    entries = [_parse_entry(raw, i) for i, raw in enumerate(args.entry)]
    if not entries:
        raise WorldBuilderError("exclusion approval needs at least one --entry")
    seen: set[str] = set()
    for row in entries:
        if row["url"] in seen:
            raise WorldBuilderError(f"duplicate URL in --entry list: {row['url']}")
        seen.add(row["url"])
    approval = {
        "kind": "worldbuilder-discovery-exclusion-approval",
        "approval_version": DISCOVERY_APPROVAL_VERSION,
        "build_id": build_id,
        "plan_sha256": plan_sha256,
        "corpus_sha256": corpus_sha256,
        "user_approved": True,
        "user_confirmation": args.user_confirmation,
        "created_at": now_iso(),
        "approved_urls": entries,
    }
    if args.approve_saturation_stop:
        approval["approve_saturation_stop"] = True
    return approval


def build_single_round(args: argparse.Namespace, build_id: str, plan_sha256: str, corpus_sha256: str) -> dict[str, Any]:
    return {
        "kind": "worldbuilder-discovery-single-round-approval",
        "approval_version": DISCOVERY_APPROVAL_VERSION,
        "build_id": build_id,
        "plan_sha256": plan_sha256,
        "corpus_sha256": corpus_sha256,
        "user_approved": True,
        "user_confirmation": args.user_confirmation,
        "created_at": now_iso(),
        "max_urls": args.max_urls,
    }


def closure_is_proven(build_state: str | None) -> tuple[bool, str]:
    """Self-approval is permitted only when the build says so and the evidence shows it.

    Two independent conditions, both required. The setting alone is not enough: a build
    configured for evidence-bounded autonomy still cannot self-approve a genuinely open
    frontier, because that is a scope decision about how much of a source to cover.
    """
    if not build_state:
        return False, "--self-approve-closed-frontier requires --build-state"
    try:
        root, state = load_build_state(build_state)
    except Exception as exc:  # noqa: BLE001
        return False, f"could not read build state: {exc}"

    autonomy = state.get("autonomy") if isinstance(state.get("autonomy"), dict) else {}
    if not autonomy.get("self_approval_permitted"):
        return False, ("this build was initialised with autonomy 'consent-required'; "
                       "self-approval is not permitted. Ask the user, or re-init with "
                       "--autonomy evidence-bounded.")
    try:
        receipt = load_json(resolve_state_path(root, state, "discovery_receipt"))
    except Exception as exc:  # noqa: BLE001
        return False, f"could not read the discovery receipt: {exc}"
    if not isinstance(receipt, dict):
        return False, "discovery receipt has the wrong format"

    is_v4 = int(receipt.get("receipt_version", 0) or 0) >= 4 or "bounded_coverage_proven" in receipt
    if is_v4:
        metrics = receipt.get("metrics") if isinstance(receipt.get("metrics"), dict) else {}
        saturation = metrics.get("saturation") if isinstance(metrics.get("saturation"), dict) else {}
        if receipt.get("bounded_coverage_proven", receipt.get("completeness_proven")) is not True:
            return False, "the v4 discovery receipt does not prove bounded source-set coverage"
        if not saturation_accepted(receipt):
            return False, "the v4 discovery receipt has no sanctioned saturation acceptance"
        if saturation.get("method") != "frontier_closure":
            return False, ("the discovery receipt did not close by frontier_closure, so automatic "
                           "closed-frontier approval does not apply")
        if saturation.get("frontier_closed") is not True:
            return False, "the v4 saturation metrics do not record a closed frontier"
        return True, "v4 receipt proves bounded coverage and an accepted frontier_closure saturation path"

    # Backward compatibility for pre-v4 receipts that carried explicit frontier fields.
    if receipt.get("frontier_state") not in {"closed", "effective_closed"}:
        return False, ("the frontier is not closed, so stopping here is a scope decision "
                       "and belongs to the user")
    unaccounted = receipt.get("unaccounted_urls")
    if isinstance(unaccounted, list) and unaccounted:
        return False, f"{len(unaccounted)} expected URL(s) are still unaccounted for"

    exclusions = receipt.get("exclusions") if isinstance(receipt.get("exclusions"), list) else []
    content_like = [e for e in exclusions if isinstance(e, dict)
                    and e.get("classification") not in {
                        "index_or_navigation", "production_metadata",
                        "non_content_namespace", "reference_only", "duplicate",
                        "retry_budget_exhausted", "confirmed_dead"}]
    if content_like:
        return False, (f"{len(content_like)} exclusion(s) are not classified as non-content; "
                       "excluding possible canon is the user's decision")
    return True, "frontier closed, all expected URLs accounted for, all exclusions non-content"


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = parser.add_subparsers(dest="kind", required=True)

    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--build-state", required=True)
    common.add_argument("--plan", required=True, help="Path to the discovery plan JSON this approval is scoped to")
    common.add_argument("--user-confirmation", help="What the person actually said/approved, quoted or closely paraphrased, not inferred. Required unless --self-approve-closed-frontier applies.")
    common.add_argument(
        "--self-approve-closed-frontier", action="store_true",
        help=(
            "Only valid when the build was initialised with --autonomy evidence-bounded AND the "
            "discovery receipt already shows a closed frontier with every expected URL accounted for "
            "and every exclusion classified non-content. Records the approval as automatic. "
            "Never valid for a scope decision, which remains the user's."
        ),
    )
    common.add_argument("--output", required=True)

    p_excl = sub.add_parser("exclusion", parents=[common])
    p_excl.add_argument("--entry", action="append", default=[], help="'URL|CODE|REASON', repeatable")
    p_excl.add_argument("--approve-saturation-stop", action="store_true", help="Also authorize stopping discovery at the current terminal low-yield state")

    p_single = sub.add_parser("single-round", parents=[common])
    p_single.add_argument("--max-urls", type=int, default=500)

    args = parser.parse_args()

    if getattr(args, "self_approve_closed_frontier", False):
        permitted, reason = closure_is_proven(getattr(args, "build_state", None))
        if not permitted:
            print(f"ERROR: self-approval refused: {reason}", file=sys.stderr)
            return 1
        if not (args.user_confirmation or "").strip():
            args.user_confirmation = (
                "AUTOMATIC (evidence-bounded autonomy): " + reason
            )
    elif not (getattr(args, "user_confirmation", "") or "").strip():
        print("ERROR: --user-confirmation is required", file=sys.stderr)
        return 1
    try:
        root, state = load_build_state(args.build_state)
        build_id = str(state.get("build_id"))
        plan_path = Path(args.plan).resolve()
        if not plan_path.exists():
            raise WorldBuilderError(f"plan file does not exist: {plan_path}")
        plan_sha256, corpus_sha256 = _plan_hashes(plan_path)

        if args.kind == "exclusion":
            approval = build_exclusion(args, build_id, plan_sha256, corpus_sha256)
        else:
            approval = build_single_round(args, build_id, plan_sha256, corpus_sha256)

        output_path = Path(args.output).resolve()
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(json.dumps(approval, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        flag = "--exclusion-approval" if args.kind == "exclusion" else "--single-round-approval"
        print(json.dumps({
            "status": "written",
            "output": str(output_path),
            "kind": approval["kind"],
            "next_step": f"Re-run discovery_gate.py with {flag} {output_path}",
        }, ensure_ascii=False, indent=2))
        return 0
    except (WorldBuilderError, OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        print(step_driver_pointer(), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
