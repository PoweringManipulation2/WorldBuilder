#!/usr/bin/env python3
"""Measure and record the post-merge decision for auto context budgeting."""
from __future__ import annotations
import argparse, json, shutil, sys
from pathlib import Path
from budget_contract import actual_entry_token_measurement, analyze_manifest, analyze_output, load_bound_plan, predict_drop_order, protected_categories, uid_key
from budget_semantics import manifest_rows as _manifest_rows, required_edges as _required_edges
from pipeline_stage_gate import advance as advance_pipeline_stage
from wb_common import WorldBuilderError, atomic_write_json, iter_entries, load_build_state, load_json, resolve_state_path, sha256_file
KIND="worldbuilder-context-budget-review"; CONTRACT="worldbuilder-context-budget-review-v1"

def _require_auto(state):
    if not bool((state.get("budget") or {}).get("auto_review_required")): raise WorldBuilderError("context budget review only applies to an auto context-window build")

def _detail_level(plan): return str(plan.get("profile_id") or "recommended")

def _rows(manifest, data):
    actual={}
    for ref in iter_entries(data):
        ident=ref.entry.get("id", ref.entry.get("uid"))
        if ident is not None: actual[uid_key(ident)]=ref.entry
    _edges, req=_required_edges(manifest); rows=[]
    for row in _manifest_rows(manifest):
        uid=uid_key(row.get("uid",row.get("id"))); entry=actual.get(uid)
        if entry is None: continue
        tokens,_=actual_entry_token_measurement(entry)
        emit=row.get("emit") if isinstance(row.get("emit"),dict) else {}; arch=row.get("architecture") if isinstance(row.get("architecture"),dict) else {}
        rows.append({"uid":uid,"name":row.get("name",""),"tokens":tokens,"weight":int(emit.get("weight",100) or 100),"insertion_order":int(emit.get("insertion_order",100) or 100),"constant":bool(emit.get("constant")) or str((row.get("activation") or {}).get("strategy","")).casefold()=="constant","protected_categories":sorted(protected_categories(row,req))})
    return rows

def measure(build_state):
    root,state=load_build_state(build_state); _require_auto(state)
    before=resolve_state_path(root,state,"context_budget_before"); manifest_path=resolve_state_path(root,state,"manifest")
    if not before.is_file(): raise WorldBuilderError("immutable pre-review snapshot is missing; merge must complete first")
    manifest=load_json(manifest_path); data=load_json(before); plan,_=load_bound_plan(root,state,manifest); detail=analyze_manifest(plan,manifest); out=analyze_output(plan,detail,data,manifest)
    simulations=out.get("simulations",[]); worst=max((int(x.get("estimated_tokens",0)) for x in simulations),default=int(out.get("total_authored_tokens",0)))
    return root,state,plan,manifest,data,{"entry_count":out.get("entries_checked",0),"total_authored_tokens":out.get("total_authored_tokens",0),"worst_case_activation_tokens":worst,"constant_tokens":out.get("constant_tokens",0),"permanent_tokens":out.get("permanent_tokens",0),"opening_tokens":out.get("opening_tokens",0),"warnings":out.get("warnings",[])}

def report(build_state,target_tokens=None):
    root,state,plan,manifest,data,stats=measure(build_state); result={"kind":KIND,"contract":CONTRACT,"status":"review_required","build_id":state.get("build_id"),"context_stats":stats,"detail_level":_detail_level(plan)}
    if target_tokens:
        result["target_tokens"]=target_tokens; result["predicted_drop_order"]=predict_drop_order(_rows(manifest,data),target_tokens,_detail_level(plan))
    return result

def record(build_state,decision,target_tokens=None,prune_proof=None):
    state_path=Path(build_state).resolve(); root,state,plan,manifest,before_data,before_stats=measure(state_path); work=resolve_state_path(root,state,"merge_input")
    if not work.is_file(): raise WorldBuilderError("working merged artifact is missing")
    if decision=="prune" and (not isinstance(target_tokens,int) or target_tokens<=0): raise WorldBuilderError("prune decision requires --target-tokens")
    if decision=="keep" and target_tokens is not None: raise WorldBuilderError("keep decision does not take --target-tokens")
    before_snapshot=resolve_state_path(root,state,"context_budget_before")
    proof_path=None; proof=None
    if decision=="keep":
        if sha256_file(work) != sha256_file(before_snapshot):
            raise WorldBuilderError("keep decision requires the merged artifact to remain unchanged from the immutable pre-review snapshot")
        if prune_proof is not None:
            raise WorldBuilderError("keep decision does not take --prune-proof")
    else:
        if prune_proof is None:
            raise WorldBuilderError("prune decision requires --prune-proof from prune_workflow.py prove; auto mode reuses the existing four-phase pruning workflow")
        proof_path=Path(prune_proof)
        if not proof_path.is_absolute():
            proof_path=(root/proof_path).resolve()
        else:
            proof_path=proof_path.resolve()
        try:
            proof_path.relative_to(root)
        except ValueError as exc:
            raise WorldBuilderError("--prune-proof must be inside the build workspace") from exc
        if not proof_path.is_file():
            raise WorldBuilderError(f"prune proof does not exist: {proof_path}")
        proof=load_json(proof_path)
        if not isinstance(proof,dict) or proof.get("contract") != "worldbuilder-prune-prove-v1":
            raise WorldBuilderError("--prune-proof must be a worldbuilder-prune-prove-v1 receipt")
        if int(proof.get("max_pressure_delta",0)) >= 0:
            raise WorldBuilderError("prune proof must demonstrate a real max-pressure reduction")
        proof_budget=(proof.get("drop_order") or {}).get("token_budget") if isinstance(proof.get("drop_order"),dict) else None
        if isinstance(proof_budget,int) and proof_budget != target_tokens:
            raise WorldBuilderError("--target-tokens must match the prune proof drop_order.token_budget")
    current=load_json(work); detail=analyze_manifest(plan,manifest); out=analyze_output(plan,detail,current,manifest); sims=out.get("simulations",[]); after_worst=max((int(x.get("estimated_tokens",0)) for x in sims),default=int(out.get("total_authored_tokens",0)))
    if decision=="prune" and after_worst >= int(before_stats["worst_case_activation_tokens"]): raise WorldBuilderError("prune decision must be recorded only after prune_workflow has produced a real worst-case reduction")
    after=resolve_state_path(root,state,"context_budget_after"); after.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(work,after)
    receipt={"kind":KIND,"receipt_version":1,"contract":CONTRACT,"status":"passed","build_id":state.get("build_id"),"decision":decision,"target_tokens":target_tokens,"detail_level":_detail_level(plan),"before_sha256":sha256_file(before_snapshot),"after_sha256":sha256_file(after),"before_tokens":before_stats["worst_case_activation_tokens"],"after_tokens":after_worst,"context_stats_before":before_stats}
    if proof_path is not None:
        receipt["prune_proof"]={"path":str(proof_path.relative_to(root)).replace("\\","/"),"sha256":sha256_file(proof_path),"contract":proof.get("contract")}
    if target_tokens: receipt["prediction_after"]=predict_drop_order(_rows(manifest,current),target_tokens,_detail_level(plan))
    rp=resolve_state_path(root,state,"context_budget_review_receipt"); atomic_write_json(rp,receipt); state.setdefault("status",{})["context_budget_review"]="complete"; state.setdefault("budget",{})["review_decision"]=decision; state["budget"]["review_target_tokens"]=target_tokens; atomic_write_json(state_path,state); advance_pipeline_stage(state_path,"context_budget_review"); receipt["receipt"]=str(rp.relative_to(root)).replace("\\","/"); receipt["receipt_sha256"]=sha256_file(rp); return receipt

def main():
    p=argparse.ArgumentParser(description=__doc__); p.add_argument("--build-state",required=True); sub=p.add_subparsers(dest="cmd",required=True); r=sub.add_parser("report"); r.add_argument("--target-tokens",type=int); q=sub.add_parser("record"); q.add_argument("--decision",choices=["keep","prune"],required=True); q.add_argument("--target-tokens",type=int); q.add_argument("--prune-proof"); a=p.parse_args()
    try: result=report(a.build_state,getattr(a,"target_tokens",None)) if a.cmd=="report" else record(a.build_state,a.decision,a.target_tokens,a.prune_proof); print(json.dumps(result,ensure_ascii=False,indent=2)); return 0
    except (WorldBuilderError,OSError,ValueError,json.JSONDecodeError) as exc: print(f"ERROR: {exc}",file=sys.stderr); return 1
if __name__=="__main__": raise SystemExit(main())
