#!/usr/bin/env python3
"""Render and validate WorldBuilder's manifest-backed activation/recursion map.

The manifest is authoritative. ``recursion-map.md`` is a human-readable,
machine-validated projection containing an activation ledger and edge ledger.
Blank optional settings inherit from the frozen default profile; the map emits
only non-default special operations.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from pathlib import Path
from typing import Any

from character_contract import assignment_context as build_character_assignment_context
from character_contract import load_bound_plan as load_character_plan
from character_contract import manifest_character_rows
from era_router_contract import assignment_context as build_era_assignment_context
from era_router_contract import load_bound_plan as load_era_plan
from placement_contract import (
    assignment_context as build_placement_assignment_context,
    load_bound_plan as load_placement_plan,
    validate_manifest as validate_placement_manifest,
)
from budget_contract import (
    analyze_manifest as analyze_budget_manifest,
    build_assignment_context as build_budget_assignment_context,
    load_bound_plan as load_budget_plan,
)
from dynamic_state_contract import (
    analyze_manifest as analyze_dynamic_state_manifest,
    assignment_context as build_dynamic_state_assignment_context,
    load_bound_plan as load_dynamic_state_plan,
)

from wb_common import (
    WorldBuilderError,
    atomic_write_json,
    iter_entries,
    load_build_state,
    load_json,
    resolve_state_path,
    sha256_file,
    step_driver_pointer,
)
from activation_semantics import (
    emit_config as _emit,
    extension_config as _extensions,
    first_value as _first,
    list_strings as _list_strings,
    manifest_activation as _manifest_activation,
    manifest_entries as _entries,
    profile_defaults as _profile_defaults,
    resolved_emit as _resolved_emit,
    setting as _setting,
    uid_key,
)

HEADER_PREFIX = "WORLDBUILDER-ARTIFACT:"
BEGIN = "<!-- WORLDBUILDER-ACTIVATION-MAP-BEGIN -->"
END = "<!-- WORLDBUILDER-ACTIVATION-MAP-END -->"
CONTRACT = "worldbuilder-activation-graph-v1"
MAP_VERSION = 1
RECEIPT_VERSION = 1
CRITICAL_NON_VECTOR_LAYERS = {"world_index", "world_core", "world_invariants", "era_context"}

# Frozen-source versions this gate accepts. A build freezes its own copy of
# both files at init, so every historical version stays readable; the range is
# derived from these sets rather than restated in the error text, which is how
# the two previously drifted apart.
SUPPORTED_REGISTRY_VERSIONS = {1, 2, 3, 4, 5}
SUPPORTED_PROFILE_VERSIONS = {1, 2, 3}


def _version_range(values: set[int]) -> str:
    return f"{min(values)}-{max(values)}"























def _expected_strategy(resolved: dict[str, Any]) -> str:
    if not resolved["enabled"]:
        return "disabled"
    if resolved["constant"]:
        return "constant"
    if resolved["vectorized"] and resolved["primary_keywords"]:
        return "hybrid"
    if resolved["vectorized"]:
        return "vector-only"
    if resolved["primary_keywords"]:
        return "keyword"
    return "manual"


def _special(resolved: dict[str, Any], defaults: dict[str, Any], strategy: str) -> dict[str, Any]:
    mapping = {
        "enabled": "enabled",
        "vectorized": "vectorized",
        "selective": "selective",
        "match_scenario": "match_scenario",
        "position": "position",
        "insertion_order": "insertion_order",
        "priority": "priority",
        "use_probability": "use_probability",
        "probability": "probability",
        "prevent_recursion": "prevent_recursion",
        "exclude_recursion": "exclude_recursion",
        "delay_until_recursion": "delay_until_recursion",
        "sticky": "sticky",
        "cooldown": "cooldown",
        "delay": "delay",
        "depth": "depth",
        "role": "role",
        "group": "group",
        "group_weight": "group_weight",
        "group_override": "group_override",
        "group_scoring": "group_scoring",
        "case_sensitive": "case_sensitive",
        "use_regex": "use_regex",
        "character_filter": "character_filter",
        "generation_triggers": "generation_triggers",
        "automation_id": "automation_id",
        "outlet": "outlet",
    }
    result: dict[str, Any] = {}
    for key, out_name in mapping.items():
        value = resolved.get(key)
        default = defaults.get(key)
        if value != default:
            result[out_name] = value
    # Strategy already exposes constant/vector state; avoid redundant false/true noise.
    if strategy in {"hybrid", "vector-only"}:
        result.pop("vectorized", None)
    if strategy == "disabled":
        result.pop("enabled", None)
    return result


def load_registry_profile(root: Path, state: dict[str, Any]) -> tuple[dict[str, Any], Path, dict[str, Any], Path]:
    registry_path = resolve_state_path(root, state, "field_registry")
    profile_path = resolve_state_path(root, state, "default_profile")
    if not registry_path.exists() or not profile_path.exists():
        raise WorldBuilderError(f"field registry and default profile must both exist and be frozen before planning; missing: {[p for p in (registry_path, profile_path) if not p.exists()]}")
    registry = load_json(registry_path)
    profile = load_json(profile_path)
    if not isinstance(registry, dict) or registry.get("kind") != "worldbuilder-field-registry" or registry.get("registry_version") not in SUPPORTED_REGISTRY_VERSIONS:
        raise WorldBuilderError(f"{registry_path.name} has the wrong format (kind={registry.get('kind') if isinstance(registry, dict) else type(registry).__name__!r}, registry_version={registry.get('registry_version') if isinstance(registry, dict) else 'n/a'}; need kind='worldbuilder-field-registry', version in {_version_range(SUPPORTED_REGISTRY_VERSIONS)})")
    if not isinstance(profile, dict) or profile.get("kind") != "worldbuilder-default-profile" or profile.get("profile_version") not in SUPPORTED_PROFILE_VERSIONS:
        raise WorldBuilderError(f"{profile_path.name} has the wrong format (kind={profile.get('kind') if isinstance(profile, dict) else type(profile).__name__!r}, profile_version={profile.get('profile_version') if isinstance(profile, dict) else 'n/a'}; need kind='worldbuilder-default-profile', version in {_version_range(SUPPORTED_PROFILE_VERSIONS)})")
    build_id = state.get("build_id")
    if registry.get("build_id") != build_id or profile.get("build_id") != build_id:
        raise WorldBuilderError(f"field registry (build_id={registry.get('build_id')!r}) or default profile (build_id={profile.get('build_id')!r}) does not match this build's own build_id ({build_id!r})")
    if profile.get("field_registry_sha256") != sha256_file(registry_path):
        raise WorldBuilderError(f"{profile_path.name}'s field_registry_sha256 does not match {registry_path.name}'s actual current hash: the profile was frozen against a different version of the registry")
    return registry, registry_path, profile, profile_path


def _validate_manifest_contract(manifest: dict[str, Any], registry_path: Path, profile_path: Path) -> None:
    contract = manifest.get("planning_contract")
    if not isinstance(contract, dict) or contract.get("kind") != "worldbuilder-planning-authority" or contract.get("version") != 1:
        raise WorldBuilderError(f"manifest's planning_contract must have kind='worldbuilder-planning-authority', version=1, found kind={contract.get('kind') if isinstance(contract, dict) else type(contract).__name__!r}, version={contract.get('version') if isinstance(contract, dict) else 'n/a'}")
    if contract.get("field_registry_sha256") != sha256_file(registry_path):
        raise WorldBuilderError(f"manifest's planning_contract.field_registry_sha256 does not match {registry_path.name}'s actual current hash: the manifest was authored against a different version of the registry")
    if contract.get("default_profile_sha256") != sha256_file(profile_path):
        raise WorldBuilderError(f"manifest's planning_contract.default_profile_sha256 does not match {profile_path.name}'s actual current hash: the manifest was authored against a different version of the profile")
    graph = manifest.get("activation_graph")
    if not isinstance(graph, dict) or graph.get("contract") != CONTRACT or graph.get("graph_version") != 1:
        raise WorldBuilderError(f"manifest's activation_graph must have contract={CONTRACT!r}, graph_version=1, found contract={graph.get('contract') if isinstance(graph, dict) else type(graph).__name__!r}, graph_version={graph.get('graph_version') if isinstance(graph, dict) else 'n/a'}")


def canonical_projection(manifest: dict[str, Any], profile: dict[str, Any]) -> dict[str, Any]:
    rows = _entries(manifest)
    by_uid: dict[str, dict[str, Any]] = {}
    ledgers: list[dict[str, Any]] = []
    for entry in rows:
        raw_uid = entry.get("uid", entry.get("id"))
        key = uid_key(raw_uid)
        if key in by_uid:
            raise WorldBuilderError(f"manifest repeats UID {key}")
        name = entry.get("name")
        entry_type = entry.get("type")
        arch = entry.get("architecture")
        if not isinstance(name, str) or not name.strip() or not isinstance(entry_type, str) or not entry_type.strip() or not isinstance(arch, dict):
            raise WorldBuilderError(f"manifest entry {key} needs name, type, and architecture")
        layer = arch.get("layer")
        if not isinstance(layer, str) or not layer.strip():
            raise WorldBuilderError(f"manifest entry {key} lacks architecture.layer")
        era_ids = _list_strings(arch.get("era_ids", []), f"entry {key} era_ids")
        activation = _manifest_activation(entry)
        defaults = _profile_defaults(profile, layer)
        resolved = _resolved_emit(entry, defaults)
        expected_strategy = _expected_strategy(resolved)
        if activation["strategy"] != expected_strategy:
            raise WorldBuilderError(
                f"manifest entry {key} strategy {activation['strategy']!r} disagrees with emitted settings ({expected_strategy})"
            )
        if layer in CRITICAL_NON_VECTOR_LAYERS and activation["strategy"] in {"hybrid", "vector-only"}:
            raise WorldBuilderError(f"critical layer {layer} entry {key} cannot depend on vector retrieval")
        if activation["strategy"] == "vector-only" and resolved["primary_keywords"]:
            raise WorldBuilderError(f"vector-only entry {key} must not retain primary keywords")
        if activation["strategy"] in {"keyword", "hybrid"} and not resolved["primary_keywords"]:
            raise WorldBuilderError(f"{activation['strategy']} entry {key} requires primary keywords")
        if activation["recursion_role"] in {"leaf", "blocked"} and activation["emits"]:
            raise WorldBuilderError(f"{activation['recursion_role']} entry {key} cannot declare emitted recursion terms")
        if activation["recursion_role"] in {"leaf", "blocked"} and not resolved["prevent_recursion"]:
            raise WorldBuilderError(
                f"entry {key} declares recursion_role={activation['recursion_role']!r} but frozen resolution leaves "
                "prevent_recursion=false; an entry declared as a recursion terminal must actually prevent recursion. "
                "Set an entry-level prevent_recursion=true override or change the recursion role."
            )
        ledger = {
            "uid": raw_uid,
            "name": name.strip(),
            "type": entry_type.strip(),
            "layer": layer.strip(),
            "era_ids": era_ids,
            "strategy": activation["strategy"],
            "primary_keywords": resolved["primary_keywords"],
            "secondary_keywords": resolved["secondary_keywords"],
            "secondary_logic": resolved["secondary_logic"],
            "recursion_role": activation["recursion_role"],
            "emits": activation["emits"],
            "forbidden_emits": activation["forbidden_emits"],
            "special": _special(resolved, defaults, activation["strategy"]),
            "incoming_edges": 0,
            "outgoing_edges": 0,
        }
        if entry_type.strip().casefold() == "character":
            character_id = arch.get("character_id")
            state_id = arch.get("character_state_id")
            if not isinstance(character_id, str) or not character_id.strip() or not isinstance(state_id, str) or not state_id.strip():
                raise WorldBuilderError(f"character manifest entry {key} lacks character_id/character_state_id")
            ledger["character_id"] = character_id.strip()
            ledger["character_state_id"] = state_id.strip()
        by_uid[key] = {"entry": entry, "ledger": ledger, "resolved": resolved}
        ledgers.append(ledger)

    graph = manifest["activation_graph"]
    raw_edges = graph.get("edges")
    if not isinstance(raw_edges, list):
        raise WorldBuilderError(f"manifest's activation_graph.edges must be an array, found {type(raw_edges).__name__}")
    edges: list[dict[str, Any]] = []
    seen_edges: set[tuple[str, str, str]] = set()
    declared_by_source: dict[str, set[str]] = {uid: set() for uid in by_uid}
    for index, edge in enumerate(raw_edges):
        if not isinstance(edge, dict):
            raise WorldBuilderError(f"activation_graph.edges[{index}] must be a JSON object, found {type(edge).__name__}")
        source = uid_key(edge.get("source_uid"))
        target = uid_key(edge.get("target_uid"))
        if source not in by_uid or target not in by_uid:
            unknown = [u for u in (("source_uid", source), ("target_uid", target)) if u[1] not in by_uid]
            raise WorldBuilderError(f"activation_graph.edges[{index}] references a UID not in the manifest: {unknown}")
        trigger = edge.get("trigger")
        target_key = edge.get("target_key")
        reason = edge.get("reason")
        if not isinstance(trigger, str) or not trigger.strip() or not isinstance(target_key, str) or not target_key.strip():
            raise WorldBuilderError(f"activation_graph.edges[{index}] ({source}->{target}) needs non-empty 'trigger' ({trigger!r}) and 'target_key' ({target_key!r}) fields")
        if not isinstance(reason, str) or not reason.strip():
            raise WorldBuilderError(f"activation_graph.edges[{index}] ({source}->{target}) needs a non-empty 'reason' field")
        level = edge.get("level")
        cost = edge.get("fan_out_cost", 1)
        required = edge.get("required", True)
        match_mode = edge.get("match_mode", "literal")
        era_ids = _list_strings(edge.get("era_ids", []), f"activation edge {index} era_ids")
        if not isinstance(level, int) or isinstance(level, bool) or level < 1:
            raise WorldBuilderError(f"activation edge {index} level must be a positive integer")
        if not isinstance(cost, int) or isinstance(cost, bool) or cost < 0:
            raise WorldBuilderError(f"activation edge {index} fan_out_cost must be a non-negative integer")
        if not isinstance(required, bool):
            raise WorldBuilderError(f"activation edge {index} required must be boolean")
        if match_mode not in {"literal", "regex"}:
            raise WorldBuilderError(f"activation edge {index} match_mode must be literal or regex")
        source_emits = {item.casefold() for item in by_uid[source]["ledger"]["emits"]}
        if trigger.strip().casefold() not in source_emits:
            raise WorldBuilderError(f"activation edge {source}->{target} trigger is not declared in source emits")
        target_keys = by_uid[target]["ledger"]["primary_keywords"]
        if match_mode == "literal":
            if target_key.strip().casefold() not in {item.casefold() for item in target_keys}:
                raise WorldBuilderError(f"activation edge {source}->{target} target_key is not a target primary keyword")
            if trigger.strip().casefold() != target_key.strip().casefold():
                raise WorldBuilderError(f"literal activation edge {source}->{target} trigger must equal target_key")
        else:
            if target_key not in target_keys:
                raise WorldBuilderError(f"regex activation edge {source}->{target} target_key is not a target primary keyword")
            try:
                if re.search(target_key, trigger) is None:
                    raise WorldBuilderError(f"regex activation edge {source}->{target} trigger does not match target_key")
            except re.error as exc:
                raise WorldBuilderError(f"activation edge {source}->{target} has invalid regex target_key") from exc
        signature = (source, target, trigger.strip().casefold())
        if signature in seen_edges:
            raise WorldBuilderError(f"duplicate activation edge {source}->{target} for {trigger!r}")
        seen_edges.add(signature)
        declared_by_source[source].add(trigger.strip().casefold())
        normalized = {
            "source_uid": by_uid[source]["ledger"]["uid"],
            "target_uid": by_uid[target]["ledger"]["uid"],
            "trigger": trigger.strip(),
            "target_key": target_key.strip(),
            "match_mode": match_mode,
            "level": level,
            "required": required,
            "era_ids": era_ids,
            "fan_out_cost": cost,
            "reason": reason.strip(),
        }
        edges.append(normalized)
        by_uid[source]["ledger"]["outgoing_edges"] += 1
        by_uid[target]["ledger"]["incoming_edges"] += 1

    # Every emitted graph term that matches another primary key must be declared.
    key_owners: dict[str, set[str]] = {}
    for target_uid, record in by_uid.items():
        for key in record["ledger"]["primary_keywords"]:
            key_owners.setdefault(key.casefold(), set()).add(target_uid)
    for source_uid, record in by_uid.items():
        role = record["ledger"]["recursion_role"]
        outgoing_count = record["ledger"]["outgoing_edges"]
        incoming_count = record["ledger"]["incoming_edges"]
        if role in {"leaf", "blocked"} and outgoing_count:
            raise WorldBuilderError(f"{role} entry {source_uid} has outgoing activation edges")
        if outgoing_count and record["resolved"]["prevent_recursion"]:
            raise WorldBuilderError(f"entry {source_uid} has outgoing edges while prevent_recursion is enabled")
        if incoming_count and record["resolved"]["exclude_recursion"]:
            raise WorldBuilderError(f"entry {source_uid} has incoming edges while exclude_recursion is enabled")
        if record["resolved"]["delay_until_recursion"] and incoming_count == 0:
            raise WorldBuilderError(f"entry {source_uid} delays until recursion but has no incoming edge")
        for term in record["ledger"]["emits"]:
            owners = key_owners.get(term.casefold(), set()) - {source_uid}
            if owners and term.casefold() not in declared_by_source[source_uid]:
                raise WorldBuilderError(f"entry {source_uid} emits undeclared recursion term {term!r}")

    return {"entries": ledgers, "edges": edges}


def parse_map(path: Path) -> tuple[dict[str, Any], dict[str, Any]]:
    text = path.read_text(encoding="utf-8", errors="strict")
    first = next((line.strip() for line in text.splitlines() if line.strip()), "")
    if not first.startswith(HEADER_PREFIX):
        raise WorldBuilderError(f"{path.name}'s first non-blank line must start with '{HEADER_PREFIX}' followed by a JSON object; found: {first[:60]!r}")
    try:
        header = json.loads(first[len(HEADER_PREFIX):].strip())
    except json.JSONDecodeError as exc:
        raise WorldBuilderError(f"{path.name}'s {HEADER_PREFIX} header line has invalid JSON: {exc}") from exc
    if not isinstance(header, dict):
        raise WorldBuilderError(f"{path.name}'s {HEADER_PREFIX} header must be a JSON object, found {type(header).__name__}")
    start = text.find(BEGIN)
    end = text.find(END)
    if start < 0 or end < 0 or end <= start:
        raise WorldBuilderError(f"{path.name} is missing the {BEGIN!r} / {END!r} payload markers, or they're out of order")
    segment = text[start + len(BEGIN):end]
    match = re.search(r"```json\s*(\{.*\})\s*```", segment, re.DOTALL)
    if not match:
        raise WorldBuilderError(f"{path.name} has no ```json ... ``` code block between its {BEGIN!r}/{END!r} markers")
    try:
        payload = json.loads(match.group(1))
    except json.JSONDecodeError as exc:
        raise WorldBuilderError(f"{path.name}'s activation-map JSON block is invalid: {exc}") from exc
    if not isinstance(payload, dict):
        raise WorldBuilderError(f"{path.name}'s activation-map payload must be a JSON object, found {type(payload).__name__}")
    return header, payload


def render_markdown(*, build_id: str, manifest_sha: str, registry_sha: str, profile_sha: str, projection: dict[str, Any], discovery_sha: str | None = None) -> str:
    header: dict[str, Any] = {
        "kind": "recursion_map",
        "build_id": build_id,
        "manifest_sha256": manifest_sha,
        "field_registry_sha256": registry_sha,
        "default_profile_sha256": profile_sha,
        "activation_contract": CONTRACT,
        "map_version": MAP_VERSION,
    }
    if discovery_sha:
        header["discovery_receipt_sha256"] = discovery_sha
    payload = {
        "kind": "worldbuilder-activation-map",
        "map_version": MAP_VERSION,
        "contract": CONTRACT,
        "build_id": build_id,
        "manifest_sha256": manifest_sha,
        "field_registry_sha256": registry_sha,
        "default_profile_sha256": profile_sha,
        "entries": projection["entries"],
        "edges": projection["edges"],
    }
    lines = [
        HEADER_PREFIX + " " + json.dumps(header, ensure_ascii=False, separators=(",", ":")),
        "",
        "# Activation and Recursion Map",
        "",
        "The manifest is authoritative. Blank optional settings inherit from the frozen default profile.",
        "`None` means explicitly disabled; `unsupported` means the selected target cannot represent the setting.",
        "",
        "## Entry activation ledger",
        "",
        "| UID | Name | Layer | Era | Strategy | Primary keys | Secondary keys | Logic | Recursion role | In | Out | Special |",
        "|---|---|---|---|---|---|---|---|---|---:|---:|---|",
    ]
    for row in projection["entries"]:
        special = ", ".join(f"{key}={value}" for key, value in row["special"].items())
        lines.append(
            "| {uid} | {name} | {layer} | {era} | {strategy} | {primary} | {secondary} | {logic} | {role} | {incoming} | {outgoing} | {special} |".format(
                uid=str(row["uid"]).replace("|", "\\|"),
                name=row["name"].replace("|", "\\|"),
                layer=row["layer"].replace("|", "\\|"),
                era="; ".join(row["era_ids"]),
                strategy=row["strategy"],
                primary="; ".join(row["primary_keywords"]),
                secondary="; ".join(row["secondary_keywords"]),
                logic="" if row["secondary_logic"] is None else str(row["secondary_logic"]),
                role=row["recursion_role"],
                incoming=row["incoming_edges"],
                outgoing=row["outgoing_edges"],
                special=special.replace("|", "\\|"),
            )
        )
    lines.extend(["", "## Recursion edge ledger", ""])
    if projection["edges"]:
        lines.extend([
            "| Source | Target | Trigger emitted by source | Target key | Level | Required | Era | Fan-out | Reason |",
            "|---|---|---|---|---:|---|---|---:|---|",
        ])
        for edge in projection["edges"]:
            # Escaped outside the f-string: a backslash inside an f-string expression is
            # 3.12+ syntax and crashes the 3.10 this skill claims to support.
            escaped_reason = edge["reason"].replace("|", "\\|")
            eras = "; ".join(edge["era_ids"])
            required = "yes" if edge["required"] else "no"
            lines.append(
                f"| {edge['source_uid']} | {edge['target_uid']} | {edge['trigger']} | "
                f"{edge['target_key']} | {edge['level']} | {required} | {eras} | "
                f"{edge['fan_out_cost']} | {escaped_reason} |"
            )
    else:
        lines.append("No recursion edges are planned.")
    lines.extend([
        "",
        BEGIN,
        "```json",
        json.dumps(payload, ensure_ascii=False, indent=2),
        "```",
        END,
        "",
    ])
    return "\n".join(lines)


def validate_payload(payload: dict[str, Any], expected: dict[str, Any], *, build_id: str, manifest_sha: str, registry_sha: str, profile_sha: str) -> None:
    expected_meta = {
        "kind": "worldbuilder-activation-map",
        "map_version": MAP_VERSION,
        "contract": CONTRACT,
        "build_id": build_id,
        "manifest_sha256": manifest_sha,
        "field_registry_sha256": registry_sha,
        "default_profile_sha256": profile_sha,
    }
    for key, value in expected_meta.items():
        if payload.get(key) != value:
            raise WorldBuilderError(f"activation-map payload is stale or mismatched at {key}")
    if payload.get("entries") != expected["entries"]:
        payload_entries = payload.get("entries") if isinstance(payload.get("entries"), list) else []
        payload_uids = {str(row.get("uid")) for row in payload_entries if isinstance(row, dict)}
        expected_uids = {str(row.get("uid")) for row in expected["entries"] if isinstance(row, dict)}
        changed = sorted(
            str(row.get("uid")) for row in expected["entries"]
            if isinstance(row, dict) and str(row.get("uid")) in payload_uids
            and next((p for p in payload_entries if isinstance(p, dict) and str(p.get("uid")) == str(row.get("uid"))), None) != row
        )
        raise WorldBuilderError(
            f"activation-map entry ledger does not exactly project the manifest: missing_uids={sorted(expected_uids - payload_uids)}, "
            f"extra_uids={sorted(payload_uids - expected_uids)}, changed_uids={changed}"
        )
    if payload.get("edges") != expected["edges"]:
        raise WorldBuilderError(
            f"activation-map edge ledger does not exactly project the manifest ({len(payload.get('edges', []) if isinstance(payload.get('edges'), list) else [])} edges present, "
            f"{len(expected['edges'])} expected); regenerate the activation map from the current manifest"
        )


def validate(build_state: str, *, write_receipt: bool = True) -> dict[str, Any]:
    root, state = load_build_state(build_state)
    build_id = str(state.get("build_id", ""))
    manifest_path = resolve_state_path(root, state, "manifest")
    map_path = resolve_state_path(root, state, "recursion_map")
    if not manifest_path.exists() or not map_path.exists():
        raise WorldBuilderError(f"both the manifest and recursion map must exist; missing: {[str(p) for p in (manifest_path, map_path) if not p.exists()]}")
    manifest = load_json(manifest_path)
    if not isinstance(manifest, dict):
        raise WorldBuilderError(f"{manifest_path.name} must be a JSON object, found {type(manifest).__name__}")
    registry, registry_path, profile, profile_path = load_registry_profile(root, state)
    _validate_manifest_contract(manifest, registry_path, profile_path)
    projection = canonical_projection(manifest, profile)
    manifest_sha = sha256_file(manifest_path)
    registry_sha = sha256_file(registry_path)
    profile_sha = sha256_file(profile_path)
    header, payload = parse_map(map_path)
    expected_header = {
        "kind": "recursion_map",
        "build_id": build_id,
        "manifest_sha256": manifest_sha,
        "field_registry_sha256": registry_sha,
        "default_profile_sha256": profile_sha,
        "activation_contract": CONTRACT,
        "map_version": MAP_VERSION,
    }
    for key, value in expected_header.items():
        if header.get(key) != value:
            raise WorldBuilderError(f"recursion-map header is stale or mismatched at {key}")
    validate_payload(payload, projection, build_id=build_id, manifest_sha=manifest_sha, registry_sha=registry_sha, profile_sha=profile_sha)
    result = {
        "kind": "worldbuilder-activation-map-gate",
        "receipt_version": RECEIPT_VERSION,
        "status": "passed",
        "build_id": build_id,
        "contract": CONTRACT,
        "manifest": str(manifest_path.relative_to(root)).replace("\\", "/"),
        "manifest_sha256": manifest_sha,
        "recursion_map": str(map_path.relative_to(root)).replace("\\", "/"),
        "recursion_map_sha256": sha256_file(map_path),
        "field_registry": str(registry_path.relative_to(root)).replace("\\", "/"),
        "field_registry_sha256": registry_sha,
        "default_profile": str(profile_path.relative_to(root)).replace("\\", "/"),
        "default_profile_sha256": profile_sha,
        "entry_count": len(projection["entries"]),
        "edge_count": len(projection["edges"]),
    }
    if write_receipt:
        receipt_path = resolve_state_path(root, state, "activation_map_receipt")
        atomic_write_json(receipt_path, result)
        result["receipt"] = str(receipt_path)
        result["receipt_sha256"] = sha256_file(receipt_path)
    return result


def render(build_state: str) -> dict[str, Any]:
    root, state = load_build_state(build_state)
    build_id = str(state.get("build_id", ""))
    manifest_path = resolve_state_path(root, state, "manifest")
    if not manifest_path.exists():
        raise WorldBuilderError(f"manifest does not exist at {manifest_path}: check paths.manifest, or author the manifest first")
    manifest = load_json(manifest_path)
    if not isinstance(manifest, dict):
        raise WorldBuilderError(f"{manifest_path.name} must be a JSON object, found {type(manifest).__name__}")
    registry, registry_path, profile, profile_path = load_registry_profile(root, state)
    _validate_manifest_contract(manifest, registry_path, profile_path)
    projection = canonical_projection(manifest, profile)
    discovery_sha = None
    discovery = state.get("discovery") if isinstance(state.get("discovery"), dict) else {}
    if discovery.get("required"):
        path = resolve_state_path(root, state, "discovery_receipt")
        if path.exists():
            discovery_sha = sha256_file(path)
    text = render_markdown(
        build_id=build_id,
        manifest_sha=sha256_file(manifest_path),
        registry_sha=sha256_file(registry_path),
        profile_sha=sha256_file(profile_path),
        projection=projection,
        discovery_sha=discovery_sha,
    )
    map_path = resolve_state_path(root, state, "recursion_map")
    map_path.parent.mkdir(parents=True, exist_ok=True)
    temporary = map_path.with_suffix(map_path.suffix + ".tmp")
    temporary.write_text(text, encoding="utf-8", newline="\n")
    temporary.replace(map_path)
    return {"status": "rendered", "path": str(map_path), "entries": len(projection["entries"]), "edges": len(projection["edges"]), "sha256": sha256_file(map_path)}


def slice_dependency_hash(root: Path, state: dict[str, Any], uids: list[Any]) -> dict[str, Any]:
    """Hash only what an assignment's correctness actually depends on.

    An assignment embeds its selected rows, the edges touching them, and summaries of
    their neighbours. A manifest change elsewhere cannot affect it. Binding the receipt
    to the whole manifest therefore expires every in-flight assignment whenever any
    entry anywhere changes, which strands completed per-entry checkpoints that are
    still on disk and still correct.

    Deliberately does not run full map validation: this is called on the recovery path,
    where the map may already be mid-change, and a hash of the current dependency set
    is exactly what is wanted.
    """
    map_path = resolve_state_path(root, state, "recursion_map")
    _header, payload = parse_map(map_path)
    wanted = [uid_key(value) for value in uids]
    rows = {uid_key(row.get("uid")): row for row in payload["entries"] if isinstance(row, dict)}
    missing = [uid for uid in wanted if uid not in rows]
    if missing:
        raise WorldBuilderError("slice hash requests unknown UIDs: " + ", ".join(missing))

    selected = set(wanted)
    edges = [e for e in payload["edges"]
             if uid_key(e["target_uid"]) in selected or uid_key(e["source_uid"]) in selected]
    neighbours = sorted({uid_key(endpoint)
                         for edge in edges
                         for endpoint in (edge["source_uid"], edge["target_uid"])
                         if uid_key(endpoint) not in selected})

    per_uid: dict[str, str] = {}
    for uid in wanted:
        material = {
            "row": rows[uid],
            "edges": sorted(
                (json.dumps(e, sort_keys=True, ensure_ascii=False) for e in edges
                 if uid in (uid_key(e["source_uid"]), uid_key(e["target_uid"]))),
            ),
        }
        per_uid[uid] = hashlib.sha256(
            json.dumps(material, sort_keys=True, ensure_ascii=False).encode("utf-8")
        ).hexdigest()

    neighbour_material = {
        key: {field: rows[key].get(field) for field in
              ("uid", "name", "type", "layer", "era_ids", "strategy", "primary_keywords")}
        for key in neighbours if key in rows
    }
    combined = {
        "uids": per_uid,
        "neighbours": hashlib.sha256(
            json.dumps(neighbour_material, sort_keys=True, ensure_ascii=False).encode("utf-8")
        ).hexdigest(),
    }
    return {
        "slice_sha256": hashlib.sha256(
            json.dumps(combined, sort_keys=True, ensure_ascii=False).encode("utf-8")
        ).hexdigest(),
        "per_uid_sha256": per_uid,
        "neighbour_sha256": combined["neighbours"],
    }



def build_soul_assignment_context(root: Path, state: dict[str, Any], manifest: dict[str, Any]) -> dict[str, Any]:
    """Carry the approved voice into the assignment, or say plainly that none applies.

    Returns the operational parts only: rules a worker acts on while writing. The
    runtime guide ships with the artifact and is not a worker instruction, so it is
    deliberately excluded to avoid a worker treating shipped prose as a directive.
    """
    architecture = manifest.get("architecture") if isinstance(manifest.get("architecture"), dict) else {}
    if architecture.get("soul_voice") != "worldbuilder-soul-voice-v1":
        return {"contract": None, "applies": False,
                "note": "no soul profile was approved for this build"}

    path = resolve_state_path(root, state, "soul_profile", required=False)
    if path is None or not path.exists():
        path = root / "artifacts" / "soul-profile.json"
    if not path.exists():
        raise WorldBuilderError(
            f"manifest binds a soul profile but {path} is missing; "
            "workers would write to an inferred voice"
        )
    profile = load_json(path)
    if not isinstance(profile, dict):
        raise WorldBuilderError(f"{path} must be a JSON object, found {type(profile).__name__}")

    bound = manifest.get("soul_profile_sha256")
    if bound and bound != sha256_file(path):
        raise WorldBuilderError(
            f"manifest's soul_profile_sha256 ({bound!r}) does not match {path}'s actual current hash ({sha256_file(path)!r}): "
            "regenerate assignments against the current soul profile, or re-approve it if this change was intentional"
        )
    return {
        "contract": "worldbuilder-soul-voice-v1",
        "applies": True,
        "profile_sha256": sha256_file(path),
        "target_type": profile.get("target_type"),
        "voice_rules": profile.get("voice_rules", []),
        "anti_patterns": profile.get("anti_patterns", []),
        "required_markers": profile.get("required_markers", []),
        "note": ("Write every prose-bearing entry to these rules. Anti-patterns are "
                 "rejected at output; do not paraphrase around them."),
    }


def build_assignment_slice(build_state: str, uids: list[Any]) -> dict[str, Any]:
    root, state = load_build_state(build_state)
    result = validate(build_state, write_receipt=False)
    manifest_path = resolve_state_path(root, state, "manifest")
    try:
        manifest = load_json(manifest_path)
    except FileNotFoundError as exc:
        raise WorldBuilderError(f"manifest does not exist at {manifest_path}: check paths.manifest, or author the manifest first") from exc
    if not isinstance(manifest, dict):
        raise WorldBuilderError(f"{manifest_path.name} must be a JSON object, found {type(manifest).__name__}")
    map_path = resolve_state_path(root, state, "recursion_map")
    _header, payload = parse_map(map_path)
    wanted = [uid_key(value) for value in uids]
    if len(set(wanted)) != len(wanted):
        raise WorldBuilderError("assignment map slice contains duplicate UIDs")
    rows = {uid_key(row.get("uid")): row for row in payload["entries"] if isinstance(row, dict)}
    missing = [uid for uid in wanted if uid not in rows]
    if missing:
        raise WorldBuilderError("assignment map slice requests unknown UIDs: " + ", ".join(missing))
    selected_entries = [rows[uid] for uid in wanted]
    incoming = [edge for edge in payload["edges"] if uid_key(edge["target_uid"]) in set(wanted)]
    outgoing = [edge for edge in payload["edges"] if uid_key(edge["source_uid"]) in set(wanted)]
    neighbors: dict[str, dict[str, Any]] = {}
    for edge in incoming + outgoing:
        for endpoint in (edge["source_uid"], edge["target_uid"]):
            key = uid_key(endpoint)
            if key not in wanted:
                row = rows[key]
                neighbors[key] = {"uid": row["uid"], "name": row["name"], "type": row["type"], "layer": row["layer"], "era_ids": row["era_ids"], "strategy": row["strategy"], "primary_keywords": row["primary_keywords"]}
    character_plan, character_path, _character_detail = load_character_plan(
        root,
        state,
        manifest,
        required=bool(manifest_character_rows(manifest)),
    )
    character_context = build_character_assignment_context(character_plan, [rows[uid]["uid"] for uid in wanted]) if character_plan else {
        "contract": None,
        "timeframe_mode": None,
        "states": [],
        "relationships": [],
        "selected_manifest_uids": [],
    }
    manifest_architecture = manifest.get("architecture") if isinstance(manifest.get("architecture"), dict) else {}
    era_cfg = manifest_architecture.get("era") if isinstance(manifest_architecture.get("era"), dict) else {}
    era_plan, era_plan_path, _era_detail = load_era_plan(
        root, state, manifest,
        required=era_cfg.get("mode") == "multi" and era_cfg.get("routing") != "root_toggle",
    )
    era_router_context = build_era_assignment_context(era_plan, manifest, [rows[uid]["uid"] for uid in wanted])
    placement_plan, placement_path, placement_profile = load_placement_plan(
        root, state, manifest, required=False
    )
    if placement_plan is not None and placement_profile is not None:
        placement_detail = validate_placement_manifest(placement_plan, manifest, placement_profile)
        placement_context = build_placement_assignment_context(
            placement_plan, placement_detail, [rows[uid]["uid"] for uid in wanted]
        )
        placement_sha = sha256_file(placement_path) if placement_path else None
    else:
        placement_context = {"contract": None, "policy": None, "profile_id": None, "entries": [], "warnings": []}
        placement_sha = None
    budget_plan, budget_path = load_budget_plan(root, state, manifest)
    if budget_plan.get("applicable"):
        budget_detail = analyze_budget_manifest(budget_plan, manifest)
        budget_context = build_budget_assignment_context(
            budget_plan, budget_detail, [rows[uid]["uid"] for uid in wanted]
        )
        budget_sha = sha256_file(budget_path)
    else:
        budget_context = {"contract": budget_plan.get("contract"), "profile_id": budget_plan.get("profile_id"), "entries": [], "warnings": []}
        budget_sha = sha256_file(budget_path)
    dynamic_plan, dynamic_path = load_dynamic_state_plan(root, state, manifest, required=False)
    if dynamic_plan is not None and dynamic_path is not None:
        dynamic_detail = analyze_dynamic_state_manifest(dynamic_plan, manifest)
        dynamic_context = build_dynamic_state_assignment_context(
            dynamic_plan, dynamic_detail, [rows[uid]["uid"] for uid in wanted]
        )
        dynamic_sha = sha256_file(dynamic_path)
    else:
        dynamic_context = {"contract": None, "policy": "off", "entries": [], "groups": [], "greeting_variants": []}
        dynamic_sha = None
    # Soul voice: the manifest marks entries soul_voice_bound and the planning gate
    # enforces it, but nothing carried the rules to the worker. A flag without its
    # payload is a worker inferring the voice it was told not to infer.
    soul_context = build_soul_assignment_context(root, state, manifest)

    dependency = slice_dependency_hash(root, state, uids)
    return {
        "soul_voice": soul_context,
        "slice_sha256": dependency["slice_sha256"],
        "per_uid_sha256": dependency["per_uid_sha256"],
        "kind": "worldbuilder-assignment-map-slice",
        "slice_version": 3,
        "contract": CONTRACT,
        "build_id": state.get("build_id"),
        "manifest_sha256": result["manifest_sha256"],
        "activation_map_sha256": result["recursion_map_sha256"],
        "field_registry_sha256": result["field_registry_sha256"],
        "default_profile_sha256": result["default_profile_sha256"],
        "character_plan_sha256": sha256_file(character_path) if character_path and character_plan else None,
        "era_plan_sha256": sha256_file(era_plan_path) if era_plan_path and era_plan else None,
        "placement_plan_sha256": placement_sha,
        "budget_plan_sha256": budget_sha,
        "dynamic_state_plan_sha256": dynamic_sha,
        "assigned_uids": [rows[uid]["uid"] for uid in wanted],
        "entries": selected_entries,
        "incoming_edges": incoming,
        "outgoing_edges": outgoing,
        "neighbors": [neighbors[key] for key in sorted(neighbors)],
        "character_context": character_context,
        "era_router_context": era_router_context,
        "placement_context": placement_context,
        "budget_context": budget_context,
        "dynamic_state_context": dynamic_context,
    }



def diagnose(build_state: str) -> dict[str, Any]:
    """Report every manifest problem in one pass instead of the first one only.

    Field evidence: a real build hit three separate activation-map failures in
    sequence: undeclared recursion term, then a bad edge level, then
    prevent_recursion on an entry with outgoing edges, discovering each only after
    fixing the last and re-running. All three were present in the manifest from the
    start and were independently detectable.

    Read-only. Later checks can echo an earlier root cause, so fix the first reported
    problem first and re-run. This never substitutes for a passing gate.
    """
    root, state = load_build_state(build_state)
    problems: list[dict[str, Any]] = []

    def record(category: str, message: str, *, uid: Any = None, fix: str = "") -> None:
        problems.append({"category": category, "uid": None if uid is None else str(uid),
                         "problem": message, "suggested_fix": fix})

    manifest_path = resolve_state_path(root, state, "manifest")
    try:
        manifest = load_json(manifest_path)
    except FileNotFoundError:
        return {"kind": "worldbuilder-activation-diagnose", "problems":
                [{"category": "manifest", "uid": None, "problem": f"manifest is missing: {manifest_path}",
                  "suggested_fix": "Author the manifest, or check paths.manifest, before diagnosing the activation map."}]}
    if not isinstance(manifest, dict):
        return {"kind": "worldbuilder-activation-diagnose", "problems":
                [{"category": "manifest", "uid": None, "problem": "manifest is not an object",
                  "suggested_fix": "Repair manifest.json before anything else."}]}

    entries = [ref.entry for ref in iter_entries(manifest) if isinstance(ref.entry, dict)]
    profile = None
    try:
        _registry, _registry_path, profile, _profile_path = load_registry_profile(root, state)
    except (WorldBuilderError, OSError, ValueError, json.JSONDecodeError, AttributeError):
        # Legacy/minimal diagnostic fixtures may expose string path stubs.
        # Profile resolution is optional enrichment for diagnose(), so fall
        # back to the legacy checks instead of crashing the whole report.
        profile = None
    seen: set[str] = set()
    for entry in entries:
        uid = entry.get("uid", entry.get("id"))
        key = uid_key(uid)
        if key in seen:
            record("identity", f"manifest repeats UID {key}", uid=uid,
                   fix="Give each entry a unique uid; re-run manifest_identity.py to reallocate.")
        seen.add(key)

    graph = manifest.get("activation_graph")
    graph = graph if isinstance(graph, dict) else {}
    edges = graph.get("edges") if isinstance(graph.get("edges"), list) else []

    emitters: dict[str, list[str]] = {}
    edge_signatures: set[tuple[str, str, str]] = set()
    for index, edge in enumerate(edges):
        if not isinstance(edge, dict):
            record("edge", f"activation edge {index} must be an object",
                   fix="Each edge needs source_uid, target_uid, term, and level.")
            continue
        level = edge.get("level")
        if not isinstance(level, int) or isinstance(level, bool) or level < 1:
            record("edge", f"activation edge {index} level {level!r} must be a positive integer", uid=edge.get("source_uid"),
                   fix="Levels start at 1. A root's first outgoing edge is level 1, not 0.")
        source, target = uid_key(edge.get("source_uid")), uid_key(edge.get("target_uid"))
        for role, value in (("source", source), ("target", target)):
            if value not in seen:
                record("edge", f"activation edge {index} {role}_uid {value} is not in the manifest", uid=value,
                       fix="Remove the edge or add the entry it references.")
        signature = (source, target, str(edge.get("term", "")))
        if signature in edge_signatures:
            record("edge", f"duplicate activation edge {source}->{target} for "
                           f"{signature[2]!r}", uid=edge.get("source_uid"),
                   fix="Remove the repeated edge; the render step rejects duplicates.")
        edge_signatures.add(signature)
        emitters.setdefault(source, []).append(str(edge.get("term", "")))

    declared_terms = {uid_key(e.get("uid", e.get("id"))): set(
        (e.get("activation", {}) or {}).get("emits", []) if isinstance(e.get("activation"), dict) else []
    ) for e in entries}

    for entry in entries:
        uid = entry.get("uid", entry.get("id"))
        key = uid_key(uid)
        emit = entry.get("emit") if isinstance(entry.get("emit"), dict) else {}
        extensions = emit.get("extensions") if isinstance(emit.get("extensions"), dict) else {}
        prevents = bool(emit.get("prevent_recursion", extensions.get("prevent_recursion")))
        if profile is not None:
            arch = entry.get("architecture") if isinstance(entry.get("architecture"), dict) else {}
            layer = arch.get("layer")
            if isinstance(layer, str) and layer.strip():
                try:
                    activation = _manifest_activation(entry)
                    defaults = _profile_defaults(profile, layer)
                    resolved = _resolved_emit(entry, defaults)
                    prevents = bool(resolved.get("prevent_recursion"))
                    if activation.get("recursion_role") in {"leaf", "blocked"} and not prevents:
                        record(
                            "recursion_resolution",
                            f"entry {key} declares recursion_role={activation.get('recursion_role')!r} but layer/profile resolution yields prevent_recursion=false",
                            uid=uid,
                            fix="Add an entry-level prevent_recursion=true override, or change the recursion role; do not rely on a conflicting layer default.",
                        )
                except WorldBuilderError as exc:
                    record("recursion_resolution", str(exc), uid=uid, fix="Repair the entry/profile activation settings and re-render the map.")
        outgoing = emitters.get(key, [])
        if prevents and outgoing:
            record("recursion", f"entry {key} has outgoing edges while prevent_recursion is enabled", uid=uid,
                   fix="Either set prevent_recursion false so it may seed other entries, or remove its "
                       "outgoing edges so the targets activate on their own keywords.")
        for term in outgoing:
            if term and term not in declared_terms.get(key, set()):
                record("recursion", f"entry {key} emits undeclared recursion term {term!r}", uid=uid,
                       fix=f"Add {term!r} to this entry's activation.emits, or drop the edge.")

    return {
        "kind": "worldbuilder-activation-diagnose",
        "contract": "worldbuilder-activation-diagnose-v1",
        "entry_count": len(entries),
        "edge_count": len(edges),
        "problem_count": len(problems),
        "problems": problems,
        "next": ("Fix the first problem, then re-run --diagnose; later entries can echo an "
                 "earlier cause. Run activation_map_gate.py --render once this reads zero."),
    }


def validate_assignment_slice(build_state: str, assignment: dict[str, Any]) -> None:
    entries = assignment.get("entries")
    if not isinstance(entries, list):
        raise WorldBuilderError("assignment entries must be an array")
    uids = [row.get("uid") for row in entries if isinstance(row, dict)]
    expected = build_assignment_slice(build_state, uids)
    observed = assignment.get("map_slice")
    if observed != expected:
        raise WorldBuilderError("generation assignment map_slice is missing, stale, or does not match the activation map")
    for key in ("activation_map_sha256", "field_registry_sha256", "default_profile_sha256"):
        if assignment.get(key) != expected[key]:
            raise WorldBuilderError(f"generation assignment {key} is missing or stale")
    if expected.get("character_plan_sha256") is not None:
        if assignment.get("character_plan_sha256") != expected["character_plan_sha256"]:
            raise WorldBuilderError("generation assignment character_plan_sha256 is missing or stale")
    if expected.get("era_plan_sha256") is not None:
        if assignment.get("era_plan_sha256") != expected["era_plan_sha256"]:
            raise WorldBuilderError("generation assignment era_plan_sha256 is missing or stale")
    if expected.get("placement_plan_sha256") is not None:
        if assignment.get("placement_plan_sha256") != expected["placement_plan_sha256"]:
            raise WorldBuilderError("generation assignment placement_plan_sha256 is missing or stale")
    if expected.get("budget_plan_sha256") is not None:
        if assignment.get("budget_plan_sha256") != expected["budget_plan_sha256"]:
            raise WorldBuilderError("generation assignment budget_plan_sha256 is missing or stale")
    if expected.get("dynamic_state_plan_sha256") is not None:
        if assignment.get("dynamic_state_plan_sha256") != expected["dynamic_state_plan_sha256"]:
            raise WorldBuilderError("generation assignment dynamic_state_plan_sha256 is missing or stale")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--build-state", required=True)
    action = parser.add_mutually_exclusive_group()
    action.add_argument("--diagnose", action="store_true", help="Read-only sweep: report every manifest activation problem at once instead of stopping at the first.")
    action.add_argument("--render", action="store_true", help="Render recursion-map.md from the authoritative manifest.")
    action.add_argument("--slice", nargs="+", help="Print an assignment map slice for the listed UIDs.")
    args = parser.parse_args()
    try:
        if args.diagnose:
            result = diagnose(args.build_state)
        elif args.render:
            result = render(args.build_state)
        elif args.slice:
            result = build_assignment_slice(args.build_state, args.slice)
        else:
            result = validate(args.build_state, write_receipt=True)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (WorldBuilderError, OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        print(step_driver_pointer(), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
