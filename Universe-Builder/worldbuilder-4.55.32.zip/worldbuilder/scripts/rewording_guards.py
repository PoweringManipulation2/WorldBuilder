#!/usr/bin/env python3
"""Prune revamp: rewording guards.

Per DR-062 (scripts check structure; auditors judge meaning), the plan
splits rewording verification into two parts. This module builds only the
deterministic hard gate; the auditor-judgment half ("every claim ID the
original cited is still supported by the reworded text") is reading
comprehension and is deliberately not attempted here; a reworded_entry
result's "note" field says so explicitly, so nothing downstream mistakes
a clean hard-gate pass for a full rewording approval.

Three deterministic checks:
  - required emitted terms survive: entry["activation"]["emits"] (the
    manifest's own declared terms this entry's content must contain, the
    same field activation_map_gate.py validates never overlaps with
    forbidden_emits) must all still appear in the reworded text.
  - forbidden terms stay absent: entry["activation"]["forbidden_emits"]
    must not appear in the reworded text.
  - named entities, numbers, and dates present before are present after,
    or explicitly declared removed: a mechanical, syntactic extraction
    (mid-sentence capitalization as a proper-noun proxy, digit patterns
    for numbers), not true NER, which would be a content judgment this
    module has no business attempting. A defensible, deterministic proxy
    for "did a concrete fact silently disappear," not a claim about
    meaning.
"""
from __future__ import annotations

import re
from typing import Any

_SENTENCE_SPLIT_RE = re.compile(r"(?<=[.!?])\s+")
_NUMBER_RE = re.compile(r"\b\d+(?:,\d{3})*(?:\.\d+)?\b")
_STRIP_CHARS = ".,!?;:\"'()[]{}"


def extract_candidate_facts(text: str) -> dict[str, set[str]]:
    """Numbers and capitalized (likely-proper-noun) tokens. Sentence-
    initial capitalization is excluded: that is just English grammar,
    not a signal of anything, so only mid-sentence capitalized words
    count. This is a syntactic pattern, not a semantic one: it makes no
    claim about whether a token is meaningful, only whether it was
    present before and is present after."""
    numbers = set(_NUMBER_RE.findall(text or ""))
    proper_nouns: set[str] = set()
    for sentence in _SENTENCE_SPLIT_RE.split(text or ""):
        words = sentence.split()
        for index, word in enumerate(words):
            cleaned = word.strip(_STRIP_CHARS)
            if index == 0 or not cleaned:
                continue
            if cleaned[0].isupper():
                proper_nouns.add(cleaned)
    return {"numbers": numbers, "proper_nouns": proper_nouns}


def check_emitted_terms_survive(entry: dict[str, Any], after_text: str) -> list[str]:
    """Returns the list of declared emit terms missing from after_text:
    empty means the check passes. Uses activation_map_gate.py's own
    _manifest_activation, never a second, independently-derived reading
    of what this entry is declared to emit."""
    from activation_semantics import manifest_activation as _manifest_activation

    activation = _manifest_activation(entry)
    folded = (after_text or "").casefold()
    return sorted(term for term in activation["emits"] if term.casefold() not in folded)


def check_forbidden_terms_absent(entry: dict[str, Any], after_text: str) -> list[str]:
    """Returns the list of forbidden terms found present in after_text:
    empty means the check passes."""
    from activation_semantics import manifest_activation as _manifest_activation

    activation = _manifest_activation(entry)
    folded = (after_text or "").casefold()
    return sorted(term for term in activation["forbidden_emits"] if term.casefold() in folded)


def check_facts_preserved(before_text: str, after_text: str, *, declared_removed: list[str] | None = None) -> dict[str, list[str]]:
    """Returns which numbers/proper-noun tokens present before are
    missing after and NOT in declared_removed: these are the ones that
    silently disappeared. declared_removed lets a caller state "this
    specific fact was intentionally cut," which is not itself judged here
    (whether that declaration is a good idea is exactly the kind of call
    left to whoever reviews it)."""
    declared = {item.casefold() for item in (declared_removed or [])}
    before = extract_candidate_facts(before_text)
    after = extract_candidate_facts(after_text)
    missing_numbers = sorted(n for n in before["numbers"] - after["numbers"] if n.casefold() not in declared)
    missing_proper_nouns = sorted(n for n in before["proper_nouns"] - after["proper_nouns"] if n.casefold() not in declared)
    return {"missing_numbers": missing_numbers, "missing_proper_nouns": missing_proper_nouns}


def rewording_hard_gate(
    entry: dict[str, Any], before_text: str, after_text: str, *, declared_removed: list[str] | None = None,
) -> dict[str, Any]:
    """All three deterministic checks together. passed=True means the
    hard gate is clean; it is not, and must not be read as, a claim
    that the rewording is faithful. Whether every claim ID the original
    cited is still supported is a separate, auditor-judgment question
    this function does not attempt."""
    missing_emits = check_emitted_terms_survive(entry, after_text)
    present_forbidden = check_forbidden_terms_absent(entry, after_text)
    facts = check_facts_preserved(before_text, after_text, declared_removed=declared_removed)
    passed = not missing_emits and not present_forbidden and not facts["missing_numbers"] and not facts["missing_proper_nouns"]
    return {
        "passed": passed,
        "missing_emitted_terms": missing_emits,
        "present_forbidden_terms": present_forbidden,
        "missing_numbers": facts["missing_numbers"],
        "missing_proper_nouns": facts["missing_proper_nouns"],
        "note": (
            "This is the deterministic hard gate only. A pass here means required terms survived, "
            "forbidden terms stayed absent, and no concrete number or proper noun silently disappeared; "
            "it is not a claim that the rewording faithfully preserves meaning. Whether every claim ID "
            "the original text cited is still supported by the reworded text is a reading-comprehension "
            "question for an auditor, not something this function judges."
        ),
    }
