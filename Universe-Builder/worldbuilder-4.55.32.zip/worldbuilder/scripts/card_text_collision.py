#!/usr/bin/env python3
"""Detect lorebook keys that collide with the containing card's own visible prompt text.

This is an advisory detector, not an editor. It reports non-constant embedded
lorebook entries whose own activation keys already match the initial chat
(``first_mes``) or an explicitly enabled character-field matching source. Raw
overlaps in disabled card-field sources are retained separately as latent
diagnostics instead of being mislabeled as active overactivation.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any

from wb_common import canonical_entry_identity, detect_artifact, iter_entries, load_json

REPORT_KIND = "worldbuilder-card-text-key-collision-report"
REPORT_VERSION = 1
CARD_FIELDS = ("description", "personality", "scenario", "first_mes")
ADDITIONAL_SOURCE_FLAGS = {
    "description": ("match_character_description", "matchCharacterDescription"),
    "personality": ("match_character_personality", "matchCharacterPersonality"),
    "scenario": ("match_scenario", "matchScenario"),
}


def _entry_name(entry: dict[str, Any], identity: Any) -> str:
    return str(entry.get("name") or entry.get("comment") or entry.get("title") or identity).strip()


def _entry_keys(entry: dict[str, Any]) -> list[str]:
    value = entry.get("keys")
    if not isinstance(value, list):
        value = entry.get("key")
    if not isinstance(value, list):
        return []
    out: list[str] = []
    seen: set[str] = set()
    for item in value:
        key = str(item).strip()
        folded = key.casefold()
        if key and folded not in seen:
            seen.add(folded)
            out.append(key)
    return out


def _is_constant(entry: dict[str, Any]) -> bool:
    if bool(entry.get("constant")):
        return True
    activation = entry.get("activation")
    return isinstance(activation, dict) and str(activation.get("strategy", "")).casefold() == "constant"


def _source_enabled(entry: dict[str, Any], field: str) -> bool:
    """Return whether SillyTavern will scan this card field for this entry.

    ``first_mes`` is part of the current conversation and is therefore in the
    normal scan buffer. Description/personality/scenario are additional
    matching sources and only participate when their per-entry flag is true.
    Accept both WorldBuilder's CCv3 extension spelling and the native/legacy
    camelCase spelling so imported cards are diagnosed conservatively.
    """
    if field == "first_mes":
        return True
    names = ADDITIONAL_SOURCE_FLAGS[field]
    ext = entry.get("extensions") if isinstance(entry.get("extensions"), dict) else {}
    for container in (entry, ext):
        for name in names:
            if name in container:
                return container.get(name) is True
    return False


def _match_fields(key: str, entry: dict[str, Any], field_text: dict[str, str]) -> tuple[str, list[str]]:
    case_sensitive = bool(entry.get("case_sensitive", entry.get("caseSensitive", False)))
    use_regex = bool(entry.get("use_regex", entry.get("useRegex", False)))
    matches: list[str] = []
    if use_regex:
        flags = 0 if case_sensitive else re.IGNORECASE
        try:
            pattern = re.compile(key, flags)
        except re.error:
            return "invalid_regex", []
        for field, text in field_text.items():
            if text and pattern.search(text):
                matches.append(field)
        return "regex", matches

    needle = key if case_sensitive else key.casefold()
    for field, text in field_text.items():
        haystack = text if case_sensitive else text.casefold()
        if needle in haystack:
            matches.append(field)
    return "substring", matches


def analyze(data: Any) -> dict[str, Any]:
    info = detect_artifact(data)
    payload = data.get("data") if isinstance(data, dict) and isinstance(data.get("data"), dict) else None
    applicable = bool(info.kind == "card_v3_embedded" and isinstance(payload, dict))
    field_text = {
        field: str(payload.get(field, "") or "") if applicable else ""
        for field in CARD_FIELDS
    }
    collisions: list[dict[str, Any]] = []
    latent_collisions: list[dict[str, Any]] = []
    invalid_regex_keys: list[dict[str, Any]] = []

    if applicable:
        for ref in iter_entries(data):
            entry = ref.entry
            if _is_constant(entry):
                continue
            identity = canonical_entry_identity(entry)
            name = _entry_name(entry, identity if identity is not None else ref.key)
            active_matches: list[dict[str, Any]] = []
            latent_matches: list[dict[str, Any]] = []
            for key in _entry_keys(entry):
                match_kind, fields = _match_fields(key, entry, field_text)
                if match_kind == "invalid_regex":
                    invalid_regex_keys.append({"uid": identity, "name": name, "path": ref.path, "key": key})
                    continue
                if not fields:
                    continue
                active_fields = [field for field in fields if _source_enabled(entry, field)]
                inactive_fields = [field for field in fields if field not in active_fields]
                if active_fields:
                    active_matches.append({"key": key, "match_kind": match_kind, "fields": active_fields})
                if inactive_fields:
                    latent_matches.append({"key": key, "match_kind": match_kind, "fields": inactive_fields})
            if active_matches:
                collisions.append({
                    "uid": identity,
                    "name": name,
                    "path": ref.path,
                    "matched_keys": [row["key"] for row in active_matches],
                    "matches": active_matches,
                })
            if latent_matches:
                latent_collisions.append({
                    "uid": identity,
                    "name": name,
                    "path": ref.path,
                    "matched_keys": [row["key"] for row in latent_matches],
                    "matches": latent_matches,
                })

    return {
        "kind": REPORT_KIND,
        "report_version": REPORT_VERSION,
        "applicable": applicable,
        "artifact_kind": info.kind,
        "card_fields": list(CARD_FIELDS),
        "collision_count": len(collisions),
        "collisions": collisions,
        "latent_collision_count": len(latent_collisions),
        "latent_collisions": latent_collisions,
        "invalid_regex_keys": invalid_regex_keys,
        "auto_fix": False,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True, help="Card JSON to inspect")
    parser.add_argument("--output", help="Optional JSON report path")
    args = parser.parse_args()
    try:
        report = analyze(load_json(Path(args.input)))
        rendered = json.dumps(report, ensure_ascii=False, indent=2) + "\n"
        if args.output:
            Path(args.output).write_text(rendered, encoding="utf-8")
        sys.stdout.write(rendered)
        return 0
    except (OSError, json.JSONDecodeError, ValueError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
