#!/usr/bin/env python3
"""Archive stale downstream artifacts after an upstream lineage change."""
from __future__ import annotations
import argparse
import json
import os
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from wb_common import WorldBuilderError, atomic_write_json, collect_uid_entries, iter_entries, load_build_state, resolve_state_path, sha256_file
from pipeline_stage_gate import invalidate_from as invalidate_pipeline_stages

def stamp() -> str: return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")

# 6.3: always archived even under --change-set, regardless of which UIDs are
# affected: these are whole-build artifacts, not per-UID ones. Includes
# integration_resume_receipt because that is where delivery_gate.write_seal
# embeds the delivery seal; there is no separate seal file of its own.
ALWAYS_MANIFEST_KEYS = [
    "final_output", "semantic_ir", "compatibility_report", "runtime_adapter_receipt",
    "adapter_output", "integration_planning_receipt", "integration_output_receipt",
    "integration_resume_receipt", "activation_test_corpus_receipt",
]


def _uids_in_json_file(path: Path) -> set[str]:
    """UIDs actually present in one JSON file (a phase, evidence receipt, or
    findings file). Unreadable files return an empty set; callers treat
    that the same as "could not determine", which fails toward archiving,
    never toward silently keeping something that might be stale."""
    try:
        data = json.loads(path.read_text(encoding="utf-8-sig"))
    except (OSError, json.JSONDecodeError, UnicodeDecodeError):
        return set()
    uids: set[str] = set()
    for ref in iter_entries(data):
        uid = ref.entry.get("uid")
        if uid is not None:
            uids.add(str(uid))
    uids.update(collect_uid_entries(data))
    return uids


def selective_manifest_paths(root: Path, state: dict[str, Any], affected_uids: set[str]) -> tuple[list[Path], list[Path]]:
    """6.3: for a non-structural manifest change, only phases, evidence
    receipts, and findings touching an affected UID need archiving.
    Everything else the whole-stage manifest list would have archived
    (planning-level receipts, assignments not touching an affected UID)
    stays, since structural=False already means none of those changed.
    Returns (selective, always)."""
    always: list[Path] = []
    for key in ALWAYS_MANIFEST_KEYS:
        path = resolve_state_path(root, state, key, required=False)
        if path and path.exists():
            always.append(path)

    selective: list[Path] = []
    for dir_key in ("phases", "evidence_receipts", "findings"):
        directory = resolve_state_path(root, state, dir_key, required=False)
        if not directory or not directory.is_dir():
            continue
        for item in sorted(directory.glob("*.json")):
            uids = _uids_in_json_file(item)
            # Could not determine which UIDs this file concerns: fail toward
            # archiving it, the same instinct as structural=True: an unknown
            # state is never treated as "unaffected".
            if not uids or (uids & affected_uids):
                selective.append(item)

    assignments_dir = resolve_state_path(root, state, "assignments", required=False)
    if assignments_dir and assignments_dir.is_dir():
        for item in sorted(assignments_dir.glob("*.json")):
            try:
                data = json.loads(item.read_text(encoding="utf-8-sig"))
            except (OSError, json.JSONDecodeError, UnicodeDecodeError):
                selective.append(item)
                continue
            if not isinstance(data, dict) or data.get("role") != "generation":
                continue
            uids = {str(row.get("uid")) for row in data.get("entries", []) if isinstance(row, dict) and row.get("uid") is not None}
            if not uids or (uids & affected_uids):
                selective.append(item)

    return selective, always

def paths_for_stage(root: Path, state: dict[str, Any], stage: str) -> list[Path]:
    keys = {
        "discovery": ["era_plan", "manifest", "build_id", "build_list", "recursion_map", "character_plan", "identity_receipt", "activation_map_receipt", "activation_test_corpus_receipt", "era_router_receipt", "placement_planning_receipt", "placement_output_receipt", "budget_planning_receipt", "budget_output_receipt", "dynamic_state_planning_receipt", "dynamic_state_output_receipt", "pruning_receipts", "architecture_planning_receipt", "architecture_output_receipt", "planning_receipt", "assignments", "evidence_receipts", "phases", "findings", "audit_assignments", "audit_runtime", "merge_input", "audit_log", "final_output", "semantic_ir", "compatibility_report", "runtime_adapter_receipt", "adapter_output", "integration_planning_receipt", "integration_output_receipt", "integration_resume_receipt"],
        "era": ["manifest", "build_id", "build_list", "recursion_map", "character_plan", "identity_receipt", "activation_map_receipt", "activation_test_corpus_receipt", "era_router_receipt", "placement_planning_receipt", "placement_output_receipt", "budget_planning_receipt", "budget_output_receipt", "dynamic_state_planning_receipt", "dynamic_state_output_receipt", "pruning_receipts", "architecture_planning_receipt", "architecture_output_receipt", "planning_receipt", "assignments", "evidence_receipts", "phases", "findings", "audit_assignments", "audit_runtime", "merge_input", "audit_log", "final_output", "semantic_ir", "compatibility_report", "runtime_adapter_receipt", "adapter_output", "integration_planning_receipt", "integration_output_receipt", "integration_resume_receipt"],
        "planning": ["activation_map_receipt", "activation_test_corpus_receipt", "era_router_receipt", "placement_planning_receipt", "placement_output_receipt", "budget_planning_receipt", "budget_output_receipt", "dynamic_state_planning_receipt", "dynamic_state_output_receipt", "pruning_receipts", "architecture_planning_receipt", "architecture_output_receipt", "planning_receipt", "assignments", "evidence_receipts", "phases", "findings", "audit_assignments", "audit_runtime", "merge_input", "audit_log", "final_output", "semantic_ir", "compatibility_report", "runtime_adapter_receipt", "adapter_output", "integration_planning_receipt", "integration_output_receipt", "integration_resume_receipt"],
        "manifest": ["activation_map_receipt", "activation_test_corpus_receipt", "era_router_receipt", "placement_planning_receipt", "placement_output_receipt", "budget_planning_receipt", "budget_output_receipt", "dynamic_state_planning_receipt", "dynamic_state_output_receipt", "pruning_receipts", "architecture_planning_receipt", "architecture_output_receipt", "planning_receipt", "assignments", "evidence_receipts", "phases", "findings", "audit_assignments", "audit_runtime", "merge_input", "audit_log", "final_output", "semantic_ir", "compatibility_report", "runtime_adapter_receipt", "adapter_output", "integration_planning_receipt", "integration_output_receipt", "integration_resume_receipt"],
        "placement": ["manifest", "build_id", "build_list", "recursion_map", "identity_receipt", "activation_map_receipt", "activation_test_corpus_receipt", "placement_planning_receipt", "placement_output_receipt", "budget_planning_receipt", "budget_output_receipt", "dynamic_state_planning_receipt", "dynamic_state_output_receipt", "pruning_receipts", "architecture_planning_receipt", "architecture_output_receipt", "planning_receipt", "assignments", "evidence_receipts", "phases", "findings", "audit_assignments", "audit_runtime", "merge_input", "audit_log", "final_output", "semantic_ir", "compatibility_report", "runtime_adapter_receipt", "adapter_output", "integration_planning_receipt", "integration_output_receipt", "integration_resume_receipt"],
        "dynamic": ["manifest", "build_id", "build_list", "recursion_map", "identity_receipt", "activation_map_receipt", "activation_test_corpus_receipt", "dynamic_state_planning_receipt", "dynamic_state_output_receipt", "architecture_planning_receipt", "architecture_output_receipt", "planning_receipt", "assignments", "evidence_receipts", "phases", "findings", "audit_assignments", "audit_runtime", "merge_input", "audit_log", "final_output", "semantic_ir", "compatibility_report", "runtime_adapter_receipt", "adapter_output", "integration_planning_receipt", "integration_output_receipt", "integration_resume_receipt"],
        "budget": ["manifest", "build_id", "build_list", "recursion_map", "identity_receipt", "activation_map_receipt", "activation_test_corpus_receipt", "budget_planning_receipt", "budget_output_receipt", "dynamic_state_planning_receipt", "dynamic_state_output_receipt", "pruning_receipts", "architecture_planning_receipt", "architecture_output_receipt", "planning_receipt", "assignments", "evidence_receipts", "phases", "findings", "audit_assignments", "audit_runtime", "merge_input", "audit_log", "final_output", "semantic_ir", "compatibility_report", "runtime_adapter_receipt", "adapter_output", "integration_planning_receipt", "integration_output_receipt", "integration_resume_receipt"],
        "generation": ["architecture_output_receipt", "placement_output_receipt", "budget_output_receipt", "pruning_receipts", "phases", "findings", "audit_assignments", "audit_runtime", "merge_input", "audit_log", "final_output", "semantic_ir", "compatibility_report", "runtime_adapter_receipt", "adapter_output", "integration_planning_receipt", "integration_output_receipt", "integration_resume_receipt"],
        "runtime": ["semantic_ir", "compatibility_report", "runtime_adapter_receipt", "adapter_output", "integration_planning_receipt", "integration_output_receipt", "integration_resume_receipt"],
    }[stage]
    result: list[Path] = []
    for key in keys:
        path = resolve_state_path(root, state, key, required=False)
        if path and path.exists() and path not in result: result.append(path)
    return result

def _snapshot_delivered_history(root: Path, state: dict[str, Any], stamp_value: str) -> dict[str, Any] | None:
    final_path = resolve_state_path(root, state, "final_output", required=False)
    if final_path is None or not final_path.is_file():
        return None
    history_dir = final_path.parent / "history"
    history_dir.mkdir(parents=True, exist_ok=True)
    target = history_dir / f"{stamp_value}-{final_path.name}"
    shutil.copy2(final_path, target)
    return {
        "path": str(target.relative_to(root)).replace(os.sep, "/"),
        "sha256": sha256_file(target),
        "source": str(final_path.relative_to(root)).replace(os.sep, "/"),
    }


def _rebind_parent_shell(root: Path, state: dict[str, Any]) -> dict[str, Any] | None:
    phases = resolve_state_path(root, state, "phases", required=False)
    manifest = resolve_state_path(root, state, "manifest", required=False)
    if phases is None or manifest is None or not manifest.exists():
        return None
    phase_one = phases / "phase-0001.json"
    if not phase_one.is_file():
        return None
    try:
        data = json.loads(phase_one.read_text(encoding="utf-8-sig"))
    except (OSError, json.JSONDecodeError, UnicodeDecodeError):
        return None
    if not isinstance(data, dict):
        return None
    meta = data.get("_worldbuilder")
    if not isinstance(meta, dict):
        return {"path": str(phase_one.relative_to(root)).replace(os.sep, "/"), "rebound": False}
    old_sha = meta.get("manifest_sha256")
    new_sha = sha256_file(manifest)
    meta["manifest_sha256"] = new_sha
    meta["phase_binding"] = "parent_shell_rebound"
    atomic_write_json(phase_one, data)
    return {
        "path": str(phase_one.relative_to(root)).replace(os.sep, "/"),
        "rebound": old_sha != new_sha,
        "old_manifest_sha256": old_sha,
        "manifest_sha256": new_sha,
        "sha256": sha256_file(phase_one),
    }


def invalidate(build_state: str, stage: str, reason: str, *, change_set_path: str | None = None, preserve_evidence: bool = False, preserve_pipeline_chain: bool = False) -> dict[str, Any]:
    root, state = load_build_state(build_state); stamp_value = stamp(); archive = root / ".work" / "invalidated" / f"{stamp_value}-{stage}"; archive.mkdir(parents=True, exist_ok=False)
    moved: list[dict[str, Any]] = []
    amendment: dict[str, Any] | None = None
    history_snapshot = _snapshot_delivered_history(root, state, stamp_value) if stage == "manifest" else None
    parent_shell_rebind: dict[str, Any] | None = None

    if change_set_path is not None:
        if stage != "manifest":
            raise WorldBuilderError("--change-set is only meaningful for --from-stage manifest")
        try:
            change_set_result = json.loads(Path(change_set_path).read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise WorldBuilderError(f"could not read change-set at {change_set_path}: {exc}")
        # 6.1: structural forces full invalidation, no exceptions; fall through
        # to the existing whole-stage loop below rather than the selective one.
        if not change_set_result.get("structural", True):
            affected = set(change_set_result.get("changed_uids", [])) | set(change_set_result.get("neighbour_affected_uids", []))
            selective, always = selective_manifest_paths(root, state, affected)
            phases_root = resolve_state_path(root, state, "phases", required=False)
            phase_one = (phases_root / "phase-0001.json").resolve() if phases_root else None
            if phase_one is not None:
                selective = [path for path in selective if path.resolve() != phase_one]
            parent_shell_rebind = _rebind_parent_shell(root, state)
            if preserve_evidence:
                evidence_root = resolve_state_path(root, state, "evidence_receipts", required=False)
                if evidence_root is not None:
                    evidence_root = evidence_root.resolve()
                    selective = [path for path in selective if path.resolve().parent != evidence_root and evidence_root not in path.resolve().parents]
            for path in selective + always:
                relative = path.relative_to(root); target = archive / relative; target.parent.mkdir(parents=True, exist_ok=True)
                before = sha256_file(path) if path.is_file() else None; shutil.move(str(path), str(target)); moved.append({"path": str(relative).replace(os.sep, "/"), "sha256": before})
            amendment = {
                "mode": "change_set", "structural": False,
                "changed_uids": sorted(change_set_result.get("changed_uids", [])),
                "neighbour_affected_uids": sorted(change_set_result.get("neighbour_affected_uids", [])),
                "preserve_evidence": bool(preserve_evidence),
                "parent_shell": parent_shell_rebind,
                "delivered_history_snapshot": history_snapshot,
            }

    if amendment is None:
        for path in paths_for_stage(root, state, stage):
            if path.name == "assignments" and path.is_dir() and stage in {"manifest", "planning"}:
                target_dir = archive / str(path.relative_to(root))
                for item in sorted(path.glob("*.json")):
                    try: data = json.loads(item.read_text(encoding="utf-8-sig"))
                    except Exception: data = {}
                    if isinstance(data, dict) and data.get("role") == "generation":
                        target_dir.mkdir(parents=True, exist_ok=True); before = sha256_file(item); shutil.move(str(item), str(target_dir / item.name)); moved.append({"path": str(item.relative_to(root)).replace(os.sep, "/"), "sha256": before})
                continue
            relative = path.relative_to(root); target = archive / relative; target.parent.mkdir(parents=True, exist_ok=True)
            before = sha256_file(path) if path.is_file() else None; shutil.move(str(path), str(target)); moved.append({"path": str(relative).replace(os.sep, "/"), "sha256": before})
        if change_set_path is not None:
            amendment = {"mode": "change_set_forced_full", "structural": True}

    if preserve_pipeline_chain and amendment is not None and amendment.get("structural") is False:
        state.setdefault("amendment", {})["pending"] = {
            "change_set": str(Path(change_set_path).resolve().relative_to(root)).replace(os.sep, "/") if Path(change_set_path).resolve().is_relative_to(root) else str(Path(change_set_path).resolve()),
            "reason": reason,
            "phase": "metadata_reemit",
            "started_at": stamp_value,
        }
    else:
        state.setdefault("status", {}).update({"generation": "invalidated", "merge": "invalidated", "post_generation_audit": "invalidated", "runtime_adapter": "invalidated", "integration_planning": "invalidated", "integration_output": "invalidated", "integration_resume": "invalidated", "delivery": "invalidated"})
    state.setdefault("lineage", {})["last_invalidation"] = {"stage": stage, "reason": reason, "archive": str(archive.relative_to(root)).replace(os.sep, "/"), "moved_count": len(moved)}
    atomic_write_json(Path(build_state).resolve(), state)
    stage_map = {
        "discovery": "research_discovery",
        "era": "planning_validated",
        "placement": "planning_validated",
        "budget": "planning_validated",
        "dynamic": "planning_validated",
        "planning": "planning_validated",
        "manifest": "planning_validated",
        "generation": "generation_ready",
        "runtime": "runtime_adapter",
    }
    if preserve_pipeline_chain and amendment is not None and amendment.get("structural") is False:
        stage_result = {"status": "preserved_base_chain", "reason": "additive amendment uses the amendment sub-ledger; immutable sealed stage receipts are retained"}
    else:
        stage_result = invalidate_pipeline_stages(Path(build_state).resolve(), stage_map[stage])
    # receipt_version 2: adds "amendment" (Batch 6, 6.3). Absent (None) means
    # full lineage, identical in meaning to every receipt_version 1 that came
    # before this: old readers that only ever saw version 1 already treat
    # every invalidation as full, which remains correct for them.
    archive_rel = str(archive.relative_to(root)).replace(os.sep, "/")
    # Build the restore index from the archive *after* all moves complete.
    # Some invalidation paths move whole directories (phases, findings,
    # assignments, receipts) as one row in ``moved``; indexing only those
    # top-level rows would preserve no per-file hash and make targeted restore
    # impossible.  Every archived file therefore gets its own source->archive
    # mapping and SHA-256 regardless of whether it arrived individually or as
    # part of a moved directory tree.
    archived_files = [path for path in sorted(archive.rglob("*")) if path.is_file()]
    index = {
        "kind": "worldbuilder-lineage-archive-index",
        "index_version": 1,
        "build_id": state.get("build_id"),
        "stage": stage,
        "created_at": stamp_value,
        "entries": [
            {
                "source_path": str(path.relative_to(archive)).replace(os.sep, "/"),
                "archive_path": f"{archive_rel}/{str(path.relative_to(archive)).replace(os.sep, '/')}",
                "sha256": sha256_file(path),
            }
            for path in archived_files
        ],
    }
    atomic_write_json(archive / "index.json", index)
    receipt = {"kind": "worldbuilder-lineage-invalidation", "receipt_version": 4, "build_id": state.get("build_id"), "stage": stage, "reason": reason, "archive": archive_rel, "archive_index": f"{archive_rel}/index.json", "archive_index_sha256": sha256_file(archive / "index.json"), "moved": moved, "amendment": amendment, "parent_shell": parent_shell_rebind, "delivered_history_snapshot": history_snapshot, "pipeline_stage_invalidation": stage_result}
    atomic_write_json(archive / "invalidation-receipt.json", receipt); return {"status": "invalidated", "archive": str(archive), "index": str(archive / "index.json"), "moved": len(moved), "amendment": amendment}

def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__); parser.add_argument("--build-state", required=True); parser.add_argument("--from-stage", required=True, choices=("discovery","era","placement","budget","dynamic","planning","manifest","generation","runtime")); parser.add_argument("--reason", required=True); parser.add_argument("--change-set", default=None, help="Path to a change_set.py JSON result. Opt-in; default stays whole-stage. Only valid with --from-stage manifest."); args=parser.parse_args()
    try: print(json.dumps(invalidate(args.build_state,args.from_stage,args.reason,change_set_path=args.change_set),indent=2)); return 0
    except (WorldBuilderError,OSError,ValueError,json.JSONDecodeError) as exc: print(f"ERROR: {exc}",file=sys.stderr); return 1
if __name__=="__main__": raise SystemExit(main())
