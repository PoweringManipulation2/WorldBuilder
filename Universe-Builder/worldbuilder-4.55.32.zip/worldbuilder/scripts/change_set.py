#!/usr/bin/env python3
"""Batch 6, 6.1: read-only manifest change-set computation.

Given an archived prior manifest and the current manifest, plus the 8
structural hashes for each side, emits:
    changed_uids             : entry_binding_hash differs (or the UID is new/removed)
    neighbour_affected_uids  : UIDs touching a changed UID by an activation-graph edge
    structural: bool         : true if ANY of the 8 structural hashes differ

structural forces full invalidation, no exceptions; only entry-level
content/keyword/edge changes ever qualify for amendment (Batch 6, 6.1/6.2).

This is the plan's own stated single highest-risk line in the entire plan:
"if structural ever returns false for a budget-plan or era-plan change,
every downstream tolerance decision inherits the bug silently." The design
choice that follows from that: compute_change_set takes the 8 structural
hashes as explicit, named parameters. It does not reach into a manifest or
build-state's nested keys itself to find them: those live scattered
across build-state's architecture/discovery sections (set at init_build
time), the manifest's own discovery_receipt_sha256, and state["lineage"]
(set at planning_gate time), with no single clean source. Pushing
extraction to the caller keeps this function's own comparison trivially
correct and impossible to get subtly wrong; a caller's key-path mistake is
then visible at the call site, not buried inside the one function
everything else trusts. Nothing consumes this module's output yet (6.1 is
read-only, by design); 6.2 and 6.3 wire it in.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

from wb_common import WorldBuilderError, entry_binding_hash, collect_uid_entries, load_json

CONTRACT = "worldbuilder-change-set-v1"

# The exact 8 signals the plan names. A caller passes exactly this key set for
# each side (prior/current); compute_change_set validates the set matches so
# a missing or misspelled key fails loudly here rather than silently comparing
# None == None as "unchanged".
STRUCTURAL_HASH_KEYS = (
    "registry_sha256",
    "default_profile_sha256",
    "era_plan_sha256",
    "character_plan_sha256",
    "placement_plan_sha256",
    "budget_plan_sha256",
    "dynamic_state_plan_sha256",
    "discovery_receipt_sha256",
)


def _validate_hash_dict(hashes: dict[str, Any], side: str) -> None:
    if not isinstance(hashes, dict):
        raise WorldBuilderError(f"{side}_structural_hashes must be an object")
    missing = [key for key in STRUCTURAL_HASH_KEYS if key not in hashes]
    if missing:
        raise WorldBuilderError(
            f"{side}_structural_hashes is missing {', '.join(missing)}: an absent key is not the "
            "same claim as a null hash, and both must be explicit. Never silently treat a hash this "
            "function was not given as unchanged."
        )
    extra = sorted(set(hashes) - set(STRUCTURAL_HASH_KEYS))
    if extra:
        raise WorldBuilderError(f"{side}_structural_hashes has unrecognized keys: {', '.join(extra)}")


def _manifest_edges(manifest: dict[str, Any]) -> list[dict[str, Any]]:
    graph = manifest.get("activation_graph")
    if not isinstance(graph, dict):
        return []
    edges = graph.get("edges")
    return [e for e in edges if isinstance(e, dict)] if isinstance(edges, list) else []


def compute_change_set(
    prior_manifest: dict[str, Any],
    current_manifest: dict[str, Any],
    *,
    prior_structural_hashes: dict[str, str | None],
    current_structural_hashes: dict[str, str | None],
) -> dict[str, Any]:
    """Read-only (6.1): nothing here writes anything or consumes anything
    else's state. See module docstring for why the 8 structural hashes are
    explicit parameters rather than derived internally."""
    _validate_hash_dict(prior_structural_hashes, "prior")
    _validate_hash_dict(current_structural_hashes, "current")

    structural_diffs = sorted(
        key for key in STRUCTURAL_HASH_KEYS
        if prior_structural_hashes.get(key) != current_structural_hashes.get(key)
    )
    structural = bool(structural_diffs)

    prior_uids = collect_uid_entries(prior_manifest)
    current_uids = collect_uid_entries(current_manifest)
    all_uids = set(prior_uids) | set(current_uids)

    changed_uids = sorted(
        uid for uid in all_uids
        if (uid not in prior_uids) or (uid not in current_uids)
        or entry_binding_hash(prior_uids[uid]) != entry_binding_hash(current_uids[uid])
    )
    changed_set = set(changed_uids)

    # Neighbours: any UID touching a changed UID by an edge in either graph:
    # both sides, since a neighbour relationship removed in the current graph
    # can matter just as much as one newly added (a UID that used to depend
    # on a changed neighbour and now silently does not is still affected).
    neighbour_uids: set[str] = set()
    for edges in (_manifest_edges(prior_manifest), _manifest_edges(current_manifest)):
        for edge in edges:
            source = str(edge.get("source_uid")) if edge.get("source_uid") is not None else None
            target = str(edge.get("target_uid")) if edge.get("target_uid") is not None else None
            if source is None or target is None:
                continue
            if source in changed_set and target not in changed_set:
                neighbour_uids.add(target)
            if target in changed_set and source not in changed_set:
                neighbour_uids.add(source)

    return {
        "contract": CONTRACT,
        "changed_uids": changed_uids,
        "neighbour_affected_uids": sorted(neighbour_uids),
        "structural": structural,
        "structural_diffs": structural_diffs,
    }


def _entry_identity_value(entry: Any) -> str | None:
    """Identity of an entry-shaped dict in either document family.

    Manifests key entries by an integer ``uid``; delivered artifacts (cards,
    lorebooks) key the same entries by an integer ``id`` and may mirror the
    value under ``extensions.uid``. Change sets must resolve both families to
    the same string identity, so this accepts any of those carriers. A bare
    integer ``id`` only counts when the dict is actually entry-shaped, so a
    nested plan block that happens to carry an ``id`` is never mistaken for an
    entry."""
    if not isinstance(entry, dict):
        return None
    value = entry.get("uid")
    if isinstance(value, int) and not isinstance(value, bool):
        return str(value)
    if isinstance(value, str) and value.strip():
        return value.strip()
    candidate = entry.get("id")
    if isinstance(candidate, int) and not isinstance(candidate, bool):
        if any(key in entry for key in ("content", "keys", "key", "comment", "extensions")):
            return str(candidate)
    ext = entry.get("extensions")
    if isinstance(ext, dict):
        mirrored = ext.get("uid")
        if isinstance(mirrored, int) and not isinstance(mirrored, bool):
            return str(mirrored)
        if isinstance(mirrored, str) and mirrored.strip():
            return mirrored.strip()
    return None


def _owning_entry_uid(document: Any, pointer: str) -> str | None:
    """Walks a JSON Pointer's segments from the root, returning the identity of
    the first entry-shaped dict the pointer passes through, in either document
    family (integer uid keys in manifests, integer id keys in delivered
    artifacts). Returns None for a pointer that never passes through an entry
    at all (e.g. a top-level /architecture/... change); that is a genuinely
    structural, non-entry-specific edit, not a UID resolution failure.

    Deliberately walks the real data rather than pattern-matching the
    pointer string (e.g. assuming "/entries/N/..." means uid=N): a real
    build's own entries[2] was confirmed, empirically, to have uid=3, not
    uid=2; entries is an array, and array position is not UID. Only
    resolving through the actual document gets this right in general.
    """
    current = document
    owning_uid: str | None = _entry_identity_value(current) if isinstance(current, dict) else None
    for part in pointer[1:].split("/") if pointer.startswith("/") else []:
        part = part.replace("~1", "/").replace("~0", "~")
        if isinstance(current, list):
            try:
                index = int(part)
            except ValueError:
                break
            if index < 0 or index >= len(current):
                break
            current = current[index]
        elif isinstance(current, dict):
            if part not in current:
                break
            current = current[part]
        else:
            break
        if isinstance(current, dict):
            found = _entry_identity_value(current)
            if found is not None:
                owning_uid = found
    return owning_uid


def change_set_from_patch_log(patch_log_records: list[dict[str, Any]], target: dict[str, Any], *,
                              manifest: dict[str, Any] | None = None,
                              alias_documents: dict[str, dict[str, Any]] | None = None) -> dict[str, Any]:
    """Batch 13, Problem 4: the pre-seal patch-and-rerun path (finding
    reconciliation -> patch verification -> re-audit, documented in
    post-gen-audit.md) has no scoped alternative to a full re-audit,
    unlike the post-seal amendment path Batch 12 built. This closes that
    gap using the same contract compute_change_set already produces, but
    derived directly from the patch log's own recorded operations against
    the single, current target. There is no separate "prior manifest"
    snapshot in this pre-seal scenario the way there is for a post-seal
    amendment, so this does not call compute_change_set itself (which
    requires two full manifest snapshots plus their 8 structural hashes
    each); it produces the same contract shape by simpler, more direct
    means suited to what is actually available here.

    A patch whose pointer never resolves through any entry (for example a
    top-level /architecture/... change) contributes no changed_uids at
    all and forces structural=True, exactly matching
    compute_change_set's own rule that a structural change always forces
    full invalidation, no exceptions.

    Batch 62: pointers are artifact-rooted (a delivered card's records read
    /data/character_book/entries/N/...), so resolution walks the document the
    record was actually written against: the record's own ``file`` alias when
    the caller supplies ``alias_documents``, else ``target``. The optional
    ``manifest`` supplies the activation-graph edges for neighbour lookup and
    defaults to ``target`` so manifest-based callers are unchanged.
    """
    changed_uids: set[str] = set()
    structural = False
    for record in patch_log_records:
        pointer = record.get("path")
        if not isinstance(pointer, str):
            structural = True
            continue
        document = target
        alias = record.get("file")
        if isinstance(alias_documents, dict) and isinstance(alias, str):
            candidate = alias_documents.get(alias)
            if isinstance(candidate, dict):
                document = candidate
        uid = _owning_entry_uid(document, pointer)
        if uid is None:
            structural = True
        else:
            changed_uids.add(uid)

    neighbour_uids: set[str] = set()
    for edge in _manifest_edges(manifest if manifest is not None else target):
        source = str(edge.get("source_uid")) if edge.get("source_uid") is not None else None
        edge_target = str(edge.get("target_uid")) if edge.get("target_uid") is not None else None
        if source is None or edge_target is None:
            continue
        if source in changed_uids and edge_target not in changed_uids:
            neighbour_uids.add(edge_target)
        if edge_target in changed_uids and source not in changed_uids:
            neighbour_uids.add(source)

    return {
        "contract": CONTRACT,
        "changed_uids": sorted(changed_uids),
        "neighbour_affected_uids": sorted(neighbour_uids),
        "structural": structural,
        "structural_diffs": ["patch_log_touched_non_entry_path"] if structural else [],
    }


def collect_document_entries(document: Any) -> dict[str, dict[str, Any]]:
    """Entries of either document family, keyed by stable identity.

    `collect_uid_entries` reads manifest-shaped entries (an integer `uid`). A
    delivered card keys the same entries by an integer `id` under
    `data.character_book.entries`, where `collect_uid_entries` finds nothing at
    all, so a change set computed with it against a card comes back empty with no
    error. This resolves both families through `_entry_identity_value`, which
    already understands the `uid`, `id`, and `extensions.uid` carriers.
    """
    if not isinstance(document, dict):
        return {}
    payload = document.get("data")
    book = payload.get("character_book") if isinstance(payload, dict) else None
    raw = book.get("entries") if isinstance(book, dict) else None
    candidates: list[Any] = []
    if isinstance(raw, list):
        candidates = list(raw)
    elif isinstance(raw, dict):
        candidates = list(raw.values())
    if not candidates:
        return collect_uid_entries(document)
    found: dict[str, dict[str, Any]] = {}
    for entry in candidates:
        if not isinstance(entry, dict):
            continue
        uid = _entry_identity_value(entry)
        if uid is not None:
            found[uid] = entry
    return found


def change_set_from_artifacts(
    prior_artifact: dict[str, Any],
    current_artifact: dict[str, Any],
    *,
    manifest: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Artifact-level change set for a post-delivery scoped amendment.

    `compute_change_set` compares two manifests, and `change_set_from_patch_log`
    derives its scope from recorded patch operations. Neither covers a delivered
    artifact edited outside both: setting `extensions.prevent_recursion` across a
    set of entries has no manifest counterpart and no patch-log record, which is
    what left two separate sessions recording a divergent ledger by hand. This
    returns the same worldbuilder-change-set-v1 shape from two revisions of the
    artifact itself, matched by stable identity, so `record_amendment` has a real
    scope to bind.

    It refuses to emit an empty change set when either side yields no entries at
    all, because a silently empty scope is exactly how this gap hid before: the
    identity collector returned nothing for a card and the caller could not tell
    that apart from a genuinely unchanged artifact. Neighbours come from the
    supplied manifest's activation graph, and are empty when none is supplied
    rather than guessed.
    """
    prior_rows = collect_document_entries(prior_artifact)
    current_rows = collect_document_entries(current_artifact)
    if not prior_rows:
        raise WorldBuilderError(
            "prior artifact yields no entries by stable identity: refusing to emit an empty change set"
        )
    if not current_rows:
        raise WorldBuilderError(
            "current artifact yields no entries by stable identity: refusing to emit an empty change set"
        )
    all_uids = set(prior_rows) | set(current_rows)
    changed_uids = sorted(
        uid for uid in all_uids
        if (uid not in prior_rows) or (uid not in current_rows)
        or entry_binding_hash(prior_rows[uid]) != entry_binding_hash(current_rows[uid])
    )
    changed_set = set(changed_uids)
    neighbour_uids: set[str] = set()
    for edge in _manifest_edges(manifest or {}):
        source = str(edge.get("source_uid")) if edge.get("source_uid") is not None else None
        edge_target = str(edge.get("target_uid")) if edge.get("target_uid") is not None else None
        if source is None or edge_target is None:
            continue
        if source in changed_set and edge_target not in changed_set:
            neighbour_uids.add(edge_target)
        if edge_target in changed_set and source not in changed_set:
            neighbour_uids.add(source)
    return {
        "contract": CONTRACT,
        "changed_uids": changed_uids,
        "neighbour_affected_uids": sorted(neighbour_uids),
        "structural": False,
        "structural_diffs": [],
        "scope_basis": "artifact",
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--prior-manifest")
    parser.add_argument("--current-manifest")
    parser.add_argument("--prior-hashes", help="Path to a JSON object with the 8 structural hash keys")
    parser.add_argument("--current-hashes", help="Path to a JSON object with the 8 structural hash keys")
    parser.add_argument("--prior-artifact", help="Prior revision of a delivered artifact (card or lorebook JSON)")
    parser.add_argument("--current-artifact", help="Current revision of a delivered artifact (card or lorebook JSON)")
    parser.add_argument("--manifest", help="Manifest supplying activation-graph edges for neighbour lookup")
    args = parser.parse_args()
    try:
        if args.prior_artifact or args.current_artifact:
            if not (args.prior_artifact and args.current_artifact):
                raise WorldBuilderError(
                    "an artifact change set needs both --prior-artifact and --current-artifact"
                )
            result = change_set_from_artifacts(
                load_json(Path(args.prior_artifact)),
                load_json(Path(args.current_artifact)),
                manifest=load_json(Path(args.manifest)) if args.manifest else None,
            )
        else:
            missing = [
                name for name, value in (
                    ("--prior-manifest", args.prior_manifest),
                    ("--current-manifest", args.current_manifest),
                    ("--prior-hashes", args.prior_hashes),
                    ("--current-hashes", args.current_hashes),
                ) if not value
            ]
            if missing:
                raise WorldBuilderError(
                    "a manifest change set requires " + ", ".join(missing)
                    + ", or pass --prior-artifact and --current-artifact instead"
                )
            result = compute_change_set(
                load_json(Path(args.prior_manifest)),
                load_json(Path(args.current_manifest)),
                prior_structural_hashes=load_json(Path(args.prior_hashes)),
                current_structural_hashes=load_json(Path(args.current_hashes)),
            )
        print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
        return 0
    except (WorldBuilderError, OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
