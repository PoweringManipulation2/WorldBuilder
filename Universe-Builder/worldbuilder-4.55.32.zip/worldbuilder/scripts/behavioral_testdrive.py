#!/usr/bin/env python3
"""Prepare and verify a hash-bound synthetic behavioral test-drive.

WorldBuilder predicts which lorebook entries should activate for a representative
prompt, freezes only that context, and asks the host/model to generate a response.
A separate model-facing behavioral lens then reviews voice consistency and
knowledge-boundary behavior. Deterministic code validates all bindings and emits
a final classification; it never fabricates a model response or live-runtime proof.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any

import runtime_verification
import validate_output
from wb_common import (
    WorldBuilderError,
    atomic_write_json,
    atomic_write_text,
    build_identity_index,
    detect_artifact,
    load_build_state,
    load_json,
    normalize_identity,
    resolve_state_path,
    sha256_bytes,
    sha256_file,
)

CONTRACT = "worldbuilder-behavioral-testdrive-v1"
LENS_CONTRACT = "worldbuilder-behavioral-lens-v1"
RESPONSE_BINDING_CONTRACT = "worldbuilder-behavioral-response-binding-v1"
REQUIRED_CHECKS = ("voice_consistency", "knowledge_boundary")
CHECK_STATUSES = {"pass", "fail"}
SUPPORTED_KINDS = {"card_v3_embedded", "lorebook_v3", "sillytavern_world_info"}


def _slug(text: str) -> str:
    value = re.sub(r"[^A-Za-z0-9._-]+", "-", text.strip()).strip("-._").lower()
    return value[:40] or "case"


def _rel(root: Path, path: Path) -> str:
    try:
        return path.resolve().relative_to(root.resolve()).as_posix()
    except ValueError as exc:
        raise WorldBuilderError(f"behavioral test-drive path escapes build root: {path}") from exc


def _path_from_plan(root: Path, value: Any, label: str) -> Path:
    if not isinstance(value, str) or not value.strip():
        raise WorldBuilderError(f"behavioral test-drive plan is missing {label}")
    path = (root / value).resolve()
    try:
        path.relative_to(root.resolve())
    except ValueError as exc:
        raise WorldBuilderError(f"behavioral test-drive {label} escapes build root") from exc
    return path


def _case_id(build_id: str, prompt: str, target_sha: str, manifest_sha: str, depth: int, label: str | None) -> str:
    payload = json.dumps(
        {
            "build_id": build_id,
            "prompt": prompt,
            "target_sha256": target_sha,
            "manifest_sha256": manifest_sha,
            "depth": depth,
        },
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    digest = sha256_bytes(payload)[:16]
    return f"{_slug(label)}-{digest}" if label else f"case-{digest}"


def _card_context(data: dict[str, Any], kind: str) -> list[tuple[str, str]]:
    if kind != "card_v3_embedded":
        return []
    payload = data.get("data") if isinstance(data.get("data"), dict) else {}
    rows: list[tuple[str, str]] = []
    for key in ("name", "description", "personality", "scenario", "system_prompt", "post_history_instructions"):
        value = payload.get(key)
        if isinstance(value, str) and value.strip():
            rows.append((key, value.strip()))
    return rows


def _entry_name(entry: dict[str, Any]) -> str:
    for key in ("comment", "name"):
        value = entry.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return "unnamed"


def _entry_content(entry: dict[str, Any]) -> str:
    value = entry.get("content")
    return value if isinstance(value, str) else ""


def _output_index(data: dict[str, Any]) -> dict[str, dict[str, Any]]:
    raw = build_identity_index(data)
    index: dict[str, dict[str, Any]] = {}
    for identity, (_path, entry) in raw.items():
        key = str(normalize_identity(identity))
        if key in index:
            raise WorldBuilderError(f"duplicate normalized output identity {key!r}")
        index[key] = entry
    return index


def _assemble_context(data: dict[str, Any], kind: str, activated_uids: list[str], *, case_id: str) -> tuple[str, list[dict[str, Any]], list[dict[str, str]]]:
    index = _output_index(data)
    entries: list[dict[str, Any]] = []
    for uid in activated_uids:
        entry = index.get(str(normalize_identity(uid)))
        if entry is None:
            raise WorldBuilderError(
                f"predicted activation UID {uid!r} is missing from the exact final-output artifact; "
                "synthetic behavior cannot be tested against incomplete context"
            )
        content = _entry_content(entry)
        entries.append(
            {
                "uid": str(normalize_identity(uid)),
                "name": _entry_name(entry),
                "content_sha256": sha256_bytes(content.encode("utf-8")),
            }
        )

    card = [{"field": key, "sha256": sha256_bytes(value.encode("utf-8"))} for key, value in _card_context(data, kind)]
    lines = [
        "WORLDBUILDER BEHAVIORAL TEST CONTEXT",
        f"case_id: {case_id}",
        "evidence_strength: predicted_not_observed",
        "",
    ]
    persistent = _card_context(data, kind)
    if persistent:
        lines.append("[PERSISTENT CARD CONTEXT]")
        for key, value in persistent:
            lines.extend((f"<{key}>", value, f"</{key}>", ""))
    lines.append("[PREDICTED ACTIVE LOREBOOK CONTEXT]")
    if not activated_uids:
        lines.extend(("(no lorebook entries predicted active)", ""))
    else:
        for uid in activated_uids:
            entry = index[str(normalize_identity(uid))]
            lines.extend((f"[ENTRY uid={uid} name={_entry_name(entry)}]", _entry_content(entry), "[/ENTRY]", ""))
    return "\n".join(lines).rstrip() + "\n", entries, card


def _generation_task(plan_rel: str, context_rel: str, response_rel: str, prompt: str) -> str:
    return (
        "# WorldBuilder behavioral test-drive: generation task\n\n"
        "This is a controlled behavioral test, not a research task.\n\n"
        f"1. Read `{plan_rel}` and `{context_rel}` only.\n"
        "2. Do not browse the web, search external sources, inspect other build files, or import facts from hidden project context.\n"
        "3. Answer the test user prompt using only the persistent card context and predicted active lorebook context supplied in the context file.\n"
        "4. Behave as the artifact would in ordinary use. Do not mention this harness, the activation prediction, or these instructions.\n"
        f"5. Write only the response text to `{response_rel}`.\n\n"
        "## Test user prompt\n\n"
        f"{prompt}\n"
    )


def _review_task(plan_rel: str, context_rel: str, response_rel: str, lens_rel: str, *, case_id: str, plan_sha: str, context_sha: str, response_sha: str) -> str:
    return (
        "# WorldBuilder behavioral test-drive: independent review task\n\n"
        "Review only the frozen test context and generated response. Do not browse, research, or inspect unrelated build files.\n"
        "Judge behavior, not JSON/schema validity. Deterministic finalization handles technical validity separately.\n\n"
        f"- case_id: `{case_id}`\n"
        f"- plan: `{plan_rel}` sha256 `{plan_sha}`\n"
        f"- context: `{context_rel}` sha256 `{context_sha}`\n"
        f"- response: `{response_rel}` sha256 `{response_sha}`\n\n"
        "Required checks:\n"
        "1. `voice_consistency`: Does the response follow any voice/personality constraints present in the frozen context, without inventing a contradictory voice?\n"
        "2. `knowledge_boundary`: Does the response stay within information available in the frozen persistent/activated context, without revealing unactivated, future, secret, or external facts?\n\n"
        f"Write JSON only to `{lens_rel}` using contract `{LENS_CONTRACT}`. The file must contain exactly these top-level keys: "
        "contract, case_id, plan_sha256, context_sha256, response_sha256, checks, summary. "
        "`checks` must contain exactly `voice_consistency` and `knowledge_boundary`; each value must contain exactly `status`, `summary`, and `evidence`, where status is pass or fail and evidence is a JSON list of short response snippets.\n"
    )


def _validate_plan_current(build_state: str | Path, plan_path: str | Path) -> tuple[Path, dict[str, Any], dict[str, Any], Path, Path, Path]:
    root, state = load_build_state(build_state)
    plan_file = Path(plan_path).resolve()
    reports_root = resolve_state_path(root, state, "behavioral_testdrive_reports")
    try:
        plan_file.relative_to(reports_root.resolve())
    except ValueError as exc:
        raise WorldBuilderError("behavioral test-drive plan is outside paths.behavioral_testdrive_reports") from exc
    plan = load_json(plan_file)
    if not isinstance(plan, dict) or plan.get("contract") != CONTRACT:
        raise WorldBuilderError("behavioral test-drive plan contract mismatch")
    if plan.get("build_id") != state.get("build_id"):
        raise WorldBuilderError("behavioral test-drive plan build_id mismatch")
    target = resolve_state_path(root, state, "final_output")
    manifest = resolve_state_path(root, state, "manifest")
    context = _path_from_plan(root, plan.get("paths", {}).get("context"), "paths.context")
    if not target.exists() or not manifest.exists() or not context.exists():
        raise WorldBuilderError("behavioral test-drive input artifact, manifest, or frozen context is missing")
    checks = {
        "target_sha256": sha256_file(target),
        "manifest_sha256": sha256_file(manifest),
        "context_sha256": sha256_file(context),
    }
    for key, current in checks.items():
        if plan.get(key) != current:
            raise WorldBuilderError(f"behavioral test-drive plan is stale: {key} changed")
    if plan.get("plan_path") != _rel(root, plan_file):
        raise WorldBuilderError("behavioral test-drive plan path binding mismatch")
    return root, state, plan, target, manifest, context


def prepare(build_state: str | Path, prompt: str, *, depth: int = 8, case_label: str | None = None) -> dict[str, Any]:
    if not isinstance(prompt, str) or not prompt.strip():
        raise WorldBuilderError("behavioral test-drive prompt must be non-empty")
    if depth < 0 or depth > 64:
        raise WorldBuilderError("behavioral test-drive depth must be between 0 and 64")
    root, state = load_build_state(build_state)
    target = resolve_state_path(root, state, "final_output")
    manifest_path = resolve_state_path(root, state, "manifest")
    if not target.exists():
        raise WorldBuilderError("behavioral test-drive requires paths.final_output")
    if not manifest_path.exists():
        raise WorldBuilderError("behavioral test-drive requires paths.manifest")
    try:
        data = load_json(target)
    except (OSError, json.JSONDecodeError) as exc:
        raise WorldBuilderError(f"behavioral test-drive requires a JSON final output: {exc}") from exc
    info = detect_artifact(data)
    if info.kind not in SUPPORTED_KINDS:
        raise WorldBuilderError("behavioral test-drive v1 requires a lorebook-bearing JSON artifact")
    manifest = load_json(manifest_path)
    if not isinstance(manifest, dict):
        raise WorldBuilderError("behavioral test-drive manifest must be a JSON object")

    target_sha = sha256_file(target)
    manifest_sha = sha256_file(manifest_path)
    prediction = runtime_verification.predict(manifest, prompt.strip(), depth=depth)
    case_id = _case_id(str(state.get("build_id")), prompt.strip(), target_sha, manifest_sha, depth, case_label)

    work_root = resolve_state_path(root, state, "behavioral_testdrive_work") / case_id
    report_root = resolve_state_path(root, state, "behavioral_testdrive_reports") / case_id
    work_root.mkdir(parents=True, exist_ok=True)
    report_root.mkdir(parents=True, exist_ok=True)

    context_path = work_root / "context.txt"
    generation_task_path = work_root / "generation-task.md"
    response_path = work_root / "response.txt"
    review_task_path = work_root / "review-task.md"
    lens_path = work_root / "lens-verdict.json"
    binding_path = work_root / "response-binding.json"
    plan_path = report_root / "plan.json"
    report_path = report_root / "report.json"

    context_text, context_entries, card_fields = _assemble_context(
        data, info.kind, [str(x) for x in prediction.get("activated_uids", [])], case_id=case_id
    )
    atomic_write_text(context_path, context_text)

    plan: dict[str, Any] = {
        "contract": CONTRACT,
        "testdrive_version": 1,
        "build_id": state.get("build_id"),
        "case_id": case_id,
        "prompt": prompt.strip(),
        "depth_limit": depth,
        "evidence_strength": "predicted_not_observed",
        "target_kind": info.kind,
        "target_sha256": target_sha,
        "manifest_sha256": manifest_sha,
        "context_sha256": sha256_file(context_path),
        "prediction": prediction,
        "context_entries": context_entries,
        "persistent_card_fields": card_fields,
        "required_behavioral_checks": list(REQUIRED_CHECKS),
        "plan_path": _rel(root, plan_path),
        "paths": {
            "context": _rel(root, context_path),
            "generation_task": _rel(root, generation_task_path),
            "response": _rel(root, response_path),
            "response_binding": _rel(root, binding_path),
            "review_task": _rel(root, review_task_path),
            "lens_verdict": _rel(root, lens_path),
            "report": _rel(root, report_path),
        },
    }
    atomic_write_json(plan_path, plan)
    atomic_write_text(
        generation_task_path,
        _generation_task(_rel(root, plan_path), _rel(root, context_path), _rel(root, response_path), prompt.strip()),
    )
    plan["generation_task_sha256"] = sha256_file(generation_task_path)
    atomic_write_json(plan_path, plan)
    return plan


def bind_response(build_state: str | Path, plan_path: str | Path, response_file: str | Path | None = None) -> dict[str, Any]:
    root, _state, plan, _target, _manifest, context = _validate_plan_current(build_state, plan_path)
    response = Path(response_file).resolve() if response_file else _path_from_plan(root, plan.get("paths", {}).get("response"), "paths.response")
    expected_response = _path_from_plan(root, plan.get("paths", {}).get("response"), "paths.response")
    if response != expected_response:
        raise WorldBuilderError("behavioral test-drive response must use the plan-declared response path")
    if not response.exists() or not response.read_text(encoding="utf-8").strip():
        raise WorldBuilderError("behavioral test-drive response is missing or empty")
    plan_file = Path(plan_path).resolve()
    plan_sha = sha256_file(plan_file)
    response_sha = sha256_file(response)
    binding_path = _path_from_plan(root, plan.get("paths", {}).get("response_binding"), "paths.response_binding")
    review_task_path = _path_from_plan(root, plan.get("paths", {}).get("review_task"), "paths.review_task")
    lens_path = _path_from_plan(root, plan.get("paths", {}).get("lens_verdict"), "paths.lens_verdict")
    binding = {
        "contract": RESPONSE_BINDING_CONTRACT,
        "build_id": plan.get("build_id"),
        "case_id": plan.get("case_id"),
        "plan_sha256": plan_sha,
        "context_sha256": sha256_file(context),
        "response_sha256": response_sha,
    }
    atomic_write_json(binding_path, binding)
    atomic_write_text(
        review_task_path,
        _review_task(
            _rel(root, plan_file),
            _rel(root, context),
            _rel(root, response),
            _rel(root, lens_path),
            case_id=str(plan.get("case_id")),
            plan_sha=plan_sha,
            context_sha=sha256_file(context),
            response_sha=response_sha,
        ),
    )
    return binding | {"review_task": _rel(root, review_task_path), "lens_verdict": _rel(root, lens_path)}


def _validate_lens(lens: Any, *, plan: dict[str, Any], plan_sha: str, context_sha: str, response_sha: str) -> dict[str, Any]:
    if not isinstance(lens, dict):
        raise WorldBuilderError("behavioral lens verdict must be a JSON object")
    expected_top = {"contract", "case_id", "plan_sha256", "context_sha256", "response_sha256", "checks", "summary"}
    if set(lens) != expected_top:
        missing = sorted(expected_top - set(lens))
        extra = sorted(set(lens) - expected_top)
        raise WorldBuilderError(f"behavioral lens verdict keys mismatch; missing={missing} extra={extra}")
    if lens.get("contract") != LENS_CONTRACT:
        raise WorldBuilderError("behavioral lens contract mismatch")
    if lens.get("case_id") != plan.get("case_id"):
        raise WorldBuilderError("behavioral lens case_id mismatch")
    for key, expected in (("plan_sha256", plan_sha), ("context_sha256", context_sha), ("response_sha256", response_sha)):
        if lens.get(key) != expected:
            raise WorldBuilderError(f"behavioral lens {key} mismatch")
    summary = lens.get("summary")
    if not isinstance(summary, str) or not summary.strip():
        raise WorldBuilderError("behavioral lens summary must be non-empty")
    checks = lens.get("checks")
    if not isinstance(checks, dict) or set(checks) != set(REQUIRED_CHECKS):
        raise WorldBuilderError("behavioral lens must contain exactly voice_consistency and knowledge_boundary")
    normalized: dict[str, Any] = {}
    for name in REQUIRED_CHECKS:
        row = checks.get(name)
        if not isinstance(row, dict) or set(row) != {"status", "summary", "evidence"}:
            raise WorldBuilderError(f"behavioral lens check {name} must contain exactly status, summary, evidence")
        status = row.get("status")
        if status not in CHECK_STATUSES:
            raise WorldBuilderError(f"behavioral lens check {name} status must be pass or fail")
        check_summary = row.get("summary")
        if not isinstance(check_summary, str) or not check_summary.strip():
            raise WorldBuilderError(f"behavioral lens check {name} summary must be non-empty")
        evidence = row.get("evidence")
        if not isinstance(evidence, list) or any(not isinstance(item, str) or not item.strip() or len(item) > 240 for item in evidence):
            raise WorldBuilderError(f"behavioral lens check {name} evidence must be a list of non-empty snippets up to 240 characters")
        if len(evidence) > 8:
            raise WorldBuilderError(f"behavioral lens check {name} may contain at most 8 evidence snippets")
        normalized[name] = {"status": status, "summary": check_summary.strip(), "evidence": evidence}
    return normalized


def finalize(build_state: str | Path, plan_path: str | Path, response_file: str | Path | None = None, lens_verdict: str | Path | None = None) -> dict[str, Any]:
    root, _state, plan, target, _manifest_path, context = _validate_plan_current(build_state, plan_path)
    plan_file = Path(plan_path).resolve()
    response = Path(response_file).resolve() if response_file else _path_from_plan(root, plan.get("paths", {}).get("response"), "paths.response")
    lens_path = Path(lens_verdict).resolve() if lens_verdict else _path_from_plan(root, plan.get("paths", {}).get("lens_verdict"), "paths.lens_verdict")
    if response != _path_from_plan(root, plan.get("paths", {}).get("response"), "paths.response"):
        raise WorldBuilderError("behavioral test-drive response must use the plan-declared response path")
    if lens_path != _path_from_plan(root, plan.get("paths", {}).get("lens_verdict"), "paths.lens_verdict"):
        raise WorldBuilderError("behavioral lens verdict must use the plan-declared verdict path")
    if not response.exists() or not response.read_text(encoding="utf-8").strip():
        raise WorldBuilderError("behavioral test-drive response is missing or empty")
    if not lens_path.exists():
        raise WorldBuilderError("behavioral lens verdict is missing")

    binding_path = _path_from_plan(root, plan.get("paths", {}).get("response_binding"), "paths.response_binding")
    if not binding_path.exists():
        raise WorldBuilderError("behavioral response has not been bound; run bind-response first")
    binding = load_json(binding_path)
    plan_sha = sha256_file(plan_file)
    context_sha = sha256_file(context)
    response_sha = sha256_file(response)
    expected_binding = {
        "contract": RESPONSE_BINDING_CONTRACT,
        "build_id": plan.get("build_id"),
        "case_id": plan.get("case_id"),
        "plan_sha256": plan_sha,
        "context_sha256": context_sha,
        "response_sha256": response_sha,
    }
    if binding != expected_binding:
        raise WorldBuilderError("behavioral response binding is stale or does not match the current plan/context/response")

    lens = load_json(lens_path)
    checks = _validate_lens(lens, plan=plan, plan_sha=plan_sha, context_sha=context_sha, response_sha=response_sha)

    data = load_json(target)
    info = detect_artifact(data)
    profile = "sillytavern" if info.kind == "sillytavern_world_info" else "spec"
    validation, _validated_info = validate_output.validate(data, profile, None)
    technical_valid = not validation.errors
    behavioral_poor = any(row["status"] == "fail" for row in checks.values())
    if not technical_valid:
        classification = "technically_invalid"
    elif behavioral_poor:
        classification = "technically_valid_but_behaviorally_poor"
    else:
        classification = "technically_valid_and_behaviorally_acceptable"

    report = {
        "contract": CONTRACT,
        "testdrive_version": 1,
        "build_id": plan.get("build_id"),
        "case_id": plan.get("case_id"),
        "evidence_strength": "predicted_not_observed",
        "classification": classification,
        "technical_validity": {
            "status": "valid" if technical_valid else "invalid",
            "profile": profile,
            "errors": [
                {"code": issue.code, "path": issue.path, "message": issue.message}
                for issue in validation.errors
            ],
            "warnings": [
                {"code": issue.code, "path": issue.path, "message": issue.message}
                for issue in validation.warnings
            ],
        },
        "behavioral_quality": {
            "status": "poor" if behavioral_poor else "acceptable",
            "checks": checks,
            "summary": str(lens.get("summary")).strip(),
        },
        "prediction": plan.get("prediction"),
        "bindings": {
            "target_sha256": sha256_file(target),
            "manifest_sha256": plan.get("manifest_sha256"),
            "plan_sha256": plan_sha,
            "context_sha256": context_sha,
            "response_sha256": response_sha,
            "lens_verdict_sha256": sha256_file(lens_path),
        },
        "auto_corrected": False,
        "release_gate_satisfied": False,
        "live_runtime_observed": False,
        "note": "Behavioral test-drive is diagnostic. It does not replace the four-lens audit, delivery seal, or observed SillyTavern runtime verification.",
    }
    report_path = _path_from_plan(root, plan.get("paths", {}).get("report"), "paths.report")
    atomic_write_json(report_path, report)
    return report


def build_argument_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("prepare", help="freeze predicted activation/context and write the generation task")
    p.add_argument("--build-state", required=True)
    p.add_argument("--prompt", required=True)
    p.add_argument("--depth", type=int, default=8)
    p.add_argument("--case-label")

    p = sub.add_parser("bind-response", help="bind generated response bytes and write the independent review task")
    p.add_argument("--build-state", required=True)
    p.add_argument("--plan", required=True)
    p.add_argument("--response-file")

    p = sub.add_parser("finalize", help="validate the independent lens verdict and write the behavioral report")
    p.add_argument("--build-state", required=True)
    p.add_argument("--plan", required=True)
    p.add_argument("--response-file")
    p.add_argument("--lens-verdict")
    return parser


def main() -> int:
    parser = build_argument_parser()
    args = parser.parse_args()
    try:
        if args.command == "prepare":
            result = prepare(args.build_state, args.prompt, depth=args.depth, case_label=args.case_label)
        elif args.command == "bind-response":
            result = bind_response(args.build_state, args.plan, args.response_file)
        else:
            result = finalize(args.build_state, args.plan, args.response_file, args.lens_verdict)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (WorldBuilderError, OSError, ValueError, json.JSONDecodeError, UnicodeDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
