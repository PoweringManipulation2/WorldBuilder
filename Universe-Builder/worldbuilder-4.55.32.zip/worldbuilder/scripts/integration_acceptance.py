#!/usr/bin/env python3
"""Freeze and validate the Batch 10 full-integration contract."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

from wb_common import (
    step_driver_pointer,
    WorldBuilderError,
    atomic_write_json,
    load_build_state,
    load_json,
    now_iso,
    resolve_state_path,
    sha256_file,
)

CONTRACT = "worldbuilder-full-integration-v1"
PLAN_VERSION = 1
RECEIPT_VERSION = 2
PIPELINE_REGISTRY_VERSION = 2
REGISTRY_KIND = "worldbuilder-pipeline-registry-source"
PLAN_KIND = "worldbuilder-integration-plan"
RECEIPT_KIND = "worldbuilder-integration-gate"


def skill_root() -> Path:
    return Path(__file__).resolve().parent.parent


def load_registry(path: Path | None = None) -> dict[str, Any]:
    target = path or (skill_root() / "references" / "pipeline-registry.json")
    data = load_json(target)
    if not isinstance(data, dict) or data.get("kind") != REGISTRY_KIND:
        raise WorldBuilderError("pipeline registry has the wrong format")
    if data.get("contract") != CONTRACT or data.get("registry_version") != PIPELINE_REGISTRY_VERSION:
        raise WorldBuilderError("pipeline registry contract/version mismatch")
    pipelines = data.get("pipelines")
    auditors = data.get("auditors")
    scenarios = data.get("acceptance_scenarios")
    if not isinstance(pipelines, dict) or not isinstance(auditors, dict) or not isinstance(scenarios, list):
        raise WorldBuilderError("pipeline registry is incomplete")
    required_pipelines = {"character", "world", "lorebook", "group", "persona", "audit", "iterate", "update", "prune", "quick", "full-detail", "multi-era", "resume-recovery"}
    if set(pipelines) != required_pipelines:
        raise WorldBuilderError("pipeline registry does not cover every Batch 10 pipeline")
    required_lenses = {"compass", "weaver", "scout", "warden"}
    if set(auditors) != required_lenses:
        raise WorldBuilderError("pipeline registry does not define all four audit lenses")
    scenario_ids = [row.get("id") for row in scenarios if isinstance(row, dict)]
    if len(scenario_ids) != 13 or len(set(scenario_ids)) != 13:
        raise WorldBuilderError("acceptance matrix must contain 13 unique scenarios")
    for row in scenarios:
        if not isinstance(row, dict):
            raise WorldBuilderError("acceptance matrix rows must be objects")
        owners = row.get("test_owners")
        if row.get("evidence_level") != "composite-deterministic":
            raise WorldBuilderError(f"acceptance scenario {row.get('id')} lacks a deterministic evidence level")
        if not isinstance(owners, list) or len(owners) < 2 or len(owners) != len(set(owners)):
            raise WorldBuilderError(f"acceptance scenario {row.get('id')} requires multiple unique test owners")
        if row.get("test_owner") not in owners or any(not isinstance(owner, str) or not owner for owner in owners):
            raise WorldBuilderError(f"acceptance scenario {row.get('id')} has an invalid owner set")
    return data


def primary_pipeline(artifact_type: str) -> str:
    mapping = {
        "card": "character",
        "world": "world",
        "lorebook": "lorebook",
        "group": "group",
        "persona": "persona",
        "audit": "audit",
        "convert": "audit",
        "prune": "prune",
        "resume-recovery": "resume-recovery",
        "iterate": "iterate",
        "update": "update",
    }
    return mapping.get(artifact_type, "lorebook")


def required_systems_for(
    registry: dict[str, Any],
    *,
    artifact_type: str,
    schema: Any,
    era_mode: str,
    source_kind: str,
    budget_profile: str,
    dynamic_applicable: bool,
    runtime_required: bool,
) -> list[str]:
    pipeline = primary_pipeline(artifact_type)
    row = registry["pipelines"][pipeline]
    systems = list(row.get("required_systems", []))
    if schema in {2, 3} or artifact_type in {"world", "lorebook", "group"}:
        for name in ("activation_graph", "placement", "budget"):
            if name not in systems:
                systems.append(name)
    if era_mode == "multi" and "era_router" not in systems:
        systems.append("era_router")
    if source_kind == "known-property" and "breadth_discovery" not in systems:
        systems.append("breadth_discovery")
    if dynamic_applicable and "dynamic_state" not in systems:
        systems.append("dynamic_state")
    if not runtime_required and "target_adapter" in systems:
        # The semantic adapter boundary remains part of the pipeline even when
        # no separate runtime conversion receipt is required.
        pass
    if budget_profile in {"maximum-detail", "maximum_detail"} and "full_detail" not in systems:
        systems.append("full_detail")
    return systems


def build_plan(
    *,
    build_id: str,
    artifact_type: str,
    schema: Any,
    persona_mode: str | None,
    era_mode: str,
    source_kind: str,
    pipeline_mode: str,
    interface_mode: str,
    budget_profile: str,
    dynamic_applicable: bool,
    runtime_required: bool,
    registry_path: Path | None = None,
) -> dict[str, Any]:
    registry = load_registry(registry_path)
    pipeline = primary_pipeline(artifact_type)
    systems = required_systems_for(
        registry,
        artifact_type=artifact_type,
        schema=schema,
        era_mode=era_mode,
        source_kind=source_kind,
        budget_profile=budget_profile,
        dynamic_applicable=dynamic_applicable,
        runtime_required=runtime_required,
    )
    route_variants = []
    if era_mode == "multi":
        route_variants.append("multi-era")
    if budget_profile == "compact":
        route_variants.append("quick")
    if budget_profile in {"maximum-detail", "maximum_detail"}:
        route_variants.append("full-detail")
    route_variants.append("resume-recovery")
    return {
        "kind": PLAN_KIND,
        "plan_version": PLAN_VERSION,
        "contract": CONTRACT,
        "build_id": build_id,
        "pipeline": pipeline,
        "artifact_type": artifact_type,
        "schema": schema,
        "persona_mode": persona_mode,
        "era_mode": era_mode,
        "source_kind": source_kind,
        "pipeline_mode": pipeline_mode,
        "interface_mode": interface_mode,
        "required_systems": systems,
        "route_variants": route_variants,
        "auditor_checks": registry["auditors"],
        "acceptance_scenarios": [row["id"] for row in registry["acceptance_scenarios"]],
        "registry_sha256": sha256_file(registry_path or (skill_root() / "references" / "pipeline-registry.json")),
        "created_at": now_iso(),
    }


def validate_plan(plan: Any, state: dict[str, Any], registry: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(plan, dict) or plan.get("kind") != PLAN_KIND:
        raise WorldBuilderError("integration plan has the wrong format")
    if plan.get("plan_version") != PLAN_VERSION or plan.get("contract") != CONTRACT:
        raise WorldBuilderError("integration plan contract/version mismatch")
    if plan.get("build_id") != state.get("build_id"):
        raise WorldBuilderError("integration plan belongs to another build")
    artifact = state.get("artifact") if isinstance(state.get("artifact"), dict) else {}
    content = state.get("content_architecture") if isinstance(state.get("content_architecture"), dict) else {}
    source = state.get("source") if isinstance(state.get("source"), dict) else {}
    if plan.get("artifact_type") != artifact.get("type") or plan.get("schema") != artifact.get("schema"):
        raise WorldBuilderError("integration plan artifact routing differs from build state")
    if plan.get("pipeline") != primary_pipeline(str(artifact.get("type"))):
        raise WorldBuilderError("integration plan primary pipeline is stale")
    if plan.get("era_mode") != content.get("era_mode"):
        raise WorldBuilderError("integration plan era mode differs from build state")
    if plan.get("source_kind") != source.get("kind"):
        raise WorldBuilderError("integration plan source kind differs from build state")
    if plan.get("auditor_checks") != registry.get("auditors"):
        raise WorldBuilderError("integration plan auditor matrix differs from the frozen registry")
    if set(plan.get("acceptance_scenarios", [])) != {row["id"] for row in registry["acceptance_scenarios"]}:
        raise WorldBuilderError("integration plan acceptance matrix is incomplete")
    required = plan.get("required_systems")
    if not isinstance(required, list) or not required or len(required) != len(set(required)):
        raise WorldBuilderError("integration plan required systems are missing or duplicated")
    return plan


def _relative(path: Path, root: Path) -> str:
    return str(path.relative_to(root)).replace("\\", "/")


def _existing_receipt(root: Path, state: dict[str, Any], key: str, required: bool) -> dict[str, str] | None:
    path = resolve_state_path(root, state, key, required=False)
    if path is None or not path.exists():
        if required:
            raise WorldBuilderError(f"full-integration gate requires {key}")
        return None
    return {"key": key, "path": _relative(path, root), "sha256": sha256_file(path)}


def _amendment_context(root: Path, state: dict[str, Any]) -> dict[str, Any] | None:
    """Batch 12: extends the existing route-level chain schema with the
    latest amendment's own summary, rather than a parallel ledger.
    component_receipts stays a flat list of individual receipt hashes
    (unchanged, since that schema has no natural place for aggregate
    metadata); this is a sibling top-level field, matching how
    route_variants already sits alongside component_receipts rather than
    inside it. Returns None when the build has never been amended; the
    key is still present in the receipt (matching delivery_gate.py's own
    pattern for optional fields like budget_plan_sha256), just null, so
    an unamended receipt's shape is otherwise unchanged.
    """
    ledger_path = resolve_state_path(root, state, "pipeline_stage_ledger", required=False)
    if ledger_path is None or not ledger_path.exists():
        return None
    ledger = load_json(ledger_path)
    amendments = ledger.get("amendments") if isinstance(ledger.get("amendments"), list) else []
    if not amendments:
        return None
    latest = amendments[-1]
    return {
        "amendment_id": latest.get("amendment_id"),
        "amendment_count": len(amendments),
        "change_set_sha256": latest.get("change_set_sha256"),
        "first_amended_stage": latest.get("first_amended_stage"),
        "structural": latest.get("structural"),
    }


def validate_build(build_state: str | Path, stage: str, target: str | Path | None = None, *, write_receipt: bool = True) -> dict[str, Any]:
    if stage not in {"planning", "output", "resume"}:
        raise WorldBuilderError("integration stage must be planning, output, or resume")
    state_path = Path(build_state).resolve()
    root, state = load_build_state(state_path)
    registry_path = resolve_state_path(root, state, "pipeline_registry")
    plan_path = resolve_state_path(root, state, "integration_plan")
    registry = load_registry(registry_path)
    plan = validate_plan(load_json(plan_path), state, registry)
    integration_state = state.get("integration") if isinstance(state.get("integration"), dict) else {}
    if integration_state.get("contract") != CONTRACT:
        raise WorldBuilderError("build state has no full-integration contract")
    if integration_state.get("plan_sha256") != sha256_file(plan_path):
        raise WorldBuilderError("build-state integration plan hash is stale")
    if integration_state.get("registry_sha256") != sha256_file(registry_path):
        raise WorldBuilderError("build-state pipeline registry hash is stale")

    systems = set(plan.get("required_systems", []))
    rows: list[dict[str, str]] = []
    if stage in {"planning", "output", "resume"}:
        for key, needed in (
            ("architecture_planning_receipt", "card_shell" in systems or "character_architecture" in systems),
            ("activation_map_receipt", "activation_graph" in systems),
            ("era_router_receipt", "era_router" in systems),
            ("placement_planning_receipt", "placement" in systems),
            ("budget_planning_receipt", "budget" in systems),
            ("dynamic_state_planning_receipt", "dynamic_state" in systems),
        ):
            row = _existing_receipt(root, state, key, bool(needed))
            if row:
                rows.append(row)
    target_path: Path | None = None
    if stage == "output":
        target_path = Path(target).resolve() if target else resolve_state_path(root, state, "final_output")
        if not target_path.exists():
            raise WorldBuilderError("full-integration output target is missing")
        for key, needed in (
            ("architecture_output_receipt", "card_shell" in systems or "character_architecture" in systems),
            ("placement_output_receipt", "placement" in systems),
            ("budget_output_receipt", "budget" in systems),
            ("dynamic_state_output_receipt", "dynamic_state" in systems),
            ("pre_generation_audit_receipt", bool(state.get("audit", {}).get("pre_generation_required"))),
            ("post_generation_audit_receipt", bool(state.get("audit", {}).get("post_generation_required"))),
            ("runtime_adapter_receipt", str(state.get("status", {}).get("runtime_adapter", "not_required")) != "not_required"),
        ):
            row = _existing_receipt(root, state, key, bool(needed))
            if row:
                rows.append(row)
    if stage == "resume":
        statuses = state.get("status") if isinstance(state.get("status"), dict) else {}
        for key, value in statuses.items():
            if value == "complete":
                path_keys = {
                    "planning": ["planning_receipt", "integration_planning_receipt"],
                    "runtime_adapter": ["runtime_adapter_receipt"],
                }.get(key, [])
                for path_key in path_keys:
                    row = _existing_receipt(root, state, path_key, True)
                    if row:
                        rows.append(row)

    receipt = {
        "kind": RECEIPT_KIND,
        "receipt_version": RECEIPT_VERSION,
        "contract": CONTRACT,
        "status": "passed",
        "stage": stage,
        "build_id": state.get("build_id"),
        "pipeline": plan.get("pipeline"),
        "required_systems": plan.get("required_systems"),
        "route_variants": plan.get("route_variants"),
        "amendment_context": _amendment_context(root, state),
        "pipeline_registry": _relative(registry_path, root),
        "pipeline_registry_sha256": sha256_file(registry_path),
        "integration_plan": _relative(plan_path, root),
        "integration_plan_sha256": sha256_file(plan_path),
        "component_receipts": rows,
        "target": _relative(target_path, root) if target_path else None,
        "target_sha256": sha256_file(target_path) if target_path else None,
        "auditor_checks": plan.get("auditor_checks"),
        "acceptance_scenarios": plan.get("acceptance_scenarios"),
        "validated_at": now_iso(),
    }
    if write_receipt:
        key = "integration_output_receipt" if stage == "output" else "integration_planning_receipt"
        if stage == "resume":
            key = "integration_resume_receipt"
        receipt_path = resolve_state_path(root, state, key)

        # Revalidation of unchanged bytes must be idempotent. Delivery commonly
        # recomputes the integration proof after sealing; rewriting an identical
        # receipt only to change ``validated_at`` would invalidate the ordered
        # pipeline-stage receipt that already binds it. Preserve the existing
        # file when its substantive evidence is identical.
        existing = load_json(receipt_path) if receipt_path.exists() else None
        def substantive(value: Any) -> Any:
            if not isinstance(value, dict):
                return value
            return {k: v for k, v in value.items() if k not in {"validated_at", "receipt", "receipt_sha256"}}

        if isinstance(existing, dict) and substantive(existing) == substantive(receipt):
            receipt = existing
        else:
            atomic_write_json(receipt_path, receipt)
        state.setdefault("status", {})[f"integration_{stage}"] = "complete"
        state.setdefault("lineage", {})[f"integration_{stage}_receipt_sha256"] = sha256_file(receipt_path)
        atomic_write_json(state_path, state)
        receipt["receipt"] = _relative(receipt_path, root)
        receipt["receipt_sha256"] = sha256_file(receipt_path)
    return receipt


def acceptance_matrix(registry_path: Path | None = None) -> dict[str, Any]:
    registry = load_registry(registry_path)
    return {
        "kind": "worldbuilder-release-acceptance-matrix",
        "matrix_version": 1,
        "contract": CONTRACT,
        "pipeline_count": len(registry["pipelines"]),
        "scenario_count": len(registry["acceptance_scenarios"]),
        "pipelines": registry["pipelines"],
        "auditors": registry["auditors"],
        "scenarios": registry["acceptance_scenarios"],
    }


def parser() -> argparse.ArgumentParser:
    root = argparse.ArgumentParser(description=__doc__)
    sub = root.add_subparsers(dest="command", required=True)
    validate = sub.add_parser("validate", help="Validate one build's integrated pipeline lineage.")
    validate.add_argument("--build-state", required=True)
    validate.add_argument("--stage", choices=["planning", "output", "resume"], required=True)
    validate.add_argument("--target")
    matrix = sub.add_parser("matrix", help="Validate and emit the release acceptance matrix.")
    matrix.add_argument("--registry")
    matrix.add_argument("--output")
    return root


def main() -> int:
    args = parser().parse_args()
    try:
        if args.command == "validate":
            result = validate_build(args.build_state, args.stage, args.target)
        else:
            result = acceptance_matrix(Path(args.registry).resolve() if args.registry else None)
            if args.output:
                atomic_write_json(Path(args.output).resolve(), result)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (WorldBuilderError, OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"FULL INTEGRATION GATE BLOCKED: {exc}", file=sys.stderr)
        print(step_driver_pointer(), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
