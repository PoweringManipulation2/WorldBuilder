#!/usr/bin/env python3
"""Validate and normalize concise semantic lorebook entry labels.

WorldBuilder keeps source provenance in structured metadata. User-visible entry
labels use a compact ``PREFIX: Subject`` form such as ``RULE: No bad`` or
``ITEM: Thingimajig``. This module validates manifest naming inputs, normalizes
merged/imported artifacts, and writes content-bound receipts.
"""
from __future__ import annotations

import argparse
import copy
import json
import re
import sys
from pathlib import Path
from typing import Any

from terminology_dictionary import (
    CONTRACT as TERMINOLOGY_CONTRACT,
    build_dictionary as build_terminology_dictionary,
    canonicalize_term,
    validate_dictionary as validate_terminology_dictionary,
)

from wb_common import (
    WorldBuilderError,
    atomic_write_json,
    canonical_entry_identity,
    detect_artifact,
    iter_entries,
    load_build_state,
    load_json,
    resolve_state_path,
    sha256_file,
)

CONTRACT = "worldbuilder-entry-naming-v1"
RECEIPT_KIND = "worldbuilder-entry-naming-receipt"
MAX_LABEL_LENGTH = 48
MAX_SUBJECT_LENGTH = 40
NAMING_EXTENSION = "worldbuilder_entry_naming"
PROVENANCE_EXTENSION = "worldbuilder_provenance"

PREFIX_BY_TYPE = {
    "character": "CHARACTER",
    "location": "LOCATION",
    "faction": "FACTION",
    "organization": "ORGANIZATION",
    "species": "SPECIES",
    "event": "EVENT",
    "object": "ITEM",
    "item": "ITEM",
    "artifact": "ITEM",
    "ability": "ABILITY",
    "power": "ABILITY",
    "relationship": "RELATIONSHIP",
    "system": "SYSTEM",
    "mechanic": "SYSTEM",
    "rule": "RULE",
    "concept": "CONCEPT",
    "episode": "EPISODE",
    "other": "CONCEPT",
}

PREFIX_BY_UID_PREFIX = {
    "CH": "CHARACTER",
    "CHAR": "CHARACTER",
    "LOC": "LOCATION",
    "PLACE": "LOCATION",
    "FAC": "FACTION",
    "ORG": "ORGANIZATION",
    "SP": "SPECIES",
    "SPEC": "SPECIES",
    "EV": "EVENT",
    "EVENT": "EVENT",
    "EP": "EPISODE",
    "EC": "ERA",
    "ERA": "ERA",
    "IDX": "INDEX",
    "INDEX": "INDEX",
    "REL": "RELATIONSHIP",
    "ITEM": "ITEM",
    "OBJ": "ITEM",
    "ABIL": "ABILITY",
    "SYS": "SYSTEM",
    "RULE": "RULE",
}

PREFIX_BY_LAYER = {
    "world_index": "INDEX",
    "world_core": "RULE",
    "world_invariants": "RULE",
    "control": "RULE",
    "era_context": "ERA",
    "character": "CHARACTER",
    "relationship": "RELATIONSHIP",
    "location": "LOCATION",
    "faction": "FACTION",
    "organization": "ORGANIZATION",
    "species": "SPECIES",
    "event": "EVENT",
    "object": "ITEM",
    "item": "ITEM",
    "ability": "ABILITY",
    "system": "SYSTEM",
    "concept": "CONCEPT",
    "detail": "CONCEPT",
    "episode": "EPISODE",
}

SEMANTIC_LABEL_RE = re.compile(
    r"^(RULE|ITEM|CHARACTER|LOCATION|FACTION|ORGANIZATION|SPECIES|EVENT|EPISODE|ERA|RELATIONSHIP|ABILITY|SYSTEM|CONCEPT|WORLD|INDEX)\s*:\s*(\S(?:.*\S)?)$",
    re.IGNORECASE,
)
SOURCEISH_RE = re.compile(
    r"(?:^|\b)(?:source(?:d)?\s+from|synthesi[sz]ed\s+from|retrieved\s+from|information\s+from|lore\s+from|source\s*:|article\s*:|page\s*:|https?://|www\.)",
    re.IGNORECASE,
)
LEADING_SOURCE_RE = re.compile(
    r"^\s*(?:source(?:d)?\s+from|synthesi[sz]ed\s+from|retrieved\s+from|information\s+from|lore\s+from|source|article|page)\b\s*[:\-–—]*\s*",
    re.IGNORECASE,
)
CONTENT_PROVENANCE_RE = re.compile(
    r"https?://\S+|\bwww\.\S+|\b(?:source|sources)\s*:|"
    r"\b(?:sourced|retrieved|information|lore)\s+from\b|"
    r"\b(?:fandom|mediawiki)\s+(?:wiki|page|article)\b|\bwiki\s+(?:page|article)\b",
    re.IGNORECASE,
)


def content_provenance_matches(value: Any) -> list[str]:
    """Detect citation/provenance boilerplate in model-facing prose without rewriting it."""
    if not isinstance(value, str) or not value:
        return []
    return list(dict.fromkeys(match.group(0)[:160] for match in CONTENT_PROVENANCE_RE.finditer(value)))


def _clean_space(value: Any) -> str:
    return re.sub(r"\s+", " ", str(value or "").strip())


def _strip_existing_prefix(value: str) -> str:
    match = SEMANTIC_LABEL_RE.fullmatch(value)
    return _clean_space(match.group(2)) if match else value


def _strip_source_boilerplate(value: str) -> str:
    text = LEADING_SOURCE_RE.sub("", _clean_space(value))
    # Legacy labels commonly used "Source from <site> - <topic>". The final
    # segment is the useful subject; provenance is retained separately.
    if SOURCEISH_RE.search(value):
        parts = [part.strip() for part in re.split(r"\s+(?:[-–—]|\|)\s+|\s*::\s*", text) if part.strip()]
        if len(parts) > 1:
            text = parts[-1]
        text = re.sub(r"https?://\S+", "", text, flags=re.IGNORECASE)
        text = re.sub(r"\b(?:fandom|mediawiki|wiki)\b\s*(?:page|article)?\s*[:\-–—]*", "", text, flags=re.IGNORECASE)
    return _clean_space(text).strip(" :-–—|")


def _truncate_subject(value: str, limit: int = MAX_SUBJECT_LENGTH) -> str:
    value = _clean_space(value)
    limit = max(8, limit)
    if len(value) <= limit:
        return value
    shortened = value[: limit - 1].rsplit(" ", 1)[0].rstrip(" ,;:-–—")
    return (shortened or value[: limit - 1]).rstrip() + "…"


def _keys(entry: dict[str, Any]) -> list[str]:
    raw = entry.get("keys") if isinstance(entry.get("keys"), list) else entry.get("key")
    if not isinstance(raw, list):
        return []
    return [_clean_space(item) for item in raw if _clean_space(item)]


def infer_prefix(entry: dict[str, Any], manifest_entry: dict[str, Any] | None = None) -> str:
    source = manifest_entry if isinstance(manifest_entry, dict) else entry
    architecture = source.get("architecture") if isinstance(source.get("architecture"), dict) else {}
    layer = _clean_space(architecture.get("layer")).casefold().replace("-", "_").replace(" ", "_")
    if layer in PREFIX_BY_LAYER:
        return PREFIX_BY_LAYER[layer]
    entry_type = _clean_space(source.get("type") or source.get("entry_type")).casefold().replace("-", "_").replace(" ", "_")
    if entry_type in PREFIX_BY_TYPE:
        return PREFIX_BY_TYPE[entry_type]
    if architecture.get("era_scope") == "context":
        return "ERA"
    existing = SEMANTIC_LABEL_RE.fullmatch(_clean_space(entry.get("name") or entry.get("comment")))
    if existing is not None:
        return existing.group(1).upper()
    identity = canonical_entry_identity(entry)
    if identity is not None:
        uid_prefix = re.split(r"[-_:]", str(identity).strip(), maxsplit=1)[0].upper()
        if uid_prefix in PREFIX_BY_UID_PREFIX:
            return PREFIX_BY_UID_PREFIX[uid_prefix]
    title = _strip_existing_prefix(_clean_space(entry.get("name") or entry.get("comment"))).casefold()
    # Generic WI/world entries need a little semantic help when no manifest is
    # available. Prefer visible subject clues over prose-wide keyword guesses.
    if any(token in title for token in ("rule", "law", "invariant", "can't", "cannot", "must not")):
        return "RULE"
    if any(token in title for token in ("system", "mechanic", "economy")):
        return "SYSTEM"
    if any(token in title for token in ("lantern", "sword", "weapon", "artifact", "amulet", "ring", "key")):
        return "ITEM"
    if title.startswith("the beast") or title.endswith(" character"):
        return "CHARACTER"
    if identity is not None and str(identity).upper().startswith("WI-"):
        return "WORLD"
    content = _clean_space(entry.get("content"))[:600].casefold()
    heuristics = (
        ("CHARACTER", (" is a character", " is a person", "born ", "personality", "appearance")),
        ("LOCATION", (" is a location", " is a place", "city of ", "region of ", "building located")),
        ("FACTION", (" is a faction", "organization", "political group", "military group")),
        ("SPECIES", (" is a species", "species of ", "race of ", "taxonomic")),
        ("ITEM", (" is an item", " is an object", " is an artifact", "weapon", "tool used")),
        ("ABILITY", (" is an ability", " is a power", "ability allows", "power allows")),
        ("EVENT", (" is an event", "battle of ", "incident", "ceremony")),
        ("SYSTEM", (" is a system", "mechanic", "economy", "magic system")),
    )
    if any(token in content for token in ("must not", "never ", "always ", "rule:", "invariant")):
        return "RULE"
    for prefix, tokens in heuristics:
        if any(token in content for token in tokens):
            return prefix
    return "CONCEPT"


def subject_for(entry: dict[str, Any], manifest_entry: dict[str, Any] | None = None, terminology: dict[str, Any] | None = None) -> str:
    source = manifest_entry if isinstance(manifest_entry, dict) else {}
    explicit = _clean_space(source.get("display_name"))
    if explicit:
        explicit_match = SEMANTIC_LABEL_RE.fullmatch(explicit)
        if not explicit_match:
            raise WorldBuilderError(f"manifest display_name is not PREFIX: Subject: {explicit!r}")
        return _truncate_subject(canonicalize_term(terminology, explicit_match.group(2)))

    current_candidates = [
        _clean_space(entry.get("name")),
        _clean_space(entry.get("comment")),
    ]
    manifest_candidates = [
        _clean_space(source.get("canonical_name")),
        _clean_space(source.get("name")),
        _clean_space(source.get("comment")),
        _clean_space(source.get("title")),
    ]
    key_candidates = _keys(source) + _keys(entry)

    # Prefer a concise canonical name. If the visible label is legacy source
    # boilerplate, prefer a primary key or manifest canonical name instead.
    concise_visible = [value for value in current_candidates if value and not SOURCEISH_RE.search(value)]
    sourceish = any(SOURCEISH_RE.search(value) for value in current_candidates if value)
    if concise_visible:
        candidates = manifest_candidates + concise_visible + key_candidates + current_candidates
    elif sourceish:
        candidates = key_candidates + manifest_candidates + current_candidates
    else:
        candidates = manifest_candidates + current_candidates + key_candidates

    for candidate in candidates:
        if not candidate:
            continue
        candidate = _strip_existing_prefix(candidate)
        candidate = _strip_source_boilerplate(candidate)
        if not candidate or SOURCEISH_RE.search(candidate):
            continue
        return _truncate_subject(canonicalize_term(terminology, candidate))

    identity = canonical_entry_identity(entry)
    if identity is not None:
        return f"Entry {identity}"
    raise WorldBuilderError("entry has no concise subject, primary key, or stable identity for naming")


def _is_era_root(entry: dict[str, Any], manifest_entry: dict[str, Any] | None, subject: str) -> bool:
    """Era roots are the constant era entries; an existing (Root) marker
    (authored or previously normalized) is honored as authoritative."""
    if subject.rstrip().endswith("(Root)"):
        return True
    if bool(entry.get("constant")):
        return True
    source = manifest_entry if isinstance(manifest_entry, dict) else entry
    emit = source.get("emit") if isinstance(source.get("emit"), dict) else {}
    return bool(emit.get("constant"))


def _era_marker(prefix: str, subject: str, entry: dict[str, Any], manifest_entry: dict[str, Any] | None) -> tuple[str, str]:
    """Return (subject, marker) for era entries. Roots end with ``(Root)``;
    non-root era entries keep an existing trailing qualifier like
    ``(Before the Collapse)`` when the full label fits, otherwise they carry
    ``(Branch)``: symmetric with the root marker, never left as the
    unmarked default, and idempotent across repeated normalization."""
    if prefix != "ERA":
        return subject, ""
    root = _is_era_root(entry, manifest_entry, subject)
    if root:
        return subject, "" if subject.rstrip().endswith("(Root)") else " (Root)"
    if re.search(r"\([^()]{2,}\)\s*$", subject):
        if len(f"{prefix}: {subject}") <= MAX_LABEL_LENGTH:
            return subject, ""
        subject = re.sub(r"\s*\([^()]{2,}\)\s*$", "", subject)
    return subject, " (Branch)"


def semantic_label(entry: dict[str, Any], manifest_entry: dict[str, Any] | None = None, terminology: dict[str, Any] | None = None) -> str:
    explicit = _clean_space((manifest_entry or {}).get("display_name")) if isinstance(manifest_entry, dict) else ""
    if explicit:
        match = SEMANTIC_LABEL_RE.fullmatch(explicit)
        if not match:
            raise WorldBuilderError(f"manifest display_name is not PREFIX: Subject: {explicit!r}")
        prefix = match.group(1).upper()
        subject = canonicalize_term(terminology, match.group(2))
    else:
        prefix = infer_prefix(entry, manifest_entry)
        subject = subject_for(entry, manifest_entry, terminology)
    subject, marker = _era_marker(prefix, subject, entry, manifest_entry)
    budget = MAX_LABEL_LENGTH - len(prefix) - 2 - len(marker)
    subject = _truncate_subject(subject, budget)
    return f"{prefix}: {subject}{marker}"


def is_semantic_label(value: Any) -> bool:
    text = _clean_space(value)
    return len(text) <= MAX_LABEL_LENGTH and SEMANTIC_LABEL_RE.fullmatch(text) is not None and SOURCEISH_RE.search(text) is None


def _manifest_by_identity(manifest: dict[str, Any] | None) -> dict[Any, dict[str, Any]]:
    result: dict[Any, dict[str, Any]] = {}
    if not isinstance(manifest, dict):
        return result
    for ref in iter_entries(manifest):
        identity = canonical_entry_identity(ref.entry)
        if identity is not None:
            result[identity] = ref.entry
    return result


def validate_manifest_data(manifest: dict[str, Any], terminology: dict[str, Any] | None = None) -> dict[str, Any]:
    rows = list(iter_entries(manifest))
    if not rows:
        raise WorldBuilderError("entry naming contract requires a non-empty manifest")
    previews: list[dict[str, Any]] = []
    for ref in rows:
        label = semantic_label(ref.entry, ref.entry, terminology)
        previews.append({
            "path": ref.path,
            "identity": canonical_entry_identity(ref.entry),
            "label": label,
            "prefix": label.split(":", 1)[0],
        })
    return {"status": "passed", "contract": CONTRACT, "entry_count": len(rows), "labels": previews}


def validate_manifest_build(build_state: str | Path, *, write_receipt: bool = True) -> dict[str, Any]:
    root, state = load_build_state(build_state)
    manifest_path = resolve_state_path(root, state, "manifest")
    manifest = load_json(manifest_path)
    if not isinstance(manifest, dict):
        raise WorldBuilderError("manifest must be an object")
    manifest_sha = sha256_file(manifest_path)
    terminology_path = resolve_state_path(root, state, "terminology_dictionary", required=False) or root / "artifacts" / "terminology-dictionary.json"
    terminology = build_terminology_dictionary(manifest, build_id=state.get("build_id"), manifest_sha256=manifest_sha)
    atomic_write_json(terminology_path, terminology)
    terminology_sha = sha256_file(terminology_path)
    result = validate_manifest_data(manifest, terminology)
    result.update({
        "kind": RECEIPT_KIND,
        "receipt_version": 1,
        "stage": "planning",
        "build_id": state.get("build_id"),
        "manifest": str(manifest_path.relative_to(root)).replace("\\", "/"),
        "manifest_sha256": manifest_sha,
        "terminology_contract": TERMINOLOGY_CONTRACT,
        "terminology_dictionary": str(terminology_path.relative_to(root)).replace("\\", "/"),
        "terminology_dictionary_sha256": terminology_sha,
        "terminology_term_count": len(terminology.get("terms", [])),
    })
    if write_receipt:
        receipt_path = resolve_state_path(root, state, "entry_naming_planning_receipt", required=False) or root / "artifacts" / "entry-naming-planning-gate.json"
        atomic_write_json(receipt_path, result)
        state.setdefault("lineage", {})["entry_naming_planning_receipt_sha256"] = sha256_file(receipt_path)
        state["lineage"]["terminology_dictionary_sha256"] = terminology_sha
        atomic_write_json(Path(build_state).resolve(), state)
        result["receipt"] = str(receipt_path)
        result["receipt_sha256"] = sha256_file(receipt_path)
    return result


def validate_artifact_labels(data: dict[str, Any]) -> dict[str, Any]:
    rows = list(iter_entries(data))
    for ref in rows:
        visible = ref.entry.get("comment") or ref.entry.get("name")
        if not is_semantic_label(visible):
            raise WorldBuilderError(f"entry label violates naming contract at {ref.path}: {visible!r}")
    return {"status": "passed", "contract": CONTRACT, "entry_count": len(rows)}


def normalize_artifact_data(data: dict[str, Any], manifest: dict[str, Any] | None = None, terminology: dict[str, Any] | None = None) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    result = copy.deepcopy(data)
    manifest_entries = _manifest_by_identity(manifest)
    changes: list[dict[str, Any]] = []
    info = detect_artifact(result)
    for ref in iter_entries(result):
        entry = ref.entry
        identity = canonical_entry_identity(entry)
        planned = manifest_entries.get(identity)
        label = semantic_label(entry, planned, terminology)
        old_name = _clean_space(entry.get("name"))
        old_comment = _clean_space(entry.get("comment"))
        locked = bool((planned or {}).get("naming", {}).get("preserve_label")) if isinstance((planned or {}).get("naming"), dict) else False
        if locked:
            current = old_comment or old_name
            if not is_semantic_label(current):
                raise WorldBuilderError(f"entry {identity!r} preserves a label that violates the semantic naming contract")
            label = current

        ext = entry.get("extensions") if isinstance(entry.get("extensions"), dict) else {}
        naming = ext.get(NAMING_EXTENSION) if isinstance(ext.get(NAMING_EXTENSION), dict) else {}
        naming.update({
            "contract": CONTRACT,
            "visible_label": label,
            "semantic_prefix": label.split(":", 1)[0],
        })
        source_labels = []
        for value in (old_name, old_comment):
            if value and value != label and value not in source_labels:
                source_labels.append(value)
        if source_labels:
            naming["previous_labels"] = source_labels
        ext[NAMING_EXTENSION] = naming
        if old_comment and SOURCEISH_RE.search(old_comment):
            provenance = ext.get(PROVENANCE_EXTENSION) if isinstance(ext.get(PROVENANCE_EXTENSION), dict) else {}
            notes = provenance.get("notes") if isinstance(provenance.get("notes"), list) else []
            if old_comment not in notes:
                notes.append(old_comment)
            provenance.update({"contract": "worldbuilder-provenance-v1", "notes": notes})
            ext[PROVENANCE_EXTENSION] = provenance
        entry["extensions"] = ext

        # SillyTavern displays comment as the World Info entry label. CCv3 also
        # supports name; set both for consistent imports while preserving prior
        # values in the extension above.
        entry["comment"] = label
        if info.kind != "sillytavern_world_info" or "name" in entry:
            entry["name"] = label

        if old_name != _clean_space(entry.get("name")) or old_comment != _clean_space(entry.get("comment")):
            changes.append({
                "path": ref.path,
                "identity": identity,
                "before": {"name": old_name or None, "comment": old_comment or None},
                "after": label,
            })
    return result, changes


def normalize_file(input_path: str | Path, output_path: str | Path | None = None, manifest_path: str | Path | None = None) -> dict[str, Any]:
    source = Path(input_path).expanduser().resolve()
    output = Path(output_path).expanduser().resolve() if output_path else source
    data = load_json(source)
    if not isinstance(data, dict):
        raise WorldBuilderError("entry naming normalization requires a JSON object")
    manifest = load_json(Path(manifest_path).expanduser().resolve()) if manifest_path else None
    if manifest is not None and not isinstance(manifest, dict):
        raise WorldBuilderError("naming manifest must be an object")
    before_sha = sha256_file(source)
    terminology = build_terminology_dictionary(manifest) if isinstance(manifest, dict) else None
    normalized, changes = normalize_artifact_data(data, manifest, terminology)
    output.parent.mkdir(parents=True, exist_ok=True)
    atomic_write_json(output, normalized)
    return {
        "status": "passed",
        "contract": CONTRACT,
        "input": str(source),
        "output": str(output),
        "before_sha256": before_sha,
        "after_sha256": sha256_file(output),
        "entry_count": sum(1 for _ in iter_entries(normalized)),
        "changed_entry_count": len(changes),
        "changes": changes,
    }


def normalize_build_output(build_state: str | Path, target: str | Path | None = None, *, write_receipt: bool = True) -> dict[str, Any]:
    root, state = load_build_state(build_state)
    output = Path(target).resolve() if target else resolve_state_path(root, state, "merge_input")
    manifest_path = resolve_state_path(root, state, "manifest", required=False)
    manifest = load_json(manifest_path) if manifest_path and manifest_path.exists() else None
    terminology_path = resolve_state_path(root, state, "terminology_dictionary", required=False)
    terminology = None
    if terminology_path and terminology_path.exists():
        terminology = load_json(terminology_path)
        validate_terminology_dictionary(terminology, expected_manifest_sha256=sha256_file(manifest_path) if manifest_path and manifest_path.exists() else None)
    if not output.exists():
        raise WorldBuilderError(f"entry naming target is missing: {output}")
    before_sha = sha256_file(output)
    data = load_json(output)
    if not isinstance(data, dict):
        raise WorldBuilderError("entry naming target must be a JSON object")
    normalized, changes = normalize_artifact_data(data, manifest if isinstance(manifest, dict) else None, terminology)
    atomic_write_json(output, normalized)
    after_sha = sha256_file(output)
    # Verify every visible label after writing.
    reopened = load_json(output)
    validate_artifact_labels(reopened)
    receipt = {
        "kind": RECEIPT_KIND,
        "receipt_version": 1,
        "contract": CONTRACT,
        "stage": "output",
        "status": "passed",
        "build_id": state.get("build_id"),
        "target": str(output.relative_to(root)).replace("\\", "/") if output.is_relative_to(root) else str(output),
        "before_sha256": before_sha,
        "after_sha256": after_sha,
        "manifest_sha256": sha256_file(manifest_path) if manifest_path and manifest_path.exists() else None,
        "terminology_dictionary_sha256": sha256_file(terminology_path) if terminology_path and terminology_path.exists() else None,
        "entry_count": sum(1 for _ in iter_entries(reopened)),
        "changed_entry_count": len(changes),
        "changes": changes,
    }
    if write_receipt:
        receipt_path = resolve_state_path(root, state, "entry_naming_output_receipt", required=False) or root / "artifacts" / "entry-naming-output-gate.json"
        atomic_write_json(receipt_path, receipt)
        state.setdefault("status", {})["entry_naming"] = "complete"
        state.setdefault("lineage", {})["entry_naming_output_receipt_sha256"] = sha256_file(receipt_path)
        state["lineage"]["entry_naming_output_sha256"] = after_sha
        atomic_write_json(Path(build_state).resolve(), state)
        receipt["receipt"] = str(receipt_path)
        receipt["receipt_sha256"] = sha256_file(receipt_path)
    return receipt


def validate_build_output(build_state: str | Path, target: str | Path | None = None) -> dict[str, Any]:
    root, state = load_build_state(build_state)
    output = Path(target).resolve() if target else resolve_state_path(root, state, "merge_input")
    receipt_path = resolve_state_path(root, state, "entry_naming_output_receipt", required=False) or root / "artifacts" / "entry-naming-output-gate.json"
    if not receipt_path.exists():
        raise WorldBuilderError("entry naming output receipt is missing")
    receipt = load_json(receipt_path)
    if not isinstance(receipt, dict) or receipt.get("kind") != RECEIPT_KIND or receipt.get("contract") != CONTRACT or receipt.get("status") != "passed":
        raise WorldBuilderError("entry naming output receipt has the wrong format")
    if receipt.get("build_id") != state.get("build_id") or receipt.get("after_sha256") != sha256_file(output):
        raise WorldBuilderError("entry naming output receipt is stale")
    terminology_path = resolve_state_path(root, state, "terminology_dictionary", required=False)
    expected_terminology_sha = receipt.get("terminology_dictionary_sha256")
    if expected_terminology_sha is not None:
        if not terminology_path or not terminology_path.exists() or sha256_file(terminology_path) != expected_terminology_sha:
            raise WorldBuilderError("entry naming output receipt is stale relative to the terminology dictionary")
    data = load_json(output)
    validate_artifact_labels(data)
    return receipt


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--build-state")
    parser.add_argument("--stage", choices=("planning", "normalize-output", "validate-output"))
    parser.add_argument("--target")
    parser.add_argument("--input")
    parser.add_argument("--output")
    parser.add_argument("--manifest")
    args = parser.parse_args()
    try:
        if args.build_state:
            if args.stage == "planning":
                result = validate_manifest_build(args.build_state)
            elif args.stage == "normalize-output":
                result = normalize_build_output(args.build_state, args.target)
            elif args.stage == "validate-output":
                result = validate_build_output(args.build_state, args.target)
            else:
                parser.error("--stage is required with --build-state")
        elif args.input:
            result = normalize_file(args.input, args.output, args.manifest)
        else:
            parser.error("use --build-state with --stage, or --input for a standalone legacy normalization")
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (WorldBuilderError, OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"ENTRY NAMING GATE BLOCKED: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
