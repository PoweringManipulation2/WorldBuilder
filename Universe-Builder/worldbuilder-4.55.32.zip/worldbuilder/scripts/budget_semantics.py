#!/usr/bin/env python3
"""Public shared budget/manifest semantics used across WorldBuilder modules.

These functions were promoted out of ``budget_contract.py`` so callers do not
reach through another module's underscore-prefixed implementation details.
Their behavior intentionally matches the historical helpers byte-for-byte at
the data-contract level; this module is organizational, not a policy change.
"""
from __future__ import annotations

from collections import defaultdict, deque
from typing import Any

from wb_common import WorldBuilderError, uid_key


def manifest_rows(manifest: dict[str, Any]) -> list[dict[str, Any]]:
    value = manifest.get("entries")
    if isinstance(value, list):
        return [row for row in value if isinstance(row, dict)]
    if isinstance(value, dict):
        return [row for row in value.values() if isinstance(row, dict)]
    return []


def emit_config(entry: dict[str, Any]) -> dict[str, Any]:
    value = entry.get("emit")
    return value if isinstance(value, dict) else {}


def activation_config(entry: dict[str, Any]) -> dict[str, Any]:
    value = entry.get("activation")
    return value if isinstance(value, dict) else {}


def entry_is_constant(entry: dict[str, Any]) -> bool:
    emit = emit_config(entry)
    return bool(emit.get("constant")) or str(activation_config(entry).get("strategy", "")).casefold() == "constant"


def entry_keys(entry: dict[str, Any]) -> list[str]:
    value = emit_config(entry).get("keys")
    return [str(item).strip().casefold() for item in value if str(item).strip()] if isinstance(value, list) else []


def required_edges(manifest: dict[str, Any]) -> tuple[list[dict[str, Any]], set[str]]:
    graph = manifest.get("activation_graph") if isinstance(manifest.get("activation_graph"), dict) else {}
    edges = [row for row in graph.get("edges", []) if isinstance(row, dict)]
    required: set[str] = set()
    for edge in edges:
        if edge.get("required"):
            required.add(uid_key(edge.get("source_uid")))
            required.add(uid_key(edge.get("target_uid")))
    return edges, required


def activation_closure(start: list[str], edges: list[dict[str, Any]], depth: int, *, include_optional: bool = True) -> list[str]:
    adjacency: dict[str, list[tuple[str, bool]]] = defaultdict(list)
    for edge in edges:
        adjacency[uid_key(edge.get("source_uid"))].append((uid_key(edge.get("target_uid")), bool(edge.get("required"))))
    seen = set(start)
    queue = deque((uid, 0) for uid in start)
    while queue:
        uid, level = queue.popleft()
        if level >= depth:
            continue
        for target, required in adjacency.get(uid, []):
            if not include_optional and not required:
                continue
            if target not in seen:
                seen.add(target)
                queue.append((target, level + 1))
    return sorted(seen)
