#!/usr/bin/env python3
"""Semantic preservation bias for WorldBuilder pruning review.

This module does not mutate artifacts and does not predict SillyTavern's
runtime drop order. It annotates already-eligible prune candidates with a
small, deterministic preservation adjustment derived from the frozen budget
plan and the exact activation sets produced by WorldBuilder's existing WCSA
simulations.
"""
from __future__ import annotations

from typing import Any, Iterable

from budget_semantics import manifest_rows
from wb_common import WorldBuilderError, uid_key

CONTRACT = "worldbuilder-pruning-objectives-v1"

# One point per active preservation objective is deliberately modest. These
# are soft review biases, not locks and not replacements for measured WCSA
# evidence. Multiple objectives may stack.
OBJECTIVE_DEFINITIONS: dict[str, dict[str, Any]] = {
    "preserve_factions": {
        "weight_adjustment": 1,
        "description": "Prefer pruning otherwise-comparable non-faction entries before faction/organization entries.",
    },
    "preserve_main_plot": {
        "weight_adjustment": 1,
        "description": "Prefer pruning otherwise-comparable entries before entries explicitly tagged as main plot.",
    },
}


def _canon(value: Any) -> str:
    return str(value or "").strip().casefold().replace("-", "_").replace(" ", "_")


def normalize_objectives(values: Iterable[Any] | None) -> list[str]:
    """Return a deterministic, duplicate-free list of supported objectives."""
    if values is None:
        return []
    if isinstance(values, (str, bytes)):
        values = [values]
    try:
        raw = list(values)
    except TypeError as exc:
        raise WorldBuilderError("pruning_objectives must be a list of named objectives") from exc
    names: list[str] = []
    seen: set[str] = set()
    for value in raw:
        name = _canon(value)
        if not name:
            raise WorldBuilderError("pruning objective names must be non-empty")
        if name not in OBJECTIVE_DEFINITIONS:
            raise WorldBuilderError(
                "unknown pruning objective %r; supported objectives are: %s"
                % (value, ", ".join(sorted(OBJECTIVE_DEFINITIONS)))
            )
        if name not in seen:
            names.append(name)
            seen.add(name)
    # Registry order is the stable plan order. Caller order never changes hashes.
    return [name for name in OBJECTIVE_DEFINITIONS if name in seen]


def objective_plan_rows(values: Iterable[Any] | None) -> list[dict[str, Any]]:
    return [
        {
            "name": name,
            "weight_adjustment": int(OBJECTIVE_DEFINITIONS[name]["weight_adjustment"]),
        }
        for name in normalize_objectives(values)
    ]


def validate_plan_rows(value: Any) -> list[str]:
    """Validate the frozen expanded budget-plan representation.

    Legacy plans may omit pruning_objectives entirely; callers pass [] in that
    case. The stored weight is verified against this code's named definition so
    an old plan cannot silently acquire a different preference strength.
    """
    if value is None:
        return []
    if not isinstance(value, list):
        raise WorldBuilderError("budget plan pruning_objectives must be a list")
    names: list[str] = []
    seen: set[str] = set()
    for row in value:
        if not isinstance(row, dict):
            raise WorldBuilderError("budget plan pruning_objectives rows must be objects")
        name = _canon(row.get("name"))
        if name not in OBJECTIVE_DEFINITIONS:
            raise WorldBuilderError(f"budget plan contains unsupported pruning objective {row.get('name')!r}")
        if name in seen:
            raise WorldBuilderError(f"budget plan repeats pruning objective {name!r}")
        expected = int(OBJECTIVE_DEFINITIONS[name]["weight_adjustment"])
        if row.get("weight_adjustment") != expected:
            raise WorldBuilderError(
                f"budget plan pruning objective {name!r} weight_adjustment must be {expected}, "
                f"found {row.get('weight_adjustment')!r}"
            )
        seen.add(name)
        names.append(name)
    expected_order = [name for name in OBJECTIVE_DEFINITIONS if name in seen]
    if names != expected_order:
        raise WorldBuilderError("budget plan pruning_objectives are not in canonical order")
    return names


def _entry_pruning_tags(entry: dict[str, Any]) -> set[str]:
    arch = entry.get("architecture") if isinstance(entry.get("architecture"), dict) else {}
    value = arch.get("pruning_tags")
    if value is None:
        return set()
    if not isinstance(value, list) or any(not isinstance(item, str) or not item.strip() for item in value):
        raise WorldBuilderError("architecture.pruning_tags must be a list of non-empty strings")
    return {_canon(item) for item in value}


def matching_objectives(entry: dict[str, Any], active_objectives: Iterable[Any] | None) -> list[str]:
    active = normalize_objectives(active_objectives)
    arch = entry.get("architecture") if isinstance(entry.get("architecture"), dict) else {}
    layer = _canon(arch.get("layer"))
    entry_type = _canon(entry.get("type"))
    tags = _entry_pruning_tags(entry)
    matched: list[str] = []
    for name in active:
        if name == "preserve_factions":
            if layer in {"faction", "organization"} or entry_type in {"faction", "organization"} or tags & {"faction", "factions"}:
                matched.append(name)
        elif name == "preserve_main_plot":
            # Deliberately explicit. A generic event is not necessarily part of
            # the main plot, so this objective never infers importance from type.
            if "main_plot" in tags:
                matched.append(name)
    return matched


def wcsa_cofire_score(uid: str, simulations: list[dict[str, Any]]) -> int:
    """Count exact co-fired peers across the already-computed WCSA simulations.

    This is an exposure count, not a projected token saving and not a runtime
    probability. Each simulation contributes the number of *other* UIDs active
    with this candidate when that UID participates in the simulation.
    """
    score = 0
    for simulation in simulations:
        activated = simulation.get("activated_uids")
        if not isinstance(activated, list):
            raise WorldBuilderError("WCSA simulation activated_uids must be a list before objective scoring")
        members = {uid_key(value) for value in activated}
        if uid in members:
            score += max(0, len(members) - 1)
    return score


def score_candidates(
    manifest: dict[str, Any],
    simulations: list[dict[str, Any]],
    candidate_strategies: dict[str, Iterable[str]],
    active_objectives: Iterable[Any] | None,
) -> dict[str, Any]:
    """Score only UIDs that survived the prune workflow's lock filters."""
    active = normalize_objectives(active_objectives)
    by_uid: dict[str, dict[str, Any]] = {}
    for row in manifest_rows(manifest):
        uid = uid_key(row.get("uid", row.get("id")))
        if uid in by_uid:
            raise WorldBuilderError(f"manifest repeats UID {uid} during pruning objective scoring")
        by_uid[uid] = row

    rows: list[dict[str, Any]] = []
    matched_by_objective = {name: 0 for name in active}
    for raw_uid, strategies in candidate_strategies.items():
        uid = uid_key(raw_uid)
        entry = by_uid.get(uid)
        if entry is None:
            raise WorldBuilderError(f"pruning candidate UID {uid} is missing from the manifest")
        matched = matching_objectives(entry, active)
        for name in matched:
            matched_by_objective[name] += 1
        adjustment = sum(int(OBJECTIVE_DEFINITIONS[name]["weight_adjustment"]) for name in matched)
        base = wcsa_cofire_score(uid, simulations)
        rows.append({
            "uid": uid,
            "eligible_strategies": sorted({str(value) for value in strategies}),
            "wcsa_cofire_score": base,
            "matched_objectives": matched,
            "objective_adjustment": adjustment,
            "adjusted_prune_score": base - adjustment,
        })

    rows.sort(key=lambda row: (-int(row["adjusted_prune_score"]), -int(row["wcsa_cofire_score"]), str(row["uid"])))
    return {
        "contract": CONTRACT,
        "active_objectives": objective_plan_rows(active),
        "rows": rows,
        "unmatched_objectives": [name for name, count in matched_by_objective.items() if count == 0],
        "note": (
            "Scores are advisory review ordering only. wcsa_cofire_score counts exact co-fired peers across the existing "
            "WCSA simulation activation sets; objective_adjustment is a soft preservation bias. Author locks are filtered "
            "before scoring, and these scores do not alter SillyTavern runtime drop order or fabricate projected savings."
        ),
    }
