#!/usr/bin/env python3
"""Shared helpers for WorldBuilder's deterministic scripts.

The module intentionally uses only the Python standard library so the skill can
run anywhere OpenClaw can provide Python 3.10+.
"""
from __future__ import annotations

import ast
import hashlib
import json
import math
import os
import re
import sys
import tempfile
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from typing import Any, Iterator


WORKER_BIRD_NAMES: tuple[str, ...] = (
    "Raven", "Magpie", "Wren", "Finch", "Sparrow",
    "Robin", "Heron", "Lark", "Swift", "Owl",
    "Hawk", "Falcon", "Crow", "Jay", "Kestrel",
)

AUDIT_LENSES: tuple[str, ...] = ("compass", "weaver", "scout", "warden")

def normalize_child_session_id(value: Any) -> str:
    """Normalize only the two documented OpenClaw child-session identity forms.

    A raw UUID-like child id and ``agent:<parent>:subagent:<id>`` refer to the
    same child. This is exact terminal-component normalization, never substring
    matching, so unrelated session ids cannot accidentally compare equal.
    """
    text = str(value or "").strip()
    marker = ":subagent:"
    if marker in text:
        prefix, suffix = text.rsplit(marker, 1)
        if prefix.startswith("agent:") and suffix and ":" not in suffix:
            return suffix
    return text

def _ensure_utf8_console() -> None:
    """Reconfigure stdout/stderr to UTF-8 so printed JSON and progress text
    (em dashes, arrows, curly quotes) never depend on a platform's default
    console codepage. Windows terminals default to cp1252/cp437, which raises
    UnicodeEncodeError on ordinary punctuation the moment it is not ASCII.
    ``errors="replace"`` degrades to a visible placeholder instead of crashing
    if the underlying stream still cannot represent something."""
    import sys as _sys
    for _stream in (_sys.stdout, _sys.stderr):
        _reconfigure = getattr(_stream, "reconfigure", None)
        if callable(_reconfigure):
            try:
                _reconfigure(encoding="utf-8", errors="replace")
            except (ValueError, OSError):
                pass


_ensure_utf8_console()


def worker_bird_name(index: int, round_number: int = 1) -> str:
    """Return a stable readable worker label.

    Names cycle only after the full bird pool is exhausted. Reused names receive
    a round suffix so logs and task cards remain distinguishable.
    """
    if index < 0:
        raise WorldBuilderError("worker index must be non-negative")
    if round_number < 1:
        raise WorldBuilderError("round number must be at least 1")
    cycle, offset = divmod(index, len(WORKER_BIRD_NAMES))
    effective_round = round_number + cycle
    base = WORKER_BIRD_NAMES[offset]
    return base if effective_round == 1 else f"{base} R{effective_round}"

def worker_slug(index: int, round_number: int = 1) -> str:
    return worker_bird_name(index, round_number).casefold().replace(" ", "-")

PHASE_RE = re.compile(r"^(?P<prefix>phase|group)-(?P<number>\d+)(?:-[A-Za-z0-9_.-]+)?\.json$", re.I)


def now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


class WorldBuilderError(ValueError):
    """Raised for a user-correctable WorldBuilder data or path problem."""


def raise_error(message: str) -> None:
    """Fail fast with one WorldBuilderError (the shared `_err` body, Batch 60)."""
    raise WorldBuilderError(message)


class ErrorCollector:
    """Collect independent validation problems, then report them together (Batch 60).

    A gate that fails on the first problem costs one repair round trip per
    problem. A collector accumulates every independent problem a single run
    can see, and `raise_if_any` preserves the pass/fail contract: any
    collected message still raises WorldBuilderError. Callers must skip
    dependent checks after a prerequisite failure and say so in the aggregate.
    """

    def __init__(self) -> None:
        self.messages: list[str] = []

    def add(self, message: str) -> None:
        self.messages.append(message)

    def raise_if_any(self) -> None:
        if self.messages:
            raise WorldBuilderError("\n".join(self.messages))


@dataclass(frozen=True)
class ArtifactInfo:
    kind: str
    schema: int | None
    container_path: str | None


@dataclass(frozen=True)
class EntryRef:
    path: str
    key: str | int
    entry: dict[str, Any]


def _decode_one_json(text: str, target: Path) -> Any:
    decoder = json.JSONDecoder()
    stripped = text.lstrip()
    try:
        value, end = decoder.raw_decode(stripped)
    except json.JSONDecodeError as exc:
        raise WorldBuilderError(f"invalid JSON in {target}: {exc}") from exc
    trailing = stripped[end:].strip()
    if trailing:
        try:
            decoder.raw_decode(trailing)
        except json.JSONDecodeError:
            kind = "non-whitespace trailing data"
        else:
            kind = "concatenated JSON values"
        raise WorldBuilderError(f"{target} contains {kind}; rewrite it as exactly one JSON value")
    return value


def load_json(path: str | os.PathLike[str]) -> Any:
    """Load imported/legacy JSON with UTF-8 BOM tolerance.

    Use :func:`load_json_strict` for any artifact that will be imported by a
    runtime such as SillyTavern. Its character import path calls ``JSON.parse``
    on the decoded text and does not discard a leading BOM.
    """
    target = Path(path)
    try:
        text = target.read_text(encoding="utf-8-sig")
    except UnicodeDecodeError as exc:
        raise WorldBuilderError(f"{target} is not valid UTF-8: {exc}") from exc
    return _decode_one_json(text, target)


def load_json_strict(path: str | os.PathLike[str]) -> Any:
    """Load one strict UTF-8 JSON value and reject a UTF-8 BOM.

    This deliberately mirrors JavaScript ``fs.readFileSync(path, 'utf8')``
    followed by ``JSON.parse`` as used by SillyTavern's JSON-card importer.
    """
    target = Path(path)
    raw = target.read_bytes()
    if raw.startswith(b"\xef\xbb\xbf"):
        raise WorldBuilderError(
            f"{target} begins with a UTF-8 BOM; SillyTavern JSON import treats this as corrupted"
        )
    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise WorldBuilderError(f"{target} is not valid UTF-8: {exc}") from exc
    if text.startswith("\ufeff"):
        raise WorldBuilderError(
            f"{target} begins with U+FEFF; SillyTavern JSON import treats this as corrupted"
        )
    return _decode_one_json(text, target)


# A computed liveness bound, never a model estimate (DR-064). safety_multiplier
# absorbs per-unit variance; fixed_slack_seconds covers setup/teardown that does
# not scale with unit count; floor_seconds is the minimum for any dispatch, since
# even a single-unit assignment needs room to research, write, and pass its gate.
TIMEOUT_SAFETY_MULTIPLIER = 3
TIMEOUT_FIXED_SLACK_SECONDS = 300
TIMEOUT_FLOOR_SECONDS = 900


def compute_run_timeout_seconds(
    unit_count: int,
    per_unit_seconds: float,
    *,
    safety_multiplier: float = TIMEOUT_SAFETY_MULTIPLIER,
    fixed_slack_seconds: int = TIMEOUT_FIXED_SLACK_SECONDS,
    floor_seconds: int = TIMEOUT_FLOOR_SECONDS,
) -> int:
    """run_timeout_seconds = per_unit_seconds * unit_count * safety_multiplier
    + fixed_slack_seconds, floored at floor_seconds.

    unit_count is whatever remains for the worker to do: remaining UIDs for a
    generation assignment, page count for a discovery assignment. Callers pass
    the count and per-unit estimate that fit their own unit of work; this
    function holds only the shared formula and its floor, so no caller can
    compute it differently.
    """
    computed = per_unit_seconds * max(0, unit_count) * safety_multiplier + fixed_slack_seconds
    return max(floor_seconds, int(math.ceil(computed)))


def sha256_file(path: str | os.PathLike[str]) -> str:
    h = hashlib.sha256()
    with Path(path).open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def atomic_write_text(path: str | os.PathLike[str], text: str) -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(prefix=f".{target.name}.", suffix=".tmp", dir=target.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as fh:
            fh.write(text)
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp_name, target)
    except Exception:
        try:
            os.unlink(tmp_name)
        except OSError:
            pass
        raise


def atomic_write_bytes(path: str | os.PathLike[str], data: bytes) -> None:
    """Binary counterpart to atomic_write_text; same temp-file/fsync/
    os.replace pattern, for content that is not text at all (PNG bytes,
    not JSON or UTF-8 prose)."""
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(prefix=f".{target.name}.", suffix=".tmp", dir=target.parent)
    try:
        with os.fdopen(fd, "wb") as fh:
            fh.write(data)
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp_name, target)
    except Exception:
        try:
            os.unlink(tmp_name)
        except OSError:
            pass
        raise


def atomic_write_json(path: str | os.PathLike[str], data: Any) -> None:
    atomic_write_text(path, json.dumps(data, ensure_ascii=False, indent=2) + "\n")


def detect_artifact(data: Any) -> ArtifactInfo:
    """Classify supported card/lorebook shapes without conflating CCv2 and CCv3."""
    if not isinstance(data, dict):
        return ArtifactInfo("unknown", None, None)

    spec = data.get("spec")
    payload = data.get("data")

    if spec == "chara_card_v3" and isinstance(payload, dict):
        if "character_book" in payload:
            book = payload.get("character_book")
            if isinstance(book, dict) and "entries" in book:
                return ArtifactInfo("card_v3_embedded", 2, "/data/character_book")
            # Presence still means an embedded-book card, but the validator will
            # report the malformed value instead of misclassifying it as Schema 1.
            return ArtifactInfo("card_v3_embedded", 2, "/data/character_book")
        return ArtifactInfo("card_v3", 1, None)

    if spec == "chara_card_v2" and isinstance(payload, dict):
        return ArtifactInfo("card_v2", None, None)

    if spec == "lorebook_v3" and isinstance(payload, dict):
        return ArtifactInfo("lorebook_v3", 3, "/data")

    # SillyTavern native World Info exports use a top-level entries collection.
    # Optional scan_depth/token_budget fields must not be used as discriminators.
    if "entries" in data and isinstance(data.get("entries"), (list, dict)):
        return ArtifactInfo("sillytavern_world_info", 3, "")

    return ArtifactInfo("unknown", None, None)


def get_lorebook_container(data: Any, info: ArtifactInfo | None = None) -> dict[str, Any] | None:
    info = info or detect_artifact(data)
    if not isinstance(data, dict):
        return None
    if info.kind == "card_v3_embedded":
        payload = data.get("data")
        return payload.get("character_book") if isinstance(payload, dict) and isinstance(payload.get("character_book"), dict) else None
    if info.kind == "lorebook_v3":
        return data.get("data") if isinstance(data.get("data"), dict) else None
    if info.kind == "sillytavern_world_info":
        return data
    return None


def iter_entries(data: Any) -> Iterator[EntryRef]:
    """Yield lorebook/manifest entries with stable JSON-pointer-like paths."""
    info = detect_artifact(data)
    container = get_lorebook_container(data, info)

    if container is None and isinstance(data, dict):
        # Manifests commonly use {"entries": ...}; a bare keyed mapping is also
        # accepted only when every value is an object.
        if isinstance(data.get("entries"), (list, dict)):
            container = data
            base = ""
        elif data and all(isinstance(v, dict) for v in data.values()):
            container = {"entries": data}
            base = ""
        else:
            return
    else:
        base = info.container_path or ""

    if not isinstance(container, dict):
        return
    entries = container.get("entries")
    if isinstance(entries, list):
        for i, entry in enumerate(entries):
            if isinstance(entry, dict):
                yield EntryRef(f"{base}/entries/{i}", i, entry)
    elif isinstance(entries, dict):
        for key, entry in entries.items():
            if isinstance(entry, dict):
                escaped = str(key).replace("~", "~0").replace("/", "~1")
                yield EntryRef(f"{base}/entries/{escaped}", key, entry)


def entry_identity_values(entry: dict[str, Any]) -> dict[str, Any]:
    values: dict[str, Any] = {}
    for key in ("uid", "id"):
        if key in entry and entry[key] is not None:
            values[key] = entry[key]
    ext = entry.get("extensions")
    if isinstance(ext, dict) and ext.get("uid") is not None:
        values["extensions.uid"] = ext["uid"]
    return values


def normalize_identity(value: Any) -> Any:
    if isinstance(value, bool):
        return value
    if isinstance(value, int):
        return value
    if isinstance(value, str):
        stripped = value.strip()
        if re.fullmatch(r"-?\d+", stripped):
            try:
                return int(stripped)
            except ValueError:
                pass
        return stripped
    return value


def uid_key(value: Any) -> str:
    """Strict entry identity for validation paths: an integer or non-empty
    string, canonicalized; anything else raises WorldBuilderError."""
    if isinstance(value, bool) or value is None:
        raise WorldBuilderError(f"entry UID cannot be boolean or null, found {value!r}")
    normalized = normalize_identity(value)
    if isinstance(normalized, int):
        return str(normalized)
    if isinstance(normalized, str) and normalized.strip():
        return normalized.strip()
    raise WorldBuilderError(
        f"entry UID must be an integer or non-empty string, found {value!r} ({type(value).__name__})"
    )


def uid_label(value: Any) -> str:
    """Lenient identity label for reporting, dashboards, and rendering: never
    raises and returns "" for anything unusable (null, boolean, blank)."""
    if isinstance(value, bool) or value is None:
        return ""
    normalized = normalize_identity(value)
    if isinstance(normalized, int):
        return str(normalized)
    if isinstance(normalized, str):
        return normalized
    return ""


def entry_uid(entry: dict[str, Any], *, strict: bool) -> str:
    """Read an entry's `uid`, fall back to `id`, then delegate to uid_key
    (strict=True) or uid_label (strict=False)."""
    value = entry.get("uid")
    if value is None:
        value = entry.get("id")
    return uid_key(value) if strict else uid_label(value)


def canonical_entry_identity(entry: dict[str, Any]) -> Any:
    values = entry_identity_values(entry)
    if not values:
        return None
    normalized = {name: normalize_identity(value) for name, value in values.items()}
    distinct = []
    for value in normalized.values():
        if value not in distinct:
            distinct.append(value)
    if len(distinct) > 1:
        raise WorldBuilderError(
            "entry identity mirrors disagree: "
            + ", ".join(f"{name}={value!r}" for name, value in normalized.items())
        )
    return distinct[0]


def count_entries(data_or_path: Any) -> int:
    data = load_json(data_or_path) if isinstance(data_or_path, (str, os.PathLike)) else data_or_path
    return sum(1 for _ in iter_entries(data))


def build_identity_index(data: Any) -> dict[Any, tuple[str, dict[str, Any]]]:
    """Every entry, keyed by its canonical identity. Raises on a duplicate
    identity rather than silently picking one; UID lookup becomes
    ambiguous the moment two entries share an identity, and that is a
    defect in the artifact, not something to resolve quietly. Shared by
    verify_patches.py and artifact_diff.py/artifact_edit.py (Batch 7);
    genuinely one primitive, not three independent implementations of
    "find an entry by its identity"."""
    index: dict[Any, tuple[str, dict[str, Any]]] = {}
    for ref in iter_entries(data):
        identity = canonical_entry_identity(ref.entry)
        if identity is None:
            continue
        if identity in index:
            raise WorldBuilderError(
                f"duplicate identity {identity!r} at {index[identity][0]} and {ref.path}; UID lookup is ambiguous"
            )
        index[identity] = (ref.path, ref.entry)
    return index


def phase_sort_key(path: Path) -> tuple[int, int, str]:
    match = PHASE_RE.match(path.name)
    if not match:
        raise WorldBuilderError(f"unsupported phase filename: {path.name}")
    prefix_rank = 0 if match.group("prefix").lower() == "phase" else 1
    return int(match.group("number")), prefix_rank, path.name.lower()


def discover_phase_files(directory: str | os.PathLike[str], allow_legacy_group: bool = True) -> list[Path]:
    root = Path(directory)
    candidates = list(root.glob("phase-*.json"))
    if allow_legacy_group:
        candidates += list(root.glob("group-*.json"))
    parsed: list[tuple[int, int, str, Path]] = []
    seen_numbers: dict[int, Path] = {}
    for path in candidates:
        try:
            number, rank, name = phase_sort_key(path)
        except WorldBuilderError:
            continue
        if number in seen_numbers:
            raise WorldBuilderError(
                f"duplicate phase number {number}: {seen_numbers[number].name} and {path.name}"
            )
        seen_numbers[number] = path
        parsed.append((number, rank, name, path))
    parsed.sort(key=lambda item: item[:3])
    return [item[3] for item in parsed]


def load_build_state(path: str | os.PathLike[str]) -> tuple[Path, dict[str, Any]]:
    state_path = Path(path).resolve()
    state = load_json(state_path)
    if not isinstance(state, dict):
        raise WorldBuilderError("build-state.json must contain a JSON object")
    if not isinstance(state.get("paths"), dict):
        raise WorldBuilderError("build-state.json is missing a paths object")
    root = state_path.parent
    return root, state


def resolve_state_path(root: Path, state: dict[str, Any], key: str, required: bool = True) -> Path | None:
    value = state.get("paths", {}).get(key)
    if value in (None, ""):
        if required:
            raise WorldBuilderError(f"build-state.json paths.{key} is missing")
        return None
    path = Path(os.path.expandvars(os.path.expanduser(str(value))))
    if not path.is_absolute():
        path = root / path
    path = path.resolve()
    # All build-state artifacts and scratch files must remain in the dedicated
    # per-build workspace. Only the explicit clean export destination may point
    # elsewhere, and delivery scripts must copy into it rather than work there.
    if key != "export_root":
        ensure_inside(path, root)
    return path


def safe_archive_path(path: str) -> str:
    """Validate a portable CHARX member path and return normalized POSIX form."""
    if "\\" in path:
        path = path.replace("\\", "/")
    pure = PurePosixPath(path)
    if pure.is_absolute() or not pure.parts:
        raise WorldBuilderError(f"archive path must be relative: {path!r}")
    reserved = {".", "..", ""}
    windows_reserved = {
        "con", "prn", "aux", "nul", *(f"com{i}" for i in range(1, 10)), *(f"lpt{i}" for i in range(1, 10))
    }
    for part in pure.parts:
        if part in reserved:
            raise WorldBuilderError(f"unsafe archive path component {part!r} in {path!r}")
        try:
            part.encode("ascii")
        except UnicodeEncodeError as exc:
            raise WorldBuilderError(f"non-ASCII archive path component {part!r} in {path!r}") from exc
        if any(ord(ch) < 32 for ch in part):
            raise WorldBuilderError(f"control character in archive path {path!r}")
        stem = part.rstrip(". ").split(".", 1)[0].lower()
        if stem in windows_reserved:
            raise WorldBuilderError(f"reserved archive path component {part!r} in {path!r}")
    return pure.as_posix()


def ensure_inside(child: Path, parent: Path) -> None:
    child = child.resolve()
    parent = parent.resolve()
    try:
        child.relative_to(parent)
    except ValueError as exc:
        raise WorldBuilderError(f"path {child} is outside allowed root {parent}") from exc


def step_driver_pointer() -> str:
    """Standard follow-up line for blocked gates: route the operator to the step driver."""
    from pathlib import Path as _P
    gate = _P(__file__).resolve().parent / "pipeline_stage_gate.py"
    return (f"[worldbuilder] Blocked? Get the exact next required command: "
            f"{sys.executable or 'python'} {gate} --build-state <your build-state.json> --next")


def entry_binding_hash(entry: Any) -> str:
    """Canonical per-entry hash for assignment slice bindings.

    Hashes the whole manifest entry under a stable serialization so any real
    change to an assigned entry invalidates exactly that assignment, while
    formatting-only or unrelated manifest changes invalidate nothing."""
    import hashlib as _hashlib
    payload = json.dumps(entry, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return _hashlib.sha256(payload.encode("utf-8")).hexdigest()


def collect_uid_entries(node: Any, into: dict[str, Any] | None = None) -> dict[str, Any]:
    """Recursively map str(uid) -> entry for every dict carrying an integer uid."""
    if into is None:
        into = {}
    if isinstance(node, dict):
        uid = node.get("uid")
        if isinstance(uid, int):
            into.setdefault(str(uid), node)
        for value in node.values():
            collect_uid_entries(value, into)
    elif isinstance(node, list):
        for value in node:
            collect_uid_entries(value, into)
    return into


def verify_workspace_root(assignment: dict[str, Any], root: Any) -> None:
    """Fail closed when an assignment was resolved from the wrong directory.

    Child working directories are not guaranteed by the runtime, so every
    assignment carries the absolute build root. A mismatch means the worker is
    operating on another project's files (the wrong-cwd failure class)."""
    from pathlib import Path as _P
    declared = assignment.get("workspace_root") or assignment.get("build_root")
    if not isinstance(declared, str) or not declared.strip():
        raise WorldBuilderError(
            "assignment has no absolute workspace_root. Re-stamp assignments with: "
            f"{sys.executable or 'python'} <skill>/scripts/phase_gate.py --build-state <your build-state.json> --stage pre-dispatch, "
            "and always dispatch workers with absolute paths in the task text."
        )
    if _P(declared).resolve() != _P(root).resolve():
        raise WorldBuilderError(
            f"assignment workspace_root {declared!r} does not match the actual build root {str(root)!r}. "
            "The worker resolved paths from the wrong working directory and may be reading another project's files. "
            "Stop, re-dispatch with absolute paths (never rely on the child working directory), and construct every "
            "path as <workspace_root>/..."
        )


REQUIREMENTS_KIND = "worldbuilder-gate-requirements"
REQUIREMENTS_CONTRACT = "worldbuilder-gate-requirements-v1"


def requirement_rows(source_file: str | Path, root: Path, state: dict[str, Any]) -> list[dict[str, Any]]:
    """Gate --requirements rows: each state key the gate resolves, with its
    resolved path and current presence. Parsed from source, so comments and
    docstrings can never contribute a row, and a gate edit that adds or drops
    a prerequisite surfaces here with no second list to maintain."""
    tree = ast.parse(Path(source_file).read_text(encoding="utf-8"))
    order: list[str] = []
    flags: dict[str, bool] = {}
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        func = node.func
        fname = func.attr if isinstance(func, ast.Attribute) else getattr(func, "id", None)
        if fname != "resolve_state_path":
            continue
        args = node.args
        if len(args) < 3:
            continue
        if not (isinstance(args[0], ast.Name) and args[0].id == "root"
                and isinstance(args[1], ast.Name) and args[1].id == "state"):
            continue
        if not (isinstance(args[2], ast.Constant) and isinstance(args[2].value, str)):
            continue
        key = args[2].value
        optional = any(
            kw.arg == "required" and isinstance(kw.value, ast.Constant) and kw.value.value is False
            for kw in node.keywords
        )
        if key not in flags:
            order.append(key)
            flags[key] = True
        flags[key] = flags[key] and not optional
    rows: list[dict[str, Any]] = []
    for key in order:
        row: dict[str, Any] = {"check": key, "required": flags[key]}
        try:
            path = resolve_state_path(root, state, key, required=False)
        except WorldBuilderError:
            path = None
        if path is None:
            row["path"] = "(not configured)"
            row["status"] = "not-configured"
        else:
            try:
                row["path"] = str(path.relative_to(root)).replace("\\", "/")
            except ValueError:
                row["path"] = str(path)
            row["status"] = "present" if path.exists() else "absent"
        rows.append(row)
    return rows


def preflight_report(gate: str, rows: list[dict[str, Any]], *, note: str = "") -> dict[str, Any]:
    """The single payload shape every gate --requirements preflight prints, so
    seventeen hand-written output formats cannot diverge. Read-only by
    construction: it renders rows; it never resolves or writes anything."""
    return {
        "kind": REQUIREMENTS_KIND,
        "contract": REQUIREMENTS_CONTRACT,
        "gate": gate,
        "requirements": rows,
        "note": note or (
            "Read-only preflight: exit 0 means the report rendered, not that the gate would pass. "
            "Run the gate itself for enforcement."
        ),
    }
