#!/usr/bin/env python3
"""Deterministic exec fallback for one breadth-discovery assignment."""
from __future__ import annotations
import argparse
import html
import json
import re
import sys
import urllib.parse
from html.parser import HTMLParser
from pathlib import Path
from typing import Any
from commit_worker_result import validate_candidate
from discovery_contract import DISCOVERY_RESULT_VERSION, canonicalize_url, contract_block
from discovery_page_filter import classify_fetch
from entity_taxonomy import normalize_entity
from facet_inference import facet_match_details, facet_matches
from wb_common import WorldBuilderError, atomic_write_json, load_json, sha256_file
from wiki_fetch import fetch_page, title_from_url

class TextExtractor(HTMLParser):
    def __init__(self) -> None:
        super().__init__(); self.parts: list[str] = []; self.skip = 0
    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag in {"script", "style", "noscript"}: self.skip += 1
    def handle_endtag(self, tag: str) -> None:
        if tag in {"script", "style", "noscript"} and self.skip: self.skip -= 1
    def handle_data(self, data: str) -> None:
        if not self.skip and data.strip(): self.parts.append(data.strip())

def lead_text(fetch: dict[str, Any]) -> str:
    rendered = fetch.get("rendered_html")
    if isinstance(rendered, str) and rendered:
        parser = TextExtractor()
        try:
            parser.feed(rendered)
            return re.sub(r"\s+", " ", html.unescape(" ".join(parser.parts)))[:4000]
        except Exception:
            pass
    wikitext = fetch.get("wikitext")
    if isinstance(wikitext, str):
        cleaned = re.sub(r"\{\{.*?\}\}", " ", wikitext, flags=re.S)
        cleaned = re.sub(r"\[\[(?:[^]|]+\|)?([^]]+)\]\]", r"\1", cleaned)
        cleaned = re.sub(r"<[^>]+>", " ", cleaned)
        return re.sub(r"\s+", " ", cleaned)[:4000]
    return ""

def category_names(fetch: dict[str, Any]) -> list[str]:
    result: list[str] = []
    for item in fetch.get("categories", []) if isinstance(fetch.get("categories"), list) else []:
        value = (item.get("category") or item.get("title") or item.get("name")) if isinstance(item, dict) else item
        if isinstance(value, str) and value.strip(): result.append(value.strip())
    return list(dict.fromkeys(result))


def link_urls(fetch: dict[str, Any], allowed_host: str, scheme: str = "https") -> list[str]:
    result: list[str] = []
    for item in fetch.get("links", []) if isinstance(fetch.get("links"), list) else []:
        if not isinstance(item, dict): continue
        namespace = item.get("ns"); title = item.get("title") or item.get("*")
        if namespace not in (None, 0) or not isinstance(title, str) or not title.strip(): continue
        path = "/wiki/" + urllib.parse.quote(title.replace(" ", "_"), safe="_()!,'-.")
        url = canonicalize_url(urllib.parse.urlunsplit((scheme, allowed_host, path, "", "")))
        if url and url not in result: result.append(url)
    return result

def low_value_exclusion(url: str) -> tuple[str, str] | None:
    lowered = urllib.parse.unquote(urllib.parse.urlsplit(url).path).casefold()
    if "/message_wall:" in lowered: return "message_wall", "Fandom Message Wall is user discussion, not an article"
    if re.search(r"/(?:user|user_talk|talk|forum|thread):", lowered): return "user_discussion", "user discussion namespace is not encyclopedic content"
    if re.search(r"/(?:special|help|mediawiki|template):", lowered): return "non_content_namespace", "MediaWiki maintenance namespace is not article content"
    if re.search(r"/(?:file|image):", lowered): return "gallery_or_media_only", "file or gallery page contains no standalone world entity"
    return None

def make_entity(url: str, fetched: dict[str, Any]) -> dict[str, Any]:
    requested = title_from_url(url); canonical = str(fetched.get("title") or requested).strip()
    display = re.sub(r"<[^>]+>", "", str(fetched.get("displaytitle") or "")).strip()
    aliases = [value for value in (requested, display) if value and value.casefold() != canonical.casefold()]
    return normalize_entity({
        "name": canonical, "type": "other", "aliases": list(dict.fromkeys(aliases)),
        "source_urls": [url], "categories": category_names(fetched), "lead": lead_text(fetched),
        "fetch_method": fetched.get("method"),
    })

def run(assignment_path: Path, timeout: float, retries: int) -> tuple[Path, dict[str, Any]]:
    assignment = load_json(assignment_path)
    if not isinstance(assignment, dict): raise WorldBuilderError("assignment must be a JSON object")
    workspace_root = assignment.get("workspace_root")
    if not isinstance(workspace_root, str) or not workspace_root.strip():
        raise WorldBuilderError("assignment has no absolute workspace_root; re-dispatch with absolute paths")
    _bs = Path(workspace_root) / "build-state.json"
    if not _bs.exists():
        raise WorldBuilderError(f"workspace_root {workspace_root!r} has no build-state.json: the worker resolved another project's directory; stop and re-dispatch with absolute paths")
    _bs_data = load_json(_bs)
    if not isinstance(_bs_data, dict) or _bs_data.get("build_id") != assignment.get("build_id"):
        raise WorldBuilderError(f"workspace_root {workspace_root!r} belongs to build {_bs_data.get('build_id')!r}, not this assignment's {assignment.get('build_id')!r}: wrong project directory; stop and re-dispatch with absolute paths")
    policy = assignment.get("fetch_policy")
    if not isinstance(policy, dict): raise WorldBuilderError("assignment.fetch_policy is missing")
    api_url = policy.get("api_url") if isinstance(policy.get("api_url"), str) else None
    allowed_host = str(policy.get("allowed_host") or "").casefold()
    if not allowed_host: raise WorldBuilderError("assignment.fetch_policy.allowed_host is missing")
    output_value = assignment.get("output_abs") or assignment.get("output")
    if not isinstance(output_value, str): raise WorldBuilderError("assignment has no output path")
    output = Path(output_value)
    if not output.is_absolute(): output = Path(str(assignment.get("workspace_root"))) / output
    output = output.resolve()
    visited: list[str] = []; failed: list[str] = []; excluded: list[dict[str, str]] = []
    records: list[dict[str, Any]] = []; discovered: list[str] = []; entities: list[dict[str, Any]] = []
    first_url = next(iter(assignment.get("page_urls", [])), "https://x")
    scheme = urllib.parse.urlsplit(str(first_url)).scheme or "https"
    for raw in assignment.get("page_urls", []):
        url = canonicalize_url(raw)
        if not url: raise WorldBuilderError(f"assignment contains invalid URL {raw!r}")
        parsed = urllib.parse.urlsplit(url)
        if parsed.netloc.casefold() != allowed_host:
            excluded.append({"url": url, "code": "out_of_scope_language", "reason": "URL host is outside assignment fetch policy"})
            records.append({"url": url, "status": "excluded", "method": None, "reason_code": "out_of_scope_language"}); continue
        trivial = low_value_exclusion(url)
        if trivial:
            code, reason = trivial; excluded.append({"url": url, "code": code, "reason": reason})
            records.append({"url": url, "status": "excluded", "method": None, "reason_code": code}); continue
        try:
            fetched = fetch_page(url, api_url, timeout, retries)
            policy_value = policy.get("content_filter_policy") if isinstance(policy.get("content_filter_policy"), dict) else None
            page_decision = classify_fetch(fetched, url, policy_value)
            page_links = link_urls(fetched, allowed_host, scheme)
            for link in page_links:
                if link not in discovered:
                    discovered.append(link)
            classification = page_decision.get("classification")
            facet_detail = facet_match_details(fetched, assignment.get("facet_filter"))
            if classification not in {"index_only", "reference_only", "excluded"} and not facet_detail["matched"]:
                cats = category_names(fetched)
                templates = [row for row in fetched.get("templates", [])] if isinstance(fetched.get("templates"), list) else []
                excluded.append({"url": url, "code": "facet_filter_mismatch", "reason": "page categories/templates do not match the user-confirmed source facet"})
                records.append({
                    "url": url, "status": "excluded", "method": fetched.get("method"),
                    "title": fetched.get("title"), "pageid": fetched.get("pageid"), "revid": fetched.get("revid"),
                    "filter_classification": "facet_filtered", "reason_code": "facet_filter_mismatch",
                    "categories": cats, "templates": templates, "harvested_link_count": len(page_links),
                })
                continue
            if classification in {"index_only", "reference_only", "excluded"}:
                code = str(page_decision.get("code") or "maintenance_page")
                reason = str(page_decision.get("reason") or "page was filtered before entity extraction")
                excluded.append({"url": url, "code": code, "reason": reason})
                records.append({
                    "url": url, "status": "excluded", "method": fetched.get("method"),
                    "title": fetched.get("title"), "pageid": fetched.get("pageid"), "revid": fetched.get("revid"),
                    "filter_classification": classification, "reason_code": code,
                    "harvested_link_count": len(page_links),
                })
                continue
            # Redirect aliases that escape the prefilter still ground their
            # canonical target and preserve the requested title as an alias.
            visited.append(url)
            records.append({
                "url": url, "status": "visited", "method": fetched.get("method"),
                "title": fetched.get("title"), "pageid": fetched.get("pageid"), "revid": fetched.get("revid"),
                "filter_classification": classification or "content",
                "facet_match": {"categories": facet_detail["categories"], "templates": facet_detail["templates"]}
                if isinstance(assignment.get("facet_filter"), dict) else None,
            })
            entities.append(make_entity(url, fetched))
        except Exception as exc:
            failed.append(url); records.append({"url": url, "status": "failed", "method": None, "error": str(exc)[:1000]})
    result = {
        "_worldbuilder": {
            "kind": "breadth-discovery", "result_version": DISCOVERY_RESULT_VERSION,
            "build_id": assignment.get("build_id"), "assignment_id": assignment.get("assignment_id"),
            "assignment_sha256": sha256_file(assignment_path), "corpus_sha256": assignment.get("corpus_sha256"),
            "worker": assignment.get("worker"), "taskName": assignment.get("taskName"), "pass_number": assignment.get("pass_number"),
            "completed": True, "runtime_status": "completed", "end_delimiter": assignment.get("expected_end_delimiter"),
            "contract": contract_block((assignment.get("contract") or {}).get("worker_kit_sha256")),
            "execution_backend": "deterministic_exec_fallback",
        },
        "visited_urls": visited, "failed_urls": failed, "excluded_urls": excluded, "delegated_urls": [],
        "discovered_urls": discovered, "fetch_records": records, "entities": entities,
        "covered_scope": [f"deterministic API-first recovery for {len(assignment.get('page_urls', []))} owned URL(s)"],
        "no_results": not bool(entities),
    }
    validated = validate_candidate(assignment, result, assignment_path)
    atomic_write_json(output, validated)
    return output, validated

def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--assignment", required=True); parser.add_argument("--timeout", type=float, default=25.0); parser.add_argument("--retries", type=int, default=2)
    args = parser.parse_args()
    try:
        output, result = run(Path(args.assignment).resolve(), args.timeout, args.retries)
        print(json.dumps({"status": "completed", "output": str(output), "output_sha256": sha256_file(output), "visited": len(result["visited_urls"]), "failed": len(result["failed_urls"]), "excluded": len(result["excluded_urls"]), "entities": len(result["entities"])}, indent=2))
        print(result["_worldbuilder"]["end_delimiter"]); return 0
    except (WorldBuilderError, OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr); return 1
if __name__ == "__main__": raise SystemExit(main())
