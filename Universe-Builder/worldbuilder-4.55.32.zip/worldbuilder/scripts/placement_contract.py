#!/usr/bin/env python3
"""Freeze and validate WorldBuilder placement and influence architecture.

The manifest remains authoritative for emitted entry fields. The placement plan
freezes purpose-based defaults, allowed deviations, and target compatibility.
The gate resolves sparse manifest settings through the frozen default profile,
then validates planning and emitted output against one semantic placement model.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any

from wb_common import (
    WorldBuilderError,
    atomic_write_json,
    canonical_entry_identity,
    iter_entries,
    load_build_state,
    load_json,
    preflight_report,
    requirement_rows,
    resolve_state_path,
    sha256_file,
)
from budget_contract import protected_categories as budget_protected_categories
from placement_semantics import (
    ALLOWED_ROLES,
    POSITION_ALIASES,
    PROTECTED_ENTRY_WEIGHT,
    STANDARD_ENTRY_WEIGHT,
    emit_config as _emit,
    extension_config as _extensions,
    first_value as _first,
    normalize_position as _normalize_position,
    placement_values as _placement_values,
    profile_defaults as _profile_defaults,
    setting as _setting,
    uid_key as _uid,
)
from budget_semantics import required_edges as budget_required_edges

CONTRACT = "worldbuilder-placement-influence-v1"

# Batch 5, 5.5. SillyTavern sorts activated entries by weight desc, then order
# desc, then uid asc, before dropping anything that doesn't fit the runtime
# budget (verified against the engine's own docs). WorldBuilder did not
# previously set this field at all, meaning protection depended on winning
# a tie on the *secondary* key, by accident, never verified. These are
# WorldBuilder-assigned values, not a claim about SillyTavern's own default
# for an entry that never sets weight; the separation (10x) is what matters,
# not the absolute numbers, since WorldBuilder now sets this on every entry
# it emits and nothing is left to an unstated default.
PLAN_KIND = "worldbuilder-placement-plan"
PLAN_VERSION = 1
RECEIPT_KIND = "worldbuilder-placement-gate"
RECEIPT_VERSION = 1

SEMANTIC_POSITIONS = {
    "before_char",
    "after_char",
    "before_examples",
    "after_examples",
    "authors_note_top",
    "authors_note_bottom",
    "depth",
    "outlet",
}
EXTENDED_POSITIONS = SEMANTIC_POSITIONS - {"before_char", "after_char"}


PURPOSE_POLICIES: dict[str, dict[str, Any]] = {
    "default": {
        "purpose": "contextual_lore",
        "influence_class": "contextual",
        "allowed_positions": ["before_char", "after_char"],
        "recommended_position": "after_char",
    },
    "world_index": {
        "purpose": "world_inventory_routing",
        "influence_class": "routing",
        "allowed_positions": ["before_char"],
        "recommended_position": "before_char",
        "requires_constant": True,
    },
    "world_core": {
        "purpose": "stable_world_foundation",
        "influence_class": "foundational",
        "allowed_positions": ["before_char"],
        "recommended_position": "before_char",
        "requires_constant": True,
    },
    "world_invariants": {
        "purpose": "cross_era_world_foundation",
        "influence_class": "foundational",
        "allowed_positions": ["before_char"],
        "recommended_position": "before_char",
        "requires_constant": True,
    },
    "era_context": {
        "purpose": "authoritative_temporal_context",
        "influence_class": "foundational_temporal",
        "allowed_positions": ["before_char"],
        "recommended_position": "before_char",
        "forbids_constant": True,
    },
    "anchor": {
        "purpose": "retrieval_and_recursion_anchor",
        "influence_class": "routing",
        "allowed_positions": ["before_char", "after_char"],
        "recommended_position": "after_char",
    },
    "character": {
        "purpose": "character_identity_behavior_and_state",
        "influence_class": "behavioral",
        "allowed_positions": ["after_char"],
        "recommended_position": "after_char",
    },
    "relationship": {
        "purpose": "relationship_state_and_behavior",
        "influence_class": "behavioral",
        "allowed_positions": ["after_char"],
        "recommended_position": "after_char",
    },
    "location": {
        "purpose": "scene_and_place_context",
        "influence_class": "contextual",
        "allowed_positions": ["before_char", "after_char"],
        "recommended_position": "after_char",
    },
    "faction": {
        "purpose": "organization_and_membership_context",
        "influence_class": "contextual",
        "allowed_positions": ["before_char", "after_char"],
        "recommended_position": "after_char",
    },
    "organization": {
        "purpose": "organization_and_membership_context",
        "influence_class": "contextual",
        "allowed_positions": ["before_char", "after_char"],
        "recommended_position": "after_char",
    },
    "event": {
        "purpose": "chronology_and_event_context",
        "influence_class": "contextual",
        "allowed_positions": ["before_char", "after_char"],
        "recommended_position": "after_char",
    },
    "scene_reminder": {
        "purpose": "immediate_scene_state",
        "influence_class": "immediate",
        "allowed_positions": ["depth", "authors_note_top", "authors_note_bottom"],
        "recommended_position": "depth",
        "recommended_depth": 2,
        "recommended_role": "system",
    },
    "correction": {
        "purpose": "high_priority_runtime_correction",
        "influence_class": "corrective",
        "allowed_positions": ["depth", "authors_note_top", "authors_note_bottom"],
        "recommended_position": "depth",
        "recommended_depth": 1,
        "recommended_role": "system",
    },
    "dialogue_example": {
        "purpose": "dialogue_demonstration",
        "influence_class": "demonstrative",
        "allowed_positions": ["before_examples", "after_examples"],
        "recommended_position": "after_examples",
    },
    "outlet_module": {
        "purpose": "prompt_manager_module",
        "influence_class": "modular",
        "allowed_positions": ["outlet"],
        "recommended_position": "outlet",
    },
}

POSITION_WEIGHTS = {
    "before_char": 35,
    "after_char": 45,
    "before_examples": 52,
    "after_examples": 58,
    "authors_note_top": 72,
    "authors_note_bottom": 78,
    "depth": 88,
    "outlet": 0,
}


















def _layer_policy(plan: dict[str, Any], layer: str) -> dict[str, Any]:
    policies = plan.get("layer_policies")
    if not isinstance(policies, dict):
        raise WorldBuilderError("placement plan layer_policies must be an object")
    base = policies.get("default")
    if not isinstance(base, dict):
        raise WorldBuilderError("placement plan requires a default layer policy")
    result = dict(base)
    if isinstance(policies.get(layer), dict):
        result.update(policies[layer])
    return result


def _compatibility(position: str | None, artifact_type: str, schema: int | None) -> tuple[str, str | None]:
    if position is None:
        return "unset", None
    if position in {"before_char", "after_char"}:
        return "core", None
    if artifact_type in {"world", "card", "group", "lorebook"} and schema in {2, 3}:
        return "extension_mapped", f"{position} requires a tested SillyTavern extension/native mapping"
    return "unsupported", f"{position} is not portable to the selected target"


def _influence_score(values: dict[str, Any], recursion_role: str) -> int:
    score = POSITION_WEIGHTS.get(values.get("position"), 0)
    order = values.get("insertion_order")
    if isinstance(order, int):
        score += max(-20, min(30, order // 10))
    priority = values.get("priority")
    if isinstance(priority, int):
        score += max(-15, min(20, priority // 10))
    if values.get("constant"):
        score += 10
    if recursion_role in {"root", "seed"}:
        score += 5
    return score


def build_plan(
    *,
    build_id: str,
    artifact_type: str,
    schema: int | None,
    policy: str,
    profile_id: str,
    default_profile_sha256: str,
    custom_overrides: dict[str, Any] | None = None,
) -> dict[str, Any]:
    policy = str(policy).strip().casefold()
    if policy not in {"automatic", "review", "custom"}:
        raise WorldBuilderError("placement policy must be automatic, review, or custom")
    custom_overrides = custom_overrides or {}
    if not isinstance(custom_overrides, dict):
        raise WorldBuilderError("custom placement overrides must be an object")
    entry_overrides = custom_overrides.get("entry_overrides", {})
    layer_overrides = custom_overrides.get("layer_overrides", {})
    outlet_consumers = custom_overrides.get("outlet_consumers", [])
    if not isinstance(entry_overrides, dict) or not isinstance(layer_overrides, dict):
        raise WorldBuilderError("placement entry_overrides and layer_overrides must be objects")
    if not isinstance(outlet_consumers, list) or any(not isinstance(item, str) or not item.strip() for item in outlet_consumers):
        raise WorldBuilderError("placement outlet_consumers must be an array of non-empty strings")
    if policy != "custom" and (entry_overrides or layer_overrides or outlet_consumers):
        raise WorldBuilderError("placement overrides require custom policy")
    layer_policies = {key: dict(value) for key, value in PURPOSE_POLICIES.items()}
    for layer, override in layer_overrides.items():
        if not isinstance(layer, str) or not layer.strip() or not isinstance(override, dict):
            raise WorldBuilderError("custom layer placement overrides require non-empty layer names and objects")
        layer_policies.setdefault(layer, dict(layer_policies["default"])).update(override)
    plan = {
        "kind": PLAN_KIND,
        "plan_version": PLAN_VERSION,
        "contract": CONTRACT,
        "build_id": build_id,
        "artifact_type": artifact_type,
        "schema": schema,
        "policy": policy,
        "profile_id": profile_id,
        "default_profile_sha256": default_profile_sha256,
        "blank_semantics": {
            "blank": "inherit the frozen default-profile value",
            "none": "explicitly disabled",
            "unsupported": "not representable by the selected runtime target",
        },
        "supported_positions": sorted(SEMANTIC_POSITIONS),
        "influence_factors": [
            "position",
            "insertion_order",
            "priority",
            "constant_status",
            "direct_or_recursive_activation",
            "depth_and_role",
        ],
        "layer_policies": layer_policies,
        "entry_overrides": entry_overrides,
        "outlet_consumers": sorted({item.strip() for item in outlet_consumers}),
        "validation": {
            "require_all_manifest_uids": True,
            "require_override_reason": True,
            "forbid_constant_depth_or_outlet": True,
            "require_root_before_char": True,
            "require_era_context_before_char": True,
            "require_depth_role": True,
            "require_outlet_consumer": True,
        },
    }
    validate_plan(plan, expected_build_id=build_id, expected_profile_sha256=default_profile_sha256)
    return plan


def validate_plan(
    plan: dict[str, Any],
    *,
    expected_build_id: str | None = None,
    expected_profile_sha256: str | None = None,
) -> None:
    if not isinstance(plan, dict) or plan.get("kind") != PLAN_KIND or plan.get("plan_version") != PLAN_VERSION:
        raise WorldBuilderError("placement plan has the wrong kind/version")
    if plan.get("contract") != CONTRACT:
        raise WorldBuilderError(f"placement plan contract must be {CONTRACT}")
    if expected_build_id is not None and plan.get("build_id") != expected_build_id:
        raise WorldBuilderError("placement plan belongs to another build")
    if expected_profile_sha256 is not None and plan.get("default_profile_sha256") != expected_profile_sha256:
        raise WorldBuilderError("placement plan is stale for the frozen default profile")
    if plan.get("policy") not in {"automatic", "review", "custom"}:
        raise WorldBuilderError("placement plan has an invalid policy")
    supported = plan.get("supported_positions")
    if not isinstance(supported, list) or set(supported) != SEMANTIC_POSITIONS:
        raise WorldBuilderError("placement plan supported_positions are incomplete")
    if not isinstance(plan.get("layer_policies"), dict) or "default" not in plan["layer_policies"]:
        raise WorldBuilderError("placement plan lacks layer policies")
    entry_overrides = plan.get("entry_overrides")
    if not isinstance(entry_overrides, dict):
        raise WorldBuilderError("placement plan entry_overrides must be an object")
    for key, override in entry_overrides.items():
        if not isinstance(key, str) or not key.strip() or not isinstance(override, dict):
            raise WorldBuilderError("placement entry overrides must map UIDs to objects")
        reason = override.get("reason")
        if not isinstance(reason, str) or not reason.strip():
            raise WorldBuilderError(f"placement override {key!r} requires a reason")
        if "position" in override:
            _normalize_position(override["position"])
    if plan.get("policy") != "custom" and entry_overrides:
        raise WorldBuilderError("non-custom placement plan cannot contain entry overrides")


def load_bound_plan(
    root: Path,
    state: dict[str, Any],
    manifest: dict[str, Any],
    *,
    required: bool,
) -> tuple[dict[str, Any] | None, Path | None, dict[str, Any] | None]:
    path = resolve_state_path(root, state, "placement_plan", required=False)
    state_contract = str(state.get("content_architecture", {}).get("placement_contract", ""))
    expected = manifest.get("placement_plan_sha256")
    arch = manifest.get("architecture") if isinstance(manifest.get("architecture"), dict) else {}
    binding = arch.get("placement") if isinstance(arch, dict) else None
    bound = isinstance(expected, str) and isinstance(binding, dict)
    if not bound:
        if required:
            raise WorldBuilderError("manifest is not bound to the frozen placement plan")
        return None, path if path and path.exists() else None, None
    if path is None or not path.exists():
        raise WorldBuilderError("placement plan is missing")
    profile_path = resolve_state_path(root, state, "default_profile")
    profile_sha = sha256_file(profile_path)
    plan = load_json(path)
    if not isinstance(plan, dict):
        raise WorldBuilderError("placement plan must be an object")
    validate_plan(plan, expected_build_id=str(state.get("build_id", "")), expected_profile_sha256=profile_sha)
    if state_contract and state_contract != CONTRACT:
        raise WorldBuilderError("build-state placement contract is unsupported")
    if expected != sha256_file(path):
        raise WorldBuilderError("manifest placement plan hash is stale")
    if binding.get("contract") != CONTRACT or binding.get("plan_sha256") != expected:
        raise WorldBuilderError("manifest architecture.placement binding is missing or stale")
    profile = load_json(profile_path)
    if not isinstance(profile, dict):
        raise WorldBuilderError("default profile must be an object")
    return plan, path, profile


def _entry_override(plan: dict[str, Any], uid: str) -> dict[str, Any] | None:
    value = plan.get("entry_overrides", {}).get(uid)
    return value if isinstance(value, dict) else None


def validate_manifest(
    plan: dict[str, Any],
    manifest: dict[str, Any],
    profile: dict[str, Any],
) -> dict[str, Any]:
    entries = manifest.get("entries")
    if not isinstance(entries, list) or not entries:
        raise WorldBuilderError("placement validation requires non-empty manifest entries")
    graph = manifest.get("activation_graph") if isinstance(manifest.get("activation_graph"), dict) else {}
    edges = graph.get("edges") if isinstance(graph.get("edges"), list) else []
    _, required_edge_uids = budget_required_edges(manifest)
    incoming: dict[str, int] = {}
    for edge in edges:
        if isinstance(edge, dict):
            target = _uid(edge.get("target_uid"))
            incoming[target] = incoming.get(target, 0) + 1
    rows: list[dict[str, Any]] = []
    warnings: list[str] = []
    roots: list[dict[str, Any]] = []
    indexes: list[dict[str, Any]] = []
    index_era_ids: dict[str, list[str]] = {}
    era_contexts: list[dict[str, Any]] = []
    seen: set[str] = set()
    artifact_type = str(plan.get("artifact_type", ""))
    schema = plan.get("schema") if isinstance(plan.get("schema"), int) else None
    outlet_consumers = {str(item).strip() for item in plan.get("outlet_consumers", [])}

    for entry in entries:
        if not isinstance(entry, dict):
            raise WorldBuilderError("manifest placement entry must be an object")
        uid = _uid(entry.get("uid", entry.get("id")))
        if uid in seen:
            raise WorldBuilderError(f"placement plan repeats manifest UID {uid}")
        seen.add(uid)
        arch = entry.get("architecture")
        if not isinstance(arch, dict):
            raise WorldBuilderError(f"manifest entry {uid} lacks architecture")
        layer = str(arch.get("layer", "")).strip()
        activation = entry.get("activation") if isinstance(entry.get("activation"), dict) else {}
        recursion_role = str(activation.get("recursion_role", "leaf"))
        if activation.get("strategy") == "manual" and not isinstance(entry.get("emit"), dict):
            rows.append({
                "uid": entry.get("uid", entry.get("id")),
                "name": str(entry.get("name", "")).strip(),
                "layer": layer,
                "purpose": "card_field_routing",
                "influence_class": "card_shell",
                "position": None,
                "insertion_order": None,
                "priority": None,
                "depth": None,
                "role": None,
                "outlet": None,
                "constant": False,
                "weight": None,
                "protected_categories": [],
                "activation_path": "manual_card_field",
                "incoming_edges": incoming.get(uid, 0),
                "influence_score": 0,
                "target_mapping": "not_applicable",
                "override": False,
            })
            continue
        values = _placement_values(entry, profile, required_edge_uids)
        policy = _layer_policy(plan, layer)
        override = _entry_override(plan, uid)
        if override:
            for field in ("position", "insertion_order", "priority", "depth", "role", "outlet"):
                if field in override:
                    expected = _normalize_position(override[field]) if field == "position" else override[field]
                    if values[field] != expected:
                        raise WorldBuilderError(f"entry {uid} does not match approved placement override {field}")
        allowed = {_normalize_position(item) for item in policy.get("allowed_positions", [])}
        if values["position"] not in allowed:
            raise WorldBuilderError(
                f"entry {uid} layer {layer!r} uses {values['position']!r}; allowed placement is {sorted(item for item in allowed if item)}"
            )
        recommended = _normalize_position(policy.get("recommended_position"))
        if values["position"] != recommended and not override:
            placement_note = arch.get("placement_override")
            if not isinstance(placement_note, dict) or not isinstance(placement_note.get("reason"), str) or not placement_note["reason"].strip():
                raise WorldBuilderError(f"entry {uid} deviates from recommended placement without architecture.placement_override.reason")
        # Batch 61: an era index is token-gated by design (world_index owns
        # that shape), so the constant requirement applies to the single-era
        # index only.
        era_index = layer == "world_index" and len(arch.get("era_ids") or []) == 1
        if policy.get("requires_constant") and not values["constant"] and not era_index:
            raise WorldBuilderError(f"entry {uid} layer {layer!r} must remain constant")
        if policy.get("forbids_constant") and values["constant"]:
            raise WorldBuilderError(f"entry {uid} layer {layer!r} must not be constant")
        if values["constant"] and values["position"] in {"depth", "outlet"}:
            raise WorldBuilderError(f"constant entry {uid} cannot use depth or outlet placement")
        if values["position"] == "depth":
            if values["depth"] is None or values["role"] is None:
                raise WorldBuilderError(f"depth-placed entry {uid} requires depth and role")
            recommended_depth = policy.get("recommended_depth")
            recommended_role = policy.get("recommended_role")
            if not override and recommended_depth is not None and values["depth"] != recommended_depth:
                raise WorldBuilderError(f"depth-placed entry {uid} does not use the layer's recommended depth")
            if not override and recommended_role is not None and values["role"] != recommended_role:
                raise WorldBuilderError(f"depth-placed entry {uid} does not use the layer's recommended role")
        elif values["depth"] is not None or values["role"] is not None:
            raise WorldBuilderError(f"entry {uid} has depth/role settings without depth placement")
        if values["position"] == "outlet":
            if not values["outlet"]:
                raise WorldBuilderError(f"outlet-placed entry {uid} requires an outlet name")
            if values["outlet"] not in outlet_consumers:
                raise WorldBuilderError(f"outlet-placed entry {uid} has no approved outlet consumer")
        elif values["outlet"] is not None:
            raise WorldBuilderError(f"entry {uid} defines an outlet without outlet placement")
        compatibility, warning = _compatibility(values["position"], artifact_type, schema)
        if compatibility == "unsupported":
            raise WorldBuilderError(f"entry {uid} uses unsupported placement for the selected target: {warning}")
        if warning:
            warnings.append(f"UID {uid}: {warning}")
        row = {
            "uid": entry.get("uid", entry.get("id")),
            "name": str(entry.get("name", "")).strip(),
            "layer": layer,
            "purpose": str(policy.get("purpose", "contextual_lore")),
            "influence_class": str(policy.get("influence_class", "contextual")),
            "position": values["position"],
            "insertion_order": values["insertion_order"],
            "priority": values["priority"],
            "depth": values["depth"],
            "role": values["role"],
            "outlet": values["outlet"],
            "constant": values["constant"],
            "weight": values["weight"],
            "protected_categories": values["protected_categories"],
            "activation_path": "recursive_possible" if incoming.get(uid, 0) else "direct_or_constant",
            "incoming_edges": incoming.get(uid, 0),
            "influence_score": _influence_score(values, recursion_role),
            "target_mapping": compatibility,
            "override": bool(override or arch.get("placement_override")),
        }
        rows.append(row)
        if layer in {"world_core", "world_invariants"}:
            roots.append(row)
        if layer == "world_index":
            indexes.append(row)
            index_era_ids[str(row["uid"])] = [str(value) for value in (arch.get("era_ids") or [])]
        if layer == "era_context":
            era_contexts.append(row)

    if len(roots) > 1:
        raise WorldBuilderError("placement architecture permits at most one world root")
    # Batch 61: the index cap is per era. A multi-era build carries one index
    # per era (DR-129); only an index with no single era id competes for the
    # one unscoped slot a single-era build has.
    per_era_index: dict[str, list[str]] = {}
    unscoped_index: list[str] = []
    for row in indexes:
        uid = str(row["uid"])
        eras = index_era_ids.get(uid, [])
        if len(eras) == 1:
            per_era_index.setdefault(eras[0], []).append(uid)
        else:
            unscoped_index.append(uid)
    for era_id, uids in sorted(per_era_index.items()):
        if len(uids) > 1:
            raise WorldBuilderError(
                f"placement architecture permits at most one world index per era; era {era_id} has {len(uids)}: "
                + ", ".join(uids)
            )
    if len(unscoped_index) > 1:
        raise WorldBuilderError(
            "placement architecture permits at most one unscoped world index, found " + ", ".join(unscoped_index)
        )
    for row in indexes:
        if row["position"] != "before_char":
            raise WorldBuilderError("world index must insert before character definitions")
    if roots and roots[0]["position"] != "before_char":
        raise WorldBuilderError("world root must insert before character definitions")
    if roots:
        root_order = roots[0].get("insertion_order")
        for row in era_contexts:
            if row["position"] != "before_char":
                raise WorldBuilderError("Era Context must insert before character definitions")
            if isinstance(root_order, int) and isinstance(row.get("insertion_order"), int) and row["insertion_order"] <= root_order:
                raise WorldBuilderError("Era Context order must be later/stronger than World Invariants within before_char placement")

    return {
        "contract": CONTRACT,
        "entry_count": len(rows),
        "entries": rows,
        "warnings": sorted(set(warnings)),
        "extended_position_count": sum(1 for row in rows if row["position"] in EXTENDED_POSITIONS),
    }


def assignment_context(plan: dict[str, Any], detail: dict[str, Any], uids: list[Any]) -> dict[str, Any]:
    wanted = {_uid(value) for value in uids}
    rows = [row for row in detail.get("entries", []) if _uid(row.get("uid")) in wanted]
    if len(rows) != len(wanted):
        found = {_uid(row.get("uid")) for row in rows}
        raise WorldBuilderError("placement assignment context is missing UIDs: " + ", ".join(sorted(wanted - found)))
    return {
        "contract": CONTRACT,
        "policy": plan.get("policy"),
        "profile_id": plan.get("profile_id"),
        "entries": rows,
        "warnings": [item for item in detail.get("warnings", []) if any(f"UID {uid}:" in item for uid in wanted)],
    }


def _output_setting(entry: dict[str, Any], names: tuple[str, ...]) -> Any:
    for name in names:
        if name in entry:
            return entry[name]
    ext = entry.get("extensions")
    if isinstance(ext, dict):
        for name in names:
            if name in ext:
                return ext[name]
    return None


def _output_index(data: dict[str, Any]) -> dict[str, dict[str, Any]]:
    result: dict[str, dict[str, Any]] = {}
    for ref in iter_entries(data):
        identity = canonical_entry_identity(ref.entry)
        if identity is not None:
            result[str(identity)] = ref.entry
    return result


def validate_output(detail: dict[str, Any], data: dict[str, Any]) -> dict[str, Any]:
    index = _output_index(data)
    checked = 0
    warnings = list(detail.get("warnings", []))
    for row in detail.get("entries", []):
        uid = _uid(row.get("uid"))
        if uid not in index:
            # Card-star/manual manifest rows do not necessarily emit lore entries.
            if row.get("layer") == "character" and row.get("position") is None:
                continue
            raise WorldBuilderError(f"placement output is missing manifest UID {uid}")
        entry = index[uid]
        observed_position = _normalize_position(_output_setting(entry, ("position",)))
        if observed_position != row.get("position"):
            raise WorldBuilderError(f"output UID {uid} placement differs from the frozen plan")
        observed_order = _output_setting(entry, ("insertion_order", "order"))
        if observed_order != row.get("insertion_order"):
            raise WorldBuilderError(f"output UID {uid} insertion order differs from the frozen plan")
        observed_priority = _output_setting(entry, ("priority",))
        if row.get("priority") is not None and observed_priority != row.get("priority"):
            raise WorldBuilderError(f"output UID {uid} priority differs from the frozen plan")
        observed_depth = _output_setting(entry, ("depth",))
        observed_role = _output_setting(entry, ("role",))
        observed_outlet = _output_setting(entry, ("outlet",))
        if observed_depth != row.get("depth") or observed_role != row.get("role") or observed_outlet != row.get("outlet"):
            raise WorldBuilderError(f"output UID {uid} extended placement settings differ from the frozen plan")
        content = entry.get("content")
        if row.get("constant") and isinstance(content, str) and len(content) > 2400:
            warnings.append(f"UID {uid}: constant entry is large for permanent prompt pressure ({len(content)} characters)")
        checked += 1
    return {"entries_checked": checked, "warnings": sorted(set(warnings))}


def validate(build_state: str, stage: str, output: str | None = None, *, write_receipt: bool = True) -> dict[str, Any]:
    root, state = load_build_state(build_state)
    manifest_path = resolve_state_path(root, state, "manifest")
    manifest = load_json(manifest_path)
    if not isinstance(manifest, dict):
        raise WorldBuilderError("manifest must be an object")
    plan, plan_path, profile = load_bound_plan(root, state, manifest, required=True)
    assert plan is not None and plan_path is not None and profile is not None
    detail = validate_manifest(plan, manifest, profile)
    target_path: Path | None = None
    output_detail: dict[str, Any] | None = None
    if stage == "output":
        target_path = Path(output).expanduser().resolve() if output else resolve_state_path(root, state, "final_output")
        if not target_path.exists():
            raise WorldBuilderError("placement output target is missing")
        data = load_json(target_path)
        if not isinstance(data, dict):
            raise WorldBuilderError("placement output target must be a JSON object")
        output_detail = validate_output(detail, data)
    elif stage != "planning":
        raise WorldBuilderError("placement stage must be planning or output")
    receipt = {
        "kind": RECEIPT_KIND,
        "receipt_version": RECEIPT_VERSION,
        "status": "passed",
        "stage": stage,
        "contract": CONTRACT,
        "build_id": state.get("build_id"),
        "manifest": str(manifest_path.relative_to(root)).replace("\\", "/"),
        "manifest_sha256": sha256_file(manifest_path),
        "placement_plan": str(plan_path.relative_to(root)).replace("\\", "/"),
        "placement_plan_sha256": sha256_file(plan_path),
        "default_profile_sha256": sha256_file(resolve_state_path(root, state, "default_profile")),
        "entry_count": detail["entry_count"],
        "entries": detail["entries"],
        "extended_position_count": detail["extended_position_count"],
        "warnings": detail["warnings"],
        "target": str(target_path.relative_to(root)).replace("\\", "/") if target_path else None,
        "target_sha256": sha256_file(target_path) if target_path else None,
        "output": output_detail,
    }
    if write_receipt:
        key = "placement_output_receipt" if stage == "output" else "placement_planning_receipt"
        receipt_path = resolve_state_path(root, state, key)
        atomic_write_json(receipt_path, receipt)
        receipt["receipt"] = str(receipt_path.relative_to(root)).replace("\\", "/")
        receipt["receipt_sha256"] = sha256_file(receipt_path)
    return receipt


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--build-state", required=True)
    parser.add_argument("--stage", choices=("planning", "output"), default="planning")
    parser.add_argument("--output")
    parser.add_argument("--requirements", action="store_true", help="Read-only preflight: print what this gate checks against the current build state.")
    args = parser.parse_args()
    if args.requirements:
        root, state = load_build_state(args.build_state)
        print(json.dumps(preflight_report("placement_contract", requirement_rows(Path(__file__), root, state)), ensure_ascii=False, indent=2))
        return 0
    try:
        print(json.dumps(validate(args.build_state, args.stage, args.output, write_receipt=True), ensure_ascii=False, indent=2))
        return 0
    except (WorldBuilderError, OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
