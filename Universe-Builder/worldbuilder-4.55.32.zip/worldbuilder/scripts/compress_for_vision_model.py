#!/usr/bin/env python3
"""Compress/resize an image to fit a vision model's real, researched
constraints, never a guessed threshold. Called with parameters the
main agent has already looked up for the specific subagent model in
use, not with defaults invented here.

Deliberately conservative: resizes by dimension first (cheapest quality
loss for screenshot-style images with text/graffiti detail), and only
drops JPEG quality if dimension resizing alone doesn't reach the target
byte budget.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from PIL import Image


def compress_for_model(
    input_path: str,
    output_path: str,
    *,
    max_dimension_px: int,
    max_bytes: int,
    min_quality: int = 40,
) -> dict[str, object]:
    img = Image.open(input_path).convert("RGB")
    original_size = Path(input_path).stat().st_size
    original_dims = img.size

    if max(img.size) > max_dimension_px:
        scale = max_dimension_px / max(img.size)
        img = img.resize((max(1, int(img.size[0] * scale)), max(1, int(img.size[1] * scale))), Image.LANCZOS)

    quality = 90
    while quality >= min_quality:
        img.save(output_path, "JPEG", quality=quality)
        if Path(output_path).stat().st_size <= max_bytes:
            break
        quality -= 10

    final_size = Path(output_path).stat().st_size
    return {
        "original_bytes": original_size,
        "original_dimensions": original_dims,
        "final_bytes": final_size,
        "final_dimensions": img.size,
        "final_quality": quality,
        "fit_within_budget": final_size <= max_bytes,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True, help="Image to compress")
    parser.add_argument("--output", required=True, help="Destination JPEG")
    parser.add_argument("--max-dimension-px", type=int, required=True)
    parser.add_argument("--max-bytes", type=int, required=True)
    parser.add_argument("--min-quality", type=int, default=40)
    args = parser.parse_args()
    result = compress_for_model(
        args.input,
        args.output,
        max_dimension_px=args.max_dimension_px,
        max_bytes=args.max_bytes,
        min_quality=args.min_quality,
    )
    print(json.dumps(result, indent=2))
    return 0 if result["fit_within_budget"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
