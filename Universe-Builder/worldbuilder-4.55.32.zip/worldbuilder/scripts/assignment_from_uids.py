#!/usr/bin/env python3
"""Create a validator-clean generation assignment for an explicit UID set.

This is the supported bridge between an activation-map slice and the generation
assignment shape consumed by evidence_gate.py. It never invents research topics:
manifest topics/sources are reused when present, otherwise a conservative identity
research topic is recorded so the assignment remains explicit and reviewable. On a
vision-enabled build it also stamps each UID's expected image count for the
session image budget.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
from pathlib import Path
from typing import Any

from activation_map_gate import build_assignment_slice
from evidence_gate import required_assignment_version, validate_assignment
from model_routing import model_for_role
from wb_common import WorldBuilderError, atomic_write_json, load_build_state, load_json, resolve_state_path, sha256_file

CONTRACT = "worldbuilder-assignment-from-uids-v1"


def _uid_key(value: Any) -> str:
    if isinstance(value, bool) or value is None:
        raise WorldBuilderError(f"invalid UID {value!r}")
    return str(value).strip()


def _manifest_rows(manifest: dict[str, Any]) -> dict[str, dict[str, Any]]:
    rows = manifest.get("entries")
    if not isinstance(rows, list):
        raise WorldBuilderError("manifest entries must be an array")
    out: dict[str, dict[str, Any]] = {}
    for row in rows:
        if not isinstance(row, dict):
            continue
        uid = row.get("uid", row.get("id"))
        if uid is None:
            continue
        out[_uid_key(uid)] = row
    return out


def _string_list(value: Any) -> list[str]:
    if not isinstance(value, list):
        return []
    return [item.strip() for item in value if isinstance(item, str) and item.strip()]


def _entry_assignment(row: dict[str, Any]) -> dict[str, Any]:
    uid = row.get("uid", row.get("id"))
    name = row.get("name") or row.get("display_name") or row.get("comment") or f"UID {uid}"
    arch = row.get("architecture") if isinstance(row.get("architecture"), dict) else {}
    sources = _string_list(row.get("source_urls"))
    if not sources:
        sources = _string_list(row.get("sources"))
    topics = _string_list(row.get("research_topics"))
    if not topics:
        topics = [f"identity and facts for {name}"]
    return {
        "uid": uid,
        "name": str(name),
        "display_name": str(row.get("display_name") or name),
        "layer": arch.get("layer", row.get("layer")),
        "type": row.get("type"),
        "manifest_pointer": f"/entries/{uid}",
        "source_urls": sources,
        "research_topics": topics,
    }


def create_assignment(
    build_state: str | Path,
    uids: list[str],
    *,
    assignment_id: str,
    worker: str,
    output: str,
    research_mode: str | None = None,
    evidence_output: str | None = None,
    evidence_receipt: str | None = None,
) -> dict[str, Any]:
    state_path = Path(build_state).resolve()
    root, state = load_build_state(state_path)
    manifest_path = resolve_state_path(root, state, "manifest")
    manifest = load_json(manifest_path)
    rows = _manifest_rows(manifest)
    clean_uids = []
    for raw in uids:
        key = _uid_key(raw)
        if key not in rows:
            raise WorldBuilderError(f"assignment requested unknown UID {raw!r}")
        if key not in clean_uids:
            clean_uids.append(key)
    if not clean_uids:
        raise WorldBuilderError("assignment requires at least one UID")
    version = required_assignment_version(root, state)
    assignment_entries = [_entry_assignment(rows[uid]) for uid in clean_uids]
    mode = research_mode or ("public_web" if state.get("discovery", {}).get("required") else "provided_sources")
    evidence_output = evidence_output or f"artifacts/discoveries/{assignment_id}-evidence.json"
    evidence_receipt = evidence_receipt or f".work/evidence-receipts/{assignment_id}-evidence-receipt.json"
    assignment: dict[str, Any] = {
        "assignment_version": version,
        "assignment_id": assignment_id,
        "build_id": state.get("build_id"),
        "manifest_sha256": sha256_file(manifest_path),
        "workspace_root": str(root),
        "role": "generation",
        "worker": worker,
        "schema": state.get("artifact", {}).get("schema", state.get("schema", 3)),
        "research_mode": mode,
        "entries": assignment_entries,
        "evidence_output": evidence_output,
        "evidence_receipt": evidence_receipt,
        "output": output,
        "end_delimiter": "END WORLDBUILDER GENERATION REPORT",
    }
    requested_model = model_for_role(state.get("models") if isinstance(state.get("models"), dict) else {}, "generation")
    if requested_model is not None:
        assignment["requested_model"] = requested_model
    if version >= 3:
        map_slice = build_assignment_slice(str(state_path), [rows[uid].get("uid", rows[uid].get("id")) for uid in clean_uids])
        assignment.update({
            "activation_map_sha256": map_slice["activation_map_sha256"],
            "field_registry_sha256": map_slice["field_registry_sha256"],
            "default_profile_sha256": map_slice["default_profile_sha256"],
            "map_slice": map_slice,
        })
        for key in ("character_plan_sha256", "era_plan_sha256", "placement_plan_sha256", "budget_plan_sha256", "dynamic_state_plan_sha256"):
            if map_slice.get(key) is not None:
                assignment[key] = map_slice[key]
        if map_slice.get("budget_plan_sha256") is not None:
            assignment["budget_context"] = map_slice.get("budget_context")
        if map_slice.get("dynamic_state_plan_sha256") is not None:
            assignment["dynamic_state_context"] = map_slice.get("dynamic_state_context")
    settings = state.get("settings") if isinstance(state.get("settings"), dict) else {}
    if settings.get("effective_image_mode"):
        image_rows = []
        for entry in assignment_entries:
            topics = entry.get("research_topics") or []
            has_appearance = any(
                isinstance(topic, str) and re.search(r"\bappearance\b", topic.casefold())
                for topic in topics
            )
            image_rows.append({"uid": entry["uid"], "expected_images": 1 if has_appearance else 0})
        assignment["image_context"] = {"entries": image_rows}
    validate_assignment(
        assignment,
        str(state.get("build_id")),
        sha256_file(manifest_path),
        int(state.get("batching", {}).get("generation_entries_per_worker", 15) or 15),
        required_version=version,
        root=root,
        state=state,
    )
    return assignment


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--build-state", required=True)
    parser.add_argument("--uid", action="append", required=True, dest="uids")
    parser.add_argument("--assignment-id", required=True)
    parser.add_argument("--worker", default="Raven")
    parser.add_argument("--output", required=True, help="Relative phase output path, e.g. .work/phases/phase-0002.json")
    parser.add_argument("--research-mode", choices=("public_web", "provided_sources", "mixed"))
    parser.add_argument("--evidence-output")
    parser.add_argument("--evidence-receipt")
    parser.add_argument("--write", help="Optional assignment JSON path; defaults to .work/assignments/<assignment-id>.json")
    args = parser.parse_args()
    try:
        assignment = create_assignment(
            args.build_state, args.uids, assignment_id=args.assignment_id, worker=args.worker,
            output=args.output, research_mode=args.research_mode,
            evidence_output=args.evidence_output, evidence_receipt=args.evidence_receipt,
        )
        root, _state = load_build_state(args.build_state)
        path = Path(args.write).expanduser() if args.write else root / ".work" / "assignments" / f"{args.assignment_id}.json"
        if not path.is_absolute():
            path = root / path
        path = path.resolve()
        try:
            path.relative_to(root)
        except ValueError as exc:
            raise WorldBuilderError("assignment output must stay inside the build workspace") from exc
        atomic_write_json(path, assignment)
        print(json.dumps({"status": "written", "contract": CONTRACT, "assignment": str(path.relative_to(root)).replace(os.sep, "/"), "assignment_version": assignment["assignment_version"], "entry_count": len(assignment["entries"])}, ensure_ascii=False, indent=2))
        return 0
    except (WorldBuilderError, OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
