#!/usr/bin/env python3
"""Verify audit patches against the actual target bytes.

Patch-log records are JSON Lines. JSON patches must identify an exact JSON
Pointer in ``path``; text patches use ``contains``/``absent`` evidence. Stable
UID lookup is retained only as an explicit migration mode.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any

from wb_common import WorldBuilderError, atomic_write_json, build_identity_index, load_json
from artifact_diff import diff_artifacts

ERROR_MARKER_RE = re.compile(r"^\s*(?:###\s*)?\[E\d+\]", re.MULTILINE)
HEADER_ERRORS_RE = re.compile(r"^hard_errors\s*:\s*(\d+)\s*$", re.I | re.M)


def decode_pointer(pointer: str) -> list[str]:
    if pointer == "":
        return []
    if not pointer.startswith("/"):
        raise WorldBuilderError(f"JSON Pointer must start with '/': {pointer!r}")
    return [part.replace("~1", "/").replace("~0", "~") for part in pointer[1:].split("/")]


def resolve_pointer(document: Any, pointer: str) -> tuple[bool, Any]:
    current = document
    for part in decode_pointer(pointer):
        if isinstance(current, list):
            try:
                index = int(part)
            except ValueError:
                return False, None
            if index < 0 or index >= len(current):
                return False, None
            current = current[index]
        elif isinstance(current, dict):
            if part not in current:
                return False, None
            current = current[part]
        else:
            return False, None
    return True, current


def parent_pointer(document: Any, pointer: str) -> tuple[bool, Any, str | None]:
    parts = decode_pointer(pointer)
    if not parts:
        return True, None, None
    parent = "" if len(parts) == 1 else "/" + "/".join(part.replace("~", "~0").replace("/", "~1") for part in parts[:-1])
    exists, value = resolve_pointer(document, parent)
    return exists, value, parts[-1]


def load_patch_log(path: Path) -> list[tuple[int, dict[str, Any]]]:
    records: list[tuple[int, dict[str, Any]]] = []
    for number, raw in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        if not raw.strip():
            continue
        try:
            item = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise WorldBuilderError(f"patch-log line {number} is invalid JSON: {exc}") from exc
        if not isinstance(item, dict):
            raise WorldBuilderError(f"patch-log line {number} must be an object")
        records.append((number, item))
    return records


def legacy_pointer(record: dict[str, Any], data: Any) -> str:
    if "uid" not in record:
        raise WorldBuilderError("JSON patch is missing required path")
    index = build_identity_index(data)
    uid = record["uid"]
    try:
        normalized = int(uid) if isinstance(uid, str) and uid.strip().lstrip("-").isdigit() else uid
    except (TypeError, ValueError):
        normalized = uid
    if normalized not in index:
        raise WorldBuilderError(f"UID {uid!r} is absent from target")
    entry_path, _ = index[normalized]
    field = record.get("field")
    if record.get("type") == "set":
        if not isinstance(field, str) or not field:
            raise WorldBuilderError("legacy set patch requires field")
        suffix = "/".join(part.replace("~", "~0").replace("/", "~1") for part in field.split("."))
        return f"{entry_path}/{suffix}"
    return entry_path


def verify_json_patch(record: dict[str, Any], data: Any, allow_legacy: bool) -> str | None:
    kind = record.get("type")
    pointer = record.get("path")
    if not isinstance(pointer, str):
        if not allow_legacy:
            return "missing exact JSON Pointer 'path' (use --allow-legacy-identity only for migration)"
        try:
            pointer = legacy_pointer(record, data)
        except WorldBuilderError as exc:
            return str(exc)

    exists, actual = resolve_pointer(data, pointer)
    if kind == "set":
        if not exists:
            return f"{pointer} does not exist"
        if actual != record.get("new"):
            return f"{pointer} is {actual!r}, expected {record.get('new')!r}"
    elif kind == "add":
        if not exists:
            return f"added path {pointer} does not exist"
        if "new" in record and actual != record["new"]:
            return f"added path {pointer} differs from recorded value"
    elif kind == "remove":
        if exists:
            return f"removed path {pointer} still exists"
    elif kind == "renumber":
        old_path = record.get("old_path")
        if not isinstance(old_path, str):
            return "renumber patch requires old_path"
        old_exists, _ = resolve_pointer(data, old_path)
        if old_exists:
            return f"old identity path {old_path} still exists"
        if not exists:
            return f"new identity path {pointer} does not exist"
    else:
        return f"unsupported JSON patch type {kind!r}"
    return None


def verify_text_patch(record: dict[str, Any], text: str) -> str | None:
    kind = record.get("type")
    if kind in {"text_contains", "replace"}:
        needle = record.get("contains", record.get("new"))
        if not isinstance(needle, str) or not needle:
            return f"{kind} requires a non-empty contains/new string"
        if needle not in text:
            return f"required text is absent: {needle!r}"
        if kind == "replace" and isinstance(record.get("old"), str) and record["old"] in text:
            return f"old text is still present: {record['old']!r}"
    elif kind == "text_absent":
        needle = record.get("absent", record.get("old"))
        if not isinstance(needle, str) or not needle:
            return "text_absent requires a non-empty absent/old string"
        if needle in text:
            return f"forbidden text is still present: {needle!r}"
    else:
        return f"unsupported text patch type {kind!r}"
    return None


def count_declared_errors(paths: list[str]) -> int:
    count = 0
    for path in paths:
        text = Path(path).read_text(encoding="utf-8", errors="replace")
        header = HEADER_ERRORS_RE.search(text)
        count += int(header.group(1)) if header else len(ERROR_MARKER_RE.findall(text))
    return count


def check_collateral_damage(alias: str, before: Any, after: Any) -> list[str]:
    """7.1/7.8: patch-log verification alone only confirms each individual
    patch record's own target changed correctly; it has no way to notice
    something ELSE silently breaking. unknown_field_loss, extension_loss,
    and a whole entry disappearing are never a legitimate outcome of
    applying a set of field-level patches: a patch record targets a
    specific pointer with a specific intended value, never "delete a
    field this patch never mentioned" and never "remove this entry
    entirely." All three are flagged unconditionally, regardless of what
    the patches themselves targeted; this system's patch records have
    no notion of an authorized entry removal at all."""
    diff = diff_artifacts(before, after)
    failures: list[str] = []
    for uid in diff["removed_uids"]:
        failures.append(
            f"collateral damage in {alias!r}: uid {uid} disappeared entirely without any patch record targeting it"
        )
    for uid, delta in diff["changed_entries"].items():
        if delta["unknown_field_loss"]:
            failures.append(
                f"collateral damage in {alias!r} uid {uid}: field(s) {', '.join(delta['unknown_field_loss'])} "
                "disappeared without any patch record targeting them"
            )
        if delta["extension_loss"]:
            failures.append(
                f"collateral damage in {alias!r} uid {uid}: extensions key(s) {', '.join(delta['extension_loss'])} "
                "disappeared without any patch record targeting them"
            )
    return failures


def main() -> int:
    parser = argparse.ArgumentParser(description="Verify an audit patch log against JSON and text targets.")
    parser.add_argument("--patch-log", required=True)
    parser.add_argument("--target", action="append", default=[], help="alias=path; may be repeated")
    parser.add_argument("--before", action="append", default=[],
                         help="alias=path; may be repeated. Optional: without it, verification is "
                              "patch-log-only, exactly as before this flag existed. When given for an "
                              "alias, that target's JSON is checked for collateral damage (unknown-field "
                              "or extension loss) beyond what the patch log itself accounts for.")
    parser.add_argument("--findings", action="append", default=[])
    parser.add_argument("--hard-errors", type=int)
    parser.add_argument("--allow-legacy-identity", action="store_true")
    parser.add_argument(
        "--write-change-set",
        help=(
            "Batch 13, Problem 4: optional path to write a change_set.py-contract change set derived "
            "from this patch log, if and only if the patch gate passes. Feeds audit_plan.py's own "
            "--scope changed --change-set <path>, so the pre-seal re-audit this patch triggers reviews "
            "only the patched entries and their neighbours, not a full re-audit, unless the patch "
            "log itself touched a non-entry (structural) path, in which case a full re-audit is still "
            "correct and this writes structural=true rather than forcing an inapplicable scope. Requires "
            "the manifest via --target manifest=<path> for the activation-graph edges, and resolves each "
            "record's entry pointers against the alias that record itself names (for example "
            "--target output=<final path>), falling back to the manifest when that alias is absent."
        ),
    )
    args = parser.parse_args()

    try:
        patch_path = Path(args.patch_log)
        records = load_patch_log(patch_path)
        targets: dict[str, Path] = {}
        for raw in args.target:
            if "=" not in raw:
                raise WorldBuilderError(f"invalid --target {raw!r}; expected alias=path")
            alias, value = raw.split("=", 1)
            if alias in targets:
                raise WorldBuilderError(f"duplicate target alias {alias!r}")
            target = Path(value).resolve()
            if not target.exists():
                raise WorldBuilderError(f"target does not exist: {target}")
            targets[alias] = target
        before_targets: dict[str, Path] = {}
        for raw in args.before:
            if "=" not in raw:
                raise WorldBuilderError(f"invalid --before {raw!r}; expected alias=path")
            alias, value = raw.split("=", 1)
            if alias not in targets:
                raise WorldBuilderError(f"--before given for alias {alias!r}, which has no matching --target")
            before_path = Path(value).resolve()
            if not before_path.exists():
                raise WorldBuilderError(f"--before target does not exist: {before_path}")
            before_targets[alias] = before_path
        cache: dict[str, tuple[str, Any]] = {}
        for alias, path in targets.items():
            if path.suffix.lower() == ".json":
                cache[alias] = ("json", load_json(path))
            else:
                cache[alias] = ("text", path.read_text(encoding="utf-8", errors="replace"))

        failures: list[str] = []
        for alias, before_path in before_targets.items():
            target_kind, after_content = cache[alias]
            if target_kind != "json":
                continue  # collateral-damage diffing is a structural, JSON-only check
            failures.extend(check_collateral_damage(alias, load_json(before_path), after_content))

        fixes = 0
        deferrals = 0
        for line, record in records:
            kind = record.get("type")
            if kind == "deferred":
                if not isinstance(record.get("hard_error"), str) or not isinstance(record.get("reason"), str):
                    failures.append(f"line {line}: deferred patch requires hard_error and reason")
                else:
                    deferrals += 1
                continue
            alias = record.get("file")
            if alias not in cache:
                failures.append(f"line {line}: unknown target alias {alias!r}")
                continue
            target_kind, content = cache[alias]
            if target_kind == "json":
                failure = verify_json_patch(record, content, args.allow_legacy_identity)
            else:
                failure = verify_text_patch(record, content)
            if failure:
                failures.append(f"line {line}: {failure}")
            else:
                fixes += 1

        declared = args.hard_errors if args.hard_errors is not None else count_declared_errors(args.findings)
        if fixes + deferrals < declared:
            failures.append(
                f"accounting mismatch: {declared} hard error(s), but only {fixes} verified fix(es) and {deferrals} deferral(s)"
            )
        print(f"Verified fixes: {fixes}; deferrals: {deferrals}; declared hard errors: {declared}")
        if failures:
            print("PATCH GATE BLOCKED")
            for failure in failures:
                print(f"  - {failure}")
            return 1
        print("PATCH GATE PASSED")
        if args.write_change_set:
            manifest_entry = cache.get("manifest")
            if manifest_entry is None or manifest_entry[0] != "json":
                print(
                    "  (--write-change-set given, but no --target manifest=<path> was provided. "
                    "skipping; the manifest provides the activation-graph edges a scoped re-audit needs)"
                )
            else:
                from change_set import change_set_from_patch_log
                bare_records = [record for _line, record in records]
                alias_documents = {
                    alias: document
                    for alias, (kind, document) in cache.items()
                    if kind == "json" and alias != "manifest"
                }
                change_set = change_set_from_patch_log(
                    bare_records, manifest_entry[1], manifest=manifest_entry[1], alias_documents=alias_documents
                )
                atomic_write_json(Path(args.write_change_set), change_set)
                print(
                    f"  Change set written to {args.write_change_set}: "
                    f"{len(change_set['changed_uids'])} changed UID(s), "
                    f"{len(change_set['neighbour_affected_uids'])} neighbour(s), "
                    f"structural={change_set['structural']}"
                )
        return 0
    except (OSError, json.JSONDecodeError, WorldBuilderError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
