#!/usr/bin/env python3
"""Reconcile the planned entry count/type breakdown and token budget
against what generation actually delivered.

Deliberately not a predictor. ``build-list.md`` declares a plan before
generation runs; this module never guesses at that number in advance. It only
measures what the delivered artifact actually contains and reports the
difference as a named, advisory diff. Token measurements reuse
``budget_contract.py`` so WorldBuilder has one token-measurement authority.
"""
from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

from budget_contract import actual_entry_token_measurement, analyze_manifest
from wb_common import canonical_entry_identity, iter_entries, load_json

REPORT_KIND = "worldbuilder-plan-reconciliation"
REPORT_VERSION = 1


def parse_declared_breakdown(build_list_text: str) -> dict[str, int] | None:
    """Extract the declared ``Entries: **N**`` breakdown line.

    Returns ``None`` if the line is not present in the expected shape. Callers
    must treat that as "nothing to reconcile against", never as zero planned
    entries.
    """
    match = re.search(r"Entries:\s*\*\*(\d+)\*\*\s*[—-]\s*(.+)", build_list_text)
    if not match:
        return None
    total = int(match.group(1))
    breakdown: dict[str, int] = {"total": total}
    for part in match.group(2).split(","):
        part = part.strip().rstrip(".")
        count_match = re.match(r"(\d+)\s+(.+)", part)
        if count_match:
            count, label = int(count_match.group(1)), count_match.group(2).strip().lower()
            breakdown[label] = breakdown.get(label, 0) + count
    return breakdown


def measure_actual_breakdown(entries: list[dict[str, Any]]) -> dict[str, int]:
    """Count what the delivered artifact actually contains.

    Classification uses each entry's real name/comment prefix (``RULE: ...``,
    ``LOCATION: ...``, ``CHARACTER: ...``). It never re-derives what the plan
    intended and does not assume an extension field exists on real entries.
    """
    counts: dict[str, int] = {"total": len(entries)}
    for entry in entries:
        label = str(entry.get("comment") or entry.get("name") or "")
        prefix_match = re.match(r"([A-Za-z][A-Za-z &]*?):\s", label)
        category = prefix_match.group(1).strip().lower() if prefix_match else "unclassified"
        counts[category] = counts.get(category, 0) + 1
    return counts


def reconcile_entry_count(declared: dict[str, int] | None, actual: dict[str, int]) -> dict[str, Any]:
    """Return a real, named diff; never a corrected prediction."""
    if declared is None:
        return {"status": "no_declared_plan_found", "actual": actual}
    total_declared = declared.get("total", 0)
    total_actual = actual.get("total", 0)
    delta = total_actual - total_declared
    declared_categories = {key: value for key, value in declared.items() if key != "total"}
    actual_categories = {key: value for key, value in actual.items() if key != "total"}
    exact_overlap = sorted(set(declared_categories) & set(actual_categories))
    exact_category_deltas = {
        key: actual_categories[key] - declared_categories[key]
        for key in exact_overlap
    }
    unmapped_declared = {
        key: declared_categories[key]
        for key in sorted(set(declared_categories) - set(actual_categories))
    }
    actual_only = {
        key: actual_categories[key]
        for key in sorted(set(actual_categories) - set(declared_categories))
    }
    return {
        "status": "matches" if delta == 0 else ("more_than_planned" if delta > 0 else "fewer_than_planned"),
        "declared_total": total_declared,
        "actual_total": total_actual,
        "delta": delta,
        "declared_breakdown": declared,
        "actual_breakdown": actual,
        "exact_category_deltas": exact_category_deltas,
        "unmapped_declared_categories": unmapped_declared,
        "actual_only_categories": actual_only,
        "category_mapping_complete": not unmapped_declared and not actual_only,
        "category_mapping_note": (
            "Category names are compared only when their labels match exactly. "
            "Coarser plan buckets such as 'routing anchors' are not silently mapped "
            "onto more granular delivered prefixes; unmapped categories are a known "
            "reconciliation limitation, not a fabricated mismatch."
        ),
        "note": (
            "A non-zero delta is not inherently a defect; discovery yield, "
            "merge decisions, and pruning can all legitimately change the final count. "
            "This is a measurement to review, not a failed check."
        ),
    }


def reconcile_token_budget(
    measured_tokens_by_uid: dict[str, int],
    target_tokens_by_uid: dict[str, int],
) -> dict[str, Any]:
    """Compare existing measured token facts against original per-entry targets."""
    over_target: list[dict[str, Any]] = []
    all_uids = set(measured_tokens_by_uid) | set(target_tokens_by_uid)
    for uid in sorted(all_uids):
        measured = measured_tokens_by_uid.get(uid)
        target = target_tokens_by_uid.get(uid)
        if measured is None or target is None:
            continue
        if measured > target:
            over_target.append({
                "uid": uid,
                "measured_tokens": measured,
                "target_tokens": target,
                "over_by": measured - target,
            })
    total_measured = sum(v for v in measured_tokens_by_uid.values() if isinstance(v, int))
    total_target = sum(v for v in target_tokens_by_uid.values() if isinstance(v, int))
    return {
        "entries_over_target": over_target,
        "total_measured_tokens": total_measured,
        "total_target_tokens": total_target,
        "total_delta": total_measured - total_target,
        "note": (
            "An over-target row is a measured fact for Weaver to evaluate, not an "
            "automatic audit finding or rewrite instruction."
        ),
    }


def analyze(
    data: Any,
    *,
    build_list_text: str | None,
    budget_plan: dict[str, Any] | None,
    manifest: dict[str, Any] | None,
) -> dict[str, Any]:
    """Build the deterministic post-generation reconciliation report.

    The count side uses the delivered entries and the plan's declared build-list
    line. The token side reuses ``budget_contract``'s actual measurement and
    per-entry planning detail, so this module does not create a second estimator.
    """
    refs = list(iter_entries(data))
    entries = [ref.entry for ref in refs]
    declared = parse_declared_breakdown(build_list_text or "")
    actual = measure_actual_breakdown(entries)
    entry_count = reconcile_entry_count(declared, actual)

    token_budget: dict[str, Any]
    if not isinstance(budget_plan, dict) or not budget_plan.get("applicable") or not isinstance(manifest, dict):
        token_budget = {
            "status": "not_applicable",
            "reason": "no applicable bound budget plan/manifest was available",
            "entries_over_target": [],
        }
    else:
        detail = analyze_manifest(budget_plan, manifest)
        targets: dict[str, int] = {}
        for row in detail.get("entries") or []:
            if not isinstance(row, dict):
                continue
            uid = row.get("uid")
            target = row.get("soft_target")
            if uid is not None and isinstance(target, int) and not isinstance(target, bool):
                targets[str(uid)] = target
        measured: dict[str, int] = {}
        sources: dict[str, str] = {}
        for ref in refs:
            identity = canonical_entry_identity(ref.entry)
            if identity is None:
                continue
            value, source = actual_entry_token_measurement(ref.entry)
            measured[str(identity)] = value
            sources[str(identity)] = source
        token_budget = reconcile_token_budget(measured, targets)
        token_budget["status"] = "measured"
        token_budget["measurement_sources"] = sources

    return {
        "kind": REPORT_KIND,
        "report_version": REPORT_VERSION,
        "applicable": bool(entries),
        "entry_count": entry_count,
        "token_budget": token_budget,
        "advisory_only": True,
        "auto_fix": False,
    }


def main() -> int:
    import argparse

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True, help="Delivered/generated JSON artifact")
    parser.add_argument("--build-list", help="Optional build-list.md used for declared entry-count reconciliation")
    parser.add_argument("--budget-plan", help="Optional bound budget-plan JSON")
    parser.add_argument("--manifest", help="Optional manifest JSON needed for per-entry target reconstruction")
    parser.add_argument("--output", help="Optional JSON report path")
    args = parser.parse_args()

    data = load_json(Path(args.input))
    build_list_text = Path(args.build_list).read_text(encoding="utf-8") if args.build_list else None
    budget_plan = load_json(Path(args.budget_plan)) if args.budget_plan else None
    manifest = load_json(Path(args.manifest)) if args.manifest else None
    report = analyze(data, build_list_text=build_list_text, budget_plan=budget_plan, manifest=manifest)
    rendered = json.dumps(report, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        Path(args.output).write_text(rendered, encoding="utf-8", newline="\n")
    print(rendered, end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
