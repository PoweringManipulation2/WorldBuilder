#!/usr/bin/env python3
"""Enforce interleaved per-entry research -> validation -> writing cycles.

A generation worker must complete each assigned UID before beginning research on
its successor. This gate stores a content-bound progress receipt under the
build workspace and refuses out-of-order or research-ahead execution.

Batch 60: the write stage carries the worker's image count and returns a
session-budget verdict (continue / handoff_after_this_uid / handoff_now), and
the finalize stage can record a partial vision-budget handoff, which is never
a completion and can never merge.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
from pathlib import Path
from typing import Any

from activation_map_gate import slice_dependency_hash, validate_assignment_slice
from character_contract import load_bound_plan as load_character_plan
from character_contract import manifest_character_rows, validate_lorebook_checkpoint
from budget_contract import actual_entry_tokens
from lock_contract import assert_unlocked
from budget_contract import (
    COMPRESSION_RATIO_BY_DETAIL,
    ENTRY_TARGET_FLOOR,
    RETENTION_LADDER,
    compute_entry_target,
    estimate_tokens,
)

from evidence_gate import (
    uid_key,
    validate_assignment,
    validate_evidence,
    validate_overflow_record,
    required_assignment_version,
    require_relative_build_path,
)
from wb_common import (
    WorldBuilderError,
    atomic_write_json,
    ensure_inside,
    step_driver_pointer,
    load_build_state,
    load_json,
    resolve_state_path,
    sha256_file,
    build_identity_index,
    normalize_identity,
)
from vision_parameters import resolve_vision_limits, session_image_budget, verify_image_coverage


def _paths(build_state_path: str, assignment_path: str) -> tuple[Path, dict[str, Any], Path, dict[str, Any], str, str]:
    root, state = load_build_state(build_state_path)
    build_id = str(state.get("build_id", "")).strip()
    if not build_id:
        raise WorldBuilderError(f"{build_state_path} has no build_id: this is not a valid, initialized build-state.json; re-run init_build.py")
    assignment_file = Path(assignment_path)
    if not assignment_file.is_absolute():
        assignment_file = (root / assignment_file).resolve()
    else:
        assignment_file = assignment_file.resolve()
    ensure_inside(assignment_file, root)
    if not assignment_file.exists():
        raise WorldBuilderError(f"assignment file does not exist at {assignment_file}: check the --assignment path is correct, or that dispatch actually wrote this file under paths.assignments")
    assignment_data = load_json(assignment_file)
    manifest_sha = str(assignment_data.get("manifest_sha256", "")).lower() if isinstance(assignment_data, dict) else ""
    if not manifest_sha:
        raise WorldBuilderError("assignment lacks manifest_sha256; regenerate it from the planning outputs before dispatch")
    batching = state.get("batching") if isinstance(state.get("batching"), dict) else {}
    limit = batching.get("generation_entries_per_worker", 15)
    required_version = required_assignment_version(root, state)
    assignment = validate_assignment(assignment_data, build_id, manifest_sha, limit, required_version, root=root, state=state)
    if assignment["assignment_version"] >= 3:
        validate_assignment_slice(str(Path(build_state_path).resolve()), assignment_data)
    return root, state, assignment_file, assignment_data, build_id, manifest_sha


def _ordered_uids(assignment_data: dict[str, Any]) -> list[str]:
    return [uid_key(row["uid"]) for row in assignment_data["entries"]]


def _cycle_path(root: Path, state: dict[str, Any], assignment_data: dict[str, Any]) -> Path:
    value = assignment_data.get("entry_cycle_receipt")
    if not isinstance(value, str) or not value.strip():
        value = f".work/evidence-receipts/{assignment_data['assignment_id']}.entry-cycle.json"
    path = require_relative_build_path(root, value, "entry_cycle_receipt")
    ensure_inside(path, resolve_state_path(root, state, "evidence_receipts"))
    return path



ENTRY_CYCLE_RECEIPT_VERSION = 2


def _declared_slice_sha(assignment_data: dict[str, Any]) -> str | None:
    """The slice hash the assignment was generated with, when it carries one."""
    slice_block = assignment_data.get("map_slice")
    if isinstance(slice_block, dict):
        value = slice_block.get("slice_sha256")
        if isinstance(value, str) and value:
            return value
    value = assignment_data.get("slice_sha256")
    return value if isinstance(value, str) and value else None


def _load_or_init(path: Path, *, build_id: str, assignment_id: str, assignment_sha: str, manifest_sha: str, ordered: list[str], slice_sha: str | None = None, per_uid_sha: dict[str, str] | None = None, neighbour_sha: str | None = None) -> dict[str, Any]:
    if path.exists():
        data = load_json(path)
        if not isinstance(data, dict) or data.get("kind") != "entry-cycle-gate" or data.get("receipt_version") != ENTRY_CYCLE_RECEIPT_VERSION:
            raise WorldBuilderError(f"{path.name} has the wrong format (kind/receipt_version mismatch): if it predates a receipt-version upgrade, delete it and let this gate reinitialize a fresh one")
        expected = {
            "build_id": build_id,
            "assignment_id": assignment_id,
            "assignment_sha256": assignment_sha,
            "ordered_uids": ordered,
        }
        for key, value in expected.items():
            if data.get(key) != value:
                raise WorldBuilderError(f"{path.name} is stale or mismatched at {key} (found {data.get(key)!r}, expected {value!r}): run --stage rebase to rescope it, or regenerate the assignment if it changed on purpose")
        # Slice scope, not manifest scope. An assignment depends on its own rows, the
        # edges touching them, and its neighbours, not on every entry in the build.
        # Binding to the manifest expired all in-flight assignments whenever any entry
        # anywhere changed, stranding completed checkpoints that were still correct.
        if slice_sha and data.get("slice_sha256"):
            if data["slice_sha256"] != slice_sha:
                raise WorldBuilderError(
                    "entry-cycle receipt is stale: this assignment's slice changed. "
                    "Run --stage rebase to see which UIDs moved and keep the rest."
                )
        elif data.get("manifest_sha256") != manifest_sha:
            raise WorldBuilderError(
                "entry-cycle receipt is stale or mismatched at manifest_sha256. "
                "Run --stage rebase to rescope this receipt to its slice."
            )
        return data
    return {
        "receipt_version": ENTRY_CYCLE_RECEIPT_VERSION,
        "kind": "entry-cycle-gate",
        "build_id": build_id,
        "assignment_id": assignment_id,
        "assignment_sha256": assignment_sha,
        "manifest_sha256": manifest_sha,
        "slice_sha256": slice_sha,
        "per_uid_sha256": per_uid_sha or {},
        "neighbour_sha256": neighbour_sha,
        "ordered_uids": ordered,
        "completed_uids": [],
        "cycles": [],
        "session_images": 0,
        "total_images_consumed": 0,
        "handoffs": [],
        "next_action": "research",
        "current_uid": ordered[0],
        "status": "in_progress",
        "updated_at_unix": int(time.time()),
    }


def _prefix_assignment(assignment: dict[str, Any], ordered: list[str], count: int) -> dict[str, Any]:
    subset = dict(assignment)
    subset["entries"] = {uid: assignment["entries"][uid] for uid in ordered[:count]}
    return subset


def _image_counts(assignment_data: dict[str, Any]) -> dict[str, int]:
    """Per-UID expected image counts from the assignment's `image_context`.

    An empty mapping means the session budget does not apply to this
    assignment: text-only builds and assignments authored before session
    budgets carry no context, and nothing about them changes."""
    context = assignment_data.get("image_context")
    counts: dict[str, int] = {}
    if not isinstance(context, dict):
        return counts
    rows = context.get("entries")
    if not isinstance(rows, list):
        return counts
    for row in rows:
        if not isinstance(row, dict):
            continue
        try:
            key = uid_key(row.get("uid"))
        except WorldBuilderError:
            continue
        count = row.get("expected_images")
        if isinstance(count, int) and not isinstance(count, bool) and count >= 0:
            counts[key] = count
    return counts


def _session_budget(state: dict[str, Any]) -> dict[str, Any] | None:
    """Resolve the session image budget for image-bearing dispatch.

    None means the vision route does not apply: a model reported as not
    multimodal routes image work to the analysis-subagent path, which is a
    route change, not an error. Raising means the budget is needed but cannot
    be trusted, because an unreported capability, or limits that are absent
    or belong to a different model, must refuse rather than default."""
    settings = state.get("settings") if isinstance(state.get("settings"), dict) else {}
    capability = str(settings.get("vision_capable", "")).strip().casefold()
    if capability == "unavailable":
        return None
    if capability != "available":
        raise WorldBuilderError(
            "vision capability is not reported as available or unavailable for this build: "
            "image-bearing dispatch requires the recorded capability check, never a guess"
        )
    image = state.get("image_analysis") if isinstance(state.get("image_analysis"), dict) else {}
    stored = image.get("vision_limits") if isinstance(image.get("vision_limits"), dict) else None
    current_model = str(settings.get("vision_capability_checked_model", "")).strip()
    if not current_model:
        last = image.get("last_capability_check")
        if isinstance(last, dict):
            current_model = str(last.get("resolved_generation_model", "")).strip()
    fresh = resolve_vision_limits(stored, current_model)
    if fresh is None:
        raise WorldBuilderError(
            "researched vision limits are missing or belong to a different model: re-run the vision "
            "capability check with the model's real limits before dispatching image-bearing work"
        )
    soft_percent = settings.get("vision_soft_percent", 75)
    if isinstance(soft_percent, bool) or not isinstance(soft_percent, int):
        raise WorldBuilderError("settings.vision_soft_percent must be an integer between 10 and 100")
    cap = settings.get("vision_session_cap")
    if cap is not None and (isinstance(cap, bool) or not isinstance(cap, int)):
        raise WorldBuilderError("settings.vision_session_cap must be an integer or null")
    try:
        budget = session_image_budget(fresh, soft_percent, cap)
    except ValueError as exc:
        raise WorldBuilderError(str(exc)) from exc
    budget["model"] = str(fresh.get("model", ""))
    return budget


def _coverage_report(assignment_data: dict[str, Any], progress: dict[str, Any], covered_uids: list[str]) -> dict[str, Any] | None:
    """Reconcile worker-reported image loads against the assignment's expectation.

    None when the assignment carries no image context (nothing to reconcile).
    Otherwise one receipt per worker session, so a handoff that loses an
    image is visible instead of silent."""
    counts = _image_counts(assignment_data)
    if not counts:
        return None
    expected = sum(counts.get(uid, 0) for uid in covered_uids)
    covered = set(covered_uids)
    sessions: dict[int, int] = {}
    for row in progress.get("cycles") or []:
        if not isinstance(row, dict) or row.get("uid") not in covered:
            continue
        consumed = row.get("images_consumed")
        consumed = consumed if isinstance(consumed, int) and not isinstance(consumed, bool) else 0
        session = row.get("worker_session")
        session = session if isinstance(session, int) and not isinstance(session, bool) else 0
        sessions[session] = sessions.get(session, 0) + consumed
    receipts = [
        {"subagent": f"worker session {index + 1}", "images_processed": count}
        for index, count in sorted(sessions.items())
    ]
    return verify_image_coverage(expected, receipts)


def _coverage_failure_message(coverage: dict[str, Any]) -> str:
    details = []
    if coverage.get("missing"):
        details.append(f"{coverage['missing']} expected image load(s) unaccounted for")
    if coverage.get("excess"):
        details.append(f"{coverage['excess']} more image load(s) reported than expected")
    detail = "; ".join(details) or "the counts do not reconcile"
    return (
        f"image coverage does not reconcile across this assignment's workers: {detail}. "
        "Workers record what they actually loaded via --images-consumed; reconcile the affected UIDs before finalizing or handing off."
    )


def _handoff_vision_budget(root: Path, state: dict[str, Any], assignment_data: dict[str, Any], cycle_path: Path, progress: dict[str, Any], ordered: list[str]) -> dict[str, Any]:
    """Record a vision-budget handoff: a partial stop at a validated write boundary.

    The assignment is never marked complete here. A replacement resumes at
    the first remaining UID with a fresh session budget, while
    total_images_consumed carries the build-level total across every worker
    that touched the assignment, so coverage still reconciles."""
    if progress.get("status") == "complete":
        raise WorldBuilderError("this assignment is already complete; nothing to hand off")
    completed = [uid for uid in progress.get("completed_uids", []) if isinstance(uid, str)]
    remaining = [uid for uid in ordered if uid not in set(completed)]
    if not remaining:
        raise WorldBuilderError("no UIDs remain outstanding: run the normal finalize (no --reason)")
    if progress.get("next_action") != "research":
        raise WorldBuilderError(
            "a vision-budget handoff may occur only immediately after a write checkpoint validates. "
            f"UID {progress.get('current_uid')!r} is mid-cycle (next action {progress.get('next_action')!r}): "
            "finish the current UID's write checkpoint first, then hand off."
        )
    budget = _session_budget(state)
    if budget is None:
        raise WorldBuilderError(
            "no session image budget applies to this build: --reason vision-budget is only valid when "
            "image-bearing work routes to this worker's model"
        )
    next_uid = remaining[0]
    next_images = _image_counts(assignment_data).get(next_uid, 0)
    session_images = int(progress.get("session_images", 0) or 0)
    if next_images > budget["hard"]:
        raise WorldBuilderError(
            f"UID {next_uid} expects {next_images} image(s), more than a whole session budget of {budget['hard']}: "
            "split this UID or raise the session budget; a handoff cannot make it fit"
        )
    triggered = None
    if session_images >= budget["soft"]:
        triggered = "soft"
    elif session_images + next_images > budget["hard"]:
        triggered = "hard_lookahead"
    if triggered is None:
        raise WorldBuilderError(
            f"the session image budget is not at a handoff point: {session_images} of {budget['hard']} image(s) spent "
            f"(soft threshold {budget['soft']}), and UID {next_uid} expects {next_images}: continue with the next UID."
        )
    coverage = _coverage_report(assignment_data, progress, completed)
    if coverage is not None and not coverage["ok"]:
        raise WorldBuilderError(_coverage_failure_message(coverage))
    handoff = {
        "sequence": len(progress.get("handoffs") or []) + 1,
        "completed_uids": completed,
        "remaining_uids": remaining,
        "session_images": session_images,
        "total_images_consumed": int(progress.get("total_images_consumed", 0) or 0),
        "limit": {
            "soft": budget["soft"],
            "hard": budget["hard"],
            "soft_percent": budget["soft_percent"],
            "cap": budget["cap"],
            "model": budget.get("model"),
            "triggered": triggered,
        },
        "at_uid": next_uid,
        "coverage": coverage,
        "recorded_at_unix": int(time.time()),
    }
    progress.setdefault("handoffs", []).append(handoff)
    progress["session_images"] = 0
    progress["status"] = "partial_handoff"
    progress["next_action"] = "research"
    progress["current_uid"] = next_uid
    progress["updated_at_unix"] = int(time.time())
    atomic_write_json(cycle_path, progress)
    progress["receipt_path"] = str(cycle_path.relative_to(root)).replace(os.sep, "/")
    progress["receipt_sha256"] = sha256_file(cycle_path)
    return progress


def rebase_stage(build_state: str, assignment_path: str) -> dict[str, Any]:
    """Rescope a stale receipt to its slice, keeping work that is still valid.

    The previous behaviour expired an assignment whenever the manifest changed at all,
    discarding completed per-entry checkpoints that were still on disk and still
    correct. That is the expensive failure: twenty workers restart because one entry
    elsewhere moved.

    This recomputes the per-UID dependency hashes and keeps every completed UID whose
    own rows, edges, and neighbours are unchanged. Affected UIDs are reset and named.
    Nothing is silently trusted: a UID is kept only when its hash matches.
    """
    root, state, cycle_path, assignment_data, assignment_sha, manifest_sha = _paths(build_state, assignment_path)
    if not cycle_path.exists():
        raise WorldBuilderError("no entry-cycle receipt to rebase; start the assignment normally")
    progress = load_json(cycle_path)
    if not isinstance(progress, dict) or progress.get("kind") != "entry-cycle-gate":
        raise WorldBuilderError(f"{cycle_path.name} has the wrong format (not a dict, or kind != 'entry-cycle-gate'): delete it and start the assignment normally instead of rebasing")

    ordered = _ordered_uids(assignment_data)
    for key, value in (("build_id", state.get("build_id")),
                       ("assignment_id", assignment_data.get("assignment_id")),
                       ("assignment_sha256", assignment_sha),
                       ("ordered_uids", ordered)):
        if progress.get(key) != value:
            raise WorldBuilderError(
                f"cannot rebase: receipt disagrees at {key}. The assignment itself changed, "
                "so regenerate it and start fresh rather than salvaging progress."
            )

    current = slice_dependency_hash(root, state, ordered)
    recorded = progress.get("per_uid_sha256")
    recorded = recorded if isinstance(recorded, dict) else {}
    completed = [uid for uid in progress.get("completed_uids", []) if isinstance(uid, str)]

    kept, reset = [], []
    for uid in completed:
        previous = recorded.get(uid)
        if previous is not None and previous == current["per_uid_sha256"].get(uid):
            kept.append(uid)
        else:
            reset.append(uid)

    neighbour_changed = (progress.get("neighbour_sha256") is not None
                         and progress["neighbour_sha256"] != current["neighbour_sha256"])
    if neighbour_changed:
        # Slices embed neighbour summaries, so a neighbour change can invalidate prose
        # that referenced it. Keeping such entries would be the unsafe kind of salvage.
        reset = completed[:]
        kept = []

    remaining = [uid for uid in ordered if uid not in kept]
    progress.update({
        "manifest_sha256": manifest_sha,
        "slice_sha256": current["slice_sha256"],
        "per_uid_sha256": current["per_uid_sha256"],
        "neighbour_sha256": current["neighbour_sha256"],
        "completed_uids": kept,
        "next_action": "research",
        "current_uid": remaining[0] if remaining else None,
        "status": "in_progress" if remaining else "complete",
        "updated_at_unix": int(time.time()),
    })
    progress.setdefault("cycles", [])
    progress["cycles"] = [c for c in progress["cycles"]
                          if isinstance(c, dict) and c.get("uid") in kept]
    atomic_write_json(cycle_path, progress)
    return {
        "stage": "rebase",
        "assignment_id": progress["assignment_id"],
        "kept_uids": kept,
        "reset_uids": reset,
        "remaining_uids": remaining,
        "neighbour_changed": neighbour_changed,
        "reason": ("a neighbour row changed, so every completed entry was reset because "
                   "slices embed neighbour context" if neighbour_changed else
                   "kept every completed entry whose own rows, edges, and neighbours are unchanged"),
        "next_action": progress["next_action"],
        "current_uid": progress["current_uid"],
    }


def research_stage(build_state: str, assignment_path: str, uid: str) -> dict[str, Any]:
    root, state, assignment_file, assignment_data, build_id, manifest_sha = _paths(build_state, assignment_path)
    assignment_sha = sha256_file(assignment_file)
    batching = state.get("batching") if isinstance(state.get("batching"), dict) else {}
    assignment = validate_assignment(assignment_data, build_id, manifest_sha, batching.get("generation_entries_per_worker", 15), required_assignment_version(root, state), root=root, state=state)
    ordered = _ordered_uids(assignment_data)
    uid = uid_key(uid)
    cycle_path = _cycle_path(root, state, assignment_data)
    progress = _load_or_init(cycle_path, build_id=build_id, assignment_id=assignment["assignment_id"], assignment_sha=assignment_sha, manifest_sha=manifest_sha, ordered=ordered, slice_sha=_declared_slice_sha(assignment))
    if progress.get("status") == "complete":
        raise WorldBuilderError("entry-cycle assignment is already complete")
    if progress.get("next_action") != "research" or progress.get("current_uid") != uid:
        raise WorldBuilderError(f"out-of-order research: next required action is {progress.get('next_action')} for UID {progress.get('current_uid')}")

    counts = _image_counts(assignment_data)
    uid_images = counts.get(uid, 0)
    if uid_images > 0:
        budget = _session_budget(state)
        if budget is not None:
            session_images = int(progress.get("session_images", 0) or 0)
            if uid_images > budget["hard"]:
                raise WorldBuilderError(
                    f"UID {uid} expects {uid_images} image(s), more than a whole session budget of {budget['hard']}: "
                    "split this UID or raise the session budget; a handoff cannot make it fit"
                )
            if session_images >= budget["soft"]:
                raise WorldBuilderError(
                    f"session image budget is at {session_images} of {budget['hard']} (soft threshold {budget['soft']}): "
                    f"the previous write advised handoff_after_this_uid. Run the finalize stage with --reason vision-budget "
                    f"and re-dispatch a replacement; do not open UID {uid}"
                )
            if session_images + uid_images > budget["hard"]:
                raise WorldBuilderError(
                    f"UID {uid} would take this session to {session_images + uid_images} image(s), past the session budget of "
                    f"{budget['hard']}: finish this session's cycle and hand off with --reason vision-budget; a fresh session can fit it"
                )

    evidence_path = require_relative_build_path(root, assignment_data.get("evidence_output"), "evidence_output")
    if not evidence_path.exists():
        raise WorldBuilderError(f"evidence ledger does not exist at {evidence_path}: research UID {uid} and write its evidence record before checkpointing")
    evidence = load_json(evidence_path)
    records = evidence.get("entries") if isinstance(evidence, dict) else None
    if not isinstance(records, list):
        raise WorldBuilderError(f"{evidence_path.name}'s 'entries' field must be a list of evidence records, found {type(records).__name__}")
    completed = list(progress.get("completed_uids", []))
    expected_prefix = completed + [uid]
    actual = [uid_key(row.get("uid")) for row in records if isinstance(row, dict) and "uid" in row]
    if actual != expected_prefix:
        raise WorldBuilderError(
            "evidence ledger must contain exactly the completed UID prefix plus the current UID; "
            f"expected {expected_prefix}, found {actual}"
        )
    subset = _prefix_assignment(assignment, ordered, len(expected_prefix))
    result = validate_evidence(
        evidence,
        assignment=subset,
        assignment_sha=assignment_sha,
        build_id=build_id,
        manifest_sha=manifest_sha,
    )
    progress["next_action"] = "write"
    progress["current_uid"] = uid
    progress["current_evidence_sha256"] = sha256_file(evidence_path)
    progress["current_claim_ids"] = result["claim_ids_by_uid"][uid]
    progress["current_status"] = result["statuses_by_uid"][uid]

    # Batch 5, 5.3/5.8: source_tokens is only knowable now: research just
    # happened. budget_context (stamped at planning time, Batch 5, 5.1/5.2)
    # carries this UID's entry_hard; compression_ratio comes from the same
    # profile's detail axis. Absent for a non-lore-bearing build or a
    # generation-batch-limit assignment with no budget_context at all;
    # target/split_signal are omitted, not guessed, in that case.
    own_record = next((r for r in records if isinstance(r, dict) and uid_key(r.get("uid")) == uid), None)
    claims = own_record.get("claims") if isinstance(own_record, dict) else None
    source_tokens = sum(estimate_tokens(c.get("text", "")) for c in claims if isinstance(c, dict)) if isinstance(claims, list) else 0
    progress["current_source_tokens"] = source_tokens
    progress["current_retention_ladder"] = RETENTION_LADDER

    manifest_path = resolve_state_path(root, state, "manifest")
    manifest_data = load_json(manifest_path)
    if not isinstance(manifest_data, dict):
        raise WorldBuilderError(f"{manifest_path.name} must be a JSON object, found {type(manifest_data).__name__}")
    manifest_index = build_identity_index(manifest_data)
    manifest_key = normalize_identity(uid)
    if manifest_key in manifest_index:
        assert_unlocked(manifest_index[manifest_key][1], operation=f"generation checkpoint for UID {uid}")

    budget_context = assignment_data.get("budget_context")
    budget_row = None
    if isinstance(budget_context, dict):
        for row in budget_context.get("entries", []):
            if isinstance(row, dict) and uid_key(row.get("uid")) == uid:
                budget_row = row
                break
    if budget_row is not None and isinstance(budget_row.get("hard_limit"), int) and budget_context.get("context_window_mode") != "auto":
        ratio = COMPRESSION_RATIO_BY_DETAIL.get(budget_context.get("profile_id"))
        progress["current_entry_target"] = compute_entry_target(
            source_tokens, ratio, ENTRY_TARGET_FLOOR, budget_row["hard_limit"]
        )

    if progress.get("status") == "partial_handoff":
        # A replacement worker has picked this assignment back up; the
        # handoff entry stays in handoffs[] as the audit trail.
        progress["status"] = "in_progress"
    progress["updated_at_unix"] = int(time.time())
    atomic_write_json(cycle_path, progress)
    progress["receipt_path"] = str(cycle_path.relative_to(root)).replace(os.sep, "/")
    progress["receipt_sha256"] = sha256_file(cycle_path)
    return progress


def write_stage(build_state: str, assignment_path: str, uid: str, checkpoint_arg: str, images_consumed: int = 0) -> dict[str, Any]:
    if isinstance(images_consumed, bool) or not isinstance(images_consumed, int) or images_consumed < 0:
        raise WorldBuilderError("images_consumed must be a non-negative integer")
    root, state, assignment_file, assignment_data, build_id, manifest_sha = _paths(build_state, assignment_path)
    assignment_sha = sha256_file(assignment_file)
    batching = state.get("batching") if isinstance(state.get("batching"), dict) else {}
    assignment = validate_assignment(assignment_data, build_id, manifest_sha, batching.get("generation_entries_per_worker", 15), required_assignment_version(root, state), root=root, state=state)
    ordered = _ordered_uids(assignment_data)
    uid = uid_key(uid)
    cycle_path = _cycle_path(root, state, assignment_data)
    progress = _load_or_init(cycle_path, build_id=build_id, assignment_id=assignment["assignment_id"], assignment_sha=assignment_sha, manifest_sha=manifest_sha, ordered=ordered, slice_sha=_declared_slice_sha(assignment))
    if progress.get("next_action") != "write" or progress.get("current_uid") != uid:
        raise WorldBuilderError(f"out-of-order write: next required action is {progress.get('next_action')} for UID {progress.get('current_uid')}")

    checkpoint = Path(checkpoint_arg)
    if not checkpoint.is_absolute():
        checkpoint = (root / checkpoint).resolve()
    else:
        checkpoint = checkpoint.resolve()
    ensure_inside(checkpoint, root)
    if not checkpoint.exists():
        raise WorldBuilderError(f"entry checkpoint does not exist at {checkpoint}: write and save the checkpoint for UID {uid} before validating it")
    data = load_json(checkpoint)
    if not isinstance(data, dict):
        raise WorldBuilderError(f"{checkpoint.name} must be a JSON object, found {type(data).__name__}")
    meta = data.get("_worldbuilder")
    entries = data.get("entries")
    if not isinstance(meta, dict) or not isinstance(entries, list) or len(entries) != 1:
        raise WorldBuilderError(f"{checkpoint.name} must contain a '_worldbuilder' metadata object and an 'entries' list with exactly one entry: one checkpoint file is exactly one UID's worth of content")
    if uid_key(meta.get("uid")) != uid:
        raise WorldBuilderError(f"{checkpoint.name}'s _worldbuilder.uid ({meta.get('uid')!r}) does not match the UID this gate call is validating ({uid!r}): check --uid matches the checkpoint you actually wrote")
    if str(meta.get("evidence_sha256", "")).lower() != progress.get("current_evidence_sha256"):
        raise WorldBuilderError(f"{checkpoint.name}'s evidence_sha256 does not match the current evidence ledger's hash: re-save the checkpoint after the evidence ledger was last updated, not before")
    identity = entries[0].get("uid", entries[0].get("id")) if isinstance(entries[0], dict) else None
    if identity is None or uid_key(identity) != uid:
        raise WorldBuilderError(f"{checkpoint.name}'s entries[0] uid/id ({identity!r}) does not match the UID this gate call is validating ({uid!r})")
    used = meta.get("evidence_claims")
    if not isinstance(used, list) or any(not isinstance(item, str) for item in used):
        raise WorldBuilderError(f"{checkpoint.name}'s _worldbuilder.evidence_claims must be a list of claim-ID strings")
    unknown = sorted(set(used) - set(progress.get("current_claim_ids", [])))
    if unknown:
        raise WorldBuilderError(f"{checkpoint.name} cites claim ID(s) not present in the evidence ledger: {', '.join(unknown)}; only cite claim IDs the evidence ledger actually recorded for this UID")
    if progress.get("current_status") != "not_found" and not used:
        raise WorldBuilderError(f"{checkpoint.name} cites zero evidence claims, but UID {uid}'s status is not 'not_found': a researched entry must cite at least one validated claim ID")
    if meta.get("unsupported_claims") != []:
        raise WorldBuilderError(f"{checkpoint.name}'s _worldbuilder.unsupported_claims must be an empty list: resolve or remove any unsupported claims before checkpointing")

    manifest_path = resolve_state_path(root, state, "manifest")
    manifest_data = load_json(manifest_path)
    if not isinstance(manifest_data, dict):
        raise WorldBuilderError(f"{manifest_path.name} must be a JSON object, found {type(manifest_data).__name__}")
    manifest_index = build_identity_index(manifest_data)
    manifest_key = normalize_identity(uid)
    if manifest_key in manifest_index:
        assert_unlocked(manifest_index[manifest_key][1], operation=f"generation checkpoint for UID {uid}")

    budget_context = assignment_data.get("budget_context")
    budget_row = None
    if isinstance(budget_context, dict):
        for row in budget_context.get("entries", []):
            if isinstance(row, dict) and uid_key(row.get("uid")) == uid:
                budget_row = row
                break
    if assignment_data.get("budget_plan_sha256") is not None:
        map_slice = assignment_data.get("map_slice")
        if not isinstance(map_slice, dict) or assignment_data.get("budget_plan_sha256") != map_slice.get("budget_plan_sha256"):
            raise WorldBuilderError("this assignment's budget_plan_sha256 does not match its own map_slice.budget_plan_sha256: regenerate the assignment from current planning outputs")
    if assignment_data.get("dynamic_state_plan_sha256") is not None:
        map_slice = assignment_data.get("map_slice")
        if not isinstance(map_slice, dict) or assignment_data.get("dynamic_state_plan_sha256") != map_slice.get("dynamic_state_plan_sha256"):
            raise WorldBuilderError("this assignment's dynamic_state_plan_sha256 does not match its own map_slice.dynamic_state_plan_sha256: regenerate the assignment from current planning outputs")
        dynamic_context = assignment_data.get("dynamic_state_context")
        if not isinstance(dynamic_context, dict):
            raise WorldBuilderError("this assignment declares a dynamic_state_plan_sha256 but its dynamic_state_context is missing or not an object: regenerate the assignment")
        if not any(isinstance(row, dict) and uid_key(row.get("uid")) == uid for row in dynamic_context.get("entries", [])):
            raise WorldBuilderError(f"this assignment's dynamic_state_context has no entry for UID {uid}: regenerate the assignment so every assigned UID gets a resolved dynamic-state context")
    checkpoint_tokens = actual_entry_tokens(entries[0])
    if assignment_data.get("budget_plan_sha256") is not None:
        if budget_row is None:
            raise WorldBuilderError(f"this assignment's budget_context has no entry for UID {uid}: regenerate the assignment so every assigned UID gets a resolved budget context")
        hard_limit = budget_row.get("hard_limit")
        auto_budget = isinstance(budget_context, dict) and budget_context.get("context_window_mode") == "auto"
        if not auto_budget and (not isinstance(hard_limit, int) or checkpoint_tokens > hard_limit):
            raise WorldBuilderError(
                f"UID {uid}'s checkpoint is {checkpoint_tokens} tokens, which exceed hard limit {hard_limit}: "
                "trim the entry or route excess material to the overflow mechanism (Tier 2/3 pointers), not a longer entry"
            )

    character_rows = manifest_character_rows(manifest_data)
    if any(str(row.get("uid", row.get("id", ""))) == uid for row in character_rows):
        character_plan, _character_path, _detail = load_character_plan(
            root, state, manifest_data, required=True
        )
        assert character_plan is not None
        validate_lorebook_checkpoint(character_plan, manifest_data, uid, entries[0])

    # Batch 5, 5.8: cut Tier 2/3 material is routed, not deleted. Overflow is
    # optional (most entries cut nothing), but whatever is present must be
    # a validated pointer list (evidence_gate.validate_overflow_record), never
    # unvalidated prose smuggled back in through a worker-authored field.
    raw_overflow = meta.get("overflow")
    overflow_records: list[dict[str, Any]] = []
    if raw_overflow is not None:
        if not isinstance(raw_overflow, list):
            raise WorldBuilderError(f"{checkpoint.name}'s _worldbuilder.overflow must be a list of validated pointer records, found {type(raw_overflow).__name__}")
        overflow_records = [validate_overflow_record(record, valid_uids={uid}) for record in raw_overflow]

    completed = list(progress.get("completed_uids", [])) + [uid]
    progress["completed_uids"] = completed
    progress["session_images"] = int(progress.get("session_images", 0) or 0) + images_consumed
    progress["total_images_consumed"] = int(progress.get("total_images_consumed", 0) or 0) + images_consumed
    progress.setdefault("cycles", []).append({
        "sequence": len(completed),
        "uid": uid,
        "evidence_sha256": progress["current_evidence_sha256"],
        "checkpoint_path": str(checkpoint.relative_to(root)).replace(os.sep, "/"),
        "checkpoint_sha256": sha256_file(checkpoint),
        "budget_plan_sha256": assignment_data.get("budget_plan_sha256"),
        "dynamic_state_plan_sha256": assignment_data.get("dynamic_state_plan_sha256"),
        "estimated_tokens": checkpoint_tokens,
        "soft_target": budget_row.get("soft_target") if isinstance(budget_row, dict) else None,
        "hard_limit": budget_row.get("hard_limit") if isinstance(budget_row, dict) else None,
        "claim_ids": used,
        "overflow": overflow_records,
        "images_consumed": images_consumed,
        "worker_session": len(progress.get("handoffs") or []),
        "completed_at_unix": int(time.time()),
    })
    for key in ("current_evidence_sha256", "current_claim_ids", "current_status"):
        progress.pop(key, None)
    next_uid = None
    if len(completed) == len(ordered):
        progress["status"] = "ready_to_finalize"
        progress["next_action"] = "finalize"
        progress["current_uid"] = None
    else:
        next_uid = ordered[len(completed)]
        progress["next_action"] = "research"
        progress["current_uid"] = next_uid
    verdict = "continue"
    image_budget: dict[str, Any] | None = None
    pending_error: WorldBuilderError | None = None
    if next_uid is not None:
        next_images = _image_counts(assignment_data).get(next_uid, 0)
        session_images = int(progress.get("session_images", 0) or 0)
        if session_images > 0 or next_images > 0:
            budget = _session_budget(state)
            if budget is not None:
                image_budget = {
                    "session_images": session_images,
                    "soft": budget["soft"],
                    "hard": budget["hard"],
                    "soft_percent": budget["soft_percent"],
                }
                if next_images > budget["hard"]:
                    pending_error = WorldBuilderError(
                        f"UID {next_uid} expects {next_images} image(s), more than a whole session budget of {budget['hard']}: "
                        "split this UID or raise the session budget; a handoff cannot make it fit"
                    )
                elif session_images + next_images > budget["hard"]:
                    verdict = "handoff_now"
                elif session_images >= budget["soft"]:
                    verdict = "handoff_after_this_uid"
    progress["updated_at_unix"] = int(time.time())
    if pending_error is None:
        progress["last_verdict"] = {"uid": uid, "verdict": verdict, "next_uid": next_uid}
    atomic_write_json(cycle_path, progress)
    if pending_error is not None:
        raise pending_error
    progress["receipt_path"] = str(cycle_path.relative_to(root)).replace(os.sep, "/")
    progress["receipt_sha256"] = sha256_file(cycle_path)
    progress["verdict"] = verdict
    if image_budget is not None:
        progress["image_budget"] = image_budget
    return progress


def refresh_stage(build_state: str, assignment_path: str, uid: str, checkpoint_arg: str) -> dict[str, Any]:
    """Batch 62: re-record one completed UID's checkpoint hash in place.

    A recorded cycle can go stale for a single UID when its checkpoint file was
    regenerated after the write stage recorded the hash (for example during a
    repair pass); the only prior recovery discarded the whole cycle. This
    re-validates the checkpoint against the same contract the write stage
    enforced, then refreshes that one cycle row's hash. It never adds, removes,
    or reorders UIDs, so a refresh can never reopen completed work.
    """
    root, state, _assignment_file, assignment_data, build_id, manifest_sha = _paths(build_state, assignment_path)
    batching = state.get("batching") if isinstance(state.get("batching"), dict) else {}
    validate_assignment(assignment_data, build_id, manifest_sha, batching.get("generation_entries_per_worker", 15), required_assignment_version(root, state), root=root, state=state)
    uid = uid_key(uid)
    cycle_path = _cycle_path(root, state, assignment_data)
    if not cycle_path.exists():
        raise WorldBuilderError("no entry-cycle receipt to refresh; start the assignment normally")
    progress = load_json(cycle_path)
    if not isinstance(progress, dict) or progress.get("kind") != "entry-cycle-gate":
        raise WorldBuilderError(f"{cycle_path.name} has the wrong format (not a dict, or kind != 'entry-cycle-gate'): nothing to refresh")
    completed = [row for row in progress.get("completed_uids", []) if isinstance(row, str)]
    if uid not in completed:
        raise WorldBuilderError(
            f"UID {uid} is not one of this cycle's completed UIDs {completed or '(none)'}: only a completed "
            "UID's checkpoint hash can be refreshed; run --stage write for the current UID instead"
        )
    cycles = progress.get("cycles") if isinstance(progress.get("cycles"), list) else []
    row = next((r for r in cycles if isinstance(r, dict) and uid_key(r.get("uid")) == uid), None)
    if row is None:
        raise WorldBuilderError(f"UID {uid} has no recorded cycle row to refresh")

    checkpoint = Path(checkpoint_arg)
    if not checkpoint.is_absolute():
        checkpoint = (root / checkpoint).resolve()
    else:
        checkpoint = checkpoint.resolve()
    ensure_inside(checkpoint, root)
    if not checkpoint.exists():
        raise WorldBuilderError(f"entry checkpoint does not exist at {checkpoint}: nothing to refresh for UID {uid}")
    data = load_json(checkpoint)
    if not isinstance(data, dict):
        raise WorldBuilderError(f"{checkpoint.name} must be a JSON object, found {type(data).__name__}")
    meta = data.get("_worldbuilder")
    entries = data.get("entries")
    if not isinstance(meta, dict) or not isinstance(entries, list) or len(entries) != 1:
        raise WorldBuilderError(f"{checkpoint.name} must contain a '_worldbuilder' metadata object and an 'entries' list with exactly one entry: one checkpoint file is exactly one UID's worth of content")
    if uid_key(meta.get("uid")) != uid:
        raise WorldBuilderError(f"{checkpoint.name}'s _worldbuilder.uid ({meta.get('uid')!r}) does not match the UID this refresh targets ({uid!r})")
    recorded_evidence = str(row.get("evidence_sha256") or "").lower()
    if not recorded_evidence or str(meta.get("evidence_sha256", "")).lower() != recorded_evidence:
        raise WorldBuilderError(
            f"{checkpoint.name}'s evidence_sha256 does not match the evidence ledger hash this cycle recorded for UID {uid}: "
            "a refreshed checkpoint must still be the one this cycle wrote; re-run the write stage instead of refreshing"
        )
    identity = entries[0].get("uid", entries[0].get("id")) if isinstance(entries[0], dict) else None
    if identity is None or uid_key(identity) != uid:
        raise WorldBuilderError(f"{checkpoint.name}'s entries[0] uid/id ({identity!r}) does not match the UID this refresh targets ({uid!r})")
    used = meta.get("evidence_claims")
    allowed_claims = row.get("claim_ids") if isinstance(row.get("claim_ids"), list) else []
    if not isinstance(used, list) or any(not isinstance(item, str) for item in used):
        raise WorldBuilderError(f"{checkpoint.name}'s _worldbuilder.evidence_claims must be a list of claim-ID strings")
    unknown = sorted(set(used) - set(allowed_claims))
    if unknown:
        raise WorldBuilderError(f"{checkpoint.name} cites claim ID(s) this cycle never recorded for UID {uid}: {', '.join(unknown)}")
    if meta.get("unsupported_claims") != []:
        raise WorldBuilderError(f"{checkpoint.name}'s _worldbuilder.unsupported_claims must be an empty list")
    raw_overflow = meta.get("overflow")
    if raw_overflow is not None:
        if not isinstance(raw_overflow, list):
            raise WorldBuilderError(f"{checkpoint.name}'s _worldbuilder.overflow must be a list of validated pointer records, found {type(raw_overflow).__name__}")
        for record in raw_overflow:
            validate_overflow_record(record, valid_uids={uid})

    manifest_path = resolve_state_path(root, state, "manifest")
    manifest_data = load_json(manifest_path)
    if isinstance(manifest_data, dict):
        manifest_index = build_identity_index(manifest_data)
        manifest_key = normalize_identity(uid)
        if manifest_key in manifest_index:
            assert_unlocked(manifest_index[manifest_key][1], operation=f"generation checkpoint for UID {uid}")
        character_rows = manifest_character_rows(manifest_data)
        if any(str(candidate.get("uid", candidate.get("id", ""))) == uid for candidate in character_rows):
            character_plan, _character_path, _detail = load_character_plan(root, state, manifest_data, required=True)
            assert character_plan is not None
            validate_lorebook_checkpoint(character_plan, manifest_data, uid, entries[0])
    budget_context = assignment_data.get("budget_context")
    budget_row = None
    if isinstance(budget_context, dict):
        for candidate in budget_context.get("entries", []):
            if isinstance(candidate, dict) and uid_key(candidate.get("uid")) == uid:
                budget_row = candidate
                break
    if assignment_data.get("budget_plan_sha256") is not None:
        map_slice = assignment_data.get("map_slice")
        if not isinstance(map_slice, dict) or assignment_data.get("budget_plan_sha256") != map_slice.get("budget_plan_sha256"):
            raise WorldBuilderError("this assignment's budget_plan_sha256 does not match its own map_slice.budget_plan_sha256: regenerate the assignment from current planning outputs")
        hard_limit = budget_row.get("hard_limit") if isinstance(budget_row, dict) else None
        auto_budget = isinstance(budget_context, dict) and budget_context.get("context_window_mode") == "auto"
        checkpoint_tokens = actual_entry_tokens(entries[0])
        if not auto_budget and (not isinstance(hard_limit, int) or checkpoint_tokens > hard_limit):
            raise WorldBuilderError(
                f"UID {uid}'s checkpoint is {checkpoint_tokens} tokens, which exceed hard limit {hard_limit}: "
                "trim the entry or route excess material to the overflow mechanism (Tier 2/3 pointers), not a longer entry"
            )
    if assignment_data.get("dynamic_state_plan_sha256") is not None:
        map_slice = assignment_data.get("map_slice")
        if not isinstance(map_slice, dict) or assignment_data.get("dynamic_state_plan_sha256") != map_slice.get("dynamic_state_plan_sha256"):
            raise WorldBuilderError("this assignment's dynamic_state_plan_sha256 does not match its own map_slice.dynamic_state_plan_sha256: regenerate the assignment from current planning outputs")

    previous_sha = str(row.get("checkpoint_sha256") or "")
    row["checkpoint_sha256"] = sha256_file(checkpoint)
    row["refreshed_at_unix"] = int(time.time())
    row["refresh_count"] = int(row.get("refresh_count", 0) or 0) + 1
    progress["updated_at_unix"] = int(time.time())
    atomic_write_json(cycle_path, progress)
    progress["receipt_path"] = str(cycle_path.relative_to(root)).replace(os.sep, "/")
    progress["receipt_sha256"] = sha256_file(cycle_path)
    progress["refreshed"] = {
        "uid": uid,
        "previous_checkpoint_sha256": previous_sha,
        "checkpoint_sha256": row["checkpoint_sha256"],
    }
    return progress


def status_stage(build_state: str, assignment_path: str) -> dict[str, Any]:
    """Read-only view of an assignment's entry-cycle progress: kept UIDs,
    remaining UIDs, and a paste-ready resume dispatch card. Never writes
    anything, so it is safe to run after a timeout, mid-repair, or just to
    check in; unlike every other stage here, it cannot itself go stale."""
    root, state, assignment_file, assignment_data, build_id, manifest_sha = _paths(build_state, assignment_path)
    ordered = _ordered_uids(assignment_data)
    cycle_path = _cycle_path(root, state, assignment_data)
    if cycle_path.exists():
        progress = load_json(cycle_path)
        completed = [uid for uid in progress.get("completed_uids", []) if uid in set(ordered)]
        current_uid = progress.get("current_uid")
        next_action = progress.get("next_action")
        session_images = int(progress.get("session_images", 0) or 0)
        total_images_consumed = int(progress.get("total_images_consumed", 0) or 0)
        handoff_count = len(progress.get("handoffs") or [])
    else:
        completed = []
        current_uid = ordered[0] if ordered else None
        next_action = "research" if ordered else None
        session_images = 0
        total_images_consumed = 0
        handoff_count = 0
    remaining = [uid for uid in ordered if uid not in set(completed)]
    # The underlying receipt's own status vocabulary (open/ready_to_finalize/complete)
    # is an implementation detail of _load_or_init/finalize_stage; remaining_uids is
    # the one signal this report needs and it can never disagree with itself.
    if not completed and not cycle_path.exists():
        cycle_status = "not_started"
    elif remaining:
        cycle_status = "in_progress"
    else:
        cycle_status = "complete"
    run_timeout_seconds = assignment_data.get("run_timeout_seconds")

    card_lines = [
        f"Assignment: {assignment_data.get('assignment_id')}",
        f"Status: {cycle_status}",
        f"Kept ({len(completed)}): {', '.join(completed) if completed else '(none yet)'}",
        f"Remaining ({len(remaining)}): {', '.join(remaining) if remaining else '(none)'}",
        f"Resume at UID: {current_uid if current_uid is not None else '(assignment complete)'}",
        f"Next action: {next_action or '(none: assignment complete)'}",
    ]
    if remaining:
        card_lines.append(
            f"Re-dispatch this exact assignment_id (never a new one) with a raised "
            f"run_timeout_seconds; current stamp: {run_timeout_seconds}. "
            f"Completed checkpoints for kept UIDs are untouched; work resumes at the UID above."
        )
    card = "\n".join(card_lines)

    return {
        "assignment_id": assignment_data.get("assignment_id"),
        "status": cycle_status,
        "kept_uids": completed,
        "remaining_uids": remaining,
        "current_uid": current_uid,
        "next_action": next_action,
        "run_timeout_seconds": run_timeout_seconds,
        "session_images": session_images,
        "total_images_consumed": total_images_consumed,
        "handoff_count": handoff_count,
        "resume_dispatch_card": card,
    }


def finalize_stage(build_state: str, assignment_path: str, reason: str | None = None) -> dict[str, Any]:
    from evidence_gate import validate_assignment_evidence
    if reason is not None:
        reason = str(reason).strip().casefold()
        if reason != "vision-budget":
            raise WorldBuilderError(f"finalize --reason accepts only 'vision-budget', found {reason!r}")
    root, state, assignment_file, assignment_data, build_id, manifest_sha = _paths(build_state, assignment_path)
    assignment_sha = sha256_file(assignment_file)
    ordered = _ordered_uids(assignment_data)
    cycle_path = _cycle_path(root, state, assignment_data)
    progress = _load_or_init(cycle_path, build_id=build_id, assignment_id=assignment_data["assignment_id"], assignment_sha=assignment_sha, manifest_sha=manifest_sha, ordered=ordered, slice_sha=_declared_slice_sha(assignment_data))
    if reason == "vision-budget":
        return _handoff_vision_budget(root, state, assignment_data, cycle_path, progress, ordered)
    if progress.get("next_action") != "finalize" or progress.get("completed_uids") != ordered:
        remaining = [u for u in ordered if u not in set(progress.get("completed_uids", []))]
        raise WorldBuilderError(
            f"cannot finalize: next_action is {progress.get('next_action')!r} (need 'finalize'), or completed_uids "
            f"does not yet match this assignment's full ordered UID list. Still outstanding: {remaining or 'none: order itself differs from assignment order'}. "
            f"Current UID is {progress.get('current_uid')!r}: research/write it, then continue to the next UID in order."
        )
    coverage = _coverage_report(assignment_data, progress, ordered)
    if coverage is not None and not coverage["ok"]:
        raise WorldBuilderError(_coverage_failure_message(coverage))
    aggregate = validate_assignment_evidence(build_state, assignment_path, write_receipt=True)
    progress["status"] = "complete"
    progress["next_action"] = None
    progress["aggregate_evidence_receipt_sha256"] = aggregate.get("receipt_sha256")
    progress["updated_at_unix"] = int(time.time())
    atomic_write_json(cycle_path, progress)
    progress["receipt_path"] = str(cycle_path.relative_to(root)).replace(os.sep, "/")
    progress["receipt_sha256"] = sha256_file(cycle_path)
    return progress


def main() -> int:
    parser = argparse.ArgumentParser(description="Enforce per-entry research -> write sequencing for generation assignments.")
    parser.add_argument("--build-state", required=True)
    parser.add_argument("--assignment", required=True)
    parser.add_argument("--stage", required=True, choices=("research", "write", "refresh", "finalize", "rebase", "status"))
    parser.add_argument("--uid")
    parser.add_argument("--checkpoint")
    parser.add_argument("--images-consumed", type=int, default=0, help="Write stage: images that entered the worker's context for this UID (default 0).")
    parser.add_argument("--reason", choices=("vision-budget",), help="Finalize stage: record a partial vision-budget handoff instead of a completion.")
    args = parser.parse_args()
    try:
        if args.stage in {"research", "write", "refresh"} and not args.uid:
            raise WorldBuilderError("--uid is required for research, write, and refresh stages")
        if args.stage in {"write", "refresh"} and not args.checkpoint:
            raise WorldBuilderError("--checkpoint is required for write and refresh stages")
        if args.images_consumed and args.stage != "write":
            raise WorldBuilderError("--images-consumed is only valid for the write stage")
        if args.reason and args.stage != "finalize":
            raise WorldBuilderError("--reason is only valid for the finalize stage")
        if args.stage == "research":
            result = research_stage(args.build_state, args.assignment, args.uid)
        elif args.stage == "write":
            result = write_stage(args.build_state, args.assignment, args.uid, args.checkpoint, images_consumed=args.images_consumed)
        elif args.stage == "refresh":
            result = refresh_stage(args.build_state, args.assignment, args.uid, args.checkpoint)
        elif args.stage == "rebase":
            result = rebase_stage(args.build_state, args.assignment)
        elif args.stage == "status":
            result = status_stage(args.build_state, args.assignment)
        else:
            result = finalize_stage(args.build_state, args.assignment, args.reason)
        print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
        if args.stage == "status":
            print(f"\n{result['resume_dispatch_card']}")
        return 0
    except (WorldBuilderError, OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        print(step_driver_pointer(), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
