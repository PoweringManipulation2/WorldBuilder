#!/usr/bin/env python3
"""Deterministic craft helpers for WorldBuilder-generated prose and voice snippets."""
from __future__ import annotations

import argparse
import json
import re
from typing import Any

from wb_common import WorldBuilderError

CONTRACT = "worldbuilder-writing-quality-v1"
CLICHE_PHRASES: tuple[str, ...] = (
    "shivers down your spine",
    "eyes sparkle with mischief",
    "a mischievous glint",
    "voice drips with sarcasm",
    "smirk playing on",
    "could cut the tension with a knife",
)
REDIRECTION_STRATEGIES = frozenset({"avoid", "ignore-question"})
SECOND_PERSON_PATTERN = re.compile(
    r"\b(?:you['’](?:re|ve|ll|d)|yourselves|yourself|youre|youve|youll|youd|yours|your|you)\b",
    re.IGNORECASE,
)
QUOTED_SPAN_PATTERN = re.compile(r'"[^"]*"|“[^”]*”', re.DOTALL)


# Batch 64 (incoming workplan "Batch 57", Part 2 item 1): soft trait adjectives. A
# run of three or more of these, listed but never demonstrated, is a trait dump:
# it asserts a personality without showing one observable behavior behind it.
TRAIT_ADJECTIVE_LEXICON: tuple[str, ...] = (
    "kind", "gentle", "caring", "compassionate", "warm", "friendly", "cheerful", "sweet", "thoughtful", "considerate",
    "mysterious", "enigmatic", "aloof", "distant", "cold", "stoic", "reserved", "quiet", "brooding", "sullen",
    "brave", "bold", "fearless", "valiant", "heroic", "cunning", "clever", "sly", "witty", "sharp",
    "loyal", "devoted", "faithful", "protective", "fierce", "passionate", "intense", "driven", "ambitious", "ruthless",
    "playful", "mischievous", "impish", "flirtatious", "charming", "charismatic", "confident", "arrogant", "proud", "vain",
    "wise", "patient", "calm", "serene", "humble", "modest", "earnest", "honest", "sincere", "curious",
    "anxious", "nervous", "timid", "shy", "awkward", "clumsy", "gullible", "naive", "cynical", "jaded",
)
_TRAIT_ALTERNATION = "|".join(
    re.escape(word) for word in sorted(TRAIT_ADJECTIVE_LEXICON, key=len, reverse=True)
)
_TRAIT_SEPARATOR = r"(?:\s*,\s*(?:and\s+)?|\s+and\s+)"
# Three or more listed adjectives in a comma/`and` run ("kind, mysterious, caring").
TRAIT_ADJECTIVE_RUN_PATTERN = re.compile(
    rf"\b(?:{_TRAIT_ALTERNATION})(?:{_TRAIT_SEPARATOR}(?:{_TRAIT_ALTERNATION})){{2,}}\b",
    re.IGNORECASE,
)


def find_cliches(text: str) -> list[str]:
    folded = str(text).casefold()
    return [phrase for phrase in CLICHE_PHRASES if phrase.casefold() in folded]


def _without_quoted_spans(text: str) -> str:
    """Legitimately quoted example text is exempt: it reproduces other voices."""
    return QUOTED_SPAN_PATTERN.sub(" ", str(text))


def find_description_second_person(text: str) -> list[str]:
    """Second-person tokens addressed to a reader, outside quoted example text.

    The description field informs the model about the world; it addresses no
    one. Real shipped builds drifted into catalog voice ("You choose who you
    are"), so this stays a deterministic review flag, never an auto-rewrite.
    """
    return [match.group(0) for match in SECOND_PERSON_PATTERN.finditer(_without_quoted_spans(text))]


def find_trait_adjective_runs(text: str) -> list[str]:
    """Bare, listed runs of soft trait adjectives, outside legitimately quoted text.

    A run such as "kind, mysterious, caring" names a personality without any
    observable behavior behind it. Matches find_cliches()'s own
    detector-not-fixer discipline: this reports runs for review and never
    rewrites the prose. A lone adjective, or an adjective followed by a
    concrete noun ("a careful negotiator"), is not a run.
    """
    runs: list[str] = []
    for match in TRAIT_ADJECTIVE_RUN_PATTERN.finditer(_without_quoted_spans(text)):
        runs.append(re.sub(r"\s+", " ", match.group(0)).strip())
    return runs


def validate_trait_adjectives(text: str) -> dict[str, Any]:
    runs = find_trait_adjective_runs(text)
    return {
        "contract": CONTRACT,
        "status": "passed" if not runs else "warning",
        "trait_adjective_runs": runs,
    }


# Batch 64 (workplan "Batch 57", Part 2 item 4): declared-rule vs first-message check.
NEGATOR_PATTERN = re.compile(
    r"\b(?:not|never|no|without|cannot|can['’]t|won['’]t|don['’]t|doesn['’]t|didn['’]t|isn['’]t|aren['’]t|refus\w*)\b",
    re.IGNORECASE,
)
PROHIBITION_CLAUSE_PATTERN = re.compile(
    r"\b(?:never|refuses? to|does(?:n['’]t| not)|do(?:n['’]t| not)|cannot|can['’]t|won['’]t|will not|must not)\s+",
    re.IGNORECASE,
)
SENTENCE_SPLIT_PATTERN = re.compile(r"(?<=[.!?])\s+|\n+")
CONTENT_STOPWORDS = frozenset({
    "the", "a", "an", "and", "or", "but", "to", "of", "in", "on", "at", "for", "with", "from", "by", "as",
    "is", "are", "was", "were", "be", "been", "being", "that", "this", "these", "those", "it", "its",
    "their", "them", "they", "she", "he", "her", "his", "him", "you", "your", "i", "we", "us", "our",
    "any", "all", "no", "not", "never", "will", "would", "can", "could", "shall", "should", "may", "might", "must",
})


def _stem(word: str) -> str:
    w = re.sub(r"['’]s$", "", str(word).lower())
    for suffix in ("ing", "ed", "es", "s"):
        if len(w) > len(suffix) + 3 and w.endswith(suffix):
            return w[: -len(suffix)]
    return w


def _key_terms(text: str) -> list[str]:
    words = re.findall(r"[A-Za-z][A-Za-z'’\-]+", str(text))
    return [w for w in words if len(w) >= 4 and w.lower() not in CONTENT_STOPWORDS]


def prohibition_key_terms(rule_text: str) -> list[str]:
    """Content terms of each prohibition clause in one named rule ("Never reveal X")."""
    terms: list[str] = []
    for match in PROHIBITION_CLAUSE_PATTERN.finditer(str(rule_text)):
        clause = str(rule_text)[match.end():]
        clause = SENTENCE_SPLIT_PATTERN.split(clause)[0]
        terms.extend(t.lower() for t in _key_terms(clause))
    return terms


# Batch 64 (workplan "Batch 57", Part 2 item 2): positive-framing rule detector.
POSITIVE_RULE_MARKERS: tuple[str, ...] = (
    "always", "requires", "required", "only", "may ", "must be", "is permitted", "are permitted",
)


def find_prohibition_only_rules(text: str) -> list[str]:
    """Rule statements phrased only as a prohibition, with no paired positive form.

    A rule the model can follow beats one it must remember not to break, so a
    prohibition-only statement is flagged for the positive-framing rewrite
    (pair or replace it with an "always Y unless Z" form). Detector, not
    fixer: it reports the statements and never rewrites them. A statement that
    already carries a positive marker ("Always answer; never reveal X") is
    the paired form this asks for and is not flagged.
    """
    flagged: list[str] = []
    for sentence in SENTENCE_SPLIT_PATTERN.split(_without_quoted_spans(text)):
        statement = sentence.strip()
        if not statement or not PROHIBITION_CLAUSE_PATTERN.search(statement):
            continue
        folded = statement.casefold()
        if any(marker in folded for marker in POSITIVE_RULE_MARKERS):
            continue
        flagged.append(re.sub(r"\s+", " ", statement))
    return flagged


def validate_rule_framing(text: str) -> dict[str, Any]:
    flagged = find_prohibition_only_rules(text)
    return {
        "contract": CONTRACT,
        "status": "passed" if not flagged else "warning",
        "prohibition_only_rules": flagged,
    }


def find_rule_contradictions(first_message: str, rules: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """First-message statements that affirmatively do what a named rule forbids.

    Rules are the build's own named behavioral rules (world-core entries,
    Soul Extractor runtime guides). Quoted dialogue is deliberately NOT
    exempt here: the first message is largely in-voice speech, and a rule a
    speaker breaks is exactly the contradiction worth surfacing. This is a
    review signal, never an auto-rewrite: it matches on shared content terms,
    so it reports candidates a human confirms, not proof of contradiction.
    """
    findings: list[dict[str, Any]] = []
    sentences = [s for s in SENTENCE_SPLIT_PATTERN.split(str(first_message)) if s.strip()]
    for rule in rules or ():
        rule = rule if isinstance(rule, dict) else {}
        name = str(rule.get("name") or rule.get("uid") or "")
        wanted = {_stem(t) for t in prohibition_key_terms(rule.get("text") or "")}
        if not wanted:
            continue
        for sentence in sentences:
            if NEGATOR_PATTERN.search(sentence):
                continue
            present = {_stem(w) for w in _key_terms(sentence)}
            if wanted <= present:
                findings.append({
                    "rule": name,
                    "prohibition_terms": sorted(wanted),
                    "sentence": re.sub(r"\s+", " ", sentence).strip(),
                })
                break
    return findings


def validate_first_message_rules(first_message: str, rules: list[dict[str, Any]]) -> dict[str, Any]:
    findings = find_rule_contradictions(first_message, rules)
    return {
        "contract": CONTRACT,
        "status": "passed" if not findings else "warning",
        "contradictions": findings,
    }


def validate_description_voice(text: str) -> dict[str, Any]:
    matches = find_description_second_person(text)
    return {
        "contract": CONTRACT,
        "status": "passed" if not matches else "warning",
        "second_person_matches": matches,
    }


def validate_dialogue_examples(text: str) -> dict[str, Any]:
    matches = find_cliches(text)
    return {"contract": CONTRACT, "status": "passed" if not matches else "failed", "cliches": matches}


def situational_voice_entry(*, uid: Any, name: str, topic: str, keys: list[str], factual_context: str, reaction: str) -> dict[str, Any]:
    clean_keys = [str(k).strip() for k in keys if str(k).strip()]
    if not clean_keys:
        raise WorldBuilderError("situational voice entry requires at least one keyword")
    if not str(reaction).strip():
        raise WorldBuilderError("situational voice entry requires an in-voice reaction")
    if find_cliches(reaction):
        raise WorldBuilderError("situational voice reaction contains a maintained generated-dialogue cliche")
    return {
        "uid": uid,
        "name": str(name).strip() or f"Voice: {topic}",
        "keys": clean_keys,
        "secondary_keys": [],
        "content": f"{str(factual_context).strip()}\n\nIn voice: {str(reaction).strip()}",
        "enabled": True,
        "constant": False,
        "selective": False,
        "insertion_order": 100,
        "use_regex": False,
        "position": "after_char",
        "extensions": {"worldbuilder_situational_voice": {"contract": CONTRACT, "topic": str(topic).strip()}},
    }


def compact_association(subject: str, association: str) -> str:
    subject, association = str(subject).strip(), str(association).strip()
    if not subject or not association:
        raise WorldBuilderError("compact association requires both subject and association")
    return f"{subject}({association})"


def validate_redirection_strategy(value: str) -> str:
    normalized = str(value).strip().casefold()
    if normalized not in REDIRECTION_STRATEGIES:
        raise WorldBuilderError(f"redirection strategy must be one of {sorted(REDIRECTION_STRATEGIES)}")
    return normalized


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest="command", required=True)
    c = sub.add_parser("check-cliches"); c.add_argument("--text", required=True)
    d = sub.add_parser("check-description"); d.add_argument("--text", required=True)
    t = sub.add_parser("check-trait-adjectives"); t.add_argument("--text", required=True)
    s = sub.add_parser("check-rule-consistency"); s.add_argument("--file", required=True, help="JSON with {first_message, rules:[{name,text}]}")
    f = sub.add_parser("check-rule-framing"); f.add_argument("--text", required=True)
    a = sub.add_parser("association"); a.add_argument("--subject", required=True); a.add_argument("--association", required=True)
    r = sub.add_parser("redirection"); r.add_argument("--strategy", required=True)
    args = p.parse_args()
    try:
        if args.command == "check-cliches":
            result = validate_dialogue_examples(args.text)
            print(json.dumps(result, ensure_ascii=False, indent=2)); return 0 if result["status"] == "passed" else 2
        if args.command == "check-description":
            result = validate_description_voice(args.text)
            print(json.dumps(result, ensure_ascii=False, indent=2)); return 0 if result["status"] == "passed" else 2
        if args.command == "check-trait-adjectives":
            result = validate_trait_adjectives(args.text)
            print(json.dumps(result, ensure_ascii=False, indent=2)); return 0 if result["status"] == "passed" else 2
        if args.command == "check-rule-framing":
            result = validate_rule_framing(args.text)
            print(json.dumps(result, ensure_ascii=False, indent=2)); return 0 if result["status"] == "passed" else 2
        if args.command == "check-rule-consistency":
            payload = json.loads(__import__('pathlib').Path(args.file).read_text(encoding="utf-8"))
            result = validate_first_message_rules(payload.get("first_message") or "", payload.get("rules") or [])
            print(json.dumps(result, ensure_ascii=False, indent=2)); return 0 if result["status"] == "passed" else 2
        if args.command == "association":
            print(compact_association(args.subject, args.association)); return 0
        print(validate_redirection_strategy(args.strategy)); return 0
    except WorldBuilderError as exc:
        print(f"ERROR: {exc}", file=__import__('sys').stderr); return 1


if __name__ == "__main__":
    raise SystemExit(main())
