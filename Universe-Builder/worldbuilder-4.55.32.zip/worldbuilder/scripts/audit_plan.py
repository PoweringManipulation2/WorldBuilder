#!/usr/bin/env python3
"""Create exact, hash-bound assignments for all four WorldBuilder auditors."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import secrets
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from entry_naming import normalize_build_output, validate_build_output
from pipeline_stage_gate import advance as advance_pipeline_stage
from pipeline_stage_gate import restamp as restamp_pipeline_stage
from pipeline_stage_gate import load_ledger as load_pipeline_ledger
from wb_common import (
    step_driver_pointer,
    AUDIT_LENSES,
    WorldBuilderError,
    atomic_write_json,
    canonical_entry_identity,
    iter_entries,
    load_build_state,
    load_json,
    resolve_state_path,
    sha256_file,
)
from change_set import CONTRACT as CHANGE_SET_CONTRACT, change_set_from_patch_log
from card_text_collision import analyze as analyze_card_text_collisions
from graphics_designer import analyze_artifact_regex
from ground_truth_graph import analyze as analyze_ground_truth_graph
from prevent_recursion_candidates import (
    book_entries,
    cascade_protected_uids,
    compute_downstream_counts,
    era_root_uids_from_manifest,
    find_prevent_recursion_candidates,
)
from plan_reconciliation import analyze as analyze_plan_reconciliation

LENS_SCOPES: dict[str, dict[str, Any]] = {
    "compass": {
        "title": "Compass",
        "purpose": "settings, source stance, schema, card/character planning, budget and dynamic-state lineage, manifest, and requested-scope compliance",
        "checks": [
            "settings-lock", "source-stance", "schema-routing", "manifest-coverage",
            "mode-contract", "entry-label-contract", "card-shell-plan", "character-plan-lineage", "placement-plan-lineage", "budget-plan-lineage", "dynamic-state-plan-lineage", "integration-plan-lineage", "budget-profile", "field-routing", "card-routing", "field-registry", "target-compatibility", "era-plan-fidelity", "required-fields", "character-state-ownership", "canonical-character-routing", "fixed-scenario-approval", "greeting-policy", "dialogue-example-policy", "field-duplication", "output-format", "scope-drift",
        ],
    },
    "weaver": {
        "title": "Weaver",
        "purpose": "activation, recursion, character relationship triggers, inclusion groups, probability, timed effects, filters, triggers, placement, card-text key collisions, activation simulations, and token architecture",
        "checks": [
            "primary-keys", "secondary-keys", "scenario-matching", "era-context-activation", "selective-activation", "relationship-activation-triggers", "required-character-emits", "inclusion-groups", "activation-graph", "recursion", "groups",
            "recursion-safety", "entry-order", "placement", "influence-model", "target-placement-compatibility", "dead-entries",
            "overactivation", "always-on-pressure", "dynamic-protected-entry-safety", "group-selection", "group-scoring", "probability", "timed-effects", "matching-sources", "character-filters", "generation-triggers", "automation-registry", "outlet-consumers", "constant-budget", "entry-pressure", "activation-simulations", "pruning-receipts", "token-pressure",
        ],
    },
    "scout": {
        "title": "Scout",
        "purpose": "discovery breadth, inventory/state coverage, source coverage, pruning scope preservation, and omitted entities or relationships",
        "checks": [
            "discovery-receipt", "source-class-coverage", "inventory-breadth", "omitted-entities", "dynamic-use-coverage",
            "source-provenance-separation", "missing-character-states", "aliases-forms", "locations-factions", "events-concepts", "relationship-knowledge-coverage", "source-coverage", "entity-state-coverage", "missing-eras", "missing-relationship-states", "pruning-scope-loss", "deferred-exclusions",
        ],
    },
    "warden": {
        "title": "Warden",
        "purpose": "identity/state ownership, protected distinctions, chronology, directed relationships, containment, and graph consistency",
        "checks": [
            "id-integrity", "ids", "alias-resolution", "previous-label-preservation", "character-state-ownership", "era-plan", "life-death-state", "knowledge-state", "secrets-known-unknown", "future-event-leakage", "temporal-leakage", "chronology", "relationships", "directed-relationship-consistency",
            "faction-membership", "location-containment", "dangling-references",
            "protected-budget-categories", "protected-pruning-survival", "protected-dynamic-state-survival", "greeting-variant-bindings", "cross-entry-contradictions", "recursion-map-consistency",
        ],
    },
}


AUDIT_PLAN_VERSION = 4


AUDIT_ASSIGNMENT_VERSION = 4


def canonical_sha(value: Any) -> str:
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def rel(path: Path, root: Path) -> str:
    return str(path.relative_to(root)).replace("\\", "/")


def entry_inventory(data: Any) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for ref in iter_entries(data):
        identity = canonical_entry_identity(ref.entry)
        if identity is None:
            raise WorldBuilderError(f"audit target contains an entry without stable identity at {ref.path}")
        name = str(ref.entry.get("name") or ref.entry.get("comment") or ref.entry.get("title") or identity).strip()
        out.append({"uid": identity, "name": name, "path": ref.path})
    if not out:
        raise WorldBuilderError("audit target contains no entries")
    return out


def state_path_for(root: Path, state: dict[str, Any], key: str, fallback: str) -> Path:
    configured = resolve_state_path(root, state, key, required=False)
    return configured or (root / fallback).resolve()


def audit_plan_executed(plan_data: dict[str, Any], findings_root: Path, runtime_root: Path) -> bool:
    """True when the plan's run left lens evidence on disk.

    A plan that was created but never dispatched (no lens ran) must not consume
    an audit iteration; the ceiling counts executed rounds only. Evidence is the
    run id the plan minted appearing in a lens result or runtime receipt. An
    unreadable or ambiguous file counts as evidence: for a ceiling, the failure
    direction that blocks is the safe one."""
    run_id = str(plan_data.get("audit_run_id") or "")
    if not run_id:
        return True
    for directory in (findings_root, runtime_root):
        if not directory.is_dir():
            continue
        for path in sorted(directory.glob("*.json")):
            try:
                text = path.read_text(encoding="utf-8")
            except OSError:
                return True
            if run_id in text:
                return True
    return False


def load_plan_run_id(plan_path: Path) -> str | None:
    try:
        data = load_json(plan_path)
    except (OSError, json.JSONDecodeError, WorldBuilderError):
        return None
    if isinstance(data, dict):
        run_id = data.get("audit_run_id")
        return str(run_id) if isinstance(run_id, str) and run_id else None
    return None


def count_prior_audit_plans(plan_path: Path, assignments_root: Path, stage_slug: str,
                            findings_root: Path, runtime_root: Path) -> int:
    """The on-disk iteration ledger: executed rounds only.

    Counting files rather than storing a counter keeps replay safe, but a plan
    that was created and then never dispatched must not burn an iteration: it
    is archived with a round-execution marker recording that nothing ran, and
    only rounds whose marker says executed count. A marker that is missing
    (pre-marker archives) or unreadable counts, conservatively, so an old
    over-count can never silently become extra headroom."""
    count = 0
    if plan_path.exists():
        run_id = load_plan_run_id(plan_path)
        if run_id is None or audit_plan_executed({"audit_run_id": run_id}, findings_root, runtime_root):
            count += 1
    if assignments_root.exists():
        for archive in sorted(assignments_root.glob(f"round*/audit-{stage_slug}-plan.json")):
            marker_path = archive.parent / "plan-execution.json"
            if not marker_path.exists():
                count += 1
                continue
            try:
                marker = load_json(marker_path)
            except (OSError, json.JSONDecodeError, WorldBuilderError):
                count += 1
                continue
            if not isinstance(marker, dict) or marker.get("executed") is not False:
                count += 1
    return count


def archive_prior_audit_plan(plan_path: Path, assignments_root: Path, stage_slug: str,
                             findings_root: Path, runtime_root: Path) -> None:
    """Move the prior canonical plan into its round archive before the new plan
    replaces it, with a marker recording whether that round ever ran."""
    if not plan_path.exists():
        return
    existing_rounds = sorted(p for p in assignments_root.glob("round*") if p.is_dir())
    target = assignments_root / f"round{len(existing_rounds) + 1}" / f"audit-{stage_slug}-plan.json"
    if target.exists():
        return
    target.parent.mkdir(parents=True, exist_ok=True)
    run_id = load_plan_run_id(plan_path)
    executed = run_id is None or audit_plan_executed({"audit_run_id": run_id}, findings_root, runtime_root)
    atomic_write_json(target.parent / "plan-execution.json", {
        "kind": "worldbuilder-audit-round-execution",
        "stage": stage_slug,
        "audit_run_id": run_id,
        "executed": bool(executed),
        "recorded_at": datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z"),
    })
    os.replace(plan_path, target)


def audit_ceiling_findings(findings_root: Path) -> list[dict[str, str]]:
    """Read a stage's current findings files for the refusal message and record."""
    rows: list[dict[str, str]] = []
    if not findings_root.exists():
        return rows
    for lens in AUDIT_LENSES:
        path = findings_root / f"{lens}-findings.json"
        if not path.exists():
            continue
        try:
            data = load_json(path)
        except (OSError, json.JSONDecodeError):
            continue
        findings = data.get("findings") if isinstance(data, dict) else None
        if not isinstance(findings, list):
            continue
        for finding in findings:
            if isinstance(finding, dict):
                rows.append({
                    "lens": lens,
                    "finding_id": str(finding.get("finding_id", "")),
                    "severity": str(finding.get("severity", "")),
                    "summary": str(finding.get("summary", ""))[:200],
                })
    return rows


def load_patch_log_records(path: Path) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    for number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        try:
            row = json.loads(line)
        except json.JSONDecodeError as exc:
            raise WorldBuilderError(f"patch-log line {number} is invalid JSON: {exc}") from exc
        if not isinstance(row, dict):
            raise WorldBuilderError(f"patch-log line {number} must be an object")
        records.append(row)
    return records


def claimed_fix_refs(root: Path, state: dict[str, Any]) -> set[str]:
    """Finding ids the applied patches claim to have addressed."""
    patch_log_path = resolve_state_path(root, state, "patch_log", required=False) or (root / ".work/patch-log.jsonl").resolve()
    refs: set[str] = set()
    if not patch_log_path.exists():
        return refs
    try:
        for record in load_patch_log_records(patch_log_path):
            ref = record.get("finding_ref")
            if isinstance(ref, str) and ref.strip():
                refs.add(ref.strip())
    except (OSError, WorldBuilderError):
        return set()
    return refs


def derive_and_write_change_set(root: Path, state: dict[str, Any], target: Path, output: Path) -> Path:
    """Batch 59: derive the scoped re-audit delta from the patch log itself.
    Failure here is fail-safe material: the caller falls back to a full run."""
    patch_log_path = resolve_state_path(root, state, "patch_log", required=False) or (root / ".work/patch-log.jsonl").resolve()
    if not patch_log_path.exists():
        raise WorldBuilderError("no patch log exists to derive a delta from")
    records = load_patch_log_records(patch_log_path)
    if not records:
        raise WorldBuilderError("the patch log is empty; there is no delta to derive")
    manifest_path = resolve_state_path(root, state, "manifest", required=False)
    manifest_data = load_json(manifest_path) if manifest_path and manifest_path.exists() else None
    change_set = change_set_from_patch_log(records, load_json(target), manifest=manifest_data)
    if change_set.get("structural"):
        raise WorldBuilderError("the patch log touched a non-entry path, so a structural change forces a full re-audit")
    if not change_set.get("changed_uids") and not change_set.get("neighbour_affected_uids"):
        raise WorldBuilderError("the patch log produced no changed or neighbour-affected UIDs")
    atomic_write_json(output, change_set)
    return output


def resolve_audit_ceiling(args, root: Path, state: dict[str, Any], build_id: str) -> tuple[int, int, Path]:
    """Batch 59: compute the on-disk iteration ledger and refuse past the ceiling.
    Returns (iteration, max_iterations, plan_path); writes the refusal record and
    names the outstanding findings when the next iteration would exceed the cap."""
    plan_key = "pre_generation_audit_plan" if args.stage == "pre-generation" else "post_generation_audit_plan"
    plan_path = state_path_for(root, state, plan_key, f".work/audit-{args.stage}-plan.json")
    assignments_root = state_path_for(root, state, "audit_assignments", ".work/audit-assignments") / args.stage
    findings_root = state_path_for(root, state, "findings", ".work/findings") / args.stage
    runtime_root = state_path_for(root, state, "audit_runtime", ".work/audit-runtime") / args.stage
    max_iterations = int((state.get("settings") or {}).get("audit_max_iterations", 3))
    prior_plan_count = count_prior_audit_plans(plan_path, assignments_root, args.stage, findings_root, runtime_root)
    iteration = prior_plan_count + 1
    if iteration > max_iterations:
        findings = audit_ceiling_findings(findings_root)
        atomic_write_json(plan_path.parent / f"audit-{args.stage}-ceiling.json", {
            "kind": "worldbuilder-audit-ceiling",
            "stage": args.stage,
            "build_id": build_id,
            "plan_count": prior_plan_count,
            "next_iteration": iteration,
            "max_iterations": max_iterations,
            "refused_at": datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z"),
            "findings": findings,
        })
        detail = "; ".join(f"{row['lens']} {row['finding_id']} [{row['severity']}]" for row in findings) or "no readable findings files"
        raise WorldBuilderError(
            f"audit iteration ceiling reached for {args.stage}: next iteration {iteration} exceeds "
            f"audit_max_iterations={max_iterations}. Outstanding findings from the previous run: {detail}. "
            "Raise --audit-max-iterations (band 1-5) via `settings_preset.py set --build-state <build-state.json> "
            "--audit-max-iterations N`, or resolve the findings manually."
        )
    return iteration, max_iterations, plan_path


def resolve_audit_scope(args, *, iteration: int, root: Path, state: dict[str, Any], target: Path,
                        full_inventory: list[dict[str, Any]], change_set_output: Path):
    """Batch 59: resolve auto/full/changed into the effective mode plus its scoped
    inputs. Any failure to derive a delta under auto falls back to a full run with
    the reason recorded, never to a silently narrowed audit."""
    scope_mode = args.scope
    scope_fallback_reason: str | None = None
    if scope_mode == "auto":
        scope_mode = "full" if iteration == 1 else "changed"
    if scope_mode != "changed":
        return scope_mode, None, None, None, full_inventory
    change_set_path: Path | None = None
    if args.change_set:
        change_set_path = Path(args.change_set).expanduser().resolve()
        if not change_set_path.exists():
            raise WorldBuilderError(f"--change-set path does not exist: {change_set_path}")
    elif args.scope == "changed":
        raise WorldBuilderError("--scope changed requires --change-set <path>")
    try:
        if change_set_path is None:
            change_set_path = derive_and_write_change_set(root, state, target, change_set_output)
        change_set_data = load_json(change_set_path)
        if change_set_data.get("contract") != CHANGE_SET_CONTRACT:
            raise WorldBuilderError(f"--change-set is not a recognized change set (contract={change_set_data.get('contract')!r})")
        # Neighbour rule (Batch 12 guard): treated as changed at this
        # phase level, not merely "nearby": entry_cycle_gate's
        # reset-all-on-neighbour-change is correct for slices, and an
        # audit lens is exactly this kind of slice-level concern.
        scoped_uids = sorted(set(change_set_data.get("changed_uids", [])) | set(change_set_data.get("neighbour_affected_uids", [])))
        if not scoped_uids:
            raise WorldBuilderError("--scope changed but the change set has no changed or neighbour-affected UIDs")
        scoped_inventory = [row for row in full_inventory if str(row["uid"]) in scoped_uids]
        if not scoped_inventory:
            raise WorldBuilderError(
                "--scope changed matched none of the target's current entries: the change set may be stale"
            )
    except (WorldBuilderError, OSError, ValueError) as exc:
        if args.scope == "changed":
            raise
        scope_fallback_reason = f"delta could not be derived, audit ran full: {exc}"
        return "full", scope_fallback_reason, None, None, full_inventory
    return "changed", None, sha256_file(change_set_path), scoped_uids, scoped_inventory


def collect_prior_findings(findings_root: Path, claimed_refs: set[str]) -> tuple[dict[str, list[dict[str, str]]], dict[str, list[str]]]:
    """Batch 59: each lens's previous findings, each with the fix's claimed status,
    plus the ids this run must confirm resolved or still open."""
    prior_findings_by_lens: dict[str, list[dict[str, str]]] = {}
    verify_ids_by_lens: dict[str, list[str]] = {}
    for lens in AUDIT_LENSES:
        lens_rows: list[dict[str, str]] = []
        findings_path = findings_root / f"{lens}-findings.json"
        lens_findings: list[Any] = []
        if findings_path.exists():
            try:
                data = load_json(findings_path)
            except (OSError, json.JSONDecodeError):
                data = None
            if isinstance(data, dict) and isinstance(data.get("findings"), list):
                lens_findings = data["findings"]
        for finding in lens_findings:
            if not isinstance(finding, dict):
                continue
            finding_id = str(finding.get("finding_id", "")).strip()
            if not finding_id:
                continue
            lens_rows.append({
                "finding_id": finding_id,
                "severity": str(finding.get("severity", "")),
                "status": "claimed_fixed" if finding_id in claimed_refs else "open",
            })
        prior_findings_by_lens[lens] = lens_rows
        verify_ids_by_lens[lens] = [row["finding_id"] for row in lens_rows]
    return prior_findings_by_lens, verify_ids_by_lens


def add_card_text_collision_check(assignment: dict[str, Any], lens: str, report: dict[str, Any] | None) -> None:
    """Bind the deterministic card-text collision report to Weaver when applicable."""
    if lens != "weaver" or not isinstance(report, dict) or not report.get("applicable"):
        return
    assignment["expected_checks"] = list(assignment.get("expected_checks") or []) + ["card-text-key-collisions"]
    deterministic = dict(assignment.get("deterministic_findings") or {})
    deterministic["card_text_key_collisions"] = report
    assignment["deterministic_findings"] = deterministic


def add_regex_authoring_check(assignment: dict[str, Any], lens: str, report: dict[str, Any] | None) -> None:
    if lens != "weaver" or not isinstance(report, dict) or not report.get("applicable"):
        return
    assignment["expected_checks"] = list(assignment.get("expected_checks") or []) + ["regex-authoring-safety"]
    deterministic = dict(assignment.get("deterministic_findings") or {})
    deterministic["regex_authoring"] = report
    assignment["deterministic_findings"] = deterministic


def add_ground_truth_graph_check(assignment: dict[str, Any], lens: str, report: dict[str, Any] | None) -> None:
    """Bind content-derived activation diagnostics to Weaver post-generation audits."""
    if lens != "weaver" or not isinstance(report, dict) or not report.get("applicable"):
        return
    assignment["expected_checks"] = list(assignment.get("expected_checks") or []) + ["ground-truth-activation-graph"]
    deterministic = dict(assignment.get("deterministic_findings") or {})
    deterministic["ground_truth_activation_graph"] = report
    assignment["deterministic_findings"] = deterministic


def add_prevent_recursion_candidates_check(assignment: dict[str, Any], lens: str, report: dict[str, Any] | None) -> None:
    """Bind foundational prevent_recursion candidates to Weaver post-generation audits."""
    if lens != "weaver" or not isinstance(report, dict) or not report.get("applicable"):
        return
    assignment["expected_checks"] = list(assignment.get("expected_checks") or []) + ["prevent-recursion-candidates"]
    deterministic = dict(assignment.get("deterministic_findings") or {})
    deterministic["prevent_recursion_candidates"] = report
    assignment["deterministic_findings"] = deterministic


def add_plan_reconciliation_checks(assignment: dict[str, Any], lens: str, report: dict[str, Any] | None) -> None:
    """Bind Batch-42 measured facts to the two lenses they offload work from."""
    if not isinstance(report, dict) or not report.get("applicable"):
        return
    deterministic = dict(assignment.get("deterministic_findings") or {})
    if lens == "scout":
        entry_count = report.get("entry_count") if isinstance(report.get("entry_count"), dict) else {}
        if entry_count.get("status") == "no_declared_plan_found":
            return
        assignment["expected_checks"] = list(assignment.get("expected_checks") or []) + ["plan-entry-count-reconciliation"]
    elif lens == "weaver":
        token_budget = report.get("token_budget") if isinstance(report.get("token_budget"), dict) else {}
        if token_budget.get("status") == "not_applicable":
            return
        assignment["expected_checks"] = list(assignment.get("expected_checks") or []) + ["token-budget-reconciliation"]
    else:
        return
    deterministic["plan_reconciliation"] = report
    assignment["deterministic_findings"] = deterministic


def guard_adapter_after_normalize(root: Path, state: dict[str, Any], target: Path, before_sha: str) -> None:
    """Batch 62: planning must not strand a runtime-adapter receipt.

    When this planning step re-normalizes the audit target, the target's bytes
    change late; an adapter receipt that already bound the previous bytes then
    fails delivery [4/11] as stale with no clue where it happened. Fail loudly
    here instead, before a plan is written, naming the recovery command.
    Normalization is idempotent, so the re-run after a fresh export changes
    nothing."""
    after_sha = sha256_file(target)
    if after_sha == before_sha:
        return
    receipt_path = resolve_state_path(root, state, "runtime_adapter_receipt", required=False)
    if receipt_path is None or not receipt_path.exists():
        return
    try:
        receipt = load_json(receipt_path)
    except (OSError, json.JSONDecodeError):
        return
    if not isinstance(receipt, dict):
        return
    if str(receipt.get("source_sha256") or "").lower() != before_sha.lower():
        return
    raise WorldBuilderError(
        f"planning re-normalized {target.name}, but the runtime adapter receipt is bound to its previous "
        "bytes at source; delivery [4/11] would fail as stale. Re-run `runtime_target_adapter.py export` "
        "and `validate` for this build, then re-run this planning command; normalization is idempotent, "
        "so the target will not move again."
    )


def check_creator_notes_freshness(root: Path, state: dict[str, Any], target: Path, target_data: dict[str, Any]) -> None:
    """Batch 62: detect a stale Creator Notes stats block here, at audit planning,
    instead of at delivery [1/11] after the adapter and audit receipts have
    already bound the old bytes. Only fires when the block exists and is stale or
    carries a placeholder; a missing block stays the delivery gate's concern."""
    from creator_notes_stats import BLOCK_BEGIN, verify_notes_block
    payload = target_data.get("data") if isinstance(target_data.get("data"), dict) else target_data
    if not isinstance(payload, dict):
        return
    problems = verify_notes_block(payload)
    if not problems:
        return
    notes = payload.get("creator_notes")
    notes = notes if isinstance(notes, str) else ""
    if BLOCK_BEGIN not in notes:
        return
    command = f"{sys.executable or 'python'} {Path(__file__).resolve().parent / 'creator_notes_stats.py'} --input {target} --write"
    budget = resolve_state_path(root, state, "budget_output_receipt", required=False)
    placement = resolve_state_path(root, state, "placement_output_receipt", required=False)
    if budget is not None and budget.exists():
        command += f" --budget-receipt {budget}"
    if placement is not None and placement.exists():
        command += f" --placement-receipt {placement}"
    raise WorldBuilderError(
        "the target's Creator Notes stats block is stale: " + "; ".join(problems) +
        ". Refresh it before the audit and adapter bind these bytes: " + command
    )


def default_post_generation_target(state: dict[str, Any], final: Path | None, merge: Path | None) -> Path | None:
    """Batch 62: the default audit target follows delivery.

    Delivery binds the post-generation audit receipt to paths.final_output, so
    once the runtime adapter has rendered the final artifact the default must
    be that artifact, not the merge input. Before the adapter has run (or when
    no final artifact exists yet), the merge input remains the target."""
    phase_gated = bool(state.get("pipeline", {}).get("requires_phase_gates"))
    adapter_rendered = str((state.get("status") or {}).get("runtime_adapter", "not_required")) != "not_required"
    if phase_gated and merge and merge.exists() and not (adapter_rendered and final and final.exists()):
        return merge
    return final if final and final.exists() else merge


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--build-state", required=True)
    parser.add_argument("--stage", required=True, choices=["pre-generation", "post-generation"])
    parser.add_argument("--target", help="Override target; must stay inside the build workspace")
    parser.add_argument("--execution-mode", choices=["independent", "consolidated"], default="independent", help="Run four separate child jobs or one consolidated job that still emits four separate lens proofs")
    parser.add_argument("--scope", choices=["auto", "full", "changed"], default="auto", help="Batch 59: 'auto' (default) plans iteration 1 as 'full' and later iterations as 'changed', deriving the delta from the patch log with a full-run fallback. Batch 12: an explicit 'changed' limits the four LLM lenses to the change set's affected UIDs plus neighbours. Corpus-wide deterministic checks (soul_contract, budget simulations, era-bleed, activation reachability) always run full regardless of this flag; they are script passes, not child agents, and scoping them would not save the cost this flag exists to save.")
    parser.add_argument("--change-set", help="Path to a change_set.py-produced change set JSON. Required when --scope changed.")
    args = parser.parse_args()
    try:
        state_path = Path(args.build_state).resolve()
        root, state = load_build_state(state_path)
        build_id = str(state.get("build_id", "")).strip()
        if not build_id:
            raise WorldBuilderError("build-state.json has no build_id")

        # Batch 59: the iteration ledger is derived from disk (the canonical plan
        # plus round archives), never a mutable counter in build-state.json.
        iteration, max_iterations, audit_plan_path = resolve_audit_ceiling(args, root, state, build_id)

        stage_slug = args.stage
        if args.target:
            target = Path(args.target).expanduser().resolve()
        elif args.stage == "pre-generation":
            target = resolve_state_path(root, state, "manifest")
        else:
            final = resolve_state_path(root, state, "final_output", required=False)
            merge = resolve_state_path(root, state, "merge_input", required=False)
            target = default_post_generation_target(state, final, merge)
            if target is None:
                raise WorldBuilderError("post-generation audit has no final_output or merge_input target")
        try:
            target.relative_to(root)
        except ValueError as exc:
            raise WorldBuilderError("audit target must stay inside the build workspace") from exc
        if not target.exists():
            raise WorldBuilderError(f"audit target is missing: {target}")
        if args.stage == "post-generation":
            target_before_sha = sha256_file(target)
            try:
                validate_build_output(state_path, target)
            except WorldBuilderError:
                normalize_build_output(state_path, target, write_receipt=True)
            guard_adapter_after_normalize(root, state, target, target_before_sha)
            # Batch 12 fix: entry_names_normalized may already be recorded
            # from an earlier run of this exact stage: a normal re-plan,
            # or (the case this exists for) re-planning after a post-seal
            # amendment changed the target's bytes. advance() on an
            # already-recorded stage only calls verify_chain (confirm the
            # OLD evidence still matches); it never re-stamps, and
            # correctly fails here since the bytes just changed on purpose.
            # restamp() is what this code has always actually needed: it
            # re-hashes entry_names_normalized's own evidence against the
            # CURRENT target without touching verify_chain or any other
            # stage's receipt, including merge_complete's.
            root, state = load_build_state(state_path)
            ledger = load_pipeline_ledger(root, state)
            already_recorded = any(
                isinstance(row, dict) and row.get("stage") == "entry_names_normalized"
                for row in (ledger.get("stages") or [])
            )
            pending_amendment = (state.get("amendment") or {}).get("pending") if isinstance(state.get("amendment"), dict) else None
            if already_recorded and isinstance(pending_amendment, dict) and args.scope == "changed":
                # The sealed base chain is immutable during an additive amendment.
                # Changed-slice proof is recorded in the amendment sub-ledger instead.
                pass
            elif already_recorded:
                restamp_pipeline_stage(state_path, "entry_names_normalized", target=target)
            else:
                advance_pipeline_stage(state_path, "entry_names_normalized", target)
            root, state = load_build_state(state_path)
        target_data = load_json(target)
        if args.stage == "post-generation":
            check_creator_notes_freshness(root, state, target, target_data)
        inventory = entry_inventory(target_data)
        card_text_collision_report = analyze_card_text_collisions(target_data) if args.stage == "post-generation" else None
        regex_authoring_report = analyze_artifact_regex(target_data) if args.stage == "post-generation" else None
        full_inventory = inventory
        scope_mode, scope_fallback_reason, change_set_sha, scoped_uids, inventory = resolve_audit_scope(
            args,
            iteration=iteration,
            root=root,
            state=state,
            target=target,
            full_inventory=full_inventory,
            change_set_output=audit_plan_path.parent / f"audit-{stage_slug}-change-set.json",
        )

        target_sha = sha256_file(target)
        manifest = resolve_state_path(root, state, "manifest")
        manifest_sha = sha256_file(manifest) if manifest.exists() else None
        manifest_data = load_json(manifest) if manifest.exists() else None
        ground_truth_graph_report = (
            analyze_ground_truth_graph(target_data, manifest_data)
            if args.stage == "post-generation" else None
        )
        plan_reconciliation_report = None
        prevent_recursion_report = None
        if args.stage == "post-generation":
            build_list_path = resolve_state_path(root, state, "build_list", required=False)
            budget_plan_path = resolve_state_path(root, state, "budget_plan", required=False)
            build_list_text = (
                build_list_path.read_text(encoding="utf-8")
                if build_list_path is not None and build_list_path.exists() else None
            )
            budget_plan_data = (
                load_json(budget_plan_path)
                if budget_plan_path is not None and budget_plan_path.exists() else None
            )
            plan_reconciliation_report = analyze_plan_reconciliation(
                target_data,
                build_list_text=build_list_text,
                budget_plan=budget_plan_data,
                manifest=manifest_data,
            )

            root_uids = era_root_uids_from_manifest(manifest_data)
            rows = book_entries(target_data)
            if root_uids and rows:
                counts = compute_downstream_counts(rows, root_uids)
                protected = cascade_protected_uids(manifest_data)
                candidates = find_prevent_recursion_candidates(rows, counts, exclude_uids=protected)
                prevent_recursion_report = {
                    "applicable": True,
                    "root_uids": root_uids,
                    "excluded_protected": protected,
                    "candidate_count": len(candidates),
                    "candidates": candidates,
                }

        def existing_artifact(key: str) -> dict[str, str] | None:
            path = resolve_state_path(root, state, key, required=False)
            if path is None or not path.exists() or not path.is_file():
                return None
            return {"key": key, "path": rel(path, root), "sha256": sha256_file(path)}

        common_support = [
            item for item in (
                existing_artifact("manifest"), existing_artifact("build_list"), existing_artifact("recursion_map"),
                existing_artifact("pipeline_registry"), existing_artifact("integration_plan"), existing_artifact("integration_planning_receipt"),
                existing_artifact("card_shell_plan"), existing_artifact("entry_naming_planning_receipt"), existing_artifact("entry_naming_output_receipt"), existing_artifact("character_plan"), existing_artifact("era_plan"), existing_artifact("placement_plan"), existing_artifact("placement_planning_receipt"), existing_artifact("budget_plan"), existing_artifact("budget_planning_receipt"), existing_artifact("budget_output_receipt"), existing_artifact("dynamic_state_plan"), existing_artifact("dynamic_state_planning_receipt"), existing_artifact("dynamic_state_output_receipt"), existing_artifact("architecture_planning_receipt"),
            ) if item is not None
        ]
        lens_support: dict[str, list[dict[str, str]]] = {
            "compass": list(common_support),
            "weaver": list(common_support),
            "scout": list(common_support) + [
                item for item in (existing_artifact("discovery_receipt"), existing_artifact("discovery_index")) if item is not None
            ],
            "warden": list(common_support),
        }

        assignments_root = state_path_for(root, state, "audit_assignments", ".work/audit-assignments") / stage_slug
        findings_root = state_path_for(root, state, "findings", ".work/findings") / stage_slug
        runtime_root = state_path_for(root, state, "audit_runtime", ".work/audit-runtime") / stage_slug
        assignments_root.mkdir(parents=True, exist_ok=True)
        findings_root.mkdir(parents=True, exist_ok=True)
        runtime_root.mkdir(parents=True, exist_ok=True)
        plan_key = "pre_generation_audit_plan" if args.stage == "pre-generation" else "post_generation_audit_plan"
        plan_path = state_path_for(root, state, plan_key, f".work/audit-{stage_slug}-plan.json")

        audit_run_id = secrets.token_hex(16)
        created_at = datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")
        scope_core = {
            "kind": "worldbuilder-audit-scope",
            "scope_version": 3,
            "build_id": build_id,
            "audit_run_id": audit_run_id,
            "stage": args.stage,
            "target": rel(target, root),
            "target_sha256": target_sha,
            "manifest_sha256": manifest_sha,
            "entries": inventory,
            "lenses": list(AUDIT_LENSES),
            "scope_mode": scope_mode,
            "change_set_sha256": change_set_sha,
            "full_entry_count": len(full_inventory),
            "scoped_entry_count": len(inventory) if scope_mode == "changed" else None,
        }
        scope_sha = canonical_sha(scope_core)
        prior_findings_by_lens: dict[str, list[dict[str, str]]] = {}
        verify_ids_by_lens: dict[str, list[str]] = {}
        if scope_mode == "changed":
            prior_findings_by_lens, verify_ids_by_lens = collect_prior_findings(
                findings_root, claimed_fix_refs(root, state)
            )
        rows: list[dict[str, Any]] = []
        for lens in AUDIT_LENSES:
            spec = LENS_SCOPES[lens]
            assignment_id = f"audit-{stage_slug}-{lens}-{audit_run_id[:8]}"
            output = findings_root / f"{lens}-findings.json"
            runtime = runtime_root / f"{lens}-runtime.json"
            assignment = {
                "assignment_version": AUDIT_ASSIGNMENT_VERSION,
                "created_at": created_at,
                "assignment_id": assignment_id,
                "build_id": build_id,
                "audit_run_id": audit_run_id,
                "role": "audit",
                "requested_model": str((state.get("models") or {}).get("audit", (state.get("models") or {}).get("subagent", "inherit"))),
                "stage": args.stage,
                "lens": lens,
                "auditor": spec["title"],
                "label": spec["title"],
                "taskName": f"audit_{stage_slug.replace('-', '_')}_{lens}",
                "purpose": spec["purpose"],
                "expected_checks": list(spec["checks"]),
                "scope_sha256": scope_sha,
                "target": rel(target, root),
                "target_sha256": target_sha,
                "manifest_sha256": manifest_sha,
                "entries": inventory,
                "scope_mode": scope_mode,
                "change_set_sha256": change_set_sha,
                "iteration": iteration,
                "max_iterations": max_iterations,
                "required_artifacts": lens_support[lens],
                "required_result_schema": "worldbuilder-audit-result-v2",
                "output": rel(output, root),
                "runtime_receipt": rel(runtime, root),
                "expected_end_delimiter": f"END WORLDBUILDER {spec['title'].upper()} AUDIT",
            }
            if scope_mode == "changed":
                assignment.update({
                    "prior_findings": prior_findings_by_lens.get(lens, []),
                    "verify_ids": verify_ids_by_lens.get(lens, []),
                    "regression_uids": list(scoped_uids or []),
                })
            add_card_text_collision_check(assignment, lens, card_text_collision_report)
            add_regex_authoring_check(assignment, lens, regex_authoring_report)
            add_ground_truth_graph_check(assignment, lens, ground_truth_graph_report)
            add_prevent_recursion_candidates_check(assignment, lens, prevent_recursion_report)
            add_plan_reconciliation_checks(assignment, lens, plan_reconciliation_report)
            assignment_path = assignments_root / f"{lens}.json"
            atomic_write_json(assignment_path, assignment)
            rows.append({
                "lens": lens,
                "auditor": spec["title"],
                "assignment_id": assignment_id,
                "assignment": rel(assignment_path, root),
                "assignment_sha256": sha256_file(assignment_path),
                "output": rel(output, root),
                "runtime_receipt": rel(runtime, root),
            })

        plan = {
            "kind": "worldbuilder-audit-plan",
            "plan_version": AUDIT_PLAN_VERSION,
            "created_at": created_at,
            "build_id": build_id,
            "audit_run_id": audit_run_id,
            "stage": args.stage,
            "scope_sha256": scope_sha,
            "scope_mode": scope_mode,
            "change_set_sha256": change_set_sha,
            "iteration": iteration,
            "max_iterations": max_iterations,
            "target": rel(target, root),
            "target_sha256": target_sha,
            "manifest_sha256": manifest_sha,
            "entry_count": len(inventory),
            "full_entry_count": len(full_inventory),
            "required_lenses": list(AUDIT_LENSES),
            "execution_mode": args.execution_mode,
            "assignments": rows,
        }
        if scope_fallback_reason:
            plan["scope_fallback_reason"] = scope_fallback_reason
        archive_prior_audit_plan(plan_path, assignments_root, stage_slug, findings_root, runtime_root)
        atomic_write_json(plan_path, plan)
        audit = state.setdefault("audit", {})
        stage_state = audit.setdefault(args.stage.replace("-", "_"), {})
        stage_state.update({
            "status": "planned",
            "audit_run_id": audit_run_id,
            "plan": rel(plan_path, root),
            "plan_sha256": sha256_file(plan_path),
            "target_sha256": target_sha,
        })
        atomic_write_json(state_path, state)
        print(json.dumps({"status": "planned", "stage": args.stage, "audit_run_id": audit_run_id, "plan": str(plan_path), "execution_mode": args.execution_mode, "auditors": rows}, indent=2))
        return 0
    except (WorldBuilderError, OSError, json.JSONDecodeError, ValueError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        print(step_driver_pointer(), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
