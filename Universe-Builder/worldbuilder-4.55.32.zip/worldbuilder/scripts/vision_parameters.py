#!/usr/bin/env python3
"""Vision subagent parameter helpers (Batch 47).

Real, researched per-model image limits drive dispatch sizing; a model
change invalidates stored limits instead of silently reusing them (the
same re-evaluation discipline Batch 29 established for `vision_capable`
itself); processed-image receipts are verified against the page's real
image count so a silent partial choke is caught, not assumed; and the
stored limits carry the per-session image budget a generation worker
accumulates against, whose stop points are computed from the researched
limit rather than guessed.
"""
from __future__ import annotations

import argparse
import json
import math
import sys
from typing import Any


def required_subagents(image_count: int, max_images_per_request: int, max_concurrent: int | None = None) -> int:
    """ceil(page_image_count / max_images_per_request); only meaningful
    with a researched, real per-request limit, never a guessed one.
    Batch 55: an optional person-set ``max_concurrent`` ceiling caps the
    result independently of the model limit (cost, rate limits, or a slower
    supervised pass); None leaves the dispatch math untouched."""
    if not isinstance(image_count, int) or isinstance(image_count, bool) or image_count < 0:
        raise ValueError("image_count must be a non-negative integer")
    if not isinstance(max_images_per_request, int) or isinstance(max_images_per_request, bool) or max_images_per_request < 1:
        raise ValueError("max_images_per_request must be a positive integer")
    if max_concurrent is not None and (not isinstance(max_concurrent, int) or isinstance(max_concurrent, bool) or max_concurrent < 1):
        raise ValueError("max_concurrent must be a positive integer or None")
    required = math.ceil(image_count / max_images_per_request)
    return min(required, max_concurrent) if max_concurrent is not None else required


def resolve_vision_limits(stored: Any, current_model: str) -> dict[str, Any] | None:
    """Return stored limits only when they belong to the current model.

    A model change returns None so the caller re-researches; stale limits
    from a prior model are never silently reused."""
    if not isinstance(stored, dict):
        return None
    model = str(stored.get("model", "")).strip()
    current = str(current_model).strip()
    if not model or not current or model != current:
        return None
    return stored


def session_image_budget(limits: dict[str, Any], soft_percent: int, cap: int | None = None) -> dict[str, int]:
    """Stop points for one worker's accumulated session, from research only.

    ``hard`` is the researched per-session count, or the person's cap when
    that is lower. ``soft`` is advisory: from it onward the worker finishes
    its current UID and hands off. The per-session count itself is research,
    never a default; a limits object without it is refused here, not filled
    in."""
    researched = limits.get("max_images_per_session") if isinstance(limits, dict) else None
    if not isinstance(researched, int) or isinstance(researched, bool) or researched < 1:
        raise ValueError(
            "limits.max_images_per_session is missing or invalid: research the model's real per-session image limit; never assume one"
        )
    if not isinstance(soft_percent, int) or isinstance(soft_percent, bool) or not 10 <= soft_percent <= 100:
        raise ValueError("soft_percent must be an integer between 10 and 100")
    if cap is not None and (not isinstance(cap, int) or isinstance(cap, bool) or cap < 1):
        raise ValueError("cap must be a positive integer or None")
    hard = min(researched, cap) if cap is not None else researched
    return {"hard": hard, "soft": max(1, hard * soft_percent // 100), "soft_percent": soft_percent, "cap": cap}


def verify_image_coverage(expected_count: int, receipts: list[dict[str, Any]]) -> dict[str, Any]:
    """Compare the page's real image count against what image-processing
    subagents genuinely reported. Fewer processed images than the page
    contains is flagged; a silent partial choke is not coverage."""
    if not isinstance(expected_count, int) or isinstance(expected_count, bool) or expected_count < 0:
        raise ValueError("expected_count must be a non-negative integer")
    if not isinstance(receipts, list):
        raise ValueError("receipts must be a list of {subagent, images_processed} objects")
    rows: list[dict[str, Any]] = []
    total = 0
    for receipt in receipts:
        if not isinstance(receipt, dict):
            raise ValueError("each receipt must be an object with an integer images_processed")
        count = receipt.get("images_processed")
        if not isinstance(count, int) or isinstance(count, bool) or count < 0:
            raise ValueError("each receipt's images_processed must be a non-negative integer")
        total += count
        rows.append({"subagent": receipt.get("subagent"), "images_processed": count})
    missing = max(0, expected_count - total)
    return {
        "kind": "worldbuilder-vision-coverage-check",
        "expected": expected_count,
        "processed": total,
        "missing": missing,
        "excess": max(0, total - expected_count),
        "ok": missing == 0 and total == expected_count,
        "flagged": missing > 0 or total > expected_count,
        "receipts": rows,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    plan = sub.add_parser("plan", help="Compute the required subagent count for a page")
    plan.add_argument("--image-count", type=int, required=True)
    plan.add_argument("--max-images-per-request", type=int, required=True)
    plan.add_argument("--max-concurrent-subagents", type=int, default=None, help="Optional person-set ceiling, independent of the model limit (Batch 55)")
    limits = sub.add_parser("limits", help="Check stored limits against the current model")
    limits.add_argument("--stored", required=True, help="Stored limits JSON (or 'null')")
    limits.add_argument("--current-model", required=True)
    coverage = sub.add_parser("coverage", help="Verify image-processing receipts against the page image count")
    coverage.add_argument("--expected", type=int, required=True)
    coverage.add_argument("--receipts", required=True, help="Receipts JSON array")
    args = parser.parse_args()
    try:
        if args.command == "plan":
            uncapped = required_subagents(args.image_count, args.max_images_per_request)
            required = required_subagents(args.image_count, args.max_images_per_request, args.max_concurrent_subagents)
            result = {
                "required_subagents": required,
                "uncapped_subagents": uncapped,
                "capped": required != uncapped,
                "image_count": args.image_count,
                "max_images_per_request": args.max_images_per_request,
                "max_concurrent_subagents": args.max_concurrent_subagents,
            }
            print(json.dumps(result, indent=2))
            return 0
        if args.command == "limits":
            stored = json.loads(args.stored) if args.stored.strip() != "null" else None
            fresh = resolve_vision_limits(stored, args.current_model)
            print(json.dumps({"fresh": fresh is not None, "limits": fresh, "current_model": args.current_model}, indent=2))
            return 0 if fresh is not None else 1
        receipts = json.loads(args.receipts)
        result = verify_image_coverage(args.expected, receipts)
        print(json.dumps(result, indent=2))
        return 0 if result["ok"] else 1
    except (ValueError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
