#!/usr/bin/env python3
"""Assign stable numeric manifest UIDs through a persistent identity registry."""
from __future__ import annotations
import argparse
import hashlib
import json
import re
import sys
import urllib.parse
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from discovery_plan import canonicalize_url
from wb_common import WorldBuilderError, atomic_write_json, iter_entries, load_build_state, load_json, resolve_state_path, sha256_file

def now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")

def norm(value: Any) -> str:
    return re.sub(r"\s+", " ", str(value or "").strip()).casefold()

def source_urls(entry: dict[str, Any]) -> list[str]:
    raw = entry.get("source_urls") or entry.get("sources") or []
    if isinstance(raw, str): raw = [raw]
    result: list[str] = []
    if isinstance(raw, list):
        for item in raw:
            if isinstance(item, dict): item = item.get("url")
            url = canonicalize_url(item)
            if url and url not in result: result.append(url)
    return result

def identity_key(entry: dict[str, Any]) -> str:
    name = norm(entry.get("name") or entry.get("comment") or entry.get("title"))
    if not name: raise WorldBuilderError("manifest entry requires name/comment/title")
    urls = source_urls(entry)
    if urls:
        page = urllib.parse.urlsplit(urls[0]); basis = f"url:{page.netloc.casefold()}{urllib.parse.unquote(page.path).casefold()}"
    else:
        aliases = entry.get("aliases") if isinstance(entry.get("aliases"), list) else []
        basis = f"name:{name}|aliases:{'|'.join(sorted(norm(item) for item in aliases if norm(item)))}"
    # A shared name or source URL usually means planning accidentally split one
    # real-world referent into two manifest rows, which is exactly what this
    # key is meant to catch. But a name or citation can legitimately belong to
    # two distinct lorebook concepts (a wiki page that both depicts a faction
    # and covers the comic issue introducing it). `disambiguator` is the
    # sanctioned, explicit way to say "yes, same name/source, different
    # canonical thing"; planning must set it deliberately, never blindly.
    disambiguator = norm(entry.get("disambiguator"))
    if disambiguator:
        basis = f"{basis}|disambiguator:{disambiguator}"
    return hashlib.sha256(basis.encode("utf-8")).hexdigest()

def load_registry(path: Path, build_id: str) -> dict[str, Any]:
    if not path.exists(): return {"kind": "worldbuilder-entity-identity-registry", "registry_version": 1, "build_id": build_id, "identities": {}}
    data = load_json(path)
    if not isinstance(data, dict) or data.get("kind") != "worldbuilder-entity-identity-registry" or data.get("build_id") != build_id or not isinstance(data.get("identities"), dict):
        raise WorldBuilderError("identity registry is invalid or belongs to another build")
    return data

def apply(build_state: str) -> dict[str, Any]:
    root, state = load_build_state(build_state); build_id = str(state.get("build_id"))
    manifest_path = resolve_state_path(root, state, "manifest")
    registry_path = resolve_state_path(root, state, "identity_registry", required=False) or (root / ".work" / "entity-identity-registry.json")
    receipt_path = resolve_state_path(root, state, "identity_receipt", required=False) or (root / "artifacts" / "identity-receipt.json")
    manifest = load_json(manifest_path)
    if not isinstance(manifest, dict) or manifest.get("build_id") != build_id: raise WorldBuilderError("manifest is not bound to current build")
    refs = list(iter_entries(manifest))
    if not refs: raise WorldBuilderError("manifest has no entries")
    registry = load_registry(registry_path, build_id); identities = registry["identities"]
    used: dict[int, str] = {}
    for key, row in identities.items():
        if isinstance(row, dict) and isinstance(row.get("uid"), int):
            if row["uid"] in used and used[row["uid"]] != key: raise WorldBuilderError(f"registry repeats UID {row['uid']}")
            used[row["uid"]] = key
    next_uid = max(used, default=-1) + 1; changes: list[dict[str, Any]] = []; seen: set[str] = set()
    seen_paths: dict[str, str] = {}
    for ref in refs:
        entry = ref.entry; key = identity_key(entry)
        if key in seen:
            first_path = seen_paths[key]
            raise WorldBuilderError(
                f"manifest has duplicate canonical identity: {first_path!r} and {ref.path!r} share the same "
                f"name/source basis ({'source URL' if source_urls(entry) else 'name'}: {entry.get('name') or entry.get('comment') or entry.get('title')!r}, "
                f"type {entry.get('type')!r}). If these are genuinely the same real-world thing, merge them into one "
                f"manifest entry. If they are legitimately distinct concepts that happen to share a name or source "
                f"(e.g. a faction and the comic issue that introduces it), set a distinct \'disambiguator\' string on "
                f"each entry to record that this was an intentional, reviewed decision, not a silent workaround."
            )
        seen.add(key); seen_paths[key] = ref.path; row = identities.get(key); existing = entry.get("uid")
        if row is None:
            if isinstance(existing, int) and existing >= 0 and existing not in used: uid = existing
            else:
                while next_uid in used: next_uid += 1
                uid = next_uid; next_uid += 1
            stable_id = "wb-" + key[:20]
            row = {"uid": uid, "stable_id": stable_id, "created_at": now(), "canonical_name": entry.get("name") or entry.get("comment") or entry.get("title"), "source_urls": source_urls(entry)}
            identities[key] = row; used[uid] = key; changes.append({"path": ref.path, "action": "allocated", "uid": uid, "stable_id": stable_id})
        else:
            uid = row.get("uid")
            if not isinstance(uid, int) or uid < 0: raise WorldBuilderError(f"registry identity {key} has invalid UID")
            if isinstance(existing, int) and existing != uid: changes.append({"path": ref.path, "action": "restored", "from": existing, "uid": uid})
        entry["uid"] = uid; entry["stable_entity_id"] = row["stable_id"]
        row.update({"last_seen_at": now(), "canonical_name": entry.get("name") or entry.get("comment") or entry.get("title"), "source_urls": source_urls(entry), "last_type": entry.get("type")})
    # Rewriting the manifest when nothing changed still moves its SHA, because
    # re-serialization can differ in whitespace or key order from whatever wrote it
    # last. Every artifact header that embedded the old SHA then goes stale, and the
    # user chases a hash that changed for no semantic reason. Skip the write when the
    # bytes would be identical.
    manifest_rewritten = False
    predicted = (json.dumps(manifest, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    if hashlib.sha256(predicted).hexdigest() != sha256_file(manifest_path):
        ensure_manifest_mutable(root, state, manifest_path, manifest)
        atomic_write_json(manifest_path, manifest)
        manifest_rewritten = True
    registry["updated_at"] = now(); atomic_write_json(registry_path, registry)
    receipt = {
        "kind": "worldbuilder-manifest-identity-receipt", "receipt_version": 1, "build_id": build_id, "created_at": now(),
        "manifest": str(manifest_path.relative_to(root)).replace("\\", "/"), "manifest_sha256": sha256_file(manifest_path),
        "registry": str(registry_path.relative_to(root)).replace("\\", "/"), "registry_sha256": sha256_file(registry_path),
        "entry_count": len(refs), "uids": sorted(ref.entry["uid"] for ref in refs), "changes": changes,
        "manifest_rewritten": manifest_rewritten,
    }
    atomic_write_json(receipt_path, receipt)

    # planning_gate requires artifacts/build-id.json and nothing produced it, so every
    # build stalled until the user hand-wrote a fingerprint. It is derived entirely from
    # values known here, so this is the correct place to emit it.
    fingerprint_path = resolve_state_path(root, state, "build_id", required=False) or (root / "artifacts" / "build-id.json")
    fingerprint_path.parent.mkdir(parents=True, exist_ok=True)
    atomic_write_json(fingerprint_path, {
        "kind": "worldbuilder-build-identity",
        "receipt_version": 1,
        "build_id": build_id,
        "manifest_sha256": sha256_file(manifest_path),
        "entry_count": len(refs),
        "created_at": now(),
    })

    state.setdefault("lineage", {})["identity_receipt_sha256"] = sha256_file(receipt_path); state["lineage"]["manifest_sha256"] = sha256_file(manifest_path)
    atomic_write_json(Path(build_state).resolve(), state)
    return {"status": "assigned", "receipt": str(receipt_path), "entry_count": len(refs), "changes": len(changes), "manifest_rewritten": manifest_rewritten, "manifest_sha256": sha256_file(manifest_path), "build_fingerprint": str(fingerprint_path)}

def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__); parser.add_argument("--build-state", required=True); args = parser.parse_args()
    try: print(json.dumps(apply(args.build_state), ensure_ascii=False, indent=2)); return 0
    except (WorldBuilderError, OSError, ValueError, json.JSONDecodeError) as exc: print(f"ERROR: {exc}", file=sys.stderr); return 1


def ensure_manifest_mutable(root: Path, state: dict[str, Any], manifest_path: Path, mutated: dict[str, Any]) -> None:
    """Block manifest byte changes once the pipeline has advanced past planning.

    Identity runs are idempotent after the first normalization pass; if this run
    would change manifest bytes while generation-era stages are recorded, every
    downstream hash binding (assignments, evidence, receipts) would silently
    break. The only sanctioned path is an explicit re-baseline."""
    import hashlib as _hashlib
    import json as _json
    from pipeline_stage_gate import STAGES, load_ledger
    predicted = _hashlib.sha256((_json.dumps(mutated, ensure_ascii=False, indent=2) + "\n").encode("utf-8")).hexdigest()
    if predicted == sha256_file(manifest_path):
        return
    ledger = load_ledger(root, state)
    rows = ledger.get("stages") if isinstance(ledger.get("stages"), list) else []
    recorded = [row.get("stage") for row in rows if isinstance(row, dict) and row.get("stage") in STAGES]
    if not recorded:
        return
    frozen_after = STAGES.index("planning_validated")
    if max(STAGES.index(stage) for stage in recorded) <= frozen_after:
        return
    gate = Path(__file__).resolve().parent / "pipeline_stage_gate.py"
    raise WorldBuilderError(
        "manifest is frozen: this identity run would change manifest bytes while pipeline stages beyond planning are recorded, "
        "which breaks every assignment and evidence hash binding. Sanctioned recovery: "
        f"{sys.executable or 'python'} {gate} --build-state <your build-state.json> --invalidate-from planning_validated, then re-run planning_gate.py "
        "and regenerate all assignments. Never edit, 'sync', or permission-lock the manifest with ad-hoc scripts."
    )


if __name__ == "__main__": raise SystemExit(main())
