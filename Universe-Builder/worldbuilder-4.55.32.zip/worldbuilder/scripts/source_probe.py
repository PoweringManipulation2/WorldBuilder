#!/usr/bin/env python3
"""Build an additive, high-recall wiki/source corpus before WorldBuilder planning.

Every available discovery channel contributes to the union.  A fresh sitemap is
never allowed to suppress AllPages, categories, SearXNG, Special:AllPages, or
bounded link crawling.  The probe also records independent page-count estimates
and independent verification samples so discovery_gate.py can distinguish
"workers visited the assigned list" from "the assigned list represents the site".
"""
from __future__ import annotations

import argparse
import concurrent.futures as cf
import gzip
import html.parser
import json
import random
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from collections import deque
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

from discovery_plan import canonicalize_url
from discovery_page_filter import default_policy as default_page_filter_policy, prefilter_urls
from wb_common import WorldBuilderError, atomic_write_json, load_build_state, load_json, resolve_state_path, sha256_file

USER_AGENT = "WorldBuilder-Source-Probe/3.6 (+exhaustive additive wiki discovery)"
MAINTENANCE_CATEGORY = re.compile(
    r"(?:maintenance|stub|articles?|pages?|templates?|files?|images?|wiki|community|cleanup|citation|tracking|hidden|redirects?)",
    re.I,
)
ENTITY_TERMS = (
    "character", "characters", "location", "locations", "faction", "organization",
    "species", "ability", "abilities", "power", "item", "weapon", "artifact",
    "event", "history", "episode", "season", "concept", "terminology", "relationship",
)


def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def fetch_bytes(url: str, timeout: float, retries: int = 2) -> tuple[int, bytes, str | None, str]:
    last: Exception | None = None
    for attempt in range(retries + 1):
        request = urllib.request.Request(
            url,
            headers={"User-Agent": USER_AGENT, "Accept": "application/json, application/xml, text/html, */*"},
        )
        try:
            with urllib.request.urlopen(request, timeout=timeout) as response:
                body = response.read()
                encoding = (response.headers.get("Content-Encoding") or "").casefold()
                final_url = response.geturl()
                if encoding == "gzip" or final_url.casefold().endswith(".gz"):
                    try:
                        body = gzip.decompress(body)
                    except OSError:
                        pass
                return int(getattr(response, "status", 200)), body, response.headers.get("Content-Type"), final_url
        except (urllib.error.URLError, OSError, TimeoutError) as exc:
            last = exc
            if attempt < retries:
                time.sleep(0.4 * (2 ** attempt))
    assert last is not None
    raise last


def fetch_json(url: str, timeout: float) -> dict[str, Any]:
    _, body, _, _ = fetch_bytes(url, timeout)
    value = json.loads(body.decode("utf-8", errors="strict"))
    if not isinstance(value, dict):
        raise WorldBuilderError(f"JSON endpoint did not return an object: {url}")
    return value


def progress(stage: str, detail: str) -> None:
    print(f"[WorldBuilder probe] {stage}: {detail}", file=sys.stderr, flush=True)


def add_params(url: str, params: dict[str, Any]) -> str:
    parsed = urllib.parse.urlsplit(url)
    current = urllib.parse.parse_qsl(parsed.query, keep_blank_values=True)
    current.extend((key, str(value)) for key, value in params.items() if value is not None)
    return urllib.parse.urlunsplit((parsed.scheme, parsed.netloc, parsed.path, urllib.parse.urlencode(current), ""))


def same_host(url: str, host: str) -> bool:
    try:
        return urllib.parse.urlsplit(url).netloc.casefold() == host.casefold()
    except ValueError:
        return False


def infer_api_candidates(base_url: str) -> list[str]:
    parsed = urllib.parse.urlsplit(base_url)
    origin = urllib.parse.urlunsplit((parsed.scheme, parsed.netloc, "", "", ""))
    paths = ["/api.php", "/w/api.php"]
    if parsed.path and parsed.path != "/":
        parent = parsed.path.rstrip("/").rsplit("/", 1)[0]
        if parent:
            paths.insert(0, parent + "/api.php")
    return list(dict.fromkeys(origin + path for path in paths))


def probe_api(candidates: Iterable[str], timeout: float, errors: list[dict[str, str]]) -> tuple[str | None, dict[str, Any] | None, dict[str, Any] | None]:
    for candidate in candidates:
        url = add_params(candidate, {
            "action": "query", "meta": "siteinfo", "siprop": "general|statistics",
            "format": "json", "formatversion": 2,
        })
        try:
            payload = fetch_json(url, timeout)
            query = payload.get("query", {})
            general = query.get("general") if isinstance(query, dict) else None
            statistics = query.get("statistics") if isinstance(query, dict) else None
            if isinstance(general, dict) and general.get("sitename"):
                return candidate, general, statistics if isinstance(statistics, dict) else None
        except Exception as exc:
            errors.append({"source": "mediawiki_api", "url": candidate, "error": str(exc)})
    return None, None, None


def article_url(general: dict[str, Any] | None, base_url: str, title: str) -> str:
    if general:
        server = str(general.get("server") or "").rstrip("/")
        articlepath = str(general.get("articlepath") or "")
        if server and "$1" in articlepath:
            encoded = urllib.parse.quote(title.replace(" ", "_"), safe="/:()!'-,")
            return server + articlepath.replace("$1", encoded)
    parsed = urllib.parse.urlsplit(base_url)
    origin = urllib.parse.urlunsplit((parsed.scheme, parsed.netloc, "", "", ""))
    return origin + "/wiki/" + urllib.parse.quote(title.replace(" ", "_"), safe="/:()!'-,")


def paginate_api(api_url: str, params: dict[str, Any], timeout: float, max_items: int) -> tuple[list[dict[str, Any]], bool]:
    continuation: dict[str, Any] = {}
    values_out: list[dict[str, Any]] = []
    exhausted = False
    while len(values_out) < max_items:
        query = dict(params)
        query.update(continuation)
        query.setdefault("format", "json")
        query.setdefault("formatversion", 2)
        payload = fetch_json(add_params(api_url, query), timeout)
        node: Any = payload.get("query", {})
        list_name = str(params.get("list", ""))
        values = node.get(list_name, []) if isinstance(node, dict) else []
        if not isinstance(values, list):
            raise WorldBuilderError(f"MediaWiki API list={list_name} returned invalid data")
        for item in values:
            if isinstance(item, dict):
                values_out.append(item)
                if len(values_out) >= max_items:
                    break
        if list_name in {"allpages", "alllinks", "allcategories", "categorymembers"}:
            progress(list_name, f"enumerated {len(values_out):,} item(s)")
        continuation = payload.get("continue") if isinstance(payload.get("continue"), dict) else {}
        if not continuation:
            exhausted = True
            break
    return values_out, exhausted


def enumerate_allpages(
    api_url: str,
    general: dict[str, Any] | None,
    base_url: str,
    timeout: float,
    max_pages: int,
    article_estimate: int | None,
) -> dict[str, Any]:
    items, exhausted = paginate_api(
        api_url,
        {"action": "query", "list": "allpages", "apnamespace": 0, "aplimit": "max", "apfilterredir": "nonredirects"},
        timeout,
        max_pages,
    )
    urls: list[dict[str, Any]] = []
    for item in items:
        title = str(item.get("title", "")).strip()
        if title:
            urls.append({"url": article_url(general, base_url, title), "title": title, "pageid": item.get("pageid")})
    count = len(urls)
    reported_total = max(count, article_estimate or 0) or count
    return {
        "urls": urls,
        "listed_count": count,
        "reported_total": reported_total,
        "complete": exhausted and (article_estimate is None or count >= max(0, int(article_estimate) - 2)),
        "truncated": not exhausted,
        "article_estimate": article_estimate,
    }


def enumerate_redirects(
    api_url: str,
    general: dict[str, Any] | None,
    base_url: str,
    timeout: float,
    max_pages: int,
) -> dict[str, Any]:
    """Enumerate namespace-0 redirect titles as alias/alternate-name evidence.

    Redirect pages are additive and do not replace canonical AllPages entries.
    Visiting them lets breadth workers record the redirect title as an alias while
    following the wiki's canonical target.
    """
    items, exhausted = paginate_api(
        api_url,
        {"action": "query", "list": "allpages", "apnamespace": 0, "aplimit": "max", "apfilterredir": "redirects"},
        timeout,
        max_pages,
    )
    urls: list[dict[str, Any]] = []
    for item in items:
        title = str(item.get("title", "")).strip()
        if title:
            urls.append({"url": article_url(general, base_url, title), "title": title, "pageid": item.get("pageid")})
    return {"urls": urls, "listed_count": len(urls), "complete": exhausted, "truncated": not exhausted}


def enumerate_alllinks(
    api_url: str,
    general: dict[str, Any] | None,
    base_url: str,
    timeout: float,
    max_pages: int,
) -> dict[str, Any]:
    """Enumerate namespace-0 titles referenced by internal links.

    ``alllinks`` is intentionally additive: it catches article titles that are
    linked from the wiki but omitted from a stale sitemap or truncated page list.
    Red links may appear and are left for breadth workers to classify explicitly.
    """
    items, exhausted = paginate_api(
        api_url,
        {"action": "query", "list": "alllinks", "alnamespace": 0, "allimit": "max", "alunique": 1},
        timeout,
        max_pages,
    )
    urls: list[dict[str, Any]] = []
    for item in items:
        title = str(item.get("title", "")).strip()
        if title:
            urls.append({"url": article_url(general, base_url, title), "title": title})
    return {"urls": urls, "listed_count": len(urls), "complete": exhausted, "truncated": not exhausted}


class LinkExtractor(html.parser.HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.links: list[str] = []
        self.next_links: list[str] = []
        self._anchor_href: str | None = None
        self._anchor_text: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag.casefold() != "a":
            return
        values = {key.casefold(): value for key, value in attrs}
        href = values.get("href")
        if href:
            self.links.append(href)
            lowered = href.casefold()
            if "special:allpages" in lowered and any(token in lowered for token in ("from=", "apfrom=", "offset=")):
                self.next_links.append(href)
            self._anchor_href = href
            self._anchor_text = []

    def handle_data(self, data: str) -> None:
        if self._anchor_href is not None:
            self._anchor_text.append(data)

    def handle_endtag(self, tag: str) -> None:
        if tag.casefold() == "a" and self._anchor_href is not None:
            text = " ".join(self._anchor_text).strip().casefold()
            if "next page" in text or text in {"next", "next 200", "next 500"}:
                self.next_links.append(self._anchor_href)
            self._anchor_href = None
            self._anchor_text = []


def special_allpages_candidates(base_url: str, general: dict[str, Any] | None) -> list[str]:
    roots = [
        article_url(general, base_url, "Special:AllPages"),
        urllib.parse.urljoin(base_url.rstrip("/") + "/", "wiki/Special:AllPages"),
        urllib.parse.urljoin(base_url.rstrip("/") + "/", "index.php?title=Special:AllPages"),
    ]
    # Alphabet/number strata make the fallback useful even on themes that hide
    # or rename the ordinary "next page" control.
    seeds = list(roots)
    for root in roots:
        for prefix in "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ":
            seeds.append(add_params(root, {"from": prefix}))
    return list(dict.fromkeys(seeds))


def enumerate_special_allpages(base_url: str, general: dict[str, Any] | None, timeout: float, max_pages: int) -> dict[str, Any]:
    host = urllib.parse.urlsplit(base_url).netloc
    queue: deque[str] = deque(special_allpages_candidates(base_url, general))
    seen_pages: set[str] = set()
    found: list[str] = []
    selected_endpoint: str | None = None
    while queue and len(seen_pages) < 500 and len(found) < max_pages:
        page = queue.popleft()
        if page in seen_pages:
            continue
        seen_pages.add(page)
        try:
            status, body, content_type, final_url = fetch_bytes(page, timeout)
            if status != 200 or (content_type and "html" not in content_type.casefold()):
                continue
        except Exception:
            continue
        selected_endpoint = selected_endpoint or final_url
        parser = LinkExtractor()
        parser.feed(body.decode("utf-8", errors="replace"))
        for href in parser.links:
            absolute = urllib.parse.urljoin(final_url, href)
            normalized = canonicalize_url(absolute)
            if normalized and same_host(normalized, host):
                found.append(normalized)
                if len(found) >= max_pages:
                    break
        for href in parser.next_links:
            absolute = urllib.parse.urljoin(final_url, href)
            if same_host(absolute, host) and absolute not in seen_pages:
                queue.append(absolute)
    unique = list(dict.fromkeys(found))
    return {"urls": unique, "endpoint": selected_endpoint, "complete": not queue, "pages_scanned": len(seen_pages)}


def enumerate_categories(
    api_url: str,
    general: dict[str, Any] | None,
    base_url: str,
    timeout: float,
    max_categories: int,
    max_category_members: int,
    seeds: list[str],
    max_depth: int,
) -> tuple[dict[str, Any], list[str], list[str]]:
    """Enumerate useful categories and recursively expand subcategories.

    The metadata records whether the category list or member traversal was
    truncated.  Category coverage is supplemental evidence and is never treated
    as complete merely because the selected roots returned some pages.
    """
    items, categories_exhausted = paginate_api(
        api_url,
        {"action": "query", "list": "allcategories", "acprop": "size", "aclimit": "max"},
        timeout,
        max(max_categories * 8, max_categories),
    )
    candidates: list[tuple[int, str]] = []
    seed_set = {value.casefold().removeprefix("category:") for value in seeds}
    for item in items:
        name = str(item.get("category", "")).strip()
        if not name:
            continue
        size = int(item.get("size", item.get("pages", 0)) or 0)
        normalized_name = name.casefold().removeprefix("category:")
        if normalized_name in seed_set or not MAINTENANCE_CATEGORY.search(name):
            candidates.append((size, name))
    candidates.sort(key=lambda row: (0 if row[1].casefold().removeprefix("category:") in seed_set else 1, -row[0], row[1].casefold()))
    selected = [name for _, name in candidates[:max_categories]]
    mapping: dict[str, Any] = {}
    category_pages: list[str] = []
    verification: list[str] = []
    queue: deque[tuple[str, int]] = deque((name, 0) for name in selected)
    seen_categories: set[str] = set()
    remaining = max_category_members
    member_queries_complete = True
    depth_limited_subcategories = 0
    while queue and remaining > 0:
        name, depth = queue.popleft()
        key = name.casefold()
        if key in seen_categories:
            continue
        seen_categories.add(key)
        category_title = name if key.startswith("category:") else f"Category:{name}"
        category_pages.append(article_url(general, base_url, category_title))
        params = {
            "action": "query", "list": "categorymembers", "cmtitle": category_title,
            "cmnamespace": "0|14", "cmtype": "page|subcat", "cmlimit": "max",
        }
        values, exhausted = paginate_api(api_url, params, timeout, remaining)
        member_queries_complete = member_queries_complete and exhausted
        members: list[str] = []
        for item in values:
            title = str(item.get("title", "")).strip()
            ns = int(item.get("ns", 0) or 0)
            if not title:
                continue
            if ns == 14:
                if depth < max_depth:
                    queue.append((title, depth + 1))
                else:
                    depth_limited_subcategories += 1
                continue
            url = article_url(general, base_url, title)
            members.append(url)
            verification.append(url)
            remaining -= 1
            if remaining <= 0:
                break
        if members:
            mapping[category_title] = list(dict.fromkeys(members))
    root_truncated = len(candidates) > len(selected) or not categories_exhausted
    traversal_truncated = bool(queue) or remaining <= 0 or not member_queries_complete or depth_limited_subcategories > 0
    mapping["_meta"] = {
        "allcategories_listed": len(items),
        "candidate_category_count": len(candidates),
        "selected_root_count": len(selected),
        "visited_category_count": len(seen_categories),
        "member_count": len(set(verification)),
        "allcategories_complete": categories_exhausted,
        "member_queries_complete": member_queries_complete,
        "depth_limit": max_depth,
        "depth_limited_subcategories": depth_limited_subcategories,
        "root_truncated": root_truncated,
        "traversal_truncated": traversal_truncated,
        "complete": not root_truncated and not traversal_truncated,
    }
    return mapping, list(dict.fromkeys(category_pages)), list(dict.fromkeys(verification))

def robots_sitemaps(base_url: str, timeout: float) -> list[str]:
    parsed = urllib.parse.urlsplit(base_url)
    origin = urllib.parse.urlunsplit((parsed.scheme, parsed.netloc, "", "", ""))
    try:
        status, body, _, _ = fetch_bytes(origin + "/robots.txt", timeout)
    except Exception:
        return []
    if status != 200:
        return []
    values: list[str] = []
    for line in body.decode("utf-8", errors="replace").splitlines():
        if line.casefold().startswith("sitemap:"):
            value = line.split(":", 1)[1].strip()
            if value:
                values.append(value)
    return list(dict.fromkeys(values))


def parse_sitemaps(candidates: list[str], timeout: float, host: str, max_sitemaps: int, max_urls: int) -> tuple[dict[str, Any], list[dict[str, str]]]:
    """Recursively read sitemap indexes and URL sets without treating them as exclusive.

    Sitemap-index ``lastmod`` values are retained separately from page ``lastmod``
    values.  This lets the planner detect a recently regenerated index that points
    at stale child maps, or a stale index that contains recently updated pages.
    """
    queue: deque[tuple[str, str | None, str | None]] = deque((url, None, None) for url in candidates)
    seen: set[str] = set()
    pages: list[dict[str, Any]] = []
    successful: list[str] = []
    index_rows: list[dict[str, Any]] = []
    errors: list[dict[str, str]] = []
    hit_sitemap_limit = False
    hit_url_limit = False
    while queue and len(pages) < max_urls:
        if len(seen) >= max_sitemaps:
            hit_sitemap_limit = True
            break
        current, declared_lastmod, parent = queue.popleft()
        if current in seen or not same_host(current, host):
            continue
        seen.add(current)
        try:
            status, body, _, final_url = fetch_bytes(current, timeout)
            if status != 200:
                raise WorldBuilderError(f"HTTP {status}")
            root = ET.fromstring(body)
        except Exception as exc:
            errors.append({"source": "sitemap", "url": current, "error": str(exc)})
            continue
        tag = root.tag.rsplit("}", 1)[-1].casefold()
        successful.append(final_url)
        if tag == "sitemapindex":
            if declared_lastmod:
                index_rows.append({"url": final_url, "lastmod": declared_lastmod, "parent": parent})
            for node in root:
                loc = None
                lastmod = None
                for child in node:
                    name = child.tag.rsplit("}", 1)[-1].casefold()
                    if name == "loc":
                        loc = (child.text or "").strip()
                    elif name == "lastmod":
                        lastmod = (child.text or "").strip()
                if loc and same_host(loc, host):
                    index_rows.append({"url": loc, "lastmod": lastmod or None, "parent": final_url})
                    queue.append((loc, lastmod or None, final_url))
            continue
        if tag != "urlset":
            errors.append({"source": "sitemap", "url": current, "error": f"unsupported root {tag}"})
            continue
        for node in root:
            loc = None
            lastmod = None
            for child in node:
                name = child.tag.rsplit("}", 1)[-1].casefold()
                if name == "loc":
                    loc = (child.text or "").strip()
                elif name == "lastmod":
                    lastmod = (child.text or "").strip()
            normalized = canonicalize_url(loc) if loc and same_host(loc, host) else None
            if normalized:
                pages.append({
                    "url": normalized,
                    "lastmod": lastmod or None,
                    "sitemap": final_url,
                    "sitemap_declared_lastmod": declared_lastmod,
                })
                if len(pages) >= max_urls:
                    hit_url_limit = True
                    break
    dedup: dict[str, dict[str, Any]] = {}
    for item in pages:
        previous = dedup.get(item["url"])
        if previous is None or (item.get("lastmod") or "") > (previous.get("lastmod") or ""):
            dedup[item["url"]] = item
    dated = [item["lastmod"] for item in dedup.values() if item.get("lastmod")]
    index_dated = [item["lastmod"] for item in index_rows if item.get("lastmod")]
    truncated = bool(queue) or hit_sitemap_limit or hit_url_limit
    return {
        "urls": list(dedup.values()),
        "sitemaps": list(dict.fromkeys(successful)),
        "sitemap_index_rows": index_rows,
        "candidate_count": len(candidates),
        "fetched_sitemap_count": len(seen),
        "newest_lastmod": max(dated) if dated else None,
        "oldest_lastmod": min(dated) if dated else None,
        "index_lastmod": max(index_dated) if index_dated else None,
        "oldest_index_lastmod": min(index_dated) if index_dated else None,
        "dated_count": len(dated),
        "index_dated_count": len(index_dated),
        "complete": not truncated,
        "truncated": truncated,
        "hit_sitemap_limit": hit_sitemap_limit,
        "hit_url_limit": hit_url_limit,
    }, errors

def discover_sitemaps(base_url: str, timeout: float, max_sitemaps: int, max_urls: int) -> tuple[dict[str, Any], list[dict[str, str]]]:
    parsed = urllib.parse.urlsplit(base_url)
    origin = urllib.parse.urlunsplit((parsed.scheme, parsed.netloc, "", "", ""))
    candidates = robots_sitemaps(base_url, timeout) + [
        origin + "/sitemap.xml", origin + "/sitemap_index.xml", origin + "/sitemap-index.xml",
        origin + "/sitemap.xml.gz", origin + "/sitemap_index.xml.gz",
    ]
    return parse_sitemaps(list(dict.fromkeys(candidates)), timeout, parsed.netloc, max_sitemaps, max_urls)


def _is_category_url(url: str) -> bool:
    parsed = urllib.parse.urlsplit(url)
    path = urllib.parse.unquote(parsed.path).casefold()
    if "category:" in path:
        return True
    title = dict(urllib.parse.parse_qsl(parsed.query)).get("title", "").casefold()
    return title.startswith("category:")


def _search_one_query(base_url: str, query: str, timeout: float, pages: int, source_host: str) -> dict[str, Any]:
    """Exactly the original per-query pagination loop, unchanged, just factored
    out so it can run inside a worker thread. Every query is independent (no
    shared state, no cross-query pagination dependency), so this is the safe
    unit of concurrency: parallelize *which query runs when*, never touch the
    sequential pagination logic within one query."""
    content: dict[str, dict[str, Any]] = {}
    category_seeds: dict[str, dict[str, Any]] = {}
    errors: list[dict[str, str]] = []
    query_seen: set[str] = set()
    successful = 0
    unusable = 0
    for page in range(1, pages + 1):
        params = urllib.parse.urlencode({"q": query, "format": "json", "categories": "general", "pageno": page})
        url = f"{base_url.rstrip('/')}/search?{params}"
        try:
            payload = fetch_json(url, timeout)
            successful += 1
        except Exception as exc:
            errors.append({"source": "searxng", "url": url, "error": str(exc)})
            break
        batch = payload.get("results", [])
        if not isinstance(batch, list) or not batch:
            break
        for item in batch:
            if not isinstance(item, dict):
                continue
            raw_url = item.get("url")
            traversal = canonicalize_url(raw_url, allow_category=True)
            if not traversal or not same_host(traversal, source_host):
                unusable += 1
                continue
            target_map = category_seeds if _is_category_url(traversal) else content
            record = target_map.setdefault(traversal, {
                "url": traversal, "titles": [], "queries": [], "pages": [], "engines": [],
            })
            title = item.get("title")
            if isinstance(title, str) and title.strip() and title.strip() not in record["titles"]:
                record["titles"].append(title.strip())
            if query not in record["queries"]:
                record["queries"].append(query)
            if page not in record["pages"]:
                record["pages"].append(page)
            engines = item.get("engines")
            if isinstance(engines, list):
                for engine in engines:
                    if isinstance(engine, str) and engine not in record["engines"]:
                        record["engines"].append(engine)
            query_seen.add(traversal)
        time.sleep(0.04)
    return {
        "query": query, "content": content, "category_seeds": category_seeds, "errors": errors,
        "seen_count": len(query_seen), "successful": successful, "unusable": unusable,
    }


def search_searxng(base_url: str, source_url: str, timeout: float, pages: int, concurrency: int = 4) -> tuple[dict[str, Any], list[dict[str, str]]]:
    """Harvest site-restricted results while preserving every query provenance.

    Category pages are retained as traversal seeds instead of being discarded by
    the content-page canonicalizer.  They are never placed directly in the final
    content corpus; bounded_bfs uses them to expose otherwise orphaned members.

    The ~57 site:host/site:host+term/site:host+letter queries are fully
    independent of each other, so they run concurrently (bounded thread pool);
    each query's own pagination stays sequential and unchanged, and per-page
    rate-limit sleeps are unaffected. Results merge back on the main thread as
    each query finishes, never under concurrent mutation.
    """
    source_host = urllib.parse.urlsplit(source_url).netloc.casefold()
    queries = [f"site:{source_host}"] + [f"site:{source_host} {term}" for term in ENTITY_TERMS]
    queries.extend(f"site:{source_host} {letter}" for letter in "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789")
    content: dict[str, dict[str, Any]] = {}
    category_seeds: dict[str, dict[str, Any]] = {}
    errors: list[dict[str, str]] = []
    query_counts: dict[str, int] = {}
    successful_request_count = 0
    unusable_result_count = 0
    workers = max(1, int(concurrency))
    with cf.ThreadPoolExecutor(max_workers=workers) as pool:
        futures = [pool.submit(_search_one_query, base_url, query, timeout, pages, source_host) for query in queries]
        for future in futures:
            row = future.result()
            for url, record in row["content"].items():
                existing = content.setdefault(url, {"url": url, "titles": [], "queries": [], "pages": [], "engines": []})
                for key in ("titles", "queries", "pages", "engines"):
                    for value in record[key]:
                        if value not in existing[key]:
                            existing[key].append(value)
            for url, record in row["category_seeds"].items():
                existing = category_seeds.setdefault(url, {"url": url, "titles": [], "queries": [], "pages": [], "engines": []})
                for key in ("titles", "queries", "pages", "engines"):
                    for value in record[key]:
                        if value not in existing[key]:
                            existing[key].append(value)
            errors.extend(row["errors"])
            query_counts[row["query"]] = row["seen_count"]
            successful_request_count += row["successful"]
            unusable_result_count += row["unusable"]
    return {
        "attempted": True,
        "endpoint": base_url.rstrip("/"),
        "urls": list(content.values()),
        "category_seed_urls": list(category_seeds.values()),
        "query_count": len(queries),
        "successful_request_count": successful_request_count,
        "failed_request_count": len(errors),
        "unusable_result_count": unusable_result_count,
        "pages_per_query": pages,
        "search_concurrency": workers,
        "query_result_counts": query_counts,
    }, errors

def _fetch_bfs_page(url: str, api_url: str | None, host: str, timeout: float) -> dict[str, Any]:
    """Pure: fetch one page's outbound links (API-first, HTML fallback), zero
    shared-state mutation. Everything that touches visited/discovered/queue
    stays in the caller, sequential, exactly as before; this function only
    does the network I/O, which is the safe unit to run concurrently."""
    parser_links: list[str] = []
    final_url = url
    api_error: Exception | None = None
    if api_url and same_host(api_url, host):
        try:
            parsed_url = urllib.parse.urlsplit(url)
            title = dict(urllib.parse.parse_qsl(parsed_url.query)).get("title")
            if not title and "/wiki/" in parsed_url.path:
                title = urllib.parse.unquote(parsed_url.path.split("/wiki/", 1)[1]).replace("_", " ")
            if title:
                payload = fetch_json(add_params(api_url, {
                    "action": "parse", "page": title, "redirects": 1,
                    "prop": "links|categories|templates", "format": "json", "formatversion": 2,
                }), timeout)
                parsed_node = payload.get("parse", {}) if isinstance(payload.get("parse"), dict) else {}
                for item in parsed_node.get("links", []) if isinstance(parsed_node.get("links"), list) else []:
                    if isinstance(item, dict) and isinstance(item.get("title"), str):
                        parser_links.append("/wiki/" + urllib.parse.quote(item["title"].replace(" ", "_"), safe="/:()!'-,"))
                for item in parsed_node.get("categories", []) if isinstance(parsed_node.get("categories"), list) else []:
                    if isinstance(item, dict):
                        name = item.get("category") or item.get("title")
                        if isinstance(name, str):
                            if not name.casefold().startswith("category:"):
                                name = "Category:" + name
                            parser_links.append("/wiki/" + urllib.parse.quote(name.replace(" ", "_"), safe="/:()!'-,"))
        except Exception as exc:
            api_error = exc
    if not parser_links:
        try:
            status, body, content_type, final_url = fetch_bytes(url, timeout, retries=1)
            if status != 200 or (content_type and "html" not in content_type.casefold()):
                return {"url": url, "parser_links": [], "final_url": final_url, "error": None, "skip": True}
            parser = LinkExtractor()
            parser.feed(body.decode("utf-8", errors="replace"))
            parser_links = parser.links
        except Exception as exc:
            return {"url": url, "parser_links": [], "final_url": final_url, "error": f"api={api_error}; html={exc}", "skip": False}
    return {"url": url, "parser_links": parser_links, "final_url": final_url, "error": None, "skip": False}


def bounded_bfs(seed_urls: list[str], base_url: str, timeout: float, max_pages: int, max_depth: int, api_url: str | None = None, deadline: float | None = None, concurrency: int = 6) -> tuple[dict[str, Any], list[dict[str, str]]]:
    """Traverse content and category seeds, returning content pages only.

    Category pages are valuable graph hubs.  They may enter the traversal queue,
    but are kept out of the content corpus so category namespace pages do not
    become lorebook-entry candidates by accident.

    Fetches the current BFS layer (all queued items sharing the shallowest
    depth present) concurrently, bounded by ``concurrency``; every visited/
    discovered/queue mutation happens sequentially afterward, in original
    dequeue order, on the main thread; identical graph-building logic to the
    single-threaded version, just with the network I/O parallelized.
    """
    host = urllib.parse.urlsplit(base_url).netloc
    queue: deque[tuple[str, int]] = deque()
    for raw in seed_urls:
        url = canonicalize_url(raw, allow_category=True)
        if url and same_host(url, host):
            queue.append((url, 0))
    visited: set[str] = set()
    content_visited: set[str] = set()
    category_visited: set[str] = set()
    discovered: set[str] = set()
    category_discovered: set[str] = set()
    errors: list[dict[str, str]] = []
    nav_candidates: set[str] = set()
    deadline_hit = False
    workers = max(1, int(concurrency))
    while queue and len(visited) < max_pages:
        if deadline is not None and time.monotonic() >= deadline:
            deadline_hit = True
            break
        batch_depth = queue[0][1]
        budget = max_pages - len(visited)
        batch: list[tuple[str, int]] = []
        while queue and queue[0][1] == batch_depth and len(batch) < budget:
            candidate = queue.popleft()
            if candidate[0] in visited:
                continue
            visited.add(candidate[0])
            batch.append(candidate)
        if not batch:
            continue
        with cf.ThreadPoolExecutor(max_workers=min(workers, len(batch))) as pool:
            fetched = list(pool.map(lambda pair: _fetch_bfs_page(pair[0], api_url, host, timeout), batch))
        for (url, depth), result in zip(batch, fetched):
            if _is_category_url(url):
                category_visited.add(url)
            else:
                content_visited.add(url)
            if result.get("error"):
                errors.append({"source": "bfs", "url": url, "error": result["error"]})
                continue
            if result.get("skip"):
                continue
            final_url = result["final_url"]
            for href in result["parser_links"]:
                absolute = urllib.parse.urljoin(final_url, href)
                traversal = canonicalize_url(absolute, allow_category=True)
                if not traversal or not same_host(traversal, host):
                    continue
                if _is_category_url(traversal):
                    category_discovered.add(traversal)
                    nav_candidates.add(traversal)
                else:
                    content_url = canonicalize_url(traversal)
                    if not content_url:
                        continue
                    discovered.add(content_url)
                    href_text = href.casefold()
                    if any(token in href_text for token in ("navbox", "portal", "index")):
                        nav_candidates.add(content_url)
                if depth < max_depth and traversal not in visited:
                    queue.append((traversal, depth + 1))
    return {
        "urls": sorted(discovered),
        "visited_seed_pages": sorted(visited),
        "visited_content_pages": sorted(content_visited),
        "visited_category_pages": sorted(category_visited),
        "category_seed_urls": sorted(category_discovered),
        "nav_candidates": sorted(nav_candidates),
        "max_depth": max_depth,
        "complete": not queue,
        "truncated": bool(queue),
        "truncated_by_wall_budget": deadline_hit,
    }, errors

def random_rounds(api_url: str, general: dict[str, Any] | None, base_url: str, timeout: float, rounds: int, size: int) -> list[list[str]]:
    output: list[list[str]] = []
    for _ in range(rounds):
        payload = fetch_json(add_params(api_url, {
            "action": "query", "list": "random", "rnnamespace": 0, "rnlimit": size,
            "format": "json", "formatversion": 2,
        }), timeout)
        values = payload.get("query", {}).get("random", [])
        urls = [article_url(general, base_url, str(item.get("title", ""))) for item in values if isinstance(item, dict) and item.get("title")]
        output.append(list(dict.fromkeys(urls)))
    return output


def union_count(*groups: Iterable[str]) -> int:
    union: set[str] = set()
    for group in groups:
        for url in group:
            normalized = canonicalize_url(url)
            if normalized:
                union.add(normalized)
    return len(union)


def build_argument_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--build-state", required=True)
    parser.add_argument("--base-url", required=True, help="Wiki/site base URL")
    parser.add_argument("--api-url", help="Explicit MediaWiki api.php URL")
    parser.add_argument("--searxng-base-url", required=True, help="Mandatory local SearXNG URL for additive search harvest")
    parser.add_argument("--timeout", type=float, default=20.0)
    parser.add_argument("--max-pages", type=int, default=100000)
    parser.add_argument("--max-sitemaps", type=int, default=250)
    parser.add_argument("--max-categories", type=int, default=5000)
    parser.add_argument("--max-category-members", type=int, default=100000)
    parser.add_argument("--category-depth", type=int, default=8, help="Maximum recursive subcategory depth")
    parser.add_argument("--category", action="append", default=[], help="High-value category seed; repeatable")
    parser.add_argument("--search-pages", type=int, default=5)
    parser.add_argument("--search-concurrency", type=int, default=4, help="Concurrent SearXNG queries (the ~57 site:/term/letter queries are independent); a self-hosted instance handles 4-8 comfortably")
    parser.add_argument("--html-fallback", choices=("auto", "always", "never"), default="auto", help="Special:AllPages HTML sweep: auto skips it when API allpages enumeration completed")
    parser.add_argument("--wall-budget-seconds", type=float, default=None, help="Soft wall-clock budget; supplemental link-graph traversal is skipped past this budget so an external exec timeout cannot kill the probe mid-run")
    parser.add_argument("--bfs-pages", type=int, default=600)
    parser.add_argument("--bfs-depth", type=int, default=2)
    parser.add_argument("--bfs-concurrency", type=int, default=6, help="Concurrent page fetches per BFS layer (same-depth pages are independent); identical discovery results at any concurrency, only wall-clock time changes")
    parser.add_argument("--random-rounds", type=int, default=4)
    parser.add_argument("--random-size", type=int, default=40)
    parser.add_argument("--output", help="Optional output path inside the build workspace")
    parser.add_argument("--delta-of", help="Frozen parent probe; write a delta probe without replacing build-state discovery_probe")
    parser.add_argument("--disable-page-prefilter", action="store_true", help="Skip deterministic MediaWiki metadata filtering; post-fetch filtering still applies")
    parser.add_argument("--include-production-pages", action="store_true", help="Include cast, crew, dubbing, staff, and other production pages in discovery workers")
    parser.add_argument("--exclude-media-pages", action="store_true", help="Keep episode/song/comic pages as reference-only instead of entity candidates")
    parser.add_argument("--prefilter-batch-size", type=int, default=40, help="MediaWiki titles per metadata request, maximum 50")
    parser.add_argument("--prefilter-harvest-rounds", type=int, default=2, help="Deterministic link-harvest rounds for index/disambiguation pages")
    return parser


def validate_arguments(args) -> None:
    """Validate cross-argument probe options before network or build-state work."""
    if args.delta_of and not args.output:
        raise WorldBuilderError("--delta-of requires a distinct --output path; the frozen parent probe must not be replaced")


def orchestrate(args) -> int:

    try:
        root, state = load_build_state(args.build_state)
        default_output = resolve_state_path(root, state, "discovery_probe")
        output = Path(args.output).expanduser().resolve() if args.output else default_output
        try:
            output.relative_to(root)
        except ValueError as exc:
            raise WorldBuilderError("probe output must remain inside the build workspace") from exc
        parent_probe_sha = None
        if args.delta_of:
            parent_path = Path(args.delta_of).expanduser().resolve()
            try:
                parent_path.relative_to(root)
            except ValueError as exc:
                raise WorldBuilderError("--delta-of must remain inside the build workspace") from exc
            if output == parent_path:
                raise WorldBuilderError("delta output must differ from the frozen parent probe")
            parent_probe = load_json(parent_path)
            if not isinstance(parent_probe, dict) or parent_probe.get("build_id") != state.get("build_id"):
                raise WorldBuilderError("delta parent probe is invalid or belongs to another build")
            parent_probe_sha = sha256_file(parent_path)
        parsed = urllib.parse.urlsplit(args.base_url)
        if parsed.scheme.casefold() not in {"http", "https"} or not parsed.netloc:
            raise WorldBuilderError("--base-url must be an absolute HTTP(S) URL")
        errors: list[dict[str, str]] = []
        progress("start", f"probing {args.base_url}")
        probe_started_monotonic = time.monotonic()
        truncated_phases: list[str] = []

        def wall_budget_exceeded() -> bool:
            return bool(args.wall_budget_seconds) and (time.monotonic() - probe_started_monotonic) > float(args.wall_budget_seconds)

        progress("sitemaps", "enumerating robots and sitemap indexes")
        sitemap, sitemap_errors = discover_sitemaps(args.base_url, args.timeout, args.max_sitemaps, args.max_pages)
        errors.extend(sitemap_errors)

        progress("mediawiki", "probing api.php and site statistics")
        candidates = [args.api_url] if args.api_url else infer_api_candidates(args.base_url)
        api_url, general, statistics = probe_api([value for value in candidates if value], args.timeout, errors)
        article_estimate: int | None = None
        if isinstance(statistics, dict):
            raw = statistics.get("articles")
            if isinstance(raw, int) and raw >= 0:
                article_estimate = raw

        allpages: dict[str, Any] = {"urls": [], "reported_total": article_estimate, "complete": False}
        redirects: dict[str, Any] = {"urls": [], "complete": False}
        alllinks: dict[str, Any] = {"urls": [], "complete": False}
        special_allpages: dict[str, Any] = {"urls": [], "complete": False}
        categories: dict[str, Any] = {}
        category_pages: list[str] = []
        category_checks: list[str] = []
        random_samples: list[list[str]] = []
        if api_url:
            progress("allpages", "starting complete namespace-0 enumeration")
            try:
                allpages = enumerate_allpages(api_url, general, args.base_url, args.timeout, args.max_pages, article_estimate)
            except Exception as exc:
                errors.append({"source": "allpages", "url": api_url, "error": str(exc)})
            try:
                redirects = enumerate_redirects(api_url, general, args.base_url, args.timeout, args.max_pages)
            except Exception as exc:
                errors.append({"source": "redirects", "url": api_url, "error": str(exc)})
            try:
                alllinks = enumerate_alllinks(api_url, general, args.base_url, args.timeout, args.max_pages)
            except Exception as exc:
                errors.append({"source": "alllinks", "url": api_url, "error": str(exc)})
            try:
                categories, category_pages, category_checks = enumerate_categories(
                    api_url, general, args.base_url, args.timeout,
                    args.max_categories, args.max_category_members, args.category, args.category_depth,
                )
                categories["category_pages"] = category_pages
            except Exception as exc:
                errors.append({"source": "categories", "url": api_url, "error": str(exc)})
            try:
                random_samples = random_rounds(api_url, general, args.base_url, args.timeout, max(2, args.random_rounds), args.random_size)
            except Exception as exc:
                errors.append({"source": "random", "url": api_url, "error": str(exc)})
        api_enumeration_complete = bool(allpages.get("complete"))
        skip_html_fallback = args.html_fallback == "never" or (
            args.html_fallback == "auto" and api_enumeration_complete
        )
        if skip_html_fallback:
            progress("special-allpages", "skipping HTML fallback (API allpages enumeration is complete)")
        else:
            progress("special-allpages", "checking HTML fallback enumeration")
            try:
                special_allpages = enumerate_special_allpages(args.base_url, general, args.timeout, args.max_pages)
            except Exception as exc:
                errors.append({"source": "special_allpages", "url": args.base_url, "error": str(exc)})

        search_harvest: dict[str, Any] = {
            "attempted": False,
            "endpoint": None,
            "urls": [],
            "query_count": 0,
            "successful_request_count": 0,
            "failed_request_count": 0,
        }
        discovery_required = bool((state.get("discovery") or {}).get("required"))
        if discovery_required and not args.searxng_base_url:
            raise WorldBuilderError(
                "known-property discovery requires --searxng-base-url after the mandatory SearXNG/WARP preflight"
            )
        if args.searxng_base_url:
            progress("searxng", "running site-restricted additive harvest")
            search_harvest, search_errors = search_searxng(
                args.searxng_base_url, args.base_url, args.timeout, max(1, args.search_pages),
                concurrency=max(1, args.search_concurrency),
            )
            errors.extend(search_errors)
            if search_harvest.get("successful_request_count", 0) <= 0:
                raise WorldBuilderError("SearXNG was configured but no search request completed successfully")

        sitemap_urls = [item.get("url") for item in sitemap.get("urls", []) if isinstance(item, dict) and item.get("url")]
        allpages_urls = [item.get("url") for item in allpages.get("urls", []) if isinstance(item, dict) and item.get("url")]
        redirect_urls = [item.get("url") for item in redirects.get("urls", []) if isinstance(item, dict) and item.get("url")]
        alllink_urls = [item.get("url") for item in alllinks.get("urls", []) if isinstance(item, dict) and item.get("url")]
        special_urls = [item.get("url") if isinstance(item, dict) else item for item in special_allpages.get("urls", [])]
        search_urls = [item.get("url") if isinstance(item, dict) else item for item in search_harvest.get("urls", [])]
        search_category_urls = [item.get("url") if isinstance(item, dict) else item for item in search_harvest.get("category_seed_urls", [])]
        category_member_urls = [url for key, values in categories.items() if not str(key).startswith("_") and key != "category_pages" and isinstance(values, list) for url in values]
        bfs_seeds = list(dict.fromkeys(
            [args.base_url] + category_pages[:100] + search_category_urls[:100] + search_urls[:60] + sitemap_urls[:30] + allpages_urls[:30]
            + redirect_urls[:15] + alllink_urls[:20] + [url for round_urls in random_samples[:2] for url in round_urls[:10]]
        ))
        if wall_budget_exceeded():
            truncated_phases.append("graph")
            progress("graph", "skipping bounded traversal: wall budget exceeded (enumeration channels are complete)")
            internal_links = {"complete": False, "urls": [], "truncated_by_wall_budget": True}
            bfs_errors = []
        else:
            progress("graph", f"running API-first bounded traversal from {len(bfs_seeds)} seed(s)")
            graph_deadline = (probe_started_monotonic + args.wall_budget_seconds) if args.wall_budget_seconds else None
            internal_links, bfs_errors = bounded_bfs(
                bfs_seeds, args.base_url, args.timeout, max(1, args.bfs_pages), max(0, args.bfs_depth), api_url,
                deadline=graph_deadline, concurrency=max(1, args.bfs_concurrency),
            )
            if internal_links.get("truncated_by_wall_budget"):
                truncated_phases.append("graph_partial")
        errors.extend(bfs_errors)

        if len(random_samples) < 2:
            # Deterministic independent strata from SearXNG and BFS when API random
            # is unavailable. They are separate from the AllPages/sitemap union.
            independent = list(dict.fromkeys(search_urls + internal_links.get("urls", [])))
            if independent:
                rng = random.Random(f"{state.get('build_id')}:{args.base_url}")
                shuffled = list(independent)
                rng.shuffle(shuffled)
                split = max(1, len(shuffled) // 2)
                random_samples = [shuffled[: min(args.random_size, split)], shuffled[split: split + args.random_size]]

        source_counts = {
            "sitemap": len(set(sitemap_urls)),
            "allpages": len(set(allpages_urls)),
            "redirects": len(set(redirect_urls)),
            "alllinks": len(set(alllink_urls)),
            "special_allpages": len(set(special_urls)),
            "categories": len(set(category_member_urls)),
            "searxng": len(set(search_urls)),
            "internal_links": len(set(internal_links.get("urls", []))),
        }
        union = union_count(sitemap_urls, allpages_urls, redirect_urls, alllink_urls, special_urls, category_member_urls, search_urls, internal_links.get("urls", []))
        independent_lower_bound = max(
            [article_estimate or 0]
            + [count for count in source_counts.values() if isinstance(count, int)]
        )
        independent_estimates = {
            "mediawiki_article_count": article_estimate,
            "allpages_listed_count": len(set(allpages_urls)),
            "redirect_count": len(set(redirect_urls)),
            "alllinks_count": len(set(alllink_urls)),
            "special_allpages_count": len(set(special_urls)),
            "sitemap_count": len(set(sitemap_urls)),
            "category_union_count": len(set(category_member_urls)),
            "searxng_union_count": len(set(search_urls)),
            "bfs_union_count": len(set(internal_links.get("urls", []))),
            "additive_union_count": union,
            "independent_lower_bound_page_count": independent_lower_bound,
            # Backward-compatible alias. It deliberately excludes additive_union_count.
            "lower_bound_page_count": independent_lower_bound,
            "independent_enumerator_count": sum(bool(source_counts[key]) for key in source_counts),
        }

        raw_union_urls = sorted({
            url for url in (
                sitemap_urls + allpages_urls + redirect_urls + alllink_urls + special_urls
                + category_member_urls + search_urls + list(internal_links.get("urls", []))
            )
            if isinstance(url, str) and url.strip()
        })
        page_filter: dict[str, Any] = {
            "kind": "worldbuilder-discovery-page-filter",
            "filter_version": 1,
            "status": "disabled" if args.disable_page_prefilter else "unavailable",
            "policy": default_page_filter_policy(),
            "records": [],
            "worker_urls": raw_union_urls,
            "accounted_without_worker": [],
            "harvested_urls": [],
            "alias_map": [],
            "classification_counts": {"content": len(raw_union_urls)},
            "estimated_worker_reduction_ratio": 0.0,
        }
        page_filter["policy"]["include_production"] = bool(args.include_production_pages)
        page_filter["policy"]["include_media"] = not bool(args.exclude_media_pages)
        page_filter["policy"]["maximum_harvest_rounds"] = max(0, min(5, int(args.prefilter_harvest_rounds)))
        if api_url and not args.disable_page_prefilter:
            progress("page-filter", f"classifying {len(raw_union_urls):,} URL(s) with batched MediaWiki metadata")
            try:
                page_filter = prefilter_urls(
                    api_url=api_url,
                    base_url=args.base_url,
                    urls=raw_union_urls,
                    timeout=args.timeout,
                    batch_size=args.prefilter_batch_size,
                    policy_value=page_filter["policy"],
                )
                progress(
                    "page-filter",
                    f"kept {len(page_filter.get('worker_urls', [])):,} worker candidate(s); "
                    f"accounted for {len(page_filter.get('accounted_without_worker', [])):,} low-value/reference page(s) without LLM work",
                )
            except Exception as exc:
                errors.append({"source": "page_filter", "url": api_url, "error": str(exc)})
                page_filter["status"] = "failed"
                page_filter["error"] = str(exc)

        # Verification workers must never receive pages already classified as
        # junk, alias-only, index-only, or reference-only. Keep the independently
        # sampled rounds, but retain only content candidates. If filtering empties
        # too many rounds, planning fails closed and asks for another probe.
        verification_candidates = set(
            page_filter.get("worker_urls", raw_union_urls)
            if page_filter.get("status") == "complete" else raw_union_urls
        )
        random_samples = [
            [url for url in round_urls if url in verification_candidates]
            for round_urls in random_samples
        ]
        random_samples = [round_urls for round_urls in random_samples if round_urls]
        category_verification_rounds = (
            [category_checks[::2][: args.random_size], category_checks[1::2][: args.random_size]]
            if category_checks else []
        )
        category_verification_rounds = [
            [url for url in round_urls if url in verification_candidates]
            for round_urls in category_verification_rounds
        ]
        category_verification_rounds = [round_urls for round_urls in category_verification_rounds if round_urls]

        probe = {
            "kind": "worldbuilder-source-probe-delta" if parent_probe_sha else "worldbuilder-source-probe",
            "probe_version": 3,
            "parent_probe_sha256": parent_probe_sha,
            "build_id": state.get("build_id"),
            "created_at": utc_now(),
            "base_url": args.base_url,
            "mediawiki": {"api_url": api_url, "siteinfo": general, "statistics": statistics},
            "sitemap": sitemap,
            "allpages": allpages,
            "redirects": redirects,
            "alllinks": alllinks,
            "special_allpages": special_allpages,
            "categories": categories,
            "search_harvest": search_harvest,
            "internal_links": internal_links,
            "bfs_seeds": bfs_seeds,
            "page_filter": page_filter,
            "random_samples": {"rounds": random_samples},
            "category_spot_checks": {"rounds": category_verification_rounds},
            "independent_estimates": independent_estimates,
            "errors": errors,
            "source_status": {
                **{key: bool(value) for key, value in source_counts.items()},
                "searxng_attempted": bool(search_harvest.get("attempted")),
                "searxng_requests_succeeded": int(search_harvest.get("successful_request_count", 0) or 0),
                "verification_rounds": len(random_samples),
                "category_enumeration_complete": bool((categories.get("_meta") or {}).get("complete")),
                "bfs_complete": bool(internal_links.get("complete")),
                "sitemap_complete": bool(sitemap.get("complete")),
                "html_fallback_skipped": bool(skip_html_fallback),
                "wall_budget_truncated_phases": truncated_phases,
                "allpages_complete": bool(allpages.get("complete")),
                "page_filter_status": page_filter.get("status"),
                "page_filter_worker_count": len(page_filter.get("worker_urls", [])),
                "page_filter_accounted_count": len(page_filter.get("accounted_without_worker", [])),
            },
        }
        if union <= 0:
            raise WorldBuilderError("no discovery channel returned usable pages")
        if len(random_samples) < 2 and not category_checks:
            raise WorldBuilderError("probe could not establish two independent verification rounds")

        progress("write", f"saving probe with {union:,} unique URL(s)")
        atomic_write_json(output, probe)
        if not parent_probe_sha:
            state.setdefault("discovery", {})["probe_status"] = "complete"
            state["discovery"]["probe_path"] = str(output.relative_to(root)).replace("\\", "/")
            state["discovery"]["probe_union_count"] = union
            state["discovery"]["independent_lower_bound"] = independent_estimates["lower_bound_page_count"]
            atomic_write_json(Path(args.build_state).resolve(), state)
        print(json.dumps({
            "status": "probed", "output": str(output), "counts": source_counts,
            "union": union, "independent_estimates": independent_estimates,
            "verification_rounds": len(random_samples), "errors": len(errors),
        }, indent=2))
        return 0
    except (WorldBuilderError, OSError, json.JSONDecodeError, urllib.error.URLError, ET.ParseError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


def main() -> int:
    parser = build_argument_parser()
    args = parser.parse_args()
    try:
        validate_arguments(args)
    except WorldBuilderError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    return orchestrate(args)

if __name__ == "__main__":
    raise SystemExit(main())
