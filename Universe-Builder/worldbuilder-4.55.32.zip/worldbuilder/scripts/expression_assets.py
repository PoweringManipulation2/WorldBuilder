#!/usr/bin/env python3
"""Author an expression set: prompt text plus CCv3 `emotion` asset descriptors.

Image Prompts generated prompt text and `assets` was preserve-and-validate only, so
the two never met. A user who wanted an expression pack got prompts with no descriptors
and descriptors with no prompts.

Two halves with different epistemic status, kept separate on purpose:

- **Descriptors and CHARX mapping are spec-level.** Asset `type`, `uri`, `name`, and
  `ext` come from the Character Card V3 proposal. Cardinality, uniqueness, and naming
  consistency are deterministically checkable and are checked here.
- **The emotion label set is implementation-level and unverified.** SillyTavern's sprite
  naming convention has never been observed by this project. The default below is marked
  unverified and replaceable, and nothing here asserts it is correct.

WorldBuilder writes prompts and descriptors, never images. Naming and cardinality are
checkable; image quality is not, and scoring it would be false rigor.

Commands:
    plan      generate prompt set and descriptors
    validate  check an existing assets array for expression-set consistency
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any

from wb_common import WorldBuilderError, load_json, raise_error

CONTRACT = "worldbuilder-expression-assets-v1"
ASSET_TYPE = "emotion"
DEFAULT_EXT = "png"

# UNVERIFIED against a running SillyTavern. Replace with --labels once Phase 0 has
# captured a real install. Recorded in the plan so a consumer knows its status.
DEFAULT_LABELS: tuple[str, ...] = (
    "neutral", "joy", "sadness", "anger", "fear", "surprise", "disgust",
    "love", "curiosity", "confusion", "pride", "embarrassment",
    "gratitude", "grief", "relief", "nervousness",
)
LABEL_STATUS = "unverified"

_SAFE_LABEL = re.compile(r"^[a-z][a-z0-9_-]{1,31}$")


def validate_labels(labels: list[str]) -> list[str]:
    """Filename-safe, unique, non-empty. These are checkable; correctness is not."""
    if not labels:
        raise_error("an expression set needs at least one label")
    cleaned = [label.strip().casefold() for label in labels]
    bad = [label for label in cleaned if not _SAFE_LABEL.match(label)]
    if bad:
        raise_error(f"labels must be lowercase, 2-32 chars, and filename-safe; rejected {bad}")
    duplicates = sorted({label for label in cleaned if cleaned.count(label) > 1})
    if duplicates:
        raise_error(f"duplicate expression labels: {duplicates}")
    return cleaned


def descriptor(label: str, *, ext: str = DEFAULT_EXT) -> dict[str, str]:
    """One CCv3 asset descriptor.

    The `embeded://` scheme is spelled as the specification spells it. The misspelling
    is in the spec, so correcting it here would produce a card that does not resolve.
    """
    return {
        "type": ASSET_TYPE,
        "uri": f"embeded://assets/{ASSET_TYPE}/{label}.{ext}",
        "name": label,
        "ext": ext,
    }


def prompt_for(label: str, character: str, style_note: str) -> str:
    return (
        f"{character}, {label} expression, consistent face and costume across the set, "
        f"neutral background, head and shoulders. {style_note}".strip()
    )


def plan(character: str, *, labels: list[str] | None = None, style_note: str = "",
         ext: str = DEFAULT_EXT) -> dict[str, Any]:
    if not character.strip():
        raise_error("character name is required")
    if not re.match(r"^[a-z0-9]{2,5}$", ext):
        raise_error("asset extension must be a short alphanumeric string such as png or webp")
    # `labels is None` means no preference; an empty list means the caller asked to
    # replace the set and supplied nothing. Falling back to an unverified default there
    # would silently substitute a guess for an explicit instruction.
    resolved = validate_labels(list(DEFAULT_LABELS) if labels is None else list(labels))
    return {
        "kind": "worldbuilder-expression-set",
        "contract": CONTRACT,
        "character": character.strip(),
        "label_count": len(resolved),
        "labels": resolved,
        "label_set_status": LABEL_STATUS if labels is None else "user_supplied",
        "label_set_note": (
            "Default label set has not been verified against a running SillyTavern. "
            "Capture a real install and replace it with --labels."
            if labels is None else
            "Labels supplied by the caller; naming and uniqueness validated, "
            "correctness for the target not asserted."
        ),
        "prompts": [{"label": label, "prompt": prompt_for(label, character.strip(), style_note)}
                    for label in resolved],
        "assets": [descriptor(label, ext=ext) for label in resolved],
        "charx_members": [f"assets/{ASSET_TYPE}/{label}.{ext}" for label in resolved],
        "produces": "prompt text and asset descriptors only; never images",
    }


def generation_sequence(character: str, *, labels: list[str] | None = None, style_note: str = "",
                         base_label: str = "neutral") -> dict[str, Any]:
    """Batch 10: orders expression-set generation as one base portrait plus
    N calls that each reference that same base portrait for visual
    consistency: the highest-value use of image_generate this skill has
    (DR-075 supersedes plan()'s prior "never images" contract). This
    function never calls image_generate itself (it has no access to the
    tool, only the calling agent's runtime does); it only orders and
    structures the sequence for that agent to execute.

    Every step references ONLY the base portrait, not a growing chain of
    prior expressions: this matches the plan's own framing (one base
    portrait as THE style reference for all expressions, not each
    expression building on the last) and keeps every expression step
    independent of the others completing first.
    """
    base_plan = plan(character, labels=labels, style_note=style_note)
    resolved_labels = base_plan["labels"]
    if base_label not in resolved_labels:
        raise_error(f"base_label {base_label!r} must be one of the resolved labels: {resolved_labels}")

    base_prompt = next(row["prompt"] for row in base_plan["prompts"] if row["label"] == base_label)
    steps: list[dict[str, Any]] = [{
        "step": "base_portrait", "label": base_label, "prompt": base_prompt,
        "reference_images": [], "order": 0,
    }]
    order = 1
    for row in base_plan["prompts"]:
        if row["label"] == base_label:
            continue
        steps.append({
            "step": "expression", "label": row["label"], "prompt": row["prompt"],
            "reference_images": [f"<generated:{base_label}>"], "order": order,
        })
        order += 1
    return {
        "kind": "worldbuilder-expression-generation-sequence",
        "contract": CONTRACT,
        "character": base_plan["character"],
        "label_count": base_plan["label_count"],
        "base_label": base_label,
        "steps": steps,
        "note": (
            "Each non-base step's reference_images placeholder (<generated:LABEL>) must be replaced "
            "by the calling agent with the actual image produced by the base_portrait step before "
            "calling image_generate: this function only orders and structures the sequence, since "
            "it has no access to image_generate itself."
        ),
    }


def validate_assets(assets: Any, *, expected_labels: list[str] | None = None) -> dict[str, Any]:
    """Check an existing assets array for expression-set consistency."""
    if not isinstance(assets, list):
        raise_error("assets must be a list of descriptors")
    emotions = [a for a in assets if isinstance(a, dict) and a.get("type") == ASSET_TYPE]
    problems: list[str] = []
    names: list[str] = []
    for asset in emotions:
        name = asset.get("name")
        if not isinstance(name, str) or not _SAFE_LABEL.match(name.strip().casefold()):
            problems.append(f"asset name {name!r} is not a filename-safe expression label")
            continue
        name = name.strip().casefold()
        names.append(name)
        uri, ext = asset.get("uri"), asset.get("ext")
        if not isinstance(uri, str) or not uri:
            problems.append(f"expression {name!r} has no uri")
        elif isinstance(ext, str) and ext and not uri.endswith(f".{ext}"):
            problems.append(f"expression {name!r} uri does not end with its declared ext {ext!r}")
        if isinstance(uri, str) and name and f"/{name}." not in uri:
            problems.append(f"expression {name!r} uri does not carry its own label: {uri}")

    duplicates = sorted({n for n in names if names.count(n) > 1})
    if duplicates:
        problems.append(f"duplicate expression labels: {duplicates}")
    if expected_labels:
        expected = set(validate_labels(list(expected_labels)))
        missing = sorted(expected - set(names))
        extra = sorted(set(names) - expected)
        if missing:
            problems.append(f"expression set is incomplete; missing {missing}")
        if extra:
            problems.append(f"expression set has labels outside the expected set: {extra}")
    return {
        "kind": "worldbuilder-expression-validation",
        "contract": CONTRACT,
        "expression_count": len(emotions),
        "labels": sorted(set(names)),
        "problems": problems,
        "status": "ok" if not problems else "problems",
        "note": "Naming and cardinality only. Whether the labels match the target's sprite "
                "convention is not asserted.",
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Author an expression set for a character card.")
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("plan", help="generate prompt set and asset descriptors")
    p.add_argument("--character", required=True)
    p.add_argument("--labels", nargs="+", help="replace the unverified default label set")
    p.add_argument("--style-note", default="")
    p.add_argument("--ext", default=DEFAULT_EXT)

    p = sub.add_parser("validate", help="check an assets array for expression-set consistency")
    p.add_argument("--card", required=True)
    p.add_argument("--expect-labels", nargs="+")

    args = parser.parse_args()
    try:
        if args.command == "plan":
            result = plan(args.character, labels=args.labels,
                          style_note=args.style_note, ext=args.ext)
        else:
            data = load_json(Path(args.card).expanduser().resolve())
            payload = data.get("data") if isinstance(data, dict) and isinstance(data.get("data"), dict) else data
            assets = payload.get("assets", []) if isinstance(payload, dict) else []
            result = validate_assets(assets, expected_labels=args.expect_labels)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (WorldBuilderError, OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
