#!/usr/bin/env python3
"""Deterministic cross-source entity resolution for discovery output.

Resolution is intentionally conservative. Two discovered entities are merged
only when they share at least one canonicalized source page and their
name/alias sets overlap. This avoids fuzzy-name guesses becoming identity
authority while still handling redirects/titles and duplicate discoveries.
"""
from __future__ import annotations

import copy
import re
from typing import Any

from discovery_plan import canonicalize_url


def _norm(value: Any) -> str:
    return re.sub(r"\s+", " ", str(value or "").strip()).casefold()


def identity_names(entity: dict[str, Any]) -> set[str]:
    names: set[str] = set()
    if _norm(entity.get("name")):
        names.add(_norm(entity.get("name")))
    aliases = entity.get("aliases") if isinstance(entity.get("aliases"), list) else []
    for alias in aliases:
        value = _norm(alias)
        if value:
            names.add(value)
    return names


def source_pages(entity: dict[str, Any]) -> set[str]:
    result: set[str] = set()
    for raw in entity.get("source_urls", []) if isinstance(entity.get("source_urls"), list) else []:
        url = raw.get("url") if isinstance(raw, dict) else raw
        normalized = canonicalize_url(url)
        if normalized:
            result.add(normalized)
    return result


def should_merge(left: dict[str, Any], right: dict[str, Any]) -> bool:
    if not (identity_names(left) & identity_names(right)):
        return False
    if not (source_pages(left) & source_pages(right)):
        return False
    left_type = _norm(left.get("type") or "other")
    right_type = _norm(right.get("type") or "other")
    return left_type == right_type or "other" in {left_type, right_type}


def _dedup_list(values: list[Any]) -> list[Any]:
    result: list[Any] = []
    seen: set[str] = set()
    for item in values:
        marker = repr(item) if isinstance(item, (dict, list)) else _norm(item)
        if marker not in seen:
            seen.add(marker)
            result.append(item)
    return result


def merge_entities(target: dict[str, Any], source: dict[str, Any]) -> dict[str, Any]:
    result = copy.deepcopy(target)
    source_name = str(source.get("name") or "").strip()
    target_name = str(result.get("name") or "").strip()
    name_candidates = [name for name in (target_name, source_name) if name]
    canonical_name = min(name_candidates, key=lambda name: (len(_norm(name)), _norm(name))) if name_candidates else target_name
    result["name"] = canonical_name
    aliases = list(result.get("aliases") or []) if isinstance(result.get("aliases"), list) else []
    aliases.extend(source.get("aliases") or [] if isinstance(source.get("aliases"), list) else [])
    for candidate_name in name_candidates:
        if _norm(candidate_name) != _norm(canonical_name):
            aliases.append(candidate_name)
    result["aliases"] = [a for a in _dedup_list(aliases) if _norm(a) and _norm(a) != _norm(canonical_name)]
    for field in ("source_urls", "relationships", "affiliations", "locations", "tags", "concepts", "eras", "categories"):
        values: list[Any] = []
        for entity in (result, source):
            current = entity.get(field)
            if isinstance(current, list):
                values.extend(current)
            elif current not in (None, ""):
                values.append(current)
        if values:
            result[field] = _dedup_list(values)
    conflicts = list(result.get("_discovery_conflicts") or []) if isinstance(result.get("_discovery_conflicts"), list) else []
    for row in source.get("_discovery_conflicts", []) if isinstance(source.get("_discovery_conflicts"), list) else []:
        if row not in conflicts:
            conflicts.append(copy.deepcopy(row))
    if conflicts:
        result["_discovery_conflicts"] = conflicts
    return result


def resolve_entities(entities: list[dict[str, Any]]) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    """Resolve exact source+alias identity overlaps with deterministic grouping."""
    remaining = [copy.deepcopy(row) for row in entities]
    resolved: list[dict[str, Any]] = []
    report: list[dict[str, Any]] = []
    while remaining:
        seed = remaining.pop(0)
        merged_names = [str(seed.get("name") or "")]
        changed = True
        while changed:
            changed = False
            survivors: list[dict[str, Any]] = []
            for candidate in remaining:
                if should_merge(seed, candidate):
                    merged_names.append(str(candidate.get("name") or ""))
                    seed = merge_entities(seed, candidate)
                    changed = True
                else:
                    survivors.append(candidate)
            remaining = survivors
        resolved.append(seed)
        if len(merged_names) > 1:
            report.append({
                "canonical_name": seed.get("name"),
                "merged_names": merged_names,
                "shared_source_pages": sorted(source_pages(seed)),
            })
    return resolved, report
