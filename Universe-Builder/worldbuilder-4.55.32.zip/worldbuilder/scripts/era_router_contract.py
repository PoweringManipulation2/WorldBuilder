#!/usr/bin/env python3
"""Validate and expose WorldBuilder's multi-era routing contract.

The era plan is the semantic authority for Scenario-keyed routing. The manifest
and activation graph must implement that plan exactly enough that each era can
be selected without temporal bleed.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any, Iterable

from wb_common import (
    ErrorCollector,
    WorldBuilderError,
    atomic_write_json,
    canonical_entry_identity,
    iter_entries,
    load_build_state,
    load_json,
    preflight_report,
    requirement_rows,
    resolve_state_path,
    sha256_file,
    uid_key,
)

KIND = "worldbuilder-era-plan"
PLAN_VERSION = 2
CONTRACT = "worldbuilder-era-router-v1"
RECEIPT_VERSION = 1
CONTEXT_GROUP = "worldbuilder-era-context"


def _string_list(value: Any, field: str, *, allow_empty: bool = True) -> list[str]:
    if value is None and allow_empty:
        return []
    problems = ErrorCollector()
    if not isinstance(value, list) or any(not isinstance(item, str) or not item.strip() for item in value):
        problems.add(f"{field} must be an array of non-empty strings")
        problems.raise_if_any()
    result: list[str] = []
    seen: set[str] = set()
    reported: set[str] = set()
    for item in value:
        clean = item.strip()
        folded = clean.casefold()
        if folded in seen:
            if folded not in reported:
                problems.add(f"{field} repeats {clean!r}")
                reported.add(folded)
            continue
        seen.add(folded)
        result.append(clean)
    problems.raise_if_any()
    return result


def _uid_list(value: Any, field: str, *, allow_empty: bool = True) -> list[str]:
    if value is None and allow_empty:
        return []
    problems = ErrorCollector()
    if not isinstance(value, list):
        problems.add(f"{field} must be an array of UIDs")
        problems.raise_if_any()
    result: list[str] = []
    seen: set[str] = set()
    reported: set[str] = set()
    for item in value:
        try:
            key = uid_key(item)
        except WorldBuilderError as exc:
            problems.add(str(exc))
            continue
        if key in seen:
            if key not in reported:
                problems.add(f"{field} repeats UID {key}")
                reported.add(key)
            continue
        seen.add(key)
        result.append(key)
    if not result and not allow_empty:
        problems.add(f"{field} must not be empty")
    problems.raise_if_any()
    return result


def _entries(manifest: dict[str, Any]) -> list[dict[str, Any]]:
    rows = manifest.get("entries")
    if not isinstance(rows, list) or not rows or any(not isinstance(row, dict) for row in rows):
        raise WorldBuilderError("manifest entries must be a non-empty array of objects")
    return rows


def _strict_entry_arch(entry: dict[str, Any]) -> dict[str, Any]:
    value = entry.get("architecture")
    if not isinstance(value, dict):
        raise WorldBuilderError(f"manifest entry {uid_key(entry.get('uid', entry.get('id')))} lacks architecture")
    return value


def _emit(entry: dict[str, Any]) -> dict[str, Any]:
    value = entry.get("emit")
    return value if isinstance(value, dict) else {}


def _extensions(entry: dict[str, Any]) -> dict[str, Any]:
    value = _emit(entry).get("extensions")
    return value if isinstance(value, dict) else {}


def _setting(entry: dict[str, Any], *names: str, default: Any = None) -> Any:
    emit = _emit(entry)
    ext = _extensions(entry)
    for name in names:
        if name in emit:
            return emit[name]
        if name in ext:
            return ext[name]
    return default


def _activation(entry: dict[str, Any]) -> dict[str, Any]:
    value = entry.get("activation")
    if not isinstance(value, dict):
        raise WorldBuilderError(f"manifest entry {uid_key(entry.get('uid', entry.get('id')))} lacks activation")
    return value


def _canonical_keyword(era: dict[str, Any], *, v2: bool) -> str:
    problems = ErrorCollector()
    explicit = str(era.get("scenario_keyword", "")).strip()
    if explicit:
        if not explicit.casefold().startswith("era:"):
            problems.add(f"era {era.get('id')} scenario_keyword must start with 'Era:'")
            problems.raise_if_any()
        return explicit
    keywords = None
    try:
        keywords = _string_list(era.get("keywords", []), f"era {era.get('id')} keywords", allow_empty=False)
    except WorldBuilderError as exc:
        problems.add(str(exc))
        problems.raise_if_any()
    matches = [item for item in keywords if item.casefold().startswith("era:")]
    if len(matches) != 1 and v2:
        problems.add(f"era {era.get('id')} needs exactly one canonical 'Era: ...' keyword")
    elif not matches:
        problems.add(f"era {era.get('id')} needs a copyable 'Era: ...' keyword")
    problems.raise_if_any()
    return matches[0]


def _keyword_matches(text: str, keyword: str, *, canonical: bool) -> bool:
    """Match canonical Era lines exactly and aliases on token boundaries."""
    if canonical:
        wanted = re.sub(r"\s+", " ", keyword.strip()).casefold()
        return any(re.sub(r"\s+", " ", line.strip()).casefold() == wanted for line in text.splitlines())
    normalized_text = re.sub(r"\s+", " ", text)
    escaped = re.escape(re.sub(r"\s+", " ", keyword.strip()))
    return re.search(rf"(?<![\w]){escaped}(?![\w])", normalized_text, flags=re.IGNORECASE) is not None


def validate_plan(plan: dict[str, Any], *, build_id: str | None = None, require_v2: bool = False) -> dict[str, Any]:
    problems = ErrorCollector()
    if plan.get("kind") != KIND:
        problems.add("era-plan.json has the wrong kind")
    version = plan.get("plan_version")
    if version not in {1, 2}:
        problems.add("era-plan.json has an unsupported plan_version")
    if plan.get("kind") != KIND or version not in {1, 2}:
        problems.add("dependent checks skipped: era-plan field checks (kind or plan_version is unusable)")
        problems.raise_if_any()
    if require_v2 and version != PLAN_VERSION:
        problems.add("this build requires worldbuilder era-plan v2")
    if build_id is not None and plan.get("build_id") != build_id:
        problems.add("era-plan.json belongs to another build")
    if plan.get("mode") != "multi":
        problems.add("era router requires mode 'multi'")
    if plan.get("isolation") not in {"strict", "balanced"}:
        problems.add("era plan isolation must be strict or balanced")
    if plan.get("user_approved") is not True:
        problems.add("era-plan.json must record explicit user approval")
    if version == 2 and plan.get("contract") != CONTRACT:
        problems.add("era-plan v2 lacks worldbuilder-era-router-v1")

    routing = plan.get("routing", {}) if version == 2 else {}
    if version == 2:
        if not isinstance(routing, dict):
            problems.add("era-plan routing must be an object")
        else:
            expected = {
                "source": "scenario",
                "single_authoritative": True,
                "replace_on_switch": True,
                "conflict_policy": "fail",
                "context_group": CONTEXT_GROUP,
            }
            for key, value in expected.items():
                if routing.get(key) != value:
                    problems.add(f"era-plan routing.{key} must be {value!r}")

    eras = plan.get("eras")
    if not isinstance(eras, list) or len(eras) < 2 or any(not isinstance(row, dict) for row in eras):
        problems.add("multi-era plan requires at least two era objects")
        problems.add("dependent checks skipped: era, event, and entity-state checks (the era table is unusable)")
        problems.raise_if_any()
    ids: set[str] = set()
    orders: set[int] = set()
    keyword_owner: dict[str, str] = {}
    canonical: dict[str, str] = {}
    eras_ok = True
    for era in eras:
        era_id = str(era.get("id", "")).strip()
        name = str(era.get("name", "")).strip()
        order = era.get("order")
        if not era_id or not name or not isinstance(order, int) or isinstance(order, bool):
            problems.add("each era needs id, name, and integer order")
            problems.add("dependent checks skipped: per-era field checks for an era with an unusable id, name, or order")
            eras_ok = False
            continue
        if era_id in ids or order in orders:
            problems.add("era ids and orders must be unique")
            eras_ok = False
            continue
        ids.add(era_id)
        orders.add(order)
        keys = None
        try:
            keys = _string_list(era.get("keywords", []), f"era {era_id} keywords", allow_empty=False)
        except WorldBuilderError as exc:
            problems.add(str(exc))
        canon = None
        try:
            canon = _canonical_keyword(era, v2=version == 2)
        except WorldBuilderError as exc:
            problems.add(str(exc))
        if keys is not None:
            canonical_keys = [item for item in keys if item.casefold().startswith("era:")]
            if version == 2 and len(canonical_keys) != 1:
                problems.add(f"era {era_id} needs exactly one canonical 'Era: ...' keyword")
            if canon is not None:
                if canon.casefold() not in {item.casefold() for item in keys}:
                    problems.add(f"era {era_id} canonical Scenario keyword must also appear in keywords")
                if version == 2 and canonical_keys and canonical_keys[0].casefold() != canon.casefold():
                    problems.add(f"era {era_id} scenario_keyword disagrees with its canonical keywords entry")
            for keyword in keys:
                folded = keyword.casefold()
                owner = keyword_owner.get(folded)
                if owner and owner != era_id:
                    problems.add(f"era keyword {keyword!r} is shared by {owner} and {era_id}")
                keyword_owner[folded] = era_id
        if canon is not None:
            canonical[era_id] = canon
        for field in ("active_characters", "active_factions", "active_locations", "future_events", "past_events"):
            try:
                _string_list(era.get(field, []), f"era {era_id} {field}")
            except WorldBuilderError as exc:
                problems.add(str(exc))
        if version == 2:
            for field in ("start_boundary", "end_boundary", "world_state"):
                if not isinstance(era.get(field), str) or not str(era.get(field)).strip():
                    problems.add(f"era {era_id} needs non-empty {field}")
            for field in ("knowledge_restrictions", "state_assertions", "prohibited_state_terms"):
                try:
                    _string_list(era.get(field, []), f"era {era_id} {field}")
                except WorldBuilderError as exc:
                    problems.add(str(exc))
    if not eras_ok:
        problems.add("dependent checks skipped: era order, event, and entity-state checks (some eras are unusable)")
    elif sorted(orders) != list(range(1, len(eras) + 1)):
        problems.add("era order values must be contiguous starting at 1")
        problems.add("dependent checks skipped: event and entity-state checks (era orders are not contiguous)")
    else:
        order_by_id = {str(row["id"]): int(row["order"]) for row in eras}
        for event in plan.get("events", []):
            if not isinstance(event, dict):
                problems.add("era-plan events must be objects")
                continue
            origin = str(event.get("origin_era_id", ""))
            visible = None
            try:
                visible = _string_list(event.get("visible_in_eras", []), "event visible_in_eras", allow_empty=False)
            except WorldBuilderError as exc:
                problems.add(str(exc))
            if visible is None:
                problems.add("dependent checks skipped: event visibility and history checks (visible_in_eras is unusable)")
                continue
            if origin not in order_by_id or origin not in visible:
                problems.add("every event needs a valid origin era included in visible_in_eras")
                continue
            expected = {era_id for era_id, order in order_by_id.items() if order >= order_by_id[origin]}
            if set(visible) != expected:
                problems.add("event visibility must include its origin and every later era, with no earlier era")
                continue
            if version == 2:
                if not str(event.get("event_id", "")).strip() or not str(event.get("name", "")).strip():
                    problems.add("era-plan v2 events need event_id and name")
                known = None
                try:
                    known = _string_list(event.get("known_as_history_from_eras", visible), "event known_as_history_from_eras", allow_empty=False)
                except WorldBuilderError as exc:
                    problems.add(str(exc))
                if known is not None:
                    if any(item not in order_by_id for item in known):
                        problems.add("event known_as_history_from_eras references an unknown era")
                    if any(item in order_by_id and order_by_id[item] < order_by_id[origin] for item in known):
                        problems.add("event cannot be known history before its origin era")
        entity_keys: set[str] = set()
        state_ids: set[str] = set()
        state_uid_owner: dict[str, str] = {}
        for entity in plan.get("entity_states", []):
            if not isinstance(entity, dict):
                problems.add("entity_states must contain objects")
                continue
            states = entity.get("states", [])
            if not isinstance(states, list) or not states or any(not isinstance(row, dict) for row in states):
                problems.add("entity_states.states must be a non-empty array of objects")
                continue
            state_eras = [str(row.get("era_id", "")) for row in states]
            if len(state_eras) != len(set(state_eras)):
                problems.add("one entity cannot define multiple states for the same era")
            if any(era_id not in order_by_id for era_id in state_eras):
                problems.add("entity state references an unknown era")
            if entity.get("split_required") is True and len(set(state_eras)) < 2:
                problems.add("split_required entity needs at least two era states")
            if version == 2:
                entity_key = str(entity.get("entity_key", "")).strip()
                entity_name = str(entity.get("name", "")).strip()
                if not entity_key or not entity_name:
                    problems.add("era-plan v2 entity_states need entity_key and name")
                if entity_key and entity_name:
                    folded_key = entity_key.casefold()
                    if folded_key in entity_keys:
                        problems.add(f"era-plan repeats entity_key {entity_key!r}")
                    entity_keys.add(folded_key)
                reasons = None
                try:
                    reasons = _string_list(entity.get("reasons", []), "entity state split reasons")
                except WorldBuilderError as exc:
                    problems.add(str(exc))
                if entity.get("split_required") is True and reasons is not None and not reasons:
                    problems.add("split_required entity needs at least one split reason")
                for state in states:
                    state_id = str(state.get("state_id", "")).strip()
                    if not state_id:
                        problems.add("era-plan v2 entity state needs state_id")
                        continue
                    if state_id.casefold() in state_ids:
                        problems.add(f"era-plan repeats state_id {state_id!r}")
                        continue
                    state_ids.add(state_id.casefold())
                    manifest_uids = None
                    try:
                        manifest_uids = _uid_list(state.get("manifest_uids", []), "entity state manifest_uids", allow_empty=False)
                    except WorldBuilderError as exc:
                        problems.add(str(exc))
                    if manifest_uids is not None:
                        for manifest_uid in manifest_uids:
                            owner = state_uid_owner.get(manifest_uid)
                            if owner is not None:
                                problems.add(f"manifest UID {manifest_uid} belongs to multiple era states: {owner} and {state_id}")
                                continue
                            state_uid_owner[manifest_uid] = state_id
                    for field in ("required_terms", "forbidden_terms", "knowledge_boundaries", "relationships", "goals"):
                        try:
                            _string_list(state.get(field, []), f"entity state {field}")
                        except WorldBuilderError as exc:
                            problems.add(str(exc))
    problems.raise_if_any()
    return {
        "plan_version": version,
        "era_count": len(eras),
        "canonical_keywords": canonical,
        "order_by_id": order_by_id,
        "keyword_owner": keyword_owner,
    }


def load_bound_plan(root: Path, state: dict[str, Any], manifest: dict[str, Any], *, required: bool) -> tuple[dict[str, Any] | None, Path | None, dict[str, Any] | None]:
    problems = ErrorCollector()
    path = resolve_state_path(root, state, "era_plan", required=False)
    if path is None or not path.exists():
        if required:
            problems.add("multi-era build requires artifacts/era-plan.json")
            problems.raise_if_any()
        return None, None, None
    plan = load_json(path)
    if not isinstance(plan, dict):
        problems.add("era-plan.json must be an object")
        problems.raise_if_any()
    require_v2 = state.get("content_architecture", {}).get("era_router_contract") == CONTRACT
    detail = None
    try:
        detail = validate_plan(plan, build_id=str(state.get("build_id", "")), require_v2=require_v2)
    except WorldBuilderError as exc:
        problems.add(str(exc))
    expected = manifest.get("era_plan_sha256")
    if expected != sha256_file(path):
        problems.add("manifest is not bound to the current era-plan.json")
    problems.raise_if_any()
    return plan, path, detail


def _manifest_by_uid(manifest: dict[str, Any]) -> dict[str, dict[str, Any]]:
    problems = ErrorCollector()
    result: dict[str, dict[str, Any]] = {}
    for row in _entries(manifest):
        try:
            key = uid_key(row.get("uid", row.get("id")))
        except WorldBuilderError as exc:
            problems.add(str(exc))
            continue
        if key in result:
            problems.add(f"manifest repeats UID {key}")
            continue
        result[key] = row
    problems.raise_if_any()
    return result


def _edges(manifest: dict[str, Any]) -> list[dict[str, Any]]:
    graph = manifest.get("activation_graph")
    if not isinstance(graph, dict) or not isinstance(graph.get("edges"), list):
        raise WorldBuilderError("manifest lacks activation_graph.edges")
    return [row for row in graph["edges"] if isinstance(row, dict)]


def validate_manifest_router(plan: dict[str, Any], manifest: dict[str, Any]) -> dict[str, Any]:
    problems = ErrorCollector()
    detail = None
    try:
        detail = validate_plan(plan)
    except WorldBuilderError as exc:
        problems.add(str(exc))
    if detail is None:
        problems.add("dependent checks skipped: manifest router checks (the era plan is invalid)")
        problems.raise_if_any()
    version = detail["plan_version"]
    by_uid = None
    try:
        by_uid = _manifest_by_uid(manifest)
    except WorldBuilderError as exc:
        problems.add(str(exc))
    if not by_uid:
        problems.add("dependent checks skipped: manifest router checks (no usable manifest entries)")
        problems.raise_if_any()
    edges_ok = True
    edges: list[dict[str, Any]] = []
    try:
        edges = _edges(manifest)
    except WorldBuilderError as exc:
        problems.add(str(exc))
        edges_ok = False
    context_by_era: dict[str, dict[str, Any]] = {}
    state_entries = 0
    for entry in by_uid.values():
        try:
            arch = _strict_entry_arch(entry)
        except WorldBuilderError as exc:
            problems.add(str(exc))
            continue
        layer = arch.get("layer")
        era_ids = arch.get("era_ids", [])
        if layer == "era_context":
            if not isinstance(era_ids, list) or len(era_ids) != 1:
                problems.add("each era context must own exactly one era")
                continue
            era_id = str(era_ids[0])
            if era_id in context_by_era:
                problems.add(f"duplicate era context for {era_id}")
                continue
            context_by_era[era_id] = entry
            if arch.get("era_group") not in {None, CONTEXT_GROUP}:
                problems.add(f"era context {era_id} uses the wrong semantic era group")
            if version == 2 and arch.get("era_group") != CONTEXT_GROUP:
                problems.add(f"era context {era_id} must declare era_group={CONTEXT_GROUP}")
        if arch.get("era_scope") in {"state", "event"}:
            state_entries += 1

    era_rows = {str(row["id"]): row for row in plan["eras"]}
    if set(context_by_era) != set(era_rows):
        problems.add("era context coverage does not match the approved era plan")

    edge_pairs: set[tuple[str, str, str]] = set()
    for row in edges:
        try:
            edge_pairs.add((uid_key(row.get("source_uid")), uid_key(row.get("target_uid")), str(row.get("trigger", "")).casefold()))
        except WorldBuilderError as exc:
            problems.add(str(exc))
    active_edge_count = 0
    for era_id, era in era_rows.items():
        context = context_by_era.get(era_id)
        if context is None:
            continue
        uid = uid_key(context.get("uid", context.get("id")))
        emit = _emit(context)
        activation = _activation(context)
        keys = None
        try:
            keys = _string_list(emit.get("keys", emit.get("key", [])), f"era context {era_id} keys", allow_empty=False)
        except WorldBuilderError as exc:
            problems.add(str(exc))
        canonical = None
        try:
            canonical = _canonical_keyword(era, v2=version == 2)
        except WorldBuilderError as exc:
            problems.add(str(exc))
        if keys is not None and canonical is not None and canonical.casefold() not in {item.casefold() for item in keys}:
            problems.add(f"era context {era_id} lacks canonical Scenario keyword {canonical!r}")
        if activation.get("strategy") != "keyword" or activation.get("recursion_role") not in {"seed", "anchor"}:
            problems.add(f"era context {era_id} must be a keyword seed/anchor")
        if bool(_setting(context, "constant", default=False)) or bool(_setting(context, "selective", default=False)):
            problems.add(f"era context {era_id} must be non-constant and non-selective")
        if _setting(context, "match_scenario", "matchScenario", default=False) is not True:
            problems.add(f"era context {era_id} must match Scenario")
        if _setting(context, "prevent_recursion", "preventRecursion", default=False) is True:
            problems.add(f"era context {era_id} must allow planned recursion")

        active_names: list[str] = []
        for field in ("active_characters", "active_factions", "active_locations"):
            try:
                active_names.extend(_string_list(era.get(field, []), f"era {era_id} {field}"))
            except WorldBuilderError as exc:
                problems.add(str(exc))
        declared = {str(item).casefold() for item in activation.get("emits", []) if isinstance(item, str)}
        for name in active_names:
            ok = True
            if name.casefold() not in declared:
                problems.add(f"era context {era_id} does not declare active entity trigger {name!r}")
                ok = False
            targets: list[str] = []
            if ok:
                for target_uid, target in by_uid.items():
                    try:
                        target_arch = _strict_entry_arch(target)
                    except WorldBuilderError:
                        continue
                    target_eras = {str(item) for item in target_arch.get("era_ids", []) if str(item)}
                    try:
                        target_keys = _string_list(_emit(target).get("keys", _emit(target).get("key", [])), f"entry {target_uid} keys")
                    except WorldBuilderError:
                        target_keys = []
                    if era_id in target_eras and name.casefold() in {item.casefold() for item in target_keys}:
                        targets.append(target_uid)
                if not targets:
                    problems.add(f"active entity {name!r} in era {era_id} has no era-scoped manifest entry")
                    ok = False
            if ok and not edges_ok:
                problems.add(f"dependent checks skipped: recursion edge check for active entity {name!r} in era {era_id} (activation_graph.edges is unusable)")
                ok = False
            if ok and not any((uid, target_uid, name.casefold()) in edge_pairs for target_uid in targets):
                problems.add(f"era context {era_id} lacks a recursion edge for active entity {name!r}")
                ok = False
            if ok:
                active_edge_count += 1

    if version == 2:
        for entity in plan.get("entity_states", []):
            for state_row in entity.get("states", []):
                era_id = str(state_row.get("era_id", ""))
                for raw_uid in state_row.get("manifest_uids", []):
                    try:
                        key = uid_key(raw_uid)
                    except WorldBuilderError as exc:
                        problems.add(str(exc))
                        continue
                    entry = by_uid.get(key)
                    if entry is None:
                        problems.add(f"era entity state references missing manifest UID {key}")
                        continue
                    try:
                        target_arch = _strict_entry_arch(entry)
                    except WorldBuilderError:
                        continue
                    if era_id not in {str(item) for item in target_arch.get("era_ids", [])}:
                        problems.add(f"manifest UID {key} is not scoped to planned era {era_id}")

    problems.raise_if_any()
    return {
        "era_count": len(era_rows),
        "era_context_count": len(context_by_era),
        "era_state_entry_count": state_entries,
        "active_entity_edge_count": active_edge_count,
        "canonical_keywords": detail["canonical_keywords"],
    }


def route_scenario(plan: dict[str, Any], text: str) -> dict[str, Any]:
    detail = validate_plan(plan)
    problems = ErrorCollector()
    matched: list[dict[str, Any]] = []
    for era in plan["eras"]:
        try:
            keys = _string_list(era.get("keywords", []), f"era {era.get('id')} keywords", allow_empty=False)
        except WorldBuilderError as exc:
            problems.add(str(exc))
            continue
        try:
            canonical = _canonical_keyword(era, v2=detail["plan_version"] == 2)
        except WorldBuilderError as exc:
            problems.add(str(exc))
            continue
        hits = [key for key in keys if _keyword_matches(text, key, canonical=key.casefold() == canonical.casefold())]
        if hits:
            matched.append({"era_id": str(era["id"]), "era_name": str(era["name"]), "matched_keywords": hits})
    problems.raise_if_any()
    if len(matched) > 1:
        return {"status": "conflict", "matched_eras": matched, "instruction": "Keep exactly one Era: ... line in Scenario."}
    if not matched:
        return {"status": "unselected", "matched_eras": [], "instruction": "Add one approved Era: ... line to Scenario."}
    return {"status": "selected", "era_id": matched[0]["era_id"], "era_name": matched[0]["era_name"], "matched_keywords": matched[0]["matched_keywords"]}


def assignment_context(plan: dict[str, Any] | None, manifest: dict[str, Any], uids: Iterable[Any]) -> dict[str, Any]:
    if plan is None:
        return {"contract": None, "plan_version": None, "selected_eras": [], "era_rows": [], "state_rows": [], "event_rows": []}
    wanted = {uid_key(value) for value in uids}
    selected_eras: set[str] = set()
    for row in _entries(manifest):
        key = uid_key(row.get("uid", row.get("id")))
        if key in wanted:
            selected_eras.update(str(item) for item in _strict_entry_arch(row).get("era_ids", []) if str(item))
    era_rows = []
    for era in plan.get("eras", []):
        if str(era.get("id")) in selected_eras:
            era_rows.append({
                "id": era.get("id"),
                "name": era.get("name"),
                "order": era.get("order"),
                "scenario_keyword": _canonical_keyword(era, v2=plan.get("plan_version") == 2),
                "keywords": era.get("keywords", []),
                "start_boundary": era.get("start_boundary"),
                "end_boundary": era.get("end_boundary"),
                "world_state": era.get("world_state"),
                "past_events": era.get("past_events", []),
                "future_events": era.get("future_events", []),
                "knowledge_restrictions": era.get("knowledge_restrictions", []),
                "state_assertions": era.get("state_assertions", []),
                "prohibited_state_terms": era.get("prohibited_state_terms", []),
            })
    state_rows = []
    for entity in plan.get("entity_states", []):
        for state_row in entity.get("states", []):
            state_uids = {uid_key(value) for value in state_row.get("manifest_uids", [])}
            if wanted.intersection(state_uids):
                state_rows.append({
                    "entity_key": entity.get("entity_key"),
                    "entity_name": entity.get("name"),
                    "entity_type": entity.get("type"),
                    "split_reasons": entity.get("reasons", []),
                    **state_row,
                })
    event_rows = [row for row in plan.get("events", []) if selected_eras.intersection(str(item) for item in row.get("visible_in_eras", []))]
    return {
        "contract": CONTRACT,
        "plan_version": plan.get("plan_version"),
        "routing": plan.get("routing", {}),
        "selected_eras": sorted(selected_eras),
        "era_rows": era_rows,
        "state_rows": state_rows,
        "event_rows": event_rows,
    }


def _output_index(data: dict[str, Any]) -> dict[str, dict[str, Any]]:
    result: dict[str, dict[str, Any]] = {}
    for ref in iter_entries(data):
        ident = canonical_entry_identity(ref.entry)
        if ident is not None:
            result[str(ident)] = ref.entry
    return result


def _entry_text(entry: dict[str, Any]) -> str:
    value = entry.get("content")
    return value if isinstance(value, str) else ""


def validate_output(plan: dict[str, Any], manifest: dict[str, Any], data: dict[str, Any]) -> dict[str, Any]:
    problems = ErrorCollector()
    detail = None
    try:
        detail = validate_manifest_router(plan, manifest)
    except WorldBuilderError as exc:
        problems.add(str(exc))
    if detail is None:
        problems.add("dependent checks skipped: era-router output checks (the manifest router check failed)")
        problems.raise_if_any()
    index = _output_index(data)
    by_uid = None
    try:
        by_uid = _manifest_by_uid(manifest)
    except WorldBuilderError as exc:
        problems.add(str(exc))
    if not by_uid:
        problems.add("dependent checks skipped: era-router output checks (no usable manifest entries)")
        problems.raise_if_any()
    era_rows = {str(row["id"]): row for row in plan["eras"]}
    checked = 0
    for uid, mentry in by_uid.items():
        try:
            arch = _strict_entry_arch(mentry)
        except WorldBuilderError:
            continue
        era_ids = [str(item) for item in arch.get("era_ids", []) if str(item)]
        if not era_ids or uid not in index or arch.get("layer") == "era_context":
            continue
        text = _entry_text(index[uid])
        folded = text.casefold()
        row_ok = True
        for era_id in era_ids:
            era = era_rows.get(era_id)
            if era is None:
                continue
            for term in era.get("prohibited_state_terms", []):
                if str(term).strip() and str(term).casefold() in folded:
                    problems.add(f"temporal leakage: UID {uid} for era {era_id} contains prohibited state term {term!r}")
                    row_ok = False
        if row_ok:
            checked += 1
    for entity in plan.get("entity_states", []):
        for state_row in entity.get("states", []):
            required = None
            try:
                required = _string_list(state_row.get("required_terms", []), "entity state required_terms")
            except WorldBuilderError as exc:
                problems.add(str(exc))
            forbidden = None
            try:
                forbidden = _string_list(state_row.get("forbidden_terms", []), "entity state forbidden_terms")
            except WorldBuilderError as exc:
                problems.add(str(exc))
            for raw_uid in state_row.get("manifest_uids", []):
                try:
                    uid = uid_key(raw_uid)
                except WorldBuilderError as exc:
                    problems.add(str(exc))
                    continue
                if uid not in index:
                    problems.add(f"planned era-state manifest UID {uid} is missing from output")
                    continue
                text = _entry_text(index[uid]).casefold()
                if required is not None:
                    for term in required:
                        if term.casefold() not in text:
                            problems.add(f"era-state UID {uid} omits required term {term!r}")
                if forbidden is not None:
                    for term in forbidden:
                        if term.casefold() in text:
                            problems.add(f"era-state UID {uid} contains forbidden term {term!r}")
    problems.raise_if_any()
    return {**detail, "era_scoped_outputs_checked": checked}


def validate(build_state: str, stage: str, artifact: str | None = None, *, write_receipt: bool = True) -> dict[str, Any]:
    problems = ErrorCollector()
    root, state = load_build_state(build_state)
    manifest_path = resolve_state_path(root, state, "manifest")
    manifest = load_json(manifest_path)
    if not isinstance(manifest, dict):
        problems.add("manifest must be an object")
        problems.raise_if_any()
    architecture = manifest.get("architecture") if isinstance(manifest.get("architecture"), dict) else {}
    era_cfg = architecture.get("era") if isinstance(architecture.get("era"), dict) else {}
    required = era_cfg.get("mode") == "multi" and era_cfg.get("routing") != "root_toggle"
    plan = None
    plan_path = None
    plan_detail = None
    try:
        plan, plan_path, plan_detail = load_bound_plan(root, state, manifest, required=required)
    except WorldBuilderError as exc:
        problems.add(str(exc))
        problems.raise_if_any()
    if not required:
        result = {"kind": "worldbuilder-era-router-gate", "receipt_version": RECEIPT_VERSION, "status": "not_required", "stage": stage, "build_id": state.get("build_id"), "contract": CONTRACT}
        if write_receipt and stage == "planning":
            # integration_acceptance requires this file to exist whenever
            # era_router is a required system for the build: true for
            # every multi-era build, root_toggle included, not just
            # scenario. Skipping validation correctly for root_toggle is
            # not the same thing as never writing the receipt; without
            # this, the last planning step failed with "full-integration
            # gate requires era_router_receipt" on every root_toggle build.
            # required=False: a build-state that never declares this path
            # at all (confirmed real, pre-existing fixtures do this) must
            # keep working exactly as before. This only writes the
            # receipt when a real path is actually configured for it.
            receipt_path = resolve_state_path(root, state, "era_router_receipt", required=False)
            if receipt_path is not None:
                atomic_write_json(receipt_path, result)
                result["receipt"] = str(receipt_path)
                result["receipt_sha256"] = sha256_file(receipt_path)
        return result
    if plan is None or plan_path is None or plan_detail is None:
        problems.add("dependent checks skipped: era-router gate checks (the era plan is unavailable)")
        problems.raise_if_any()
    if stage == "planning":
        detail = None
        try:
            detail = validate_manifest_router(plan, manifest)
        except WorldBuilderError as exc:
            problems.add(str(exc))
        if detail is None:
            problems.add("dependent checks skipped: era-router receipt generation (the manifest router check failed)")
            problems.raise_if_any()
        target_sha = sha256_file(manifest_path)
    else:
        target = Path(artifact).resolve() if artifact else resolve_state_path(root, state, "final_output")
        data = load_json(target)
        if not isinstance(data, dict):
            problems.add("output artifact must be JSON")
            problems.raise_if_any()
        detail = None
        try:
            detail = validate_output(plan, manifest, data)
        except WorldBuilderError as exc:
            problems.add(str(exc))
        if detail is None:
            problems.add("dependent checks skipped: era-router receipt generation (the output check failed)")
            problems.raise_if_any()
        target_sha = sha256_file(target)
    result = {
        "kind": "worldbuilder-era-router-gate",
        "receipt_version": RECEIPT_VERSION,
        "status": "passed",
        "stage": stage,
        "build_id": state.get("build_id"),
        "contract": CONTRACT,
        "era_plan": str(plan_path.relative_to(root)).replace("\\", "/"),
        "era_plan_sha256": sha256_file(plan_path),
        "manifest_sha256": sha256_file(manifest_path),
        "target_sha256": target_sha,
        **detail,
    }
    if write_receipt and stage == "planning":
        receipt_path = resolve_state_path(root, state, "era_router_receipt")
        atomic_write_json(receipt_path, result)
        result["receipt"] = str(receipt_path)
        result["receipt_sha256"] = sha256_file(receipt_path)
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--build-state")
    parser.add_argument("--stage", choices=["planning", "output"], default="planning")
    parser.add_argument("--artifact")
    parser.add_argument("--scenario-text")
    parser.add_argument("--era-plan")
    parser.add_argument("--no-write-receipt", action="store_true")
    parser.add_argument("--requirements", action="store_true", help="Read-only preflight: print what this gate checks against the current build state.")
    args = parser.parse_args()
    if args.requirements:
        if not args.build_state:
            parser.error("--requirements needs --build-state")
        root, state = load_build_state(args.build_state)
        print(json.dumps(preflight_report("era_router_contract", requirement_rows(Path(__file__), root, state)), ensure_ascii=False, indent=2))
        return 0
    try:
        if args.scenario_text is not None:
            if not args.era_plan:
                raise WorldBuilderError("--scenario-text requires --era-plan")
            plan = load_json(Path(args.era_plan).expanduser().resolve())
            if not isinstance(plan, dict):
                raise WorldBuilderError("era plan must be an object")
            result = route_scenario(plan, args.scenario_text)
        else:
            if not args.build_state:
                raise WorldBuilderError("--build-state is required")
            result = validate(args.build_state, args.stage, args.artifact, write_receipt=not args.no_write_receipt)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (WorldBuilderError, OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
