#!/usr/bin/env python3
"""Character identity, behavior, state, and relationship planning contract.

The character plan is a deterministic planning artifact. It separates stable
identity/behavior from era-specific state, records relationship consequences,
and supplies exact required/forbidden terms to generation workers and gates.
"""
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Any

from wb_common import (
    ErrorCollector,
    WorldBuilderError,
    load_build_state,
    load_json,
    preflight_report,
    requirement_rows,
    resolve_state_path,
    sha256_file,
)

CONTRACT = "worldbuilder-character-system-v1"
KIND = "worldbuilder-character-plan"
PLAN_VERSION = 1

IDENTITY_LIST_FIELDS = ("pronouns", "occupations", "factions")
IDENTITY_TEXT_FIELDS = ("species", "age_state", "rank", "location", "life_status", "physical_form")
BEHAVIOR_LIST_FIELDS = (
    "speech_patterns", "vocabulary", "drives", "fears", "values", "habits",
    "relationship_behavior", "capabilities", "limitations", "knowledge_boundaries",
    "secrets_known", "secrets_unknown",
)
BEHAVIOR_TEXT_FIELDS = ("emotional_regulation", "conflict_behavior")
STATE_LIST_FIELDS = (
    "occupations", "factions", "goals", "knowledge_boundaries", "secrets_known",
    "secrets_unknown", "required_vitals_terms", "required_voice_terms",
    "required_current_terms", "forbidden_knowledge_terms",
)
STATE_TEXT_FIELDS = ("life_status", "role", "rank", "location", "physical_form")
SPLIT_REASONS = {
    "life_status", "role", "rank", "allegiance", "location", "relationships",
    "knowledge", "physical_form", "capabilities", "goals", "reputation", "equipment",
}
LORE_SECTIONS = (
    "TIMELINE", "VITALS", "PERSONALITY & VOICE", "CONNECTIONS",
    "APPEARANCE", "BACKSTORY", "CURRENT",
)

# Core/state split (DR-059). Under the old Scenario router only one variant fired, so
# every era state had to be self-sufficient and carried all seven sections. The cascade
# lets a core entry co-occur with whichever state won, so invariant material is written
# once and cannot drift between eras.
CORE_SECTIONS = ("VITALS", "PERSONALITY & VOICE", "APPEARANCE")
STATE_SECTIONS = ("TIMELINE", "VITALS", "CONNECTIONS", "BACKSTORY", "CURRENT")

# Categories the Warden lens examines in core content. These are HINTS for a
# semantic reviewer, never a verdict: a script cannot tell "the bridge serves the
# eastern quarter" from "he serves House Vane", and it misses "his loyalty lies with"
# entirely. Structure is checkable; meaning is the auditor's job.
CONTAMINATION_PATTERNS: tuple[tuple[str, str, str], ...] = (
    ("status", r"\b(?:is|are|remains?|currently)\s+(?:alive|dead|deceased|missing|imprisoned|exiled)\b",
     "life or freedom status changes between eras"),
    ("rank", r"\b(?:is|serves as|holds the rank of|now)\s+(?:the\s+)?(?:king|queen|lord|lady|warden|captain|commander|general|high\s+\w+)\b",
     "rank and title change between eras"),
    ("allegiance", r"\b(?:serves|belongs to|is loyal to|swore|sworn to|member of)\b",
     "allegiance changes between eras"),
    ("location", r"\b(?:lives in|resides in|is stationed|is based|currently in|has fled to)\b",
     "location changes between eras"),
    ("relationship", r"\b(?:is married to|is betrothed|is the (?:husband|wife|widow|widower) of|rules alongside)\b",
     "relationships change between eras"),
    ("knowledge", r"\b(?:knows about|has learned|is aware of|discovered)\b",
     "knowledge state changes between eras"),
)


def suggest_core_review(text: str, *, name: str = "core entry") -> list[str]:
    """Surface passages a semantic reviewer should look at. Never a verdict.

    Hoisting invariants into a core entry created a place to put a wrong permanent
    claim, and that risk is real. What is not real is a script's ability to judge it:
    keyword matching flags "the bridge serves the eastern quarter" and misses "his
    loyalty lies with House Vane".

    So this produces candidates for the Warden lens, which owns era exclusivity and
    temporal leakage and can read for meaning. Nothing here blocks a build.
    """
    problems: list[str] = []
    for label, pattern, why in CONTAMINATION_PATTERNS:
        for match in re.finditer(pattern, text, re.IGNORECASE):
            snippet = text[max(0, match.start() - 30):match.end() + 30].replace("\n", " ").strip()
            problems.append(
                f"{name}: possible {label} claim in core content ({why}): "
                f"...{snippet}... Warden should confirm whether this is era-specific; "
                "if so, move it to the era state or restate it without present-tense status."
            )
    return problems


def _string(value: Any, label: str, *, allow_blank: bool = False) -> str:
    if not isinstance(value, str):
        raise WorldBuilderError(f"{label} must be a string")
    clean = value.strip()
    if not clean and not allow_blank:
        raise WorldBuilderError(f"{label} must not be blank")
    return clean


def _string_list(value: Any, label: str, *, allow_empty: bool = True) -> list[str]:
    problems = ErrorCollector()
    if not isinstance(value, list) or any(not isinstance(item, str) for item in value):
        problems.add(f"{label} must be a string array")
        problems.raise_if_any()
    clean = [item.strip() for item in value if item.strip()]
    folded = [item.casefold() for item in clean]
    if len(folded) != len(set(folded)):
        problems.add(f"{label} contains duplicates")
    if not allow_empty and not clean:
        problems.add(f"{label} must not be empty")
    problems.raise_if_any()
    return clean


def _uid_key(value: Any) -> str:
    if isinstance(value, bool) or not isinstance(value, (str, int)):
        raise WorldBuilderError("character state manifest_uids must contain string/integer UIDs")
    clean = str(value).strip()
    if not clean:
        raise WorldBuilderError("character state manifest UID must not be blank")
    return clean


def manifest_character_rows(manifest: dict[str, Any]) -> list[dict[str, Any]]:
    entries = manifest.get("entries")
    if not isinstance(entries, list):
        return []
    return [row for row in entries if isinstance(row, dict) and str(row.get("type", "")).casefold() == "character"]


def validate_plan(plan: dict[str, Any], *, expected_build_id: str | None = None, era_ids: set[str] | None = None) -> dict[str, Any]:
    problems = ErrorCollector()
    if plan.get("kind") != KIND or plan.get("plan_version") != PLAN_VERSION or plan.get("contract") != CONTRACT:
        problems.add("character-plan.json has the wrong kind/version/contract")
        problems.raise_if_any()
    build_id = None
    try:
        build_id = _string(plan.get("build_id"), "character plan build_id")
    except WorldBuilderError as exc:
        problems.add(str(exc))
    if expected_build_id is not None and build_id is not None and build_id != expected_build_id:
        problems.add("character-plan.json belongs to another build")
    mode = plan.get("timeframe_mode")
    if mode not in {"single", "multi", "set"}:
        problems.add("character plan timeframe_mode must be single, multi, or set")
    characters = plan.get("characters")
    if not isinstance(characters, list) or not characters:
        problems.add("character plan requires at least one character")
        problems.add("dependent checks skipped: character and relationship checks (the characters table is unusable)")
        problems.raise_if_any()

    char_by_id: dict[str, dict[str, Any]] = {}
    state_owner: dict[str, str] = {}
    uid_owner: dict[str, tuple[str, str]] = {}
    state_by_id: dict[str, dict[str, Any]] = {}
    alias_owner: dict[str, str] = {}

    for index, character in enumerate(characters):
        if not isinstance(character, dict):
            problems.add(f"character plan row {index} must be an object")
            continue
        character_id = None
        try:
            character_id = _string(character.get("character_id"), f"character row {index} character_id")
        except WorldBuilderError as exc:
            problems.add(str(exc))
        if character_id is None:
            problems.add(f"dependent checks skipped: character plan row {index} checks (character_id is unusable)")
            continue
        if character_id in char_by_id:
            problems.add(f"duplicate character_id {character_id!r}")
            continue
        canonical_name = None
        try:
            canonical_name = _string(character.get("canonical_name"), f"character {character_id} canonical_name")
        except WorldBuilderError as exc:
            problems.add(str(exc))
        aliases = None
        try:
            aliases = _string_list(character.get("aliases", []), f"character {character_id} aliases")
        except WorldBuilderError as exc:
            problems.add(str(exc))
        titles = None
        try:
            titles = _string_list(character.get("titles", []), f"character {character_id} titles")
        except WorldBuilderError as exc:
            problems.add(str(exc))
        if canonical_name is not None and aliases is not None and canonical_name.casefold() in {alias.casefold() for alias in aliases}:
            problems.add(f"character {character_id} repeats its canonical name as an alias")
        if canonical_name is not None:
            for name in [canonical_name, *(aliases or [])]:
                folded = name.casefold()
                other = alias_owner.get(folded)
                if other and other != character_id:
                    problems.add(f"character identity alias {name!r} is shared by {other} and {character_id}")
                alias_owner[folded] = character_id

        identity = character.get("identity")
        if not isinstance(identity, dict):
            problems.add(f"character {character_id} identity must be an object")
            problems.add(f"dependent checks skipped: character {character_id} identity field checks (identity is not an object)")
        else:
            for field in IDENTITY_TEXT_FIELDS:
                try:
                    _string(identity.get(field, ""), f"character {character_id} identity.{field}", allow_blank=True)
                except WorldBuilderError as exc:
                    problems.add(str(exc))
            for field in IDENTITY_LIST_FIELDS:
                try:
                    _string_list(identity.get(field, []), f"character {character_id} identity.{field}")
                except WorldBuilderError as exc:
                    problems.add(str(exc))

        behavior = character.get("behavior")
        if not isinstance(behavior, dict):
            problems.add(f"character {character_id} behavior must be an object")
            problems.add(f"dependent checks skipped: character {character_id} behavior field checks (behavior is not an object)")
        else:
            for field in BEHAVIOR_TEXT_FIELDS:
                try:
                    _string(behavior.get(field, ""), f"character {character_id} behavior.{field}", allow_blank=True)
                except WorldBuilderError as exc:
                    problems.add(str(exc))
            for field in BEHAVIOR_LIST_FIELDS:
                try:
                    _string_list(behavior.get(field, []), f"character {character_id} behavior.{field}")
                except WorldBuilderError as exc:
                    problems.add(str(exc))
            if not any(behavior.get(field) for field in ("speech_patterns", "vocabulary", "drives", "values", "conflict_behavior")):
                problems.add(f"character {character_id} behavior model is empty")

        states = character.get("states")
        if not isinstance(states, list) or not states:
            problems.add(f"character {character_id} requires at least one state")
            problems.add(f"dependent checks skipped: character {character_id} state and split checks (no usable states)")
            char_by_id[character_id] = character
            continue
        local_state_ids: list[str] = []
        for state_index, state in enumerate(states):
            if not isinstance(state, dict):
                problems.add(f"character {character_id} state {state_index} must be an object")
                continue
            state_id = None
            try:
                state_id = _string(state.get("state_id"), f"character {character_id} state_id")
            except WorldBuilderError as exc:
                problems.add(str(exc))
            if state_id is None:
                problems.add(f"dependent checks skipped: character {character_id} state {state_index} checks (state_id is unusable)")
                continue
            if state_id in state_owner:
                problems.add(f"duplicate character state_id {state_id!r}")
                continue
            era_id = None
            try:
                era_id = _string(state.get("era_id"), f"character state {state_id} era_id")
            except WorldBuilderError as exc:
                problems.add(str(exc))
            if era_id is not None and era_ids is not None and era_id not in era_ids and era_id not in {"single", "unspecified"}:
                problems.add(f"character state {state_id} references unknown era {era_id!r}")
            manifest_uids = state.get("manifest_uids", [])
            clean_uids = None
            if not isinstance(manifest_uids, list):
                problems.add(f"character state {state_id} manifest_uids must be an array")
            else:
                clean_uids = []
                seen_uids: set[str] = set()
                for uid in manifest_uids:
                    try:
                        clean = _uid_key(uid)
                    except WorldBuilderError as exc:
                        problems.add(str(exc))
                        continue
                    if clean in seen_uids:
                        problems.add(f"character state {state_id} repeats a manifest UID")
                        continue
                    seen_uids.add(clean)
                    clean_uids.append(clean)
            reference_only = state.get("reference_only", False)
            if not isinstance(reference_only, bool):
                problems.add(f"character state {state_id} reference_only must be boolean")
            if clean_uids is not None and not clean_uids and not reference_only:
                problems.add(f"character state {state_id} needs manifest_uids or reference_only=true")
            if clean_uids is not None:
                for uid in clean_uids:
                    if uid in uid_owner:
                        problems.add(f"manifest UID {uid} is assigned to multiple character states")
                        continue
                    uid_owner[uid] = (character_id, state_id)
            for field in STATE_TEXT_FIELDS:
                try:
                    _string(state.get(field, ""), f"character state {state_id}.{field}", allow_blank=True)
                except WorldBuilderError as exc:
                    problems.add(str(exc))
            state_lists: dict[str, list[str] | None] = {}
            for field in STATE_LIST_FIELDS:
                try:
                    state_lists[field] = _string_list(state.get(field, []), f"character state {state_id}.{field}")
                except WorldBuilderError as exc:
                    problems.add(str(exc))
                    state_lists[field] = None
            if reference_only is False:
                for field in ("required_vitals_terms", "required_voice_terms", "required_current_terms"):
                    value = state_lists.get(field)
                    if value is not None and not value:
                        problems.add(f"generated character state {state_id} requires at least one {field} value")
            state_owner[state_id] = character_id
            state_by_id[state_id] = state
            local_state_ids.append(state_id)

        split = character.get("split")
        if not isinstance(split, dict) or not isinstance(split.get("required"), bool):
            problems.add(f"character {character_id} split requires a boolean required field")
            problems.add(f"dependent checks skipped: character {character_id} split consistency checks (split is unusable)")
        else:
            reasons = None
            try:
                reasons = _string_list(split.get("reasons", []), f"character {character_id} split.reasons")
            except WorldBuilderError as exc:
                problems.add(str(exc))
            if reasons is not None:
                unknown = sorted(set(reasons) - SPLIT_REASONS)
                if unknown:
                    problems.add(f"character {character_id} has unsupported split reasons: {', '.join(unknown)}")
            declared_states = None
            try:
                declared_states = _string_list(split.get("state_ids", []), f"character {character_id} split.state_ids", allow_empty=False)
            except WorldBuilderError as exc:
                problems.add(str(exc))
            if declared_states is not None and set(declared_states) != set(local_state_ids):
                problems.add(f"character {character_id} split.state_ids must equal its state IDs")
            if len(local_state_ids) > 1 and split.get("required") is not True:
                problems.add(f"character {character_id} has multiple states but split.required is false")
            if split.get("required") is True and (len(local_state_ids) < 2 or (reasons is not None and not reasons)):
                problems.add(f"character {character_id} split requires multiple states and at least one reason")
            if len(local_state_ids) == 1 and split.get("required") is True:
                problems.add(f"character {character_id} cannot require a split with one state")
        char_by_id[character_id] = character

    relationships = plan.get("relationships", [])
    if not isinstance(relationships, list):
        problems.add("character plan relationships must be an array")
        problems.add("dependent checks skipped: relationship checks (relationships is not an array)")
        problems.raise_if_any()
    relation_ids: set[str] = set()
    for index, relation in enumerate(relationships):
        if not isinstance(relation, dict):
            problems.add(f"relationship row {index} must be an object")
            continue
        relation_id = None
        try:
            relation_id = _string(relation.get("relationship_id"), f"relationship row {index} relationship_id")
        except WorldBuilderError as exc:
            problems.add(str(exc))
        if relation_id is None:
            problems.add(f"dependent checks skipped: relationship row {index} checks (relationship_id is unusable)")
            continue
        if relation_id in relation_ids:
            problems.add(f"duplicate relationship_id {relation_id!r}")
            continue
        relation_ids.add(relation_id)
        source_id = None
        try:
            source_id = _string(relation.get("source_character_id"), f"relationship {relation_id} source_character_id")
        except WorldBuilderError as exc:
            problems.add(str(exc))
        if source_id is not None and source_id not in char_by_id:
            problems.add(f"relationship {relation_id} has unknown source character {source_id!r}")
            source_id = None
        source_state_id = None
        try:
            source_state_id = _string(relation.get("source_state_id"), f"relationship {relation_id} source_state_id")
        except WorldBuilderError as exc:
            problems.add(str(exc))
        if source_id is not None and source_state_id is not None and state_owner.get(source_state_id) != source_id:
            problems.add(f"relationship {relation_id} source_state_id does not belong to its source")
        target_name = None
        try:
            target_name = _string(relation.get("target_name"), f"relationship {relation_id} target_name")
        except WorldBuilderError as exc:
            problems.add(str(exc))
        target_id = relation.get("target_character_id")
        if target_id is not None:
            try:
                target_id = _string(target_id, f"relationship {relation_id} target_character_id")
            except WorldBuilderError as exc:
                problems.add(str(exc))
                target_id = None
            if target_id is not None and target_id not in char_by_id:
                problems.add(f"relationship {relation_id} has unknown target character {target_id!r}")
                target_id = None
            elif target_id is not None and target_id == source_id:
                problems.add(f"relationship {relation_id} cannot target the same character")
        target_state_id = relation.get("target_state_id")
        if target_state_id is not None:
            try:
                target_state_id = _string(target_state_id, f"relationship {relation_id} target_state_id")
            except WorldBuilderError as exc:
                problems.add(str(exc))
                target_state_id = None
            if target_state_id is not None and (target_id is None or state_owner.get(target_state_id) != target_id):
                problems.add(f"relationship {relation_id} target_state_id does not belong to its target")
        era_id = None
        try:
            era_id = _string(relation.get("era_id"), f"relationship {relation_id} era_id")
        except WorldBuilderError as exc:
            problems.add(str(exc))
        if era_id is not None and source_state_id is not None and source_state_id in state_by_id:
            if era_id != str(state_by_id[source_state_id].get("era_id")):
                problems.add(f"relationship {relation_id} era does not match source state")
        if era_id is not None and target_state_id is not None and target_state_id in state_by_id:
            if era_id != str(state_by_id[target_state_id].get("era_id")):
                problems.add(f"relationship {relation_id} era does not match target state")
        try:
            _string(relation.get("relationship_type"), f"relationship {relation_id} relationship_type")
        except WorldBuilderError as exc:
            problems.add(str(exc))
        public_state = ""
        try:
            public_state = _string(relation.get("public_state", ""), f"relationship {relation_id} public_state", allow_blank=True)
        except WorldBuilderError as exc:
            problems.add(str(exc))
        private_state = ""
        try:
            private_state = _string(relation.get("private_state", ""), f"relationship {relation_id} private_state", allow_blank=True)
        except WorldBuilderError as exc:
            problems.add(str(exc))
        knowledge = relation.get("knowledge_state")
        knowledge_lists: dict[str, list[str] | None] = {}
        if not isinstance(knowledge, dict):
            problems.add(f"relationship {relation_id} knowledge_state must be an object")
        else:
            for field in ("source_knows", "target_knows", "mutual_unknowns"):
                try:
                    knowledge_lists[field] = _string_list(knowledge.get(field, []), f"relationship {relation_id} knowledge_state.{field}")
                except WorldBuilderError as exc:
                    problems.add(str(exc))
                    knowledge_lists[field] = None
        consequences = relation.get("behavioral_consequences")
        consequence_values: list[str] = []
        consequences_ok = isinstance(consequences, dict)
        if not consequences_ok:
            problems.add(f"relationship {relation_id} behavioral_consequences must be an object")
        else:
            for field in ("source", "target"):
                try:
                    consequence_values.extend(_string_list(consequences.get(field, []), f"relationship {relation_id} behavioral_consequences.{field}"))
                except WorldBuilderError as exc:
                    problems.add(str(exc))
                    consequences_ok = False
        knowledge_values = [
            item
            for field in ("source_knows", "target_knows", "mutual_unknowns")
            for item in (knowledge_lists.get(field) or [])
            if isinstance(item, str) and item.strip()
        ]
        knowledge_ok = isinstance(knowledge, dict) and all(value is not None for value in knowledge_lists.values())
        if knowledge_ok and consequences_ok and not any((public_state.strip(), private_state.strip(), consequence_values, knowledge_values)):
            problems.add(f"relationship {relation_id} has no state, knowledge, or behavioral consequence")
        trigger = None
        try:
            trigger = _string(relation.get("activation_trigger", ""), f"relationship {relation_id} activation_trigger", allow_blank=True)
        except WorldBuilderError as exc:
            problems.add(str(exc))
        target_uid = relation.get("activation_target_uid")
        if target_uid is not None:
            try:
                _uid_key(target_uid)
            except WorldBuilderError as exc:
                problems.add(str(exc))
            else:
                if not trigger:
                    problems.add(f"relationship {relation_id} with activation_target_uid requires activation_trigger")
        required_connection_terms = None
        try:
            required_connection_terms = _string_list(
                relation.get("required_connection_terms", []),
                f"relationship {relation_id} required_connection_terms",
            )
        except WorldBuilderError as exc:
            problems.add(str(exc))
        required_in_connections = relation.get("required_in_connections", True)
        if not isinstance(required_in_connections, bool):
            problems.add(f"relationship {relation_id} required_in_connections must be boolean")
        if isinstance(required_in_connections, bool) and required_in_connections is not True and required_connection_terms is not None and required_connection_terms:
            problems.add(f"relationship {relation_id} cannot require CONNECTIONS terms when required_in_connections is false")
        if target_id is not None and target_id in char_by_id and target_name is not None:
            target = char_by_id[target_id]
            allowed_names = {str(target.get("canonical_name", "")).casefold(), *[str(item).casefold() for item in target.get("aliases", [])]}
            if target_name.casefold() not in allowed_names:
                problems.add(f"relationship {relation_id} target_name does not match target identity")
    problems.raise_if_any()
    return {
        "character_count": len(char_by_id),
        "state_count": len(state_by_id),
        "relationship_count": len(relationships),
        "uid_owner": uid_owner,
        "character_by_id": char_by_id,
        "state_by_id": state_by_id,
        "state_owner": state_owner,
    }


def validate_manifest_binding(plan: dict[str, Any], manifest: dict[str, Any], *, era_ids: set[str] | None = None) -> dict[str, Any]:
    problems = ErrorCollector()
    detail = None
    try:
        detail = validate_plan(plan, expected_build_id=str(manifest.get("build_id", "")), era_ids=era_ids)
    except WorldBuilderError as exc:
        problems.add(str(exc))
    if detail is None:
        problems.add("dependent checks skipped: manifest binding checks (the character plan is invalid)")
        problems.raise_if_any()
    rows = manifest_character_rows(manifest)
    row_by_uid = {str(row.get("uid", row.get("id", ""))): row for row in rows}
    uid_owner: dict[str, tuple[str, str]] = detail["uid_owner"]
    if set(row_by_uid) != set(uid_owner):
        missing = sorted(set(row_by_uid) - set(uid_owner))
        extra = sorted(set(uid_owner) - set(row_by_uid))
        problems.add(f"character plan/manifest UID coverage mismatch; missing={missing}, extra={extra}")
    for uid, row in row_by_uid.items():
        if uid not in uid_owner:
            continue
        arch = row.get("architecture") if isinstance(row.get("architecture"), dict) else {}
        expected_character, expected_state = uid_owner[uid]
        if arch.get("character_id") != expected_character or arch.get("character_state_id") != expected_state:
            problems.add(f"character manifest UID {uid} is not bound to its planned identity/state")
        if arch.get("identity_model") != "structured-v1" or arch.get("behavior_model") != "structured-v1":
            problems.add(f"character manifest UID {uid} lacks structured identity/behavior models")

    # Validate relationship graph edges when they point to generated entries.
    for relation in plan.get("relationships", []):
        target_uid = relation.get("activation_target_uid")
        if target_uid is None:
            continue
        relation_id = relation.get("relationship_id")
        source_state = detail["state_by_id"].get(relation.get("source_state_id"))
        if source_state is None:
            continue
        source_uids = [str(uid) for uid in source_state.get("manifest_uids", [])]
        if not source_uids:
            problems.add(f"relationship {relation_id} has no generated source state")
            continue
        target_key = str(target_uid)
        if target_key not in row_by_uid:
            problems.add(f"relationship {relation_id} activation target UID is not a character entry")
            continue
        target_id = relation.get("target_character_id")
        if target_id is not None and detail["uid_owner"].get(target_key, (None, None))[0] != target_id:
            problems.add(f"relationship {relation_id} activation target UID does not belong to its target character")
        trigger = str(relation.get("activation_trigger", "")).strip().casefold()
        target_row = row_by_uid[target_key]
        emit = target_row.get("emit") if isinstance(target_row.get("emit"), dict) else {}
        keys = emit.get("keys", target_row.get("keys", []))
        if not isinstance(keys, list) or trigger not in {str(item).strip().casefold() for item in keys}:
            problems.add(f"relationship {relation_id} trigger cannot match target UID {target_key}")
        for source_uid in source_uids:
            source_row = row_by_uid.get(source_uid)
            if source_row is None:
                problems.add(f"relationship {relation_id} source UID {source_uid} is missing")
                continue
            activation = source_row.get("activation") if isinstance(source_row.get("activation"), dict) else {}
            emits = {str(item).strip().casefold() for item in activation.get("emits", []) if str(item).strip()}
            if trigger not in emits:
                problems.add(f"relationship {relation_id} trigger is not emitted by source UID {source_uid}")
    problems.raise_if_any()
    return detail


def load_bound_plan(root: Path, state: dict[str, Any], manifest: dict[str, Any], *, required: bool, era_ids: set[str] | None = None) -> tuple[dict[str, Any] | None, Path | None, dict[str, Any] | None]:
    problems = ErrorCollector()
    paths = state.get("paths") if isinstance(state.get("paths"), dict) else {}
    if "character_plan" not in paths:
        if required:
            problems.add("build-state lacks a character_plan path")
            problems.raise_if_any()
        return None, None, None
    path = resolve_state_path(root, state, "character_plan")
    if not path.exists():
        if required:
            problems.add("character-bearing build requires artifacts/character-plan.json")
            problems.raise_if_any()
        return None, path, None
    plan = load_json(path)
    if not isinstance(plan, dict):
        problems.add("character-plan.json must be an object")
        problems.raise_if_any()
    expected_sha = manifest.get("character_plan_sha256")
    observed_sha = sha256_file(path)
    if expected_sha != observed_sha:
        problems.add("manifest is not bound to the current character-plan.json")
    arch = manifest.get("architecture") if isinstance(manifest.get("architecture"), dict) else {}
    system = arch.get("character_system") if isinstance(arch.get("character_system"), dict) else {}
    if system.get("contract") != CONTRACT or system.get("plan_sha256") != observed_sha:
        problems.add("manifest architecture.character_system is missing or stale")
    detail = None
    try:
        detail = validate_manifest_binding(plan, manifest, era_ids=era_ids)
    except WorldBuilderError as exc:
        problems.add(str(exc))
    problems.raise_if_any()
    return plan, path, detail


def assignment_context(plan: dict[str, Any], selected_uids: list[Any]) -> dict[str, Any]:
    detail = validate_plan(plan, expected_build_id=str(plan.get("build_id", "")))
    wanted = {str(uid) for uid in selected_uids}
    selected_states: list[dict[str, Any]] = []
    selected_state_ids: set[str] = set()
    for character in plan.get("characters", []):
        for state in character.get("states", []):
            owned = {str(uid) for uid in state.get("manifest_uids", [])}
            if owned.intersection(wanted):
                selected_states.append({
                    "character_id": character["character_id"],
                    "canonical_name": character["canonical_name"],
                    "aliases": character.get("aliases", []),
                    "titles": character.get("titles", []),
                    "identity": character.get("identity", {}),
                    "behavior": character.get("behavior", {}),
                    "split": character.get("split", {}),
                    "state": state,
                })
                selected_state_ids.add(state["state_id"])
    relationships = [
        relation for relation in plan.get("relationships", [])
        if relation.get("source_state_id") in selected_state_ids
        or relation.get("target_state_id") in selected_state_ids
    ]
    return {
        "contract": CONTRACT,
        "timeframe_mode": plan.get("timeframe_mode"),
        "states": selected_states,
        "relationships": relationships,
        "selected_manifest_uids": [str(uid) for uid in selected_uids if str(uid) in detail["uid_owner"]],
    }


def _section_bodies(text: str) -> dict[str, str]:
    problems = ErrorCollector()
    matches: list[tuple[str, re.Match[str]]] = []
    missing: list[str] = []
    for section in LORE_SECTIONS:
        match = re.search(rf"(?im)^\s*{re.escape(section)}\s*:", text)
        if not match:
            missing.append(section)
        else:
            matches.append((section, match))
    for section in missing:
        problems.add(f"missing character section {section!r}")
    if missing:
        problems.add("dependent checks skipped: character section order and body checks (required sections are missing)")
        problems.raise_if_any()
    positions = [match.start() for _, match in matches]
    if positions != sorted(positions):
        problems.add("character sections are not in canonical order")
    extra = re.search(r"(?im)^\s*EXTRA\s*:", text)
    if extra and extra.start() < matches[-1][1].start():
        problems.add("optional EXTRA section must follow CURRENT")
    result: dict[str, str] = {}
    for index, (section, match) in enumerate(matches):
        if index + 1 < len(matches):
            end = matches[index + 1][1].start()
        elif extra:
            end = extra.start()
        else:
            end = len(text)
        body = text[match.end():end].strip()
        if not body:
            problems.add(f"character section {section!r} is empty")
        result[section] = body
    if extra and not text[extra.end():].strip():
        problems.add("optional EXTRA section is empty")
    problems.raise_if_any()
    return result


def _contains_all(text: str, terms: list[str], label: str) -> None:
    problems = ErrorCollector()
    folded = text.casefold()
    for term in terms:
        if term.strip() and term.strip().casefold() not in folded:
            problems.add(f"character checkpoint omits required {label} term {term!r}")
    problems.raise_if_any()


def validate_lorebook_checkpoint(plan: dict[str, Any], manifest: dict[str, Any], uid: Any, output_entry: dict[str, Any]) -> None:
    """Validate one generated lorebook-character checkpoint against the plan."""
    problems = ErrorCollector()
    detail = None
    try:
        detail = validate_manifest_binding(plan, manifest)
    except WorldBuilderError as exc:
        problems.add(str(exc))
    if detail is None:
        problems.add("dependent checks skipped: character checkpoint checks (the manifest binding check failed)")
        problems.raise_if_any()
    key = str(uid)
    owner = detail["uid_owner"].get(key)
    if owner is None:
        return
    manifest_row = next(
        (row for row in manifest_character_rows(manifest) if str(row.get("uid", row.get("id", ""))) == key),
        None,
    )
    if not isinstance(manifest_row, dict):
        problems.add(f"character checkpoint UID {key} is absent from the manifest")
        problems.add("dependent checks skipped: character checkpoint content checks (the manifest row is missing)")
        problems.raise_if_any()
    arch = manifest_row.get("architecture") if isinstance(manifest_row.get("architecture"), dict) else {}
    if arch.get("character_role", "lorebook_character") == "card_star":
        return
    content = output_entry.get("content")

    # A core_invariant entry is gated with AND ANY over exactly the tokens of the
    # eras its subject exists in (Batch 58), so a claim only has to hold across
    # that subset rather than across every era in the book. Existence claims are
    # therefore safe; status claims still are not, because the subset can span a
    # promotion or a change of allegiance.
    # A core_invariant entry fires in every era it is gated to, so era-specific claims
    # in it leak everywhere and no token gate can catch them (DR-059). Whether a given
    # sentence *is* era-specific is a reading question, so the checkpoint verifies the
    # structure only and Warden reads the prose. A script that blocked here would reject
    # correct writing and pass the contamination it was built to catch.
    if arch.get("era_cascade_role") == "core_invariant":
        constant = bool(output_entry.get("constant"))
        keys = output_entry.get("keys") or output_entry.get("key") or []
        if not constant and not keys:
            problems.add(
                f"core entry {key} is neither constant nor keyed, so it can never activate"
            )
    if not isinstance(content, str) or not content.strip():
        problems.add(f"character checkpoint UID {key} has no content")
        problems.add("dependent checks skipped: character checkpoint content checks (no usable content)")
        problems.raise_if_any()
    character_id, state_id = owner
    character = detail["character_by_id"][character_id]
    state = detail["state_by_id"][state_id]
    sections = None
    try:
        sections = _section_bodies(content)
    except WorldBuilderError as exc:
        problems.add(str(exc))
    if sections is None:
        problems.add("dependent checks skipped: character checkpoint content checks (required sections are missing or out of order)")
        problems.raise_if_any()
    if str(character["canonical_name"]).casefold() not in content.casefold():
        problems.add(f"character checkpoint UID {key} omits canonical name {character['canonical_name']!r}")
    try:
        _contains_all(sections["VITALS"], state.get("required_vitals_terms", []), "VITALS")
    except WorldBuilderError as exc:
        problems.add(str(exc))
    try:
        _contains_all(sections["PERSONALITY & VOICE"], state.get("required_voice_terms", []), "voice")
    except WorldBuilderError as exc:
        problems.add(str(exc))
    try:
        _contains_all(sections["CURRENT"], state.get("required_current_terms", []), "CURRENT")
    except WorldBuilderError as exc:
        problems.add(str(exc))
    folded = content.casefold()
    for term in state.get("forbidden_knowledge_terms", []):
        if term.strip() and term.strip().casefold() in folded:
            problems.add(f"character checkpoint future leakage or knowledge-boundary violation: forbidden term {term!r}")
    for relation in plan.get("relationships", []):
        if not isinstance(relation, dict) or relation.get("source_state_id") != state_id:
            continue
        if relation.get("required_in_connections", True) is not True:
            continue
        target = str(relation.get("target_name", "")).strip()
        if target and target.casefold() not in sections["CONNECTIONS"].casefold():
            problems.add(f"character checkpoint UID {key} omits relationship target {target!r}")
        try:
            _contains_all(
                sections["CONNECTIONS"],
                relation.get("required_connection_terms", []),
                "CONNECTIONS",
            )
        except WorldBuilderError as exc:
            problems.add(str(exc))
    problems.raise_if_any()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--build-state", help="Build-state path for the read-only --requirements preflight.")
    parser.add_argument("--requirements", action="store_true", help="Read-only preflight: print what this gate checks against the current build state.")
    args = parser.parse_args()
    if not args.requirements:
        parser.error("this module has no standalone run mode; use --requirements for the read-only preflight")
    if not args.build_state:
        parser.error("--requirements needs --build-state")
    root, state = load_build_state(args.build_state)
    print(json.dumps(preflight_report("character_contract", requirement_rows(Path(__file__), root, state)), ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
