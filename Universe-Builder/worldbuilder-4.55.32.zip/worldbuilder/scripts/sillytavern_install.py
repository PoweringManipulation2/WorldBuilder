#!/usr/bin/env python3
"""Locate and read a SillyTavern installation.

A fourth input class alongside user description, uploaded files, and web research
(DR-057). Shared infrastructure, not a mode: Audit checks settings with it, era
builds verify recursion, Iteration detects keyword collisions with installed books.

Three rules shape the design:

1. **Read-only.** There is no write path. Changing a user's SillyTavern install is
   outside this contract entirely.
2. **Propose, never guess.** Detection returns ranked candidates with the evidence
   that produced each. The caller confirms one. A single plausible match is still a
   proposal.
3. **Never block a build.** A missing or unreadable install degrades to advisory.
   The install is a source of better information, not a prerequisite.

Privacy: chat logs are personal correspondence. They are never read, never included
in captured fixtures, and never passed to research workers. No flag enables it.

Key-name honesty: SillyTavern's `settings.json` schema has not been verified against
a running instance. `settings` therefore reports every key matching a world-info
prefix rather than asserting names, and `preflight` reports `unknown` for anything it
cannot find instead of failing. Phase 0 replaces inference with observation.

Commands:
    locate            propose install candidates with evidence
    settings          report world-info settings from a confirmed install
    worlds            list installed world files (collision detection)
    extensions        list installed extensions
    preflight         check settings against a build's requirements
    capture-fixtures  write a fixture corpus for runtime verification
"""
from __future__ import annotations

import argparse
import json
import os
import platform
import shutil
import sys
from pathlib import Path
from typing import Any

from wb_common import WorldBuilderError, atomic_write_json, load_json, raise_error

CONTRACT = "worldbuilder-install-reader-v1"
RECEIPT_VERSION = 1

# A SillyTavern data directory holds per-user handles; each handle holds these.
USER_MARKERS = ("settings.json", "worlds", "characters")
# Chats are deliberately absent from anything captured or summarized by default.
PRIVATE_DIRS = ("chats", "user", "backups", "thumbnails")

WORLD_INFO_PREFIXES = ("world_info", "worldInfo")

# Candidate spellings for the settings this project depends on. Unverified against a
# running instance; `preflight` reports `unknown` rather than guessing a default.
SETTING_ALIASES: dict[str, tuple[str, ...]] = {
    "recursive_scan": ("world_info_recursive", "world_info_recursive_scan", "worldInfoRecursive"),
    "max_recursion_steps": ("world_info_max_recursion_steps", "world_info_max_recursion",
                            "worldInfoMaxRecursionSteps"),
    "min_activations": ("world_info_min_activations", "worldInfoMinActivations"),
    "budget": ("world_info_budget", "worldInfoBudget"),
    "depth": ("world_info_depth", "worldInfoDepth"),
}


def _home() -> Path:
    return Path.home()


def candidate_roots(extra: str | None = None) -> list[Path]:
    """Ordered search locations. An explicit path always outranks a guess."""
    roots: list[Path] = []
    if extra:
        roots.append(Path(os.path.expandvars(os.path.expanduser(extra))))
    env = os.environ.get("SILLYTAVERN_DIR")
    if env:
        roots.append(Path(os.path.expandvars(os.path.expanduser(env))))
    home = _home()
    roots += [
        home / "SillyTavern", home / "sillytavern",
        home / "Documents" / "SillyTavern",
        home / "Desktop" / "SillyTavern",
        Path.cwd() / "SillyTavern",
    ]
    if platform.system().lower().startswith("linux"):
        roots += [Path("/opt/SillyTavern"), Path("/srv/SillyTavern")]
    seen: set[Path] = set()
    ordered: list[Path] = []
    for root in roots:
        if root not in seen:
            seen.add(root)
            ordered.append(root)
    return ordered


def _user_dirs(data_dir: Path) -> list[Path]:
    if not data_dir.is_dir():
        return []
    found = []
    for child in sorted(data_dir.iterdir()):
        if not child.is_dir():
            continue
        if any((child / marker).exists() for marker in USER_MARKERS):
            found.append(child)
    return found


def locate(extra: str | None = None) -> dict[str, Any]:
    """Return ranked candidates with the evidence for each. Never picks one."""
    candidates: list[dict[str, Any]] = []
    for root in candidate_roots(extra):
        data_dir = root / "data"
        users = _user_dirs(data_dir)
        if not users:
            continue
        evidence = []
        if (root / "package.json").exists():
            evidence.append("package.json present")
        if (root / "server.js").exists():
            evidence.append("server.js present")
        evidence.append(f"{len(users)} user directory/directories under data/")
        candidates.append({
            "root": str(root),
            "data_dir": str(data_dir),
            "users": [u.name for u in users],
            "evidence": evidence,
            "confidence": "strong" if len(evidence) > 1 else "weak",
        })
    return {
        "kind": "worldbuilder-install-locate",
        "contract": CONTRACT,
        "candidates": candidates,
        "status": "found" if candidates else "not_found",
        "next": (
            ["Confirm one candidate with --root before reading anything from it."]
            if candidates else
            ["No SillyTavern installation found. Pass --root explicitly, or continue without "
             "install access: every build works without it."]
        ),
    }


def resolve_user_dir(root: str, user: str | None = None) -> Path:
    base = Path(os.path.expandvars(os.path.expanduser(root))).resolve()
    data_dir = base / "data" if (base / "data").is_dir() else base
    users = _user_dirs(data_dir)
    if not users:
        raise_error(f"no SillyTavern user directory found under {data_dir}")
    if user:
        for candidate in users:
            if candidate.name == user:
                return candidate
        raise_error(f"user {user!r} not found; available: {[u.name for u in users]}")
    if len(users) > 1:
        raise_error(f"multiple users found: {[u.name for u in users]}. Choose one with --user")
    return users[0]


def read_settings(user_dir: Path) -> dict[str, Any]:
    """Report every world-info key present rather than asserting names.

    The schema is unverified, so reporting what exists is honest where looking up
    specific names would silently return nothing when a name is wrong.
    """
    path = user_dir / "settings.json"
    if not path.exists():
        return {"status": "missing", "path": str(path), "world_info": {}}
    try:
        data = load_json(path)
    except (WorldBuilderError, json.JSONDecodeError, OSError) as exc:
        return {"status": "unreadable", "path": str(path), "error": str(exc)[:300], "world_info": {}}
    if not isinstance(data, dict):
        return {"status": "unexpected_shape", "path": str(path), "world_info": {}}
    world_info = {k: v for k, v in data.items()
                  if any(k.startswith(p) for p in WORLD_INFO_PREFIXES)}
    return {"status": "read", "path": str(path), "world_info": world_info,
            "world_info_key_count": len(world_info)}


def _lookup(world_info: dict[str, Any], logical: str) -> tuple[str | None, Any]:
    for name in SETTING_ALIASES.get(logical, ()):
        if name in world_info:
            return name, world_info[name]
    return None, None


def preflight(user_dir: Path, *, required_recursion_steps: int | None = None) -> dict[str, Any]:
    """Verify settings rather than instructing the user to check them.

    Findings are advisory by construction: an unknown key is reported as unknown, and
    a caller must never fail a build because this reader could not resolve something.
    """
    settings = read_settings(user_dir)
    world_info = settings.get("world_info", {})
    checks: list[dict[str, Any]] = []

    name, value = _lookup(world_info, "recursive_scan")
    if name is None:
        checks.append({"setting": "Recursive Scan", "status": "unknown",
                       "detail": "no matching key found; verify manually in World Info settings"})
    else:
        ok = bool(value)
        checks.append({"setting": "Recursive Scan", "status": "ok" if ok else "problem",
                       "key": name, "value": value,
                       "detail": "" if ok else "off: an era cascade cannot fire; you get the era frame only"})

    name, value = _lookup(world_info, "max_recursion_steps")
    if name is None:
        checks.append({"setting": "Max Recursion Steps", "status": "unknown",
                       "detail": "no matching key found; verify manually"})
    elif required_recursion_steps is not None and isinstance(value, int) and value < required_recursion_steps:
        checks.append({"setting": "Max Recursion Steps", "status": "problem", "key": name, "value": value,
                       "detail": f"{value} is below the {required_recursion_steps} this build needs; "
                                 "the cascade truncates mid-tree with no error"})
    else:
        checks.append({"setting": "Max Recursion Steps", "status": "ok", "key": name, "value": value})

    name, value = _lookup(world_info, "min_activations")
    if name is None:
        checks.append({"setting": "Min Activations", "status": "unknown",
                       "detail": "no matching key found; verify manually"})
    else:
        ok = not value
        checks.append({"setting": "Min Activations", "status": "ok" if ok else "problem",
                       "key": name, "value": value,
                       "detail": "" if ok else "non-zero; SillyTavern treats this as mutually "
                                               "exclusive with Max Recursion Steps"})

    problems = [c for c in checks if c["status"] == "problem"]
    unknowns = [c for c in checks if c["status"] == "unknown"]
    return {
        "kind": "worldbuilder-install-preflight",
        "contract": CONTRACT,
        "receipt_version": RECEIPT_VERSION,
        "settings_status": settings["status"],
        "checks": checks,
        "problem_count": len(problems),
        "unknown_count": len(unknowns),
        # Advisory by contract. A caller that turns this into a hard failure has
        # made the install a prerequisite, which DR-057 forbids.
        "severity": "advisory",
    }


def list_worlds(user_dir: Path) -> dict[str, Any]:
    """Installed world files and their top-level keys, for collision detection."""
    worlds_dir = user_dir / "worlds"
    if not worlds_dir.is_dir():
        return {"status": "missing", "path": str(worlds_dir), "worlds": []}
    worlds = []
    for path in sorted(worlds_dir.glob("*.json")):
        record: dict[str, Any] = {"name": path.stem, "path": str(path), "entry_count": 0, "keys": []}
        try:
            data = load_json(path)
        except (WorldBuilderError, json.JSONDecodeError, OSError):
            record["status"] = "unreadable"
            worlds.append(record)
            continue
        entries = data.get("entries") if isinstance(data, dict) else None
        rows = list(entries.values()) if isinstance(entries, dict) else (entries or [])
        keys: set[str] = set()
        for row in rows:
            if not isinstance(row, dict):
                continue
            for key in (row.get("key") or row.get("keys") or []):
                if isinstance(key, str) and key.strip():
                    keys.add(key.strip())
        record["status"] = "read"
        record["entry_count"] = len(rows)
        record["keys"] = sorted(keys)
        worlds.append(record)
    return {"status": "read", "path": str(worlds_dir), "worlds": worlds}


def keyword_collisions(user_dir: Path, candidate_keys: list[str]) -> dict[str, Any]:
    """Warn when a new book would collide with a book the user already has.

    Two enabled books sharing a keyword both insert. Nothing in SillyTavern reports
    this, and nothing in WorldBuilder could see it before the install was readable.
    """
    installed = list_worlds(user_dir)
    wanted = {k.strip().casefold() for k in candidate_keys if k and k.strip()}
    hits = []
    for world in installed.get("worlds", []):
        shared = sorted({k for k in world.get("keys", []) if k.casefold() in wanted})
        if shared:
            hits.append({"world": world["name"], "shared_keys": shared[:20],
                         "shared_count": len(shared)})
    return {"status": installed["status"], "collisions": hits, "collision_count": len(hits)}


def list_extensions(user_dir: Path) -> dict[str, Any]:
    """Report installed extensions so the build can stop asking the user to self-report.

    Two locations: third-party extensions under the user directory, and bundled ones
    under the install root. Reports what is present; makes no claim about whether an
    extension is enabled, which lives in settings rather than on disk.
    """
    found: list[dict[str, str]] = []
    for label, base in (("user", user_dir / "extensions"),
                        ("bundled", user_dir.parent.parent / "public" / "scripts" / "extensions")):
        if not base.is_dir():
            continue
        for child in sorted(base.iterdir()):
            if child.is_dir() and not child.name.startswith("."):
                found.append({"name": child.name, "scope": label, "path": str(child)})
    return {
        "status": "read" if found else "none_found",
        "extensions": found,
        "note": "Presence on disk only. Enablement lives in settings and is not asserted here.",
    }


def capture_fixtures(user_dir: Path, destination: str) -> dict[str, Any]:
    """Copy a runtime fixture corpus for verification work.

    Deliberately excludes chats, backups, and user avatars, with no opt-in. Chat logs
    are personal correspondence and are not evidence about activation behavior; an
    exported activation log is both smaller and more informative.
    """
    out = Path(os.path.expandvars(os.path.expanduser(destination))).resolve()
    out.mkdir(parents=True, exist_ok=True)
    captured: list[str] = []
    skipped: list[str] = []

    settings = user_dir / "settings.json"
    if settings.exists():
        shutil.copy2(settings, out / "settings.json")
        captured.append("settings.json")
    else:
        skipped.append("settings.json (missing)")

    worlds_dir = user_dir / "worlds"
    if worlds_dir.is_dir():
        target = out / "worlds"
        target.mkdir(exist_ok=True)
        for path in sorted(worlds_dir.glob("*.json"))[:10]:
            shutil.copy2(path, target / path.name)
            captured.append(f"worlds/{path.name}")
    else:
        skipped.append("worlds/ (missing)")

    # No opt-in exists for chats. Personal correspondence is not evidence about
    # activation behavior, and an activation log is both smaller and more useful.
    skipped.append("chats/ (personal correspondence; never captured. Export an activation log instead)")
    for name in PRIVATE_DIRS:
        if name != "chats":
            skipped.append(f"{name}/ (not evidence; excluded)")

    manifest = {
        "kind": "worldbuilder-runtime-fixture-capture",
        "contract": CONTRACT,
        "source_user_dir": str(user_dir),
        "captured": captured,
        "skipped": skipped,
        "sillytavern_version": None,
        "next": [
            "Record the SillyTavern version in this manifest; fixtures without a version "
            "cannot be interpreted later.",
            "Export a World Info activation log from a real session and place it beside these files.",
            "Keep the capture under the active build workspace (for example .work/runtime-fixtures/) and bind any runtime-verification note to its exact files.",
        ],
    }
    atomic_write_json(out / "capture-manifest.json", manifest)
    return {**manifest, "destination": str(out)}


def main() -> int:
    parser = argparse.ArgumentParser(description="Read a SillyTavern installation (read-only).")
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("locate", help="propose install candidates with evidence")
    p.add_argument("--root", help="explicit install root to check first")

    for name, helptext in (("settings", "report world-info settings"),
                           ("worlds", "list installed world files"),
                           ("extensions", "list installed extensions")):
        s = sub.add_parser(name, help=helptext)
        s.add_argument("--root", required=True)
        s.add_argument("--user")

    p = sub.add_parser("preflight", help="check settings against a build's requirements")
    p.add_argument("--root", required=True)
    p.add_argument("--user")
    p.add_argument("--required-recursion-steps", type=int)

    p = sub.add_parser("collisions", help="check keywords against installed worlds")
    p.add_argument("--root", required=True)
    p.add_argument("--user")
    p.add_argument("--keys", nargs="+", required=True)

    p = sub.add_parser("capture-fixtures", help="write a runtime fixture corpus (never includes chats)")
    p.add_argument("--root", required=True)
    p.add_argument("--user")
    p.add_argument("--destination", required=True)

    args = parser.parse_args()
    try:
        if args.command == "locate":
            result = locate(args.root)
        else:
            user_dir = resolve_user_dir(args.root, args.user)
            if args.command == "settings":
                result = read_settings(user_dir)
            elif args.command == "worlds":
                result = list_worlds(user_dir)
            elif args.command == "extensions":
                result = list_extensions(user_dir)
            elif args.command == "preflight":
                result = preflight(user_dir, required_recursion_steps=args.required_recursion_steps)
            elif args.command == "collisions":
                result = keyword_collisions(user_dir, args.keys)
            else:
                result = capture_fixtures(user_dir, args.destination)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (WorldBuilderError, OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
