#!/usr/bin/env python3
"""Batch 7, 7.8: structural before/after diff for any lorebook artifact.

Reports:
    added_uids, removed_uids        : whole-entry additions/removals
    changed_entries                 : per-UID: field_deltas, unknown_field_loss,
                                       extension_loss, key_order_changed
    moved_entries                   : same UID, different container

Every field this reports is checked against what actually changed, not
assumed from operation intent; artifact_edit.py's own operation log says
what a tool *meant* to do; this module exists to catch what actually
happened, including collateral damage from something other than
artifact_edit.py (a naive full-rewrite, a hand edit, a third-party tool).

unknown_field_loss uses CORE_ENTRY_FIELDS (runtime_target_adapter.py) rather
than a second, parallel field list: the same set already used to recognize
legitimate top-level World Info fields elsewhere in this codebase. A field
outside that set that existed before and is gone after is unknown-field
loss; it does not matter whether the field was ever meaningful, only that
something present is now absent without this tool having decided to remove
it. extension_loss is checked separately, against extensions' own sub-keys,
never folded into the top-level check: extensions are the sanctioned
mechanism for anything beyond the base spec (sillytavern-import-contract.md),
so any extensions key disappearing is loss regardless of whether it happens
to be one this codebase specifically recognizes.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

from wb_common import WorldBuilderError, build_identity_index, load_json
from runtime_target_adapter import CORE_ENTRY_FIELDS

CONTRACT = "worldbuilder-artifact-diff-v1"


def _container_prefix(path: str) -> str:
    """Everything in an EntryRef.path except the final index/key: the
    container an entry lives in, for moved_entries detection."""
    parts = path.rstrip("/").split("/")
    return "/".join(parts[:-1]) if len(parts) > 1 else ""


def _entry_delta(before: dict[str, Any], after: dict[str, Any]) -> dict[str, Any]:
    field_deltas: dict[str, dict[str, Any]] = {}
    all_fields = set(before) | set(after)
    for field in sorted(all_fields):
        if field == "extensions":
            continue  # handled separately, below, at the sub-key level
        if before.get(field) != after.get(field):
            field_deltas[field] = {"before": before.get(field), "after": after.get(field)}

    unknown_field_loss = sorted(
        field for field in set(before) - set(after)
        if field not in CORE_ENTRY_FIELDS and field != "extensions"
    )

    before_ext = before.get("extensions") if isinstance(before.get("extensions"), dict) else {}
    after_ext = after.get("extensions") if isinstance(after.get("extensions"), dict) else {}
    extension_loss = sorted(set(before_ext) - set(after_ext))
    extension_changes = sorted(
        key for key in (set(before_ext) & set(after_ext))
        if before_ext.get(key) != after_ext.get(key)
    )

    before_keys = [k for k in before.keys()]
    after_keys = [k for k in after.keys()]
    # A purely additive append (new keys at the end) is not a reorder:
    # artifact_edit.py's own operations produce exactly this shape. Only the
    # relative order of keys present in BOTH counts as a reorder.
    common_before_order = [k for k in before_keys if k in after]
    common_after_order = [k for k in after_keys if k in before]
    key_order_changed = common_before_order != common_after_order

    return {
        "field_deltas": field_deltas,
        "unknown_field_loss": unknown_field_loss,
        "extension_loss": extension_loss,
        "extension_changes": extension_changes,
        "key_order_changed": key_order_changed,
    }


def diff_artifacts(before: Any, after: Any) -> dict[str, Any]:
    before_index = build_identity_index(before)
    after_index = build_identity_index(after)
    before_uids = set(before_index)
    after_uids = set(after_index)

    added_uids = sorted(str(u) for u in (after_uids - before_uids))
    removed_uids = sorted(str(u) for u in (before_uids - after_uids))

    changed_entries: dict[str, Any] = {}
    moved_entries: list[dict[str, Any]] = []
    for uid in sorted(before_uids & after_uids, key=str):
        before_path, before_entry = before_index[uid]
        after_path, after_entry = after_index[uid]
        if _container_prefix(before_path) != _container_prefix(after_path):
            moved_entries.append({
                "uid": uid, "before_container": _container_prefix(before_path),
                "after_container": _container_prefix(after_path),
            })
        # Python dict equality ignores key order: a pure reorder with no
        # value changes at all would otherwise never reach _entry_delta, and
        # key_order_changed exists specifically to catch that case. Compute
        # the delta unconditionally; only decide whether to report it after.
        delta = _entry_delta(before_entry, after_entry)
        if delta["field_deltas"] or delta["key_order_changed"] or delta["unknown_field_loss"] or delta["extension_loss"] or delta["extension_changes"]:
            changed_entries[str(uid)] = delta

    any_loss = any(
        row["unknown_field_loss"] or row["extension_loss"]
        for row in changed_entries.values()
    ) or bool(removed_uids)

    return {
        "contract": CONTRACT,
        "added_uids": added_uids,
        "removed_uids": removed_uids,
        "changed_entries": changed_entries,
        "moved_entries": moved_entries,
        "summary": {
            "added_count": len(added_uids), "removed_count": len(removed_uids),
            "changed_count": len(changed_entries), "moved_count": len(moved_entries),
            "any_field_or_extension_loss": any_loss,
        },
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--before", required=True)
    parser.add_argument("--after", required=True)
    parser.add_argument("--output", help="Where to write the diff JSON (default: stdout only)")
    args = parser.parse_args()
    try:
        result = diff_artifacts(load_json(Path(args.before)), load_json(Path(args.after)))
        text = json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True)
        if args.output:
            from wb_common import atomic_write_json
            atomic_write_json(Path(args.output), result)
        print(text)
        return 0
    except (WorldBuilderError, OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
