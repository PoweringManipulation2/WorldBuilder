#!/usr/bin/env python3
"""Prune revamp: the four-phase workflow (Analyze -> Select -> Apply -> Prove).

This module is Phase 1, Analyze: whole-book detection across every
detector built so far, with projected WCSA impact where that projection
can be computed directly and cheaply. Phases 2-4 (Select, Apply, Prove)
are separate, later pieces; Analyze is deliberately self-contained and
useful on its own (a read-only report), so it does not need the later
phases to exist to already be worth having.

Projected savings are only ever a real, computed number or an explicit
None; never a guess dressed up as a projection. Tier 0's
keyword-collision candidates get a real projection here, because
tightening a key away from a shared term is cheap to simulate directly
(construct the hypothetical after-state, re-run the same
worst_case_after_pruning simulation pruning_receipt.py already uses for
its own before/after comparison). Constant-demotion and depth-
restratification's actual WCSA impact depends on runtime activation
probability in a way this codebase does not yet model well enough to
project honestly; their projected_savings field says so explicitly
rather than fabricating a number. Tier 1 (ancestor and card-shell
redundancy) reports candidates as-is; their savings are a function of how
much overlapping content an auditor finds, which this workflow cannot
know in advance.
"""
from __future__ import annotations

import copy
from typing import Any

from lock_contract import is_locked, lock_reason
from pruning_objectives import score_candidates, validate_plan_rows as validate_pruning_objective_rows
from wb_common import build_identity_index, normalize_identity


def _lock_blocks(index: dict[Any, tuple[str, dict[str, Any]]], uid: Any, fields: tuple[str, ...]) -> tuple[bool, str | None]:
    key = normalize_identity(uid)
    row = index.get(key)
    if row is None:
        return False, None
    entry = row[1]
    for field in fields:
        if is_locked(entry, field):
            return True, lock_reason(entry, field)
    return False, None


def _hypothetical_after_removing_key(before_data: dict[str, Any], uid: str, key: str) -> dict[str, Any]:
    """A deep copy of before_data with one specific key removed from one
    specific entry's keys list; nothing else touched. This is the exact
    Tier 0 operation (keyword collision tightening): no content change,
    only a keyword removed from the collision."""
    hypothetical = copy.deepcopy(before_data)
    folded_key = key.casefold()
    for entry in hypothetical.get("data", {}).get("entries", []):
        if str(entry.get("id", entry.get("uid"))) == uid:
            keys = entry.get("keys")
            if isinstance(keys, list):
                entry["keys"] = [k for k in keys if str(k).strip().casefold() != folded_key]
            break
    return hypothetical


def _paginate(items: list[Any], page: int, page_size: int) -> dict[str, Any]:
    if page_size <= 0:
        raise ValueError("page_size must be positive")
    total = len(items)
    total_pages = max(1, -(-total // page_size))  # ceiling division
    page = max(1, min(page, total_pages))
    start = (page - 1) * page_size
    return {
        "items": items[start:start + page_size],
        "page": page, "page_size": page_size, "total_items": total, "total_pages": total_pages,
    }


EXECUTABLE_STRATEGIES = ("keyword_collision_tightening", "depth_restratification")
# constant_demotion is reported by Analyze but not executable through this
# workflow: "constant" is not in artifact_edit.py's SET_FIELD_ALLOWED or
# pruning_receipt.py's ALLOWED_MUTABLE_FIELDS, and neither was an
# oversight; both deliberately limit themselves to content-bearing
# fields, not activation-strategy ones. Widening either boundary just to
# make this one strategy executable is a bigger decision than this
# workflow should make on its own; a constant-demotion candidate stays a
# report for a human to act on directly, not something Select/Apply can
# carry out.

STRATEGY_TIER = {"keyword_collision_tightening": 0, "depth_restratification": 0}
# 7.9: Unbound has no declared protected set (no manifest to declare one),
# so a heuristic could delete something critical it does not recognize,
# an era root, an identity kernel, without knowing it was protected.
# capability_tiers.UNBOUND_MAX_PRUNE_TIER records the ceiling; this is
# where it is actually enforced. Both executable strategies are Tier 0
# today, so this check is currently vacuous in practice; it is wired in
# explicitly anyway, so the constraint is a property of select() itself,
# not an accident of which strategies happen to exist yet. A future
# Tier 2/3 execution path would trip this the moment it tried to run
# against an Unbound artifact, rather than silently skipping the check
# because nobody remembered to add it there too.


def select(
    analyze_result: dict[str, Any], *, strategies: list[str], vetoed_uids: dict[str, list[str]] | None = None,
    artifact_tier: str | None = None,
) -> dict[str, Any]:
    """Phase 2: validates a user's strategy choices against what Analyze
    actually found. Never accepts a selection for a strategy or UID
    Analyze did not itself identify as a candidate; that would mean
    acting on an unverified claim instead of a proven opportunity. Tier 1
    (ancestor/card-shell redundancy) is not selectable here: those need
    an auditor to first identify actual overlapping content, which this
    workflow deliberately never computes; once identified, an auditor
    acts on them through artifact_edit.py directly, not through Select.

    artifact_tier (from capability_tiers.detect_tier) is optional; when
    given and equal to "unbound", every selected strategy's own
    STRATEGY_TIER is checked against UNBOUND_MAX_PRUNE_TIER (7.9: no
    declared protected set means a heuristic could delete something
    critical it does not recognize). Both executable strategies today are
    Tier 0, well within the limit, so this rejects nothing in practice;
    it exists so a future higher-tier strategy trips this check
    automatically rather than silently bypassing it.
    """
    from capability_tiers import UNBOUND_MAX_PRUNE_TIER

    unknown_strategies = sorted(set(strategies) - set(EXECUTABLE_STRATEGIES))
    if unknown_strategies:
        raise ValueError(
            f"unknown or non-executable strategies: {', '.join(unknown_strategies)}. "
            f"Executable strategies are: {', '.join(EXECUTABLE_STRATEGIES)}"
        )
    if artifact_tier == "unbound":
        too_high = sorted(s for s in strategies if STRATEGY_TIER[s] > UNBOUND_MAX_PRUNE_TIER)
        if too_high:
            raise ValueError(
                f"strategies {', '.join(too_high)} exceed this Unbound artifact's max prune tier "
                f"({UNBOUND_MAX_PRUNE_TIER}); no declared protected set exists to check against, "
                "so anything more destructive requires per-UID confirmation outside this workflow"
            )
    vetoed_uids = vetoed_uids or {}

    objective_block = analyze_result.get("objective_priority") if isinstance(analyze_result.get("objective_priority"), dict) else {}
    active_objectives = objective_block.get("active_objectives") if isinstance(objective_block.get("active_objectives"), list) else []
    priority_by_uid = {
        str(row.get("uid")): row
        for row in objective_block.get("rows", [])
        if isinstance(row, dict) and row.get("uid") is not None
    }

    def _priority_key(row: dict[str, Any]) -> tuple[Any, ...]:
        uid = str(row.get("uid", ""))
        priority = priority_by_uid.get(uid, {})
        return (-int(priority.get("adjusted_prune_score", 0)), -int(priority.get("wcsa_cofire_score", 0)), uid, str(row.get("key", "")))

    selected: dict[str, list[dict[str, Any]]] = {}
    if "keyword_collision_tightening" in strategies:
        vetoed = set(vetoed_uids.get("keyword_collision_tightening", []))
        candidates = analyze_result["tier_0"]["keyword_collision_tightening"]["candidates"]
        rows = []
        for key, owners in candidates.items():
            for uid in owners:
                if uid not in vetoed:
                    rows.append({"uid": uid, "key": key})
        if active_objectives:
            rows.sort(key=_priority_key)
        selected["keyword_collision_tightening"] = rows
    if "depth_restratification" in strategies:
        vetoed = set(vetoed_uids.get("depth_restratification", []))
        candidates = analyze_result["tier_0"]["depth_restratification"]["candidates"]
        rows = [row for row in candidates if row["uid"] not in vetoed]
        if active_objectives:
            rows.sort(key=_priority_key)
        selected["depth_restratification"] = rows

    return {
        "contract": "worldbuilder-prune-select-v1",
        "selected": selected,
        "objective_priority_contract": objective_block.get("contract") if active_objectives else None,
        "active_pruning_objectives": active_objectives,
    }


def apply_selection(after_data: dict[str, Any], selection: dict[str, Any]) -> dict[str, Any]:
    """Phase 3: applies a validated selection to a deep copy of
    after_data; the caller's own object is never mutated. Every
    operation goes through artifact_edit.py, never a parallel, ad-hoc
    mutation path; the same discipline that made artifact_edit.py the
    sanctioned way to edit an artifact in the first place applies here
    too.
    """
    import copy as _copy
    from artifact_edit import op_retag_keys, op_move_depth
    from artifact_lookup import locate_entry as _locate

    working = _copy.deepcopy(after_data)
    operations_applied: list[dict[str, Any]] = []

    for row in selection["selected"].get("keyword_collision_tightening", []):
        entry = _locate(working, uid=row["uid"])
        current_keys = entry.get("keys") if isinstance(entry.get("keys"), list) else []
        folded_key = row["key"].casefold()
        new_keys = [k for k in current_keys if str(k).strip().casefold() != folded_key]
        record = op_retag_keys(working, uid=row["uid"], keys=new_keys)
        operations_applied.append(record)

    for row in selection["selected"].get("depth_restratification", []):
        record = op_move_depth(
            working, uid=row["uid"], delay_until_recursion=True,
            receipt_bound_reason=(
                f"prune workflow depth restratification: {row['incoming_edge_count']} incoming edge(s), "
                "reachable only via recursion (Analyze phase, depth_restratification_candidates)"
            ),
        )
        operations_applied.append(record)

    return {"contract": "worldbuilder-prune-apply-v1", "after_data": working, "operations_applied": operations_applied}



def prove(plan: dict[str, Any], manifest: dict[str, Any], profile: dict[str, Any], before_data: dict[str, Any], after_data: dict[str, Any], *, token_budget: int | None = None, detail_level: str | None = None) -> dict[str, Any]:
    """Phase 4: binds before/after simulations into a single proof,
    per-scenario (not just the single worst-case number Analyze's
    projections used), plus the drop-order change from Batch 5.5:
    does the SAME token budget now keep more, or protect what it used to
    drop, once the applied operations are in effect. This is the actual
    proof a user or auditor can point to: not "this should help" but
    "here is what changed, simulation by simulation."
    """
    from budget_contract import actual_entry_token_measurement, uid_key, predict_drop_order, recommend_token_budget
    from budget_semantics import manifest_rows as _manifest_rows, required_edges as _required_edges
    from placement_semantics import placement_values as _placement_values
    from pruning_receipt import worst_case_after_pruning
    from wb_common import iter_entries, canonical_entry_identity

    before_pressure = worst_case_after_pruning(plan, manifest, before_data)
    after_pressure = worst_case_after_pruning(plan, manifest, after_data)

    per_scenario_delta = []
    after_by_name = {s["name"]: s for s in after_pressure["all_simulations"]}
    for before_sim in before_pressure["all_simulations"]:
        after_sim = after_by_name.get(before_sim["name"])
        after_tokens = after_sim["estimated_tokens"] if after_sim else None
        per_scenario_delta.append({
            "name": before_sim["name"],
            "before_tokens": before_sim["estimated_tokens"],
            "after_tokens": after_tokens,
            "delta": (after_tokens - before_sim["estimated_tokens"]) if after_tokens is not None else None,
        })

    _edges, required_edge_uids = _required_edges(manifest)
    placement_by_uid = {
        uid_key(row.get("uid", row.get("id"))): _placement_values(row, profile, required_edge_uids)
        for row in _manifest_rows(manifest)
    }

    def _drop_order_entries(data: dict[str, Any]) -> list[dict[str, Any]]:
        actual_rows: dict[str, dict[str, Any]] = {}
        for ref in iter_entries(data):
            identity = canonical_entry_identity(ref.entry)
            if identity is not None:
                actual_rows[uid_key(identity)] = ref.entry
        rows = []
        for uid, placement in placement_by_uid.items():
            actual = actual_rows.get(uid)
            tokens = actual_entry_token_measurement(actual)[0] if actual is not None else 0
            rows.append({
                "uid": uid, "tokens": tokens, "weight": placement["weight"],
                "insertion_order": placement["insertion_order"], "constant": placement["constant"],
                "protected_categories": placement["protected_categories"], "name": actual.get("name", "") if actual else "",
            })
        return rows

    before_rows = _drop_order_entries(before_data)
    after_rows = _drop_order_entries(after_data)
    if token_budget is None:
        recommendation = recommend_token_budget(before_rows, plan["targets"]["worst_case_hard"], detail_level)
        token_budget = recommendation["recommended_token_budget"]
    before_drop_order = predict_drop_order(before_rows, token_budget, detail_level)
    after_drop_order = predict_drop_order(after_rows, token_budget, detail_level)

    return {
        "contract": "worldbuilder-prune-prove-v1",
        "baseline_max_pressure": before_pressure["max_pressure"],
        "resulting_max_pressure": after_pressure["max_pressure"],
        "max_pressure_delta": after_pressure["max_pressure"] - before_pressure["max_pressure"],
        "per_scenario_delta": per_scenario_delta,
        "drop_order": {
            "token_budget": token_budget,
            "before_dropped_count": before_drop_order["dropped_count"],
            "after_dropped_count": after_drop_order["dropped_count"],
            "before_any_protected_dropped": before_drop_order["any_protected_dropped"],
            "after_any_protected_dropped": after_drop_order["any_protected_dropped"],
            "before_dropped_uids": [d["uid"] for d in before_drop_order["dropped"]],
            "after_dropped_uids": [d["uid"] for d in after_drop_order["dropped"]],
        },
    }



def analyze(
    plan: dict[str, Any], manifest: dict[str, Any], profile: dict[str, Any],
    before_data: dict[str, Any], card_data: dict[str, Any],
    *, page: int = 1, page_size: int = 20,
) -> dict[str, Any]:
    """Phase 1: whole-book detection across every built detector, with
    real projected WCSA impact for keyword-collision candidates and an
    explicit None everywhere a projection cannot yet be honestly computed.
    Tier 0's keyword-collision candidates list is what gets paged (it is
    the one that can grow large on a real book with many shared terms);
    everything else is returned in full, since none of the other detector
    outputs are expected to reach a size that needs paging on a real book.
    """
    from ancestor_redundancy import ancestor_redundancy_candidates, card_shell_redundancy_targets
    from tier_zero_detectors import constant_demotion_candidates, depth_restratification_candidates, keyword_collision_candidates
    from pruning_receipt import worst_case_after_pruning

    keyword_collisions = keyword_collision_candidates(manifest)
    constant_demotions = constant_demotion_candidates(manifest)
    depth_candidates = depth_restratification_candidates(manifest)
    ancestor_candidates = ancestor_redundancy_candidates(manifest, profile)
    shell_candidates = card_shell_redundancy_targets(manifest, card_data)

    lock_index = build_identity_index(manifest)
    lock_exclusions: list[dict[str, Any]] = []
    filtered_collisions: dict[str, list[str]] = {}
    for key, owners in keyword_collisions.items():
        kept = []
        for uid in owners:
            blocked, reason = _lock_blocks(lock_index, uid, ("keys",))
            if blocked:
                lock_exclusions.append({"uid": str(uid), "strategy": "keyword_collision_tightening", "reason": reason})
            else:
                kept.append(uid)
        if kept:
            filtered_collisions[key] = kept
    keyword_collisions = filtered_collisions

    kept_depth = []
    for row in depth_candidates:
        uid = row.get("uid") if isinstance(row, dict) else None
        blocked, reason = _lock_blocks(lock_index, uid, ("recursion_level", "delay_until_recursion"))
        if blocked:
            lock_exclusions.append({"uid": str(uid), "strategy": "depth_restratification", "reason": reason})
        else:
            kept_depth.append(row)
    depth_candidates = kept_depth

    kept_constant = []
    for row in constant_demotions:
        uid = row.get("uid") if isinstance(row, dict) else None
        blocked, reason = _lock_blocks(lock_index, uid, ("constant", "activation"))
        if blocked:
            lock_exclusions.append({"uid": str(uid), "strategy": "constant_demotion", "reason": reason})
        else:
            kept_constant.append(row)
    constant_demotions = kept_constant

    baseline = worst_case_after_pruning(plan, manifest, before_data)

    # Item 30: score only candidates that survived the existing strategy-specific
    # lock filters. The base score is exact co-fire exposure across the same
    # WCSA activation sets already computed above; semantic objectives are a
    # small preservation bias, never a replacement for measured projections.
    objective_names = validate_pruning_objective_rows(plan.get("pruning_objectives", []))
    candidate_strategies: dict[str, set[str]] = {}
    for _key, owners in keyword_collisions.items():
        for uid in owners:
            candidate_strategies.setdefault(str(uid), set()).add("keyword_collision_tightening")
    for row in constant_demotions:
        if isinstance(row, dict) and row.get("uid") is not None:
            candidate_strategies.setdefault(str(row["uid"]), set()).add("constant_demotion")
    for row in depth_candidates:
        if isinstance(row, dict) and row.get("uid") is not None:
            candidate_strategies.setdefault(str(row["uid"]), set()).add("depth_restratification")
    objective_priority = score_candidates(
        manifest, baseline["all_simulations"], candidate_strategies, objective_names
    )
    priority_by_uid = {row["uid"]: row for row in objective_priority["rows"]}

    keyword_projections: list[dict[str, Any]] = []
    for key, owners in sorted(keyword_collisions.items()):
        for owner_uid in owners:
            hypothetical = _hypothetical_after_removing_key(before_data, owner_uid, key)
            projected = worst_case_after_pruning(plan, manifest, hypothetical)
            keyword_projections.append({
                "strategy": "keyword_collision_tightening", "uid": owner_uid, "key": key,
                "projected_max_pressure": projected["max_pressure"],
                "projected_delta": projected["max_pressure"] - baseline["max_pressure"],
                "pruning_priority": priority_by_uid.get(str(owner_uid)),
            })
    if objective_names:
        # Objectives bias review order, while the real projected WCSA delta is
        # retained as the next key and reported unchanged.
        keyword_projections.sort(key=lambda row: (
            -int((row.get("pruning_priority") or {}).get("adjusted_prune_score", 0)),
            row["projected_delta"], str(row["uid"]), str(row["key"]),
        ))
    else:
        keyword_projections.sort(key=lambda row: row["projected_delta"])  # legacy: biggest reduction first
    paged_projections = _paginate(keyword_projections, page, page_size)

    return {
        "contract": "worldbuilder-prune-analyze-v1",
        "baseline_max_pressure": baseline["max_pressure"],
        "tier_0": {
            "keyword_collision_tightening": {
                "candidates": keyword_collisions,
                "projections": paged_projections,
            },
            "constant_demotion": {"candidates": constant_demotions, "projected_savings": None},
            "depth_restratification": {"candidates": depth_candidates, "projected_savings": None},
        },
        "tier_1": {
            "ancestor_redundancy": ancestor_candidates,
            "ancestor_redundancy_engine": {
                "engine": "dominator_analysis",
                "executed": True,
                "meaning": "graph dominators prove guaranteed co-occurrence before ancestor redundancy is proposed",
            },
            "card_shell_redundancy": shell_candidates,
        },
        "lock_exclusions": lock_exclusions,
        "objective_priority": objective_priority,
        "note": (
            "Tier 0's keyword-collision projections are real, simulated numbers. Constant-demotion "
            "and depth-restratification's projected_savings are explicitly None; their actual WCSA "
            "impact depends on runtime activation probability this codebase does not yet model well "
            "enough to project honestly. Tier 1 candidates are reported as structural opportunities; "
            "their savings depend on how much content an auditor actually finds overlapping. Semantic pruning "
            "objectives, when active, only bias candidate review order using co-fire exposure from these same "
            "simulations; they are not locks, runtime drop-order changes, or fabricated savings."
        ),
    }
