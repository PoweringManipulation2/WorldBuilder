#!/usr/bin/env python3
"""Infer source-facet candidates from real MediaWiki page structure.

This module never auto-confirms a facet mapping. It only projects categories,
infobox templates, and navigation templates from page-fetch records so the
parent can show candidates to the user before discovery filtering begins.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any, Iterable

from wb_common import WorldBuilderError, atomic_write_json, load_build_state, load_json, resolve_state_path, sha256_file

CONTRACT = "worldbuilder-facet-candidates-v1"
KIND = "worldbuilder-facet-candidates"
VERSION = 1

# Conservative semantic bridges for common source facets. Unknown facets still
# work through literal token matching; this table only covers obvious taxonomy
# synonyms such as weapons <-> armament.
FACET_EQUIVALENTS: dict[str, tuple[str, ...]] = {
    "weapon": ("weapon", "weapons", "armament", "armaments", "arsenal", "arms"),
    "weapons": ("weapon", "weapons", "armament", "armaments", "arsenal", "arms"),
    "character": ("character", "characters", "person", "people", "npc", "npcs"),
    "characters": ("character", "characters", "person", "people", "npc", "npcs"),
    "location": ("location", "locations", "place", "places", "region", "regions", "area", "areas"),
    "locations": ("location", "locations", "place", "places", "region", "regions", "area", "areas"),
    "faction": ("faction", "factions", "organization", "organizations", "organisation", "organisations", "group", "groups", "guild", "guilds"),
    "factions": ("faction", "factions", "organization", "organizations", "organisation", "organisations", "group", "groups", "guild", "guilds"),
    "ability": ("ability", "abilities", "power", "powers", "skill", "skills", "magic"),
    "abilities": ("ability", "abilities", "power", "powers", "skill", "skills", "magic"),
    "item": ("item", "items", "object", "objects", "equipment", "gear"),
    "items": ("item", "items", "object", "objects", "equipment", "gear"),
}


def _space(value: Any) -> str:
    return re.sub(r"[_\s]+", " ", str(value or "").strip())


def _norm(value: Any, prefix: str | None = None) -> str:
    text = _space(value)
    if prefix and text.casefold().startswith(prefix.casefold() + ":"):
        text = text.split(":", 1)[1]
    return text.casefold()


def _title(value: Any, prefix: str) -> str | None:
    if isinstance(value, dict):
        value = value.get("title") or value.get(prefix.casefold()) or value.get("name") or value.get("*")
    if not isinstance(value, str) or not value.strip():
        return None
    text = _space(value)
    if not text.casefold().startswith(prefix.casefold() + ":"):
        text = f"{prefix}:{text}"
    return text


def category_names(fetch: dict[str, Any]) -> list[str]:
    out: list[str] = []
    for item in fetch.get("categories", []) if isinstance(fetch.get("categories"), list) else []:
        title = _title(item, "Category")
        if title and title not in out:
            out.append(title)
    return out


def template_names(fetch: dict[str, Any]) -> list[str]:
    out: list[str] = []
    for item in fetch.get("templates", []) if isinstance(fetch.get("templates"), list) else []:
        title = _title(item, "Template")
        if title and title not in out:
            out.append(title)
    return out


def facet_terms(facet: str) -> set[str]:
    normalized = _norm(facet)
    terms = {token for token in re.findall(r"[a-z0-9]+", normalized) if len(token) >= 2}
    expanded = set(terms)
    for token in list(terms):
        expanded.update(FACET_EQUIVALENTS.get(token, ()))
        if token.endswith("s"):
            expanded.add(token[:-1])
    if normalized in FACET_EQUIVALENTS:
        expanded.update(FACET_EQUIVALENTS[normalized])
    return {term.casefold() for term in expanded if term}


def _tokens(value: str, *, prefix: str | None = None) -> set[str]:
    text = _norm(value, prefix)
    return {token for token in re.findall(r"[a-z0-9]+", text) if len(token) >= 2}


def _role(template: str, fetch: dict[str, Any]) -> tuple[str | None, list[str]]:
    plain = _norm(template, "Template")
    reasons: list[str] = []
    if "infobox" in plain:
        return "infobox_template", ["template-name:infobox"]
    if any(token in plain for token in ("navbox", "navigation box", "navigation", "sidebar")):
        return "navbox_template", ["template-name:navigation"]
    rendered = fetch.get("rendered_html")
    if isinstance(rendered, str):
        lower = rendered.casefold()
        if re.search(r'class\s*=\s*["\'][^"\']*\binfobox\b', lower):
            reasons.append("rendered-html:infobox")
        if re.search(r'class\s*=\s*["\'][^"\']*\bnavbox\b', lower):
            reasons.append("rendered-html:navbox")
    # Rendered HTML can establish that the page uses an infobox/navbox, but not
    # which arbitrary template produced it. Only use this weaker structural
    # signal when the template name itself also matches the requested facet;
    # build_candidates() applies that term check before accepting the row.
    if "rendered-html:infobox" in reasons:
        return "infobox_template", reasons
    if "rendered-html:navbox" in reasons:
        return "navbox_template", reasons
    return None, []


def _term_match(name: str, facet: str, prefix: str) -> tuple[bool, list[str]]:
    terms = facet_terms(facet)
    tokens = _tokens(name, prefix=prefix)
    matched = sorted(terms & tokens)
    return bool(matched), [f"facet-term:{term}" for term in matched]


def _pages(data: Any) -> list[dict[str, Any]]:
    if isinstance(data, dict) and data.get("kind") == "worldbuilder-page-fetch":
        return [data]
    if isinstance(data, dict) and isinstance(data.get("pages"), list):
        return [row for row in data["pages"] if isinstance(row, dict)]
    if isinstance(data, list):
        return [row for row in data if isinstance(row, dict)]
    raise WorldBuilderError("facet inference input must be a page-fetch object, pages[] object, or JSON array")


def build_candidates(facet: str, pages: Iterable[dict[str, Any]], *, input_sha256s: list[str] | None = None) -> dict[str, Any]:
    if not isinstance(facet, str) or not facet.strip():
        raise WorldBuilderError("requested facet must be non-empty")
    rows: dict[tuple[str, str], dict[str, Any]] = {}
    count = 0
    for fetch in pages:
        if not isinstance(fetch, dict):
            continue
        count += 1
        page_title = str(fetch.get("title") or fetch.get("requested_title") or fetch.get("source_url") or f"page-{count}")
        source_url = fetch.get("source_url") if isinstance(fetch.get("source_url"), str) else None
        for name in category_names(fetch):
            matched, reasons = _term_match(name, facet, "Category")
            if not matched:
                continue
            key = ("category", _norm(name, "Category"))
            row = rows.setdefault(key, {"signal": "category", "name": name, "supporting_pages": [], "reasons": set(), "score": 0})
            row["reasons"].update(reasons)
            row["score"] += 2
            row["supporting_pages"].append({"title": page_title, "source_url": source_url})
        for name in template_names(fetch):
            role, role_reasons = _role(name, fetch)
            if role is None:
                continue
            matched, term_reasons = _term_match(name, facet, "Template")
            # Explicit template roles whose own names do not semantically match
            # the requested facet are not useful facet candidates.
            if not matched:
                continue
            key = (role, _norm(name, "Template"))
            row = rows.setdefault(key, {"signal": role, "name": name, "supporting_pages": [], "reasons": set(), "score": 0})
            row["reasons"].update(role_reasons + term_reasons)
            row["score"] += 4 if role == "infobox_template" else 3
            row["supporting_pages"].append({"title": page_title, "source_url": source_url})
    candidates: list[dict[str, Any]] = []
    for row in rows.values():
        row["reasons"] = sorted(row["reasons"])
        unique_pages: list[dict[str, Any]] = []
        seen: set[tuple[str, str | None]] = set()
        for page in row["supporting_pages"]:
            key = (str(page.get("title")), page.get("source_url"))
            if key not in seen:
                seen.add(key)
                unique_pages.append(page)
        row["supporting_pages"] = unique_pages
        row["support_count"] = len(unique_pages)
        row["score"] += max(0, len(unique_pages) - 1)
        candidates.append(row)
    candidates.sort(key=lambda row: (-int(row["score"]), str(row["signal"]), _norm(row["name"])))
    return {
        "kind": KIND,
        "contract": CONTRACT,
        "facet_candidates_version": VERSION,
        "requested_facet": facet.strip(),
        "page_count": count,
        "input_sha256s": list(input_sha256s or []),
        "candidates": candidates,
        "confirmation_required": True,
        "auto_apply": False,
    }


def validate_candidates(data: Any, *, requested_facet: str | None = None) -> dict[str, Any]:
    if not isinstance(data, dict) or data.get("kind") != KIND or data.get("contract") != CONTRACT or data.get("facet_candidates_version") != VERSION:
        raise WorldBuilderError("facet candidates must use worldbuilder-facet-candidates-v1")
    facet = data.get("requested_facet")
    if not isinstance(facet, str) or not facet.strip():
        raise WorldBuilderError("facet candidates requested_facet is missing")
    if requested_facet is not None and _norm(facet) != _norm(requested_facet):
        raise WorldBuilderError("facet candidates requested_facet does not match --facet")
    candidates = data.get("candidates")
    if not isinstance(candidates, list):
        raise WorldBuilderError("facet candidates must contain candidates[]")
    seen: set[tuple[str, str]] = set()
    for row in candidates:
        if not isinstance(row, dict) or row.get("signal") not in {"category", "infobox_template", "navbox_template"}:
            raise WorldBuilderError("facet candidate signal is invalid")
        name = row.get("name")
        if not isinstance(name, str) or not name.strip():
            raise WorldBuilderError("facet candidate name is missing")
        prefix = "Category" if row["signal"] == "category" else "Template"
        key = (row["signal"], _norm(name, prefix))
        if key in seen:
            raise WorldBuilderError("facet candidates contain duplicate signals")
        seen.add(key)
    return data


def candidate_names(data: dict[str, Any], signals: set[str]) -> dict[str, str]:
    validate_candidates(data)
    result: dict[str, str] = {}
    for row in data["candidates"]:
        if row["signal"] not in signals:
            continue
        prefix = "Category" if row["signal"] == "category" else "Template"
        result[_norm(row["name"], prefix)] = row["name"]
    return result


def facet_match_details(fetch: dict[str, Any], facet_filter: Any) -> dict[str, Any]:
    if not isinstance(facet_filter, dict):
        return {"matched": True, "categories": [], "templates": []}
    selected_categories = {_norm(v, "Category") for v in facet_filter.get("category_names", []) if str(v).strip()}
    selected_templates = {_norm(v, "Template") for v in facet_filter.get("template_names", []) if str(v).strip()}
    if not selected_categories and not selected_templates:
        return {"matched": True, "categories": [], "templates": []}
    actual_categories = {_norm(v, "Category"): v for v in category_names(fetch)}
    actual_templates = {_norm(v, "Template"): v for v in template_names(fetch)}
    matched_categories = [actual_categories[key] for key in sorted(selected_categories & set(actual_categories))]
    matched_templates = [actual_templates[key] for key in sorted(selected_templates & set(actual_templates))]
    return {
        "matched": bool(matched_categories or matched_templates),
        "categories": matched_categories,
        "templates": matched_templates,
    }


def facet_matches(fetch: dict[str, Any], facet_filter: Any) -> bool:
    return bool(facet_match_details(fetch, facet_filter)["matched"])


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--build-state", help="Build-state path; when supplied, default output is paths.facet_candidates")
    parser.add_argument("--facet", required=True)
    parser.add_argument("--page-fetch", action="append", default=[], help="JSON page-fetch or pages[] file; repeat as needed")
    parser.add_argument("--output")
    args = parser.parse_args()
    try:
        if not args.page_fetch:
            raise WorldBuilderError("at least one --page-fetch file is required")
        root: Path | None = None
        state: dict[str, Any] | None = None
        if args.build_state:
            root, state = load_build_state(Path(args.build_state).resolve())
        pages: list[dict[str, Any]] = []
        hashes: list[str] = []
        for raw in args.page_fetch:
            path = Path(raw).resolve()
            if root is not None:
                try:
                    path.relative_to(root)
                except ValueError as exc:
                    raise WorldBuilderError("facet page-fetch files must remain inside the build workspace") from exc
            data = load_json(path)
            pages.extend(_pages(data))
            hashes.append(sha256_file(path))
        output = build_candidates(args.facet, pages, input_sha256s=hashes)
        if args.output:
            out = Path(args.output).resolve()
        elif root is not None and state is not None:
            out = resolve_state_path(root, state, "facet_candidates")
            assert out is not None
        else:
            raise WorldBuilderError("--output is required when --build-state is omitted")
        if root is not None:
            try:
                out.relative_to(root)
            except ValueError as exc:
                raise WorldBuilderError("facet candidate output must remain inside the build workspace") from exc
        atomic_write_json(out, output)
        print(json.dumps({"status": "proposed", "output": str(out), "candidate_count": len(output["candidates"]), "output_sha256": sha256_file(out)}, indent=2))
        return 0
    except (WorldBuilderError, OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
