#!/usr/bin/env python3
"""Bind a worker findings file to the exact WorldBuilder build and assignment.

The findings file must begin with a machine-readable header line:

    WORLDBUILDER-FINDINGS: {"build_id":"...","manifest_sha256":"...",
      "entry_count":9,"assigned":[{"uid":7,"name":"Example"}]}

This prevents stale or unrelated reports from passing based on loose substring
matches.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any

from wb_common import WorldBuilderError, load_json, normalize_identity

HEADER_PREFIX = "WORLDBUILDER-FINDINGS:"
COUNT_RE = re.compile(r"\b(?:entry_count|entries?)\s*[:=]?\s*(\d[\d,]*)\b", re.I)


def find_asserted_counts(text: str) -> list[int]:
    return [int(match.group(1).replace(",", "")) for match in COUNT_RE.finditer(text)]


def parse_header(text: str) -> dict[str, Any]:
    first_nonempty = next((line.strip() for line in text.splitlines() if line.strip()), "")
    if not first_nonempty.startswith(HEADER_PREFIX):
        raise WorldBuilderError(f"first non-empty line must start with {HEADER_PREFIX}")
    payload = first_nonempty[len(HEADER_PREFIX):].strip()
    try:
        header = json.loads(payload)
    except json.JSONDecodeError as exc:
        raise WorldBuilderError(f"invalid findings header JSON: {exc}") from exc
    if not isinstance(header, dict):
        raise WorldBuilderError("findings header must be a JSON object")
    return header


def assignment_pairs(value: Any) -> set[tuple[Any, str]]:
    if not isinstance(value, list):
        raise WorldBuilderError("assigned must be an array")
    result: set[tuple[Any, str]] = set()
    for item in value:
        if not isinstance(item, dict):
            raise WorldBuilderError("each assigned item must be an object")
        uid = normalize_identity(item.get("uid", item.get("id")))
        name = str(item.get("name", "")).strip()
        if uid is None or not name:
            raise WorldBuilderError("each assigned item requires uid/id and name")
        pair = (uid, name)
        if pair in result:
            raise WorldBuilderError(f"duplicate assigned item {pair!r}")
        result.add(pair)
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate a worker report against a build fingerprint.")
    parser.add_argument("path")
    parser.add_argument("--build-id", required=True)
    parser.add_argument("--assignment")
    parser.add_argument("--min-chars", type=int, default=120)
    args = parser.parse_args()

    try:
        report_path = Path(args.path)
        if not report_path.exists():
            raise WorldBuilderError(f"findings file not found: {report_path}")
        text = report_path.read_text(encoding="utf-8", errors="replace")
        if len(text.strip()) < args.min_chars:
            raise WorldBuilderError(f"findings file is too short ({len(text.strip())} characters)")
        header = parse_header(text)
        build = load_json(args.build_id)
        if not isinstance(build, dict):
            raise WorldBuilderError("build-id.json must be an object")

        expected_id = str(build.get("build_id", "")).strip()
        expected_hash = str(build.get("manifest_sha256", "")).strip().lower()
        expected_count = build.get("entry_count")
        if not expected_id or not expected_hash or not isinstance(expected_count, int):
            raise WorldBuilderError("build-id.json requires build_id, manifest_sha256, and integer entry_count")
        if header.get("build_id") != expected_id:
            raise WorldBuilderError(f"build_id mismatch: {header.get('build_id')!r} != {expected_id!r}")
        if str(header.get("manifest_sha256", "")).lower() != expected_hash:
            raise WorldBuilderError("manifest_sha256 mismatch")
        if header.get("entry_count") != expected_count:
            raise WorldBuilderError(f"entry_count mismatch: {header.get('entry_count')!r} != {expected_count}")

        observed_assigned = assignment_pairs(header.get("assigned", []))
        if args.assignment:
            assignment = load_json(args.assignment)
            expected_assigned = assignment_pairs(assignment.get("entries", assignment.get("assigned", [])))
        else:
            expected_assigned = assignment_pairs(build.get("assigned", build.get("sentinels", [])))
        if expected_assigned and observed_assigned != expected_assigned:
            missing = sorted(expected_assigned - observed_assigned, key=str)
            extra = sorted(observed_assigned - expected_assigned, key=str)
            raise WorldBuilderError(f"assigned set mismatch; missing={missing!r}, extra={extra!r}")

        # Labeled counts in the body may be omitted, but any that are asserted
        # must match the structured header/build exactly. Single digits work.
        for count in find_asserted_counts("\n".join(text.splitlines()[1:])):
            if count != expected_count and count != len(expected_assigned):
                raise WorldBuilderError(f"body asserts unrelated entry count {count}")
        if expected_assigned:
            lower = text.casefold()
            absent = [name for _, name in expected_assigned if name.casefold() not in lower]
            if absent:
                raise WorldBuilderError(f"report never mentions assigned name(s): {absent!r}")

        print("FINDINGS GATE PASSED")
        return 0
    except (OSError, json.JSONDecodeError, WorldBuilderError) as exc:
        print(f"FINDINGS GATE BLOCKED: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
