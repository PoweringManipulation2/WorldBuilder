#!/usr/bin/env python3
"""Record parent-observed OpenClaw completion for one discovery worker.

The worker result cannot certify its own execution. Run this from the parent
only after the matching worker reports ``completed`` and its
hash-bound JSON output exists. ``discovery_gate.py`` requires one unique runtime
receipt per bird-named assignment.
"""
from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from dispatch_observation import (
    CHILD_RUN_COMPLETION, CHILD_RUNTIME_PARTIAL_KIND, CHILD_RUNTIME_RECEIPT_KIND,
    PARENT_EXEC_COMPLETION, PARENT_OBSERVED_CHILD_RUN, PARENT_OBSERVED_EXEC, RECORDED_BY_PARENT,
)
from typing import Any

from discovery_contract import DISCOVERY_ASSIGNMENT_VERSION, DISCOVERY_RUNTIME_RECEIPT_VERSION, contract_block
from worker_run_ledger import update as update_run
from wb_common import (
    WorldBuilderError,
    atomic_write_json,
    ensure_inside,
    load_build_state,
    load_json,
    now_iso,
    resolve_state_path,
    sha256_file,
)


def parse_iso(value: str, field: str) -> datetime:
    text = value.strip().replace("Z", "+00:00")
    try:
        parsed = datetime.fromisoformat(text)
    except ValueError as exc:
        raise WorldBuilderError(f"{field} must be an ISO-8601 timestamp") from exc
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def timed_out_record_path(runtime_path: Path) -> Path:
    """Sibling path for a timed-out partial record, never the receipt path
    itself. 'Only completed can be receipted' means runtime_receipt's own
    location is written by nothing but a genuine completion."""
    return runtime_path.with_name(runtime_path.stem + ".timed_out.json")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--build-state", required=True)
    parser.add_argument("--assignment", required=True, help="Assignment JSON path inside the build workspace")
    parser.add_argument(
        "--runtime-source",
        choices=["sessions_spawn", "exec"],
        default="sessions_spawn",
    )
    parser.add_argument("--child-session-id")
    parser.add_argument("--run-id", required=True, help="Unique run/process ID observed by the parent")
    parser.add_argument("--runtime-event-id", help="Stable completion event/idempotency ID; defaults to run ID for parent-observed exec")
    parser.add_argument("--workdir", help="Required absolute workdir for exec receipts")
    parser.add_argument("--exit-code", type=int, help="Required successful exit code for exec receipts")
    parser.add_argument("--status", default="completed", choices=["completed", "failed", "timed_out"])
    parser.add_argument("--spawned-at", required=True)
    parser.add_argument("--completed-at")
    parser.add_argument("--parent-session-id", required=True)
    args = parser.parse_args()
    runtime_backend = {
        "sessions_spawn": "sessions_spawn",
        "exec": "exec",
    }[args.runtime_source]
    runtime_event_id = args.runtime_event_id or f"completion:{args.run_id}"

    try:
        if args.status == "timed_out":
            for field, value in (("run_id", args.run_id),):
                if not value.strip() or len(value.strip()) < 4:
                    raise WorldBuilderError(f"{field} is missing or implausibly short")
            if not args.parent_session_id.strip() or len(args.parent_session_id.strip()) < 4:
                raise WorldBuilderError("parent_session_id is missing or implausibly short")
            if runtime_backend == "sessions_spawn" and (not args.child_session_id or len(args.child_session_id.strip()) < 4):
                raise WorldBuilderError("child_session_id is required for sessions_spawn receipts")
            spawned = parse_iso(args.spawned_at, "spawned_at")
            observed = parse_iso(args.completed_at or now_iso(), "completed_at")
            if observed < spawned:
                raise WorldBuilderError("completed_at precedes spawned_at")

            state_path = Path(args.build_state).resolve()
            root, state = load_build_state(state_path)
            assignments_root = resolve_state_path(root, state, "assignments")
            assignment_path = Path(args.assignment)
            if not assignment_path.is_absolute():
                assignment_path = root / assignment_path
            assignment_path = assignment_path.resolve()
            ensure_inside(assignment_path, assignments_root)
            if not assignment_path.exists():
                raise WorldBuilderError(f"discovery assignment does not exist: {assignment_path}")
            assignment = load_json(assignment_path)
            if not isinstance(assignment, dict) or int(assignment.get("assignment_version", 0) or 0) not in {5, 6, DISCOVERY_ASSIGNMENT_VERSION}:
                raise WorldBuilderError(f"discovery assignment must use a supported assignment version (5, 6, or {DISCOVERY_ASSIGNMENT_VERSION})")
            if assignment.get("build_id") != state.get("build_id"):
                raise WorldBuilderError("discovery assignment belongs to another build")

            runtime_value = assignment.get("runtime_receipt")
            if not isinstance(runtime_value, str) or not runtime_value:
                raise WorldBuilderError("discovery assignment has no runtime_receipt path")
            runtime_path = (root / runtime_value).resolve()
            runtime_root = resolve_state_path(root, state, "discovery_runtime", required=False) or (root / ".work" / "discovery-runtime")
            ensure_inside(runtime_path, runtime_root.resolve())
            if runtime_path.exists():
                raise WorldBuilderError("a completion receipt already exists for this assignment; a timeout cannot follow a completion")
            partial_path = timed_out_record_path(runtime_path)
            record: dict[str, Any] = {
                "kind": CHILD_RUNTIME_PARTIAL_KIND,
                "status": "timed_out",
                "runtime_source": PARENT_OBSERVED_CHILD_RUN if runtime_backend == "sessions_spawn" else PARENT_OBSERVED_EXEC,
                "recorded_by": RECORDED_BY_PARENT,
                "build_id": assignment.get("build_id"),
                "assignment_id": assignment.get("assignment_id"),
                "assignment_sha256": sha256_file(assignment_path),
                "stage": assignment.get("stage"),
                "pass_number": assignment.get("pass_number"),
                "worker": assignment.get("worker"),
                "taskName": assignment.get("taskName"),
                "child_session_id": args.child_session_id if runtime_backend == "sessions_spawn" else None,
                "run_id": args.run_id,
                "parent_session_id": args.parent_session_id,
                "spawned_at": spawned.isoformat().replace("+00:00", "Z"),
                "observed_at": observed.isoformat().replace("+00:00", "Z"),
                "elapsed_seconds": int((observed - spawned).total_seconds()),
                "assignment_output": assignment.get("output"),
                "note": (
                    "Not a receipt. Re-dispatch the same assignment_id with a longer "
                    "run_timeout_seconds; the page cache skips already-fetched URLs."
                ),
            }
            atomic_write_json(partial_path, record)
            print(json.dumps({
                "status": "timed_out_recorded",
                "partial_record": str(partial_path),
                "assignment_id": assignment.get("assignment_id"),
                "worker": assignment.get("worker"),
                "elapsed_seconds": record["elapsed_seconds"],
            }, indent=2))
            return 0

        if args.status != "completed":
            raise WorldBuilderError(f"discovery worker runtime status is {args.status!r}; only completed can be receipted")
        for field, value in (
            ("run_id", args.run_id),
            ("runtime_event_id", runtime_event_id),
        ):
            if not value.strip() or len(value.strip()) < 4:
                raise WorldBuilderError(f"{field} is missing or implausibly short")
        if not args.parent_session_id.strip() or len(args.parent_session_id.strip()) < 4:
            raise WorldBuilderError("parent_session_id is missing or implausibly short")
        if runtime_backend == "sessions_spawn":
            if not args.child_session_id or len(args.child_session_id.strip()) < 4:
                raise WorldBuilderError("child_session_id is required for sessions_spawn receipts")
            if args.parent_session_id.strip() == args.child_session_id.strip():
                raise WorldBuilderError("parent_session_id must differ from child_session_id")
        else:
            if args.exit_code not in (None, 0):
                raise WorldBuilderError("exec receipt requires a successful exit code")
            if args.workdir and not Path(args.workdir).is_absolute():
                raise WorldBuilderError("exec receipt workdir must be absolute when provided")
        spawned = parse_iso(args.spawned_at, "spawned_at")
        completed = parse_iso(args.completed_at or now_iso(), "completed_at")
        if completed < spawned:
            raise WorldBuilderError("completed_at precedes spawned_at")

        state_path = Path(args.build_state).resolve()
        root, state = load_build_state(state_path)
        effective_workdir = Path(args.workdir).resolve() if args.workdir else root.resolve()
        effective_exit_code = 0 if args.exit_code is None else args.exit_code
        assignments_root = resolve_state_path(root, state, "assignments")
        assignment_path = Path(args.assignment)
        if not assignment_path.is_absolute():
            assignment_path = root / assignment_path
        assignment_path = assignment_path.resolve()
        ensure_inside(assignment_path, assignments_root)
        if not assignment_path.exists():
            raise WorldBuilderError(f"discovery assignment does not exist: {assignment_path}")
        assignment = load_json(assignment_path)
        if not isinstance(assignment, dict) or int(assignment.get("assignment_version", 0) or 0) not in {5, 6, DISCOVERY_ASSIGNMENT_VERSION}:
            raise WorldBuilderError(f"discovery assignment must use a supported assignment version (5, 6, or {DISCOVERY_ASSIGNMENT_VERSION})")
        if assignment.get("build_id") != state.get("build_id"):
            raise WorldBuilderError("discovery assignment belongs to another build")

        output_value = assignment.get("output")
        if not isinstance(output_value, str) or not output_value:
            raise WorldBuilderError("discovery assignment has no output path")
        result_path = (root / output_value).resolve()
        discoveries_root = resolve_state_path(root, state, "discoveries", required=False) or (root / "artifacts" / "discoveries")
        ensure_inside(result_path, discoveries_root.resolve())
        if not result_path.exists():
            raise WorldBuilderError("discovery result does not exist")
        result = load_json(result_path)
        meta = result.get("_worldbuilder") if isinstance(result, dict) else None
        if not isinstance(meta, dict):
            raise WorldBuilderError("discovery result lacks _worldbuilder metadata")
        exact_meta = {
            "assignment_id": assignment.get("assignment_id"),
            "assignment_sha256": sha256_file(assignment_path),
            "worker": assignment.get("worker"),
            "taskName": assignment.get("taskName"),
            "pass_number": assignment.get("pass_number"),
            "completed": True,
            "runtime_status": "completed",
            "end_delimiter": assignment.get("expected_end_delimiter"),
        }
        for key, expected in exact_meta.items():
            if meta.get(key) != expected:
                raise WorldBuilderError(f"discovery result metadata mismatch at {key}")
        # A child may not know the OpenClaw session key assigned by the parent.
        # When it voluntarily echoes one, require an exact match; otherwise the
        # separate parent-observed runtime receipt remains authoritative.
        echoed_child = meta.get("child_session_id")
        if runtime_backend == "sessions_spawn" and echoed_child not in (None, "") and echoed_child != args.child_session_id:
            raise WorldBuilderError("parent-observed child session ID does not match discovery result")

        runtime_value = assignment.get("runtime_receipt")
        if not isinstance(runtime_value, str) or not runtime_value:
            raise WorldBuilderError("discovery assignment has no runtime_receipt path")
        runtime_path = (root / runtime_value).resolve()
        runtime_root = resolve_state_path(root, state, "discovery_runtime", required=False) or (root / ".work" / "discovery-runtime")
        ensure_inside(runtime_path, runtime_root.resolve())
        receipt: dict[str, Any] = {
            "kind": CHILD_RUNTIME_RECEIPT_KIND,
            "receipt_version": DISCOVERY_RUNTIME_RECEIPT_VERSION,
            "runtime_source": PARENT_OBSERVED_CHILD_RUN if runtime_backend == "sessions_spawn" else PARENT_OBSERVED_EXEC,
            "source": CHILD_RUN_COMPLETION if runtime_backend == "sessions_spawn" else PARENT_EXEC_COMPLETION,
            "recorded_by": RECORDED_BY_PARENT,
            "contract": contract_block((assignment.get("contract") or {}).get("worker_kit_sha256")),
            "build_id": assignment.get("build_id"),
            "assignment_id": assignment.get("assignment_id"),
            "assignment_sha256": sha256_file(assignment_path),
            "stage": assignment.get("stage"),
            "pass_number": assignment.get("pass_number"),
            "worker": assignment.get("worker"),
            "taskName": assignment.get("taskName"),
            "status": "completed",
            "child_session_id": args.child_session_id if runtime_backend == "sessions_spawn" else None,
            "workdir": str(effective_workdir) if runtime_backend == "exec" else None,
            "exit_code": effective_exit_code if runtime_backend == "exec" else None,
            "run_id": args.run_id,
            "runtime_event_id": runtime_event_id,
            "parent_session_id": args.parent_session_id,
            "spawned_at": spawned.isoformat().replace("+00:00", "Z"),
            "completed_at": completed.isoformat().replace("+00:00", "Z"),
            "result": output_value,
            "result_sha256": sha256_file(result_path),
            "terminal_delimiter": assignment.get("expected_end_delimiter"),
        }
        ledger_check = update_run(
            str(state_path), "check", args.run_id, assignment.get("assignment_id"), runtime_backend, None, runtime_event_id
        )
        if ledger_check.get("status") == "unknown":
            # Parent-observed receipt recording is itself an authoritative run
            # observation. Register legacy/adapter dispatches on first receipt.
            update_run(
                str(state_path), "register", args.run_id, assignment.get("assignment_id"), runtime_backend, None, None
            )
        elif ledger_check.get("status") == "abandoned":
            raise WorldBuilderError("runtime completion belongs to an abandoned worker run")
        atomic_write_json(runtime_path, receipt)
        ledger_result = update_run(
            str(state_path), "complete", args.run_id, assignment.get("assignment_id"), runtime_backend, None, runtime_event_id
        )
        if ledger_result.get("status") == "quarantined":
            runtime_path.unlink(missing_ok=True)
            raise WorldBuilderError("runtime completion belongs to an abandoned worker run")
        print(json.dumps({
            "status": "recorded",
            "runtime_receipt": str(runtime_path),
            "assignment_id": assignment.get("assignment_id"),
            "worker": assignment.get("worker"),
        }, indent=2))
        return 0
    except (WorldBuilderError, OSError, json.JSONDecodeError, ValueError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
