#!/usr/bin/env python3
"""Measure gate convergence, and partition generation batches by dependency density.

Two problems that turn out to share a shape.

**Reliability is unmeasured.** "Does a cheap model work" is currently a feeling. The
gates already guarantee validity, malformed output cannot ship regardless of model,
so the real variable is *convergence*: how many attempts a model needs before its
output passes. That is measurable, and measuring it converts a vibe into a number a
release note can carry.

**DR-015 was aspirational.** It states that generation batches are "partitioned by
dependency density, evidence volume, context, runtime health, and user budget", but
the implementation was a flat configurable size. Entries that reference each other
need small batches to stay coherent; independent entries batch large safely. A single
global number is either too small for the independent majority or too large for the
interdependent minority.

Commands:
    record     append one gate attempt to the ledger
    report     first-attempt pass rate and convergence, by gate and model
    partition  split entries into batches sized by dependency density
"""
from __future__ import annotations

import argparse
import json
import math
import statistics
import sys
from collections import defaultdict
from pathlib import Path
from typing import Any

from wb_common import WorldBuilderError, load_json, raise_error

CONTRACT = "worldbuilder-gate-telemetry-v1"
LEDGER_NAME = "gate-attempts.jsonl"

OUTCOMES = ("pass", "fail", "error")
WORK_KINDS = ("discovery", "generation", "audit", "other")
CONFIDENCE_VALUES = {"high": 1.0, "medium": 0.65, "low": 0.35, "unknown": 0.5}
STAGGER_FLOOR_SECONDS = 10
STAGGER_CEILING_SECONDS = 60
STAGGER_BASE_SECONDS = 20

# Dependency-density bands. A batch of interdependent entries drifts because each
# entry's correctness depends on siblings the worker has not written yet.
DENSITY_BANDS = (
    (0.0, 1.0),    # isolated entries: full configured size
    (0.15, 0.66),  # lightly linked: two thirds
    (0.35, 0.4),   # densely linked: two fifths
    (0.60, 0.2),   # hub cluster: one fifth
)
MIN_BATCH = 1


# ------------------------------------------------------------------- telemetry


def record_attempt(ledger: Path, *, gate: str, model: str, attempt: int, outcome: str,
                   scope: str | None = None, error_class: str | None = None,
                   provider: str | None = None, latency_seconds: float | None = None,
                   timed_out: bool | None = None, work_kind: str | None = None,
                   input_tokens: int | None = None, output_tokens: int | None = None,
                   cache_read_tokens: int | None = None, cache_write_tokens: int | None = None) -> dict[str, Any]:
    if outcome not in OUTCOMES:
        raise_error(f"outcome must be one of {OUTCOMES}")
    if attempt < 1:
        raise_error("attempt numbering starts at 1")
    if not gate.strip() or not model.strip():
        raise_error("gate and model are required")
    if latency_seconds is not None and latency_seconds < 0:
        raise_error("latency_seconds must be non-negative")
    if work_kind is not None and work_kind not in WORK_KINDS:
        raise_error(f"work_kind must be one of {WORK_KINDS}")
    token_values = {
        "input_tokens": input_tokens,
        "output_tokens": output_tokens,
        "cache_read_tokens": cache_read_tokens,
        "cache_write_tokens": cache_write_tokens,
    }
    for field, value in token_values.items():
        if value is not None and (isinstance(value, bool) or not isinstance(value, int) or value < 0):
            raise_error(f"{field} must be a non-negative integer")
    row = {
        "kind": "worldbuilder-gate-attempt",
        "contract": CONTRACT,
        "gate": gate.strip(),
        "model": model.strip(),
        "scope": scope,
        "attempt": attempt,
        "outcome": outcome,
        "error_class": error_class,
        "provider": provider.strip() if isinstance(provider, str) and provider.strip() else None,
        "latency_seconds": float(latency_seconds) if latency_seconds is not None else None,
        "timed_out": bool(timed_out) if timed_out is not None else None,
        "work_kind": work_kind,
        **token_values,
    }
    ledger.parent.mkdir(parents=True, exist_ok=True)
    with ledger.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(row, ensure_ascii=False) + "\n")
    return row


def read_ledger(ledger: Path) -> list[dict[str, Any]]:
    if not ledger.exists():
        return []
    rows: list[dict[str, Any]] = []
    for line in ledger.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            row = json.loads(line)
        except json.JSONDecodeError:
            continue  # a truncated final line must not lose the whole ledger
        if isinstance(row, dict) and row.get("kind") == "worldbuilder-gate-attempt":
            rows.append(row)
    return rows


def _row_timed_out(row: dict[str, Any]) -> bool:
    if row.get("timed_out") is True:
        return True
    error_class = str(row.get("error_class") or "").lower()
    return "timeout" in error_class or "timed_out" in error_class


def recommended_stagger_seconds(rows: list[dict[str, Any]], *, provider: str | None = None,
                                base: int = STAGGER_BASE_SECONDS,
                                floor: int = STAGGER_FLOOR_SECONDS,
                                ceiling: int = STAGGER_CEILING_SECONDS,
                                window: int = 12) -> int:
    """Return deterministic spawn spacing from recent observed outcomes.

    This tunes only the delay between independent child starts. It never changes the
    assignment's stamped run_timeout_seconds liveness bound (DR-064). Old telemetry
    rows remain valid.
    """
    if not (1 <= floor <= base <= ceiling):
        raise_error("stagger bounds must satisfy 1 <= floor <= base <= ceiling")
    if window < 1:
        raise_error("stagger window must be at least 1")
    filtered = rows if not provider else [r for r in rows if r.get("provider") == provider]
    recent = filtered[-window:]
    if not recent:
        return base
    flags = [_row_timed_out(r) for r in recent]
    timeout_count = sum(flags)
    trailing_timeouts = 0
    for flag in reversed(flags):
        if not flag:
            break
        trailing_timeouts += 1
    if timeout_count:
        proposed = base + round((timeout_count / len(recent)) * 20) + trailing_timeouts * 5
    else:
        trailing_successes = 0
        for row in reversed(recent):
            if row.get("outcome") != "pass":
                break
            trailing_successes += 1
        proposed = base - min(10, trailing_successes * 2)
    return max(floor, min(ceiling, int(proposed)))


def report(rows: list[dict[str, Any]]) -> dict[str, Any]:
    """First-attempt pass rate and attempts-to-pass, per gate and per model.

    Validity is guaranteed by the gates, so this measures cost rather than quality:
    a low first-attempt rate means a model reaches the same correct output more
    expensively, not that it produces worse output.
    """
    by_scope: dict[tuple[str, str, str | None], list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        by_scope[(row["gate"], row["model"], row.get("scope"))].append(row)

    first_attempts: dict[tuple[str, str], list[bool]] = defaultdict(list)
    converged: dict[tuple[str, str], list[int]] = defaultdict(list)
    unresolved: dict[tuple[str, str], int] = defaultdict(int)
    error_classes: dict[str, int] = defaultdict(int)

    for (gate, model, _scope), attempts in by_scope.items():
        attempts.sort(key=lambda r: r["attempt"])
        passing = next((a for a in attempts if a["outcome"] == "pass"), None)
        first = attempts[0]
        first_attempts[(gate, model)].append(first["outcome"] == "pass")
        if passing is not None:
            converged[(gate, model)].append(passing["attempt"])
        else:
            unresolved[(gate, model)] += 1
        for attempt in attempts:
            if attempt["outcome"] != "pass" and attempt.get("error_class"):
                error_classes[attempt["error_class"]] += 1

    summary = []
    for key in sorted(set(first_attempts) | set(converged)):
        gate, model = key
        flags = first_attempts.get(key, [])
        steps = converged.get(key, [])
        summary.append({
            "gate": gate,
            "model": model,
            "samples": len(flags),
            "first_attempt_pass_rate": round(sum(flags) / len(flags), 4) if flags else None,
            "mean_attempts_to_pass": round(statistics.fmean(steps), 2) if steps else None,
            "max_attempts_to_pass": max(steps) if steps else None,
            "never_passed": unresolved.get(key, 0),
        })

    rates = [s["first_attempt_pass_rate"] for s in summary if s["first_attempt_pass_rate"] is not None]
    return {
        "kind": "worldbuilder-gate-telemetry-report",
        "contract": CONTRACT,
        "attempt_count": len(rows),
        "by_gate_and_model": summary,
        "overall_first_attempt_pass_rate": round(statistics.fmean(rates), 4) if rates else None,
        # The gates that cost the most retries are the ones whose instructions are
        # underspecified, not necessarily the ones that matter least.
        # Deduplicated by gate: the same gate appears once per model, and a list that
        # repeats a name reads as two findings when it is one.
        "most_expensive_gates": list(dict.fromkeys(
            s["gate"] for s in sorted(
                (s for s in summary if s["mean_attempts_to_pass"] is not None),
                key=lambda s: -s["mean_attempts_to_pass"])))[:3],
        "common_error_classes": sorted(error_classes.items(), key=lambda kv: -kv[1])[:5],
        "note": "Gates guarantee validity regardless of model. This measures convergence cost, "
                "not output quality.",
    }


def infer_work_kind(row: dict[str, Any]) -> str:
    """Return the optional recorded work kind, or conservatively infer it from gate name."""
    explicit = row.get("work_kind")
    if explicit in WORK_KINDS:
        return str(explicit)
    gate = str(row.get("gate") or "").casefold()
    if "discovery" in gate or "source_probe" in gate:
        return "discovery"
    if "audit" in gate or "warden" in gate or "weaver" in gate or "compass" in gate or "scout" in gate:
        return "audit"
    if any(token in gate for token in ("evidence", "generation", "entry_cycle", "phase")):
        return "generation"
    return "other"


def attempt_multiplier(rows: list[dict[str, Any]], *, model: str | None = None) -> dict[str, Any]:
    """Mean attempts-to-pass across converged logical scopes.

    This is a cost multiplier only (DR-061), never a quality score. Unresolved scopes
    are reported but excluded because they have no observed attempts-to-pass value.
    """
    filtered = [r for r in rows if model is None or r.get("model") == model]
    by_scope: dict[tuple[str, str, str | None], list[dict[str, Any]]] = defaultdict(list)
    for row in filtered:
        by_scope[(str(row.get("gate")), str(row.get("model")), row.get("scope"))].append(row)
    converged: list[int] = []
    unresolved = 0
    for attempts in by_scope.values():
        attempts.sort(key=lambda r: int(r.get("attempt", 0) or 0))
        passing = next((a for a in attempts if a.get("outcome") == "pass"), None)
        if passing is None:
            unresolved += 1
            continue
        try:
            converged.append(max(1, int(passing.get("attempt", 1))))
        except (TypeError, ValueError):
            converged.append(1)
    multiplier = round(statistics.fmean(converged), 4) if converged else 1.0
    return {
        "multiplier": multiplier,
        "converged_scope_samples": len(converged),
        "unresolved_scopes": unresolved,
        "model": model,
        "note": "Attempts-to-pass is a convergence cost multiplier, not output quality.",
    }


def token_profile(rows: list[dict[str, Any]], *, model: str | None = None) -> dict[str, Any]:
    """Observed model-token means by work kind, using only rows that recorded tokens.

    Old telemetry rows remain valid and simply contribute no token sample. Cache token
    counters are surfaced separately and are not silently double-counted into billed
    input/output totals because provider billing semantics differ.
    """
    samples: dict[str, list[int]] = defaultdict(list)
    cache_samples: dict[str, list[int]] = defaultdict(list)
    for row in rows:
        if model is not None and row.get("model") != model:
            continue
        input_tokens = row.get("input_tokens")
        output_tokens = row.get("output_tokens")
        if not (isinstance(input_tokens, int) and not isinstance(input_tokens, bool) and input_tokens >= 0):
            input_tokens = None
        if not (isinstance(output_tokens, int) and not isinstance(output_tokens, bool) and output_tokens >= 0):
            output_tokens = None
        kind = infer_work_kind(row)
        if input_tokens is not None or output_tokens is not None:
            samples[kind].append(int(input_tokens or 0) + int(output_tokens or 0))
        cache_total = 0
        cache_seen = False
        for field in ("cache_read_tokens", "cache_write_tokens"):
            value = row.get(field)
            if isinstance(value, int) and not isinstance(value, bool) and value >= 0:
                cache_total += value
                cache_seen = True
        if cache_seen:
            cache_samples[kind].append(cache_total)
    means = {kind: round(statistics.fmean(values), 2) for kind, values in samples.items() if values}
    counts = {kind: len(values) for kind, values in samples.items() if values}
    cache_means = {kind: round(statistics.fmean(values), 2) for kind, values in cache_samples.items() if values}
    return {
        "model": model,
        "mean_input_plus_output_tokens": means,
        "sample_counts": counts,
        "mean_cache_tokens": cache_means,
        "total_token_samples": sum(counts.values()),
        "note": "Only explicitly recorded input/output token counters are averaged; absent history stays unknown.",
    }


# ------------------------------------------------------------------ partitioning


def _edges(manifest: dict[str, Any]) -> list[tuple[str, str]]:
    """Return graph edges from the current activation-graph contract or legacy fixtures."""
    graph = manifest.get("activation_graph")
    edges = graph.get("edges") if isinstance(graph, dict) else None
    current: list[tuple[str, str]] = []
    if isinstance(edges, list):
        current = [
            (str(e.get("source_uid")), str(e.get("target_uid")))
            for e in edges
            if isinstance(e, dict) and e.get("source_uid") is not None and e.get("target_uid") is not None
        ]
    if current:
        return current
    legacy = manifest.get("edges")
    if not isinstance(legacy, list):
        return []
    return [(str(e.get("source")), str(e.get("target")))
            for e in legacy if isinstance(e, dict) and e.get("source") and e.get("target")]


def dependency_density(manifest: dict[str, Any]) -> dict[str, float]:
    """Per-entry share of the graph it touches, in 0..1."""
    entries = [e for e in manifest.get("entries", []) if isinstance(e, dict)]
    uids = [str(e.get("uid", e.get("id", ""))) for e in entries]
    if not uids:
        return {}
    degree: dict[str, int] = {uid: 0 for uid in uids}
    for source, target in _edges(manifest):
        if source in degree:
            degree[source] += 1
        if target in degree:
            degree[target] += 1
    ceiling = max(1, max(degree.values()))
    return {uid: round(count / ceiling, 4) for uid, count in degree.items()}


def band_for(density: float) -> float:
    factor = DENSITY_BANDS[0][1]
    for threshold, value in DENSITY_BANDS:
        if density >= threshold:
            factor = value
    return factor


def evidence_quality_from_ledger(evidence: dict[str, Any]) -> dict[str, dict[str, Any]]:
    """Reduce existing validated evidence into optional per-UID quality signals."""
    result: dict[str, dict[str, Any]] = {}
    for entry in evidence.get("entries", []):
        if not isinstance(entry, dict):
            continue
        uid = str(entry.get("uid", ""))
        if not uid:
            continue
        values = []
        for claim in entry.get("claims", []):
            if isinstance(claim, dict):
                weighted = claim.get("_worldbuilder_weighted_confidence")
                if isinstance(weighted, (int, float)) and not isinstance(weighted, bool) and 0.0 <= float(weighted) <= 1.0:
                    values.append(float(weighted))
                else:
                    raw = str(claim.get("confidence", "unknown")).lower()
                    values.append(CONFIDENCE_VALUES.get(raw, CONFIDENCE_VALUES["unknown"]))
        confidence = statistics.fmean(values) if values else CONFIDENCE_VALUES["unknown"]
        conflicted = bool(entry.get("conflicts")) or any(
            isinstance(topic, dict) and topic.get("status") == "conflicted"
            for topic in entry.get("topics", []))
        result[uid] = {"confidence": round(float(confidence), 4), "conflicted": conflicted}
    return result


def evidence_risk_scores(evidence_quality: dict[str, dict[str, Any]] | None) -> dict[str, float]:
    if not evidence_quality:
        return {}
    scores: dict[str, float] = {}
    for uid, row in evidence_quality.items():
        if not isinstance(row, dict):
            continue
        try:
            confidence = float(row.get("confidence", 0.5))
        except (TypeError, ValueError):
            confidence = 0.5
        confidence = max(0.0, min(1.0, confidence))
        risk = 1.0 if row.get("conflicted") is True else 1.0 - confidence
        scores[str(uid)] = round(risk, 4)
    return scores


def partition(manifest: dict[str, Any], max_batch: int = 15,
              evidence_quality: dict[str, dict[str, Any]] | None = None) -> dict[str, Any]:
    """Group entries into batches whose size falls as dependency density rises.

    Entries are ordered by density so a batch is internally homogeneous; mixing an
    isolated entry with a hub would size the whole batch for the hub.
    """
    if not 1 <= max_batch <= 50:
        raise_error("max batch size must be between 1 and 50 entries")
    density = dependency_density(manifest)
    if not density:
        return {"batches": [], "entry_count": 0, "max_batch": max_batch}
    evidence_risk = evidence_risk_scores(evidence_quality)
    effective_risk = {uid: max(value, evidence_risk.get(uid, 0.0)) for uid, value in density.items()}

    ordered = sorted(effective_risk.items(), key=lambda kv: (kv[1], kv[0]))
    batches: list[dict[str, Any]] = []
    current: list[str] = []
    current_cap = max_batch

    for uid, value in ordered:
        cap = max(MIN_BATCH, math.floor(max_batch * band_for(value)))
        if current and cap != current_cap:
            batches.append({"uids": current, "size": len(current), "cap": current_cap})
            current, current_cap = [], cap
        current_cap = cap
        current.append(uid)
        if len(current) >= current_cap:
            batches.append({"uids": current, "size": len(current), "cap": current_cap})
            current = []

    if current:
        batches.append({"uids": current, "size": len(current), "cap": current_cap})

    sizes = [b["size"] for b in batches]
    return {
        "kind": "worldbuilder-batch-partition",
        "contract": CONTRACT,
        "entry_count": len(density),
        "max_batch": max_batch,
        "batch_count": len(batches),
        "batches": batches,
        "mean_batch_size": round(statistics.fmean(sizes), 2) if sizes else 0,
        "density_bands": [{"at_or_above": t, "size_factor": f} for t, f in DENSITY_BANDS],
        "evidence_risk_applied": bool(evidence_risk),
        "note": "Batch size falls as dependency density rises; when validated evidence already "
                "exists, low-confidence or conflicted evidence may conservatively shrink the same "
                "batches. Initial generation remains density-only because evidence does not exist yet.",
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Gate telemetry and batch partitioning.")
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("record", help="append one gate attempt")
    p.add_argument("--ledger", required=True)
    p.add_argument("--gate", required=True)
    p.add_argument("--model", required=True)
    p.add_argument("--attempt", type=int, required=True)
    p.add_argument("--outcome", required=True, choices=list(OUTCOMES))
    p.add_argument("--scope")
    p.add_argument("--error-class")
    p.add_argument("--provider")
    p.add_argument("--latency-seconds", type=float)
    p.add_argument("--timed-out", action="store_true", default=None)
    p.add_argument("--work-kind", choices=list(WORK_KINDS))
    p.add_argument("--input-tokens", type=int)
    p.add_argument("--output-tokens", type=int)
    p.add_argument("--cache-read-tokens", type=int)
    p.add_argument("--cache-write-tokens", type=int)

    p = sub.add_parser("report", help="first-attempt pass rate and convergence")
    p.add_argument("--ledger", required=True)

    p = sub.add_parser("partition", help="split entries into density-sized batches")
    p.add_argument("--manifest", required=True)
    p.add_argument("--max-batch", type=int, default=15)
    p.add_argument("--evidence-ledger", help="optional validated evidence JSON for resumed/rework batching")

    p = sub.add_parser("stagger", help="compute bounded child-start spacing from recent telemetry")
    p.add_argument("--ledger", required=True)
    p.add_argument("--provider")
    p.add_argument("--base", type=int, default=STAGGER_BASE_SECONDS)
    p.add_argument("--floor", type=int, default=STAGGER_FLOOR_SECONDS)
    p.add_argument("--ceiling", type=int, default=STAGGER_CEILING_SECONDS)
    p.add_argument("--window", type=int, default=12)

    args = parser.parse_args()
    try:
        if args.command == "record":
            result = record_attempt(
                Path(args.ledger).expanduser().resolve(), gate=args.gate, model=args.model,
                attempt=args.attempt, outcome=args.outcome, scope=args.scope,
                error_class=args.error_class, provider=args.provider,
                latency_seconds=args.latency_seconds, timed_out=args.timed_out,
                work_kind=args.work_kind, input_tokens=args.input_tokens,
                output_tokens=args.output_tokens, cache_read_tokens=args.cache_read_tokens,
                cache_write_tokens=args.cache_write_tokens)
        elif args.command == "report":
            result = report(read_ledger(Path(args.ledger).expanduser().resolve()))
        elif args.command == "partition":
            quality = None
            if args.evidence_ledger:
                quality = evidence_quality_from_ledger(load_json(Path(args.evidence_ledger).expanduser().resolve()))
            result = partition(load_json(Path(args.manifest).expanduser().resolve()),
                               max_batch=args.max_batch, evidence_quality=quality)
        else:
            seconds = recommended_stagger_seconds(
                read_ledger(Path(args.ledger).expanduser().resolve()), provider=args.provider,
                base=args.base, floor=args.floor, ceiling=args.ceiling, window=args.window)
            result = {"kind": "worldbuilder-adaptive-stagger", "contract": CONTRACT,
                      "seconds": seconds, "floor": args.floor, "ceiling": args.ceiling,
                      "provider": args.provider}
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (WorldBuilderError, OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
