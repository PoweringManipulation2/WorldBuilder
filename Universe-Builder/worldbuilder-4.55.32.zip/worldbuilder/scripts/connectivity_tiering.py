#!/usr/bin/env python3
"""Apply connectivity-driven default order/weight tiering to a built book.

Uses the real ground-truth activation graph (content-derived edges) to stamp
default weight floors (world core > high-connectivity hubs > ordinary >
genuine leaves) and type-aware order bands (same semantic type shares one
contiguous order neighborhood, ranked root-first then connectivity tier).
Explicit author-set values and protected weights are never overridden:
connectivity is a floor under keyword-driven relevance, not a replacement
for it. --reassign-orders additionally repairs an existing book's order
scatter to the type-aware bands. See references/entry-settings.md and
DR-122.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

from ground_truth_graph import (
    build_ground_truth_edges,
    apply_connectivity_tier_defaults_in_place,
)
from wb_common import WorldBuilderError, atomic_write_json, iter_entries, load_json

REPORT_KIND = "worldbuilder-connectivity-tiering-report"
REPORT_VERSION = 1


def tier_entries(data: Any, hub_in_degree_threshold: int, *, reassign_orders: bool = False) -> dict[str, Any]:
    refs = [ref for ref in iter_entries(data) if isinstance(ref.entry, dict)]
    entries = [ref.entry for ref in refs]
    if not entries:
        return {
            "kind": REPORT_KIND,
            "report_version": REPORT_VERSION,
            "status": "not_applicable",
            "reason": "no lorebook entries found in the input",
            "entry_count": 0,
        }
    edges = build_ground_truth_edges(entries)
    application = apply_connectivity_tier_defaults_in_place(
        entries, edges, hub_in_degree_threshold=hub_in_degree_threshold, reassign_orders=reassign_orders
    )
    application["kind"] = REPORT_KIND
    application["report_version"] = REPORT_VERSION
    application["status"] = "applied"
    application["entry_count"] = len(entries)
    application["edge_count"] = len(edges)
    return application


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True, help="Built card/lorebook JSON to tier")
    parser.add_argument("--output", help="Write the tiered artifact here (omitted = report only)")
    parser.add_argument("--hub-threshold", type=int, default=2, help="Minimum in-degree for hub tier (default 2)")
    parser.add_argument("--reassign-orders", action="store_true", help="Also recompute existing insertion orders to the type-aware bands (repair mode for an existing book's order scatter)")
    args = parser.parse_args()
    try:
        data = load_json(Path(args.input))
        report = tier_entries(data, args.hub_threshold, reassign_orders=args.reassign_orders)
        rendered = json.dumps(report, ensure_ascii=False, indent=2) + "\n"
        if args.output:
            atomic_write_json(Path(args.output), data)
        sys.stdout.write(rendered)
        return 0
    except (WorldBuilderError, OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
