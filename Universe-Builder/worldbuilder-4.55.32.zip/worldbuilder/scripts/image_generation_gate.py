#!/usr/bin/env python3
"""Batch 10: two gates that must clear before the first image_generate
call: cost confirmation and content safety at prompt construction.

Neither gate is a definitive, automated judgment. Cost confirmation
requires an explicit human decision (WorldBuilder has no pricing table of
its own to compute from: that would be provider plumbing this batch
explicitly declines to build). Content safety flags a structural signal
for review: whether a prompt names a specific, identifiable individual
is a judgment call, not something a name-pattern regex can settle
reliably; the check surfaces the signal, an auditor or the person
decides what it means.
"""
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Any

from wb_common import load_build_state, preflight_report, requirement_rows

_SENTENCE_SPLIT_RE = re.compile(r"(?<=[.!?])\s+")
_STRIP_CHARS = ".,!?;:\"'()[]{}"


def cost_confirmation_gate(
    image_count: int, *, confirmed: bool, per_image_cost_estimate: float | None = None,
) -> dict[str, Any]:
    """Batch 10, decision 3: cost is user-owned (philosophy point 9).
This never computes a price itself: WorldBuilder has no pricing
    table (that is provider plumbing this batch declines to build);
    per_image_cost_estimate, when given, must come from image_generate's
    own reporting, never a guessed or hardcoded figure. confirmed must be
an explicit, separate decision; this function does not treat
    "a cost was computed" as the same thing as "a person agreed to it."
    """
    if image_count <= 0:
        raise ValueError(f"image_count must be positive, got {image_count}")
    total_estimate = None if per_image_cost_estimate is None else round(per_image_cost_estimate * image_count, 4)
    passed = confirmed and image_count > 0
    return {
        "image_count": image_count,
        "per_image_cost_estimate": per_image_cost_estimate,
        "total_cost_estimate": total_estimate,
        "cost_source": "image_generate reporting" if per_image_cost_estimate is not None else "unknown: confirm the count itself with the person",
        "confirmed": confirmed,
        "passed": passed,
        "note": (
            "passed=True means image_count and confirmation are both present; it is not a claim "
            "that the estimated cost is accurate. A missing per_image_cost_estimate must not block "
            "confirmation on cost alone; confirming the IMAGE COUNT explicitly is the floor even when "
            "no price is known yet."
        ),
    }


def prompt_safety_signals(prompt: str) -> dict[str, Any]:
    """Batch 10, decision 4: content rules apply before the prompt
    reaches the provider. Returns structural signals only: a mid-
    sentence, multi-word capitalized sequence (the same proper-noun
    proxy rewording_guards.py uses) that could name a specific,
    identifiable real person. This is a signal for the calling agent or
    an auditor to review, never an automatic pass/fail: a fictional
    character sharing a common name pattern is not a real person, and
    this function cannot tell the difference; it only flags a shape
    worth a human decision.
    """
    candidate_names: set[str] = set()
    for sentence in _SENTENCE_SPLIT_RE.split(prompt or ""):
        words = sentence.split()
        run: list[str] = []
        for index, word in enumerate(words):
            cleaned = word.strip(_STRIP_CHARS)
            is_capitalized = bool(cleaned) and cleaned[0].isupper()
            if index == 0:
                run = []  # sentence-initial capitalization is just grammar, never starts a run
                continue
            if is_capitalized:
                run.append(cleaned)
            else:
                if len(run) >= 2:
                    candidate_names.add(" ".join(run))
                run = []
        if len(run) >= 2:
            candidate_names.add(" ".join(run))
    return {
        "possible_named_individuals": sorted(candidate_names),
        "requires_review": bool(candidate_names),
        "note": (
            "A multi-word capitalized sequence is a structural signal only; it does not confirm a "
            "real, identifiable person is named, and its absence does not confirm one isn't (a single "
            "given name, or a well-known figure referred to descriptively, would not be caught here). "
            "This never blocks automatically; requires_review=True means a human decision is needed "
            "before the prompt reaches image_generate, not that the prompt is rejected."
        ),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--build-state", help="Build-state path for the read-only --requirements preflight.")
    parser.add_argument("--requirements", action="store_true", help="Read-only preflight: print what this gate checks against the current build state.")
    args = parser.parse_args()
    if not args.requirements:
        parser.error("this module has no standalone run mode; use --requirements for the read-only preflight")
    if not args.build_state:
        parser.error("--requirements needs --build-state")
    root, state = load_build_state(args.build_state)
    print(json.dumps(preflight_report("image_generation_gate", requirement_rows(Path(__file__), root, state)), ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
