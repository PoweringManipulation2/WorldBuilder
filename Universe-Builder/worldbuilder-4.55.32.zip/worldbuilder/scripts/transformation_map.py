#!/usr/bin/env python3
"""Compatibility facade for Batch 23 Guided transformation mappings.

WorldBuilder 4.40+ stores transforms as `kind: transform` entries in the
canonical Guided Mode decision log. Existing transformation-map.json files are
migration input only. This facade preserves the old CLI and deterministic
`tm-*` identifiers for callers and receipts.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any, Iterable

from decision_log import (
    LEGACY_CONTRACT as CONTRACT,
    LEGACY_KIND as KIND,
    LEGACY_VERSION as MAP_VERSION,
    decision_id,
    legacy_map_path as transformation_map_path,
    normalized_identity,
    resolve_transform,
    transformation_context,
    list_decisions,
)
from wb_common import WorldBuilderError


def mapping_key(source_concept: str, target_concept: str, transformation_type: str) -> tuple[str, str, str]:
    identity = normalized_identity(
        "transform",
        {
            "source_concept": source_concept,
            "target_concept": target_concept,
            "transformation_type": transformation_type,
            "rationale": "identity-placeholder",
        },
    )
    return identity[1], identity[2], identity[3]


def mapping_id(source_concept: str, target_concept: str, transformation_type: str) -> str:
    return decision_id(
        "transform",
        {
            "source_concept": source_concept,
            "target_concept": target_concept,
            "transformation_type": transformation_type,
            "rationale": "identity-placeholder",
        },
    )


def _mapping_view(row: dict[str, Any]) -> dict[str, Any]:
    return {
        "id": row["id"],
        "source_concept": row["source_concept"],
        "target_concept": row["target_concept"],
        "transformation_type": row["transformation_type"],
        "rationale": row["rationale"],
        "created_at": row["created_at"],
    }


def resolve_mapping(
    build_state: str | Path,
    *,
    source_concept: str,
    target_concept: str,
    transformation_type: str,
    rationale: str | None = None,
) -> dict[str, Any]:
    result = resolve_transform(
        build_state,
        source_concept=source_concept,
        target_concept=target_concept,
        transformation_type=transformation_type,
        rationale=rationale,
    )
    return {
        "status": result["status"],
        "mapping": _mapping_view(result["decision"]),
        "map": result["decision_log"],
        "map_sha256": result["decision_log_sha256"],
        "decision_log": result["decision_log"],
        "decision_log_sha256": result["decision_log_sha256"],
    }


def mapping_context(root: Path, state: dict[str, Any], mapping_ids: Iterable[str]) -> dict[str, Any]:
    return transformation_context(root, state, mapping_ids)


def list_mappings(build_state: str | Path) -> dict[str, Any]:
    result = list_decisions(build_state, kind="transform")
    return {
        "status": result["status"],
        "map": result["decision_log"],
        "map_sha256": result["decision_log_sha256"],
        "decision_log": result["decision_log"],
        "decision_log_sha256": result["decision_log_sha256"],
        "mapping_count": result["decision_count"],
        "mappings": [_mapping_view(row) for row in result["decisions"]],
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--build-state", required=True)
    sub = parser.add_subparsers(dest="command", required=True)
    resolve = sub.add_parser("resolve", help="reuse an existing transform decision or record the first confirmed use")
    resolve.add_argument("--source-concept", required=True)
    resolve.add_argument("--target-concept", required=True)
    resolve.add_argument("--transformation-type", required=True)
    resolve.add_argument("--rationale")
    sub.add_parser("list", help="show recorded transform decisions")
    args = parser.parse_args()
    try:
        if args.command == "resolve":
            result = resolve_mapping(
                args.build_state,
                source_concept=args.source_concept,
                target_concept=args.target_concept,
                transformation_type=args.transformation_type,
                rationale=args.rationale,
            )
        else:
            result = list_mappings(args.build_state)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (WorldBuilderError, OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
