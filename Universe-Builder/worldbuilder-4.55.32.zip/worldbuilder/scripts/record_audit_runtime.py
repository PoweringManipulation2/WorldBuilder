#!/usr/bin/env python3
"""Record parent-observed OpenClaw completion for one WorldBuilder auditor.

Run this only from the parent/orchestrator after OpenClaw reports the named child
session as completed and the expected structured result file exists.  The
result cannot certify itself: audit_gate.py requires this separate, hash-bound
runtime receipt for Compass, Weaver, Scout, and Warden.
"""
from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from dispatch_observation import (
    CHILD_RUN_COMPLETION, CHILD_RUNTIME_PARTIAL_KIND, CHILD_RUNTIME_RECEIPT_KIND,
    PARENT_EXEC_COMPLETION, PARENT_OBSERVED_CHILD_RUN, PARENT_OBSERVED_EXEC, RECORDED_BY_PARENT,
)
from typing import Any

from wb_common import AUDIT_LENSES, WorldBuilderError, atomic_write_json, ensure_inside, load_build_state, load_json, normalize_child_session_id, now_iso, resolve_state_path, sha256_file



# Shared with audit_gate so producer and consumer cannot drift apart. Two literals in
# two files is what stranded every known-property build when the discovery receipt was
# bumped from 3 to 4.
AUDIT_RUNTIME_RECEIPT_VERSION = 2

def parse_iso(value: str, field: str) -> datetime:
    text = value.strip().replace("Z", "+00:00")
    try:
        parsed = datetime.fromisoformat(text)
    except ValueError as exc:
        raise WorldBuilderError(f"{field} must be an ISO-8601 timestamp") from exc
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def timed_out_record_path(runtime_path: Path) -> Path:
    """Sibling path for a timed-out partial record, never the receipt path
    itself. 'Only completed can be receipted' means runtime_receipt's own
    location is written by nothing but a genuine completion."""
    return runtime_path.with_name(runtime_path.stem + ".timed_out.json")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--build-state", required=True)
    parser.add_argument("--stage", required=True, choices=["pre-generation", "post-generation"])
    parser.add_argument("--lens", required=True, choices=list(AUDIT_LENSES))
    parser.add_argument("--child-session-id", required=True)
    parser.add_argument("--run-id", required=True, help="Run ID returned by sessions_spawn")
    parser.add_argument("--runtime-event-id", required=True, help="Stable idempotency/event ID from the OpenClaw completion handoff")
    parser.add_argument("--status", required=True, choices=["completed", "failed", "timed_out"])
    parser.add_argument("--spawned-at", required=True, help="Parent-observed ISO timestamp for sessions_spawn")
    parser.add_argument("--completed-at", help="Parent-observed ISO completion timestamp")
    parser.add_argument("--parent-session-id", required=True, help="Parent OpenClaw session identifier")
    args = parser.parse_args()
    try:
        if args.status == "timed_out":
            for field, value in (("child_session_id", args.child_session_id), ("run_id", args.run_id), ("runtime_event_id", args.runtime_event_id)):
                if not value.strip() or len(value.strip()) < 4:
                    raise WorldBuilderError(f"{field} is missing or implausibly short")
            if not args.parent_session_id.strip() or len(args.parent_session_id.strip()) < 4:
                raise WorldBuilderError("parent_session_id is missing or implausibly short")
            if normalize_child_session_id(args.parent_session_id) == normalize_child_session_id(args.child_session_id):
                raise WorldBuilderError("parent_session_id must differ from child_session_id")
            spawned = parse_iso(args.spawned_at, "spawned_at")
            observed = parse_iso(args.completed_at or now_iso(), "completed_at")
            if observed < spawned:
                raise WorldBuilderError("completed_at precedes spawned_at")

            state_path = Path(args.build_state).resolve()
            root, state = load_build_state(state_path)
            plan_key = "pre_generation_audit_plan" if args.stage == "pre-generation" else "post_generation_audit_plan"
            plan_path = resolve_state_path(root, state, plan_key)
            plan = load_json(plan_path)
            if not isinstance(plan, dict) or plan.get("kind") != "worldbuilder-audit-plan":
                raise WorldBuilderError("audit plan is missing or invalid")
            row = next((item for item in plan.get("assignments", []) if isinstance(item, dict) and item.get("lens") == args.lens), None)
            if row is None:
                raise WorldBuilderError(f"audit plan has no {args.lens} assignment")
            assignment_path = (root / str(row.get("assignment"))).resolve()
            ensure_inside(assignment_path, resolve_state_path(root, state, "audit_assignments"))
            if not assignment_path.exists() or sha256_file(assignment_path) != row.get("assignment_sha256"):
                raise WorldBuilderError("audit assignment changed after planning")
            assignment = load_json(assignment_path)
            if not isinstance(assignment, dict) or assignment.get("lens") != args.lens:
                raise WorldBuilderError("audit assignment lens mismatch")
            runtime_path = (root / str(assignment.get("runtime_receipt"))).resolve()
            ensure_inside(runtime_path, resolve_state_path(root, state, "audit_runtime"))
            if runtime_path.exists():
                raise WorldBuilderError("a completion receipt already exists for this assignment; a timeout cannot follow a completion")
            partial_path = timed_out_record_path(runtime_path)
            record: dict[str, Any] = {
                "kind": CHILD_RUNTIME_PARTIAL_KIND,
                "status": "timed_out",
                "runtime_source": PARENT_OBSERVED_CHILD_RUN,
                "recorded_by": RECORDED_BY_PARENT,
                "build_id": assignment.get("build_id"),
                "audit_run_id": assignment.get("audit_run_id"),
                "assignment_id": assignment.get("assignment_id"),
                "assignment_sha256": sha256_file(assignment_path),
                "lens": assignment.get("lens"),
                "auditor": assignment.get("auditor"),
                "taskName": assignment.get("taskName"),
                "child_session_id": args.child_session_id,
                "run_id": args.run_id,
                "runtime_event_id": args.runtime_event_id,
                "parent_session_id": args.parent_session_id,
                "spawned_at": spawned.isoformat().replace("+00:00", "Z"),
                "observed_at": observed.isoformat().replace("+00:00", "Z"),
                "elapsed_seconds": int((observed - spawned).total_seconds()),
                "note": "Not a receipt. Re-dispatch this lens with a longer run_timeout_seconds.",
            }
            atomic_write_json(partial_path, record)
            print(json.dumps({
                "status": "timed_out_recorded",
                "partial_record": str(partial_path),
                "assignment_id": assignment.get("assignment_id"),
                "lens": assignment.get("lens"),
                "elapsed_seconds": record["elapsed_seconds"],
            }, indent=2))
            return 0

        if args.status != "completed":
            raise WorldBuilderError(f"auditor runtime status is {args.status!r}; only completed can be receipted")
        for field, value in (("child_session_id", args.child_session_id), ("run_id", args.run_id), ("runtime_event_id", args.runtime_event_id)):
            if not value.strip() or len(value.strip()) < 4:
                raise WorldBuilderError(f"{field} is missing or implausibly short")
        if not args.parent_session_id.strip() or len(args.parent_session_id.strip()) < 4:
            raise WorldBuilderError("parent_session_id is missing or implausibly short")
        if normalize_child_session_id(args.parent_session_id) == normalize_child_session_id(args.child_session_id):
            raise WorldBuilderError("parent_session_id must differ from child_session_id")
        spawned = parse_iso(args.spawned_at, "spawned_at")
        completed_text = args.completed_at or now_iso()
        completed = parse_iso(completed_text, "completed_at")
        if completed < spawned:
            raise WorldBuilderError("completed_at precedes spawned_at")
        state_path = Path(args.build_state).resolve()
        root, state = load_build_state(state_path)
        plan_key = "pre_generation_audit_plan" if args.stage == "pre-generation" else "post_generation_audit_plan"
        plan_path = resolve_state_path(root, state, plan_key)
        plan = load_json(plan_path)
        if not isinstance(plan, dict) or plan.get("kind") != "worldbuilder-audit-plan":
            raise WorldBuilderError("audit plan is missing or invalid")
        row = next((item for item in plan.get("assignments", []) if isinstance(item, dict) and item.get("lens") == args.lens), None)
        if row is None:
            raise WorldBuilderError(f"audit plan has no {args.lens} assignment")
        assignment_path = (root / str(row.get("assignment"))).resolve()
        ensure_inside(assignment_path, resolve_state_path(root, state, "audit_assignments"))
        if not assignment_path.exists() or sha256_file(assignment_path) != row.get("assignment_sha256"):
            raise WorldBuilderError("audit assignment changed after planning")
        assignment = load_json(assignment_path)
        if not isinstance(assignment, dict) or assignment.get("lens") != args.lens:
            raise WorldBuilderError("audit assignment lens mismatch")
        result_path = (root / str(assignment.get("output"))).resolve()
        ensure_inside(result_path, resolve_state_path(root, state, "findings"))
        if not result_path.exists():
            raise WorldBuilderError("auditor result does not exist")
        result = load_json(result_path)
        meta = result.get("_worldbuilder") if isinstance(result, dict) else None
        if not isinstance(meta, dict):
            raise WorldBuilderError("auditor result lacks _worldbuilder metadata")
        echoed_child = meta.get("child_session_id")
        if echoed_child not in (None, "") and normalize_child_session_id(echoed_child) != normalize_child_session_id(args.child_session_id):
            raise WorldBuilderError("parent-observed child session ID does not match auditor result")
        if meta.get("runtime_status") != "completed" or meta.get("completed") is not True:
            raise WorldBuilderError("auditor result does not declare completed runtime status")
        runtime_path = (root / str(assignment.get("runtime_receipt"))).resolve()
        ensure_inside(runtime_path, resolve_state_path(root, state, "audit_runtime"))
        receipt: dict[str, Any] = {
            "kind": CHILD_RUNTIME_RECEIPT_KIND,
            "receipt_version": AUDIT_RUNTIME_RECEIPT_VERSION,
            "runtime_source": PARENT_OBSERVED_CHILD_RUN,
            "source": CHILD_RUN_COMPLETION,
            "recorded_by": RECORDED_BY_PARENT,
            "build_id": assignment.get("build_id"),
            "audit_run_id": assignment.get("audit_run_id"),
            "assignment_id": assignment.get("assignment_id"),
            "assignment_sha256": sha256_file(assignment_path),
            "lens": assignment.get("lens"),
            "auditor": assignment.get("auditor"),
            "taskName": assignment.get("taskName"),
            "status": "completed",
            "child_session_id": args.child_session_id,
            "run_id": args.run_id,
            "runtime_event_id": args.runtime_event_id,
            "parent_session_id": args.parent_session_id,
            "spawned_at": spawned.isoformat().replace("+00:00", "Z"),
            "completed_at": completed.isoformat().replace("+00:00", "Z"),
            "result": assignment.get("output"),
            "result_sha256": sha256_file(result_path),
            "terminal_delimiter": assignment.get("expected_end_delimiter"),
        }
        atomic_write_json(runtime_path, receipt)
        print(json.dumps({"status": "recorded", "runtime_receipt": str(runtime_path), "child_session_id": args.child_session_id}, indent=2))
        return 0
    except (WorldBuilderError, OSError, json.JSONDecodeError, ValueError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
