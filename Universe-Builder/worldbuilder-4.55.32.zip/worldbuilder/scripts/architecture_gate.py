#!/usr/bin/env python3
"""Validate WorldBuilder's era-isolation and canonical-character architecture.

This gate is intentionally narrower than ``validate_output.py``. It checks the
content systems that are easy for a model to simplify incorrectly:

* canonical character section routing;
* World/Lorebook/Group root-control architecture;
* multi-era plan approval and keyword isolation;
* era-context negative-space blocks;
* era-filtered entity activation; and
* obvious future-event leakage into earlier-era entries.

The planning stage validates ``manifest.json`` plus ``era-plan.json``. The output
stage validates the generated artifact against those frozen planning records.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any, Iterable

from card_shell_contract import CONTRACT as CARD_SHELL_CONTRACT, validate_plan as validate_card_shell_plan
from activation_map_gate import load_registry_profile
from activation_semantics import profile_defaults as _profile_defaults, setting as _setting
from character_contract import (
    CONTRACT as CHARACTER_SYSTEM_CONTRACT,
    load_bound_plan as load_character_plan,
)
from era_router_contract import (
    CONTRACT as ERA_ROUTER_CONTRACT,
    load_bound_plan as load_era_router_plan,
    validate_manifest_router,
    validate_output as validate_era_router_output,
    validate_plan as validate_era_router_plan,
)
from era_root_contract import load_era_root_plan, load_valid_era_ids
from wb_common import (
    ErrorCollector,
    WorldBuilderError,
    atomic_write_json,
    canonical_entry_identity,
    detect_artifact,
    step_driver_pointer,
    iter_entries,
    load_build_state,
    load_json,
    preflight_report,
    requirement_rows,
    resolve_state_path,
    sha256_file,
)

CONTRACT = "worldbuilder-content-architecture-v1"
CHARACTER_FORMAT = "canonical-v1"
LORE_CHARACTER_SECTIONS = (
    "TIMELINE",
    "VITALS",
    "PERSONALITY & VOICE",
    "CONNECTIONS",
    "APPEARANCE",
    "BACKSTORY",
    "CURRENT",
)
STAR_DESCRIPTION_SECTIONS = (
    "TIMELINE",
    "VITALS",
    "CONNECTIONS",
    "APPEARANCE",
    "BACKSTORY",
    "CURRENT",
)
ERA_CONTEXT_SECTIONS = (
    "CURRENT ERA",
    "WORLD STATE THIS ERA",
    "ACTIVE FACTIONS THIS ERA",
    "ACTIVE CHARACTERS THIS ERA",
    "ACTIVE LOCATIONS THIS ERA",
    "WHAT HAS NOT HAPPENED YET",
    "WHAT IS ALREADY PAST",
)
ERA_CONTEXT_SECTIONS_V2 = ERA_CONTEXT_SECTIONS + ("KNOWLEDGE LIMITS THIS ERA",)


def _entries(manifest: dict[str, Any]) -> list[dict[str, Any]]:
    value = manifest.get("entries")
    problems = ErrorCollector()
    if not isinstance(value, list):
        problems.add(f"manifest.entries must be a list for the content-architecture contract, found {type(value).__name__}")
        problems.raise_if_any()
    if not value:
        problems.add("manifest.entries is empty: author at least one entry before this contract can be checked")
    terrible = [type(row).__name__ for row in value if not isinstance(row, dict)]
    if terrible:
        problems.add(f"every manifest entry must be a JSON object; found non-object entries: {terrible}")
    problems.raise_if_any()
    return value


def _manifest_arch(manifest: dict[str, Any]) -> dict[str, Any]:
    value = manifest.get("architecture")
    problems = ErrorCollector()
    if not isinstance(value, dict):
        problems.add(f"manifest has no 'architecture' object, found {type(value).__name__}")
        problems.raise_if_any()
    if value.get("contract") != CONTRACT:
        problems.add(f"manifest architecture.contract is {value.get('contract')!r}, must be {CONTRACT!r}")
    if value.get("character_format") != CHARACTER_FORMAT:
        problems.add(f"manifest architecture.character_format is {value.get('character_format')!r}, must be {CHARACTER_FORMAT!r}")
    era = value.get("era")
    if not isinstance(era, dict):
        problems.add(f"manifest architecture.era.mode must be 'single' or 'multi', found {type(era).__name__!r}")
    else:
        if era.get("mode") not in {"single", "multi"}:
            problems.add(f"manifest architecture.era.mode must be 'single' or 'multi', found {era.get('mode')!r}")
        if era.get("isolation") not in {"strict", "balanced"}:
            problems.add(f"manifest architecture.era.isolation must be 'strict' or 'balanced', found {era.get('isolation')!r}")
    problems.raise_if_any()
    return value


def _entry_arch(entry: dict[str, Any]) -> dict[str, Any]:
    value = entry.get("architecture")
    return value if isinstance(value, dict) else {}


def _emit(entry: dict[str, Any]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key in ("settings", "emit"):
        value = entry.get(key)
        if isinstance(value, dict):
            result.update(value)
    for key in (
        "keys", "key", "secondary_keys", "keysecondary", "constant", "selective",
        "selectiveLogic", "position", "insertion_order", "order", "enabled", "disable",
        "extensions", "prevent_recursion", "preventRecursion",
    ):
        if key in entry:
            result[key] = entry[key]
    return result


def _bool_setting(settings: dict[str, Any], *names: str, default: bool = False) -> bool:
    for name in names:
        if name in settings:
            return bool(settings[name])
    ext = settings.get("extensions")
    if isinstance(ext, dict):
        for name in names:
            if name in ext:
                return bool(ext[name])
    return default


def _list_setting(settings: dict[str, Any], *names: str) -> list[str]:
    for name in names:
        value = settings.get(name)
        if isinstance(value, list):
            return [str(item).strip() for item in value if str(item).strip()]
    return []


def _position(settings: dict[str, Any]) -> Any:
    if "position" in settings:
        return settings["position"]
    ext = settings.get("extensions")
    return ext.get("position") if isinstance(ext, dict) else None


def _prevent_recursion(settings: dict[str, Any]) -> bool:
    return _bool_setting(settings, "prevent_recursion", "preventRecursion")


def _match_scenario(settings: dict[str, Any]) -> bool:
    return _bool_setting(settings, "match_scenario", "matchScenario")


def _selective_logic(settings: dict[str, Any]) -> Any:
    if "selectiveLogic" in settings:
        return settings["selectiveLogic"]
    ext = settings.get("extensions")
    if isinstance(ext, dict):
        return ext.get("selectiveLogic", ext.get("selective_logic"))
    return None


def _identity(entry: dict[str, Any]) -> str:
    value = entry.get("uid", entry.get("id", entry.get("name", "?")))
    return str(value)



def load_card_shell_plan(root: Path, state: dict[str, Any], manifest: dict[str, Any]) -> tuple[dict[str, Any] | None, Path | None]:
    paths = state.get("paths") if isinstance(state.get("paths"), dict) else {}
    state_contract = str(state.get("content_architecture", {}).get("card_shell_contract", ""))
    if "card_shell_plan" not in paths and not state_contract:
        return None, None
    problems = ErrorCollector()
    path = resolve_state_path(root, state, "card_shell_plan")
    if not path.exists():
        problems.add(f"card-shell plan does not exist at {path}: author it before this contract can be checked")
        problems.raise_if_any()
    plan = load_json(path)
    if not isinstance(plan, dict):
        problems.add(f"{path.name} must be a JSON object, found {type(plan).__name__}")
        problems.raise_if_any()
    try:
        validate_card_shell_plan(plan, expected_build_id=str(state.get("build_id", "")))
    except WorldBuilderError as exc:
        problems.add(str(exc))
    if state_contract and state_contract != CARD_SHELL_CONTRACT:
        problems.add(f"build-state's content_architecture.card_shell_contract is {state_contract!r}, which this gate does not support (expects {CARD_SHELL_CONTRACT!r})")
    expected_sha = manifest.get("card_shell_plan_sha256")
    actual_sha = sha256_file(path)
    if expected_sha != actual_sha:
        problems.add(f"manifest's card_shell_plan_sha256 ({expected_sha!r}) does not match {path.name}'s actual current hash ({actual_sha!r}): the manifest was authored against a different version of the plan")
    manifest_arch = manifest.get("architecture")
    card_shell = manifest_arch.get("card_shell") if isinstance(manifest_arch, dict) else None
    if not isinstance(card_shell, dict) or card_shell.get("contract") != CARD_SHELL_CONTRACT:
        problems.add(f"manifest architecture.card_shell must be an object with contract={CARD_SHELL_CONTRACT!r}, found {card_shell!r}")
    elif card_shell.get("plan_sha256") != expected_sha:
        problems.add(f"manifest architecture.card_shell.plan_sha256 ({card_shell.get('plan_sha256')!r}) does not match manifest.card_shell_plan_sha256 ({expected_sha!r}): these two bindings have diverged")
    problems.raise_if_any()
    return plan, path


def _normalized_blocks(value: str, minimum: int) -> set[str]:
    blocks: set[str] = set()
    for block in re.split(r"\n\s*\n|(?<=[.!?])\s+", value):
        normalized = re.sub(r"\s+", " ", block).strip().casefold()
        if len(normalized) >= minimum:
            blocks.add(normalized)
    return blocks


def _duplicate_blocks(left: str, right: str, minimum: int) -> list[str]:
    return sorted(_normalized_blocks(left, minimum).intersection(_normalized_blocks(right, minimum)))


def _validate_policy_field(payload: dict[str, Any], field: str, policy: str, fixed_text: str = "") -> None:
    problems = ErrorCollector()
    value = payload.get(field)
    text = value if isinstance(value, str) else ""
    if policy == "none" and text.strip():
        problems.add(f"card-shell plan requires {field} to be blank (policy is 'none'), but found: {text.strip()[:80]!r}")
    if policy == "custom" and not text.strip():
        problems.add(f"card-shell plan's policy for {field!r} is 'custom', so {field} must have non-empty content, but it is blank")
    if fixed_text and text.strip() != fixed_text.strip():
        problems.add(f"output {field} ({text.strip()[:80]!r}) does not match the explicitly approved fixed text ({fixed_text.strip()[:80]!r})")
    problems.raise_if_any()


def validate_card_shell_output(state: dict[str, Any], plan: dict[str, Any], data: dict[str, Any]) -> dict[str, Any]:
    artifact_type = str(state.get("artifact", {}).get("type", ""))
    info = detect_artifact(data)
    if info.kind not in {"card_v3", "card_v3_embedded"} or artifact_type not in {"world", "card", "group"}:
        return {"card_shell_applicable": False, "card_shell_warnings": []}
    problems = ErrorCollector()
    payload = data.get("data")
    if not isinstance(payload, dict):
        problems.add(f"card-shell output's 'data' must be a JSON object, found {type(payload).__name__}")
        problems.add("dependent checks skipped: card-shell field checks (no usable data object)")
        problems.raise_if_any()
    choices = plan["choices"]
    validation = plan["validation"]
    warnings: list[str] = []
    for field in ("name", "description", "personality", "scenario", "first_mes", "mes_example", "creator_notes", "system_prompt", "post_history_instructions"):
        if not isinstance(payload.get(field), str):
            problems.add(f"card-shell field {field!r} must be a string, found {type(payload.get(field)).__name__}")
    if not str(payload.get("name", "")).strip():
        problems.add("card-shell 'name' must not be empty")
    if validation.get("require_first_message") and not str(payload.get("first_mes", "")).strip():
        problems.add("card-shell plan requires a non-empty first_mes, but found none")
    if validation.get("require_creator_notes") and not str(payload.get("creator_notes", "")).strip():
        problems.add("card-shell plan requires human-facing creator_notes, but found none")
    if validation.get("require_creator_notes"):
        book = payload.get("character_book")
        if isinstance(book, dict) and isinstance(book.get("entries"), list) and book["entries"]:
            from creator_notes_stats import verify_notes_block
            for problem in verify_notes_block(payload):
                if str(choices.get("creator_notes_policy", "automatic")) == "automatic":
                    problems.add(problem)
                else:
                    warnings.append(problem)
    scenario_policy = str(choices.get("scenario_policy"))
    scenario = str(payload.get("scenario", ""))
    if scenario_policy == "blank" and scenario.strip():
        problems.add(f"card-shell plan's scenario_policy is 'blank', so scenario must be empty unless a fixed premise was approved, but found: {scenario.strip()[:80]!r}")
    if scenario_policy == "fixed":
        try:
            _validate_policy_field(payload, "scenario", "custom", str(plan.get("fixed_scenario", {}).get("text", "")))
        except WorldBuilderError as exc:
            problems.add(str(exc))
    if validation.get("require_personality_blank") and str(payload.get("personality", "")).strip():
        problems.add(f"World card Personality must remain blank, but found: {str(payload.get('personality', '')).strip()[:80]!r}")
    greeting_minimum = int(validation.get("alternate_greetings_minimum", 0) or 0)
    greetings = payload.get("alternate_greetings")
    if not isinstance(greetings, list) or any(not isinstance(item, str) for item in greetings):
        problems.add(f"alternate_greetings must be a list of strings, found {greetings!r}")
    elif len([item for item in greetings if item.strip()]) < greeting_minimum:
        problems.add(f"greeting policy requires at least {greeting_minimum} useful alternate greeting(s), found {len([item for item in greetings if item.strip()])}")
    dialogue_policy = str(choices.get("dialogue_policy"))
    examples = str(payload.get("mes_example", ""))
    if dialogue_policy == "none" and examples.strip():
        problems.add(f"dialogue_policy is 'none', so mes_example must be empty, but found: {examples.strip()[:80]!r}")
    if validation.get("require_character_examples"):
        if not examples.strip():
            problems.add("this character card requires dialogue examples under the selected dialogue_policy, but mes_example is empty")
        if "<START>" not in examples:
            problems.add("character dialogue examples must use the <START> delimiter between exchanges")
    try:
        _validate_policy_field(payload, "system_prompt", str(choices.get("system_prompt_policy")))
    except WorldBuilderError as exc:
        problems.add(str(exc))
    try:
        _validate_policy_field(payload, "post_history_instructions", str(choices.get("post_history_policy")))
    except WorldBuilderError as exc:
        problems.add(str(exc))
    if artifact_type == "world":
        kernel = plan.get("fallback_kernel") if isinstance(plan.get("fallback_kernel"), dict) else {}
        if kernel.get("required"):
            fields = kernel.get("fields") if isinstance(kernel.get("fields"), list) else []
            combined = "\n".join(str(payload.get(field, "")) for field in fields).strip()
            minimum = int(kernel.get("minimum_chars", 80) or 80)
            maximum = int(kernel.get("maximum_chars", 1600) or 1600)
            if len(combined) < minimum:
                problems.add(f"this world card's fallback behavior kernel ({', '.join(fields)}) is {len(combined)} characters, below the required minimum of {minimum}")
            if len(combined) > maximum:
                problems.add(f"this world card's fallback behavior kernel ({', '.join(fields)}) is {len(combined)} characters, over its compact limit of {maximum}")
    minimum = int(validation.get("duplication_min_chars", 80) or 80)
    duplicates = _duplicate_blocks(str(payload.get("description", "")), str(payload.get("personality", "")), minimum)
    if duplicates:
        problems.add(f"description and personality duplicate substantial permanent-prompt prose: {len(duplicates)} block(s) of >= {minimum} chars each; state each fact once, in whichever field owns it")
    permanent = sum(len(str(payload.get(field, ""))) for field in ("description", "personality", "scenario", "system_prompt", "post_history_instructions"))
    hard = int(validation.get("permanent_prompt_hard_limit_chars", 30000) or 30000)
    soft = int(validation.get("permanent_prompt_soft_limit_chars", 16000) or 16000)
    if permanent > hard:
        problems.add(f"permanent card-shell prompt cost exceeds hard limit ({permanent}>{hard} characters): trim description/personality/scenario/system_prompt/post_history_instructions")
    if permanent > soft:
        warnings.append(f"permanent card-shell prompt cost exceeds soft limit ({permanent}>{soft} characters)")
    description = str(payload.get("description", ""))
    description_soft = int(validation.get("description_soft_limit_chars", 0) or 0)
    if description_soft and len(description) > description_soft:
        warnings.append(f"Description exceeds its soft compactness target ({len(description)}>{description_soft} characters)")
    if artifact_type == "world":
        if not description.strip():
            problems.add("this world card's description is empty: it must contain a compact world core (setting, tone, stakes), not be left blank")
        template_match = re.search(r"(?im)^\s*(?:TIMELINE|VITALS|PERSONALITY\s*&\s*VOICE|CONNECTIONS|APPEARANCE|BACKSTORY|CURRENT)\s*:", description)
        if template_match:
            problems.add(f"this world card's description contains a character-template section header ({template_match.group(0).strip()!r}), which belongs on a character entry instead; a World description should be a compact world core only")
    problems.raise_if_any()
    return {
        "card_shell_applicable": True,
        "card_shell_warnings": warnings,
        "permanent_prompt_chars": permanent,
        "alternate_greetings": len([item for item in greetings if item.strip()]),
    }


def load_era_plan(root: Path, state: dict[str, Any], manifest: dict[str, Any]) -> tuple[dict[str, Any], Path]:
    plan, path, _detail = load_era_router_plan(root, state, manifest, required=True)
    assert plan is not None and path is not None
    return plan, path


def validate_era_plan(plan: dict[str, Any]) -> None:
    validate_era_router_plan(plan)

def validate_character_manifest_entry(entry: dict[str, Any]) -> None:
    problems = ErrorCollector()
    arch = _entry_arch(entry)
    if arch.get("character_format") != CHARACTER_FORMAT:
        problems.add(f"character entry {_identity(entry)}'s architecture.character_format is {arch.get('character_format')!r}, must be {CHARACTER_FORMAT!r}")
    role = arch.get("character_role", "lorebook_character")
    required = arch.get("required_sections")
    expected = list(STAR_DESCRIPTION_SECTIONS if role == "card_star" else LORE_CHARACTER_SECTIONS)
    if required != expected:
        problems.add(f"character entry {_identity(entry)}'s required_sections is {required!r}, but role {role!r} requires exactly {expected!r} in that order")
    if not str(arch.get("character_id", "")).strip() or not str(arch.get("character_state_id", "")).strip():
        problems.add(f"character entry {_identity(entry)} needs non-empty character_id ({arch.get('character_id')!r}) and character_state_id ({arch.get('character_state_id')!r})")
    if arch.get("identity_model") != "structured-v1" or arch.get("behavior_model") != "structured-v1":
        problems.add(f"character entry {_identity(entry)}'s identity_model ({arch.get('identity_model')!r}) and behavior_model ({arch.get('behavior_model')!r}) must both be 'structured-v1'")
    problems.raise_if_any()


def validate_planning_architecture(root: Path, state: dict[str, Any], manifest: dict[str, Any]) -> dict[str, Any]:
    problems = ErrorCollector()
    architecture: dict[str, Any] | None = None
    try:
        architecture = _manifest_arch(manifest)
    except WorldBuilderError as exc:
        problems.add(str(exc))
    entries: list[dict[str, Any]] | None = None
    try:
        entries = _entries(manifest)
    except WorldBuilderError as exc:
        problems.add(str(exc))
    if architecture is None or entries is None:
        problems.add(
            "dependent checks skipped: planning architecture checks (a usable manifest.architecture object and a usable manifest.entries list are required)"
        )
        problems.raise_if_any()
    era_cfg = architecture["era"]
    mode = era_cfg["mode"]
    # root_toggle became the multi-era default in 4.0, but this gate only ever
    # implemented the Scenario shape: it demanded match_scenario and forbade constant,
    # which every era root violates by definition. A build on the documented default
    # could not pass planning. Branch on the routing the manifest declares.
    era_routing = str(era_cfg.get("routing", "scenario"))
    routing_ok = era_routing in {"scenario", "root_toggle"}
    if not routing_ok:
        problems.add(f"manifest architecture.era.routing must be 'scenario' or 'root_toggle', got {era_routing!r}")
    artifact_type = str(state.get("artifact", {}).get("type", ""))
    card_shell_plan: dict[str, Any] | None = None
    card_shell_path: Path | None = None
    try:
        card_shell_plan, card_shell_path = load_card_shell_plan(root, state, manifest)
    except WorldBuilderError as exc:
        problems.add(str(exc))
    plan: dict[str, Any] | None = None
    era_path: Path | None = None
    era_keywords: dict[str, set[str]] = {}
    era_order: dict[str, int] = {}
    era_tokens: dict[str, str] = {}
    router_detail: dict[str, Any] = {}
    era_plan_ok = True
    if mode == "multi" and era_routing == "scenario":
        try:
            plan, era_path = load_era_plan(root, state, manifest)
            router_detail = validate_manifest_router(plan, manifest)
        except WorldBuilderError as exc:
            problems.add(str(exc))
            era_plan_ok = False
        else:
            for row in plan["eras"]:
                era_keywords[str(row["id"])] = {str(k).strip().casefold() for k in row["keywords"] if str(k).strip()}
                era_order[str(row["id"])] = int(row["order"])
    valid_era_ids: set[str] = set()
    era_ids_ok = True
    if mode == "multi":
        if not routing_ok:
            era_ids_ok = False
        elif era_routing == "root_toggle":
            # Root_toggle's real source of valid era IDs is the era-root
            # plan, not era_keywords: era_keywords stays empty for this
            # routing by design (the DR-083-shaped fix), so any downstream
            # check validating era references needs this instead, not a
            # requirement to leave those checks unenforced for this routing.
            try:
                valid_era_ids = load_valid_era_ids(root, state, manifest)
                # Batch 50 completion: era event-reach validation reads
                # era_order, which scenario routing fills from the era plan.
                # Root_toggle builds carry their order values in the era-root
                # plan instead; without this, every event-scope entry failed
                # with "not one of the era-plan's own era IDs: []".
                era_root_plan, _era_root_path = load_era_root_plan(root, state, manifest)
            except WorldBuilderError as exc:
                problems.add(str(exc))
                era_ids_ok = False
            else:
                for era_row in era_root_plan.get("eras", []):
                    if isinstance(era_row, dict) and era_row.get("id") is not None and isinstance(era_row.get("order"), int) and not isinstance(era_row.get("order"), bool):
                        era_order[str(era_row["id"])] = int(era_row["order"])
                for era_row in era_root_plan.get("eras", []):
                    if isinstance(era_row, dict) and era_row.get("id") is not None and era_row.get("token"):
                        era_tokens[str(era_row["id"])] = str(era_row["token"])
        elif era_plan_ok:
            valid_era_ids = set(era_keywords)
        else:
            era_ids_ok = False
    lore_bearing = artifact_type in {"world", "lorebook", "group"} or bool(architecture.get("lorebook_bearing"))
    root_entries = [row for row in entries if _entry_arch(row).get("layer") in {"world_core", "world_invariants"}]
    if lore_bearing:
        if len(root_entries) != 1:
            problems.add(f"lore-bearing builds require exactly one world_core/world_invariants root entry, found {len(root_entries)}: {[_identity(row) for row in root_entries]}")
            problems.add("dependent checks skipped: root world-entry settings checks (requires exactly one root entry)")
        else:
            settings = _emit(root_entries[0])
            try:
                _registry, _registry_path, profile, _profile_path = load_registry_profile(root, state)
                defaults = _profile_defaults(profile, str(_entry_arch(root_entries[0]).get("layer", "")))
                constant = bool(_setting(settings, ("constant",), defaults.get("constant", False)))
                prevent_recursion = bool(_setting(settings, ("prevent_recursion", "preventRecursion"), defaults.get("prevent_recursion", False)))
                if not constant or not prevent_recursion:
                    problems.add(f"root world entry {_identity(root_entries[0])} must be constant (found {constant}) and prevent recursion (found {prevent_recursion})")
            except WorldBuilderError as exc:
                problems.add(str(exc))
            expected_layer = "world_invariants" if mode == "multi" else "world_core"
            if _entry_arch(root_entries[0]).get("layer") != expected_layer:
                problems.add(f"{mode}-era lore-bearing build requires root layer {expected_layer}")

    # Batch 61: index cardinality is per era, not per build. DR-129 gives a
    # multi-era build one index per era, each owning exactly one era id and
    # gated on that era's own token; world_index.validate owns that rule, so
    # planning, delivery, and the standalone CLI cannot drift apart. A routing
    # with no era token (single-era, legacy scenario) keeps the single-index
    # shape it had.
    index_entries = [row for row in entries if _entry_arch(row).get("layer") == "world_index"]
    if index_entries:
        from world_index import validate as _validate_world_index

        try:
            index_report = _validate_world_index(
                index_entries,
                era_mode=mode if era_tokens else "single",
                era_tokens=era_tokens,
            )
        except WorldBuilderError as exc:
            problems.add(f"world index: {exc}")
        else:
            for problem in index_report.get("errors", []):
                problems.add(f"world index: {problem}")

    character_rows = [row for row in entries if str(row.get("type", "")).casefold() == "character"]
    for row in character_rows:
        try:
            validate_character_manifest_entry(row)
        except WorldBuilderError as exc:
            problems.add(str(exc))
    character_plan: dict[str, Any] | None = None
    character_path: Path | None = None
    character_detail: dict[str, Any] = {}
    if mode == "multi" and not era_ids_ok:
        problems.add("dependent checks skipped: character plan checks (era IDs are unavailable)")
    else:
        try:
            character_plan, character_path, character_detail = load_character_plan(
                root,
                state,
                manifest,
                required=bool(character_rows),
                era_ids=valid_era_ids if mode == "multi" else None,
            )
        except WorldBuilderError as exc:
            problems.add(str(exc))

    if mode == "multi":
        multi_ok = routing_ok and era_ids_ok
        if not multi_ok:
            problems.add(
                "dependent checks skipped: era-context, era-scoped, and split-entity planning checks (a valid routing and loadable era data are required)"
            )
        contexts = [] if not multi_ok else [row for row in entries if _entry_arch(row).get("layer") == "era_context"]
        context_by_era: dict[str, dict[str, Any]] = {}
        for row in contexts:
            era_ids = _entry_arch(row).get("era_ids")
            if not isinstance(era_ids, list) or len(era_ids) != 1:
                problems.add(f"era_context entry {_identity(row)} must own exactly one era_id, found {era_ids!r}")
                problems.add(
                    f"dependent checks skipped: era_context entry {_identity(row)} layout and keyword checks (the era_id is missing or malformed)"
                )
                continue
            era_id = str(era_ids[0])
            if era_id in context_by_era:
                problems.add(f"duplicate era_context for {era_id}")
            context_by_era[era_id] = row
            settings = _emit(row)
            keys = {k.casefold() for k in _list_setting(settings, "keys", "key")}
            if era_routing == "scenario" and not keys.intersection(era_keywords.get(era_id, set())):
                problems.add(f"era_context {era_id} keys do not include its era-plan keywords")
            if era_routing == "root_toggle":
                # Under root_toggle the era context sits at cascade level 1: it is
                # token-gated (therefore selective) and recursion-delayed, not
                # Scenario-matched. Requiring the Scenario shape here rejected the
                # documented default.
                if _bool_setting(settings, "constant"):
                    problems.add(f"era_context {era_id} must not be constant; only the era root is constant")
                if not _bool_setting(settings, "selective"):
                    problems.add(f"era_context {era_id} must be selective to carry its era token gate")
                if _prevent_recursion(settings):
                    problems.add(f"era_context {era_id} sets prevent_recursion, which stops the cascade below it")
            else:
                if _bool_setting(settings, "constant") or _bool_setting(settings, "selective"):
                    problems.add(f"era_context {era_id} must be keyword-triggered and non-selective")
                if _prevent_recursion(settings) or not _match_scenario(settings):
                    problems.add(f"era_context {era_id} must allow recursion and match Scenario")
            if _position(settings) not in {"before_char", "beforeChar", 0, None}:
                problems.add(f"era_context {era_id} must insert before character definitions")
        if multi_ok and set(context_by_era) != valid_era_ids:
            missing = sorted(valid_era_ids - set(context_by_era))
            extra = sorted(set(context_by_era) - valid_era_ids)
            problems.add(f"era_context coverage mismatch; missing={missing}, extra={extra}")

        state_rows: dict[tuple[str, str], list[dict[str, Any]]] = {}
        scoped_rows = [] if not multi_ok else [row for row in entries if _entry_arch(row).get("era_scope") in {"state", "event"}]
        for row in scoped_rows:
            entry_arch = _entry_arch(row)
            scope = entry_arch.get("era_scope")
            era_ids = entry_arch.get("era_ids")
            if not isinstance(era_ids, list) or not era_ids:
                problems.add(f"era-scoped entry {_identity(row)} needs era_ids")
                problems.add(
                    f"dependent checks skipped: era-scoped entry {_identity(row)} keyword and era-reach checks (era_ids is missing or malformed)"
                )
                continue
            unknown = [str(item) for item in era_ids if str(item) not in valid_era_ids]
            if unknown:
                problems.add(f"era-scoped entry {_identity(row)} uses unknown eras {unknown}")
            settings = _emit(row)
            secondary = {k.casefold() for k in _list_setting(settings, "secondary_keys", "keysecondary")}
            if era_routing == "scenario" and not unknown:
                for era_id in era_ids:
                    if not secondary.intersection(era_keywords[str(era_id)]):
                        problems.add(f"era-scoped entry {_identity(row)} lacks secondary keywords for era {era_id}")
            # Each routing puts different things in keysecondary, so the safe logic
            # differs. See era-system.md: under scenario the secondary keys are an era
            # phrase plus aliases (AND ANY, or the entry never fires); under root_toggle
            # they are one machine token (AND ALL, or any extra key opens the gate).
            if era_routing == "root_toggle":
                if not _bool_setting(settings, "selective") or _selective_logic(settings) not in {3, "3", "AND_ALL", "and_all"}:
                    problems.add(f"era-scoped entry {_identity(row)} must use selective AND_ALL under root_toggle routing")
                # Era roots are constant and do not match Scenario; that is the point of
                # the routing. Only the token gate and the cascade constrain them here,
                # and era_root_contract.py owns the rest.
            else:
                if not _bool_setting(settings, "selective") or _selective_logic(settings) not in {0, "0", "AND_ANY", "and_any"}:
                    problems.add(f"era-scoped entry {_identity(row)} must use selective AND_ANY under scenario routing")
                if not _match_scenario(settings) or _bool_setting(settings, "constant"):
                    problems.add(f"era-scoped entry {_identity(row)} must match Scenario and must not be constant")
            entity_key = str(entry_arch.get("entity_key", row.get("name", ""))).strip().casefold()
            for era_id in era_ids:
                state_rows.setdefault((entity_key, str(era_id)), []).append(row)
            if scope == "event":
                origin = str(entry_arch.get("origin_era_id", ""))
                if origin not in era_order:
                    problems.add(f"event entry {_identity(row)}'s origin_era_id ({origin!r}) is not one of the era-plan's own era IDs: {sorted(era_order)}")
                else:
                    expected_eras = {
                        era_id for era_id, order in era_order.items()
                        if order >= era_order[origin]
                    }
                    if {str(era_id) for era_id in era_ids} != expected_eras:
                        problems.add(
                            f"event entry {_identity(row)} declares era_ids {sorted(str(e) for e in era_ids)}, but its origin era {origin!r} requires exactly {sorted(expected_eras)} (its own era plus every later one)"
                        )
        if plan is not None:
            for entity in plan.get("entity_states", []):
                if not isinstance(entity, dict) or entity.get("split_required") is not True:
                    continue
                entity_key = str(entity.get("entity_key", entity.get("entity", ""))).strip().casefold()
                for state_row in entity.get("states", []):
                    if not isinstance(state_row, dict):
                        continue
                    era_id = str(state_row.get("era_id", ""))
                    if not state_rows.get((entity_key, era_id)):
                        problems.add(f"split entity {entity_key!r} lacks a manifest state entry for era {era_id}")

    problems.raise_if_any()
    return {
        "contract": CONTRACT,
        "era_mode": mode,
        "era_isolation": era_cfg["isolation"],
        "character_entries": len(character_rows),
        "character_system_contract": CHARACTER_SYSTEM_CONTRACT if character_plan is not None else None,
        "character_plan": str(character_path.relative_to(root)).replace("\\", "/") if character_path and character_plan else None,
        "character_plan_sha256": sha256_file(character_path) if character_path and character_plan else None,
        "character_identities": int(character_detail.get("character_count", 0)) if character_detail else 0,
        "character_states": int(character_detail.get("state_count", 0)) if character_detail else 0,
        "character_relationships": int(character_detail.get("relationship_count", 0)) if character_detail else 0,
        "era_plan": str(era_path.relative_to(root)).replace("\\", "/") if era_path else None,
        "era_plan_sha256": sha256_file(era_path) if era_path else None,
        "era_router_contract": ERA_ROUTER_CONTRACT if mode == "multi" else None,
        "era_router_era_count": router_detail.get("era_count", 0),
        "era_router_active_edge_count": router_detail.get("active_entity_edge_count", 0),
        "card_shell_contract": CARD_SHELL_CONTRACT if card_shell_plan is not None else None,
        "card_shell_plan": str(card_shell_path.relative_to(root)).replace("\\", "/") if card_shell_path else None,
        "card_shell_plan_sha256": sha256_file(card_shell_path) if card_shell_path else None,
        "card_shell_applicability": card_shell_plan.get("applicability") if card_shell_plan else None,
    }


def _section_positions(text: str, sections: Iterable[str], *, allow_extra: bool = False) -> list[int]:
    problems = ErrorCollector()
    matches: list[tuple[str, re.Match[str]]] = []
    missing: list[str] = []
    for section in sections:
        pattern = re.compile(rf"(?im)^\s*{re.escape(section)}\s*:")
        match = pattern.search(text)
        if not match:
            missing.append(section)
        else:
            matches.append((section, match))
    for section in missing:
        problems.add(f"missing character section {section!r}")
    if missing:
        problems.add("dependent checks skipped: character section order and body checks (required sections are missing)")
        problems.raise_if_any()
    positions = [match.start() for _, match in matches]
    if positions != sorted(positions):
        actual_order = [section for section, _match in sorted(matches, key=lambda pair: pair[1].start())]
        problems.add(f"character sections are not in canonical order; found them in this order: {actual_order}, expected: {[s for s, _m in matches]}")
    extra = re.search(r"(?im)^\s*EXTRA\s*:", text) if allow_extra else None
    if extra and extra.start() < matches[-1][1].start():
        problems.add(f"optional EXTRA section must follow {matches[-1][0]!r} (the last required section), but it appears earlier in the text")
    boundaries = [match.start() for _, match in matches[1:]]
    boundaries.append(extra.start() if extra else len(text))
    for (section, match), end in zip(matches, boundaries):
        body = text[match.end():end].strip()
        if not body:
            problems.add(f"character section {section!r} is empty: it has no content between its own header and the next section")
    if extra and not text[extra.end():].strip():
        problems.add("optional EXTRA section header is present but has no content after it; remove the header entirely if there is nothing to add")
    problems.raise_if_any()
    return positions


def _section_bodies(text: str, sections: Iterable[str], *, allow_extra: bool = False) -> dict[str, str]:
    problems = ErrorCollector()
    names = list(sections)
    matches: list[tuple[str, re.Match[str]]] = []
    for section in names:
        match = re.search(rf"(?im)^\s*{re.escape(section)}\s*:", text)
        if not match:
            problems.add(f"missing character section {section!r}")
        else:
            matches.append((section, match))
    problems.raise_if_any()
    extra = re.search(r"(?im)^\s*EXTRA\s*:", text) if allow_extra else None
    result: dict[str, str] = {}
    for index, (section, match) in enumerate(matches):
        if index + 1 < len(matches):
            end = matches[index + 1][1].start()
        elif extra:
            end = extra.start()
        else:
            end = len(text)
        result[section] = text[match.end():end].strip()
    if extra:
        result["EXTRA"] = text[extra.end():].strip()
    return result


def _require_terms(text: str, terms: Iterable[str], label: str) -> None:
    problems = ErrorCollector()
    folded = text.casefold()
    for term in terms:
        clean = str(term).strip()
        if clean and clean.casefold() not in folded:
            problems.add(f"character output omits required {label} term {clean!r}")
    problems.raise_if_any()


def _forbid_terms(text: str, terms: Iterable[str]) -> None:
    problems = ErrorCollector()
    folded = text.casefold()
    for term in terms:
        clean = str(term).strip()
        if clean and clean.casefold() in folded:
            problems.add(f"character future leakage or knowledge-boundary violation: output contains forbidden term {clean!r}")
    problems.raise_if_any()


def _planned_character_state(character_plan: dict[str, Any], detail: dict[str, Any], uid: str) -> tuple[dict[str, Any], dict[str, Any]]:
    owner = detail.get("uid_owner", {}).get(uid)
    if not owner:
        raise WorldBuilderError(f"character plan has no identity/state owner for manifest UID {uid}")
    character_id, state_id = owner
    character = detail.get("character_by_id", {}).get(character_id)
    state = detail.get("state_by_id", {}).get(state_id)
    if not isinstance(character, dict) or not isinstance(state, dict):
        raise WorldBuilderError(f"character plan's owner for UID {uid} is incomplete: character_id {character_id!r} resolves to {type(character).__name__}, state_id {state_id!r} resolves to {type(state).__name__} (both must be objects)")
    return character, state


def _validate_character_state_text(
    *,
    character_plan: dict[str, Any],
    detail: dict[str, Any],
    uid: str,
    description_text: str,
    personality_text: str | None,
    role: str,
) -> None:
    problems = ErrorCollector()
    character = None
    state = None
    try:
        character, state = _planned_character_state(character_plan, detail, uid)
    except WorldBuilderError as exc:
        problems.add(str(exc))
    if character is None or state is None:
        problems.add(f"dependent checks skipped: character output checks for UID {uid} (no resolvable character identity/state in the plan)")
        problems.raise_if_any()
    canonical_name = str(character.get("canonical_name", "")).strip()
    combined = description_text + "\n" + (personality_text or "")
    if role != "card_star" and canonical_name and canonical_name.casefold() not in combined.casefold():
        problems.add(f"character UID {uid} output does not name canonical identity {canonical_name!r}")
    sections = None
    try:
        sections = _section_bodies(
            description_text,
            STAR_DESCRIPTION_SECTIONS if role == "card_star" else LORE_CHARACTER_SECTIONS,
            allow_extra=True,
        )
    except WorldBuilderError as exc:
        problems.add(str(exc))
    if sections is None:
        problems.add(f"dependent checks skipped: character UID {uid} name and state-term checks (required sections are missing or out of order)")
        problems.raise_if_any()
    try:
        _require_terms(sections.get("VITALS", ""), state.get("required_vitals_terms", []), "VITALS")
    except WorldBuilderError as exc:
        problems.add(str(exc))
    voice_text = personality_text if role == "card_star" else sections.get("PERSONALITY & VOICE", "")
    try:
        _require_terms(voice_text or "", state.get("required_voice_terms", []), "voice")
    except WorldBuilderError as exc:
        problems.add(str(exc))
    try:
        _require_terms(sections.get("CURRENT", ""), state.get("required_current_terms", []), "CURRENT")
    except WorldBuilderError as exc:
        problems.add(str(exc))
    try:
        _forbid_terms(combined, state.get("forbidden_knowledge_terms", []))
    except WorldBuilderError as exc:
        problems.add(str(exc))
    state_id = str(state.get("state_id", ""))
    connections = sections.get("CONNECTIONS", "")
    for relation in character_plan.get("relationships", []):
        if not isinstance(relation, dict) or relation.get("source_state_id") != state_id:
            continue
        if relation.get("required_in_connections", True) is not True:
            continue
        target_name = str(relation.get("target_name", "")).strip()
        if target_name and target_name.casefold() not in connections.casefold():
            problems.add(f"character UID {uid} CONNECTIONS omits planned relationship target {target_name!r}")
        try:
            _require_terms(connections, relation.get("required_connection_terms", []), "CONNECTIONS")
        except WorldBuilderError as exc:
            problems.add(str(exc))
    problems.raise_if_any()


def _entry_content_index(data: dict[str, Any]) -> dict[str, tuple[dict[str, Any], str]]:
    result: dict[str, tuple[dict[str, Any], str]] = {}
    for ref in iter_entries(data):
        identity = canonical_entry_identity(ref.entry)
        if identity is not None:
            result[str(identity)] = (ref.entry, ref.path)
    return result


def _entry_text(entry: dict[str, Any]) -> str:
    value = entry.get("content")
    return value if isinstance(value, str) else ""


def _entry_setting_from_output(entry: dict[str, Any], name: str, native_name: str | None = None) -> Any:
    if name in entry:
        return entry[name]
    if native_name and native_name in entry:
        return entry[native_name]
    ext = entry.get("extensions")
    if isinstance(ext, dict):
        if name in ext:
            return ext[name]
        if native_name and native_name in ext:
            return ext[native_name]
    return None


def _validate_era_context_output(entry: dict[str, Any], era: dict[str, Any], *, plan_version: int = 1) -> None:
    problems = ErrorCollector()
    text = _entry_text(entry)
    sections = ERA_CONTEXT_SECTIONS_V2 if plan_version >= 2 else ERA_CONTEXT_SECTIONS
    try:
        _section_positions(text, sections)
    except WorldBuilderError as exc:
        problems.add(str(exc))
    folded = text.casefold()
    if str(era.get("name", "")).strip().casefold() not in folded:
        problems.add(f"era context {era['id']} does not mention its own approved era name ({era.get('name', '')!r}) anywhere in the text")
    if plan_version >= 2:
        world_state = str(era.get("world_state", "")).strip()
        if world_state and world_state.casefold() not in folded:
            problems.add(f"era context {era['id']} does not mention its own approved world_state ({world_state!r}) anywhere in the text")
    for field, label in (
        ("active_factions", "active faction"),
        ("active_characters", "active character"),
        ("active_locations", "active location"),
        ("future_events", "future-event prohibition"),
        ("past_events", "known past event"),
        ("knowledge_restrictions", "knowledge restriction"),
        ("state_assertions", "state assertion"),
    ):
        for item in era.get(field, []):
            if str(item).strip() and str(item).casefold() not in folded:
                problems.add(f"era context {era['id']} omits {label} {item!r}")
    problems.raise_if_any()


def _future_terms_by_era(plan: dict[str, Any]) -> dict[str, list[str]]:
    return {
        str(row["id"]): [str(item) for item in row.get("future_events", []) if str(item).strip()]
        for row in plan.get("eras", []) if isinstance(row, dict)
    }


def validate_output_architecture(root: Path, state: dict[str, Any], manifest: dict[str, Any], data: dict[str, Any]) -> dict[str, Any]:
    problems = ErrorCollector()
    architecture: dict[str, Any] | None = None
    try:
        architecture = _manifest_arch(manifest)
    except WorldBuilderError as exc:
        problems.add(str(exc))
    if architecture is None:
        problems.add("dependent checks skipped: output architecture checks (a usable manifest.architecture object is required)")
        problems.raise_if_any()
    card_shell_plan: dict[str, Any] | None = None
    card_shell_path: Path | None = None
    try:
        card_shell_plan, card_shell_path = load_card_shell_plan(root, state, manifest)
    except WorldBuilderError as exc:
        problems.add(str(exc))
    era_mode = architecture["era"]["mode"]
    era_routing = str(architecture["era"].get("routing", "scenario"))
    routing_ok = era_routing in {"scenario", "root_toggle"}
    if not routing_ok:
        problems.add(f"manifest architecture.era.routing must be 'scenario' or 'root_toggle', got {era_routing!r}")
    index = _entry_content_index(data)
    plan: dict[str, Any] | None = None
    if era_mode == "multi" and era_routing == "scenario":
        try:
            plan, _ = load_era_plan(root, state, manifest)
        except WorldBuilderError as exc:
            problems.add(str(exc))
    valid_era_ids: set[str] = set()
    era_ids_ok = True
    if era_mode == "multi":
        if not routing_ok:
            era_ids_ok = False
        elif era_routing == "root_toggle":
            # Parity with the planning stage: root_toggle validates era
            # references against the era-root plan's own era ids, and never
            # against (or by demanding) the scenario era plan.
            try:
                valid_era_ids = load_valid_era_ids(root, state, manifest)
            except WorldBuilderError as exc:
                problems.add(str(exc))
                era_ids_ok = False
        elif plan is not None:
            valid_era_ids = {str(row.get("id")) for row in plan.get("eras", [])}
        else:
            era_ids_ok = False
    entries: list[dict[str, Any]] | None = None
    try:
        entries = _entries(manifest)
    except WorldBuilderError as exc:
        problems.add(str(exc))
    if entries is None:
        problems.add("dependent checks skipped: output entry checks (a usable manifest.entries list is required)")
        problems.raise_if_any()
    character_rows = [row for row in entries if str(row.get("type", "")).casefold() == "character"]
    character_plan: dict[str, Any] | None = None
    character_path: Path | None = None
    character_detail: dict[str, Any] = {}
    if era_mode == "multi" and not era_ids_ok:
        problems.add("dependent checks skipped: character plan output checks (era IDs are unavailable)")
    else:
        try:
            character_plan, character_path, character_detail = load_character_plan(
                root,
                state,
                manifest,
                required=bool(character_rows),
                era_ids=valid_era_ids if era_mode == "multi" else None,
            )
        except WorldBuilderError as exc:
            problems.add(str(exc))
    checked_characters = 0
    for mentry in entries:
        entry_arch = _entry_arch(mentry)
        uid = str(mentry.get("uid", mentry.get("id", "")))
        if str(mentry.get("type", "")).casefold() == "character":
            role = entry_arch.get("character_role", "lorebook_character")
            if role == "card_star":
                continue
            if uid not in index:
                problems.add(f"character manifest UID {uid} is missing from output")
            else:
                output_entry, _ = index[uid]
                text = _entry_text(output_entry)
                sections_ok = True
                try:
                    _section_positions(text, LORE_CHARACTER_SECTIONS, allow_extra=True)
                except WorldBuilderError as exc:
                    problems.add(str(exc))
                    sections_ok = False
                if character_plan is not None and character_detail is not None:
                    if sections_ok:
                        try:
                            _validate_character_state_text(
                                character_plan=character_plan,
                                detail=character_detail,
                                uid=uid,
                                description_text=text,
                                personality_text=None,
                                role="lorebook_character",
                            )
                        except WorldBuilderError as exc:
                            problems.add(str(exc))
                    else:
                        problems.add(f"dependent checks skipped: character UID {uid} name and state-term checks (required sections are missing or out of order)")
                checked_characters += 1
        if era_mode == "multi" and entry_arch.get("layer") == "era_context":
            if not routing_ok or not era_ids_ok:
                problems.add(f"dependent checks skipped: era_context output checks for manifest UID {uid} (routing or era data is unavailable)")
                continue
            if uid not in index:
                problems.add(f"era_context manifest UID {uid} is missing from output")
                continue
            era_id = str(entry_arch.get("era_ids", [""])[0])
            output_entry, _ = index[uid]
            if era_routing == "root_toggle":
                # Routing-aware output checks (Batch 50 completion): the era
                # context is token-gated and recursion-delayed, never
                # Scenario-matched or constant. The scenario-shaped checks
                # below rejected every legitimate root_toggle delivery.
                if era_id not in valid_era_ids:
                    problems.add(f"era_context {era_id} is not one of the era-root plan's era ids: {sorted(valid_era_ids)}")
                if _entry_setting_from_output(output_entry, "constant") is True:
                    problems.add(f"era_context {era_id} was emitted as constant; only the era root is constant")
                if _entry_setting_from_output(output_entry, "selective") is not True:
                    problems.add(f"era_context {era_id} was emitted without its era token gate (selective must be true)")
                if _entry_setting_from_output(output_entry, "prevent_recursion", "preventRecursion") is True:
                    problems.add(f"era_context {era_id} was emitted with prevent_recursion, which stops the cascade below it")
            else:
                era = next((row for row in plan["eras"] if str(row["id"]) == era_id), None) if plan else None
                if era is None:
                    problems.add(f"no era-plan row for era_context {era_id}")
                else:
                    try:
                        _validate_era_context_output(output_entry, era, plan_version=int(plan.get("plan_version", 1)) if plan else 1)
                    except WorldBuilderError as exc:
                        problems.add(str(exc))
                    if _entry_setting_from_output(output_entry, "constant") is True:
                        problems.add(f"era_context {era_id} was emitted as constant")
                    if _entry_setting_from_output(output_entry, "selective") is True:
                        problems.add(f"era_context {era_id} was emitted as selective")
                    if _entry_setting_from_output(output_entry, "match_scenario", "matchScenario") is not True:
                        problems.add(f"era_context {era_id} does not match Scenario")
    info = detect_artifact(data)
    artifact_type = str(state.get("artifact", {}).get("type", ""))
    if artifact_type == "world" and info.schema == 2:
        payload = data.get("data")
        if not isinstance(payload, dict):
            problems.add(f"World card's 'data' must be a JSON object, found {type(payload).__name__}")
        else:
            scenario = payload.get("scenario")
            if card_shell_plan is not None and card_shell_plan.get("choices", {}).get("scenario_policy") == "blank" and isinstance(scenario, str) and scenario.strip():
                problems.add(f"World Mode keeps Scenario blank unless the user explicitly approved a fixed premise, but found: {scenario.strip()[:80]!r}")
            if era_mode == "multi" and plan is not None:
                notes = payload.get("creator_notes")
                if not isinstance(notes, str) or not notes.strip():
                    problems.add("this multi-era World card's creator_notes is empty: it must contain the era picker")
                    problems.add("dependent checks skipped: per-era Creator Notes keyword checks (creator_notes is empty)")
                else:
                    for era in plan.get("eras", []):
                        copyable = str(era.get("scenario_keyword", "")).strip() or next(
                            (str(key).strip() for key in era.get("keywords", []) if str(key).strip().casefold().startswith("era:")),
                            "",
                        )
                        if copyable and copyable.casefold() not in notes.casefold():
                            problems.add(f"Creator Notes omit era {era.get('id')!r}'s copyable Scenario keyword {copyable!r}: it must be mentioned somewhere in creator_notes")
    if info.schema == 1:
        payload = data.get("data")
        if not isinstance(payload, dict):
            problems.add(f"Schema 1 card's 'data' must be a JSON object, found {type(payload).__name__}")
        else:
            description = str(payload.get("description", ""))
            sections_ok = True
            try:
                _section_positions(description, STAR_DESCRIPTION_SECTIONS, allow_extra=True)
            except WorldBuilderError as exc:
                problems.add(str(exc))
                sections_ok = False
            duplicate_match = re.search(r"(?im)^\s*PERSONALITY\s*&\s*VOICE\s*:", str(payload.get("description", "")))
            if duplicate_match:
                problems.add("Schema 1 description repeats a 'PERSONALITY & VOICE:' header; that content belongs in the personality field only, not duplicated in description")
            personality = payload.get("personality")
            if not isinstance(personality, str) or not personality.strip():
                problems.add(f"Schema 1 canonical character card requires a non-empty 'personality' field, found {personality!r}")
            star_rows = [row for row in character_rows if _entry_arch(row).get("character_role") == "card_star"]
            if len(star_rows) != 1:
                problems.add(f"Schema 1 character output requires exactly one card_star manifest entry, found {len(star_rows)}: {[_identity(row) for row in star_rows]}")
                problems.add("dependent checks skipped: star character identity and state-text checks (exactly one card_star manifest entry is required)")
            elif character_plan is not None and character_detail is not None:
                star_uid = str(star_rows[0].get("uid", star_rows[0].get("id", "")))
                try:
                    star_character, _star_state = _planned_character_state(character_plan, character_detail, star_uid)
                    allowed_names = {
                        str(star_character.get("canonical_name", "")).strip().casefold(),
                        *[str(item).strip().casefold() for item in star_character.get("aliases", [])],
                    }
                    if str(payload.get("name", "")).strip().casefold() not in allowed_names:
                        problems.add(f"Schema 1 card Name ({payload.get('name')!r}) does not match the planned character identity (canonical name or alias): {sorted(allowed_names)}")
                except WorldBuilderError as exc:
                    problems.add(str(exc))
                if not sections_ok:
                    problems.add("dependent checks skipped: star character state-text checks (description sections are missing or out of order)")
                elif not (isinstance(personality, str) and personality.strip()):
                    problems.add("dependent checks skipped: star character state-text checks (the personality field is unusable)")
                else:
                    try:
                        _validate_character_state_text(
                            character_plan=character_plan,
                            detail=character_detail,
                            uid=star_uid,
                            description_text=description,
                            personality_text=personality,
                            role="card_star",
                        )
                    except WorldBuilderError as exc:
                        problems.add(str(exc))
            fixed = bool(card_shell_plan and card_shell_plan.get("choices", {}).get("scenario_policy") == "fixed")
            scenario = payload.get("scenario")
            if not fixed and isinstance(scenario, str) and scenario.strip():
                problems.add(f"canonical Character Mode keeps Scenario blank unless a fixed premise was explicitly selected, but found: {scenario.strip()[:80]!r}")
            checked_characters += 1
    if era_mode == "multi":
        if plan is not None:
            future = _future_terms_by_era(plan)
            for mentry in entries:
                entry_arch = _entry_arch(mentry)
                if entry_arch.get("layer") == "era_context":
                    continue
                era_ids = entry_arch.get("era_ids")
                uid = str(mentry.get("uid", mentry.get("id", "")))
                if not isinstance(era_ids, list) or uid not in index:
                    continue
                text = _entry_text(index[uid][0]).casefold()
                for era_id in era_ids:
                    for term in future.get(str(era_id), []):
                        if term.casefold() in text:
                            problems.add(
                                f"future leakage: entry UID {uid} for era {era_id} mentions prohibited future event {term!r}"
                            )
        elif era_routing == "scenario":
            problems.add("dependent checks skipped: future-event leakage output checks (the era plan is unavailable)")
    router_output_detail: dict[str, Any] = {}
    if era_mode == "multi" and plan is not None:
        try:
            router_output_detail = validate_era_router_output(plan, manifest, data)
        except WorldBuilderError as exc:
            problems.add(str(exc))
    shell_detail: dict[str, Any] = {"card_shell_applicable": False, "card_shell_warnings": []}
    if card_shell_plan is not None:
        try:
            shell_detail = validate_card_shell_output(state, card_shell_plan, data)
        except WorldBuilderError as exc:
            problems.add(str(exc))
    problems.raise_if_any()
    return {
        "contract": CONTRACT,
        "era_mode": era_mode,
        "character_entries_checked": checked_characters,
        "character_system_contract": CHARACTER_SYSTEM_CONTRACT if character_plan is not None else None,
        "character_plan": str(character_path.relative_to(root)).replace("\\", "/") if character_path and character_plan else None,
        "character_plan_sha256": sha256_file(character_path) if character_path and character_plan else None,
        "character_identities": int(character_detail.get("character_count", 0)) if character_detail else 0,
        "character_states": int(character_detail.get("state_count", 0)) if character_detail else 0,
        "character_relationships": int(character_detail.get("relationship_count", 0)) if character_detail else 0,
        "card_shell_contract": CARD_SHELL_CONTRACT if card_shell_plan is not None else None,
        "card_shell_plan": str(card_shell_path.relative_to(root)).replace("\\", "/") if card_shell_path else None,
        "card_shell_plan_sha256": sha256_file(card_shell_path) if card_shell_path else None,
        "era_router_contract": ERA_ROUTER_CONTRACT if era_mode == "multi" else None,
        "era_router_active_edge_count": router_output_detail.get("active_entity_edge_count", 0),
        "era_scoped_outputs_checked": router_output_detail.get("era_scoped_outputs_checked", 0),
        **shell_detail,
        "output_sha256": None,
    }


def validate(build_state: str, stage: str, artifact: str | None = None, write_receipt: bool = True) -> dict[str, Any]:
    root, state = load_build_state(build_state)
    manifest_path = resolve_state_path(root, state, "manifest")
    if not manifest_path.exists():
        raise WorldBuilderError(f"manifest does not exist at {manifest_path}: check paths.manifest, or author the manifest first")
    manifest = load_json(manifest_path)
    if not isinstance(manifest, dict):
        raise WorldBuilderError(f"{manifest_path.name} must be a JSON object, found {type(manifest).__name__}")
    if stage == "planning":
        detail = validate_planning_architecture(root, state, manifest)
        target_sha = sha256_file(manifest_path)
        receipt_key = "architecture_planning_receipt"
    else:
        target = Path(artifact).resolve() if artifact else resolve_state_path(root, state, "final_output")
        if not target.exists():
            raise WorldBuilderError(f"output artifact does not exist at {target} (explicit --artifact, or paths.final_output if none was given)")
        data = load_json(target)
        if not isinstance(data, dict):
            raise WorldBuilderError(f"{target} must contain a JSON object, found {type(data).__name__}")
        detail = validate_output_architecture(root, state, manifest, data)
        target_sha = sha256_file(target)
        detail["output_sha256"] = target_sha
        receipt_key = "architecture_output_receipt"
    receipt = {
        "kind": "worldbuilder-content-architecture-gate",
        "receipt_version": 1,
        "status": "passed",
        "stage": stage,
        "build_id": state.get("build_id"),
        "manifest_sha256": sha256_file(manifest_path),
        "target_sha256": target_sha,
        **detail,
    }
    if write_receipt:
        path = resolve_state_path(root, state, receipt_key)
        atomic_write_json(path, receipt)
    return receipt


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--build-state", required=True)
    parser.add_argument("--stage", choices=["planning", "output"])
    parser.add_argument("--artifact", help="Output artifact path; defaults to build-state paths.final_output")
    parser.add_argument("--no-write-receipt", action="store_true")
    parser.add_argument("--requirements", action="store_true", help="Read-only preflight: print what this gate checks against the current build state.")
    args = parser.parse_args()
    if args.requirements:
        root, state = load_build_state(args.build_state)
        print(json.dumps(preflight_report("architecture_gate", requirement_rows(Path(__file__), root, state)), ensure_ascii=False, indent=2))
        return 0
    if not args.stage:
        parser.error("--stage is required")
    try:
        print(json.dumps(validate(args.build_state, args.stage, args.artifact, not args.no_write_receipt), ensure_ascii=False, indent=2))
        return 0
    except (WorldBuilderError, OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        print(step_driver_pointer(), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
