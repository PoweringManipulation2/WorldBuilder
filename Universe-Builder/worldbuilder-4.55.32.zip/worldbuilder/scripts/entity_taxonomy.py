#!/usr/bin/env python3
"""Classify and normalize WorldBuilder discovery entities deterministically."""
from __future__ import annotations
import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any, Iterable
from discovery_contract import ENTITY_TYPES
from wb_common import WorldBuilderError, atomic_write_json, load_json

SPACE_RE = re.compile(r"\s+")
CATEGORY_RULES: tuple[tuple[str, tuple[str, ...]], ...] = (
    ("species", ("species", "races", "demon species", "angel species", "hellborn species", "creatures")),
    ("population", ("populations", "residents", "citizens", "sinners", "winners", "humans")),
    ("rank", ("ranks", "titles", "social classes", "nobility", "overlords", "deadly sins")),
    ("faction", ("factions", "groups", "families", "clans", "houses", "orders")),
    ("organization", ("organizations", "companies", "businesses", "agencies", "teams")),
    ("location", ("locations", "places", "cities", "buildings", "realms", "rings of hell")),
    ("event", ("events", "battles", "wars", "incidents", "exterminations")),
    ("era", ("eras", "timelines", "periods")),
    ("ability", ("abilities", "powers", "magic")),
    ("object", ("objects", "items", "weapons", "artifacts")),
    ("media", ("episodes", "songs", "comics", "shorts", "films", "media")),
    ("production", ("voice actors", "cast", "crew", "staff", "production", "dubbing")),
    ("character", ("characters", "individuals", "protagonists", "antagonists")),
)
LEAD_RULES: tuple[tuple[str, tuple[str, ...]], ...] = (
    ("species", (" is a species", " are a species", "species of ", "race of ", "type of demon", "type of angel")),
    ("population", (" are the inhabitants", "population of ", "collective term for", "people who ")),
    ("rank", (" is a rank", " are a rank", "title given to", "social class", "class of demon")),
    ("faction", (" is a faction", " are a faction", "political group", "noble house", "royal family", "demonic order")),
    ("organization", (" is an organization", " is a company", " is a business", " is an agency", " is a team")),
    ("location", (" is a location", " is a city", " is a building", " is a realm", " is one of the rings")),
    ("event", (" was an event", " is an event", "battle that", "war between")),
    ("media", (" is an episode", " is a song", " is a comic", " is a short")),
    ("production", (" is a voice actor", " is an actor", " is a director", " is a writer", "production staff")),
)
TITLE_HINTS: dict[str, str] = {
    "ars goetia": "faction", "seven deadly sins": "rank", "overlords": "rank",
    "hellborn nobility": "rank", "exorcists": "population", "sinners": "population",
    "winners": "population", "demons": "species", "angels": "species", "humans": "species",
    "imps": "species", "hellhounds": "species", "cherubs": "species", "seraphim": "species",
    "succubi": "species", "incubi": "species", "fallen angels": "species",
}

def norm(value: Any) -> str:
    return SPACE_RE.sub(" ", str(value or "").strip()).casefold()

def category_text(categories: Iterable[Any]) -> str:
    values: list[str] = []
    for item in categories:
        if isinstance(item, dict):
            item = item.get("title") or item.get("name") or item.get("category")
        if isinstance(item, str):
            values.append(item.replace("Category:", ""))
    return " | ".join(norm(value) for value in values)

def classify_entity(*, name: str, explicit_type: Any = None, categories: Iterable[Any] = (), lead_text: str = "", page_kind: str | None = None) -> dict[str, Any]:
    title, explicit, cats, lead = norm(name), norm(explicit_type), category_text(categories), norm(lead_text)[:4000]
    evidence: list[tuple[str, str]] = []
    for entity_type, markers in CATEGORY_RULES:
        for marker in markers:
            if marker in cats:
                evidence.append((entity_type, f"category:{marker}"))
                break
    for entity_type, markers in LEAD_RULES:
        for marker in markers:
            if marker in lead:
                evidence.append((entity_type, f"lead:{marker.strip()}"))
                break
    if title in TITLE_HINTS:
        evidence.append((TITLE_HINTS[title], "title-hint"))
    if page_kind in {"redirect", "disambiguation", "category", "maintenance"}:
        return {"type": "other", "confidence": "high", "reasons": [f"page-kind:{page_kind}"], "preserved_explicit": False}
    scores: dict[str, int] = {}
    reasons: dict[str, list[str]] = {}
    for entity_type, reason in evidence:
        weight = 4 if reason.startswith("category:") else 3 if reason.startswith("lead:") else 2
        scores[entity_type] = scores.get(entity_type, 0) + weight
        reasons.setdefault(entity_type, []).append(reason)
    supported = explicit if explicit in ENTITY_TYPES else None
    best = max(scores, key=lambda key: (scores[key], key)) if scores else None
    if supported and supported not in {"character", "other"}:
        chosen, preserved = supported, True
    elif best and (not supported or best != supported) and scores[best] >= 4:
        chosen, preserved = best, False
    elif supported:
        chosen, preserved = supported, True
    elif best:
        chosen, preserved = best, False
    else:
        chosen, preserved = "other", False
    top = scores.get(chosen, 0)
    chosen_reasons = list(reasons.get(chosen, []))
    if preserved:
        chosen_reasons.insert(0, "supported-explicit-type")
    if not chosen_reasons:
        chosen_reasons.append("insufficient-structured-evidence")
    return {
        "type": chosen,
        "confidence": "high" if top >= 6 else "medium" if top >= 3 else "low",
        "reasons": chosen_reasons,
        "preserved_explicit": preserved,
        "alternatives": [
            {"type": kind, "score": score, "reasons": reasons.get(kind, [])}
            for kind, score in sorted(scores.items(), key=lambda item: (-item[1], item[0]))
            if kind != chosen
        ],
    }

def normalize_entity(entity: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(entity.get("name"), str) or not entity["name"].strip():
        raise WorldBuilderError("entity requires a non-empty name")
    result = dict(entity)
    taxonomy = classify_entity(
        name=result["name"],
        explicit_type=result.get("type"),
        categories=result.get("categories") if isinstance(result.get("categories"), list) else [],
        lead_text=str(result.get("lead") or result.get("summary") or result.get("description") or ""),
        page_kind=result.get("page_kind") if isinstance(result.get("page_kind"), str) else None,
    )
    prior = result.get("type")
    result["type"] = taxonomy["type"]
    result["taxonomy"] = taxonomy
    if prior and norm(prior) != taxonomy["type"]:
        result.setdefault("classification_history", []).append({"from": prior, "to": taxonomy["type"], "reason": taxonomy["reasons"]})
    return result

def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True)
    parser.add_argument("--output")
    args = parser.parse_args()
    try:
        source = Path(args.input).resolve()
        data = load_json(source)
        if not isinstance(data, dict) or not isinstance(data.get("entities"), list):
            raise WorldBuilderError("input must be an object containing entities[]")
        value = dict(data)
        value["entities"] = [normalize_entity(item) for item in data["entities"] if isinstance(item, dict)]
        output = Path(args.output).resolve() if args.output else source
        atomic_write_json(output, value)
        print(json.dumps({"status": "normalized", "output": str(output), "entities": len(value["entities"])}, indent=2))
        return 0
    except (WorldBuilderError, OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
if __name__ == "__main__":
    raise SystemExit(main())
