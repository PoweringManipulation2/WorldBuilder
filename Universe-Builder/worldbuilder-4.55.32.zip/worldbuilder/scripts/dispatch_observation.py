#!/usr/bin/env python3
"""Host-neutral vocabulary for parent-observed worker execution receipts.

The host adapter/tooling may be OpenClaw, a standalone runner, or another host.
Gates validate these semantic observation methods rather than host product names.
"""
from __future__ import annotations

CHILD_RUNTIME_RECEIPT_KIND = "worldbuilder-child-runtime-receipt"
CHILD_RUNTIME_PARTIAL_KIND = "worldbuilder-child-runtime-partial"
PARENT_OBSERVED_CHILD_RUN = "parent_observed_child_run"
PARENT_OBSERVED_EXEC = "parent_observed_exec"
CHILD_RUN_COMPLETION = "parent-child-run-completion"
PARENT_EXEC_COMPLETION = "parent-exec-completion"
RECORDED_BY_PARENT = "worldbuilder_parent_orchestrator"

SUPPORTED_OBSERVATION_METHODS = frozenset({PARENT_OBSERVED_CHILD_RUN, PARENT_OBSERVED_EXEC})


def completion_source_for(method: str) -> str:
    if method == PARENT_OBSERVED_CHILD_RUN:
        return CHILD_RUN_COMPLETION
    if method == PARENT_OBSERVED_EXEC:
        return PARENT_EXEC_COMPLETION
    raise ValueError(f"unsupported dispatch observation method: {method!r}")
