#!/usr/bin/env python3
"""WorldBuilder's content-bound release gate.

The preferred interface is ``--build-state``. A build state names every mutable
artifact, so prose in separate workflow documents cannot accidentally point the
gate at stale files.

Examples:
    python delivery_gate.py --build-state build-state.json --seal
    python delivery_gate.py --build-state build-state.json
    python delivery_gate.py creations/card.json --no-post-gen-audit
    python delivery_gate.py creations/persona.txt --artifact-type persona

A post-generation audit is required for any artifact containing a lorebook
(Schema 2 or Schema 3). The audit bypass is accepted only after inspecting the
actual target and confirming that it is either a Schema 1 V3 card or persona
text. Freshness is proven with SHA-256 lineage, never modification timestamps.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import sys
from pathlib import Path
from typing import Any

from validate_output import print_report as print_json_report
from validate_output import validate as validate_json
from validate_persona import print_report as print_persona_report
from validate_persona import validate_persona
from audit_gate import validate_audit_run
from audit_plan import audit_ceiling_findings, count_prior_audit_plans
from architecture_gate import validate as validate_architecture
from era_root_contract import run as validate_era_root
from era_router_contract import validate as validate_era_router_output
from soul_contract import run as validate_soul_voice
from placement_contract import validate as validate_placement
from budget_contract import validate as validate_budget
from dynamic_state_contract import validate as validate_dynamic_state
from entry_naming import validate_artifact_labels
from runtime_target_adapter import validate_build_receipt as validate_runtime_adapter_receipt
from integration_acceptance import validate_build as validate_integration
from graphics_designer import validate_delivery_metadata as validate_graphics_designer_delivery
from pipeline_stage_gate import advance as advance_pipeline_stage, load_ledger as load_pipeline_stage_ledger, verify_chain as verify_pipeline_stage_chain
from wb_common import (
    step_driver_pointer,
    ArtifactInfo,
    WorldBuilderError,
    atomic_write_json,
    atomic_write_text,
    count_entries,
    detect_artifact,
    discover_phase_files,
    iter_entries,
    load_build_state,
    load_json,
    load_json_strict,
    now_iso,
    phase_sort_key,
    preflight_report,
    requirement_rows,
    resolve_state_path,
    sha256_file,
)

SEAL_PREFIX = "WORLDBUILDER-AUDIT-SEAL:"
PASS_RE = re.compile(r"^\s*(?:[-─ ]*)PASS\s*([0-4])\s+COMPLETE(?:[-─ ]*)\s*$", re.I | re.M)
REQUIRED_PASSES = {0, 1, 2, 3, 4}

ACTIVATION_SCAN_MESSAGES = (
    "Let's get started.",
    "I look around, taking stock of where I am.",
    "Nothing in particular is happening right now.",
)


def run_activation_scan(value: Any, *, root: Path | None = None, state: dict[str, Any] | None = None, target: Path | None = None) -> list[str]:
    """Batch 46 universal pre-ship activation scan: run ordinary, innocuous
    messages through the faithful ST scanner for any book and flag majority
    fan-out. Advisory only; it surfaces the numbers, never blocks delivery.
    Batch 55: when a build root and target are available, the structured
    report is persisted (state path `activation_scan_report`, else
    `artifacts/activation-scan-report.json`) so later budget validation can
    reuse the real activation data instead of re-deriving it."""
    try:
        from st_activation_scanner import diagnostic_report, entries_from_dicts
    except ImportError:
        return ["  OK - activation scan: scanner unavailable in this environment"]
    rows = [ref.entry for ref in iter_entries(value) if isinstance(ref.entry, dict)]
    if not rows:
        return ["  OK - activation scan: no lorebook entries in this artifact"]
    try:
        entries = entries_from_dicts(rows)
        report = diagnostic_report(entries, list(ACTIVATION_SCAN_MESSAGES), depth_limit=8)
    except (ValueError, TypeError, KeyError):
        return ["  WARN - activation scan could not parse this artifact's entries"]
    _persist_activation_scan_report(report, root=root, state=state, target=target)
    eligible = report.get("eligible_entry_count", 0)
    if eligible == 0:
        return ["  OK - activation scan: no eligible (non-constant) entries"]
    lines = [
        f"  OK - activation scan: {report['message_count']} innocuous messages; "
        f"max fan-out {report['max_activated_count']}/{eligible} entries"
    ]
    if report.get("majority_activation_flagged"):
        lines.append(
            f"  WARN - activation scan: one innocuous message activated "
            f"{report['max_activated_count']}/{eligible} entries (>50%); "
            f"review keys/recursion with st_activation_scanner.py"
        )
    return lines


def _persist_activation_scan_report(report: dict[str, Any], *, root: Path | None, state: dict[str, Any] | None, target: Path | None) -> None:
    """Batch 55: persist the structured scan report for reuse. Best-effort;
    the scan is advisory and this must never fail a delivery."""
    if root is None or target is None:
        return
    destination = None
    if state is not None:
        destination = resolve_state_path(root, state, "activation_scan_report", required=False)
    if destination is None:
        fallback = root / "artifacts" / "activation-scan-report.json"
        destination = fallback if fallback.parent.exists() else None
    if destination is None or not destination.parent.exists():
        return
    try:
        payload = dict(report)
        payload["target"] = str(target)
        payload["target_sha256"] = sha256_file(target)
        atomic_write_json(destination, payload)
    except (OSError, WorldBuilderError):
        return


def relative_or_absolute(path: Path, root: Path | None) -> str:
    if root is not None:
        try:
            return str(path.resolve().relative_to(root.resolve())).replace(os.sep, "/")
        except ValueError:
            pass
    return str(path.resolve())


def resolve_optional(root: Path, state: dict[str, Any], key: str) -> Path | None:
    return resolve_state_path(root, state, key, required=False)


def read_receipts(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        raise WorldBuilderError(f"pipeline receipt file is missing: {path}")
    result: list[dict[str, Any]] = []
    for line_no, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        try:
            item = json.loads(line)
        except json.JSONDecodeError as exc:
            raise WorldBuilderError(f"receipt line {line_no} is invalid JSON: {exc}") from exc
        if not isinstance(item, dict):
            raise WorldBuilderError(f"receipt line {line_no} must be an object")
        result.append(item)
    return result


def latest_receipt(receipts: list[dict[str, Any]], stage: str, build_id: str) -> dict[str, Any] | None:
    matches = [r for r in receipts if r.get("stage") == stage and r.get("build_id") == build_id]
    if not matches:
        return None
    # Batch 62: a restamped receipt is re-recorded in place behind its original
    # created_at, so on a tie the restamped row (higher restamp_count, then the
    # later restamp time) is the live one, never the first row that used that
    # original instant.
    return max(
        matches,
        key=lambda r: (int(r.get("created_at_unix", 0)), int(r.get("restamp_count", 0) or 0), str(r.get("restamped_at") or "")),
    )


def phase_path_for_key(phases_dir: Path, key: str) -> Path | None:
    if key == "phase_1":
        for path in discover_phase_files(phases_dir):
            if phase_sort_key(path)[0] == 1:
                return path
        return None
    candidate = phases_dir / key
    return candidate if candidate.exists() else None


def verify_receipt_hashes(
    receipt: dict[str, Any], root: Path, state: dict[str, Any], phases_dir: Path
) -> list[str]:
    messages: list[str] = []
    artifacts = receipt.get("artifacts")
    if not isinstance(artifacts, dict) or not artifacts:
        raise WorldBuilderError(f"{receipt.get('stage')} receipt has no artifact hashes")
    for key, expected in artifacts.items():
        if not isinstance(expected, str) or not re.fullmatch(r"[0-9a-fA-F]{64}", expected):
            raise WorldBuilderError(f"receipt hash for {key!r} is not a full SHA-256")
        path: Path | None
        configured_paths = state.get("paths") if isinstance(state.get("paths"), dict) else {}
        if key in configured_paths:
            path = resolve_optional(root, state, key)
        else:
            path = phase_path_for_key(phases_dir, key)
        if path is None or not path.exists():
            raise WorldBuilderError(f"receipt names a missing artifact: {key}")
        observed = sha256_file(path)
        if observed.lower() != expected.lower():
            raise WorldBuilderError(f"receipt hash mismatch for {key}: {path}")
        messages.append(f"receipt binds {key}")
    return messages


def verify_phase_dispatch_lineage(
    state: dict[str, Any], phases_dir: Path, pre_dispatch: dict[str, Any] | None
) -> None:
    mode = str(state.get("pipeline", {}).get("mode", "sequential"))
    dispatch_count = state.get("pipeline", {}).get("dispatch_count", 0)
    parallel = mode == "parallel" or (isinstance(dispatch_count, int) and dispatch_count > 0)
    if not parallel:
        return
    if pre_dispatch is None:
        raise WorldBuilderError("parallel build has no pre-dispatch receipt; record the pre-dispatch phase with phase_gate.py --stage pre-dispatch before delivering")
    dispatched_at = int(pre_dispatch.get("created_at_unix", 0))
    for path in discover_phase_files(phases_dir):
        number = phase_sort_key(path)[0]
        if number == 1:
            continue
        data = load_json(path)
        meta = data.get("_worldbuilder") if isinstance(data, dict) else None
        if not isinstance(meta, dict):
            raise WorldBuilderError(f"{path.name} has no _worldbuilder metadata")
        generated = meta.get("generated_at_unix")
        if not isinstance(generated, int):
            raise WorldBuilderError(f"{path.name} lacks integer generated_at_unix")
        # Two seconds of clock skew is tolerated, but a phase demonstrably older
        # than dispatch cannot be evidence from this worker run.
        if generated + 2 < dispatched_at:
            raise WorldBuilderError(
                f"{path.name} predates the pre-dispatch receipt: generated_at_unix={generated} is older than "
                f"the dispatch instant created_at_unix={dispatched_at}. If the receipt was re-recorded after "
                "the wave (a binding refresh rather than a real dispatch), run `phase_gate.py --restamp "
                "pre-dispatch [--preserve-created-at <unix>]` to refresh its bindings while preserving the "
                "recorded dispatch instant; if this phase's own generated_at_unix is a placeholder from "
                "before the build, no receipt repair can make an older phase younger and that phase's own "
                "metadata must be corrected."
            )


def _latest_amendment_stage_decisions(root: Path, state: dict[str, Any]) -> tuple[list[dict[str, Any]], dict[str, dict[str, Any]]]:
    """Return the verified amendment chain and the latest stage decisions.

    Delivery never treats the mere presence of an amendment as a bypass.  The
    pipeline-stage verifier authenticates the entire amendment sub-ledger; this
    helper then exposes only the latest explicit per-stage decisions so legacy
    phase receipts can be carried forward *only* where the amendment says the
    slice was unaffected.
    """
    ledger = load_pipeline_stage_ledger(root, state)
    amendments = ledger.get("amendments") if isinstance(ledger.get("amendments"), list) else []
    if not amendments:
        return [], {}
    latest = amendments[-1]
    decisions = latest.get("stage_decisions") if isinstance(latest, dict) else None
    by_stage = {
        str(row.get("stage")): row for row in (decisions if isinstance(decisions, list) else [])
        if isinstance(row, dict) and isinstance(row.get("stage"), str)
    }
    return amendments, by_stage


def check_receipts(root: Path, state: dict[str, Any], required: bool, *, state_path: Path | None = None, target: Path | None = None) -> list[str]:
    if not required:
        return ["phase receipts not required for this artifact"]
    receipts_path = resolve_state_path(root, state, "receipts")
    phases_dir = resolve_state_path(root, state, "phases")
    receipts = read_receipts(receipts_path)
    build_id = str(state.get("build_id", ""))
    if not build_id:
        raise WorldBuilderError("build-state.json has no build_id")

    required_stages = ["pre-generation", "pre-merge"]
    mode = str(state.get("pipeline", {}).get("mode", "sequential"))
    dispatch_count = state.get("pipeline", {}).get("dispatch_count", 0)
    parallel = mode == "parallel" or (isinstance(dispatch_count, int) and dispatch_count > 0)
    if parallel:
        required_stages.insert(1, "pre-dispatch")

    amendments, amendment_decisions = _latest_amendment_stage_decisions(root, state)
    if amendments:
        if state_path is None:
            raise WorldBuilderError("an amended build requires build-state context to verify its amendment ledger")
        # This authenticates every change-set hash, carried-forward base receipt
        # hash, and re-proven receipt before any carry-forward is accepted here.
        verify_pipeline_stage_chain(state_path, through="delivery_permitted", target=target)

    # Legacy phase-gate names map to their authoritative ordered pipeline stage.
    phase_stage_map = {
        "pre-generation": "generation_ready",
        "pre-dispatch": "generation_dispatched",
        "pre-merge": "generation_complete",
    }
    messages: list[str] = []
    selected: dict[str, dict[str, Any]] = {}
    carried: set[str] = set()
    for stage in required_stages:
        pipeline_stage = phase_stage_map[stage]
        decision = amendment_decisions.get(pipeline_stage)
        if amendments and isinstance(decision, dict) and decision.get("status") == "carried_forward":
            if decision.get("reason") != "slice_unaffected":
                raise WorldBuilderError(f"amendment carry-forward for {pipeline_stage} has an unsupported reason")
            carried.add(stage)
            messages.append(f"{stage} receipt carried forward by verified amendment decision for {pipeline_stage}")
            continue
        receipt = latest_receipt(receipts, stage, build_id)
        if receipt is None:
            raise WorldBuilderError(f"missing {stage} receipt for build {build_id}")
        selected[stage] = receipt
        messages.extend(verify_receipt_hashes(receipt, root, state, phases_dir))
    if "pre-dispatch" not in carried:
        verify_phase_dispatch_lineage(state, phases_dir, selected.get("pre-dispatch"))
    if amendments:
        messages.append(f"verified amendment ledger permits exactly {len(carried)} carried-forward phase receipt(s)")
    messages.append("required receipt chain is content-bound and complete")
    return messages


def check_pre_generation_findings(
    root: Path,
    state: dict[str, Any],
    state_path: Path,
    required: bool,
) -> list[str]:
    if not required:
        return ["pre-generation four-lens gate not required by build state"]
    receipt_path = resolve_state_path(root, state, "pre_generation_audit_receipt")
    if not receipt_path.exists():
        raise WorldBuilderError("pre-generation audit receipt is missing; run audit_gate.py --stage pre-generation (after audit_plan.py --stage pre-generation) to record it")
    stored = load_json(receipt_path)
    current = validate_audit_run(state_path, "pre-generation", write_receipt=False)
    if stored != current:
        raise WorldBuilderError("pre-generation audit receipt is stale relative to current assignments/results/runtime receipts")
    auditors = current.get("auditors")
    if not isinstance(auditors, list) or len(auditors) != 4:
        raise WorldBuilderError("pre-generation audit did not validate all four audit lenses")
    return [
        f"four structured pre-generation auditor runs validated ({', '.join(str(row.get('auditor')) for row in auditors)})",
        f"pre-generation audit run {current.get('audit_run_id')} is content-bound",
    ]


def check_audit_iteration_ceiling(root: Path, state: dict[str, Any]) -> list[str]:
    """Batch 59: a build that reached its audit iteration ceiling with findings
    still outstanding must not ship. Recomputed live from the on-disk ledger
    (canonical plan plus round archives); never a stored counter."""
    max_iterations = int((state.get("settings") or {}).get("audit_max_iterations", 3))
    for stage in ("pre-generation", "post-generation"):
        plan_key = "pre_generation_audit_plan" if stage == "pre-generation" else "post_generation_audit_plan"
        plan_path = resolve_state_path(root, state, plan_key, required=False) or (root / f".work/audit-{stage}-plan.json")
        assignments_root = (resolve_state_path(root, state, "audit_assignments", required=False) or (root / ".work/audit-assignments")) / stage
        findings_root = (resolve_state_path(root, state, "findings", required=False) or (root / ".work/findings")) / stage
        runtime_root = (resolve_state_path(root, state, "audit_runtime", required=False) or (root / ".work/audit-runtime")) / stage
        plan_count = count_prior_audit_plans(plan_path, assignments_root, stage, findings_root, runtime_root)
        if plan_count + 1 <= max_iterations:
            continue
        findings = audit_ceiling_findings(findings_root)
        if not findings:
            continue
        detail = "; ".join(f"{row['lens']} {row['finding_id']} [{row['severity']}]" for row in findings)
        raise WorldBuilderError(
            f"delivery blocked: the {stage} audit loop is at its ceiling (next iteration would be "
            f"{plan_count + 1}, audit_max_iterations={max_iterations}) and findings remain outstanding: {detail}. "
            "Raise --audit-max-iterations (band 1-5, via `settings_preset.py set`) and complete a clean audit round, "
            "or resolve the findings manually."
        )
    return []


def load_target(target: Path, artifact_type: str) -> tuple[str, Any, ArtifactInfo | None]:
    if artifact_type == "persona" or (artifact_type == "auto" and target.suffix.lower() == ".txt"):
        try:
            return "persona", target.read_bytes().decode("utf-8-sig"), None
        except UnicodeDecodeError as exc:
            raise WorldBuilderError(f"persona is not valid UTF-8 text: {exc}") from exc
    try:
        data = load_json_strict(target)
    except (json.JSONDecodeError, WorldBuilderError) as exc:
        if artifact_type == "auto":
            raise WorldBuilderError(
                f"target is neither a .txt persona nor valid JSON; use --artifact-type persona only for persona text: {exc}"
            ) from exc
        raise
    return "json", data, detect_artifact(data)


def check_direct_import_compatible(adapter_receipt: dict[str, Any]) -> None:
    """Batch 13 enforcement gate: a known SillyTavern-side incompatibility
    must block delivery, not just get reported. This is a safety net
    independent of the default-resolution fix in
    runtime_target_adapter.py's resolve_preserve_target. It exists
    specifically for a FUTURE regression of that fix, a bypassed code
    path, or a config override, not for catching today's already-fixed
    default. It only fires when the unrequested default ("preserve")
    produced a non-importable shape; an explicit, deliberate request
    for the portable interchange format (e.g. --runtime-format
    lorebook-v3 directly) is never blocked here, since that is a real,
    legitimate choice, not a silent trap.
    """
    if adapter_receipt.get("direct_import_compatible") is False and adapter_receipt.get("target") == "preserve":
        probe = adapter_receipt.get("sillytavern_import_probe") or {}
        raise WorldBuilderError(
            "delivery blocked: the default output format is not directly importable into "
            "SillyTavern, and this build never explicitly requested a different (interchange-"
            "only) format. "
            f"{probe.get('reason', 'See artifacts/target-compatibility-report.json for detail.')} "
            "This should not happen with the current default-resolution logic "
            "(runtime_target_adapter.py's resolve_preserve_target); if you are seeing this, "
            "something bypassed or regressed that resolution. To ship the interchange format "
            "anyway, re-run init_build.py with an explicit --runtime-format lorebook-v3 (or the "
            "correct explicit target), which this gate does not block."
        )


def validate_target(
    kind: str,
    value: Any,
    info: ArtifactInfo | None,
    manifest: Any | None,
    profile: str,
    persona_mode: str,
    require_clean: bool,
) -> tuple[bool, int, int]:
    if kind == "persona":
        report = validate_persona(value, mode=persona_mode, profile="worldbuilder")
        print_persona_report(report)
        return (not report.errors and (not require_clean or not report.warnings), len(report.errors), len(report.warnings))
    report, detected = validate_json(value, profile=profile, manifest=manifest)
    print_json_report(report, detected)
    if info is not None and detected != info:
        raise WorldBuilderError("artifact classification changed during validation")
    return (not report.errors and (not require_clean or not report.warnings), len(report.errors), len(report.warnings))


def audit_required(kind: str, info: ArtifactInfo | None) -> bool:
    return kind == "json" and info is not None and info.schema in {2, 3}


def bypass_allowed(kind: str, info: ArtifactInfo | None) -> bool:
    return kind == "persona" or (
        kind == "json" and info is not None and info.kind == "card_v3" and info.schema == 1
    )


def parse_seals(text: str) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    for line_no, line in enumerate(text.splitlines(), 1):
        stripped = line.strip()
        if not stripped.startswith(SEAL_PREFIX):
            continue
        try:
            value = json.loads(stripped[len(SEAL_PREFIX):].strip())
        except json.JSONDecodeError as exc:
            raise WorldBuilderError(f"audit seal on line {line_no} is invalid JSON: {exc}") from exc
        if not isinstance(value, dict):
            raise WorldBuilderError(f"audit seal on line {line_no} must be an object")
        result.append(value)
    return result


def audit_passes(text: str) -> set[int]:
    return {int(match.group(1)) for match in PASS_RE.finditer("\n" + text + "\n")}


def resolve_lineage_merge_input(root: Path, state: dict[str, Any]) -> Path | None:
    """Batch 62 B1: default to the file the recorded merge lineage names.

    In auto context-window mode merge_phases.py records lineage.merge.output as
    the immutable pre-review snapshot, and pipeline stage 8 demands exactly that
    binding, but post-merge rewrites (entry naming, recorded repairs) necessarily
    change paths.merge_input. Comparing against the wrong file made [7/11] and
    --seal refuse on builds whose merge lineage was intact. The lineage's own
    recorded file is authoritative; paths.merge_input remains the fallback when
    no lineage path is recorded or present."""
    lineage = state.get("lineage") if isinstance(state.get("lineage"), dict) else {}
    merge = lineage.get("merge") if isinstance(lineage.get("merge"), dict) else {}
    recorded = merge.get("output")
    if isinstance(recorded, str) and recorded.strip():
        candidate = Path(recorded)
        if not candidate.is_absolute():
            candidate = root / candidate
        if candidate.exists():
            return candidate
    return resolve_optional(root, state, "merge_input")


def merge_hash_for(root: Path | None, state: dict[str, Any] | None, merge_input: Path | None) -> str | None:
    if merge_input is None:
        return None
    if not merge_input.exists():
        raise WorldBuilderError(f"merge input is missing: {merge_input}; run merge_phases.py to produce it")
    observed = sha256_file(merge_input)
    if state is not None:
        expected = state.get("lineage", {}).get("merge", {}).get("sha256")
        if expected and str(expected).lower() != observed:
            raise WorldBuilderError("merge input no longer matches build-state lineage")
    return observed


def _validated_audit_receipt(
    *, root: Path, state: dict[str, Any], state_path: Path, stage: str
) -> tuple[dict[str, Any], Path]:
    key = "pre_generation_audit_receipt" if stage == "pre-generation" else "post_generation_audit_receipt"
    receipt_path = resolve_state_path(root, state, key)
    if not receipt_path.exists():
        raise WorldBuilderError(f"{stage} structured audit receipt is missing")
    stored = load_json(receipt_path)
    current = validate_audit_run(state_path, stage, write_receipt=False)
    if stored != current:
        raise WorldBuilderError(f"{stage} audit receipt is stale or does not match current child runtime evidence")
    return current, receipt_path


def validate_saved_receipt(state_path: Path, stage: str) -> dict[str, Any]:
    root, state = load_build_state(state_path)
    receipt, _ = _validated_audit_receipt(root=root, state=state, state_path=state_path, stage=stage)
    return receipt


def write_seal(
    target: Path,
    audit_log: Path,
    *,
    root: Path | None,
    state_path: Path | None,
    state: dict[str, Any] | None,
    merge_input: Path | None,
    amends: str | None = None,
    change_set_sha256: str | None = None,
) -> dict[str, Any]:
    if not audit_log.exists():
        raise WorldBuilderError(f"audit log is missing: {audit_log}")
    if (amends is None) != (change_set_sha256 is None):
        raise WorldBuilderError("amends and change_set_sha256 must be given together or not at all")
    text = audit_log.read_text(encoding="utf-8")
    target_data: Any = None
    try:
        target_data = load_json(target)
    except (json.JSONDecodeError, UnicodeDecodeError):
        pass
    entry_count = count_entries(target_data) if isinstance(target_data, dict) else 0
    merge_sha = merge_hash_for(root, state, merge_input)
    build_id = str(state.get("build_id", "standalone")) if state else "standalone"

    if state is not None and state_path is not None and root is not None:
        receipt, receipt_path = _validated_audit_receipt(
            root=root, state=state, state_path=state_path, stage="post-generation"
        )
        if receipt.get("target_sha256") != sha256_file(target):
            raise WorldBuilderError(
                "post-generation auditors did not review the exact target bytes being sealed: "
                f"the audit receipt is bound to target_sha256={receipt.get('target_sha256')!r}, but the bytes "
                f"at {target} currently hash to {sha256_file(target)!r}. The post-generation audit must target "
                "the exact file this seal will bind (usually paths.final_output, not an intermediate merge or "
                "adapter-output file). Re-plan with `audit_plan.py --stage post-generation --target "
                f"{target}`, dispatch the four lenses again, pass audit_gate.py, THEN re-run this seal; "
                "sealing against a different target than what was audited is never permitted, regardless of "
                "how close the two files are."
            )
        pre_dispatch_worker_kit = None
        receipts_path = resolve_state_path(root, state, "receipts", required=False)
        if receipts_path is not None and receipts_path.exists():
            pre_dispatch = latest_receipt(read_receipts(receipts_path), "pre-dispatch", build_id)
            if isinstance(pre_dispatch, dict) and isinstance(pre_dispatch.get("worker_kit"), dict):
                pre_dispatch_worker_kit = pre_dispatch["worker_kit"]
        seal = {
            # Batch 12: an amendment still binds every field a fresh seal
            # binds (target bytes, entry count, merge input); an
            # amendment is never a fast path around those checks, only
            # around re-proving stages the change set genuinely does not
            # touch (pipeline_stage_gate.py's amendment sub-ledger).
            "seal_version": 4 if amends is not None else 3,
            "audit_run_id": receipt.get("audit_run_id"),
            "audit_receipt": relative_or_absolute(receipt_path, root),
            "audit_receipt_sha256": sha256_file(receipt_path),
            "auditor_result_sha256": {
                str(row.get("lens")): row.get("result_sha256")
                for row in receipt.get("auditors", []) if isinstance(row, dict)
            },
            "auditor_runtime_sha256": {
                str(row.get("lens")): row.get("runtime_receipt_sha256")
                for row in receipt.get("auditors", []) if isinstance(row, dict)
            },
            "build_id": build_id,
            "worker_kit_sha256": pre_dispatch_worker_kit.get("worker_kit_sha256") if pre_dispatch_worker_kit else None,
            "worker_kit_skill_release": pre_dispatch_worker_kit.get("skill_release") if pre_dispatch_worker_kit else None,
            "target": relative_or_absolute(target, root),
            "target_sha256": sha256_file(target),
            "entry_count": entry_count,
            "merge_input_sha256": merge_sha,
            "budget_plan_sha256": sha256_file(resolve_state_path(root, state, "budget_plan")) if resolve_state_path(root, state, "budget_plan", required=False) and resolve_state_path(root, state, "budget_plan", required=False).exists() else None,
            "budget_output_receipt_sha256": sha256_file(resolve_state_path(root, state, "budget_output_receipt")) if resolve_state_path(root, state, "budget_output_receipt", required=False) and resolve_state_path(root, state, "budget_output_receipt", required=False).exists() else None,
            "dynamic_state_plan_sha256": sha256_file(resolve_state_path(root, state, "dynamic_state_plan")) if resolve_state_path(root, state, "dynamic_state_plan", required=False) and resolve_state_path(root, state, "dynamic_state_plan", required=False).exists() else None,
            "dynamic_state_output_receipt_sha256": sha256_file(resolve_state_path(root, state, "dynamic_state_output_receipt")) if resolve_state_path(root, state, "dynamic_state_output_receipt", required=False) and resolve_state_path(root, state, "dynamic_state_output_receipt", required=False).exists() else None,
            "runtime_adapter_receipt_sha256": sha256_file(resolve_state_path(root, state, "runtime_adapter_receipt")) if resolve_state_path(root, state, "runtime_adapter_receipt", required=False) and resolve_state_path(root, state, "runtime_adapter_receipt", required=False).exists() else None,
            "runtime_adapter_output_sha256": sha256_file(resolve_state_path(root, state, "adapter_output")) if resolve_state_path(root, state, "adapter_output", required=False) and resolve_state_path(root, state, "adapter_output", required=False).exists() else None,
            "created_at": now_iso(),
        }
        if amends is not None:
            seal["amends"] = amends
            seal["change_set_sha256"] = change_set_sha256
    else:
        missing = REQUIRED_PASSES - audit_passes(text)
        if missing:
            raise WorldBuilderError(f"cannot seal standalone legacy audit: log lacks PASS markers {sorted(missing)}")
        # Legacy standalone mode has no child runtime evidence. Keep it explicitly
        # separate from the v3 build-state seal.
        import uuid
        seal = {
            "seal_version": 2,
            "audit_run_id": uuid.uuid4().hex,
            "build_id": build_id,
            "target": relative_or_absolute(target, root),
            "target_sha256": sha256_file(target),
            "entry_count": entry_count,
            "merge_input_sha256": merge_sha,
            "created_at": now_iso(),
        }

    lines = [line for line in text.splitlines() if not line.strip().startswith(SEAL_PREFIX)]
    clean = "\n".join(lines).rstrip() + "\n\n" + SEAL_PREFIX + " " + json.dumps(seal, sort_keys=True) + "\n"
    atomic_write_text(audit_log, clean)
    if state is not None and state_path is not None:
        state.setdefault("status", {})["post_generation_audit"] = "sealed"
        state.setdefault("lineage", {})["audit"] = {
            "audit_log": relative_or_absolute(audit_log, root),
            "audit_log_sha256": sha256_file(audit_log),
            "seal": seal,
        }
        atomic_write_json(state_path, state)
        # Batch 22 C/E: persist minimal source provenance pointers and snapshot
        # the newly sealed state.  Both are post-seal metadata; neither changes
        # model-facing content or target bytes.
        from source_sync import write_source_lineage
        write_source_lineage(state_path)
        from revision_history import record_sealed_revision
        record_sealed_revision(state_path, seal=seal)
    return seal


def verify_audit(
    target: Path,
    audit_log: Path | None,
    required: bool,
    allow_bypass_flag: bool,
    bypass_is_valid: bool,
    *,
    root: Path | None,
    state_path: Path | None,
    state: dict[str, Any] | None,
    merge_input: Path | None,
) -> list[str]:
    if allow_bypass_flag and not bypass_is_valid:
        raise WorldBuilderError("--no-post-gen-audit is forbidden for a lorebook-bearing Schema 2/3 artifact")
    if not required:
        return ["post-generation lorebook audit not required for this inspected artifact"]
    if audit_log is None or not audit_log.exists():
        raise WorldBuilderError("lorebook-bearing artifact requires an audit log")
    text = audit_log.read_text(encoding="utf-8")
    seals = parse_seals(text)
    if len(seals) != 1:
        raise WorldBuilderError(f"audit log must contain exactly one current seal; found {len(seals)}")
    seal = seals[0]
    build_id = str(state.get("build_id", "standalone")) if state else "standalone"
    if seal.get("build_id") != build_id:
        raise WorldBuilderError("audit seal build_id mismatch")
    observed_target = sha256_file(target)
    if str(seal.get("target_sha256", "")).lower() != observed_target:
        raise WorldBuilderError("target bytes changed after the audit seal was written")
    try:
        data = load_json(target)
        observed_count = count_entries(data)
    except (json.JSONDecodeError, OSError):
        observed_count = 0
    if seal.get("entry_count") != observed_count:
        raise WorldBuilderError("audit seal entry_count does not match target")
    merge_sha = merge_hash_for(root, state, merge_input)
    if seal.get("merge_input_sha256") != merge_sha:
        raise WorldBuilderError("audit seal is not bound to the current merge input")

    if state is not None and state_path is not None and root is not None:
        # Batch 12 guard: delivery_gate never gets an amendment fast path.
        # seal_version 4 is accepted here, but every check above this line
        # (target bytes, merge input) and below it (audit receipt, entry
        # count) already runs unconditionally for both 3 and 4; an
        # amendment changes which upstream STAGES got re-proven, never
        # what delivery_gate itself re-verifies from disk.
        if seal.get("seal_version") not in (3, 4):
            raise WorldBuilderError("build-state releases require a structured four-lens seal_version 3 or an amended seal_version 4")
        receipts_path = resolve_state_path(root, state, "receipts", required=False)
        if receipts_path is not None and receipts_path.exists():
            pre_dispatch = latest_receipt(read_receipts(receipts_path), "pre-dispatch", build_id)
            if isinstance(pre_dispatch, dict) and isinstance(pre_dispatch.get("worker_kit"), dict):
                kit = pre_dispatch["worker_kit"]
                if seal.get("worker_kit_sha256") != kit.get("worker_kit_sha256"):
                    raise WorldBuilderError("audit seal does not bind the worker kit recorded at pre-dispatch")
                if seal.get("worker_kit_skill_release") != kit.get("skill_release"):
                    raise WorldBuilderError("audit seal worker-kit skill release does not match pre-dispatch")
        receipt, receipt_path = _validated_audit_receipt(
            root=root, state=state, state_path=state_path, stage="post-generation"
        )
        if seal.get("audit_run_id") != receipt.get("audit_run_id"):
            raise WorldBuilderError("audit seal run ID does not originate from the post-generation assignments")
        if seal.get("audit_receipt_sha256") != sha256_file(receipt_path):
            raise WorldBuilderError("audit seal does not bind the current structured audit receipt")
        expected_results = {str(row.get("lens")): row.get("result_sha256") for row in receipt.get("auditors", [])}
        expected_runtime = {str(row.get("lens")): row.get("runtime_receipt_sha256") for row in receipt.get("auditors", [])}
        if seal.get("auditor_result_sha256") != expected_results or seal.get("auditor_runtime_sha256") != expected_runtime:
            raise WorldBuilderError("audit seal does not bind all four auditor result/runtime files")
        budget_plan = resolve_state_path(root, state, "budget_plan", required=False)
        budget_output_receipt = resolve_state_path(root, state, "budget_output_receipt", required=False)
        if budget_plan and budget_plan.exists() and seal.get("budget_plan_sha256") != sha256_file(budget_plan):
            raise WorldBuilderError("audit seal does not bind the current budget plan")
        if budget_output_receipt and budget_output_receipt.exists() and seal.get("budget_output_receipt_sha256") != sha256_file(budget_output_receipt):
            raise WorldBuilderError("audit seal does not bind the current budget output receipt")
        dynamic_plan = resolve_state_path(root, state, "dynamic_state_plan", required=False)
        dynamic_output_receipt = resolve_state_path(root, state, "dynamic_state_output_receipt", required=False)
        if dynamic_plan and dynamic_plan.exists() and seal.get("dynamic_state_plan_sha256") != sha256_file(dynamic_plan):
            raise WorldBuilderError("audit seal does not bind the current dynamic-state plan")
        if dynamic_output_receipt and dynamic_output_receipt.exists() and seal.get("dynamic_state_output_receipt_sha256") != sha256_file(dynamic_output_receipt):
            raise WorldBuilderError("audit seal does not bind the current dynamic-state output receipt")
        runtime_status = str(state.get("status", {}).get("runtime_adapter", "not_required"))
        if runtime_status != "not_required":
            adapter_receipt = validate_runtime_adapter_receipt(state_path)
            adapter_receipt_path = resolve_state_path(root, state, "runtime_adapter_receipt")
            adapter_output = resolve_state_path(root, state, "adapter_output")
            if seal.get("runtime_adapter_receipt_sha256") != sha256_file(adapter_receipt_path):
                raise WorldBuilderError("audit seal does not bind the current runtime-adapter receipt")
            if seal.get("runtime_adapter_output_sha256") != sha256_file(adapter_output):
                raise WorldBuilderError("audit seal does not bind the current runtime-adapter output")
        return ["all four structured auditor runs validated", "singleton v3 audit seal matches target, merge, results, runtime, and adapter receipts"]

    missing = REQUIRED_PASSES - audit_passes(text)
    if missing:
        raise WorldBuilderError(f"standalone legacy audit log lacks PASS markers {sorted(missing)}")
    if seal.get("seal_version") != 2:
        raise WorldBuilderError("standalone legacy audit seal version is unsupported")
    return ["legacy PASS 0-4 markers present", "singleton legacy audit seal matches target and merge lineage"]


def state_default_target(root: Path, state: dict[str, Any]) -> Path:
    return resolve_state_path(root, state, "final_output")


def build_argument_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Validate and release-gate a WorldBuilder artifact.")
    parser.add_argument("path", nargs="?", help="Final JSON or persona text path (optional with --build-state).")
    parser.add_argument("--build-state", help="Authoritative build-state.json path.")
    parser.add_argument("--artifact-type", choices=["auto", "json", "persona"], default="auto")
    parser.add_argument("--manifest", help="Legacy override; build-state paths.manifest is preferred.")
    parser.add_argument("--audit-log", help="Legacy override; build-state paths.audit_log is preferred.")
    parser.add_argument("--merge-input", help="Legacy override; the file recorded in build-state lineage.merge is preferred.")
    parser.add_argument("--receipts", help="Legacy receipt path (only build-state mode enforces full lineage).")
    parser.add_argument("--profile", choices=["spec", "sillytavern", "worldbuilder"], default="sillytavern")
    parser.add_argument("--persona-mode", choices=["auto", "simple", "split"], default="auto")
    parser.add_argument("--require-clean", action="store_true", help="Block on warnings as well as errors.")
    parser.add_argument(
        "--no-post-gen-audit",
        action="store_true",
        help="Compatibility flag; accepted only after target inspection proves Schema 1 or persona text.",
    )
    parser.add_argument("--seal", action="store_true", help="Replace the audit log's current seal with one for target bytes.")
    parser.add_argument("--requirements", action="store_true", help="Read-only preflight: print what this gate checks against the current build state.")
    return parser


def orchestrate(args: argparse.Namespace, parser: argparse.ArgumentParser) -> int:
    root: Path | None = None
    state_path: Path | None = None
    state: dict[str, Any] | None = None
    if args.build_state:
        root, state = load_build_state(args.build_state)
        state_path = Path(args.build_state).resolve()
        target = Path(args.path).resolve() if args.path else state_default_target(root, state)
        manifest_path = Path(args.manifest).resolve() if args.manifest else resolve_optional(root, state, "manifest")
        audit_log = Path(args.audit_log).resolve() if args.audit_log else resolve_optional(root, state, "audit_log")
        merge_input = Path(args.merge_input).resolve() if args.merge_input else resolve_lineage_merge_input(root, state)
        configured_type = str(state.get("artifact", {}).get("type", "auto"))
        artifact_type = args.artifact_type if args.artifact_type != "auto" else ("persona" if configured_type == "persona" else "auto")
        persona_mode = args.persona_mode if args.persona_mode != "auto" else str(state.get("artifact", {}).get("persona_mode", "auto"))
    else:
        if not args.path:
            parser.error("path is required unless --build-state is used")
        target = Path(args.path).resolve()
        manifest_path = Path(args.manifest).resolve() if args.manifest else None
        audit_log = Path(args.audit_log).resolve() if args.audit_log else None
        merge_input = Path(args.merge_input).resolve() if args.merge_input else None
        artifact_type = args.artifact_type
        persona_mode = args.persona_mode

    if not target.exists():
        raise WorldBuilderError(f"target file is missing: {target}")
    kind, value, info = load_target(target, artifact_type)
    if kind == "json" and isinstance(value, dict):
        validate_graphics_designer_delivery(value)
    requires_audit = audit_required(kind, info)
    bypass_ok = bypass_allowed(kind, info)
    if args.no_post_gen_audit and not bypass_ok:
        raise WorldBuilderError("--no-post-gen-audit was requested for an ineligible target")

    if args.seal:
        if not requires_audit:
            raise WorldBuilderError("audit seals are only used for lorebook-bearing Schema 2/3 artifacts")
        if state_path is None:
            raise WorldBuilderError("--seal requires --build-state so four auditor runtimes can be verified")
        post_receipt = validate_saved_receipt(state_path, "post-generation")
        if post_receipt.get("target_sha256") != sha256_file(target):
            raise WorldBuilderError(
                "post-generation auditors did not review the exact target bytes being sealed: "
                f"the saved receipt is bound to target_sha256={post_receipt.get('target_sha256')!r}, but the "
                f"bytes at {target} currently hash to {sha256_file(target)!r}. The post-generation audit must "
                "target the exact file this seal will bind (usually paths.final_output, not an intermediate "
                f"merge or adapter-output file). Re-plan with `audit_plan.py --stage post-generation --target "
                f"{target}`, dispatch the four lenses again, pass audit_gate.py, THEN re-run --seal."
            )
        if audit_log is None:
            raise WorldBuilderError("--seal requires an audit log path")
        if kind == "json":
            validate_architecture(str(state_path), "output", str(target), write_receipt=True)
            validate_placement(str(state_path), "output", str(target), write_receipt=True)
            validate_budget(str(state_path), "output", str(target), write_receipt=True)
            dynamic_state = state.get("dynamic_state") if isinstance(state.get("dynamic_state"), dict) else {}
            if dynamic_state.get("applicable") is True:
                validate_dynamic_state(str(state_path), "output", write_receipt=True)
            if str(state.get("status", {}).get("runtime_adapter", "not_required")) != "not_required":
                adapter_receipt = validate_runtime_adapter_receipt(state_path)
                check_direct_import_compatible(adapter_receipt)
            validate_integration(state_path, "output", target, write_receipt=True)
        pending_amendment = (state.get("amendment") or {}).get("pending") if isinstance(state.get("amendment"), dict) else None
        amends = None
        change_set_sha = None
        if isinstance(pending_amendment, dict):
            change_set_raw = pending_amendment.get("change_set")
            if not isinstance(change_set_raw, str) or not change_set_raw:
                raise WorldBuilderError("pending amendment is missing its change_set path")
            change_set_path = Path(change_set_raw)
            if not change_set_path.is_absolute():
                change_set_path = root / change_set_path
            if not change_set_path.exists():
                raise WorldBuilderError(f"pending amendment change set is missing: {change_set_path}")
            prior_seal = ((state.get("lineage") or {}).get("audit") or {}).get("seal") if isinstance(state.get("lineage"), dict) else None
            if not isinstance(prior_seal, dict):
                raise WorldBuilderError("an additive amendment requires the prior structured audit seal it amends")
            amends = hashlib.sha256(json.dumps(prior_seal, sort_keys=True).encode("utf-8")).hexdigest()
            change_set_sha = sha256_file(change_set_path)
        else:
            advance_pipeline_stage(state_path, "output_contracts", target)
            advance_pipeline_stage(state_path, "runtime_adapter", target)
            advance_pipeline_stage(state_path, "integration_output", target)
        # Validation helpers above may have refreshed state-bound receipts. Reload
        # before sealing so the seal binds the exact current state.
        root, state = load_build_state(state_path)
        seal = write_seal(
            target,
            audit_log,
            root=root,
            state_path=state_path,
            state=state,
            merge_input=merge_input,
            amends=amends,
            change_set_sha256=change_set_sha,
        )
        if isinstance(pending_amendment, dict):
            root, state = load_build_state(state_path)
            pending = state.setdefault("amendment", {}).setdefault("pending", {})
            pending.update({
                "phase": "record_amendment",
                "amended_seal_sha256": hashlib.sha256(json.dumps(seal, sort_keys=True).encode("utf-8")).hexdigest(),
                "amends": amends,
                "change_set_sha256": change_set_sha,
            })
            atomic_write_json(state_path, state)
        print(SEAL_PREFIX, json.dumps(seal, sort_keys=True))
        return 0

    manifest = load_json(manifest_path) if manifest_path and manifest_path.exists() else None
    if manifest_path and not manifest_path.exists() and requires_audit:
        raise WorldBuilderError(f"configured manifest is missing: {manifest_path}")

    print("── WORLDBUILDER DELIVERY GATE ──")
    print(f"Target: {target}")
    print(f"Artifact: {kind if info is None else info.kind}")
    print()
    print("[1/11] Target validation")
    validator_ok, errors, warnings = validate_target(
        kind, value, info, manifest, args.profile, persona_mode, args.require_clean
    )
    if kind == "json" and state_path is not None:
        architecture_receipt = validate_architecture(str(state_path), "output", str(target), write_receipt=True)
        print("  OK: content architecture", architecture_receipt.get("contract"), "validated")
        # Both routings are now validated at planning and at delivery; the router
        # contract self-skips when the manifest declares root_toggle routing.
        era_router_receipt = validate_era_router_output(str(state_path), "output", str(target), write_receipt=True)
        if era_router_receipt.get("status") == "passed":
            print("  OK: era router", era_router_receipt.get("contract"), "validated")
        soul_receipt = validate_soul_voice(str(state_path), "output", str(target), write_receipt=True)
        if soul_receipt.get("status") == "passed":
            detail = soul_receipt["detail"]
            print("  OK: soul voice", soul_receipt.get("contract"), "validated")
            for warning in detail.get("warnings", []):
                print("  WARN:", warning)
        era_root_receipt = validate_era_root(str(state_path), "output", str(target), write_receipt=True)
        if era_root_receipt.get("status") == "passed":
            print("  OK: era roots", era_root_receipt.get("contract"),
                  "validated;", era_root_receipt["detail"].get("era_count"), "eras,",
                  "settings block present")
        manifest_arch = manifest.get("architecture") if isinstance(manifest, dict) and isinstance(manifest.get("architecture"), dict) else {}
        if isinstance(manifest_arch.get("placement"), dict):
            placement_receipt = validate_placement(str(state_path), "output", str(target), write_receipt=True)
            print("  OK: placement and influence", placement_receipt.get("contract"), "validated")

    print("\n[2/11] Context budget and pruning safeguards")
    if kind == "json" and state_path is not None:
        budget_receipt = validate_budget(str(state_path), "output", str(target), write_receipt=True)
        print("  OK:", budget_receipt.get("profile_label"), "profile;", len(budget_receipt.get("simulations", [])), "activation simulations")
        for warning in budget_receipt.get("warnings", []):
            print("  WARN:", warning)
    else:
        print("  OK: not applicable")

    if kind == "json":
        for message in run_activation_scan(value, root=root, state=state, target=target):
            print(message)

    print("\n[3/11] Dynamic State and Variation")
    dynamic_state = state.get("dynamic_state") if isinstance(state, dict) and isinstance(state.get("dynamic_state"), dict) else {}
    if kind == "json" and state_path is not None and dynamic_state.get("applicable") is True:
        dynamic_receipt = validate_dynamic_state(str(state_path), "output", write_receipt=True)
        print("  OK:", dynamic_receipt.get("policy"), "policy;", dynamic_receipt.get("dynamic_entry_count", 0), "dynamic entries;", dynamic_receipt.get("group_count", 0), "groups")
        for warning in dynamic_receipt.get("warnings", []):
            print("  WARN:", warning)
    else:
        print("  OK: not applicable")

    print("\n[4/11] Runtime target adapter")
    runtime_status = str(state.get("status", {}).get("runtime_adapter", "not_required")) if isinstance(state, dict) else "not_required"
    if state_path is not None and runtime_status != "not_required":
        adapter_receipt = validate_runtime_adapter_receipt(state_path)
        print("  OK:", adapter_receipt.get("target"), "adapter; IR", adapter_receipt.get("semantic_ir_sha256"))
    else:
        print("  OK: portable source artifact; adapter not required")

    print("\n[5/11] Pre-generation evidence")
    if state is not None and root is not None:
        pregen_required = bool(state.get("audit", {}).get("pre_generation_required", requires_audit))
        pregen_messages = check_pre_generation_findings(root, state, state_path, pregen_required)
        pregen_messages.extend(check_audit_iteration_ceiling(root, state))
    else:
        pregen_messages = ["not enforced without --build-state"]
    for message in pregen_messages:
        print("  OK:", message)

    print("\n[6/11] Post-generation audit")
    if requires_audit:
        if state_path is None:
            raise WorldBuilderError("lorebook-bearing release requires --build-state to prove four post-generation auditor runs")
        post_receipt = validate_saved_receipt(state_path, "post-generation")
        if post_receipt.get("target_sha256") != sha256_file(target):
            raise WorldBuilderError(
                "post-generation audit receipt is not bound to the current target bytes: the audit reviewed "
                f"target_sha256={post_receipt.get('target_sha256')!r}, but {target} currently hashes to "
                f"{sha256_file(target)!r}. Re-plan the post-generation audit against the delivery target "
                f"(audit_plan.py --stage post-generation --target {target}), re-run the four lenses, pass "
                "audit_gate.py, then re-run delivery."
            )
        print("  OK: four post-generation auditor runtimes validated")
    audit_messages = verify_audit(
        target,
        audit_log,
        requires_audit,
        args.no_post_gen_audit,
        bypass_ok,
        root=root,
        state_path=state_path,
        state=state,
        merge_input=merge_input,
    )
    for message in audit_messages:
        print("  OK:", message)

    print("\n[7/11] Merge lineage")
    merge_sha = merge_hash_for(root, state, merge_input)
    if requires_audit and merge_sha is None:
        raise WorldBuilderError("lorebook-bearing artifact has no merge input lineage")
    print("  OK:", "not applicable" if merge_sha is None else f"merge SHA-256 {merge_sha}")

    print("\n[8/11] Entry naming and provenance")
    if kind == "json":
        naming_result = validate_artifact_labels(value)
        print("  OK:", naming_result.get("entry_count", 0), "semantic entry labels; provenance kept out of visible names")
    else:
        print("  OK: not applicable")

    print("\n[9/11] Full integration and acceptance")
    if state_path is not None:
        integration_receipt = validate_integration(state_path, "output", target, write_receipt=True)
        print("  OK:", integration_receipt.get("pipeline"), "pipeline;", len(integration_receipt.get("required_systems", [])), "systems bound")
    else:
        print("  OK: not enforced without --build-state")

    print("\n[10/11] Pipeline receipts")
    if state is not None and root is not None:
        receipt_messages = check_receipts(root, state, requires_audit, state_path=state_path, target=target)
    elif requires_audit:
        raise WorldBuilderError("lorebook-bearing release requires --build-state for receipt enforcement")
    else:
        receipt_messages = ["not required"]
    for message in receipt_messages:
        print("  OK:", message)

    print("\n[11/11] Ordered pipeline stage chain")
    if not validator_ok:
        # Never mutate the ordered pipeline to delivery_permitted when the
        # target validator has already blocked the artifact. Receipts for
        # the architecture/integration checks above may exist, but the
        # authoritative stage ledger must remain before output_contracts.
        raise WorldBuilderError(
            f"validator reported {errors} error(s) and {warnings} warning(s)"
            + ("; --require-clean blocks warnings" if args.require_clean else "")
        )
    if state_path is not None:
        ledger = load_pipeline_stage_ledger(root, state)
        amendments = ledger.get("amendments") if isinstance(ledger.get("amendments"), list) else []
        if amendments:
            # The immutable base chain is already complete.  Re-advancing it
            # would demand fresh non-amendment evidence and defeat the
            # amendment sub-ledger.  Verify the base chain plus every
            # amendment decision instead.
            chain = verify_pipeline_stage_chain(state_path, through="delivery_permitted", target=target)
            if len(chain.get("verified_amendments", [])) != len(amendments):
                raise WorldBuilderError("not every recorded amendment was verified for delivery")
            print("  OK:", len(chain.get("verified_stages", [])), "immutable base stage receipts verified")
            print("  OK:", len(chain.get("verified_amendments", [])), "amendment ledger entr" + ("y" if len(amendments) == 1 else "ies"), "verified")
        else:
            advance_pipeline_stage(state_path, "output_contracts", target)
            advance_pipeline_stage(state_path, "runtime_adapter", target)
            advance_pipeline_stage(state_path, "integration_output", target)
            advance_pipeline_stage(state_path, "delivery_permitted", target)
            chain = verify_pipeline_stage_chain(state_path, through="delivery_permitted", target=target)
            print("  OK:", len(chain.get("verified_stages", [])), "ordered stage receipts verified")
        print("  OK: skipped applicable stages are impossible to deliver")
    else:
        print("  OK: standalone legacy mode has no ordered build-state chain")

    final_sha = sha256_file(target)
    if state is not None and state_path is not None:
        state.setdefault("status", {})["delivery"] = "permitted"
        state.setdefault("lineage", {})["final"] = {
            "path": relative_or_absolute(target, root),
            "sha256": final_sha,
            "validated_at": now_iso(),
            "profile": args.profile if kind == "json" else "worldbuilder-persona",
        }
        atomic_write_json(state_path, state)
    print("\n✅ DELIVERY PERMITTED")
    print(f"SHA-256: {final_sha}")
    return 0


def main() -> int:
    parser = build_argument_parser()
    args = parser.parse_args()
    if args.requirements:
        if not args.build_state:
            parser.error("--requirements needs --build-state")
        root, state = load_build_state(args.build_state)
        print(json.dumps(preflight_report("delivery_gate", requirement_rows(Path(__file__), root, state)), ensure_ascii=False, indent=2))
        return 0
    try:
        return orchestrate(args, parser)
    except (WorldBuilderError, OSError, json.JSONDecodeError, ValueError) as exc:
        print(f"\n⛔ DELIVERY BLOCKED: {exc}", file=sys.stderr)
        print(step_driver_pointer(), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
