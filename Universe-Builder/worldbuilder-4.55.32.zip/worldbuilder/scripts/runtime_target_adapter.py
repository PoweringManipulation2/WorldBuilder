#!/usr/bin/env python3
"""WorldBuilder semantic IR and versioned target adapters.

The parent imports supported card/lorebook artifacts into a neutral semantic
representation, emits a named target, validates the emitted target, reopens it,
and verifies that the represented semantics survived. Application-specific
fields are never written directly into portable CCv3 objects.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import sys
import tempfile
import zipfile
from pathlib import Path
from typing import Any, Iterable

from dynamic_state_contract import CONTRACT as DYNAMIC_CONTRACT, ENVELOPE_KEY
from validate_output import validate as validate_output_artifact
from sillytavern_import_probe import probe_artifact as probe_sillytavern_artifact
from wb_common import (
    step_driver_pointer,
    WorldBuilderError,
    atomic_write_json,
    canonical_entry_identity,
    detect_artifact,
    get_lorebook_container,
    iter_entries,
    load_build_state,
    load_json,
    load_json_strict,
    resolve_state_path,
    safe_archive_path,
    sha256_file,
    uid_key,
)

IR_KIND = "worldbuilder-semantic-ir"
IR_VERSION = 2
ADAPTER_CONTRACT = "worldbuilder-runtime-target-adapter-v2"
ADAPTER_VERSION = 3
# Batch 7, 7.9: a persistent provenance marker, stamped only via
# serialize_build_state (never the standalone INPUT/OUTPUT conversion path,
# which has no build to claim provenance from). Found during this batch: no
# delivered artifact previously carried ANY marker identifying it as
# WorldBuilder-produced once its workspace was gone; capability-tier
# detection (capability_tiers.py) needs this to recognize Legacy-bound
# artifacts at all. Stamped into ir BEFORE export_target runs, not after,
# so both sides of roundtrip verification's semantic_projection comparison
# see it consistently; stamping it post-hoc would make every export fail
# roundtrip verification, since semantic_projection deep-copies the entire
# extensions dict for comparison.
PROVENANCE_KEY = "worldbuilder_provenance"
WORLDBUILDER_VERSION = (Path(__file__).resolve().parent.parent / "VERSION").read_text(encoding="utf-8").strip()
RECEIPT_KIND = "worldbuilder-runtime-target-receipt"
COMPATIBILITY_KIND = "worldbuilder-target-compatibility-report"
RUNTIME_PACKAGE_CONTRACT = "worldbuilder-runtime-package-v1"
RECOMMENDED_SETTINGS_KIND = "worldbuilder-recommended-settings"
BUNDLE_MANIFEST_KIND = "worldbuilder-runtime-bundle-manifest"
BUNDLE_RECEIPT_KIND = "worldbuilder-runtime-bundle-receipt"
ST_PROFILE = "sillytavern-1.18.0"
ST_VERSION = "1.18.0"
PORTABLE_PROFILE = "portable-ccv3-v3"
RUNTIME_PROFILES = {PORTABLE_PROFILE, ST_PROFILE}

RUNTIME_ENVELOPE_KEY = "worldbuilder_runtime"
RUNTIME_CONTRACT = "worldbuilder-runtime-semantics-v1"
ST_REGEX_ENVELOPE_KEY = "worldbuilder_sillytavern_regex"
ST_REGEX_CONTRACT = "worldbuilder-sillytavern-regex-translation-v1"
PRESERVED_ARTIFACT_KEY = "worldbuilder_preserved_artifact_fields"
PRESERVED_CARD_KEY = "worldbuilder_preserved_card_fields"
PRESERVED_BOOK_KEY = "worldbuilder_preserved_lorebook_fields"
PRESERVED_ENTRY_KEY = "worldbuilder_preserved_entry_fields"
PRESERVED_DECORATORS_KEY = "worldbuilder_preserved_decorators"

TARGETS = {
    "preserve", "schema1-character", "ccv3-embedded", "lorebook-v3",
    "sillytavern-native", "charx", "group-set", "persona-lorebook",
}

CARD_FIELDS = (
    "name", "description", "personality", "scenario", "first_mes", "mes_example",
    "creator_notes", "system_prompt", "post_history_instructions", "alternate_greetings",
    "group_only_greetings", "tags", "creator", "character_version", "nickname",
    "creator_notes_multilingual", "source", "creation_date", "modification_date",
)
BOOK_FIELDS = ("name", "description", "scan_depth", "token_budget", "recursive_scanning")
CORE_ENTRY_FIELDS = {
    "id", "uid", "name", "comment", "keys", "key", "secondary_keys", "keysecondary",
    "content", "enabled", "disable", "insertion_order", "order", "use_regex", "case_sensitive",
    "caseSensitive", "constant", "selective", "selectiveLogic", "position", "priority",
    "extensions", "character_filter", "characterFilter",
}
OUTLET_POSITION = 7  # Confirmed against SillyTavern/SillyTavern PR #4523 (merged 2025-09-18): "Added a new 'Outlet' position option (value=\"7\")", real, current, not assumed.

MATCH_TO_CCV3 = {
    "persona_description": "match_persona_description",
    "character_description": "match_character_description",
    "character_personality": "match_character_personality",
    "character_note": "match_character_depth_prompt",
    "scenario": "match_scenario",
    "creator_notes": "match_creator_notes",
}
MATCH_TO_NATIVE = {
    "persona_description": "matchPersonaDescription",
    "character_description": "matchCharacterDescription",
    "character_personality": "matchCharacterPersonality",
    "character_note": "matchCharacterDepthPrompt",
    "scenario": "matchScenario",
    "creator_notes": "matchCreatorNotes",
}
RUNTIME_ALIASES: dict[str, tuple[str, ...]] = {
    "position": ("position", "position"),
    "selective_logic": ("selectiveLogic", "selectiveLogic"),
    "case_sensitive": ("caseSensitive", "case_sensitive"),
    "vectorized": ("vectorized",),
    "exclude_recursion": ("excludeRecursion", "exclude_recursion"),
    "prevent_recursion": ("preventRecursion", "prevent_recursion"),
    "delay_until_recursion": ("delayUntilRecursion", "delay_until_recursion"),
    "display_index": ("displayIndex", "display_index"),
    "depth": ("depth",),
    "role": ("role",),
    "scan_depth": ("scanDepth", "scan_depth"),
    "match_whole_words": ("matchWholeWords", "match_whole_words"),
    "ignore_budget": ("ignoreBudget", "ignore_budget"),
}
NATIVE_RUNTIME_FIELDS = {name for aliases in RUNTIME_ALIASES.values() for name in aliases}
NATIVE_DYNAMIC_FIELDS = {
    "probability", "useProbability", "group", "groupOverride", "groupWeight", "useGroupScoring",
    "sticky", "cooldown", "delay", "triggers", "automationId", "outletName", "characterFilter",
    *MATCH_TO_NATIVE.values(),
}
CCV3_DYNAMIC_FIELDS = {
    "probability", "useProbability", "use_probability", "group", "group_override", "groupOverride",
    "group_weight", "groupWeight", "use_group_scoring", "useGroupScoring", "sticky", "cooldown",
    "delay", "triggers", "automation_id", "automationId", "outlet_name", "outletName",
    "character_filter", "characterFilter", *MATCH_TO_CCV3.values(), *MATCH_TO_NATIVE.values(),
}


def _json_hash(value: Any) -> str:
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def _str_list(value: Any, label: str) -> list[str]:
    if value is None:
        return []
    if not isinstance(value, list) or any(not isinstance(item, str) for item in value):
        raise WorldBuilderError(f"{label} must be an array of strings")
    return list(value)


def _extensions(value: Any, label: str) -> dict[str, Any]:
    if value is None:
        return {}
    if not isinstance(value, dict):
        raise WorldBuilderError(f"{label} must be an object")
    return copy.deepcopy(value)


def _unknown(source: dict[str, Any], known: Iterable[str]) -> dict[str, Any]:
    known_set = set(known)
    return {key: copy.deepcopy(value) for key, value in source.items() if key not in known_set}


def _pop_object(container: dict[str, Any], key: str) -> dict[str, Any]:
    value = container.pop(key, {})
    return copy.deepcopy(value) if isinstance(value, dict) else {}


def _first_present(source: dict[str, Any], aliases: tuple[str, ...]) -> tuple[bool, Any]:
    for name in aliases:
        if name in source:
            return True, copy.deepcopy(source[name])
    return False, None


def _escape_st_regex_pattern(pattern: str) -> str:
    """Escape unescaped slash delimiters for SillyTavern's /pattern/flags syntax."""
    if not pattern:
        raise WorldBuilderError("SillyTavern regex translation requires a non-empty pattern")
    out: list[str] = []
    backslashes = 0
    for char in pattern:
        if char == "/" and backslashes % 2 == 0:
            out.append("\\/")
        else:
            out.append(char)
        if char == "\\":
            backslashes += 1
        else:
            backslashes = 0
    return "".join(out)


def _st_regex_literal(pattern: str, *, case_sensitive: Any) -> str:
    flags = "i" if case_sensitive is False else ""
    return f"/{_escape_st_regex_pattern(pattern)}/{flags}"


def _runtime_regex_view(
    entry: dict[str, Any], ext: dict[str, Any], report: dict[str, Any]
) -> tuple[list[str], list[str], bool, bool]:
    """Return ST-active keys while preserving CCv3 regex semantics in an envelope."""
    keys = list(entry.get("keys", []))
    secondary = list(entry.get("secondary_keys", []))
    selective = bool(entry.get("selective", False))
    constant = bool(entry.get("constant", False))
    if not bool(entry.get("use_regex", False)):
        return keys, secondary, selective, constant
    ext[ST_REGEX_ENVELOPE_KEY] = {
        "contract": ST_REGEX_CONTRACT,
        "keys": copy.deepcopy(keys),
        "secondary_keys": copy.deepcopy(secondary),
        "selective": selective,
        "constant": constant,
    }
    translated = [_st_regex_literal(value, case_sensitive=entry.get("case_sensitive")) for value in keys]
    report.setdefault("regex_translations", 0)
    report["regex_translations"] += 1
    report["warnings"].append(
        f"entry {entry.get('identity')}: CCv3 use_regex was translated to SillyTavern slash-delimited keys; "
        "secondary-key and constant flags were disabled in the runtime view because SillyTavern ignores use_regex"
    )
    return translated, [], False, False


def _restore_regex_semantics(
    ext: dict[str, Any], keys: list[str], secondary: list[str], selective: bool, constant: bool, use_regex: bool
) -> tuple[list[str], list[str], bool, bool, bool]:
    envelope = ext.pop(ST_REGEX_ENVELOPE_KEY, None)
    if envelope is None:
        return keys, secondary, selective, constant, use_regex
    if not isinstance(envelope, dict) or envelope.get("contract") != ST_REGEX_CONTRACT:
        raise WorldBuilderError("worldbuilder_sillytavern_regex envelope is malformed or unsupported")
    original_keys = envelope.get("keys")
    original_secondary = envelope.get("secondary_keys", [])
    if not isinstance(original_keys, list) or any(not isinstance(value, str) for value in original_keys):
        raise WorldBuilderError("worldbuilder_sillytavern_regex.keys must be an array of strings")
    if not isinstance(original_secondary, list) or any(not isinstance(value, str) for value in original_secondary):
        raise WorldBuilderError("worldbuilder_sillytavern_regex.secondary_keys must be an array of strings")
    return (
        list(original_keys),
        list(original_secondary),
        bool(envelope.get("selective", False)),
        bool(envelope.get("constant", False)),
        True,
    )


def _runtime_from_source(entry: dict[str, Any], ext: dict[str, Any], *, native: bool) -> dict[str, Any] | None:
    neutral = ext.pop(RUNTIME_ENVELOPE_KEY, None)
    result: dict[str, Any] = {}
    if neutral is not None:
        if not isinstance(neutral, dict) or neutral.get("contract") != RUNTIME_CONTRACT:
            raise WorldBuilderError("worldbuilder_runtime envelope is malformed or unsupported")
        fields = neutral.get("fields", {})
        if not isinstance(fields, dict):
            raise WorldBuilderError("worldbuilder_runtime.fields must be an object")
        result.update(copy.deepcopy(fields))
    source = entry if native else ext
    for semantic, aliases in RUNTIME_ALIASES.items():
        present, value = _first_present(source, aliases)
        if present:
            result[semantic] = value
        for alias in aliases:
            if not native:
                ext.pop(alias, None)
    if not native and "position" in ext:
        result["position"] = copy.deepcopy(ext.pop("position"))
    if not native and "selective_logic" in ext:
        result["selective_logic"] = copy.deepcopy(ext.pop("selective_logic"))
    return {"contract": RUNTIME_CONTRACT, "fields": result} if result else None


def _dynamic_from_entry(ext: dict[str, Any]) -> dict[str, Any] | None:
    value = ext.pop(ENVELOPE_KEY, None)
    if value is None:
        return None
    if not isinstance(value, dict) or value.get("contract") != DYNAMIC_CONTRACT:
        raise WorldBuilderError("worldbuilder_dynamic envelope is malformed or unsupported")
    normalized = copy.deepcopy(value)
    probability = int(normalized.get("probability", 100))
    normalized.setdefault("probability_enabled", probability != 100)
    for key in ("automation_id", "named_outlet", "character_filter"):
        if normalized.get(key) is None:
            normalized.pop(key, None)
    timed = normalized.get("timed_effects")
    if isinstance(timed, dict):
        normalized["timed_effects"] = {
            key: amount for key, amount in timed.items() if isinstance(amount, int) and amount > 0
        }
        if not normalized["timed_effects"]:
            normalized.pop("timed_effects")
    return normalized


def _dynamic_from_runtime(entry: dict[str, Any], ext: dict[str, Any], *, native: bool) -> dict[str, Any] | None:
    source = entry if native else ext
    probability_present = "probability" in source
    use_names = ("useProbability",) if native else ("useProbability", "use_probability")
    use_present, use_value = _first_present(source, use_names)
    probability = int(source.get("probability", 100) if probability_present else 100)
    probability_enabled = bool(use_value) if use_present else probability != 100

    group_text = source.get("group", "")
    groups: list[dict[str, Any]] = []
    if isinstance(group_text, str) and group_text.strip():
        priority_key = "groupOverride" if native else "group_override"
        scoring_key = "useGroupScoring" if native else "use_group_scoring"
        weight_key = "groupWeight" if native else "group_weight"
        selection = "priority" if bool(source.get(priority_key, source.get("groupOverride", False))) else "weighted_random"
        weight = source.get(weight_key, source.get("groupWeight", 100))
        scoring = bool(source.get(scoring_key, source.get("useGroupScoring", False)))
        for name in [part.strip() for part in group_text.split(",") if part.strip()]:
            groups.append({"group_id": name, "selection": selection, "weight": int(weight), "group_scoring": scoring})

    timed = {key: int(source.get(key, 0) or 0) for key in ("sticky", "cooldown", "delay")}
    matching = ["chat"]
    mapping = MATCH_TO_NATIVE if native else MATCH_TO_CCV3
    for semantic, field in mapping.items():
        if source.get(field) is True:
            matching.append(semantic)

    filter_names = ("characterFilter",) if native else ("character_filter", "characterFilter")
    filter_present, filter_value = _first_present(source, filter_names)
    character_filter = None
    if filter_present and isinstance(filter_value, dict):
        names = list(filter_value.get("names", [])) if isinstance(filter_value.get("names", []), list) else []
        tags = list(filter_value.get("tags", [])) if isinstance(filter_value.get("tags", []), list) else []
        if names or tags:
            character_filter = {
                "mode": "exclude" if bool(filter_value.get("isExclude", False)) else "include",
                "names": [str(v) for v in names],
                "tags": [str(v) for v in tags],
                "runtime_character_ids": bool(names),
                "runtime_tag_ids": bool(tags),
            }

    triggers = source.get("triggers", [])
    if not isinstance(triggers, list):
        raise WorldBuilderError("runtime triggers must be an array")
    automation = source.get("automationId" if native else "automation_id", source.get("automationId"))
    outlet = source.get("outletName" if native else "outlet_name", source.get("outletName"))
    any_runtime_field = any(name in source for name in (NATIVE_DYNAMIC_FIELDS if native else CCV3_DYNAMIC_FIELDS))
    active = any_runtime_field or probability_present or use_present or bool(groups) or any(timed.values()) or len(matching) > 1 or character_filter is not None or bool(triggers) or bool(automation) or bool(outlet)
    if not active:
        return None
    result = {
        "contract": DYNAMIC_CONTRACT,
        "purpose": "imported_runtime_behavior",
        "probability": probability,
        "probability_enabled": probability_enabled,
        "groups": groups,
        "matching_sources": matching,
        "generation_triggers": [str(value) for value in triggers],
        "greeting_variants": [],
    }
    if any(timed.values()):
        result["timed_effects"] = {key: value for key, value in timed.items() if value}
    if character_filter is not None:
        result["character_filter"] = character_filter
    if automation:
        result["automation_id"] = str(automation)
    if outlet:
        result["named_outlet"] = str(outlet)
    return result


def _neutral_entry(entry: dict[str, Any], source_format: str) -> dict[str, Any]:
    identity = canonical_entry_identity(entry)
    if identity is None:
        raise WorldBuilderError("every lorebook entry requires a stable id/uid")
    native = source_format == "sillytavern-native"
    keys = entry.get("key" if native else "keys", [])
    secondary = entry.get("keysecondary" if native else "secondary_keys", [])
    enabled = not bool(entry.get("disable", False)) if native else bool(entry.get("enabled", True))
    order = entry.get("order", 100) if native else entry.get("insertion_order", 100)
    if not isinstance(order, int) or isinstance(order, bool):
        raise WorldBuilderError(f"entry {identity} insertion order must be an integer")
    ext = _extensions(entry.get("extensions"), f"entry {identity}.extensions")
    preserved = _pop_object(ext, PRESERVED_ENTRY_KEY)
    preserved_decorators = copy.deepcopy(ext.pop(PRESERVED_DECORATORS_KEY, [])) if native else []
    content = str(entry.get("content", ""))
    if not native:
        # Batch 9: decorators are the portable emission form for
        # depth/role/activate_only_after; recognized here and injected
        # into ext under the exact keys _runtime_from_source and
        # _dynamic_from_runtime already read (RUNTIME_ALIASES's "depth"/
        # "role", and timed_effects's "delay"), so this reuses their
        # existing, already-proven construction logic rather than
        # building a second, parallel path. Content is stripped of the
        # decorator block before it becomes this entry's content; the
        # entries are never real content, matching the fact that
        # actual_entry_token_measurement (budget_contract.py) already
        # excludes them from counting for the same reason.
        from decorators import parse_leading_decorators, first_effective_value

        found_decorators, content = parse_leading_decorators(content)
        preserved_decorators = [
            {"name": d.name, "value": d.value, "is_fallback": bool(d.is_fallback)} for d in found_decorators
        ]
        depth_value = first_effective_value(found_decorators, "depth")
        role_value = first_effective_value(found_decorators, "role")
        activate_after_value = first_effective_value(found_decorators, "activate_only_after")
        if depth_value is not None and "depth" not in ext:
            ext["depth"] = int(float(depth_value))
        if role_value is not None and "role" not in ext:
            ext["role"] = role_value
        if activate_after_value is not None and "delay" not in ext:
            ext["delay"] = int(float(activate_after_value))
    keys = _str_list(keys, f"entry {identity}.keys")
    secondary = _str_list(secondary, f"entry {identity}.secondary_keys")
    selective = bool(entry.get("selective", False))
    constant = bool(entry.get("constant", False))
    use_regex = bool(entry.get("use_regex", False))
    keys, secondary, selective, constant, use_regex = _restore_regex_semantics(
        ext, keys, secondary, selective, constant, use_regex
    )
    dynamic = _dynamic_from_entry(ext)
    if dynamic is None:
        dynamic = _dynamic_from_runtime(entry, ext, native=native)
    if not native:
        # Exact SillyTavern application fields are represented by the neutral
        # dynamic/runtime envelopes, not preserved a second time as vendor data.
        for key in CCV3_DYNAMIC_FIELDS:
            ext.pop(key, None)
    runtime = _runtime_from_source(entry, ext, native=native)
    position = copy.deepcopy(entry.get("position", 1 if native else "after_char"))
    selective_logic = copy.deepcopy(entry.get("selectiveLogic"))
    case_sensitive = copy.deepcopy(entry.get("caseSensitive") if native else entry.get("case_sensitive"))
    if isinstance(runtime, dict) and isinstance(runtime.get("fields"), dict) and "position" in runtime["fields"]:
        position = copy.deepcopy(runtime["fields"].pop("position"))
    if isinstance(runtime, dict) and isinstance(runtime.get("fields"), dict) and "selective_logic" in runtime["fields"]:
        selective_logic = copy.deepcopy(runtime["fields"].pop("selective_logic"))
    if isinstance(runtime, dict) and isinstance(runtime.get("fields"), dict) and "case_sensitive" in runtime["fields"]:
        case_sensitive = copy.deepcopy(runtime["fields"].pop("case_sensitive"))
    if isinstance(runtime, dict) and isinstance(runtime.get("fields"), dict) and not runtime["fields"]:
        runtime = None
    unknown_fields = {**preserved, **_unknown(entry, CORE_ENTRY_FIELDS)}
    if native:
        for key in NATIVE_DYNAMIC_FIELDS | NATIVE_RUNTIME_FIELDS:
            unknown_fields.pop(key, None)
    return {
        "identity": identity,
        "name": str(entry.get("name", entry.get("comment", ""))),
        "comment": str(entry.get("comment", entry.get("name", ""))),
        "keys": keys,
        "secondary_keys": secondary,
        "content": content,
        "enabled": enabled,
        "insertion_order": order,
        "use_regex": use_regex,
        "case_sensitive": case_sensitive,
        "constant": constant,
        "selective": selective,
        "selective_logic": selective_logic,
        "position": position,
        "priority": entry.get("priority"),
        "runtime": runtime,
        "dynamic": copy.deepcopy(dynamic) if dynamic is not None else None,
        "decorators": preserved_decorators,
        "extensions": ext,
        "unknown": unknown_fields,
    }


def detect_source_format(data: Any) -> str:
    if isinstance(data, dict) and data.get("kind") == "worldbuilder-group-set-v1":
        return "group-set"
    if isinstance(data, dict) and data.get("kind") == "worldbuilder-persona-package-v1":
        return "persona-lorebook"
    info = detect_artifact(data)
    return {
        "card_v3": "schema1-character",
        "card_v3_embedded": "ccv3-embedded",
        "lorebook_v3": "lorebook-v3",
        "sillytavern_world_info": "sillytavern-native",
    }.get(info.kind, "unknown")


def import_ir(data: Any, *, persona_text: str | None = None) -> dict[str, Any]:
    source_format = detect_source_format(data)
    if source_format == "unknown":
        raise WorldBuilderError("unsupported source artifact for semantic IR import")
    if source_format == "group-set":
        if not isinstance(data.get("characters"), list) or not isinstance(data.get("shared_lorebook"), dict):
            raise WorldBuilderError("group-set requires characters array and shared_lorebook")
        characters = [import_ir(card) for card in data["characters"]]
        lore = import_ir(data["shared_lorebook"])
        return {
            "kind": IR_KIND, "ir_version": IR_VERSION, "source_format": source_format,
            "card": None, "lorebook": lore.get("lorebook"), "assets": [],
            "group_characters": [
                {**copy.deepcopy(row.get("card") or {}), "assets": copy.deepcopy(row.get("assets", []))}
                for row in characters
            ], "persona_text": None,
            "source_metadata": copy.deepcopy(data.get("source_metadata", {})),
            "unknown": _unknown(data, {"kind", "characters", "shared_lorebook", "source_metadata"}),
        }
    if source_format == "persona-lorebook":
        text = data.get("persona_text")
        if not isinstance(text, str):
            raise WorldBuilderError("persona-lorebook requires persona_text")
        lore = data.get("lorebook")
        lore_ir = import_ir(lore) if isinstance(lore, dict) else None
        return {
            "kind": IR_KIND, "ir_version": IR_VERSION, "source_format": source_format,
            "card": None, "lorebook": lore_ir.get("lorebook") if lore_ir else None,
            "assets": [], "group_characters": [], "persona_text": text,
            "source_metadata": copy.deepcopy(data.get("source_metadata", {})),
            "unknown": _unknown(data, {"kind", "persona_text", "lorebook", "source_metadata"}),
        }

    info = detect_artifact(data)
    payload = data.get("data") if isinstance(data, dict) and isinstance(data.get("data"), dict) else {}
    top_unknown = _unknown(data, {"spec", "spec_version", "data", "entries", *BOOK_FIELDS, "extensions"})
    card = None
    assets: list[Any] = []
    if source_format in {"schema1-character", "ccv3-embedded"}:
        card_ext = _extensions(payload.get("extensions"), "card.extensions")
        top_unknown = {**_pop_object(card_ext, PRESERVED_ARTIFACT_KEY), **top_unknown}
        card_unknown = {**_pop_object(card_ext, PRESERVED_CARD_KEY), **_unknown(payload, set(CARD_FIELDS) | {"extensions", "character_book", "assets"})}
        card = {
            "fields": {field: copy.deepcopy(payload[field]) for field in CARD_FIELDS if field in payload},
            "extensions": card_ext,
            "unknown": card_unknown,
        }
        assets = copy.deepcopy(payload.get("assets", [])) if isinstance(payload.get("assets", []), list) else []

    container = get_lorebook_container(data, info)
    lorebook = None
    if isinstance(container, dict):
        lore_ext = _extensions(container.get("extensions"), "lorebook.extensions")
        artifact_preserved = _pop_object(lore_ext, PRESERVED_ARTIFACT_KEY)
        if source_format in {"lorebook-v3", "sillytavern-native"}:
            top_unknown = {**artifact_preserved, **top_unknown}
        book_unknown = {**_pop_object(lore_ext, PRESERVED_BOOK_KEY), **_unknown(container, set(BOOK_FIELDS) | {"extensions", "entries"})}
        if source_format == "sillytavern-native" and not artifact_preserved:
            book_unknown = {**top_unknown, **book_unknown}
            top_unknown = {}
        lorebook = {
            "metadata": {field: copy.deepcopy(container[field]) for field in BOOK_FIELDS if field in container},
            "extensions": lore_ext,
            "entries": [_neutral_entry(ref.entry, source_format) for ref in iter_entries(data)],
            "container_style": "object" if isinstance(container.get("entries"), dict) else "array",
            "unknown": book_unknown,
        }
    return {
        "kind": IR_KIND, "ir_version": IR_VERSION, "source_format": source_format,
        "card": card, "lorebook": lorebook, "assets": assets,
        "group_characters": [], "persona_text": persona_text,
        "source_metadata": {"spec": data.get("spec"), "spec_version": data.get("spec_version")},
        "unknown": top_unknown,
    }


def validate_ir(ir: Any) -> None:
    if not isinstance(ir, dict) or ir.get("kind") != IR_KIND or ir.get("ir_version") != IR_VERSION:
        raise WorldBuilderError("semantic IR kind/version is unsupported")
    if ir.get("card") is None and ir.get("lorebook") is None and not ir.get("group_characters") and ir.get("persona_text") is None:
        raise WorldBuilderError("semantic IR contains no card, lorebook, group, or persona data")
    book = ir.get("lorebook")
    if book is not None:
        if not isinstance(book, dict) or not isinstance(book.get("entries"), list):
            raise WorldBuilderError("semantic IR lorebook.entries must be an array")
        seen: set[str] = set()
        for entry in book["entries"]:
            if not isinstance(entry, dict):
                raise WorldBuilderError("semantic IR entries must be objects")
            key = uid_key(entry.get("identity"))
            if key in seen:
                raise WorldBuilderError(f"semantic IR repeats entry identity {key}")
            seen.add(key)
            if not isinstance(entry.get("content"), str):
                raise WorldBuilderError(f"semantic IR entry {key} content must be text")


def _group_fields(groups: list[dict[str, Any]]) -> dict[str, Any]:
    if not groups:
        return {}
    selections = {row.get("selection") for row in groups}
    scorings = {bool(row.get("group_scoring", row.get("use_group_scoring", False))) for row in groups}
    weights = {row.get("weight", 100) for row in groups}
    if len(selections) != 1:
        raise WorldBuilderError("one entry uses mixed priority and weighted inclusion groups; target mapping would be lossy")
    if len(scorings) != 1:
        raise WorldBuilderError("one entry uses mixed group-scoring policies; target mapping would be lossy")
    if len(weights) != 1:
        raise WorldBuilderError("one entry uses different weights across groups; target mapping would be lossy")
    return {
        "group": ", ".join(str(row.get("group_id")) for row in groups),
        "priority": next(iter(selections)) == "priority",
        "scoring": next(iter(scorings)), "weight": next(iter(weights)),
    }


def _load_string_map(path: str | None, label: str) -> dict[str, str]:
    if not path:
        return {}
    raw = load_json(path)
    if not isinstance(raw, dict):
        raise WorldBuilderError(f"{label} must be an object")
    result: dict[str, str] = {}
    for key, value in raw.items():
        if not isinstance(key, str) or not key.strip() or not isinstance(value, str) or not value.strip():
            raise WorldBuilderError(f"{label} keys and values must be non-empty strings")
        result[key.strip()] = value.strip()
    return result


def load_tag_map(path: str | None) -> dict[str, str]:
    return _load_string_map(path, "tag map")


def load_character_map(path: str | None) -> dict[str, str]:
    return _load_string_map(path, "character map")


def load_asset_map(path: str | None) -> dict[str, Path]:
    if not path:
        return {}
    raw = load_json(path)
    if not isinstance(raw, dict):
        raise WorldBuilderError("CHARX asset map must be an object of embedded URI to source path")
    result: dict[str, Path] = {}
    for uri, value in raw.items():
        if not isinstance(uri, str) or not uri.startswith("embeded://") or not isinstance(value, str) or not value.strip():
            raise WorldBuilderError("CHARX asset map requires embeded:// URI keys and non-empty path values")
        source = Path(value).expanduser().resolve()
        if not source.is_file() or source.is_symlink():
            raise WorldBuilderError(f"CHARX asset source is missing or unsafe: {source}")
        result[uri] = source
    return result


def _map_filter_values(values: list[Any], mapping: dict[str, str], *, already_runtime: bool, label: str) -> list[str]:
    if already_runtime:
        return [str(value) for value in values]
    result: list[str] = []
    for value in values:
        key = str(value)
        if key not in mapping:
            if label == "tag":
                raise WorldBuilderError(f"character filter tag {key!r} lacks an explicit SillyTavern tag-ID map")
            raise WorldBuilderError(
                f"character filter character {key!r} lacks an explicit SillyTavern character filename-stem map"
            )
        result.append(mapping[key])
    return result


def _dynamic_runtime_fields(dynamic: dict[str, Any] | None, *, native: bool, tag_map: dict[str, str], character_map: dict[str, str], allow_neutral_only: bool, report: dict[str, Any]) -> dict[str, Any]:
    if not dynamic:
        return {}
    if dynamic.get("contract") != DYNAMIC_CONTRACT:
        raise WorldBuilderError("dynamic envelope contract is unsupported")
    target: dict[str, Any] = {}
    probability = int(dynamic.get("probability", 100))
    enabled = bool(dynamic.get("probability_enabled", probability != 100))
    if probability != 100 or "probability_enabled" in dynamic:
        target["probability"] = probability
        target["useProbability"] = enabled
    groups = dynamic.get("groups", [])
    if groups:
        fields = _group_fields(groups)
        target["group"] = fields["group"]
        target["groupOverride" if native else "group_override"] = fields["priority"]
        target["groupWeight" if native else "group_weight"] = fields["weight"]
        target["useGroupScoring" if native else "use_group_scoring"] = fields["scoring"]
    timed = dynamic.get("timed_effects", {})
    if isinstance(timed, dict):
        for key in ("sticky", "cooldown", "delay"):
            if int(timed.get(key, 0) or 0):
                target[key] = int(timed[key])
    matching = dynamic.get("matching_sources", ["chat"])
    if "chat" not in matching:
        raise WorldBuilderError("SillyTavern always scans chat; excluding chat is not losslessly representable")
    mapping = MATCH_TO_NATIVE if native else MATCH_TO_CCV3
    for neutral, field in mapping.items():
        if neutral in matching:
            target[field] = True
    char_filter = dynamic.get("character_filter")
    if isinstance(char_filter, dict):
        if not native:
            message = (
                "SillyTavern 1.18.0 convertCharacterBook preserves extensions.character_filter "
                "but does not activate it; use SillyTavern-native World Info for active character filters"
            )
            if not allow_neutral_only:
                raise WorldBuilderError(message)
            # Keep the named extension beside the versioned WorldBuilder
            # envelope so the exact source intent survives applications that
            # retain unknown CCv3 extension data.  SillyTavern 1.18.0 does not
            # promote this object to active native ``characterFilter`` data.
            target["character_filter"] = copy.deepcopy(char_filter)
            report["warnings"].append(message + "; neutral semantics were preserved only")
            report["neutral_only"] = True
            report["active_setting_compatible"] = False
        else:
            names = _map_filter_values(
                list(char_filter.get("names", [])), character_map,
                already_runtime=bool(char_filter.get("runtime_character_ids")), label="character",
            )
            tags = _map_filter_values(
                list(char_filter.get("tags", [])), tag_map,
                already_runtime=bool(char_filter.get("runtime_tag_ids")), label="tag",
            )
            target["characterFilter"] = {
                "isExclude": char_filter.get("mode") == "exclude", "names": names, "tags": tags,
            }
    triggers = [str(value) for value in dynamic.get("generation_triggers", [])]
    if triggers:
        target["triggers"] = triggers
    if dynamic.get("automation_id"):
        target["automationId" if native else "automation_id"] = dynamic["automation_id"]
        report["warnings"].append("automation IDs require matching Quick Reply/STscript commands at runtime")
    if dynamic.get("named_outlet"):
        target["position"] = OUTLET_POSITION
        target["outletName" if native else "outlet_name"] = dynamic["named_outlet"]
        report["warnings"].append("outlet names are exact-case and require a macro-capable prompt field")
    if dynamic.get("greeting_variants"):
        message = "the tested SillyTavern World Info fields do not enforce greeting scope"
        if not allow_neutral_only:
            raise WorldBuilderError(message)
        report["warnings"].append(message + "; neutral semantics were preserved only")
        report["neutral_only"] = True
    return target


def _runtime_target_fields(runtime: dict[str, Any] | None, *, native: bool) -> dict[str, Any]:
    if not runtime:
        return {}
    if runtime.get("contract") != RUNTIME_CONTRACT or not isinstance(runtime.get("fields"), dict):
        raise WorldBuilderError("runtime semantic envelope is malformed")
    fields = runtime["fields"]
    out: dict[str, Any] = {}
    for semantic, value in fields.items():
        aliases = RUNTIME_ALIASES.get(semantic)
        if aliases is None:
            raise WorldBuilderError(f"unsupported runtime semantic field {semantic!r}")
        out[aliases[0] if native else aliases[-1]] = copy.deepcopy(value)
    return out


def _runtime_envelope(entry: dict[str, Any]) -> dict[str, Any] | None:
    fields: dict[str, Any] = {}
    runtime = entry.get("runtime")
    if isinstance(runtime, dict) and isinstance(runtime.get("fields"), dict):
        fields.update(copy.deepcopy(runtime["fields"]))
    position = entry.get("position")
    if position not in {"before_char", "after_char"}:
        fields["position"] = copy.deepcopy(position)
    if entry.get("selective_logic") is not None:
        fields["selective_logic"] = copy.deepcopy(entry.get("selective_logic"))
    return {"contract": RUNTIME_CONTRACT, "fields": fields} if fields else None


def _ccv3_entry(entry: dict[str, Any], *, st_extensions: bool, tag_map: dict[str, str], character_map: dict[str, str], allow_neutral_only: bool, report: dict[str, Any]) -> dict[str, Any]:
    ext = copy.deepcopy(entry.get("extensions", {}))
    if entry.get("dynamic") is not None:
        ext[ENVELOPE_KEY] = copy.deepcopy(entry["dynamic"])
    runtime_envelope = _runtime_envelope(entry)
    if runtime_envelope:
        ext[RUNTIME_ENVELOPE_KEY] = runtime_envelope
    if entry.get("unknown"):
        ext[PRESERVED_ENTRY_KEY] = copy.deepcopy(entry["unknown"])
    position = entry.get("position")
    core_position = position if position in {"before_char", "after_char"} else ("before_char" if position == 0 else "after_char")
    keys = list(entry.get("keys", []))
    secondary_keys = list(entry.get("secondary_keys", []))
    selective = bool(entry.get("selective", False))
    constant = bool(entry.get("constant", False))
    if st_extensions:
        keys, secondary_keys, selective, constant = _runtime_regex_view(entry, ext, report)
    content = entry.get("content", "")
    preserved_decorators = entry.get("decorators") if isinstance(entry.get("decorators"), list) else []
    if preserved_decorators:
        lines = []
        for d in preserved_decorators:
            if not isinstance(d, dict) or not isinstance(d.get("name"), str):
                continue
            prefix = "@@@" if d.get("is_fallback") else "@@"
            value = d.get("value")
            lines.append(prefix + d["name"] + ((" " + str(value)) if value is not None else ""))
        if lines:
            content = "\n".join(lines) + (("\n\n" + content) if content else "")
    out = {
        "id": entry["identity"], "name": entry.get("name", ""), "comment": entry.get("comment", ""),
        "keys": keys, "secondary_keys": secondary_keys,
        "content": content, "enabled": bool(entry.get("enabled", True)),
        "insertion_order": int(entry.get("insertion_order", 100)), "use_regex": bool(entry.get("use_regex", False)),
        "constant": constant, "selective": selective,
        "position": core_position, "extensions": ext,
    }
    if entry.get("case_sensitive") is not None:
        out["case_sensitive"] = bool(entry["case_sensitive"])
    if entry.get("priority") is not None:
        out["priority"] = entry["priority"]
    if st_extensions:
        # Named SillyTavern profile: emit the exact application extension fields
        # that the pinned importer consumes. Portable decorators are not a
        # substitute for these native fields on this profile.
        runtime_fields = _runtime_target_fields(entry.get("runtime"), native=False)
        dynamic_fields = _dynamic_runtime_fields(
            entry.get("dynamic"), native=False, tag_map=tag_map, character_map=character_map,
            allow_neutral_only=allow_neutral_only, report=report,
        )
        out["extensions"].update(runtime_fields)
        out["extensions"].update(dynamic_fields)
        # SillyTavern 1.18 convertCharacterBook reads these values from the
        # application extension object, not from semantically similar top-level
        # fields. Emit the exact spellings used by the release importer.
        if entry.get("selective_logic") is not None:
            out["extensions"]["selectiveLogic"] = copy.deepcopy(entry["selective_logic"])
        if entry.get("case_sensitive") is not None:
            out["extensions"]["case_sensitive"] = bool(entry["case_sensitive"])
        if position not in {"before_char", "after_char"}:
            out["extensions"]["position"] = copy.deepcopy(position)
    else:
        # Portable CCv3 owns overlapping depth/role/timing semantics via the
        # spec decorator stream, never the SillyTavern extension spelling.
        runtime_fields = copy.deepcopy((entry.get("runtime") or {}).get("fields", {})) if isinstance(entry.get("runtime"), dict) else {}
        dynamic = entry.get("dynamic") if isinstance(entry.get("dynamic"), dict) else {}
        timed = dynamic.get("timed_effects") if isinstance(dynamic.get("timed_effects"), dict) else {}
        existing_names = {
            d.get("name") for d in preserved_decorators if isinstance(d, dict)
        }
        decorator_entries: list[tuple[str, Any]] = []
        depth_value = runtime_fields.get("depth")
        if "depth" not in existing_names and isinstance(depth_value, (int, float)) and not isinstance(depth_value, bool):
            decorator_entries.append(("depth", depth_value))
        role_value = runtime_fields.get("role")
        if "role" not in existing_names and role_value in ("assistant", "system", "user"):
            decorator_entries.append(("role", role_value))
        delay_value = timed.get("delay")
        if "activate_only_after" not in existing_names and isinstance(delay_value, (int, float)) and not isinstance(delay_value, bool):
            decorator_entries.append(("activate_only_after", delay_value))
        for key in ("depth", "role", "delay"):
            out["extensions"].pop(key, None)
        if decorator_entries:
            from decorators import prepend_decorators
            out["content"] = prepend_decorators(out["content"], decorator_entries)
    return out


def _native_entry(entry: dict[str, Any], *, tag_map: dict[str, str], character_map: dict[str, str], allow_neutral_only: bool, report: dict[str, Any]) -> dict[str, Any]:
    position = entry.get("position")
    native_position = 0 if position == "before_char" else 1 if position == "after_char" else position
    ext = copy.deepcopy(entry.get("extensions", {}))
    if isinstance(entry.get("decorators"), list) and entry.get("decorators"):
        ext[PRESERVED_DECORATORS_KEY] = copy.deepcopy(entry["decorators"])
    keys, secondary_keys, selective, constant = _runtime_regex_view(entry, ext, report)
    out = {
        **copy.deepcopy(entry.get("unknown", {})),
        "uid": entry["identity"], "key": keys,
        "keysecondary": secondary_keys,
        "comment": entry.get("comment", entry.get("name", "")), "content": entry.get("content", ""),
        "constant": constant, "selective": selective,
        "order": int(entry.get("insertion_order", 100)), "position": native_position,
        "disable": not bool(entry.get("enabled", True)), "extensions": ext,
    }
    if entry.get("dynamic") is not None:
        out["extensions"][ENVELOPE_KEY] = copy.deepcopy(entry["dynamic"])
    runtime_envelope = _runtime_envelope(entry)
    if runtime_envelope:
        out["extensions"][RUNTIME_ENVELOPE_KEY] = runtime_envelope
    if entry.get("selective_logic") is not None:
        out["selectiveLogic"] = entry["selective_logic"]
    if entry.get("case_sensitive") is not None:
        out["caseSensitive"] = entry["case_sensitive"]
    if entry.get("priority") is not None:
        out["priority"] = entry["priority"]
    out.update(_runtime_target_fields(entry.get("runtime"), native=True))
    dynamic_fields = _dynamic_runtime_fields(
        entry.get("dynamic"), native=True, tag_map=tag_map, character_map=character_map,
        allow_neutral_only=allow_neutral_only, report=report,
    )
    if dynamic_fields.get("position") == OUTLET_POSITION:
        out["position"] = OUTLET_POSITION
    out.update(dynamic_fields)
    return out


def _book(ir: dict[str, Any], *, native: bool, st_extensions: bool, tag_map: dict[str, str], character_map: dict[str, str], allow_neutral_only: bool, report: dict[str, Any], include_artifact_unknown: bool = False, canonical_native_container: bool = True) -> dict[str, Any]:
    book = ir.get("lorebook")
    if not isinstance(book, dict):
        raise WorldBuilderError("selected target requires a lorebook in semantic IR")
    if native:
        out = {**copy.deepcopy(book.get("metadata", {}))}
        out["extensions"] = copy.deepcopy(book.get("extensions", {}))
        if include_artifact_unknown and ir.get("unknown"):
            out["extensions"][PRESERVED_ARTIFACT_KEY] = copy.deepcopy(ir["unknown"])
        if book.get("unknown"):
            out["extensions"][PRESERVED_BOOK_KEY] = copy.deepcopy(book["unknown"])
        rows = [_native_entry(row, tag_map=tag_map, character_map=character_map, allow_neutral_only=allow_neutral_only, report=report) for row in book["entries"]]
        if canonical_native_container or book.get("container_style") == "object":
            out["entries"] = {str(row["uid"]): row for row in rows}
        else:
            out["entries"] = rows
        return out
    ext = copy.deepcopy(book.get("extensions", {}))
    if book.get("unknown"):
        ext[PRESERVED_BOOK_KEY] = copy.deepcopy(book["unknown"])
    if include_artifact_unknown and ir.get("unknown"):
        ext[PRESERVED_ARTIFACT_KEY] = copy.deepcopy(ir["unknown"])
    out = {**copy.deepcopy(book.get("metadata", {})), "extensions": ext}
    out["entries"] = [_ccv3_entry(row, st_extensions=st_extensions, tag_map=tag_map, character_map=character_map, allow_neutral_only=allow_neutral_only, report=report) for row in book["entries"]]
    return out


def _card_data(ir: dict[str, Any]) -> dict[str, Any]:
    card = ir.get("card")
    if not isinstance(card, dict):
        raise WorldBuilderError("selected target requires character card fields in semantic IR")
    ext = copy.deepcopy(card.get("extensions", {}))
    if card.get("unknown"):
        ext[PRESERVED_CARD_KEY] = copy.deepcopy(card["unknown"])
    if ir.get("unknown"):
        ext[PRESERVED_ARTIFACT_KEY] = copy.deepcopy(ir["unknown"])
    data = {**copy.deepcopy(card.get("fields", {})), "extensions": ext}
    if ir.get("assets"):
        data["assets"] = copy.deepcopy(ir["assets"])
    return data


def resolve_preserve_target(ir: dict[str, Any], target: str) -> tuple[str, bool]:
    """The single source of truth for what "preserve" resolves to.

    Real-world regression: this exact resolution was independently
    reimplemented in four separate places in this file (emit_json,
    compatibility_report, export_target, validate_build_receipt), and a fix
    applied to one was silently absent from the other three; each had to
    be found and fixed one at a time via failing tests. Every caller must
    use this function instead of re-deriving the resolution itself.

    A standalone lorebook (no card at all: ir["card"] is None,
    ir["lorebook"] present) whose internal working format is "lorebook-v3"
    (WorldBuilder's own non-native representation, used throughout the
    pipeline from the merge step onward, not a deliberate final-delivery
    choice) upgrades "preserve" to "sillytavern-native": the shape
    SillyTavern's real /api/worldinfo/import actually accepts (bare
    top-level "entries", no "spec"/"data" wrapper; confirmed against
    SillyTavern's own source, src/endpoints/worldinfo.js and
    src/endpoints/characters.js). Any explicit, non-"preserve" request
    (including an explicit "lorebook-v3") is untouched by this function;
    it only changes what the unrequested default silently produces.

    Returns (resolved_target, preserve_upgraded_to_native).
    """
    if target != "preserve":
        return target, False
    has_card = ir.get("card") is not None
    has_book = ir.get("lorebook") is not None
    upgraded = str(ir.get("source_format")) == "lorebook-v3" and not has_card and has_book
    return ("sillytavern-native" if upgraded else str(ir.get("source_format") or "preserve")), upgraded


def compatibility_report(ir: dict[str, Any], target: str, *, runtime_profile: str = PORTABLE_PROFILE, allow_lossy: bool = False) -> dict[str, Any]:
    validate_ir(ir)
    if target not in TARGETS:
        raise WorldBuilderError(f"unsupported runtime target {target!r}")
    if runtime_profile not in RUNTIME_PROFILES:
        raise WorldBuilderError(f"unsupported runtime profile {runtime_profile!r}")
    if target == "sillytavern-native":
        runtime_profile = ST_PROFILE
    has_card = isinstance(ir.get("card"), dict)
    has_book = isinstance(ir.get("lorebook"), dict)
    effective_target, preserve_upgraded_to_native = resolve_preserve_target(ir, target)
    direct_routes = {
        "schema1-character": (True, "character-json"),
        "ccv3-embedded": (True, "character-json"),
        "charx": (True, "character-charx"),
        "sillytavern-native": (True, "world-info-json"),
        "lorebook-v3": (False, "portable-interchange-only"),
        "group-set": (False, "worldbuilder-package"),
        "persona-lorebook": (False, "worldbuilder-package"),
    }
    direct_import, import_route = direct_routes.get(effective_target, (False, "unknown"))
    report = {
        "kind": COMPATIBILITY_KIND, "report_version": 3, "contract": ADAPTER_CONTRACT,
        "source_format": ir.get("source_format"), "target": target, "runtime_profile": runtime_profile,
        "supported": True, "lossy": False, "lossy_approved": False, "neutral_only": False,
        "direct_import_compatible": direct_import, "import_route": import_route,
        "active_setting_compatible": True,
        "warnings": [], "unsupported": [], "preserved_unknown": [],
    }
    if target == "schema1-character" and not has_card:
        report["supported"] = False; report["unsupported"].append("target requires card fields")
    if target == "schema1-character" and has_book and ir["lorebook"].get("entries"):
        report["lossy"] = True; report["warnings"].append("embedded/standalone lorebook is omitted from Schema 1")
    if target == "ccv3-embedded" and (not has_card or not has_book):
        report["supported"] = False; report["unsupported"].append("target requires both card fields and lorebook")
    # Batch 58 / A12: a CHARX container does not imply a lorebook. A Schema 1
    # character card is a valid CHARX payload on its own.
    if target == "charx" and not has_card:
        report["supported"] = False; report["unsupported"].append("target requires card fields")
    if target in {"lorebook-v3", "sillytavern-native"} and not has_book:
        report["supported"] = False; report["unsupported"].append("target requires lorebook data")
    if target == "group-set" and not ir.get("group_characters"):
        report["supported"] = False; report["unsupported"].append("target requires group_characters")
    if target == "persona-lorebook" and ir.get("persona_text") is None:
        report["supported"] = False; report["unsupported"].append("target requires persona_text")
    if effective_target == "lorebook-v3":
        report["warnings"].append(
            "lorebook_v3 is a portable Character Card V3 interchange wrapper, not a direct "
            "SillyTavern 1.18.0 World Info import; export sillytavern-native for direct import"
        )
        if runtime_profile == ST_PROFILE:
            report["warnings"].append(
                "the named SillyTavern profile can mirror tested entry fields inside the portable wrapper, "
                "but the wrapper still requires conversion before direct World Info import"
            )
    if has_book:
        entries = ir["lorebook"].get("entries", [])
        has_runtime_semantics = any(row.get("runtime") or row.get("dynamic") for row in entries)
        has_assistant_message_delay = any(
            any(isinstance(d, dict) and d.get("name") == "activate_only_after" for d in (row.get("decorators") or []))
            for row in entries
        )
        if (effective_target == "sillytavern-native" or runtime_profile == ST_PROFILE) and has_assistant_message_delay:
            report["lossy"] = True
            report["active_setting_compatible"] = False
            report["warnings"].append(
                "@@activate_only_after counts assistant/character messages, while SillyTavern native delay counts total chat messages; "
                "automatic translation is not semantics-preserving"
            )
        if effective_target in {"ccv3-embedded", "charx"} and runtime_profile == PORTABLE_PROFILE and has_runtime_semantics:
            report["active_setting_compatible"] = False
            report["warnings"].append(
                "portable CCv3 keeps WorldBuilder runtime/dynamic envelopes for round-trip recovery, "
                "but SillyTavern does not execute those envelopes; use runtime profile sillytavern-1.18.0"
            )
        if effective_target in {"ccv3-embedded", "charx", "sillytavern-native"}:
            metadata = ir["lorebook"].get("metadata", {})
            inactive_book_settings = [
                key for key in ("scan_depth", "token_budget", "recursive_scanning") if key in metadata
            ]
            if inactive_book_settings:
                report["active_setting_compatible"] = False
                report["warnings"].append(
                    "SillyTavern 1.18.0 treats scan depth, token budget, and recursive scanning as global "
                    "World Info settings; imported per-book values are retained only as metadata: "
                    + ", ".join(inactive_book_settings)
                )
            if any(row.get("priority") is not None for row in entries):
                report["active_setting_compatible"] = False
                report["warnings"].append(
                    "CCv3 entry priority has no active SillyTavern World Info field and is preserved only for round trips"
                )
    if ir.get("unknown"):
        report["preserved_unknown"].append("artifact fields relocated to a target extension envelope")
    if has_card and (ir["card"].get("unknown") or ir["card"].get("extensions")):
        report["preserved_unknown"].append("card fields/extensions")
    if has_book and (ir["lorebook"].get("unknown") or ir["lorebook"].get("extensions")):
        report["preserved_unknown"].append("lorebook fields/extensions")
    if report["lossy"]:
        report["lossy_approved"] = bool(allow_lossy)
        if not allow_lossy:
            report["supported"] = False
    return report


def export_png_card(
    ir: dict[str, Any], output: Path, carrier_png_bytes: bytes, *,
    runtime_profile: str = PORTABLE_PROFILE, tag_map: dict[str, str] | None = None,
    character_map: dict[str, str] | None = None, allow_lossy: bool = False, allow_neutral_only: bool = False,
) -> tuple[bytes, dict[str, Any]]:
    """Batch 8, Phase B only: writes a PNG card carrying the exported JSON
    in its ccv3 tEXt chunk. carrier_png_bytes is REQUIRED and every other
    chunk in it (IHDR, IDAT, IEND, the actual image) is preserved byte-
    for-byte; this function has no image-generation capability at all
    (Phase C is stdlib placeholder generation, a separate piece; Batch 10
    is real generation). Reuses emit_json's own ccv3-embedded path
    exactly; the PNG wrapping is the only new thing here, never a
    second, parallel JSON construction.
    """
    from png_card import write_card_json
    from wb_common import atomic_write_bytes, sha256_file

    artifact, report = emit_json(
        ir, "ccv3-embedded", runtime_profile=runtime_profile, tag_map=tag_map,
        character_map=character_map, allow_lossy=allow_lossy, allow_neutral_only=allow_neutral_only,
    )
    png_bytes = write_card_json(carrier_png_bytes, artifact, keyword="ccv3")
    atomic_write_bytes(output, png_bytes)
    report = dict(report)
    report["requested_target"] = "png-card"
    report["target"] = "png-card"
    report["output_sha256"] = sha256_file(output)
    report["carrier_image_sha256"] = hashlib.sha256(carrier_png_bytes).hexdigest()
    return png_bytes, report


def emit_json(ir: dict[str, Any], target: str, *, runtime_profile: str = PORTABLE_PROFILE, tag_map: dict[str, str] | None = None, character_map: dict[str, str] | None = None, allow_lossy: bool = False, allow_neutral_only: bool = False) -> tuple[dict[str, Any], dict[str, Any]]:
    tag_map = tag_map or {}; character_map = character_map or {}
    requested_target = target
    report = compatibility_report(ir, target, runtime_profile=runtime_profile, allow_lossy=allow_lossy)
    if not report["supported"]:
        raise WorldBuilderError("target conversion is unsupported or lossy: " + "; ".join(report["unsupported"] + report["warnings"]))
    if target == "preserve":
        # See resolve_preserve_target's own docstring for why this must go
        # through the shared helper rather than being re-derived here.
        target, preserve_upgraded_to_native = resolve_preserve_target(ir, target)
        report["requested_target"] = requested_target; report["target"] = target
        report["preserve_upgraded_to_native"] = preserve_upgraded_to_native
    st_extensions = runtime_profile == ST_PROFILE
    if target == "schema1-character":
        return {"spec": "chara_card_v3", "spec_version": "3.0", "data": _card_data(ir)}, report
    if target == "ccv3-embedded":
        data = _card_data(ir)
        data["character_book"] = _book(ir, native=False, st_extensions=st_extensions, tag_map=tag_map, character_map=character_map, allow_neutral_only=allow_neutral_only, report=report)
        return {"spec": "chara_card_v3", "spec_version": "3.0", "data": data}, report
    if target == "lorebook-v3":
        return {"spec": "lorebook_v3", "spec_version": "3.0", "data": _book(ir, native=False, st_extensions=st_extensions, tag_map=tag_map, character_map=character_map, allow_neutral_only=allow_neutral_only, report=report, include_artifact_unknown=True)}, report
    if target == "sillytavern-native":
        return _book(
            ir, native=True, st_extensions=False, tag_map=tag_map, character_map=character_map,
            allow_neutral_only=allow_neutral_only, report=report, include_artifact_unknown=True,
            # A "preserve" that was upgraded to native (see above) is a
            # deliberate choice of the canonical native shape, not an
            # incidental preservation of whatever the source's own container
            # style was; it must produce the real, object-keyed entries
            # container SillyTavern's own readWorldInfoFile expects
            # ({entries: {}}, not an array), the same as an explicit request.
            canonical_native_container=requested_target != "preserve" or report.get("preserve_upgraded_to_native", False),
        ), report
    if target == "group-set":
        characters = []
        for card in ir.get("group_characters", []):
            sub = copy.deepcopy(ir); sub_card = copy.deepcopy(card)
            char_assets = copy.deepcopy(sub_card.pop("assets", [])) if isinstance(sub_card, dict) else []
            sub["card"] = sub_card; sub["assets"] = char_assets; sub["lorebook"] = None; sub["group_characters"] = []
            characters.append(emit_json(sub, "schema1-character", runtime_profile=runtime_profile, tag_map=tag_map, character_map=character_map)[0])
        # Real-world regression, same family as resolve_preserve_target's:
        # this was previously conditional on runtime_profile (lorebook-v3
        # unless explicitly ST_PROFILE), leaving the default path's shared
        # lorebook wrapped in the same non-importable "spec"/"data" shape
        # SillyTavern's real character importer would misroute; and
        # inconsistently so, since this group-set's own characters are
        # already unconditionally emitted as schema1-character just above,
        # never gated on runtime_profile at all. A group-set target's whole
        # purpose is a directly SillyTavern-usable package; its shared
        # lorebook must always be sillytavern-native, matching its own
        # characters' treatment, not conditional on a setting that controls
        # ST-extension inclusion, an unrelated concern from container shape.
        lore = emit_json({**copy.deepcopy(ir), "card": None, "group_characters": []}, "sillytavern-native", runtime_profile=runtime_profile, tag_map=tag_map, character_map=character_map, allow_neutral_only=allow_neutral_only)[0]
        return {**copy.deepcopy(ir.get("unknown", {})), "kind": "worldbuilder-group-set-v1", "characters": characters, "shared_lorebook": lore, "source_metadata": copy.deepcopy(ir.get("source_metadata", {}))}, report
    if target == "persona-lorebook":
        # Same fix, same reasoning, as group-set immediately above.
        lore = emit_json({**copy.deepcopy(ir), "card": None, "group_characters": []}, "sillytavern-native", runtime_profile=runtime_profile, tag_map=tag_map, character_map=character_map, allow_neutral_only=allow_neutral_only)[0] if ir.get("lorebook") else None
        return {**copy.deepcopy(ir.get("unknown", {})), "kind": "worldbuilder-persona-package-v1", "persona_text": ir.get("persona_text", ""), "lorebook": lore, "source_metadata": copy.deepcopy(ir.get("source_metadata", {}))}, report
    if target == "charx":
        # Batch 58 / A12: choose the payload from the source. An embedded-lorebook
        # source uses the ccv3-embedded payload; a Schema 1 character card with no
        # lorebook packages as a Schema 1 payload inside the CHARX container.
        payload_target = "ccv3-embedded" if isinstance(ir.get("lorebook"), dict) else "schema1-character"
        artifact, nested = emit_json(ir, payload_target, runtime_profile=runtime_profile, tag_map=tag_map, character_map=character_map, allow_lossy=allow_lossy, allow_neutral_only=allow_neutral_only)
        nested["target"] = "charx"; nested["container_format"] = "charx-v1"
        nested["payload_target"] = payload_target
        return artifact, nested
    raise WorldBuilderError(f"unhandled target {target}")


def semantic_projection(ir: dict[str, Any]) -> dict[str, Any]:
    validate_ir(ir)
    def entry_projection(row: dict[str, Any]) -> dict[str, Any]:
        return {key: copy.deepcopy(row.get(key)) for key in (
            "identity", "name", "comment", "keys", "secondary_keys", "content", "enabled",
            "insertion_order", "use_regex", "case_sensitive", "constant", "selective",
            "selective_logic", "position", "priority", "runtime", "dynamic", "extensions", "unknown",
        )}
    book = ir.get("lorebook")
    return {
        "card": copy.deepcopy(ir.get("card")),
        "lorebook": None if book is None else {
            "metadata": copy.deepcopy(book.get("metadata", {})), "extensions": copy.deepcopy(book.get("extensions", {})),
            "entries": [entry_projection(row) for row in book.get("entries", [])],
            "container_style": book.get("container_style"), "unknown": copy.deepcopy(book.get("unknown", {})),
        },
        "assets": copy.deepcopy(ir.get("assets", [])), "group_characters": copy.deepcopy(ir.get("group_characters", [])),
        "persona_text": ir.get("persona_text"), "unknown": copy.deepcopy(ir.get("unknown", {})),
    }


def _normalize_projection_for_target(
    projection: dict[str, Any], target: str, *, runtime_profile: str = PORTABLE_PROFILE,
    canonical_native_container: bool = True,
) -> dict[str, Any]:
    out = copy.deepcopy(projection)
    if target == "schema1-character":
        out["lorebook"] = None
    if target in {"lorebook-v3", "sillytavern-native"}:
        out["card"] = None; out["assets"] = []
    if target in {"lorebook-v3", "ccv3-embedded", "charx"} and isinstance(out.get("lorebook"), dict):
        out["lorebook"]["container_style"] = "array"
    if target in {"sillytavern-native", "group-set", "persona-lorebook"} and isinstance(out.get("lorebook"), dict):
        # group-set and persona-lorebook's own shared lorebook is now always
        # emitted sillytavern-native (see emit_json's comment on this same
        # fix); the roundtrip projection must apply the identical
        # container-style and position normalization a standalone
        # sillytavern-native target already gets here, or "expected"
        # (computed from the pre-emission ir) and "observed" (re-imported
        # from the now-native-shaped artifact) genuinely, correctly diverge
        # on exactly the fields this fix changed.
        if canonical_native_container:
            out["lorebook"]["container_style"] = "object"
        for row in out["lorebook"].get("entries", []):
            if row.get("position") == "before_char":
                row["position"] = 0
            elif row.get("position") == "after_char":
                row["position"] = 1
            if isinstance(row.get("dynamic"), dict) and row["dynamic"].get("named_outlet"):
                row["position"] = OUTLET_POSITION
    if runtime_profile == ST_PROFILE and isinstance(out.get("lorebook"), dict):
        for row in out["lorebook"].get("entries", []):
            if isinstance(row.get("dynamic"), dict) and row["dynamic"].get("named_outlet"):
                row["position"] = OUTLET_POSITION
    if target == "group-set":
        out["card"] = None
        for card in out.get("group_characters", []):
            if isinstance(card, dict) and card.get("assets") == []:
                card.pop("assets", None)
    if target == "persona-lorebook":
        out["card"] = None; out["assets"] = []; out["group_characters"] = []
    return out


def verify_roundtrip(
    ir: dict[str, Any], artifact: dict[str, Any], target: str, *,
    runtime_profile: str = PORTABLE_PROFILE, allow_lossy: bool = False,
    canonical_native_container: bool = True,
) -> dict[str, Any]:
    reopened = import_ir(artifact)
    expected = _normalize_projection_for_target(
        semantic_projection(ir), target, runtime_profile=runtime_profile,
        canonical_native_container=canonical_native_container,
    )
    observed = _normalize_projection_for_target(
        semantic_projection(reopened), target, runtime_profile=runtime_profile,
        canonical_native_container=canonical_native_container,
    )
    if expected != observed and not allow_lossy:
        raise WorldBuilderError("reopened target does not match the semantic intermediate representation")
    return {"semantic_ir_sha256": _json_hash(expected), "reopened_ir_sha256": _json_hash(observed), "equal": expected == observed}


def utf8_gate(path: Path) -> None:
    raw = path.read_bytes()
    if raw.startswith(b"\xef\xbb\xbf"):
        raise WorldBuilderError("output begins with a UTF-8 BOM and would be rejected as corrupted by SillyTavern JSON import")
    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise WorldBuilderError(f"output is not valid UTF-8: {exc}") from exc
    for marker in ("\ufffd", "Ã", "Â", "â€™", "â€œ", "â€"):
        if marker in text:
            raise WorldBuilderError(f"output contains likely mojibake marker {marker!r}")


def _validate_one(artifact: dict[str, Any], profile: str) -> dict[str, Any]:
    report, info = validate_output_artifact(artifact, profile)
    if report.errors:
        detail = "; ".join(f"{issue.path}: {issue.message}" for issue in report.errors[:8])
        raise WorldBuilderError(f"emitted target failed {profile} validation ({info.kind}): {detail}")
    return {"artifact": info.kind, "profile": profile, "errors": 0, "warnings": len(report.warnings)}


def validate_target_artifact(artifact: dict[str, Any], target: str) -> dict[str, Any]:
    if target in {"schema1-character", "ccv3-embedded", "charx"}:
        return _validate_one(artifact, "spec")
    if target == "lorebook-v3":
        return _validate_one(artifact, "spec")
    if target == "sillytavern-native":
        return _validate_one(artifact, "sillytavern")
    if target == "group-set":
        results = [_validate_one(card, "spec") for card in artifact.get("characters", [])]
        # The shared lorebook is now always emitted sillytavern-native (see
        # emit_json's own comment on this same fix), so it must be validated
        # against that profile, not "spec"; validating a native artifact
        # against the CCv3 wrapper profile is exactly the mismatch that
        # broke this the first time.
        results.append(_validate_one(artifact["shared_lorebook"], "sillytavern"))
        return {"artifact": "group-set", "profile": "spec", "errors": 0, "members": results}
    if target == "persona-lorebook":
        if not isinstance(artifact.get("persona_text"), str):
            raise WorldBuilderError("persona package text must be UTF-8 text")
        if artifact.get("lorebook") is not None:
            _validate_one(artifact["lorebook"], "sillytavern")
        return {"artifact": "persona-lorebook", "profile": "spec", "errors": 0}
    raise WorldBuilderError(f"no validator is registered for target {target}")


def write_charx(path: Path, card: dict[str, Any], asset_map: dict[str, Path] | None = None) -> None:
    validate_target_artifact(card, "charx")
    # Batch 58 / A12: one shared member-resolution rule (build_charx.py), so this
    # path and the standalone packer cannot disagree about whether an embedded
    # descriptor resolves to a real member. Imported here rather than at module
    # scope to keep the dependency one-way.
    from build_charx import resolve_embedded_members
    members = resolve_embedded_members(card, asset_map or {})
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = (json.dumps(card, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("card.json", payload)
        for member, source in members:
            archive.write(source, member)
    with zipfile.ZipFile(path, "r") as archive:
        if archive.testzip() is not None:
            raise WorldBuilderError("CHARX package integrity check failed")
        for name in archive.namelist():
            safe_archive_path(name)
        loaded = json.loads(archive.read("card.json").decode("utf-8"))
        if loaded != card:
            raise WorldBuilderError("CHARX card.json changed during packaging")
        validate_target_artifact(loaded, "charx")


def export_target(ir: dict[str, Any], output: Path, target: str, *, runtime_profile: str = PORTABLE_PROFILE, tag_map: dict[str, str] | None = None, character_map: dict[str, str] | None = None, asset_map: dict[str, Path] | None = None, allow_lossy: bool = False, allow_neutral_only: bool = False) -> tuple[dict[str, Any], dict[str, Any]]:
    artifact, report = emit_json(ir, target, runtime_profile=runtime_profile, tag_map=tag_map, character_map=character_map, allow_lossy=allow_lossy, allow_neutral_only=allow_neutral_only)
    # Reuse emit_json's own resolution (report["target"]) rather than
    # re-deriving it here independently; emit_json is the single place that
    # knows about the preserve-to-native upgrade for a standalone lorebook
    # (see its own comment); a second, separate resolution here previously
    # fell back to the old "preserve -> ir['source_format']" logic and
    # disagreed with what emit_json had actually just produced, validating
    # the emitted sillytavern-native bytes against the wrong ("spec") profile.
    resolved_target = str(report.get("payload_target") or "ccv3-embedded") if target == "charx" else str(report.get("target", target))
    if target == "charx":
        write_charx(output, artifact, asset_map=asset_map)
        with zipfile.ZipFile(output, "r") as archive:
            reopened = json.loads(archive.read("card.json").decode("utf-8"))
    else:
        atomic_write_json(output, artifact); utf8_gate(output); reopened = load_json_strict(output)
    report["target_validation"] = validate_target_artifact(reopened, resolved_target)
    if resolved_target in {"schema1-character", "ccv3-embedded", "charx", "sillytavern-native", "lorebook-v3"}:
        report["sillytavern_import_probe"] = probe_sillytavern_artifact(reopened)
    report["roundtrip"] = verify_roundtrip(
        ir, reopened, resolved_target, runtime_profile=runtime_profile, allow_lossy=allow_lossy,
        canonical_native_container=target != "preserve" or report.get("preserve_upgraded_to_native", False),
    )
    report["output_sha256"] = sha256_file(output)
    return artifact, report


def _stamp_provenance(ir: dict[str, Any], *, build_id: str, manifest_sha256: str | None) -> None:
    """Stamps ir in place; must run before export_target, never after
    (see PROVENANCE_KEY's comment). No-op targets (neither card nor
    lorebook present) leave ir untouched rather than inventing a container
    to hold the marker."""
    marker = {"worldbuilder_version": WORLDBUILDER_VERSION, "build_id": build_id, "manifest_sha256": manifest_sha256}
    if isinstance(ir.get("lorebook"), dict):
        ir["lorebook"].setdefault("extensions", {})[PROVENANCE_KEY] = dict(marker)
    if isinstance(ir.get("card"), dict):
        ir["card"].setdefault("extensions", {})[PROVENANCE_KEY] = dict(marker)


def _default_target(state: dict[str, Any]) -> str:
    value = str(state.get("settings", {}).get("runtime_format", "preserve"))
    return value if value in TARGETS else "preserve"


def _probed_artifact_attribution(root: Path, output: Path, target: str) -> tuple[str, str]:
    """Return the exact path/member and byte hash that the import probe inspected."""
    output_rel = str(output.relative_to(root)).replace("\\", "/")
    if target == "charx":
        with zipfile.ZipFile(output, "r") as archive:
            card_bytes = archive.read("card.json")
        return f"{output_rel}!/card.json", hashlib.sha256(card_bytes).hexdigest()
    return output_rel, sha256_file(output)


def serialize_build_state(state_path: Path, *, replace_target: str | None = None, allow_lossy: bool = False, allow_neutral_only: bool = False) -> dict[str, Any]:
    root, state = load_build_state(state_path)
    final_output = resolve_state_path(root, state, "final_output", required=False)
    merge_input = resolve_state_path(root, state, "merge_input")
    source = final_output if final_output is not None and final_output.exists() else merge_input
    if not source.exists():
        raise WorldBuilderError("runtime adapter source artifact is missing")
    target = replace_target or _default_target(state)
    configured_profile = str(state.get("settings", {}).get("runtime_target", "portable"))
    source_data = load_json(source)
    if configured_profile == ST_PROFILE or target == "sillytavern-native":
        runtime_profile = ST_PROFILE
    elif configured_profile == "preserve" and detect_source_format(source_data) == "sillytavern-native":
        runtime_profile = ST_PROFILE
    else:
        runtime_profile = PORTABLE_PROFILE
    output = resolve_state_path(root, state, "adapter_output")
    ir_path = resolve_state_path(root, state, "semantic_ir")
    report_path = resolve_state_path(root, state, "compatibility_report")
    receipt_path = resolve_state_path(root, state, "runtime_adapter_receipt")
    tag_path = resolve_state_path(root, state, "sillytavern_tag_map", required=False)
    char_path = resolve_state_path(root, state, "sillytavern_character_map", required=False)
    asset_path = resolve_state_path(root, state, "runtime_asset_map", required=False)
    tag_map = load_tag_map(str(tag_path)) if tag_path and tag_path.exists() else {}
    character_map = load_character_map(str(char_path)) if char_path and char_path.exists() else {}
    asset_map = load_asset_map(str(asset_path)) if asset_path and asset_path.exists() else {}
    ir = import_ir(source_data)
    _stamp_provenance(ir, build_id=str(state.get("build_id")), manifest_sha256=state.get("lineage", {}).get("manifest_sha256"))
    atomic_write_json(ir_path, ir)
    _, report = export_target(ir, output, target, runtime_profile=runtime_profile, tag_map=tag_map, character_map=character_map, asset_map=asset_map, allow_lossy=allow_lossy, allow_neutral_only=allow_neutral_only)
    atomic_write_json(report_path, report)
    probed_path, probed_sha256 = _probed_artifact_attribution(root, output, target)
    receipt = {
        "kind": RECEIPT_KIND, "receipt_version": 4, "contract": ADAPTER_CONTRACT, "adapter_version": ADAPTER_VERSION,
        "target": target, "target_profile": runtime_profile,
        "source": str(source.relative_to(root)).replace("\\", "/"), "source_sha256": sha256_file(source),
        "semantic_ir": str(ir_path.relative_to(root)).replace("\\", "/"), "semantic_ir_sha256": sha256_file(ir_path),
        "output": str(output.relative_to(root)).replace("\\", "/"), "output_sha256": sha256_file(output),
        "probed_path": probed_path, "probed_sha256": probed_sha256,
        "compatibility_report": str(report_path.relative_to(root)).replace("\\", "/"), "compatibility_report_sha256": sha256_file(report_path),
        "lossy": bool(report.get("lossy")), "lossy_approved": bool(report.get("lossy_approved")),
        "neutral_only": bool(report.get("neutral_only")), "warnings": report.get("warnings", []),
        "unsupported": report.get("unsupported", []), "target_validation": report.get("target_validation"),
        "direct_import_compatible": report.get("direct_import_compatible"),
        "active_setting_compatible": report.get("active_setting_compatible"),
        "sillytavern_import_probe": report.get("sillytavern_import_probe"),
        "roundtrip": report.get("roundtrip"),
    }
    atomic_write_json(receipt_path, receipt)
    state.setdefault("status", {})["runtime_adapter"] = "complete"
    state.setdefault("lineage", {})["runtime_adapter"] = {
        "contract": ADAPTER_CONTRACT, "target": target,
        "receipt": str(receipt_path.relative_to(root)).replace("\\", "/"),
        "receipt_sha256": sha256_file(receipt_path), "output_sha256": receipt["output_sha256"],
        "semantic_ir_sha256": receipt["semantic_ir_sha256"], "lossy_approved": receipt["lossy_approved"],
    }
    atomic_write_json(state_path, state)
    return receipt



def _json_bytes(value: Any) -> bytes:
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def _bundle_source(state_path: Path, root: Path, state: dict[str, Any]) -> tuple[Path, dict[str, Any] | None]:
    """Return the already-delivered source bytes used by opt-in packaging.

    Packaging is deliberately downstream of delivery. If an adapter output was
    part of the delivered route, validate its receipt and package those exact
    bytes; otherwise package the sealed final output. Nothing here serializes a
    replacement for the delivery target.
    """
    if str(state.get("status", {}).get("delivery")) != "permitted":
        raise WorldBuilderError("runtime bundle is post-delivery only; delivery must be permitted first")
    receipt_path = resolve_state_path(root, state, "runtime_adapter_receipt", required=False)
    if receipt_path is not None and receipt_path.exists() and str(state.get("status", {}).get("runtime_adapter")) == "complete":
        receipt = validate_build_receipt(state_path)
        rel = receipt.get("output")
        if not isinstance(rel, str) or not rel:
            raise WorldBuilderError("runtime adapter receipt lacks output path")
        source = (root / rel).resolve()
        try:
            source.relative_to(root.resolve())
        except ValueError as exc:
            raise WorldBuilderError("runtime adapter bundle source escapes build root") from exc
        return source, receipt
    final_output = resolve_state_path(root, state, "final_output", required=False)
    if final_output is None or not final_output.exists():
        raise WorldBuilderError("delivered final output is missing")
    return final_output, None


def _load_bundle_ir(source: Path) -> dict[str, Any]:
    if zipfile.is_zipfile(source):
        with zipfile.ZipFile(source, "r") as archive:
            if "card.json" not in archive.namelist():
                raise WorldBuilderError("runtime bundle source archive has no card.json")
            data = json.loads(archive.read("card.json").decode("utf-8"))
    else:
        data = load_json_strict(source)
    return import_ir(data)


def _validated_plan(root: Path, state: dict[str, Any], path_key: str, state_key: str) -> tuple[dict[str, Any], str]:
    path = resolve_state_path(root, state, path_key)
    if not path.exists():
        raise WorldBuilderError(f"runtime bundle requires {path_key}")
    actual = sha256_file(path)
    block = state.get(state_key)
    expected = block.get("plan_sha256") if isinstance(block, dict) else None
    if expected and actual != expected:
        raise WorldBuilderError(f"runtime bundle refuses stale {path_key}: build-state hash mismatch")
    plan = load_json(path)
    if plan.get("build_id") not in {None, state.get("build_id")}:
        raise WorldBuilderError(f"runtime bundle {path_key} belongs to another build")
    return plan, actual


def build_recommended_settings(state_path: str | Path, *, adapter_receipt: dict[str, Any] | None = None) -> dict[str, Any]:
    """Derive recommendation-only runtime guidance from frozen build choices.

    This is intentionally not an executable SillyTavern settings import. It
    carries only values already decided by the budget/placement plans, keeping
    packaging downstream from generation and avoiding invented runtime policy.
    """
    root, state = load_build_state(state_path)
    budget, budget_sha = _validated_plan(root, state, "budget_plan", "budget")
    placement, placement_sha = _validated_plan(root, state, "placement_plan", "placement")
    targets = budget.get("targets") if isinstance(budget.get("targets"), dict) else {}
    layer_policies = placement.get("layer_policies") if isinstance(placement.get("layer_policies"), dict) else {}
    layer_recommendations: dict[str, Any] = {}
    for layer, row in sorted(layer_policies.items()):
        if not isinstance(row, dict):
            continue
        recommendation = {
            key: copy.deepcopy(row[key])
            for key in ("recommended_position", "recommended_depth", "recommended_role")
            if key in row
        }
        if recommendation:
            layer_recommendations[str(layer)] = recommendation
    settings = state.get("settings") if isinstance(state.get("settings"), dict) else {}
    runtime_target = {
        "format": adapter_receipt.get("target") if adapter_receipt else settings.get("runtime_format", "preserve"),
        "profile": adapter_receipt.get("target_profile") if adapter_receipt else settings.get("runtime_target", "portable"),
    }
    token_budget = targets.get("lorebook_token_budget") if budget.get("applicable") else None
    return {
        "kind": RECOMMENDED_SETTINGS_KIND,
        "settings_version": 1,
        "contract": RUNTIME_PACKAGE_CONTRACT,
        "build_id": state.get("build_id"),
        "mode": "recommendation-only",
        "runtime_target": runtime_target,
        "source_plans": {
            "budget_plan_sha256": budget_sha,
            "placement_plan_sha256": placement_sha,
        },
        "world_info_global": {
            "token_budget": token_budget,
            "token_budget_source": "budget-plan.targets.lorebook_token_budget" if token_budget is not None else None,
            "scan_depth": None,
            "recursive_scanning": None,
            "unset_reason": "not inferred unless explicitly decided by the build",
        },
        "worldbuilder_budget": {
            "policy": budget.get("policy"),
            "profile_id": budget.get("profile_id"),
            "profile_label": budget.get("profile_label"),
            "targets": copy.deepcopy(targets),
        },
        "placement": {
            "policy": placement.get("policy"),
            "profile_id": placement.get("profile_id"),
            "layer_recommendations": layer_recommendations,
        },
    }


def _bundle_components(ir: dict[str, Any], *, runtime_profile: str) -> dict[str, bytes]:
    """Create validated convenience components from one semantic IR.

    The exact delivered artifact is always included separately. These component
    files are additive conveniences, never replacements for the source bytes.
    """
    validate_ir(ir)
    members: dict[str, bytes] = {}
    if ir.get("card") is not None:
        card_ir = copy.deepcopy(ir)
        card_ir["lorebook"] = None
        card_ir["group_characters"] = []
        card, _ = emit_json(card_ir, "schema1-character", runtime_profile=runtime_profile)
        validate_target_artifact(card, "schema1-character")
        members["components/card.json"] = _json_bytes(card)
    for index, card in enumerate(ir.get("group_characters", []), start=1):
        sub = copy.deepcopy(ir)
        sub["card"] = copy.deepcopy(card)
        sub["lorebook"] = None
        sub["group_characters"] = []
        artifact, _ = emit_json(sub, "schema1-character", runtime_profile=runtime_profile)
        validate_target_artifact(artifact, "schema1-character")
        members[f"components/characters/{index:03d}.json"] = _json_bytes(artifact)
    if ir.get("lorebook") is not None:
        lore_ir = copy.deepcopy(ir)
        lore_ir["card"] = None
        lore_ir["group_characters"] = []
        lore_target = "sillytavern-native" if runtime_profile == ST_PROFILE else "lorebook-v3"
        lore, _ = emit_json(lore_ir, lore_target, runtime_profile=runtime_profile)
        validate_target_artifact(lore, lore_target)
        members["components/lorebooks/main.json"] = _json_bytes(lore)
    if isinstance(ir.get("persona_text"), str):
        members["components/persona.txt"] = (str(ir["persona_text"]).rstrip("\n") + "\n").encode("utf-8")
    return members


def build_runtime_bundle(state_path: str | Path) -> dict[str, Any]:
    state_path = Path(state_path).resolve()
    root, state = load_build_state(state_path)
    source, adapter_receipt = _bundle_source(state_path, root, state)
    source_before = sha256_file(source)
    ir = _load_bundle_ir(source)
    if adapter_receipt:
        runtime_profile = str(adapter_receipt.get("target_profile", PORTABLE_PROFILE))
    else:
        configured = str((state.get("settings") or {}).get("runtime_target", "portable"))
        runtime_profile = ST_PROFILE if configured == ST_PROFILE else PORTABLE_PROFILE
    recommended = build_recommended_settings(state_path, adapter_receipt=adapter_receipt)
    recommended_path = resolve_state_path(root, state, "recommended_settings")
    manifest_path = resolve_state_path(root, state, "runtime_bundle_manifest")
    receipt_path = resolve_state_path(root, state, "runtime_bundle_receipt")
    bundle_path = resolve_state_path(root, state, "runtime_bundle")
    atomic_write_json(recommended_path, recommended)

    suffix = ".charx" if zipfile.is_zipfile(source) else source.suffix.lower() or ".json"
    primary_name = f"source/delivered-artifact{suffix}"
    members: dict[str, bytes] = {primary_name: source.read_bytes()}
    members.update(_bundle_components(ir, runtime_profile=runtime_profile))
    members["recommended_settings.json"] = recommended_path.read_bytes()
    manifest = {
        "kind": BUNDLE_MANIFEST_KIND,
        "manifest_version": 1,
        "contract": RUNTIME_PACKAGE_CONTRACT,
        "build_id": state.get("build_id"),
        "source": {
            "path": str(source.relative_to(root)).replace("\\", "/"),
            "sha256": source_before,
            "member": primary_name,
        },
        "runtime_profile": runtime_profile,
        "members": [
            {"path": name, "sha256": hashlib.sha256(payload).hexdigest(), "size": len(payload)}
            for name, payload in sorted(members.items())
        ],
    }
    atomic_write_json(manifest_path, manifest)
    members["bundle-manifest.json"] = manifest_path.read_bytes()
    bundle_path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(bundle_path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for name, payload in sorted(members.items()):
            safe_archive_path(name)
            info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            archive.writestr(info, payload)
    with zipfile.ZipFile(bundle_path, "r") as archive:
        if archive.testzip() is not None:
            raise WorldBuilderError("runtime bundle ZIP integrity check failed")
        for name in archive.namelist():
            safe_archive_path(name)
        if archive.read(primary_name) != source.read_bytes():
            raise WorldBuilderError("runtime bundle changed the delivered artifact bytes")
        inside_manifest = json.loads(archive.read("bundle-manifest.json").decode("utf-8"))
        if inside_manifest != manifest:
            raise WorldBuilderError("runtime bundle manifest changed during packaging")
    source_after = sha256_file(source)
    if source_after != source_before:
        raise WorldBuilderError("runtime bundle mutated the delivered artifact")
    receipt = {
        "kind": BUNDLE_RECEIPT_KIND,
        "receipt_version": 1,
        "contract": RUNTIME_PACKAGE_CONTRACT,
        "build_id": state.get("build_id"),
        "source_sha256_before": source_before,
        "source_sha256_after": source_after,
        "source_unchanged": source_before == source_after,
        "recommended_settings": str(recommended_path.relative_to(root)).replace("\\", "/"),
        "recommended_settings_sha256": sha256_file(recommended_path),
        "bundle_manifest": str(manifest_path.relative_to(root)).replace("\\", "/"),
        "bundle_manifest_sha256": sha256_file(manifest_path),
        "bundle": str(bundle_path.relative_to(root)).replace("\\", "/"),
        "bundle_sha256": sha256_file(bundle_path),
        "member_count": len(members),
    }
    atomic_write_json(receipt_path, receipt)
    return receipt


def validate_runtime_bundle(state_path: str | Path) -> dict[str, Any]:
    root, state = load_build_state(state_path)
    receipt_path = resolve_state_path(root, state, "runtime_bundle_receipt")
    if not receipt_path.exists():
        raise WorldBuilderError("runtime bundle receipt is missing")
    receipt = load_json(receipt_path)
    if receipt.get("kind") != BUNDLE_RECEIPT_KIND or receipt.get("contract") != RUNTIME_PACKAGE_CONTRACT:
        raise WorldBuilderError("runtime bundle receipt kind/contract is unsupported")
    bundle_path = resolve_state_path(root, state, "runtime_bundle")
    settings_path = resolve_state_path(root, state, "recommended_settings")
    manifest_path = resolve_state_path(root, state, "runtime_bundle_manifest")
    checks = (
        (bundle_path, "bundle_sha256", "bundle"),
        (settings_path, "recommended_settings_sha256", "recommended settings"),
        (manifest_path, "bundle_manifest_sha256", "bundle manifest"),
    )
    for path, key, label in checks:
        if not path.exists() or sha256_file(path) != receipt.get(key):
            raise WorldBuilderError(f"runtime bundle receipt is stale at {label}")
    source, _ = _bundle_source(Path(state_path).resolve(), root, state)
    current = sha256_file(source)
    if current != receipt.get("source_sha256_before") or current != receipt.get("source_sha256_after"):
        raise WorldBuilderError("runtime bundle source changed after packaging")
    with zipfile.ZipFile(bundle_path, "r") as archive:
        if archive.testzip() is not None:
            raise WorldBuilderError("runtime bundle ZIP integrity check failed")
        for name in archive.namelist():
            safe_archive_path(name)
    return receipt


def validate_build_receipt(state_path: str | Path) -> dict[str, Any]:
    root, state = load_build_state(state_path)
    receipt_path = resolve_state_path(root, state, "runtime_adapter_receipt")
    if not receipt_path.exists():
        raise WorldBuilderError("runtime target adapter receipt is missing")
    receipt = load_json(receipt_path)
    if receipt.get("kind") != RECEIPT_KIND or receipt.get("contract") != ADAPTER_CONTRACT:
        raise WorldBuilderError("runtime target adapter receipt kind/contract is unsupported")
    source_rel = receipt.get("source")
    if not isinstance(source_rel, str) or not source_rel:
        raise WorldBuilderError("runtime target adapter receipt lacks a source path")
    source = (root / source_rel).resolve()
    try:
        source.relative_to(root.resolve())
    except ValueError as exc:
        raise WorldBuilderError("runtime target adapter receipt source escapes the build root") from exc
    checks = [
        (source, "source_sha256", "source"),
        (resolve_state_path(root, state, "semantic_ir"), "semantic_ir_sha256", "semantic_ir"),
        (resolve_state_path(root, state, "adapter_output"), "output_sha256", "adapter_output"),
        (resolve_state_path(root, state, "compatibility_report"), "compatibility_report_sha256", "compatibility_report"),
    ]
    for path, hash_key, label in checks:
        if not path.exists() or sha256_file(path) != receipt.get(hash_key):
            raise WorldBuilderError(f"runtime target adapter receipt is stale at {label}")
    receipt_version = int(receipt.get("receipt_version", 0) or 0)
    if receipt_version >= 4:
        expected_probed_path, expected_probed_sha = _probed_artifact_attribution(root, resolve_state_path(root, state, "adapter_output"), str(receipt.get("target")))
        if receipt.get("probed_path") != expected_probed_path or receipt.get("probed_sha256") != expected_probed_sha:
            raise WorldBuilderError("runtime target adapter receipt is stale at probed artifact attribution")
    if receipt.get("lossy") is True and receipt.get("lossy_approved") is not True:
        raise WorldBuilderError("runtime target adapter receipt is lossy without explicit approval")
    if receipt.get("unsupported"):
        raise WorldBuilderError("runtime target adapter receipt contains unsupported fields")
    ir = load_json(resolve_state_path(root, state, "semantic_ir")); output = resolve_state_path(root, state, "adapter_output")
    target = str(receipt.get("target"))
    resolved, preserve_upgraded_to_native = ("ccv3-embedded", False) if target == "charx" else resolve_preserve_target(ir, target)
    if target == "charx":
        with zipfile.ZipFile(output, "r") as archive:
            artifact = json.loads(archive.read("card.json").decode("utf-8"))
    else:
        utf8_gate(output); artifact = load_json_strict(output)
    validate_target_artifact(artifact, resolved)
    if resolved in {"schema1-character", "ccv3-embedded", "charx", "sillytavern-native", "lorebook-v3"}:
        probe_sillytavern_artifact(artifact)
    verify_roundtrip(
        ir, artifact, resolved, runtime_profile=str(receipt.get("target_profile", PORTABLE_PROFILE)),
        allow_lossy=bool(receipt.get("lossy_approved")),
        canonical_native_container=target != "preserve" or preserve_upgraded_to_native,
    )
    return receipt


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="WorldBuilder semantic IR and runtime target adapter")
    sub = p.add_subparsers(dest="command", required=True)
    imp = sub.add_parser("import", help="Import a supported artifact to semantic IR")
    imp.add_argument("input"); imp.add_argument("output")
    exp = sub.add_parser("export", help="Export semantic IR or a supported artifact to a named target")
    exp.add_argument("input", nargs="?"); exp.add_argument("output", nargs="?")
    exp.add_argument("--build-state"); exp.add_argument("--target", choices=sorted(TARGETS))
    exp.add_argument("--runtime-profile", choices=sorted(RUNTIME_PROFILES), default=PORTABLE_PROFILE)
    exp.add_argument("--tag-map"); exp.add_argument("--character-map"); exp.add_argument("--asset-map")
    exp.add_argument("--allow-lossy", action="store_true"); exp.add_argument("--allow-neutral-only", action="store_true")
    bundle = sub.add_parser("bundle", help="Opt-in post-delivery runtime package: exact artifact + components + recommended settings")
    bundle.add_argument("--build-state", required=True)
    bundle_val = sub.add_parser("validate-bundle", help="Validate a post-delivery runtime bundle receipt and ZIP")
    bundle_val.add_argument("--build-state", required=True)
    val = sub.add_parser("validate", help="Validate an adapter receipt or standalone artifact")
    val.add_argument("input", nargs="?"); val.add_argument("--build-state")
    rt = sub.add_parser("roundtrip", help="Export to a temporary target and verify semantic equality")
    rt.add_argument("input"); rt.add_argument("--target", choices=sorted(TARGETS), required=True)
    rt.add_argument("--runtime-profile", choices=sorted(RUNTIME_PROFILES), default=PORTABLE_PROFILE)
    rt.add_argument("--tag-map"); rt.add_argument("--character-map"); rt.add_argument("--asset-map")
    return p


def main() -> int:
    args = parser().parse_args()
    try:
        if args.command == "import":
            ir = import_ir(load_json(args.input)); atomic_write_json(args.output, ir)
            print(json.dumps({"semantic_ir": str(Path(args.output).resolve()), "sha256": sha256_file(args.output)}, indent=2)); return 0
        if args.command == "export":
            print("── RUNTIME TARGET ADAPTER ──"); print("[1/5] Source and target detection: OK")
            if args.build_state:
                receipt = serialize_build_state(Path(args.build_state).resolve(), replace_target=args.target, allow_lossy=args.allow_lossy, allow_neutral_only=args.allow_neutral_only)
                print("[2/5] Semantic intermediate representation: OK"); print("[3/5] Versioned target mapping: OK")
                print("[4/5] Target validation and round-trip verification: OK"); print("[5/5] Compatibility and output lineage: OK")
                print(json.dumps(receipt, ensure_ascii=False, indent=2)); print("✅ TARGET OUTPUT VERIFIED"); return 0
            if not args.input or not args.output or not args.target:
                raise WorldBuilderError("standalone export requires INPUT OUTPUT --target")
            raw = load_json(args.input); ir = raw if isinstance(raw, dict) and raw.get("kind") == IR_KIND else import_ir(raw)
            _, report = export_target(ir, Path(args.output).resolve(), args.target, runtime_profile=args.runtime_profile, tag_map=load_tag_map(args.tag_map), character_map=load_character_map(args.character_map), asset_map=load_asset_map(args.asset_map), allow_lossy=args.allow_lossy, allow_neutral_only=args.allow_neutral_only)
            print("[2/5] Semantic intermediate representation: OK"); print("[3/5] Versioned target mapping: OK")
            print("[4/5] Target validation and round-trip verification: OK"); print("[5/5] Compatibility and output lineage: OK")
            print(json.dumps(report, ensure_ascii=False, indent=2)); print("✅ TARGET OUTPUT VERIFIED"); return 0
        if args.command == "bundle":
            print(json.dumps(build_runtime_bundle(args.build_state), ensure_ascii=False, indent=2)); return 0
        if args.command == "validate-bundle":
            print(json.dumps(validate_runtime_bundle(args.build_state), ensure_ascii=False, indent=2)); return 0
        if args.command == "validate":
            if args.build_state:
                print(json.dumps(validate_build_receipt(args.build_state), ensure_ascii=False, indent=2)); return 0
            if not args.input:
                raise WorldBuilderError("validate requires INPUT or --build-state")
            raw = load_json(args.input); validate_target_artifact(raw, detect_source_format(raw)); ir = import_ir(raw); validate_ir(ir)
            print(json.dumps({"status": "passed", "semantic_ir_sha256": _json_hash(semantic_projection(ir))}, indent=2)); return 0
        if args.command == "roundtrip":
            raw = load_json(args.input); ir = raw if isinstance(raw, dict) and raw.get("kind") == IR_KIND else import_ir(raw)
            suffix = ".charx" if args.target == "charx" else ".json"
            with tempfile.TemporaryDirectory() as td:
                output = Path(td) / ("roundtrip" + suffix)
                _, report = export_target(ir, output, args.target, runtime_profile=args.runtime_profile, tag_map=load_tag_map(args.tag_map), character_map=load_character_map(args.character_map), asset_map=load_asset_map(args.asset_map))
            print(json.dumps(report["roundtrip"], indent=2)); return 0
        raise WorldBuilderError("unsupported command")
    except (WorldBuilderError, OSError, json.JSONDecodeError, zipfile.BadZipFile) as exc:
        print(f"RUNTIME TARGET ADAPTER BLOCKED: {exc}", file=sys.stderr); print(step_driver_pointer(), file=sys.stderr); return 1


if __name__ == "__main__":
    raise SystemExit(main())
