#!/usr/bin/env python3
"""Re-bind the machine header of build-list.md to the current manifest.

Only the first WORLDBUILDER-ARTIFACT JSON line is changed. Human-authored body
content is preserved byte-for-byte after that line.
"""
from __future__ import annotations
import argparse, json, sys
from pathlib import Path
from wb_common import WorldBuilderError, load_build_state, resolve_state_path, sha256_file

PREFIX = "WORLDBUILDER-ARTIFACT:"


def rebind(build_state: str | Path) -> dict:
    root, state = load_build_state(build_state)
    manifest = resolve_state_path(root, state, "manifest")
    build_list = resolve_state_path(root, state, "build_list")
    if not manifest.exists() or not build_list.exists():
        raise WorldBuilderError("build-list rebind requires both manifest and build-list")
    discovery = resolve_state_path(root, state, "discovery_receipt", required=False)
    text = build_list.read_text(encoding="utf-8")
    lines = text.splitlines(keepends=True)
    idx = next((i for i, line in enumerate(lines) if line.strip()), None)
    if idx is None or not lines[idx].strip().startswith(PREFIX):
        raise WorldBuilderError("build-list.md has no WORLDBUILDER-ARTIFACT header to re-bind")
    try:
        old = json.loads(lines[idx].strip()[len(PREFIX):].strip())
    except json.JSONDecodeError as exc:
        raise WorldBuilderError(f"build-list header JSON is invalid: {exc}") from exc
    if not isinstance(old, dict) or old.get("kind") != "build_list":
        raise WorldBuilderError("build-list header kind must be build_list")
    header = dict(old)
    header["build_id"] = state.get("build_id")
    header["manifest_sha256"] = sha256_file(manifest)
    if discovery and discovery.exists():
        header["discovery_receipt_sha256"] = sha256_file(discovery)
    newline = "\r\n" if lines[idx].endswith("\r\n") else "\n"
    lines[idx] = PREFIX + " " + json.dumps(header, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + newline
    build_list.write_text("".join(lines), encoding="utf-8", newline="")
    return {"status":"rebound","build_list":str(build_list.relative_to(root)).replace("\\","/"),"manifest_sha256":header["manifest_sha256"],"sha256":sha256_file(build_list)}


def main() -> int:
    p=argparse.ArgumentParser(description=__doc__); p.add_argument("--build-state", required=True); a=p.parse_args()
    try: print(json.dumps(rebind(a.build_state),ensure_ascii=False,indent=2)); return 0
    except (WorldBuilderError,OSError,ValueError,json.JSONDecodeError) as exc: print(f"ERROR: {exc}",file=sys.stderr); return 1
if __name__=="__main__": raise SystemExit(main())
