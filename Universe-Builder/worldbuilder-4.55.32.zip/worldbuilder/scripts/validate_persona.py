#!/usr/bin/env python3
"""Validate a SillyTavern user-persona description stored as plain text.

Persona descriptions are not Character Card JSON. This validator keeps format
requirements separate from optional WorldBuilder editorial guidance.

Profiles:
  format       Blocking checks only (UTF-8 text, non-empty, not JSON).
  worldbuilder Adds non-blocking persona quality guidance.

Split-mode core descriptions are capped at 300 words because they are intended
as a lean always-on summary; the threshold is a WorldBuilder profile rule, not a
SillyTavern import requirement.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

CONTROL_RE = re.compile(
    r"(?:AI|assistant|model).{0,80}(?:never|must\s+not|does\s+not).{0,100}"
    r"(?:decid|control|choose|narrat).{0,80}(?:\{\{user\}\}|user(?:'s)?).{0,80}"
    r"(?:action|thought|feeling|decision|internal)",
    re.IGNORECASE | re.DOTALL,
)
USER_TOKEN_RE = re.compile(r"\{\{user\}\}", re.IGNORECASE)
SECTION_RE = re.compile(
    r"(?im)^\s*(?:\[|#{1,4}\s*)?(name|appearance|personality|voice|speech|"
    r"skills?|abilities|backstory|current situation|default situation|relationships?|"
    r"notable items?|ai control)(?:\]|\s*:|\s*$)"
)
WORD_RE = re.compile(r"\b[\w'’-]+\b", re.UNICODE)


@dataclass(frozen=True)
class Issue:
    severity: str
    code: str
    message: str


@dataclass
class PersonaReport:
    profile: str
    mode: str
    word_count: int
    issues: list[Issue]

    @property
    def errors(self) -> list[Issue]:
        return [item for item in self.issues if item.severity == "error"]

    @property
    def warnings(self) -> list[Issue]:
        return [item for item in self.issues if item.severity == "warning"]


def looks_like_json(text: str) -> bool:
    stripped = text.lstrip("\ufeff \t\r\n")
    if not stripped.startswith(("{", "[")):
        return False
    try:
        value: Any = json.loads(stripped)
    except json.JSONDecodeError:
        return False
    return isinstance(value, (dict, list))


def validate_persona(
    text: str,
    *,
    mode: str = "auto",
    profile: str = "worldbuilder",
    split_max_words: int = 300,
    split_warn_words: int = 280,
) -> PersonaReport:
    if mode not in {"auto", "simple", "split"}:
        raise ValueError(f"unsupported mode: {mode}")
    if profile not in {"format", "worldbuilder"}:
        raise ValueError(f"unsupported profile: {profile}")

    issues: list[Issue] = []
    normalized = text.replace("\r\n", "\n").replace("\r", "\n")
    stripped = normalized.strip()
    word_count = len(WORD_RE.findall(stripped))

    if "\x00" in normalized:
        issues.append(Issue("error", "P001", "persona text contains a NUL byte"))
    if not stripped:
        issues.append(Issue("error", "P002", "persona description is empty"))
    if looks_like_json(stripped):
        issues.append(
            Issue(
                "error",
                "P003",
                "persona description is JSON; SillyTavern persona descriptions must be pasted as text",
            )
        )

    # Infer split mode only when an explicit mode is not supplied. The filename
    # is intentionally not used: callers may choose any safe name.
    effective_mode = mode
    if mode == "auto":
        effective_mode = "split" if word_count <= split_max_words and "lorebook" in stripped.casefold() else "simple"

    if profile == "worldbuilder" and stripped:
        if not USER_TOKEN_RE.search(stripped):
            issues.append(
                Issue(
                    "warning",
                    "P101",
                    "description does not use {{user}}; confirm that references remain unambiguous in chat",
                )
            )
        if not CONTROL_RE.search(stripped):
            issues.append(
                Issue(
                    "warning",
                    "P102",
                    "no explicit rule prevents the AI from deciding {{user}}'s actions or internal thoughts",
                )
            )
        sections = {match.group(1).casefold() for match in SECTION_RE.finditer(stripped)}
        if not any(name in sections for name in {"appearance", "personality"}):
            issues.append(
                Issue(
                    "warning",
                    "P103",
                    "no recognizable appearance or personality section was found; prose-only descriptions are allowed",
                )
            )
        if effective_mode == "split":
            if word_count > split_max_words:
                issues.append(
                    Issue(
                        "error",
                        "P104",
                        f"split-mode core is {word_count} words; WorldBuilder's configured maximum is {split_max_words}",
                    )
                )
            elif word_count >= split_warn_words:
                issues.append(
                    Issue(
                        "warning",
                        "P105",
                        f"split-mode core is {word_count} words and is approaching the {split_max_words}-word profile limit",
                    )
                )
        if word_count < 20:
            issues.append(
                Issue(
                    "warning",
                    "P106",
                    "persona is very short; verify that it contains enough stable identifying detail",
                )
            )

    return PersonaReport(profile=profile, mode=effective_mode, word_count=word_count, issues=issues)


def print_report(report: PersonaReport) -> None:
    print(f"Artifact: persona-text; mode={report.mode}; profile={report.profile}; words={report.word_count}")
    for issue in report.issues:
        print(f"[{issue.severity.upper()}][{issue.code}] {issue.message}")
    print(f"Summary: {len(report.errors)} error(s), {len(report.warnings)} warning(s)")


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate a SillyTavern persona description text file.")
    parser.add_argument("path")
    parser.add_argument("--mode", choices=["auto", "simple", "split"], default="auto")
    parser.add_argument("--profile", choices=["format", "worldbuilder"], default="worldbuilder")
    parser.add_argument("--split-max-words", type=int, default=300)
    parser.add_argument("--split-warn-words", type=int, default=280)
    parser.add_argument("--strict-warnings", action="store_true")
    parser.add_argument("--json-report")
    args = parser.parse_args()

    try:
        raw = Path(args.path).read_bytes()
        text = raw.decode("utf-8-sig")
    except (OSError, UnicodeDecodeError) as exc:
        print(f"ERROR: cannot read persona as UTF-8 text: {exc}", file=sys.stderr)
        return 2

    report = validate_persona(
        text,
        mode=args.mode,
        profile=args.profile,
        split_max_words=args.split_max_words,
        split_warn_words=args.split_warn_words,
    )
    print_report(report)
    if args.json_report:
        payload = {
            "artifact": "persona-text",
            "mode": report.mode,
            "profile": report.profile,
            "word_count": report.word_count,
            "errors": len(report.errors),
            "warnings": len(report.warnings),
            "issues": [asdict(issue) for issue in report.issues],
        }
        Path(args.json_report).write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return 1 if report.errors or (args.strict_warnings and report.warnings) else 0


if __name__ == "__main__":
    raise SystemExit(main())
