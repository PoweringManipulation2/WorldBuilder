#!/usr/bin/env python3
"""Rank what is worth verifying, label what was not, and price a build before it runs.

Verification cost approaches generation cost when applied uniformly, which is why
additive builds on unverified material stall. But accuracy risk is not uniform: an
entry that is constant, has many dependents, and makes falsifiable claims breaks
immersion on turn three, while an atmospheric entry that rarely fires may never
surface a mistake at all.

So verification is triaged by blast radius and the budget is spent top-down. What the
budget does not reach is labeled rather than silently trusted, and de-risked according
to a policy the user approved. The goal is not to be right about everything; it is to
be accurate about what is uncertain, which converts an unbounded cost problem into a
bounded labeling one.

Costs are reported in units (entries, worker rounds, estimated tokens) with rates
supplied by the caller. Hard-coded prices go stale and a stale price is worse than no
price.

Commands:
    rank     score entries by verification priority
    label    apply confidence labels from a verification result
    derisk   apply the approved policy to unverified entries
    project  estimate build cost in units, optionally priced
"""
from __future__ import annotations

import argparse
import json
import math
import re
import sys
from pathlib import Path
from typing import Any

from wb_common import (
    WorldBuilderError,
    atomic_write_json,
    entry_uid,
    load_build_state,
    load_json,
    raise_error,
    resolve_state_path,
)

CONTRACT = "worldbuilder-verification-triage-v1"
RECEIPT_VERSION = 1

CONFIDENCE_LEVELS = ("verified", "inferred", "unverified")
DERISK_POLICIES = ("disable", "deprioritize", "despecify", "ship_labeled")

# Falsifiable-claim markers. A wrong date breaks immersion; vague atmosphere cannot.
CLAIM_PATTERNS = (
    r"\b\d{3,4}\b",                                    # years, counts
    r"\b\d+(?:st|nd|rd|th)\b",                         # ordinals
    r"\b(?:killed|died|born|founded|destroyed|crowned|married|betrayed)\b",
    r"\b(?:son|daughter|brother|sister|father|mother|heir) of\b",
    r"\b(?:north|south|east|west) of\b",
)

# Heuristic weights (DR-060). Activation dominates because an entry that never fires
# cannot break immersion regardless of how wrong it is.
WEIGHTS = {"activation": 0.5, "dependents": 0.3, "claims": 0.2}


def _entries(manifest: dict[str, Any]) -> list[dict[str, Any]]:
    rows = manifest.get("entries")
    if not isinstance(rows, list):
        raise_error("manifest entries must be a list")
    return [r for r in rows if isinstance(r, dict)]


def _emit(entry: dict[str, Any]) -> dict[str, Any]:
    value = entry.get("emit")
    return value if isinstance(value, dict) else {}


def _text(entry: dict[str, Any]) -> str:
    for source in (entry, _emit(entry)):
        value = source.get("content")
        if isinstance(value, str):
            return value
    return ""


def activation_likelihood(entry: dict[str, Any]) -> float:
    """0..1. Constant entries are always present; disabled entries never fire."""
    emit = _emit(entry)
    if emit.get("enabled") is False or entry.get("disable") is True:
        return 0.0
    if emit.get("constant") is True or entry.get("constant") is True:
        return 1.0
    keys = emit.get("keys") or entry.get("keys") or entry.get("key") or []
    if not keys:
        return 0.05
    # More keys means more ways to fire. Saturating rather than linear: the tenth
    # keyword adds far less than the second.
    return min(0.9, 0.25 + 0.65 * (1 - math.exp(-len(keys) / 3)))


def dependent_count(uid: str, manifest: dict[str, Any]) -> int:
    """How many entries this one can pull in. A wrong hub corrupts its subtree."""
    edges = manifest.get("edges")
    if isinstance(edges, list):
        return sum(1 for e in edges if isinstance(e, dict) and str(e.get("source")) == uid)
    total = 0
    for entry in _entries(manifest):
        activation = entry.get("activation")
        if isinstance(activation, dict) and str(activation.get("parent", "")) == uid:
            total += 1
    return total


def claim_density(text: str) -> float:
    """0..1. Falsifiable assertions per hundred words."""
    words = len(re.findall(r"[A-Za-z']+", text)) or 1
    hits = sum(len(re.findall(p, text, re.IGNORECASE)) for p in CLAIM_PATTERNS)
    return min(1.0, (hits / words) * 100 / 8)


def rank(manifest: dict[str, Any]) -> dict[str, Any]:
    rows = _entries(manifest)
    max_dependents = 1
    scored: list[dict[str, Any]] = []
    for entry in rows:
        uid = entry_uid(entry, strict=False)
        dependents = dependent_count(uid, manifest)
        max_dependents = max(max_dependents, dependents)
        scored.append({
            "uid": uid,
            "activation": round(activation_likelihood(entry), 4),
            "dependents": dependents,
            "claim_density": round(claim_density(_text(entry)), 4),
        })
    for row in scored:
        row["priority"] = round(
            WEIGHTS["activation"] * row["activation"]
            + WEIGHTS["dependents"] * (row["dependents"] / max_dependents)
            + WEIGHTS["claims"] * row["claim_density"],
            4,
        )
    scored.sort(key=lambda r: (-r["priority"], r["uid"]))
    return {
        "kind": "worldbuilder-verification-ranking",
        "contract": CONTRACT,
        "entry_count": len(scored),
        "weights": WEIGHTS,
        "ranked": scored,
    }


def select_budget(ranking: dict[str, Any], budget: int) -> dict[str, Any]:
    """Top-N by priority. Everything below the line is labeled, not silently trusted."""
    if budget < 0:
        raise_error("verification budget must be non-negative")
    ranked = ranking["ranked"]
    return {
        "verify": [r["uid"] for r in ranked[:budget]],
        "below_budget": [r["uid"] for r in ranked[budget:]],
        "budget": budget,
        "coverage": round(min(1.0, budget / max(1, len(ranked))), 4),
    }


def label(manifest: dict[str, Any], results: dict[str, str], *, default: str = "unverified") -> dict[str, Any]:
    """Attach a confidence level to every entry.

    An entry the budget never reached is `unverified`, not `verified`. Absence of a
    contradiction is not evidence.
    """
    if default not in CONFIDENCE_LEVELS:
        raise_error(f"default confidence must be one of {CONFIDENCE_LEVELS}")
    bad = {uid: level for uid, level in results.items() if level not in CONFIDENCE_LEVELS}
    if bad:
        raise_error(f"unknown confidence levels: {bad}")
    labeled: dict[str, str] = {}
    for entry in _entries(manifest):
        uid = entry_uid(entry, strict=False)
        labeled[uid] = results.get(uid, default)
    counts = {level: sum(1 for v in labeled.values() if v == level) for level in CONFIDENCE_LEVELS}
    return {"labels": labeled, "counts": counts, "default_applied": default}


def derisk(labels: dict[str, str], policy: str) -> dict[str, Any]:
    """Apply the approved policy to unverified entries.

    `ship_labeled` is a legitimate choice: the user may prefer complete coverage with
    honest labels over a thinner book. It is recorded rather than silently allowed.
    """
    if policy not in DERISK_POLICIES:
        raise_error(f"de-risk policy must be one of {DERISK_POLICIES}")
    targets = sorted(uid for uid, level in labels.items() if level == "unverified")
    actions = {
        "disable": {"op": "set", "field": "enabled", "value": False,
                    "effect": "unverified entries ship disabled; the user enables them knowingly"},
        "deprioritize": {"op": "lower", "field": "insertion_order",
                         "effect": "verified entries win the budget when both match"},
        "despecify": {"op": "review", "field": "content",
                      "effect": "falsifiable specifics removed, atmosphere kept; a wrong date "
                                "breaks immersion, vague ambience cannot"},
        "ship_labeled": {"op": "none", "field": None,
                         "effect": "shipped as-is with confidence stated in the delivery report"},
    }
    return {
        "policy": policy,
        "action": actions[policy],
        "affected": targets,
        "affected_count": len(targets),
    }


def _projection_price(tokens: int, rates: dict[str, float] | None) -> dict[str, float] | None:
    if not rates:
        return None
    return {name: round(tokens / 1000 * rate, 2) for name, rate in rates.items()}


def _detail_from_state(root: Path, state: dict[str, Any]) -> str:
    budget_path = resolve_state_path(root, state, "budget_plan", required=False)
    profile = None
    if budget_path and budget_path.exists():
        budget = load_json(budget_path)
        if isinstance(budget, dict):
            profile = str(budget.get("profile_id") or "").casefold()
    if profile in {"quick", "compact"}:
        return "quick"
    if profile in {"maximum-detail", "full-detail", "maximum", "full"}:
        return "full"
    return "recommended"


def _era_count_from_state(root: Path, state: dict[str, Any]) -> int:
    if str((state.get("content_architecture") or {}).get("era_mode") or "single") != "multi":
        return 1
    era_path = resolve_state_path(root, state, "era_plan", required=False)
    if era_path and era_path.exists():
        plan = load_json(era_path)
        if isinstance(plan, dict) and isinstance(plan.get("eras"), list) and plan["eras"]:
            return len([row for row in plan["eras"] if isinstance(row, dict)]) or 1
    return 1


def _audit_call_estimate(state: dict[str, Any]) -> int:
    audit = state.get("audit") if isinstance(state.get("audit"), dict) else {}
    calls = 0
    if audit.get("pre_generation_required") is True:
        lenses = audit.get("pre_generation_lenses")
        calls += len(lenses) if isinstance(lenses, list) and lenses else 4
    if audit.get("post_generation_required") is True:
        calls += 4
    return calls


def _discovery_projection(root: Path, state: dict[str, Any]) -> tuple[int | None, int | None, dict[str, Any]]:
    required = bool((state.get("discovery") or {}).get("required", False))
    plan_path = resolve_state_path(root, state, "discovery_plan", required=False)
    if not required:
        return 0, 0, {"status": "not_required", "plan": None}
    if not plan_path or not plan_path.exists():
        return None, None, {
            "status": "unknown_until_discovery_plan_exists",
            "plan": str(plan_path) if plan_path else None,
        }
    plan = load_json(plan_path)
    if not isinstance(plan, dict):
        return None, None, {"status": "invalid_plan", "plan": str(plan_path)}
    assignments = plan.get("assignments") if isinstance(plan.get("assignments"), list) else []
    assignment_count = plan.get("total_assignment_count")
    if not isinstance(assignment_count, int) or isinstance(assignment_count, bool) or assignment_count < 0:
        assignment_count = len([row for row in assignments if isinstance(row, dict)])
    waves = plan.get("dispatch_waves")
    wave_count = len([row for row in waves if isinstance(row, dict)]) if isinstance(waves, list) else None
    return assignment_count, wave_count, {
        "status": "planned",
        "plan": str(plan_path),
        "primary_worker_count": plan.get("primary_worker_count"),
        "ramp_policy": plan.get("ramp_policy"),
    }


def project(entry_count: int, *, detail: str = "recommended", eras: int = 1,
            rates: dict[str, float] | None = None,
            discovery_assignment_count: int | None = None,
            discovery_wave_count: int | None = None,
            generation_worker_count: int | None = None,
            audit_calls_override: int | None = None,
            telemetry_rows: list[dict[str, Any]] | None = None,
            model: str | None = None,
            models_by_work_kind: dict[str, str | None] | None = None) -> dict[str, Any]:
    """Estimate a build in units. Rates are supplied, never assumed.

    With only entry_count/detail/eras this preserves the original 4.6.0 rough
    projection. Rich callers may supply real discovery/generation/audit structure and
    historical telemetry. Everything remains explicitly an estimate, never a guarantee.
    """
    if entry_count < 0 or eras < 1:
        raise_error("entry_count must be non-negative and eras at least 1")
    per_entry = {"quick": 1, "recommended": 2, "full": 3}.get(detail)
    if per_entry is None:
        raise_error("detail must be quick, recommended, or full")
    for name, value in (
        ("discovery_assignment_count", discovery_assignment_count),
        ("discovery_wave_count", discovery_wave_count),
        ("generation_worker_count", generation_worker_count),
        ("audit_calls_override", audit_calls_override),
    ):
        if value is not None and (isinstance(value, bool) or not isinstance(value, int) or value < 0):
            raise_error(f"{name} must be a non-negative integer or None")

    import gate_telemetry as gt

    generation_calls = entry_count * per_entry
    era_overhead = (eras - 1) * max(4, entry_count // 10)
    audit_calls = audit_calls_override if audit_calls_override is not None else 4 + math.ceil(entry_count / 15)
    worker_rounds = generation_worker_count if generation_worker_count is not None else math.ceil((generation_calls + era_overhead) / 15)

    rows = telemetry_rows or []
    role_models = dict(models_by_work_kind or {})

    def selected_model_for(kind: str) -> str | None:
        if model is not None:
            return model
        value = role_models.get(kind)
        return value if isinstance(value, str) and value and value not in {"inherit", "default"} else None

    work_kinds = ("discovery", "generation", "audit")
    rows_by_kind = {
        kind: [row for row in rows if gt.infer_work_kind(row) == kind]
        for kind in work_kinds
    }
    convergence_by_kind = {
        kind: gt.attempt_multiplier(rows_by_kind[kind], model=selected_model_for(kind))
        for kind in work_kinds
    }
    token_history_by_kind = {
        kind: gt.token_profile(rows_by_kind[kind], model=selected_model_for(kind))
        for kind in work_kinds
    }
    # Preserve the original single-model output shape for legacy callers. Build-aware
    # role routing instead reports the exact per-work-kind samples it used.
    if not role_models:
        convergence = convergence_by_kind["generation"]
        token_history = token_history_by_kind["generation"]
    else:
        convergence = {"by_work_kind": convergence_by_kind, "models": {k: selected_model_for(k) for k in convergence_by_kind}}
        token_history = {"by_work_kind": token_history_by_kind, "models": {k: selected_model_for(k) for k in token_history_by_kind}}

    generation_base_calls = generation_calls + era_overhead
    generation_multiplier = float(convergence_by_kind["generation"]["multiplier"])
    audit_multiplier = float(convergence_by_kind["audit"]["multiplier"])
    discovery_multiplier = float(convergence_by_kind["discovery"]["multiplier"])
    token_components: dict[str, dict[str, Any]] = {}
    gen_mean = token_history_by_kind["generation"]["mean_input_plus_output_tokens"].get("generation")
    if isinstance(gen_mean, (int, float)):
        generation_tokens = int(round(generation_base_calls * generation_multiplier * float(gen_mean)))
        gen_basis = "telemetry_mean_input_plus_output_tokens"
    else:
        generation_tokens = int(round(generation_base_calls * generation_multiplier * 1800))
        gen_basis = "static_1800_tokens_per_generation_call"
    token_components["generation"] = {
        "estimated_tokens": generation_tokens,
        "basis": gen_basis,
        "base_calls": generation_base_calls,
    }

    audit_mean = token_history_by_kind["audit"]["mean_input_plus_output_tokens"].get("audit")
    if isinstance(audit_mean, (int, float)):
        audit_tokens = int(round(audit_calls * audit_multiplier * float(audit_mean)))
        audit_basis = "telemetry_mean_input_plus_output_tokens"
    else:
        audit_tokens = int(round(audit_calls * audit_multiplier * 6000))
        audit_basis = "static_6000_tokens_per_audit_call"
    token_components["audit"] = {
        "estimated_tokens": audit_tokens,
        "basis": audit_basis,
        "base_calls": audit_calls,
    }

    discovery_tokens: int | None = None
    discovery_mean = token_history_by_kind["discovery"]["mean_input_plus_output_tokens"].get("discovery")
    if discovery_assignment_count is not None and isinstance(discovery_mean, (int, float)):
        discovery_tokens = int(round(discovery_assignment_count * discovery_multiplier * float(discovery_mean)))
        token_components["discovery"] = {
            "estimated_tokens": discovery_tokens,
            "basis": "telemetry_mean_input_plus_output_tokens",
            "base_calls": discovery_assignment_count,
        }
    elif discovery_assignment_count is not None:
        token_components["discovery"] = {
            "estimated_tokens": None,
            "basis": "unmodeled_without_observed_token_history",
            "base_calls": discovery_assignment_count,
        }

    estimated_tokens = generation_tokens + audit_tokens + (discovery_tokens or 0)
    base_model_calls = generation_base_calls + audit_calls + (discovery_assignment_count or 0)
    expected_attempts_float = (
        generation_base_calls * generation_multiplier
        + audit_calls * audit_multiplier
        + (discovery_assignment_count or 0) * discovery_multiplier
    )
    expected_model_attempts = int(math.ceil(expected_attempts_float))
    attempt_multiplier = (expected_attempts_float / base_model_calls) if base_model_calls else 1.0
    units = {
        "entries": entry_count,
        "eras": eras,
        "discovery_research_assignments": discovery_assignment_count,
        "discovery_dispatch_waves": discovery_wave_count,
        "generation_calls": generation_calls,
        "era_overhead_calls": era_overhead,
        "generation_worker_assignments": generation_worker_count,
        "audit_calls": audit_calls,
        "worker_rounds": worker_rounds,
        "base_model_calls": base_model_calls,
        "expected_model_attempts": expected_model_attempts,
        "attempt_multiplier": round(attempt_multiplier, 4),
        "attempt_multipliers_by_work_kind": {
            "discovery": round(discovery_multiplier, 4),
            "generation": round(generation_multiplier, 4),
            "audit": round(audit_multiplier, 4),
        },
        "estimated_tokens": estimated_tokens,
        "token_components": token_components,
    }
    result: dict[str, Any] = {
        "kind": "worldbuilder-cost-projection",
        "contract": CONTRACT,
        "projection_version": 2,
        "estimate_label": "estimate_not_guarantee",
        "detail": detail,
        "units": units,
        "convergence_basis": convergence,
        "token_history": token_history,
        "note": "Estimate, not a guarantee. It uses measured structure when supplied, measured convergence when available, and plainly labeled static token fallbacks otherwise. Prices are never hard-coded.",
    }
    if discovery_assignment_count is not None and discovery_tokens is None:
        result["token_scope_note"] = "Discovery research calls are counted, but discovery tokens are excluded until telemetry records an observed discovery-token sample."
    priced = _projection_price(estimated_tokens, rates)
    if priced is not None:
        result["estimated_cost"] = priced
        result["cost_note"] = "Order-of-magnitude estimate, not a billing guarantee. Any token component marked unmodeled is excluded from this price."
    return result


def project_build(build_state: str | Path, *, rates: dict[str, float] | None = None,
                  telemetry_ledger: str | Path | None = None,
                  model: str | None = None) -> dict[str, Any]:
    """Build-aware pre-freeze projection from already materialized planning facts."""
    import gate_telemetry as gt

    root, state = load_build_state(build_state)
    manifest_path = resolve_state_path(root, state, "manifest")
    if not manifest_path.exists():
        raise_error("build-aware projection requires the current manifest; do not invent entry count before planning creates it")
    manifest = load_json(manifest_path)
    if not isinstance(manifest, dict):
        raise_error("manifest must be a JSON object")
    entry_count = len(_entries(manifest))
    detail = _detail_from_state(root, state)
    eras = _era_count_from_state(root, state)
    max_batch = int((state.get("batching") or {}).get("generation_entries_per_worker", 15))
    generation_partition = gt.partition(manifest, max_batch=max_batch)
    discovery_assignments, discovery_waves, discovery_basis = _discovery_projection(root, state)
    audit_calls = _audit_call_estimate(state)

    ledger_path = Path(telemetry_ledger).expanduser().resolve() if telemetry_ledger else (root / ".work" / gt.LEDGER_NAME)
    rows = gt.read_ledger(ledger_path)
    selected_model = model
    state_models = state.get("models") or {}
    role_models = None
    if selected_model is None:
        role_models = {
            "discovery": str(state_models.get("discovery", state_models.get("subagent", "inherit"))),
            "generation": str(state_models.get("generation", state_models.get("subagent", "inherit"))),
            "audit": str(state_models.get("audit", state_models.get("subagent", "inherit"))),
        }
    result = project(
        entry_count,
        detail=detail,
        eras=eras,
        rates=rates,
        discovery_assignment_count=discovery_assignments,
        discovery_wave_count=discovery_waves,
        generation_worker_count=int(generation_partition.get("batch_count", 0)),
        audit_calls_override=audit_calls,
        telemetry_rows=rows,
        model=selected_model,
        models_by_work_kind=role_models,
    )
    result["build_id"] = state.get("build_id")
    result["basis"] = {
        "manifest": str(manifest_path),
        "model_routing": {
            "explicit_telemetry_model_override": selected_model,
            "roles": role_models,
        },
        "generation_partition": {
            "max_batch": max_batch,
            "batch_count": generation_partition.get("batch_count"),
            "density_bands": generation_partition.get("density_bands"),
        },
        "discovery": discovery_basis,
        "audit": {
            "pre_generation_required": bool((state.get("audit") or {}).get("pre_generation_required", False)),
            "post_generation_required": bool((state.get("audit") or {}).get("post_generation_required", False)),
        },
        "telemetry_ledger": str(ledger_path),
        "telemetry_rows": len(rows),
    }
    structural_known = discovery_assignments is not None
    token_history = result.get("token_history") or {}
    if isinstance(token_history.get("by_work_kind"), dict):
        token_samples = sum(
            int((profile or {}).get("total_token_samples", 0) or 0)
            for profile in token_history["by_work_kind"].values()
            if isinstance(profile, dict)
        )
    else:
        token_samples = int(token_history.get("total_token_samples", 0) or 0)
    result["estimate_confidence"] = "higher" if structural_known and token_samples else ("medium" if structural_known else "low")
    return result


def _count_completed_auditors(root: Path, state: dict[str, Any]) -> int:
    total = 0
    for key in ("pre_generation_audit_receipt", "post_generation_audit_receipt"):
        path = resolve_state_path(root, state, key, required=False)
        if not path or not path.exists():
            continue
        receipt = load_json(path)
        auditors = receipt.get("auditors") if isinstance(receipt, dict) else None
        if isinstance(auditors, list):
            total += len([row for row in auditors if isinstance(row, dict)])
    return total


def _final_output_token_estimate(root: Path, state: dict[str, Any]) -> int | None:
    path = resolve_state_path(root, state, "final_output", required=False)
    if not path or not path.exists() or not path.is_file():
        return None
    try:
        from budget_contract import estimate_tokens
        if path.suffix.casefold() in {".json"}:
            return estimate_tokens(load_json(path))
        if path.suffix.casefold() in {".txt", ".md"}:
            return estimate_tokens(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError, WorldBuilderError):
        return None
    return None


def collect_actual_usage(build_state: str | Path, *, telemetry_ledger: str | Path | None = None) -> dict[str, Any]:
    """Collect final observed resource counts without pretending host billing data exists."""
    import gate_telemetry as gt

    root, state = load_build_state(build_state)
    assignments_dir = resolve_state_path(root, state, "assignments", required=False)
    generation_assignments = 0
    generation_completed = 0
    if assignments_dir and assignments_dir.exists():
        for path in assignments_dir.glob("*.json"):
            try:
                assignment = load_json(path)
            except (OSError, json.JSONDecodeError):
                continue
            if not isinstance(assignment, dict) or assignment.get("role") != "generation":
                continue
            generation_assignments += 1
            output = assignment.get("output")
            if isinstance(output, str) and output and (root / output).resolve().exists():
                generation_completed += 1

    discovery_completed = 0
    discovery_runtime = resolve_state_path(root, state, "discovery_runtime", required=False)
    if discovery_runtime and discovery_runtime.exists():
        for path in discovery_runtime.glob("*.json"):
            try:
                row = load_json(path)
            except (OSError, json.JSONDecodeError):
                continue
            if isinstance(row, dict) and row.get("kind") == "worldbuilder-child-runtime-receipt" and row.get("status") == "completed":
                discovery_completed += 1

    worker_statuses: dict[str, int] = {}
    ledger_path = resolve_state_path(root, state, "worker_run_ledger", required=False)
    if ledger_path and ledger_path.exists():
        try:
            run_ledger = load_json(ledger_path)
            runs = run_ledger.get("runs") if isinstance(run_ledger, dict) else None
            if isinstance(runs, dict):
                for row in runs.values():
                    if isinstance(row, dict):
                        status = str(row.get("status") or "unknown")
                        worker_statuses[status] = worker_statuses.get(status, 0) + 1
        except (OSError, json.JSONDecodeError):
            pass

    telemetry_path = Path(telemetry_ledger).expanduser().resolve() if telemetry_ledger else (root / ".work" / gt.LEDGER_NAME)
    telemetry_rows = gt.read_ledger(telemetry_path)
    observed_tokens = 0
    token_rows = 0
    for row in telemetry_rows:
        seen = False
        for field in ("input_tokens", "output_tokens"):
            value = row.get(field)
            if isinstance(value, int) and not isinstance(value, bool) and value >= 0:
                observed_tokens += value
                seen = True
        if seen:
            token_rows += 1

    return {
        "kind": "worldbuilder-resource-usage",
        "contract": "worldbuilder-resource-usage-v1",
        "measurement_label": "observed_where_available",
        "build_id": state.get("build_id"),
        "units": {
            "discovery_completed_runtime_receipts": discovery_completed,
            "generation_assignments": generation_assignments,
            "generation_assignments_with_output": generation_completed,
            "audit_completed_lens_receipts": _count_completed_auditors(root, state),
            "worker_run_statuses": worker_statuses,
            "gate_attempts": len(telemetry_rows),
            "observed_input_plus_output_tokens": observed_tokens if token_rows else None,
            "observed_token_rows": token_rows,
            "final_output_authored_token_estimate": _final_output_token_estimate(root, state),
        },
        "note": "Counts come from build receipts/ledgers. Provider model-token usage is reported only when telemetry explicitly recorded it; final-output authored tokens are a content-size estimate, not provider billing usage.",
    }


def reconcile_projection(build_state: str | Path, projection: dict[str, Any], *,
                         telemetry_ledger: str | Path | None = None) -> dict[str, Any]:
    actual = collect_actual_usage(build_state, telemetry_ledger=telemetry_ledger)
    root, state = load_build_state(build_state)
    if projection.get("build_id") not in (None, state.get("build_id")):
        raise_error("projection belongs to another build")
    estimated = projection.get("units") if isinstance(projection.get("units"), dict) else {}
    observed = actual["units"]
    comparable = {
        "discovery_worker_calls": (estimated.get("discovery_research_assignments"), observed.get("discovery_completed_runtime_receipts")),
        "generation_worker_assignments": (estimated.get("generation_worker_assignments"), observed.get("generation_assignments")),
        "audit_calls": (estimated.get("audit_calls"), observed.get("audit_completed_lens_receipts")),
    }
    variance: dict[str, Any] = {}
    for key, (estimate, real) in comparable.items():
        if isinstance(estimate, int) and isinstance(real, int):
            variance[key] = {"estimated": estimate, "actual": real, "delta": real - estimate}
    return {
        "kind": "worldbuilder-cost-comparison",
        "contract": "worldbuilder-cost-comparison-v1",
        "build_id": state.get("build_id"),
        "estimate_label": "estimate_not_guarantee",
        "projection": projection,
        "actual": actual,
        "comparable_variance": variance,
        "note": "The pre-build projection is retained unchanged beside final observed usage. Deltas are descriptive, not pass/fail gates.",
    }

def main() -> int:
    parser = argparse.ArgumentParser(description="Verification triage and cost projection.")
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("rank", help="score entries by verification priority")
    p.add_argument("--manifest", required=True)
    p.add_argument("--budget", type=int)
    p.add_argument("--out")

    p = sub.add_parser("label", help="apply confidence labels")
    p.add_argument("--manifest", required=True)
    p.add_argument("--results", help="JSON file mapping uid -> confidence level")
    p.add_argument("--default", default="unverified", choices=list(CONFIDENCE_LEVELS))

    p = sub.add_parser("derisk", help="apply the approved policy to unverified entries")
    p.add_argument("--labels", required=True, help="JSON file mapping uid -> confidence level")
    p.add_argument("--policy", required=True, choices=list(DERISK_POLICIES))

    p = sub.add_parser("project", help="estimate build cost in units")
    source = p.add_mutually_exclusive_group(required=True)
    source.add_argument("--entries", type=int)
    source.add_argument("--build-state")
    p.add_argument("--detail", default="recommended", choices=["quick", "recommended", "full"])
    p.add_argument("--eras", type=int, default=1)
    p.add_argument("--telemetry-ledger")
    p.add_argument("--model")
    p.add_argument("--out")
    p.add_argument("--replace-projection", action="store_true",
                   help="explicitly replace an existing build-state projection")
    p.add_argument("--rate-per-1k", type=float, help="model rate per 1000 tokens")

    p = sub.add_parser("reconcile", help="show a saved pre-build estimate beside final observed usage")
    p.add_argument("--build-state", required=True)
    p.add_argument("--projection", help="projection JSON; defaults to build-state paths.cost_projection")
    p.add_argument("--telemetry-ledger")
    p.add_argument("--out")

    args = parser.parse_args()
    try:
        if args.command == "rank":
            ranking = rank(load_json(Path(args.manifest).expanduser().resolve()))
            if args.budget is not None:
                ranking["selection"] = select_budget(ranking, args.budget)
            if args.out:
                atomic_write_json(Path(args.out).expanduser().resolve(), ranking)
            result = ranking
        elif args.command == "label":
            results = load_json(Path(args.results).expanduser().resolve()) if args.results else {}
            result = label(load_json(Path(args.manifest).expanduser().resolve()),
                           results if isinstance(results, dict) else {}, default=args.default)
        elif args.command == "derisk":
            labels = load_json(Path(args.labels).expanduser().resolve())
            result = derisk(labels if isinstance(labels, dict) else {}, args.policy)
        elif args.command == "project":
            rates = {"model": args.rate_per_1k} if args.rate_per_1k is not None else None
            if args.build_state:
                result = project_build(args.build_state, rates=rates, telemetry_ledger=args.telemetry_ledger, model=args.model)
                root, state = load_build_state(args.build_state)
                out_path = Path(args.out).expanduser().resolve() if args.out else (resolve_state_path(root, state, "cost_projection", required=False) or (root / "artifacts" / "cost-projection.json"))
                if out_path.exists() and not args.replace_projection:
                    raise WorldBuilderError(
                        f"cost projection already exists: {out_path}; keep the pre-build estimate frozen, "
                        "or pass --replace-projection for an explicit replacement")
                atomic_write_json(out_path, result)
                result["saved_to"] = str(out_path)
            else:
                rows = []
                if args.telemetry_ledger:
                    import gate_telemetry as gt
                    rows = gt.read_ledger(Path(args.telemetry_ledger).expanduser().resolve())
                result = project(args.entries, detail=args.detail, eras=args.eras, rates=rates,
                                 telemetry_rows=rows, model=args.model)
                if args.out:
                    atomic_write_json(Path(args.out).expanduser().resolve(), result)
        else:
            root, state = load_build_state(args.build_state)
            projection_path = Path(args.projection).expanduser().resolve() if args.projection else (resolve_state_path(root, state, "cost_projection", required=False) or (root / "artifacts" / "cost-projection.json"))
            if not projection_path.exists():
                raise WorldBuilderError(f"cost projection does not exist: {projection_path}")
            result = reconcile_projection(args.build_state, load_json(projection_path), telemetry_ledger=args.telemetry_ledger)
            out_path = Path(args.out).expanduser().resolve() if args.out else (resolve_state_path(root, state, "resource_usage", required=False) or (root / "artifacts" / "resource-usage.json"))
            atomic_write_json(out_path, result)
            result["saved_to"] = str(out_path)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (WorldBuilderError, OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
