#!/usr/bin/env python3
"""Plan and materialize multi-lorebook packages as independent WorldBuilder builds.

Package planning stays above the ordinary pipeline.  Each book owns its own
``build-state.json`` and therefore uses the existing stage ledger unchanged.
Cross-book dependencies live only in the parent package registry.
"""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Any

from wb_common import WorldBuilderError, atomic_write_json, build_identity_index, load_json, now_iso, sha256_file

CONTRACT = "worldbuilder-package-plan-v1"
DEPENDENCY_CONTRACT = "worldbuilder-package-dependencies-v1"


def validate_spec(spec: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(spec, dict): raise WorldBuilderError("package plan spec must be an object")
    mode = spec.get("mode", "multi")
    if mode not in {"single", "multi"}: raise WorldBuilderError("package plan mode must be single or multi")
    books = spec.get("books")
    if not isinstance(books, list) or not books: raise WorldBuilderError("package plan requires books: []")
    names=set(); normalized=[]
    for row in books:
        if not isinstance(row, dict): raise WorldBuilderError("each package book must be an object")
        name=str(row.get("name","")).strip()
        if not name or name in names: raise WorldBuilderError(f"package book name is empty or duplicated: {name!r}")
        names.add(name)
        artifact_type=row.get("artifact_type","lorebook")
        if artifact_type not in {"lorebook","world","card","persona"}: raise WorldBuilderError(f"unsupported package artifact_type {artifact_type!r}")
        normalized.append({**row,"name":name,"artifact_type":artifact_type,"source_kind":row.get("source_kind","original")})
    deps=spec.get("dependencies",[])
    if not isinstance(deps,list): raise WorldBuilderError("package dependencies must be a list")
    for d in deps:
        if not isinstance(d,dict) or d.get("from_book") not in names or d.get("to_book") not in names:
            raise WorldBuilderError("each cross-book dependency must name existing from_book/to_book values")
    return {"contract":CONTRACT,"created_at":now_iso(),"mode":mode,"books":normalized,"dependencies":deps,"shared_source_plan":spec.get("shared_source_plan")}


def create(package_root: str, spec_path: str) -> dict[str, Any]:
    root=Path(package_root).resolve(); root.mkdir(parents=True,exist_ok=True)
    spec=validate_spec(load_json(Path(spec_path).resolve()))
    plan=root/"package-plan.json"; deps=root/"package-dependencies.json"
    atomic_write_json(plan,spec)
    atomic_write_json(deps,{"contract":DEPENDENCY_CONTRACT,"created_at":now_iso(),"dependencies":spec["dependencies"],"books":{}})
    return {"status":"planned","package_plan":str(plan),"dependencies":str(deps)}


def materialize(package_root: str, *, workspace: str | None=None) -> dict[str, Any]:
    root=Path(package_root).resolve(); plan_path=root/"package-plan.json"; plan=load_json(plan_path)
    if plan.get("contract")!=CONTRACT: raise WorldBuilderError("package-plan.json has unsupported contract")
    workspace_path=Path(workspace).expanduser().resolve() if workspace else (root/"workspace").resolve()
    workspace_path.mkdir(parents=True,exist_ok=True)
    children={}
    init=Path(__file__).resolve().parent/"init_build.py"
    for book in plan["books"]:
        name=book["name"]
        child_dir=workspace_path/"builds"/name.casefold().replace(" ","-")
        args=[sys.executable,str(init),name,"--workspace",str(workspace_path),"--build-dir",str(child_dir),"--artifact-type",str(book.get("artifact_type","lorebook")),"--source-kind",str(book.get("source_kind","original")),"--schema",str(book.get("schema","auto"))]
        proc=subprocess.run(args,text=True,capture_output=True,encoding="utf-8")
        if proc.returncode!=0: raise WorldBuilderError(f"failed to materialize package book {name!r}: {proc.stderr.strip() or proc.stdout.strip()}")
        state_path=child_dir/"build-state.json"; state=load_json(state_path)
        state["package"]={"package_root":str(root),"package_plan_sha256":sha256_file(plan_path),"book_name":name,"shared_source_plan":plan.get("shared_source_plan")}
        atomic_write_json(state_path,state)
        children[name]={"build_state":str(state_path),"build_id":state.get("build_id")}
    dep_path=root/"package-dependencies.json"; dep=load_json(dep_path); dep["books"]=children; dep["package_plan_sha256"]=sha256_file(plan_path); atomic_write_json(dep_path,dep)
    return {"status":"materialized","books":children,"pipeline_stage_gate_modified":False}


def validate_dependencies(package_root: str) -> dict[str, Any]:
    root=Path(package_root).resolve(); dep=load_json(root/"package-dependencies.json")
    books=dep.get("books",{}); problems=[]
    manifests={}
    for name,meta in books.items():
        state=load_json(Path(meta["build_state"])); build_root=Path(meta["build_state"]).resolve().parent
        rel=(state.get("paths") or {}).get("manifest"); path=build_root/rel if rel else None
        manifests[name]=load_json(path) if path and path.exists() else None
    for row in dep.get("dependencies",[]):
        source=row.get("to_book"); target=manifests.get(source)
        if target is None:
            problems.append({"dependency":row,"problem":"target book manifest missing"}); continue
        idx=build_identity_index(target)
        uid=row.get("to_uid")
        if uid is not None:
            from wb_common import normalize_identity
            entry=idx.get(normalize_identity(uid),(None,None))[1]
            if entry is None:
                problems.append({"dependency":row,"problem":f"target UID {uid} missing"}); continue
            expected=row.get("to_name")
            actual=entry.get("name") or entry.get("comment")
            if expected and actual!=expected: problems.append({"dependency":row,"problem":f"target UID {uid} renamed from {expected!r} to {actual!r}"})
    return {"status":"ok" if not problems else "broken","problems":problems,"dependency_count":len(dep.get("dependencies",[]))}


def main()->int:
    p=argparse.ArgumentParser(description=__doc__); p.add_argument("--package-root",required=True)
    sub=p.add_subparsers(dest="command",required=True)
    c=sub.add_parser("create"); c.add_argument("--spec",required=True)
    m=sub.add_parser("materialize"); m.add_argument("--workspace")
    sub.add_parser("validate")
    a=p.parse_args()
    try:
        result=create(a.package_root,a.spec) if a.command=="create" else materialize(a.package_root,workspace=getattr(a,"workspace",None)) if a.command=="materialize" else validate_dependencies(a.package_root)
        print(json.dumps(result,ensure_ascii=False,indent=2)); return 0
    except (WorldBuilderError,OSError,ValueError,json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}",file=sys.stderr); return 1

if __name__=="__main__": raise SystemExit(main())
