#!/usr/bin/env python3
"""Prune revamp: dominator analysis on the activation graph.

Ancestor redundancy is provable; sibling redundancy is not. If entry C
only fires because B's content emitted C's key, then C being in context
guarantees B is in context; anything C repeats from B is redundant
every time C fires. This module computes each entry's dominator set: the
entries that are GUARANTEED to also be in context whenever this one is.
Overlap with an entry's dominator set is safe to cut; overlap with
anything else (a sibling, a cousin) is a report, not a cut; that
guarantee simply does not hold there.

Standard algorithm (Cooper, Harvey, Kennedy, "A Simple, Fast Dominance
Algorithm"): a node's immediate dominator is computed by iterating to a
fixed point over a reverse-postorder walk, intersecting each node's
already-processed predecessors' dominator chains. This is the same
algorithm compilers use for control-flow analysis; the graph sizes here
(hundreds of entries, not millions) make the simple iterative version
appropriate over the more complex Lengauer-Tarjan optimization.

Multiple seeds and always-active constants are handled with a single
virtual root connected to all of them: an entry dominated only by the
virtual root has no real dominator at all (nothing but the empty
activation state is guaranteed alongside it).
"""
from __future__ import annotations

from typing import Any

VIRTUAL_ROOT = "__virtual_root__"


def _reverse_postorder(root: str, successors: dict[str, list[str]]) -> list[str]:
    """DFS-based reverse postorder from root. Nodes unreachable from root
    are never visited; reverse postorder is only meaningful relative to
    a specific root, and the dominator algorithm below only defines
    dominance for nodes actually reachable from it."""
    visited: set[str] = set()
    postorder: list[str] = []

    def visit(node: str) -> None:
        if node in visited:
            return
        visited.add(node)
        for succ in successors.get(node, []):
            visit(succ)
        postorder.append(node)

    visit(root)
    return list(reversed(postorder))


def compute_dominators(root: str, edges: list[tuple[str, str]]) -> dict[str, str]:
    """Returns immediate-dominator map: idom[n] is n's immediate dominator.
    idom[root] == root. Only nodes reachable from root appear in the
    result: an unreachable node has no defined dominance relationship to
    root at all, and including one would be a fabricated answer, not a
    computed one.

    edges: list of (source, target) pairs, meaning source's activation can
    trigger target's (an emit relationship). This is a plain function of
    (root, edges); no manifest-specific knowledge here at all, so it can
    be tested and trusted independently of everything built on top of it.
    """
    successors: dict[str, list[str]] = {}
    predecessors: dict[str, list[str]] = {}
    nodes: set[str] = {root}
    for source, target in edges:
        successors.setdefault(source, []).append(target)
        predecessors.setdefault(target, []).append(source)
        nodes.add(source)
        nodes.add(target)

    rpo = _reverse_postorder(root, successors)
    if not rpo or rpo[0] != root:
        # root has no outgoing reach at all (isolated node); it still
        # dominates itself, nothing else is reachable to consider.
        return {root: root}
    rpo_number = {node: i for i, node in enumerate(rpo)}

    idom: dict[str, str] = {root: root}

    def intersect(a: str, b: str) -> str:
        while a != b:
            while rpo_number[a] > rpo_number[b]:
                a = idom[a]
            while rpo_number[b] > rpo_number[a]:
                b = idom[b]
        return a

    changed = True
    while changed:
        changed = False
        for node in rpo[1:]:  # skip root
            preds = [p for p in predecessors.get(node, []) if p in rpo_number]
            processed_preds = [p for p in preds if p in idom]
            if not processed_preds:
                continue
            new_idom = processed_preds[0]
            for pred in processed_preds[1:]:
                new_idom = intersect(new_idom, pred)
            if idom.get(node) != new_idom:
                idom[node] = new_idom
                changed = True

    return idom


def dominator_set(node: str, idom: dict[str, str]) -> list[str]:
    """The full chain from node up to the root, inclusive of node itself.
    Returns [] if node was never reachable from root (not present in idom
    at all): an unreachable node has no dominator chain to report."""
    if node not in idom:
        return []
    chain = [node]
    while chain[-1] != idom[chain[-1]]:
        chain.append(idom[chain[-1]])
    return chain


def build_virtual_rooted_edges(
    seed_uids: list[str], constant_uids: list[str], graph_edges: list[dict[str, Any]],
) -> list[tuple[str, str]]:
    """Wires a single virtual root through every always-active constant
    first, chained in sequence, THEN branches out to every seed, never
    constants and seeds as parallel, independent children of the root.
    Parallel wiring would only guarantee a constant for paths that happen
    to pass through it, which is wrong: a constant is unconditionally
    present regardless of which specific seed actually fired. Chaining
    constants before the branch point means every seed (and everything
    reachable from it) is provably dominated by all of them, matching
    what "always active" actually means. Real activation-graph edges are
    added on top of both. Vectorized-entry edges must already be excluded
    by the caller before this point; vector retrieval is a path this
    graph does not model, so an edge touching one is not a real graph
    edge for dominance purposes at all."""
    edges: list[tuple[str, str]] = []
    chain_head = VIRTUAL_ROOT
    for constant_uid in sorted(set(constant_uids)):
        edges.append((chain_head, constant_uid))
        chain_head = constant_uid
    for seed_uid in sorted(set(seed_uids) - set(constant_uids)):
        edges.append((chain_head, seed_uid))
    for edge in graph_edges:
        source = edge.get("source_uid")
        target = edge.get("target_uid")
        if source is not None and target is not None:
            edges.append((str(source), str(target)))
    return edges
