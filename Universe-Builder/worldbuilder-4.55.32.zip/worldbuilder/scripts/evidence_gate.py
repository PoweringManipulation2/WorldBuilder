#!/usr/bin/env python3
"""Validate per-assignment research coverage before generation is accepted.

Generation assignments in WorldBuilder 3.6 use a two-stage contract:

1. Research every assigned UID and write a structured evidence ledger.
2. Run this gate to bind that evidence to the exact assignment and manifest.
3. Generate the phase while recording the resulting evidence and receipt hashes.

The gate is deterministic. It does not judge prose quality, but it prevents a
phase from being accepted when an assigned UID was skipped, required topics
were not covered, sources/claims are malformed, or the evidence belongs to a
different assignment/build.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
import time
from pathlib import Path
from typing import Any

from activation_map_gate import validate_assignment_slice
from source_semantics import (
    SOURCE_QUALITY_CONTRACT,
    derive_canon_conflicts,
    merge_derived_conflicts,
    normalize_source_type,
    validate_canon_precedence,
    validate_source_type_weights,
    weighted_claim_confidence,
)

from wb_common import (
    verify_workspace_root,
    step_driver_pointer,
    WorldBuilderError,
    atomic_write_json,
    canonical_entry_identity,
    ensure_inside,
    iter_entries,
    load_build_state,
    load_json,
    resolve_state_path,
    sha256_file,
    uid_key,
)

ALLOWED_RESEARCH_MODES = {"public_web", "provided_sources", "mixed"}
ALLOWED_RESEARCH_STATUS = {"complete", "user_canonical", "not_found"}
ALLOWED_TOPIC_STATUS = {"supported", "conflicted", "not_found", "not_applicable"}
ALLOWED_CLAIM_KINDS = {"direct", "inference", "user_canonical"}
ALLOWED_CONFIDENCE = {"high", "medium", "low"}
URL_RE = re.compile(r"^https?://", re.IGNORECASE)


def required_assignment_version(build_root: Path, state: dict[str, Any]) -> int:
    planning = state.get("planning") if isinstance(state.get("planning"), dict) else {}
    configured = int(planning.get("generation_assignment_version", 2) or 2)
    if configured < 3:
        return configured
    try:
        receipt_path = resolve_state_path(build_root, state, "planning_receipt")
    except WorldBuilderError:
        return 2
    if not receipt_path.exists():
        return 2
    receipt = load_json(receipt_path)
    if isinstance(receipt, dict) and int(receipt.get("receipt_version", 0) or 0) >= 2 and receipt.get("status") == "passed":
        return 3
    return 2


# 5.8: "Cap the overflow record at claim IDs plus a one-line descriptor per
# item." Not a number the plan gives directly: a documented choice, sized
# for a genuinely single terminal line rather than a paragraph masquerading
# as one; the evidence ledger already holds the full text, so this is a
# pointer list, never a place for the content itself to leak back in.
MAX_OVERFLOW_DESCRIPTOR_CHARS = 200
OVERFLOW_TIERS = {"2", "3"}  # Tier 0 is never cut; Tier 1 is cut last, not routed to overflow.


def validate_overflow_record(record: Any, *, valid_uids: set[str] | None = None) -> dict[str, Any]:
    """5.8: a worker cutting Tier 2/3 material must route it, not delete it;
    but the record itself must stay a pointer list, never a second copy of
    the prose it points at. Raises on anything that looks like content
    smuggled back in through the descriptor."""
    if not isinstance(record, dict):
        raise WorldBuilderError(f"overflow record must be a JSON object, found {type(record).__name__}")
    source_uid = record.get("source_uid")
    if source_uid is None or not str(source_uid).strip():
        raise WorldBuilderError(f"overflow record is missing source_uid (found {source_uid!r}): every overflow record must name the UID whose material it points at")
    source_uid = uid_key(source_uid)
    if valid_uids is not None and source_uid not in valid_uids:
        raise WorldBuilderError(f"overflow record source_uid {source_uid} is not in this assignment")
    tier = record.get("tier")
    if str(tier) not in OVERFLOW_TIERS:
        raise WorldBuilderError(
            f"overflow record tier must be one of {sorted(OVERFLOW_TIERS)} (Tier 0 is never cut; "
            "Tier 1 is cut last, not routed to overflow)"
        )
    claim_ids = record.get("claim_ids")
    if not isinstance(claim_ids, list) or not claim_ids or not all(isinstance(c, str) and c.strip() for c in claim_ids):
        raise WorldBuilderError(f"overflow record for {source_uid} needs a non-empty list of claim_ids (pointers, not text)")
    descriptor = record.get("descriptor")
    if not isinstance(descriptor, str) or not descriptor.strip():
        raise WorldBuilderError(f"overflow record for {source_uid} is missing a descriptor")
    if "\n" in descriptor or "\r" in descriptor:
        raise WorldBuilderError(f"overflow record descriptor for {source_uid} must be one line, not multi-line prose")
    if len(descriptor) > MAX_OVERFLOW_DESCRIPTOR_CHARS:
        raise WorldBuilderError(
            f"overflow record descriptor for {source_uid} is {len(descriptor)} chars, over the "
            f"{MAX_OVERFLOW_DESCRIPTOR_CHARS}-char cap: point at the evidence ledger, don't restate it"
        )
    return {
        "source_uid": source_uid, "tier": str(tier),
        "claim_ids": [c.strip() for c in claim_ids], "descriptor": descriptor.strip(),
    }


def require_relative_build_path(build_root: Path, value: Any, field: str) -> Path:
    if not isinstance(value, str) or not value.strip():
        raise WorldBuilderError(f"assignment field {field!r} must be a non-empty relative path string, found {value!r}")
    raw = Path(os.path.expandvars(os.path.expanduser(value.strip())))
    if raw.is_absolute():
        raise WorldBuilderError(f"assignment field {field!r} ({value!r}) must be relative to the build root, not an absolute path")
    path = (build_root / raw).resolve()
    ensure_inside(path, build_root)
    return path


def validate_assignment(assignment: Any, build_id: str, manifest_sha: str, generation_batch_limit: int = 15, required_version: int = 2, *, root: Path | None = None, state: dict[str, Any] | None = None) -> dict[str, Any]:
    if not isinstance(assignment, dict):
        raise WorldBuilderError(f"generation assignment must be a JSON object, found {type(assignment).__name__}")
    version = assignment.get("assignment_version")
    if version not in {2, 3}:
        raise WorldBuilderError(f"generation assignment_version must be 2 or 3, found {version!r}")
    if version < required_version:
        raise WorldBuilderError(f"generation assignment_version is {version}, but this build requires at least {required_version}: regenerate the assignment from current planning outputs")
    if assignment.get("role") != "generation":
        raise WorldBuilderError(f"evidence_gate.py only accepts role='generation' assignments, found role={assignment.get('role')!r}")
    if assignment.get("build_id") != build_id:
        raise WorldBuilderError(f"assignment's build_id ({assignment.get('build_id')!r}) does not match this build-state.json's own build_id ({build_id!r})")
    if root is not None:
        verify_workspace_root(assignment, root)
        if state is not None:
            assignment["_manifest_binding"] = verify_manifest_binding(assignment, root, state, manifest_sha)
    assignment_id = assignment.get("assignment_id")
    if not isinstance(assignment_id, str) or not assignment_id.strip():
        raise WorldBuilderError(f"assignment_id must be a non-empty string, found {assignment_id!r}")
    mode = assignment.get("research_mode")
    if mode not in ALLOWED_RESEARCH_MODES:
        raise WorldBuilderError(
            f"research_mode is {mode!r}; must be one of: " + ", ".join(sorted(ALLOWED_RESEARCH_MODES))
        )
    entries = assignment.get("entries")
    if not isinstance(entries, list) or not entries:
        raise WorldBuilderError(f"assignment 'entries' must be a non-empty list, found {entries!r}")
    if len(entries) > generation_batch_limit:
        raise WorldBuilderError(
            f"generation assignment contains {len(entries)} entries; configured hard maximum is {generation_batch_limit}: "
            "split the assignment into smaller batches or raise batching.generation_entries_per_worker if that's genuinely intended"
        )

    by_uid: dict[str, dict[str, Any]] = {}
    for index, entry in enumerate(entries):
        if not isinstance(entry, dict):
            raise WorldBuilderError(f"assignment entries[{index}] must be a JSON object, found {type(entry).__name__}")
        if "uid" not in entry:
            raise WorldBuilderError(f"assignment entries[{index}] has no 'uid' field: {entry!r}")
        key = uid_key(entry["uid"])
        if key in by_uid:
            raise WorldBuilderError(f"assignment contains duplicate uid {key}: each assigned UID must appear exactly once")
        name = entry.get("name")
        if not isinstance(name, str) or not name.strip():
            raise WorldBuilderError(f"assignment uid {key} has no non-empty 'name' field")
        topics = entry.get("research_topics")
        if not isinstance(topics, list) or not topics:
            raise WorldBuilderError(f"assignment uid {key} must declare a non-empty 'research_topics' list")
        clean_topics: list[str] = []
        for topic in topics:
            if not isinstance(topic, str) or not topic.strip():
                raise WorldBuilderError(f"assignment uid {key} has an invalid research topic: {topic!r} (must be a non-empty string)")
            normalized = topic.strip().casefold()
            if normalized in clean_topics:
                raise WorldBuilderError(f"assignment uid {key} repeats research topic {topic!r}: each topic must be listed once")
            clean_topics.append(normalized)
        by_uid[key] = {"entry": entry, "topics": clean_topics}
    if version >= 3:
        for field in ("activation_map_sha256", "field_registry_sha256", "default_profile_sha256"):
            value = assignment.get(field)
            if not isinstance(value, str) or not re.fullmatch(r"[0-9a-fA-F]{64}", value):
                raise WorldBuilderError(f"generation assignment field {field!r} must be a 64-character hex SHA-256 string, found {value!r}")
        if not isinstance(assignment.get("map_slice"), dict):
            raise WorldBuilderError("generation assignment_version 3 requires a 'map_slice' object: regenerate the assignment from current planning outputs")
        map_slice = assignment.get("map_slice")
        if isinstance(map_slice, dict) and map_slice.get("character_plan_sha256") is not None:
            value = assignment.get("character_plan_sha256")
            if not isinstance(value, str) or not re.fullmatch(r"[0-9a-fA-F]{64}", value):
                raise WorldBuilderError(f"this map_slice declares character_plan_sha256, so the assignment's own character_plan_sha256 field must be a 64-character hex SHA-256 string, found {value!r}")
        if isinstance(map_slice, dict) and map_slice.get("era_plan_sha256") is not None:
            value = assignment.get("era_plan_sha256")
            if not isinstance(value, str) or not re.fullmatch(r"[0-9a-fA-F]{64}", value):
                raise WorldBuilderError(f"this map_slice declares era_plan_sha256, so the assignment's own era_plan_sha256 field must be a 64-character hex SHA-256 string, found {value!r}")
        if isinstance(map_slice, dict) and map_slice.get("placement_plan_sha256") is not None:
            value = assignment.get("placement_plan_sha256")
            if not isinstance(value, str) or not re.fullmatch(r"[0-9a-fA-F]{64}", value):
                raise WorldBuilderError(f"this map_slice declares placement_plan_sha256, so the assignment's own placement_plan_sha256 field must be a 64-character hex SHA-256 string, found {value!r}")
        if isinstance(map_slice, dict) and map_slice.get("budget_plan_sha256") is not None:
            value = assignment.get("budget_plan_sha256")
            if not isinstance(value, str) or not re.fullmatch(r"[0-9a-fA-F]{64}", value):
                raise WorldBuilderError(f"this map_slice declares budget_plan_sha256, so the assignment's own budget_plan_sha256 field must be a 64-character hex SHA-256 string, found {value!r}")
            if not isinstance(assignment.get("budget_context"), dict):
                raise WorldBuilderError(f"this map_slice declares budget_plan_sha256, so the assignment must also carry a resolved 'budget_context' object, found {type(assignment.get('budget_context')).__name__}")
        if root is not None and state is not None:
            terminology_path = resolve_state_path(root, state, "terminology_dictionary", required=False)
            declared_path = assignment.get("terminology_dictionary")
            declared_sha = assignment.get("terminology_dictionary_sha256")
            if declared_path is not None or declared_sha is not None:
                if not terminology_path or not terminology_path.exists():
                    raise WorldBuilderError("generation assignment declares terminology binding but the dictionary is missing")
                expected_rel = str(terminology_path.relative_to(root)).replace("\\", "/")
                if declared_path != expected_rel:
                    raise WorldBuilderError("generation assignment terminology_dictionary path is stale")
                if not isinstance(declared_sha, str) or not re.fullmatch(r"[0-9a-fA-F]{64}", declared_sha):
                    raise WorldBuilderError("generation assignment terminology_dictionary_sha256 is missing or invalid")
                if declared_sha.lower() != sha256_file(terminology_path):
                    raise WorldBuilderError("generation assignment terminology_dictionary_sha256 is stale")
        if isinstance(map_slice, dict) and map_slice.get("dynamic_state_plan_sha256") is not None:
            value = assignment.get("dynamic_state_plan_sha256")
            if not isinstance(value, str) or not re.fullmatch(r"[0-9a-fA-F]{64}", value):
                raise WorldBuilderError(f"this map_slice declares dynamic_state_plan_sha256, so the assignment's own dynamic_state_plan_sha256 field must be a 64-character hex SHA-256 string, found {value!r}")
            if not isinstance(assignment.get("dynamic_state_context"), dict):
                raise WorldBuilderError(f"this map_slice declares dynamic_state_plan_sha256, so the assignment must also carry a resolved 'dynamic_state_context' object, found {type(assignment.get('dynamic_state_context')).__name__}")
    return {"assignment_id": assignment_id.strip(), "research_mode": mode, "entries": by_uid, "assignment_version": version}


def validate_evidence(
    evidence: Any,
    *,
    assignment: dict[str, Any],
    assignment_sha: str,
    build_id: str,
    manifest_sha: str,
    canon_precedence: list[str] | None = None,
    source_type_weights: dict[str, float] | None = None,
) -> dict[str, Any]:
    if not isinstance(evidence, dict):
        raise WorldBuilderError(f"evidence ledger must be a JSON object, found {type(evidence).__name__}")
    if evidence.get("evidence_version") != 1:
        raise WorldBuilderError(f"evidence_version must be 1, found {evidence.get('evidence_version')!r}")
    metadata = evidence.get("_worldbuilder")
    if not isinstance(metadata, dict):
        raise WorldBuilderError("evidence ledger lacks a '_worldbuilder' metadata object; write the ledger with the _worldbuilder block (build_id, assignment_id, assignment_sha256, manifest_sha256, research_mode) that this assignment's evidence step requires")
    if metadata.get("build_id") != build_id:
        raise WorldBuilderError(f"evidence ledger's _worldbuilder.build_id ({metadata.get('build_id')!r}) does not match this build's own build_id ({build_id!r})")
    if metadata.get("assignment_id") != assignment["assignment_id"]:
        raise WorldBuilderError(f"evidence ledger's _worldbuilder.assignment_id ({metadata.get('assignment_id')!r}) does not match the assignment being processed ({assignment['assignment_id']!r})")
    if str(metadata.get("assignment_sha256", "")).lower() != assignment_sha:
        raise WorldBuilderError("evidence ledger's _worldbuilder.assignment_sha256 does not match the assignment file's actual current hash: the ledger was bound to a different version of the assignment")
    if str(metadata.get("manifest_sha256", "")).lower() != str(manifest_sha).lower():
        raise WorldBuilderError("evidence manifest_sha256 does not match the assignment's manifest binding; the ledger must copy the assignment's manifest_sha256 verbatim.")
    if metadata.get("research_mode") != assignment["research_mode"]:
        raise WorldBuilderError(f"evidence ledger's _worldbuilder.research_mode ({metadata.get('research_mode')!r}) does not match the assignment's research_mode ({assignment['research_mode']!r})")

    records = evidence.get("entries")
    if not isinstance(records, list):
        raise WorldBuilderError(f"evidence ledger's 'entries' field must be a list, found {type(records).__name__}")

    assigned = assignment["entries"]
    seen: dict[str, dict[str, Any]] = {}
    claim_ids_by_uid: dict[str, list[str]] = {}
    statuses_by_uid: dict[str, str] = {}
    for index, record in enumerate(records):
        if not isinstance(record, dict):
            raise WorldBuilderError(f"evidence entries[{index}] must be a JSON object, found {type(record).__name__}")
        if "uid" not in record:
            raise WorldBuilderError(f"evidence entries[{index}] has no 'uid' field: {record!r}")
        key = uid_key(record["uid"])
        if key in seen:
            raise WorldBuilderError(f"evidence ledger contains duplicate uid {key}: each UID must have exactly one evidence record")
        if key not in assigned:
            raise WorldBuilderError(f"evidence ledger contains uid {key}, which is not assigned to this worker: only research UIDs actually in this assignment")
        expected_name = assigned[key]["entry"]["name"].strip()
        actual_name = record.get("name")
        if not isinstance(actual_name, str) or actual_name.strip() != expected_name:
            raise WorldBuilderError(f"evidence uid {key}'s name ({actual_name!r}) does not match the assignment's own name for it ({expected_name!r})")

        status = record.get("research_status")
        if status not in ALLOWED_RESEARCH_STATUS:
            raise WorldBuilderError(f"evidence uid {key}'s research_status is {status!r}; must be one of {sorted(ALLOWED_RESEARCH_STATUS)}")
        if assignment["research_mode"] == "public_web" and status == "user_canonical":
            raise WorldBuilderError(f"evidence uid {key} cannot use user_canonical status in public_web mode")

        searches = record.get("searches", [])
        if not isinstance(searches, list) or any(not isinstance(item, str) or not item.strip() for item in searches):
            raise WorldBuilderError(f"evidence uid {key}'s 'searches' must be a list of non-empty strings, found {searches!r}")
        if assignment["research_mode"] == "public_web" and not searches:
            raise WorldBuilderError(f"evidence uid {key} must record at least one SearXNG query in public_web mode")

        sources = record.get("sources")
        if not isinstance(sources, list):
            raise WorldBuilderError(f"evidence uid {key}'s 'sources' must be a list, found {type(sources).__name__}")
        source_ids: set[str] = set()
        source_types: dict[str, str] = {}
        for source_index, source in enumerate(sources):
            if not isinstance(source, dict):
                raise WorldBuilderError(f"evidence uid {key} sources[{source_index}] must be a JSON object, found {type(source).__name__}")
            source_id = source.get("source_id")
            locator = source.get("locator")
            title = source.get("title")
            accessed_at = source.get("accessed_at")
            source_type = source.get("source_type")
            if not isinstance(source_id, str) or not source_id.strip() or source_id in source_ids:
                raise WorldBuilderError(f"evidence uid {key} sources[{source_index}]'s source_id ({source_id!r}) is empty, not a string, or a duplicate within this entry")
            if not isinstance(locator, str) or not locator.strip():
                raise WorldBuilderError(f"evidence uid {key} source {source_id!r} has no non-empty 'locator' field")
            if not isinstance(title, str) or not title.strip():
                raise WorldBuilderError(f"evidence uid {key} source {source_id!r} has no non-empty 'title' field")
            if not isinstance(accessed_at, str) or not accessed_at.strip():
                raise WorldBuilderError(f"evidence uid {key} source {source_id!r} has no non-empty 'accessed_at' field")
            if not isinstance(source_type, str) or not source_type.strip():
                raise WorldBuilderError(f"evidence uid {key} source {source_id!r} has no non-empty 'source_type' field")
            if assignment["research_mode"] == "public_web" and not URL_RE.match(locator.strip()):
                raise WorldBuilderError(f"evidence uid {key} public-web source {source_id!r}'s locator ({locator!r}) is not an HTTP(S) URL")
            source_ids.add(source_id)
            source_types[source_id] = normalize_source_type(source_type)

        claims = record.get("claims")
        if not isinstance(claims, list):
            raise WorldBuilderError(f"evidence uid {key}'s 'claims' must be a list, found {type(claims).__name__}")
        claim_ids: set[str] = set()
        claims_by_topic: dict[str, int] = {}
        for claim_index, claim in enumerate(claims):
            if not isinstance(claim, dict):
                raise WorldBuilderError(f"evidence uid {key} claims[{claim_index}] must be a JSON object, found {type(claim).__name__}")
            claim_id = claim.get("claim_id")
            topic = claim.get("topic")
            text = claim.get("text")
            kind = claim.get("kind")
            confidence = claim.get("confidence")
            refs = claim.get("source_refs")
            if not isinstance(claim_id, str) or not claim_id.strip() or claim_id in claim_ids:
                raise WorldBuilderError(f"evidence uid {key} claims[{claim_index}]'s claim_id ({claim_id!r}) is empty, not a string, or a duplicate within this entry")
            if not isinstance(topic, str) or not topic.strip():
                raise WorldBuilderError(f"evidence uid {key} claim {claim_id!r} has no non-empty 'topic' field")
            topic_key = topic.strip().casefold()
            if not isinstance(text, str) or not text.strip():
                raise WorldBuilderError(f"evidence uid {key} claim {claim_id!r} has no non-empty 'text' field")
            if kind not in ALLOWED_CLAIM_KINDS:
                raise WorldBuilderError(f"evidence uid {key} claim {claim_id!r}'s kind is {kind!r}; must be one of {sorted(ALLOWED_CLAIM_KINDS)}")
            if confidence not in ALLOWED_CONFIDENCE:
                raise WorldBuilderError(f"evidence uid {key} claim {claim_id!r}'s confidence is {confidence!r}; must be one of {sorted(ALLOWED_CONFIDENCE)}")
            if not isinstance(refs, list) or not refs:
                raise WorldBuilderError(f"evidence uid {key} claim {claim_id!r} must cite a non-empty 'source_refs' list")
            if any(ref not in source_ids for ref in refs):
                raise WorldBuilderError(f"evidence uid {key} claim {claim_id!r} cites a source_ref not present in this entry's own sources: {[r for r in refs if r not in source_ids]}")
            weights = validate_source_type_weights(source_type_weights)
            if weights:
                claim["_worldbuilder_weighted_confidence"] = weighted_claim_confidence(
                    claim, source_types=source_types, source_type_weights=weights
                )
            else:
                claim.pop("_worldbuilder_weighted_confidence", None)
            claim_ids.add(claim_id)
            claims_by_topic[topic_key] = claims_by_topic.get(topic_key, 0) + 1

        topics = record.get("topics")
        if not isinstance(topics, list):
            raise WorldBuilderError(f"evidence uid {key}'s 'topics' must be a list, found {type(topics).__name__}")
        topic_status: dict[str, str] = {}
        for topic_record in topics:
            if not isinstance(topic_record, dict):
                raise WorldBuilderError(f"evidence uid {key}'s topic records must each be a JSON object, found {type(topic_record).__name__}")
            topic = topic_record.get("topic")
            topic_state = topic_record.get("status")
            if not isinstance(topic, str) or not topic.strip():
                raise WorldBuilderError(f"evidence uid {key} has a topic record with no non-empty 'topic' field: {topic_record!r}")
            topic_key = topic.strip().casefold()
            if topic_key in topic_status:
                raise WorldBuilderError(f"evidence uid {key} repeats topic {topic!r}: each topic must have exactly one status record")
            if topic_state not in ALLOWED_TOPIC_STATUS:
                raise WorldBuilderError(f"evidence uid {key} topic {topic!r}'s status is {topic_state!r}; must be one of {sorted(ALLOWED_TOPIC_STATUS)}")
            if topic_state in {"supported", "conflicted"} and claims_by_topic.get(topic_key, 0) == 0:
                raise WorldBuilderError(f"evidence uid {key} topic {topic!r} is marked {topic_state!r} but no claim in this entry cites it")
            topic_status[topic_key] = topic_state

        missing_topics = [topic for topic in assigned[key]["topics"] if topic not in topic_status]
        if missing_topics:
            raise WorldBuilderError(
                f"evidence uid {key} does not cover required topics: {', '.join(missing_topics)}; add a topic status record for each"
            )
        if status == "complete" and not claims:
            raise WorldBuilderError(f"evidence uid {key} has research_status 'complete' but zero claims: a complete entry needs at least one supported claim")
        if status == "user_canonical" and not claims:
            raise WorldBuilderError(f"evidence uid {key} has research_status 'user_canonical' but zero claims: cite the user-provided canonical source as a claim")
        if status == "not_found":
            required_states = {topic_status[topic] for topic in assigned[key]["topics"]}
            if not required_states.issubset({"not_found", "not_applicable"}):
                raise WorldBuilderError(f"evidence uid {key} has research_status 'not_found', but its own topics include statuses other than not_found/not_applicable: {sorted(required_states)}")

        conflicts = record.get("conflicts", [])
        unknowns = record.get("unknowns", [])
        if not isinstance(conflicts, list) or not isinstance(unknowns, list):
            raise WorldBuilderError(f"evidence uid {key}'s 'conflicts' and 'unknowns' must both be lists, found {type(conflicts).__name__}/{type(unknowns).__name__}")
        derived_conflicts = derive_canon_conflicts(
            record, canon_precedence=canon_precedence, source_type_weights=source_type_weights
        )
        merge_derived_conflicts(record, derived_conflicts)

        seen[key] = record
        claim_ids_by_uid[key] = sorted(claim_ids)
        statuses_by_uid[key] = status

    missing_uids = sorted(set(assigned) - set(seen))
    if missing_uids:
        raise WorldBuilderError("evidence ledger is missing assigned UIDs: " + ", ".join(missing_uids) + "; research and record every assigned UID before this passes")

    return {
        "researched_uids": sorted(seen, key=lambda value: (not value.lstrip("-").isdigit(), value)),
        "claim_ids_by_uid": claim_ids_by_uid,
        "statuses_by_uid": statuses_by_uid,
    }


def validate_assignment_evidence(
    build_state_path: str | os.PathLike[str],
    assignment_path: str | os.PathLike[str],
    *,
    write_receipt: bool = False,
) -> dict[str, Any]:
    build_root, state = load_build_state(build_state_path)
    build_id = str(state.get("build_id", "")).strip()
    if not build_id:
        raise WorldBuilderError(f"{build_state_path} has no build_id: this is not a valid, initialized build-state.json; re-run init_build.py")
    manifest_path = resolve_state_path(build_root, state, "manifest")
    if not manifest_path.exists():
        raise WorldBuilderError(f"manifest does not exist at {manifest_path}: check paths.manifest, or author the manifest before dispatching generation")
    manifest_sha = sha256_file(manifest_path)

    assignment_file = Path(assignment_path)
    if not assignment_file.is_absolute():
        assignment_file = (build_root / assignment_file).resolve()
    else:
        assignment_file = assignment_file.resolve()
    ensure_inside(assignment_file, build_root)
    if not assignment_file.exists():
        raise WorldBuilderError(f"assignment file does not exist at {assignment_file}: check the --assignment path, or that dispatch actually wrote this file")
    assignment_data = load_json(assignment_file)
    assignment_sha = sha256_file(assignment_file)
    batching = state.get("batching") if isinstance(state.get("batching"), dict) else {}
    generation_batch_limit = batching.get("generation_entries_per_worker", 15)
    if (
        not isinstance(generation_batch_limit, int)
        or isinstance(generation_batch_limit, bool)
        or not 1 <= generation_batch_limit <= 50
    ):
        raise WorldBuilderError(
            f"build-state's batching.generation_entries_per_worker must be an integer from 1 to 50, found {generation_batch_limit!r}"
        )
    required_version = required_assignment_version(build_root, state)
    assignment = validate_assignment(
        assignment_data, build_id, manifest_sha, generation_batch_limit, required_version, root=build_root, state=state
    )
    if assignment["assignment_version"] >= 3:
        validate_assignment_slice(str(Path(build_state_path).resolve()), assignment_data)

    manifest_data = load_json(manifest_path)
    manifest_by_uid: dict[str, dict[str, Any]] = {}
    for ref in iter_entries(manifest_data):
        identity = canonical_entry_identity(ref.entry)
        if identity is None:
            continue
        key = uid_key(identity)
        if key in manifest_by_uid:
            raise WorldBuilderError(f"the authoritative manifest itself contains duplicate uid {key}: this must be fixed in the manifest, not in any downstream assignment or evidence ledger")
        manifest_by_uid[key] = ref.entry
    for key, assigned in assignment["entries"].items():
        if key not in manifest_by_uid:
            raise WorldBuilderError(f"assignment uid {key} does not exist in the authoritative manifest: the assignment was generated against a stale or different manifest")
        manifest_name = manifest_by_uid[key].get("name")
        if isinstance(manifest_name, str) and manifest_name.strip():
            if manifest_name.strip() != assigned["entry"]["name"].strip():
                raise WorldBuilderError(f"assignment uid {key}'s name ({assigned['entry']['name']!r}) does not match the authoritative manifest's own name for it ({manifest_name!r})")

    manifest_architecture = manifest_data.get("architecture") if isinstance(manifest_data.get("architecture"), dict) else {}
    canon_precedence = validate_canon_precedence(manifest_architecture.get("canon_precedence"))
    source_type_weights = validate_source_type_weights(manifest_architecture.get("source_type_weights"))

    evidence_path = require_relative_build_path(build_root, assignment_data.get("evidence_output"), "evidence_output")
    receipt_path = require_relative_build_path(build_root, assignment_data.get("evidence_receipt"), "evidence_receipt")
    discoveries = resolve_state_path(build_root, state, "discoveries")
    evidence_receipts = resolve_state_path(build_root, state, "evidence_receipts")
    ensure_inside(evidence_path, discoveries)
    ensure_inside(receipt_path, evidence_receipts)
    if not evidence_path.exists():
        raise WorldBuilderError(f"evidence ledger does not exist at {evidence_path}: research the assigned UIDs and write their evidence records before validating")

    evidence_data = load_json(evidence_path)
    before_evidence = json.dumps(evidence_data, ensure_ascii=False, sort_keys=True)
    binding = assignment.get("_manifest_binding") if isinstance(assignment.get("_manifest_binding"), dict) else {}
    slice_tolerated = binding.get("manifest_binding") == "slice_tolerated"
    evidence_meta = evidence_data.get("_worldbuilder") if isinstance(evidence_data, dict) and isinstance(evidence_data.get("_worldbuilder"), dict) else {}
    # A slice-tolerated assignment may have been re-emitted after a manifest
    # metadata amendment. Validate the evidence records against the *current*
    # assignment contents, while permitting only the historical envelope SHA
    # fields to remain old. Phase-gate later proves the old generation slice is
    # byte-for-byte dependency-equivalent before accepting its phase envelope.
    evidence_assignment_sha = str(evidence_meta.get("assignment_sha256", "")) if slice_tolerated else assignment_sha
    evidence_manifest_sha = str(evidence_meta.get("manifest_sha256", "")) if slice_tolerated else str(assignment_data.get("manifest_sha256", "")).lower()
    result = validate_evidence(
        evidence_data,
        assignment=assignment,
        assignment_sha=evidence_assignment_sha,
        build_id=build_id,
        manifest_sha=evidence_manifest_sha,
        canon_precedence=canon_precedence,
        source_type_weights=source_type_weights,
    )
    after_evidence = json.dumps(evidence_data, ensure_ascii=False, sort_keys=True)
    if after_evidence != before_evidence:
        atomic_write_json(evidence_path, evidence_data)
    receipt = {
        "receipt_version": 2 if assignment["assignment_version"] >= 3 else 1,
        "kind": "evidence-gate",
        "build_id": build_id,
        "assignment_id": assignment["assignment_id"],
        "assignment_path": str(assignment_file.relative_to(build_root)).replace(os.sep, "/"),
        "assignment_sha256": assignment_sha,
        "manifest_sha256": manifest_sha,
        "activation_map_sha256": assignment_data.get("activation_map_sha256"),
        "field_registry_sha256": assignment_data.get("field_registry_sha256"),
        "default_profile_sha256": assignment_data.get("default_profile_sha256"),
        "character_plan_sha256": assignment_data.get("character_plan_sha256"),
        "era_plan_sha256": assignment_data.get("era_plan_sha256"),
        "placement_plan_sha256": assignment_data.get("placement_plan_sha256"),
        "budget_plan_sha256": assignment_data.get("budget_plan_sha256"),
        "dynamic_state_plan_sha256": assignment_data.get("dynamic_state_plan_sha256"),
        "manifest_binding": assignment_data.get("_manifest_binding", {"manifest_binding": "exact", "manifest_sha256_at_check": assignment_data.get("manifest_sha256")}),
        "evidence_path": str(evidence_path.relative_to(build_root)).replace(os.sep, "/"),
        "evidence_sha256": sha256_file(evidence_path),
        "research_mode": assignment["research_mode"],
        "researched_uids": result["researched_uids"],
        "claim_ids_by_uid": result["claim_ids_by_uid"],
        "statuses_by_uid": result["statuses_by_uid"],
        "source_quality_contract": SOURCE_QUALITY_CONTRACT,
        "source_type_weights": source_type_weights,
        "canon_precedence_mode": "explicit" if canon_precedence else ("source_type_weights" if source_type_weights else "none"),
        "validated_at_unix": int(time.time()),
    }
    if write_receipt:
        atomic_write_json(receipt_path, receipt)
        receipt["receipt_path"] = str(receipt_path.relative_to(build_root)).replace(os.sep, "/")
        receipt["receipt_sha256"] = sha256_file(receipt_path)
    else:
        receipt["receipt_path"] = str(receipt_path.relative_to(build_root)).replace(os.sep, "/")
    return receipt


def verify_manifest_binding(assignment: dict[str, Any], root: Path, state: dict[str, Any], live_manifest_sha: str) -> dict[str, Any]:
    """Verify the assignment's manifest binding, preferring the assigned slice.

    Exact byte match passes as before. On drift, per-UID entry hashes stamped at
    pre-dispatch let unaffected assignments proceed (recorded as slice_tolerated)
    while assignments whose entries actually changed fail with a surgical,
    per-assignment recovery instead of a whole-build invalidation."""
    from wb_common import collect_uid_entries, entry_binding_hash
    declared = str(assignment.get("manifest_sha256", "")).lower()
    if declared == live_manifest_sha:
        return {"manifest_binding": "exact", "manifest_sha256_at_check": live_manifest_sha}
    hashes = assignment.get("entry_hashes")
    if isinstance(hashes, dict) and hashes:
        manifest = load_json(resolve_state_path(root, state, "manifest"))
        lookup = collect_uid_entries(manifest)
        changed: list[str] = []
        for row in assignment.get("entries", []):
            uid = str(row.get("uid")) if isinstance(row, dict) else None
            if uid is None:
                continue
            entry = lookup.get(uid)
            if entry is None or entry_binding_hash(entry) != hashes.get(uid):
                changed.append(uid)
        if not changed:
            return {"manifest_binding": "slice_tolerated", "manifest_sha256_at_check": live_manifest_sha}
        raise WorldBuilderError(
            "manifest changed for assigned UIDs " + ", ".join(sorted(changed)) + ". Only assignments touching these UIDs "
            "need re-planning: correct the manifest through planning, re-run planning_gate.py, re-stamp with "
            "phase_gate.py --stage pre-dispatch, and re-dispatch just the affected workers. Completed assignments whose "
            "slices are unchanged remain valid. (Full re-baseline via pipeline_stage_gate.py --invalidate-from "
            "planning_validated remains available; never edit or 'sync' the manifest with ad-hoc scripts.)"
        )
    raise WorldBuilderError(
        "assignment manifest_sha256 does not match current manifest bytes and the assignment carries no entry_hashes. "
        "Re-stamp assignments with phase_gate.py --stage pre-dispatch to enable per-slice tolerance, or re-baseline via "
        "pipeline_stage_gate.py --build-state <your build-state.json> --invalidate-from planning_validated and re-run "
        "planning_gate.py; never edit or 'sync' the manifest with ad-hoc scripts or file-permission locks."
    )


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate research coverage for one generation assignment.")
    parser.add_argument("--build-state", required=True)
    parser.add_argument("--assignment", required=True, help="Assignment path, absolute or relative to build root.")
    parser.add_argument("--check-only", action="store_true", help="Validate without writing the evidence receipt.")
    args = parser.parse_args()
    try:
        receipt = validate_assignment_evidence(
            args.build_state,
            args.assignment,
            write_receipt=not args.check_only,
        )
        print(json.dumps(receipt, ensure_ascii=False, indent=2, sort_keys=True))
        return 0
    except (WorldBuilderError, OSError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        print(step_driver_pointer(), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
