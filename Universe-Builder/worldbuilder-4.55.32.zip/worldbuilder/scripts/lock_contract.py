#!/usr/bin/env python3
"""Author-lock and entry-ownership contract.

Locks are entry-local metadata at ``architecture.lock``.  A portable export can
relocate that block into ``extensions.worldbuilder_preserved_entry_fields``,
so this module resolves every supported representation rather than only the
canonical one.  It is the single authority for interpreting locks; mutating
subsystems must import these helpers rather than re-derive lock semantics.
"""
from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

from wb_common import WorldBuilderError, atomic_write_json, build_identity_index, load_build_state, load_json, normalize_identity, preflight_report, requirement_rows

CONTRACT = "worldbuilder-author-lock-v1"
OWNERSHIP_VALUES = frozenset({
    "generated",
    "user-authored",
    "source-derived",
    "transformed",
    "imported",
    "generated-then-manually-edited",
})


PRESERVED_ENTRY_KEY = "worldbuilder_preserved_entry_fields"

# The same underlying field under its portable and its native spelling. A lock
# naming either spelling protects both, so a lock written as ``keys`` cannot be
# evaded by editing ``key``.
FIELD_ALIASES: dict[str, set[str]] = {
    "keys": {"keys", "key"},
    "key": {"keys", "key"},
    "secondary_keys": {"secondary_keys", "keysecondary"},
    "keysecondary": {"secondary_keys", "keysecondary"},
    "comment": {"comment", "name"},
    "name": {"comment", "name"},
    "recursion_level": {"recursion_level", "depth"},
    "depth": {"recursion_level", "depth"},
    "delay_until_recursion": {"delay_until_recursion", "delayUntilRecursion"},
    "delayUntilRecursion": {"delay_until_recursion", "delayUntilRecursion"},
}


def _field_alias_set(field: str) -> set[str]:
    return FIELD_ALIASES.get(field, {field})


def _lock_container_candidates(entry: dict[str, Any]) -> list[Any]:
    """Every place a lock block is known to live after a real conversion."""
    candidates: list[Any] = []
    architecture = entry.get("architecture")
    if isinstance(architecture, dict):
        candidates.append(architecture.get("lock"))
    extensions = entry.get("extensions")
    if isinstance(extensions, dict):
        preserved = extensions.get(PRESERVED_ENTRY_KEY)
        if isinstance(preserved, dict):
            candidates.append(preserved.get("lock"))
            preserved_architecture = preserved.get("architecture")
            if isinstance(preserved_architecture, dict):
                candidates.append(preserved_architecture.get("lock"))
    return candidates


def _lock_block(entry: Any) -> dict[str, Any] | None:
    if not isinstance(entry, dict):
        return None
    for candidate in _lock_container_candidates(entry):
        if isinstance(candidate, dict):
            return candidate
    return None


def validate_lock(entry: Any) -> dict[str, Any] | None:
    lock = _lock_block(entry)
    if lock is None:
        return None
    if lock.get("locked") is not True:
        return None
    fields = lock.get("fields")
    if fields is not None:
        if not isinstance(fields, list) or not fields or any(not isinstance(v, str) or not v.strip() for v in fields):
            raise WorldBuilderError("architecture.lock.fields must be null or a non-empty list of field names")
        if len(set(fields)) != len(fields):
            raise WorldBuilderError("architecture.lock.fields repeats a field name")
    reason = lock.get("reason")
    if not isinstance(reason, str) or not reason.strip():
        raise WorldBuilderError("architecture.lock.reason must be a non-empty string")
    ownership = lock.get("ownership")
    if ownership not in OWNERSHIP_VALUES:
        raise WorldBuilderError(
            f"architecture.lock.ownership must be one of {', '.join(sorted(OWNERSHIP_VALUES))}; found {ownership!r}"
        )
    locked_at = lock.get("locked_at")
    if not isinstance(locked_at, str) or not locked_at.strip():
        raise WorldBuilderError("architecture.lock.locked_at must be an ISO-8601 timestamp string")
    return lock


def is_locked(entry: Any, field: str | None = None) -> bool:
    lock = validate_lock(entry)
    if lock is None:
        return False
    if field is None:
        return True
    fields = lock.get("fields")
    if fields is None:
        return True
    return bool(set(fields) & _field_alias_set(field))


def lock_reason(entry: Any, field: str | None = None) -> str | None:
    lock = validate_lock(entry)
    if lock is None or (field is not None and not is_locked(entry, field)):
        return None
    return str(lock["reason"]).strip()


def ownership(entry: Any) -> str | None:
    lock = validate_lock(entry)
    return str(lock.get("ownership")) if lock else None


def assert_unlocked(entry: Any, *, field: str | None = None, operation: str = "automated operation") -> None:
    if not is_locked(entry, field):
        return
    scope = f" field {field!r}" if field is not None else ""
    raise WorldBuilderError(
        f"{operation} cannot modify locked entry{scope}: {lock_reason(entry, field)}. "
        "Unlock it explicitly with lock_contract.py before retrying; locks are never removed as a side effect of another operation."
    )


def assert_write_allowed(entry: Any, changed_fields: Iterable[str], *, operation: str) -> None:
    """The shared, write-time lock authority (Batch 58 / A02).

    Call this from every mutating path with the fields that are about to change,
    immediately before the write, so a lock is enforced against the artifact
    being written rather than only against a plan made earlier.
    """
    fields = list(changed_fields)
    if not fields:
        assert_unlocked(entry, operation=operation)
        return
    for field in fields:
        if is_locked(entry, field):
            raise WorldBuilderError(
                f"{operation} cannot modify locked entry field {field!r}: {lock_reason(entry, field)}. "
                "Unlock it explicitly with lock_contract.py before retrying; locks are never removed as a side effect of another operation."
            )


def locked_uid_map(data: Any) -> dict[str, dict[str, Any]]:
    result: dict[str, dict[str, Any]] = {}
    for uid, (_path, entry) in build_identity_index(data).items():
        if is_locked(entry):
            result[str(uid)] = entry
    return result


def _locate(data: Any, uid: Any) -> dict[str, Any]:
    index = build_identity_index(data)
    key = normalize_identity(uid)
    if key not in index:
        raise WorldBuilderError(f"no entry with uid/id {uid!r}")
    return index[key][1]


def lock_entry(
    data: Any,
    uid: Any,
    *,
    fields: Iterable[str] | None,
    reason: str,
    ownership_value: str,
    locked_at: str | None = None,
) -> dict[str, Any]:
    if ownership_value not in OWNERSHIP_VALUES:
        raise WorldBuilderError(f"unsupported ownership value {ownership_value!r}")
    if not isinstance(reason, str) or not reason.strip():
        raise WorldBuilderError("lock reason must be non-empty")
    entry = _locate(data, uid)
    architecture = entry.setdefault("architecture", {})
    if not isinstance(architecture, dict):
        raise WorldBuilderError("entry architecture is not an object")
    field_list = None if fields is None else [str(v).strip() for v in fields if str(v).strip()]
    if field_list == []:
        field_list = None
    stamp = locked_at or datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")
    architecture["lock"] = {
        "locked": True,
        "fields": field_list,
        "reason": reason.strip(),
        "locked_at": stamp,
        "ownership": ownership_value,
    }
    validate_lock(entry)
    return architecture["lock"]


def unlock_entry(data: Any, uid: Any, *, fields: Iterable[str] | None = None) -> dict[str, Any]:
    entry = _locate(data, uid)
    lock = validate_lock(entry)
    if lock is None:
        return {"changed": False, "remaining_fields": None}
    architecture = entry.get("architecture")
    if isinstance(architecture, dict) and architecture.get("lock") is lock:
        owner = architecture
    else:
        extensions = entry.get("extensions") if isinstance(entry.get("extensions"), dict) else {}
        preserved = extensions.get(PRESERVED_ENTRY_KEY) if isinstance(extensions.get(PRESERVED_ENTRY_KEY), dict) else {}
        if preserved.get("lock") is lock:
            owner = preserved
        elif isinstance(preserved.get("architecture"), dict) and preserved["architecture"].get("lock") is lock:
            owner = preserved["architecture"]
        else:
            raise WorldBuilderError("lock container could not be resolved for unlock")
    requested = None if fields is None else {str(v).strip() for v in fields if str(v).strip()}
    current = lock.get("fields")
    if requested is None or current is None:
        owner.pop("lock", None)
        return {"changed": True, "remaining_fields": None}
    remaining = [field for field in current if field not in requested]
    if not remaining:
        owner.pop("lock", None)
        return {"changed": True, "remaining_fields": None}
    lock["fields"] = remaining
    return {"changed": True, "remaining_fields": remaining}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--target", help="JSON artifact/manifest containing the entry")
    parser.add_argument("--uid")
    parser.add_argument("--build-state", help="Build-state path for the read-only --requirements preflight.")
    parser.add_argument("--requirements", action="store_true", help="Read-only preflight: print what this gate checks against the current build state.")
    sub = parser.add_subparsers(dest="command")
    lock_p = sub.add_parser("lock")
    lock_p.add_argument("--field", action="append", dest="fields")
    lock_p.add_argument("--reason", required=True)
    lock_p.add_argument("--ownership", required=True, choices=sorted(OWNERSHIP_VALUES))
    lock_p.add_argument("--locked-at")
    unlock_p = sub.add_parser("unlock")
    unlock_p.add_argument("--field", action="append", dest="fields")
    args = parser.parse_args()
    if args.requirements:
        if not args.build_state:
            parser.error("--requirements needs --build-state")
        root, state = load_build_state(args.build_state)
        print(json.dumps(preflight_report("lock_contract", requirement_rows(Path(__file__), root, state)), ensure_ascii=False, indent=2))
        return 0
    if args.target is None:
        parser.error("--target is required")
    if args.uid is None:
        parser.error("--uid is required")
    if args.command is None:
        parser.error("a command is required")
    try:
        target = Path(args.target).resolve()
        data = load_json(target)
        if args.command == "lock":
            result = lock_entry(data, args.uid, fields=args.fields, reason=args.reason, ownership_value=args.ownership, locked_at=args.locked_at)
        else:
            result = unlock_entry(data, args.uid, fields=args.fields)
        atomic_write_json(target, data)
        print(json.dumps({"status": "ok", "contract": CONTRACT, "uid": args.uid, "result": result}, ensure_ascii=False, indent=2))
        return 0
    except (WorldBuilderError, OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
