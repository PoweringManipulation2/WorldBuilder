#!/usr/bin/env python3
"""Per-stage exit contracts: what the next gate requires and what is missing.

Everything here is derived from source at run time, never hand-maintained:
STAGES and STAGE_COMMANDS come from pipeline_stage_gate.py, the required state
keys come from the gate each stage names, default paths come from the
init_build.py path table, and producing scripts come from a write-side scan of
scripts/ plus a small verified override table for writers that select their
receipt key by stage (budget_contract.py picks its receipt by --stage, for
example). The command exits 0 in every inspection mode: this is a preflight,
and a preflight that can fail is just another gate.

Usage:
    python3 scripts/phase_contract.py --build-state <path> --stage <stage>
    python3 scripts/phase_contract.py --build-state <path> --next
    python3 scripts/phase_contract.py --render-docs
"""
from __future__ import annotations

import argparse
import ast
import json
import re
import sys
from pathlib import Path
from typing import Any

from wb_common import WorldBuilderError, load_build_state, resolve_state_path

SCRIPTS = Path(__file__).resolve().parent
ROOT = SCRIPTS.parent
CONTRACT_KIND = "worldbuilder-phase-exit-contract"
CONTRACT_VERSION = 1
GATE_FILE_RE = re.compile(r"[A-Za-z_][A-Za-z0-9_\-]*\.py")
WRITE_CALL_RE = re.compile(r"atomic_write_json\(|write_text\(|write_bytes\(|shutil\.copy|copy2\(|\.mkdir\(")
WRITE_WINDOW = 14
POINTER_PREFIX = "<!-- phase-contract -->"
SKIP_SCAN_SCRIPTS = {"init_build.py", "pipeline_stage_gate.py", "phase_contract.py"}

# The measured table names runtime_target_adapter.py as the gate for the
# runtime_adapter stage while STAGE_COMMANDS names delivery_gate.py; both
# currently resolve the same thirteen keys, and this module follows the table.
GATE_OVERRIDES = {"runtime_adapter": "runtime_target_adapter.py"}

# Producers the write-side scan cannot name on its own: stage-selected receipt
# keys, helper-written artifacts, and authored inputs. Every command here was
# verified by reading the named script's writer path.
PRODUCER_OVERRIDES: dict[str, str] = {
    "budget_planning_receipt": "budget_contract.py --stage planning",
    "budget_output_receipt": "budget_contract.py --stage output",
    "budget_plan": "budget_contract.py --stage planning",
    "dynamic_state_planning_receipt": "dynamic_state_contract.py --stage planning",
    "dynamic_state_output_receipt": "dynamic_state_contract.py --stage output",
    "dynamic_state_plan": "dynamic_state_contract.py --stage planning",
    "era_router_receipt": "era_router_contract.py --stage planning",
    "entry_naming_planning_receipt": "entry_naming.py --stage planning",
    "entry_naming_output_receipt": "entry_naming.py --stage normalize-output",
    "architecture_planning_receipt": "architecture_gate.py --stage planning",
    "planning_receipt": "planning_gate.py",
    "identity_receipt": "manifest_identity.py",
    "activation_test_corpus_receipt": "activation_test_corpus.py",
    "discovery_receipt": "discovery_gate.py",
    "discovery_index": "discovery_gate.py (records the discovery index)",
    "discovery_exclusion_approval": "write_discovery_approval.py",
    "discovery_single_round_approval": "write_discovery_approval.py",
    "discovery_recovery_plan": "discovery_recovery.py",
    "assignments": "discovery_plan.py",
    "audit_assignments": "audit_plan.py",
    "audit_runtime": "record_audit_runtime.py --stage <stage>",
    "pre_generation_audit_plan": "audit_plan.py --stage pre-generation",
    "post_generation_audit_plan": "audit_plan.py --stage post-generation",
    "pre_generation_audit_receipt": "audit_gate.py --stage pre-generation",
    "post_generation_audit_receipt": "audit_gate.py --stage post-generation",
    "findings": "audit workers (validated by audit_gate.py)",
    "terminology_dictionary": "terminology_dictionary.py",
    "character_plan": "character_contract.py (validated at planning)",
    "merge_input": "merge_phases.py",
    "phases": "phase_gate.py --stage pre-dispatch",
    "receipts": "pipeline_stage_gate.py (one row per recorded stage)",
    "worker_kit": "init_build.py (staged at workspace init)",
    "worker_kit_bundle": "init_build.py (staged at workspace init)",
    "default_profile": "staged from references/ at workspace init",
    "field_registry": "staged from references/ at workspace init",
    "effective_config": "init_build.py (written at workspace init)",
    "card_shell_plan": "authored during planning (card_shell_contract.py validates)",
    "pipeline_registry": "authored during planning (integration_acceptance.py validates)",
    "integration_plan": "authored during planning (integration_acceptance.py --stage planning validates)",
    "manifest": "authored during planning (manifest_identity.py validates)",
    "build_id": "set at workspace init (init_build.py)",
    "build_list": "authored during planning (build_list_rebind.py rebinds)",
    "recursion_map": "authored during planning",
    "final_output": "runtime_target_adapter.py export",
    "adapter_output": "runtime_target_adapter.py export",
    "semantic_ir": "runtime_target_adapter.py export",
    "compatibility_report": "runtime_target_adapter.py export",
    "runtime_adapter_receipt": "runtime_target_adapter.py export",
    "sillytavern_tag_map": "runtime_target_adapter.py export",
    "sillytavern_character_map": "runtime_target_adapter.py export",
    "runtime_asset_map": "runtime_target_adapter.py export",
    "recommended_settings": "runtime_target_adapter.py export",
    "runtime_bundle": "runtime_target_adapter.py bundle",
    "runtime_bundle_manifest": "runtime_target_adapter.py bundle",
    "runtime_bundle_receipt": "runtime_target_adapter.py bundle",
    "context_budget_before": "merge_phases.py (copied when budget review flags it)",
}

_PARSE_CACHE: dict[str, ast.Module] = {}
_CONTEXT: dict[str, Any] | None = None


def _parse_script(name: str) -> ast.Module:
    if name not in _PARSE_CACHE:
        _PARSE_CACHE[name] = ast.parse((SCRIPTS / name).read_text(encoding="utf-8"))
    return _PARSE_CACHE[name]


def load_stage_map() -> tuple[tuple[str, ...], dict[str, tuple[str, str]]]:
    tree = _parse_script("pipeline_stage_gate.py")
    stages: tuple[str, ...] | None = None
    commands: dict[str, tuple[str, str]] | None = None
    for node in tree.body:
        if isinstance(node, ast.Assign):
            names = [t.id for t in node.targets if isinstance(t, ast.Name)]
            value = node.value
        elif isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
            names = [node.target.id]
            value = node.value
        else:
            continue
        if value is None:
            continue
        if "STAGES" in names:
            stages = tuple(ast.literal_eval(value))
        elif "STAGE_COMMANDS" in names:
            commands = dict(ast.literal_eval(value))
    if not stages or not commands:
        raise WorldBuilderError("cannot read STAGES and STAGE_COMMANDS from pipeline_stage_gate.py")
    return stages, commands


def stage_gate(stage: str, commands: dict[str, tuple[str, str]]) -> str:
    override = GATE_OVERRIDES.get(stage)
    if override:
        return override
    match = GATE_FILE_RE.search(commands[stage][0])
    if not match:
        raise WorldBuilderError(f"no gate script is named in the command for stage {stage!r}")
    return match.group(0)


def _is_name(node: ast.expr, name: str) -> bool:
    return isinstance(node, ast.Name) and node.id == name


def required_keys(gate: str) -> list[tuple[str, bool]]:
    """State keys the gate resolves, with a flag for non-blocking resolutions.

    Parsed from source, so comments and docstrings can never contribute a key.
    A key resolved with required=False anywhere is labelled optional.
    """
    tree = _parse_script(gate)
    order: list[str] = []
    flags: dict[str, bool] = {}
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        func = node.func
        fname = func.attr if isinstance(func, ast.Attribute) else getattr(func, "id", None)
        if fname != "resolve_state_path":
            continue
        args = node.args
        if len(args) < 3 or not _is_name(args[0], "root") or not _is_name(args[1], "state"):
            continue
        if not (isinstance(args[2], ast.Constant) and isinstance(args[2].value, str)):
            continue
        key = args[2].value
        optional = any(
            kw.arg == "required" and isinstance(kw.value, ast.Constant) and kw.value.value is False
            for kw in node.keywords
        )
        if key not in flags:
            order.append(key)
            flags[key] = True
        flags[key] = flags[key] and not optional
    return [(key, flags[key]) for key in order]


def evidence_keys(stage: str) -> list[str]:
    """Keys the stage ledger binds, read from collect_evidence in
    pipeline_stage_gate.py. Used for stages whose command names no gate (the
    workspace bootstrap)."""
    tree = _parse_script("pipeline_stage_gate.py")
    collector = None
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef) and node.name == "collect_evidence":
            collector = node
            break
    if collector is None:
        return []
    keys: list[str] = []
    for node in ast.walk(collector):
        if not isinstance(node, ast.If):
            continue
        test = node.test
        if not (isinstance(test, ast.Compare) and isinstance(test.left, ast.Name) and test.left.id == "stage"):
            continue
        if not (len(test.comparators) == 1 and isinstance(test.comparators[0], ast.Constant)
                and test.comparators[0].value == stage):
            continue
        for statement in node.body:
            for inner in ast.walk(statement):
                if not isinstance(inner, ast.Tuple):
                    continue
                values = [e.value for e in inner.elts if isinstance(e, ast.Constant) and isinstance(e.value, str)]
                if not values or len(values) != len(inner.elts):
                    continue
                for value in values:
                    if value not in keys:
                        keys.append(value)
    return keys


def load_default_paths() -> dict[str, str]:
    """The canonical key to default path table from init_build.py."""
    tree = _parse_script("init_build.py")
    best: list[tuple[str, ast.expr]] | None = None
    for node in ast.walk(tree):
        if not isinstance(node, ast.Dict):
            continue
        items: list[tuple[str, ast.expr]] = []
        for key, value in zip(node.keys, node.values):
            if key is not None and isinstance(key, ast.Constant) and isinstance(key.value, str):
                items.append((key.value, value))
        names = {name for name, _ in items}
        if "manifest" in names and "planning_receipt" in names and len(items) >= 60:
            if best is None or len(items) > len(best):
                best = items
    return {key: _render_default(value) for key, value in (best or [])}


def _render_default(value: ast.expr) -> str:
    if isinstance(value, ast.Constant):
        return str(value.value) if value.value is not None else "(not set)"
    if isinstance(value, ast.IfExp):
        first = _render_default(value.body)
        second = _render_default(value.orelse)
        if second == "(not set)":
            return first
        return first if first == second else f"{first} (or {second})"
    if isinstance(value, ast.JoinedStr):
        return "(computed at init)"
    return "(set by init_build)"


def scan_producers(keys: set[str]) -> dict[str, str]:
    """Primary producing script per key: the script whose source resolves the
    key literal nearest to a write call. Overrides win where the scan cannot
    see a stage-selected receipt key."""
    best: dict[str, tuple[int, str]] = {}
    for path in sorted(SCRIPTS.glob("*.py")):
        if path.name in SKIP_SCAN_SCRIPTS:
            continue
        lines = path.read_text(encoding="utf-8", errors="replace").split("\n")
        write_lines = [i for i, line in enumerate(lines) if WRITE_CALL_RE.search(line)]
        if not write_lines:
            continue
        for key in keys:
            needle = f'"{key}"'
            found = [i for i, line in enumerate(lines) if needle in line]
            if not found:
                continue
            distance = min(abs(a - b) for a in found for b in write_lines)
            if distance <= WRITE_WINDOW and (key not in best or distance < best[key][0]):
                best[key] = (distance, path.name)
    return {key: row[1] for key, row in best.items()}


def context() -> dict[str, Any]:
    global _CONTEXT
    if _CONTEXT is None:
        stages, commands = load_stage_map()
        paths = load_default_paths()
        all_keys: set[str] = set()
        for stage in stages:
            gate = stage_gate(stage, commands)
            for key, _ in required_keys(gate):
                all_keys.add(key)
            for key in evidence_keys(stage):
                all_keys.add(key)
        _CONTEXT = {"stages": stages, "commands": commands, "paths": paths, "producers": scan_producers(all_keys)}
    return _CONTEXT


def stage_keys(stage: str) -> tuple[str, list[tuple[str, bool]]]:
    """(gate script, (key, required) rows) for one stage."""
    ctx = context()
    gate = stage_gate(stage, ctx["commands"])
    rows = required_keys(gate)
    if not rows:
        rows = [(key, True) for key in evidence_keys(stage)]
    return gate, rows


def stage_contract(build_state: str | Path | None, stage: str) -> dict[str, Any]:
    ctx = context()
    if stage not in ctx["commands"]:
        raise WorldBuilderError(f"unknown pipeline stage {stage!r}")
    gate, key_rows = stage_keys(stage)
    template, doc = ctx["commands"][stage]
    command = template.format(
        py=sys.executable or "python",
        sd=str(SCRIPTS),
        bs=str(Path(build_state).resolve()) if build_state else "<build-state.json>",
    )
    root_state = load_build_state(build_state) if build_state else None
    rows: list[dict[str, Any]] = []
    for key, required in key_rows:
        row: dict[str, Any] = {"key": key, "required": required}
        row["producer"] = PRODUCER_OVERRIDES.get(key) or ctx["producers"].get(key) or "(see the gate's message)"
        if root_state is not None:
            root, state = root_state
            try:
                path = resolve_state_path(root, state, key, required=False)
            except WorldBuilderError:
                path = None
            if path is None:
                row["path"] = "(not configured)"
                row["status"] = "not-configured"
            else:
                try:
                    row["path"] = str(path.relative_to(root)).replace("\\", "/")
                except ValueError:
                    row["path"] = str(path)
                row["status"] = "present" if path.exists() else "absent"
        else:
            row["path"] = ctx["paths"].get(key, "(not in table)")
            row["status"] = "unknown"
        rows.append(row)
    return {
        "kind": CONTRACT_KIND,
        "contract_version": CONTRACT_VERSION,
        "stage": stage,
        "gate": gate,
        "doc": doc,
        "command": command,
        "requirements": rows,
    }


def render_text(contract: dict[str, Any]) -> str:
    lines = [
        f"Exit contract for stage '{contract['stage']}' (gate: {contract['gate']})",
        f"  read first: {contract['doc']}",
        f"  record it with: {contract['command']}",
        "",
    ]
    for row in contract["requirements"]:
        kind = "required" if row["required"] else "optional"
        lines.append(f"- {row['key']} [{row['status']}, {kind}]")
        lines.append(f"    path: {row['path']}")
        lines.append(f"    produced by: {row['producer']}")
    return "\n".join(lines)


def doc_targets() -> dict[str, list[str]]:
    """Document path -> stages that point at it, from STAGE_COMMANDS."""
    ctx = context()
    targets: dict[str, list[str]] = {}
    for stage, (_template, doc) in ctx["commands"].items():
        for part in doc.split(";"):
            match = re.search(r"(?:references/[A-Za-z0-9_.\-]+\.md|SKILL\.md)", part)
            if not match:
                continue
            name = match.group(0)
            targets.setdefault(name, [])
            if stage not in targets[name]:
                targets[name].append(stage)
    return targets


def pointer_line(stages: list[str]) -> str:
    listed = ", ".join(stages)
    stage_hint = listed if len(stages) == 1 else f"one of: {listed}"
    return (
        f"{POINTER_PREFIX} Exit contract: run `python3 {{baseDir}}/scripts/phase_contract.py "
        f"--build-state <build-state> --stage <{stage_hint}>` before this stage's gate; "
        f"rendered copies ship in the build's worker kit under `exit-contracts/`."
    )


def render_docs() -> list[str]:
    """Refresh the generated pointer line in each phase document. Returns the
    documents whose content changed (an empty list means everything is
    current)."""
    changed: list[str] = []
    for target, stages in sorted(doc_targets().items()):
        path = ROOT / target
        lines = path.read_text(encoding="utf-8").split("\n")
        fresh = pointer_line(stages)
        for index, line in enumerate(lines):
            if line.startswith(POINTER_PREFIX):
                if line != fresh:
                    lines[index] = fresh
                    path.write_text("\n".join(lines), encoding="utf-8", newline="\n")
                    changed.append(target)
                break
        else:
            insert_at = 0
            for index, line in enumerate(lines):
                if line.startswith("# "):
                    insert_at = index + 1
                    while insert_at < len(lines) and lines[insert_at].strip() == "":
                        insert_at += 1
                    break
            lines.insert(insert_at, fresh)
            path.write_text("\n".join(lines), encoding="utf-8", newline="\n")
            changed.append(target)
    return changed


def render_workspace_contracts(build_root: Path, state_path: str | Path | None, *, kit_dir: Path | None = None) -> list[str]:
    """Write one rendered exit contract per stage into a kit directory (the
    build's worker kit by default). Called by the worker-kit staging hook so
    the contracts can never drift from the source they were rendered from.
    Before a build state exists, contracts render with default paths and
    unknown statuses, exactly as an agent would inspect them. Returns the
    paths written."""
    base = kit_dir or (build_root / ".work" / "worker-kit" / "exit-contracts")
    written: list[str] = []
    for stage in context()["stages"]:
        path = base / f"{stage}.md"
        path.parent.mkdir(parents=True, exist_ok=True)
        contract = stage_contract(state_path, stage)
        path.write_text(render_text(contract) + "\n", encoding="utf-8", newline="\n")
        written.append(str(path))
    return written


def next_contract_payload(build_state: str | Path, stage: str) -> dict[str, Any]:
    """The compact payload pipeline_stage_gate --next embeds for its stage."""
    contract = stage_contract(build_state, stage)
    return {
        "kind": contract["kind"],
        "contract_version": contract["contract_version"],
        "stage": contract["stage"],
        "gate": contract["gate"],
        "doc": contract["doc"],
        "requirements": contract["requirements"],
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--build-state")
    parser.add_argument("--stage")
    parser.add_argument("--next", action="store_true", help="print the contract for the build's next pipeline stage")
    parser.add_argument("--render-docs", action="store_true", help="refresh the generated pointer line in each phase document")
    args = parser.parse_args()
    try:
        if args.render_docs:
            changed = render_docs()
            print(f"[worldbuilder] phase contract pointers written; {len(changed)} document(s) updated")
            for target in changed:
                print(f"  - {target}")
            return 0
        if args.stage:
            print(render_text(stage_contract(args.build_state, args.stage)))
            return 0
        if args.next:
            if not args.build_state:
                raise WorldBuilderError("--next requires --build-state")
            import pipeline_stage_gate
            result = pipeline_stage_gate.next_step(args.build_state)
            stage = result.get("next_stage") if isinstance(result, dict) else None
            if not stage:
                print(f"[worldbuilder] no next stage to describe (status: {result.get('status')})")
                return 0
            print(render_text(stage_contract(args.build_state, stage)))
            return 0
        print(__doc__.strip())
        return 0
    except (WorldBuilderError, OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"PHASE CONTRACT: {exc}", file=sys.stderr)
        return 0


if __name__ == "__main__":
    raise SystemExit(main())
