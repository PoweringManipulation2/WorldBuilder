#!/usr/bin/env python3
"""Build a privacy-first public diagnostics bundle for one WorldBuilder build.

The default bundle is safe metadata, not a project export: it contains the build-state
shape, a small allowlisted state summary, receipt/gate metadata and hashes, a scrubbed
copy of one explicitly supplied failing-gate output, and a sanitized capability report.
Generated build content is included only with --include-generated-content. Raw inputs,
research/evidence ledgers, and source corpora are never included by this command.
"""
from __future__ import annotations

import argparse
import hashlib
import io
import json
import os
import re
import zipfile
from pathlib import Path
from typing import Any, Callable, Mapping

from wb_common import WorldBuilderError, atomic_write_bytes, load_build_state, resolve_state_path, sha256_bytes, sha256_file
from wb_operations import probe_capabilities

CONTRACT = "worldbuilder-public-diagnostics-v1"
BUNDLE_KIND = "worldbuilder-public-diagnostics-bundle"
RECEIPT_KIND = "worldbuilder-public-diagnostics-receipts"
FIXED_ZIP_TIME = (1980, 1, 1, 0, 0, 0)
MAX_GATE_EXCERPT = 16_000
SKILL_ROOT = Path(__file__).resolve().parent.parent
EXPORTER_VERSION = (SKILL_ROOT / "VERSION").read_text(encoding="utf-8").strip()

SAFE_STATE_SECTIONS: dict[str, tuple[str, ...]] = {
    "artifact": ("type", "schema", "persona_mode"),
    "source": ("stance", "kind", "research_kind", "imported_confidence_default", "additive"),
    "settings": ("runtime_target", "runtime_format", "runtime_target_requested", "runtime_format_requested"),
    "discovery": ("required", "execution", "status", "confirmed_dead_after_rounds"),
    "planning": ("required", "identity_registry_required", "authority_contract", "activation_contract", "generation_assignment_version", "map_required", "profile_id"),
    "pipeline": ("mode", "dispatch_count", "expected_phase_count", "requires_phase_gates"),
    "batching": ("generation_entries_per_worker",),
    "timeouts": ("per_uid_seconds", "per_page_seconds"),
    "interface": ("mode", "build_menu", "max_settings_per_page"),
    "budget": ("contract", "policy", "profile_id", "profile_label", "applicable", "context_window_mode", "context_window", "auto_review_required"),
    "dynamic_state": ("contract", "policy", "applicable"),
    "pipeline_stage_gate": ("contract", "current_stage"),
    "status": (),
}

SAFE_RECEIPT_EXACT = {
    "kind", "contract", "schema", "status", "stage", "receipt_version", "version",
    "build_id", "outcome", "error_class", "execution_mode", "check", "gate",
    "profile", "profile_id", "policy", "target_profile", "source_mode", "decision",
}
HASHED_ARTIFACT_KEYS = (
    "manifest", "build_id", "recursion_map", "planning_receipt", "discovery_receipt",
    "activation_map_receipt", "architecture_planning_receipt", "architecture_output_receipt",
    "placement_planning_receipt", "placement_output_receipt", "budget_planning_receipt",
    "budget_output_receipt", "dynamic_state_planning_receipt", "dynamic_state_output_receipt",
    "pre_generation_audit_receipt", "post_generation_audit_receipt", "runtime_adapter_receipt",
    "integration_planning_receipt", "integration_output_receipt", "integration_resume_receipt",
    "pipeline_stage_ledger", "final_output",
)


def _json_bytes(value: Any) -> bytes:
    return (json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n").encode("utf-8")


def _shape(value: Any, *, depth: int = 0) -> Any:
    """Describe structure without retaining scalar values or user-authored strings."""
    if depth > 10:
        return {"type": "depth-limit"}
    if isinstance(value, dict):
        return {
            "type": "object",
            "key_count": len(value),
            "keys": {str(key): _shape(item, depth=depth + 1) for key, item in sorted(value.items(), key=lambda kv: str(kv[0]))},
        }
    if isinstance(value, list):
        item_types = sorted({type(item).__name__ for item in value})
        return {"type": "array", "item_count": len(value), "item_types": item_types}
    if value is None:
        return {"type": "null"}
    if isinstance(value, bool):
        return {"type": "boolean"}
    if isinstance(value, int):
        return {"type": "integer"}
    if isinstance(value, float):
        return {"type": "number"}
    if isinstance(value, str):
        return {"type": "string", "length": len(value)}
    return {"type": type(value).__name__}


def _safe_state_summary(state: Mapping[str, Any]) -> dict[str, Any]:
    summary: dict[str, Any] = {
        "state_version": state.get("state_version"),
        "worldbuilder_version": state.get("worldbuilder_version"),
        "exporter_version": EXPORTER_VERSION,
        "build_id": state.get("build_id"),
    }
    for section, fields in SAFE_STATE_SECTIONS.items():
        value = state.get(section)
        if not isinstance(value, Mapping):
            continue
        if not fields:
            summary[section] = {str(k): v for k, v in value.items() if isinstance(v, (bool, int, float)) or v is None or (isinstance(v, str) and len(v) <= 80)}
        else:
            summary[section] = {field: value.get(field) for field in fields if field in value}
    models = state.get("models") if isinstance(state.get("models"), Mapping) else {}
    if models:
        summary["model_routes"] = {
            str(role): ("inherit" if value in {None, "", "inherit"} else "configured")
            for role, value in models.items()
        }
    paths = state.get("paths") if isinstance(state.get("paths"), Mapping) else {}
    summary["path_keys"] = sorted(str(k) for k in paths)
    lineage = state.get("lineage") if isinstance(state.get("lineage"), Mapping) else {}
    summary["lineage"] = {"input_present": bool(lineage.get("input"))}
    return summary


def _safe_receipt_metadata(value: Any) -> dict[str, Any]:
    if not isinstance(value, Mapping):
        return {"json_type": type(value).__name__}
    out: dict[str, Any] = {}
    for key, item in value.items():
        name = str(key)
        safe_name = (
            name in SAFE_RECEIPT_EXACT
            or name.endswith("_sha256")
            or name.endswith("_count")
            or name.startswith("all_")
            or name.endswith("_required")
            or name.endswith("_validated")
            or name.endswith("_proven")
        )
        if not safe_name:
            continue
        if item is None or isinstance(item, (bool, int, float)):
            out[name] = item
        elif isinstance(item, str):
            if name.endswith("_sha256") and re.fullmatch(r"[0-9a-fA-F]{64}", item):
                out[name] = item.lower()
            elif name in SAFE_RECEIPT_EXACT and len(item) <= 120 and not re.search(r"[/\\@]", item):
                out[name] = item
    return out


def _receipt_inventory(root: Path, state: Mapping[str, Any]) -> dict[str, Any]:
    paths = state.get("paths") if isinstance(state.get("paths"), Mapping) else {}
    rows: list[dict[str, Any]] = []
    aggregates: list[dict[str, Any]] = []
    seen: set[Path] = set()

    def add_file(logical_key: str, path: Path) -> None:
        resolved = path.resolve()
        if resolved in seen or not path.is_file():
            return
        seen.add(resolved)
        row: dict[str, Any] = {
            "logical_key": logical_key,
            "sha256": sha256_file(path),
            "size_bytes": path.stat().st_size,
        }
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError, OSError):
            row["format"] = "opaque"
        else:
            row["format"] = "json"
            row["metadata"] = _safe_receipt_metadata(data)
        rows.append(row)

    for key, rel in sorted(paths.items(), key=lambda kv: str(kv[0])):
        if rel is None or not isinstance(rel, str):
            continue
        key_s = str(key)
        if "receipt" not in key_s and key_s not in {"pipeline_stage_ledger", "repair_ledger", "receipts"}:
            continue
        try:
            path = (root / rel).resolve()
            path.relative_to(root.resolve())
        except (ValueError, OSError):
            continue
        if path.is_file():
            if path.suffix == ".jsonl":
                aggregates.append({"logical_key": key_s, "sha256": sha256_file(path), "size_bytes": path.stat().st_size, "format": "jsonl"})
            else:
                add_file(key_s, path)
        elif path.is_dir():
            files = sorted(p for p in path.rglob("*.json") if p.is_file())
            aggregate_hash = hashlib.sha256()
            for child in files:
                digest = sha256_file(child)
                aggregate_hash.update(digest.encode("ascii"))
                add_file(key_s, child)
            aggregates.append({"logical_key": key_s, "file_count": len(files), "aggregate_sha256": aggregate_hash.hexdigest()})

    return {"kind": RECEIPT_KIND, "contract": CONTRACT, "receipts": rows, "aggregates": aggregates}


def _hash_inventory(root: Path, state: Mapping[str, Any]) -> dict[str, Any]:
    paths = state.get("paths") if isinstance(state.get("paths"), Mapping) else {}
    rows = []
    for key in HASHED_ARTIFACT_KEYS:
        rel = paths.get(key)
        if not isinstance(rel, str):
            continue
        try:
            path = (root / rel).resolve()
            path.relative_to(root.resolve())
        except (ValueError, OSError):
            continue
        if path.is_file():
            rows.append({"logical_key": key, "present": True, "sha256": sha256_file(path), "size_bytes": path.stat().st_size})
        else:
            rows.append({"logical_key": key, "present": False})
    return {"kind": "worldbuilder-public-diagnostics-hashes", "contract": CONTRACT, "artifacts": rows}


def _safe_capability_report(report: Mapping[str, Any]) -> dict[str, Any]:
    caps = report.get("capabilities") if isinstance(report.get("capabilities"), Mapping) else {}
    safe_caps: dict[str, Any] = {}
    for name, value in caps.items():
        if not isinstance(value, Mapping):
            continue
        safe_caps[str(name)] = {
            "status": value.get("status"),
            "needed_for": value.get("needed_for"),
            "degradation": value.get("degradation"),
        }
    host = report.get("openclaw_host") if isinstance(report.get("openclaw_host"), Mapping) else {}
    return {
        "schema": report.get("schema"),
        "capabilities": safe_caps,
        "openclaw_host": {k: host.get(k) for k in ("available", "version", "minimum", "compatible") if k in host},
        "hard_stop": bool(report.get("hard_stop")),
        "degraded": list(report.get("degraded") or []),
        "unknown": list(report.get("unknown") or []),
    }


def _scrub_gate_text(text: str, *, root: Path, workspace: str | None) -> str:
    replacements = [str(root.resolve()), str(Path.home())]
    if workspace:
        replacements.append(str(Path(workspace).expanduser()))
    result = text
    for value in sorted({x for x in replacements if x}, key=len, reverse=True):
        result = result.replace(value, "<path>")
        result = result.replace(value.replace("/", "\\"), "<path>")
    result = re.sub(r"https?://[^\s<>]+", "<url>", result, flags=re.I)
    result = re.sub(r"\b[A-Z]:\\[^\r\n\t ]+", "<path>", result, flags=re.I)
    result = re.sub(r"/(?:home|Users|mnt|tmp|var/tmp)/[^\r\n\t ]+", "<path>", result)
    result = re.sub(r"[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}", "<email>", result, flags=re.I)
    # Gate errors frequently quote entry prose, paths, entity names, or field values.
    # Public diagnostics preserve the surrounding error semantics but not quoted payloads.
    result = re.sub(r"`[^`\r\n]*`", "<redacted>", result)
    result = re.sub(r'"[^"\r\n]*"', "<redacted>", result)
    result = re.sub(r"'[^'\r\n]*'", "<redacted>", result)

    # Common gate prose can mention an entity/build/project token without quoting it.
    # Keep numeric UIDs/counts useful, but remove arbitrary identifier payloads after
    # content-bearing nouns so a public excerpt cannot leak a private name merely
    # because the producer omitted quotes.
    def redact_named_token(match: re.Match[str]) -> str:
        label, token = match.group(1), match.group(2)
        return f"{label} {token}" if token.isdigit() else f"{label} <redacted>"

    result = re.sub(
        r"\b(entry|entity|character|project|build|name|title|prompt|content)\s+([^\s,;:]+)",
        redact_named_token,
        result,
        flags=re.I,
    )
    if len(result) > MAX_GATE_EXCERPT:
        result = result[:MAX_GATE_EXCERPT] + "\n<excerpt-truncated>\n"
    return result


def _gate_output_record(path: Path | None, *, root: Path, state: Mapping[str, Any]) -> dict[str, Any]:
    if path is None:
        return {"provided": False}
    if not path.is_file():
        raise WorldBuilderError(f"gate output file does not exist: {path}")
    raw = path.read_bytes()
    text = raw.decode("utf-8", errors="replace")
    scrubbed = _scrub_gate_text(text, root=root, workspace=state.get("workspace") if isinstance(state.get("workspace"), str) else None)
    return {
        "provided": True,
        "raw_sha256": sha256_bytes(raw),
        "raw_size_bytes": len(raw),
        "sanitized_excerpt": scrubbed,
        "sanitized_excerpt_sha256": sha256_bytes(scrubbed.encode("utf-8")),
    }


def _generated_content_files(root: Path, state: Mapping[str, Any]) -> list[tuple[str, Path]]:
    paths = state.get("paths") if isinstance(state.get("paths"), Mapping) else {}
    selected: list[tuple[str, Path]] = []
    for logical_key in ("final_output", "merge_input"):
        rel = paths.get(logical_key)
        if not isinstance(rel, str):
            continue
        path = (root / rel).resolve()
        try:
            path.relative_to(root.resolve())
        except ValueError:
            continue
        if path.is_file():
            selected.append((logical_key, path))
    rel = paths.get("phases")
    if isinstance(rel, str):
        phase_dir = (root / rel).resolve()
        try:
            phase_dir.relative_to(root.resolve())
        except ValueError:
            phase_dir = root / ".never"
        if phase_dir.is_dir():
            for path in sorted(phase_dir.glob("phase-*.json")):
                if path.is_file():
                    selected.append(("phase", path))
    return selected


def _zip_bytes(files: Mapping[str, bytes]) -> bytes:
    out = io.BytesIO()
    with zipfile.ZipFile(out, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name in sorted(files):
            info = zipfile.ZipInfo(name, date_time=FIXED_ZIP_TIME)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            archive.writestr(info, files[name])
    return out.getvalue()


def build_bundle(
    build_state: str | os.PathLike[str],
    *,
    gate_output: str | os.PathLike[str] | None = None,
    include_generated_content: bool = False,
    capability_kwargs: Mapping[str, Any] | None = None,
    capability_probe: Callable[..., Any] = probe_capabilities,
) -> tuple[bytes, dict[str, Any]]:
    root, state = load_build_state(build_state)
    files: dict[str, bytes] = {}

    shape = {"kind": "worldbuilder-build-state-structure", "contract": CONTRACT, "structure": _shape(state)}
    summary = {"kind": "worldbuilder-build-state-summary", "contract": CONTRACT, "state": _safe_state_summary(state)}
    receipts = _receipt_inventory(root, state)
    hashes = _hash_inventory(root, state)
    gate = _gate_output_record(Path(gate_output).expanduser().resolve() if gate_output is not None else None, root=root, state=state)

    probe_value = capability_probe(**dict(capability_kwargs or {}))
    report = probe_value.report if hasattr(probe_value, "report") else probe_value
    capabilities = _safe_capability_report(report if isinstance(report, Mapping) else {})

    files["build-state-structure.json"] = _json_bytes(shape)
    files["build-state-summary.json"] = _json_bytes(summary)
    files["receipts.json"] = _json_bytes(receipts)
    files["hashes.json"] = _json_bytes(hashes)
    files["capabilities.json"] = _json_bytes(capabilities)
    files["failing-gate-output.json"] = _json_bytes(gate)

    content_manifest: list[dict[str, Any]] = []
    if include_generated_content:
        for index, (logical_key, path) in enumerate(_generated_content_files(root, state), start=1):
            suffix = path.suffix if path.suffix else ".bin"
            member = f"generated-content/{index:03d}-{logical_key}{suffix}"
            raw = path.read_bytes()
            files[member] = raw
            content_manifest.append({"member": member, "logical_key": logical_key, "sha256": sha256_bytes(raw), "size_bytes": len(raw)})

    inventory = [
        {"member": name, "sha256": sha256_bytes(raw), "size_bytes": len(raw)}
        for name, raw in sorted(files.items())
    ]
    bundle_manifest = {
        "kind": BUNDLE_KIND,
        "contract": CONTRACT,
        "bundle_version": 1,
        "worldbuilder_version": state.get("worldbuilder_version"),
        "exporter_version": EXPORTER_VERSION,
        "build_id": state.get("build_id"),
        "privacy": {
            "generated_content_included": include_generated_content,
            "raw_input_included": False,
            "raw_research_or_evidence_included": False,
            "raw_build_state_included": False,
            "raw_receipts_included": False,
            "gate_output_scrubbed": bool(gate.get("provided")),
        },
        "generated_content": content_manifest,
        "files": inventory,
    }
    files["bundle.json"] = _json_bytes(bundle_manifest)
    return _zip_bytes(files), bundle_manifest


def _default_output(root: Path, state: Mapping[str, Any]) -> Path:
    path = resolve_state_path(root, dict(state), "public_diagnostics_bundle", required=False)
    return path if path is not None else root / "artifacts" / "public-diagnostics.zip"


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--build-state", required=True)
    parser.add_argument("--gate-output", help="Specific failing gate stdout/stderr captured to a file; scrubbed before bundling.")
    parser.add_argument("--output", help="ZIP destination. Defaults to the build's public_diagnostics_bundle path.")
    parser.add_argument("--include-generated-content", action="store_true", help="Explicitly include final/merged/phase generated bytes. Raw inputs/research/evidence remain excluded.")
    for flag in ("sessions-spawn", "show-widget", "image-generate", "html-render", "st-bridge", "wi-introspection"):
        parser.add_argument(f"--{flag}", choices=("available", "unavailable"), default=None)
    parser.add_argument("--searxng-base-url", default=None, help="Deprecated compatibility flag; public-web readiness is verified only by searxng_preflight.py and is not folded into the generic capability snapshot.")
    parser.add_argument("--timeout", type=float, default=10.0)
    args = parser.parse_args()

    root, state = load_build_state(args.build_state)
    capability_kwargs = {
        "sessions_spawn": args.sessions_spawn,
        "show_widget": args.show_widget,
        "image_generate": args.image_generate,
        "html_render": args.html_render,
        "st_bridge": args.st_bridge,
        "wi_introspection": args.wi_introspection,
        "timeout": args.timeout,
    }
    payload, manifest = build_bundle(
        args.build_state,
        gate_output=args.gate_output,
        include_generated_content=args.include_generated_content,
        capability_kwargs=capability_kwargs,
    )
    output = Path(args.output).expanduser().resolve() if args.output else _default_output(root, state)
    atomic_write_bytes(output, payload)
    result = {
        "kind": "worldbuilder-public-diagnostics-export",
        "contract": CONTRACT,
        "status": "written",
        "output": str(output),
        "sha256": sha256_bytes(payload),
        "size_bytes": len(payload),
        "generated_content_included": manifest["privacy"]["generated_content_included"],
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except WorldBuilderError as exc:
        print(f"WorldBuilder error: {exc}", file=os.sys.stderr)
        raise SystemExit(2)
