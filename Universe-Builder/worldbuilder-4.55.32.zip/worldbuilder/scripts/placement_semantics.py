#!/usr/bin/env python3
"""Public placement-resolution semantics shared by planning and pruning.

Promoted from ``placement_contract.py`` during the Batch 23 maintainability
refactor. The values and validation behavior are intentionally unchanged.
"""
from __future__ import annotations

import re
from typing import Any

from wb_common import WorldBuilderError, uid_key
from budget_contract import protected_categories as budget_protected_categories
# Batch 52: one shared resolver. These five were locally duplicated here and
# had already drifted from activation_semantics.py (unseeded
# profile_defaults); the canonical implementation now lives there only.
from activation_semantics import (
    emit_config,
    extension_config,
    first_value,
    profile_defaults,
    setting,
)

PROTECTED_ENTRY_WEIGHT = 1000

STANDARD_ENTRY_WEIGHT = 100

ALLOWED_ROLES = {None, "system", "user", "assistant", 0, 1, 2}

POSITION_ALIASES: dict[Any, str] = {
    "before_char": "before_char",
    "beforechar": "before_char",
    "before character definitions": "before_char",
    0: "before_char",
    "after_char": "after_char",
    "afterchar": "after_char",
    "after character definitions": "after_char",
    1: "after_char",
    "before_examples": "before_examples",
    "before example messages": "before_examples",
    "after_examples": "after_examples",
    "after example messages": "after_examples",
    "authors_note_top": "authors_note_top",
    "author's note top": "authors_note_top",
    "authors note top": "authors_note_top",
    "authors_note_bottom": "authors_note_bottom",
    "author's note bottom": "authors_note_bottom",
    "authors note bottom": "authors_note_bottom",
    "depth": "depth",
    "at_depth": "depth",
    "at chat depth": "depth",
    "outlet": "outlet",
    "named outlet": "outlet",
}


def normalize_position(value: Any) -> str | None:
    if value is None or value == "":
        return None
    key: Any = value
    if isinstance(value, str):
        key = re.sub(r"\s+", " ", value.strip().casefold())
    result = POSITION_ALIASES.get(key)
    if result is None:
        raise WorldBuilderError(f"unsupported semantic placement {value!r}")
    return result


def placement_values(entry: dict[str, Any], profile: dict[str, Any], required_edge_uids: set[str]) -> dict[str, Any]:
    arch = entry.get("architecture")
    if not isinstance(arch, dict):
        raise WorldBuilderError(f"manifest entry {uid_key(entry.get('uid', entry.get('id')))} lacks architecture")
    layer = str(arch.get("layer", "")).strip()
    if not layer:
        raise WorldBuilderError(f"manifest entry {uid_key(entry.get('uid', entry.get('id')))} lacks architecture.layer")
    defaults = profile_defaults(profile, layer)
    emit = emit_config(entry)
    position = normalize_position(setting(emit, ("position",), defaults.get("position")))
    order = setting(emit, ("insertion_order", "order"), defaults.get("insertion_order"))
    priority = setting(emit, ("priority",), defaults.get("priority"))
    depth = setting(emit, ("depth",), defaults.get("depth"))
    role = setting(emit, ("role",), defaults.get("role"))
    ROLE_NUMERIC_SHORTHAND = {0: "system", 1: "user", 2: "assistant"}
    if isinstance(role, int) and not isinstance(role, bool) and role in ROLE_NUMERIC_SHORTHAND:
        role = ROLE_NUMERIC_SHORTHAND[role]
    outlet = setting(emit, ("outlet",), defaults.get("outlet"))
    constant = bool(setting(emit, ("constant",), defaults.get("constant", False)))
    if order is not None and (not isinstance(order, int) or isinstance(order, bool) or not 0 <= order <= 10000):
        raise WorldBuilderError(f"entry {uid_key(entry.get('uid', entry.get('id')))} insertion order must be 0..10000 or null")
    if priority is not None and (not isinstance(priority, int) or isinstance(priority, bool) or not -10000 <= priority <= 10000):
        raise WorldBuilderError(f"entry {uid_key(entry.get('uid', entry.get('id')))} priority must be an integer or null")
    if depth is not None and (not isinstance(depth, int) or isinstance(depth, bool) or depth < 0):
        raise WorldBuilderError(f"entry {uid_key(entry.get('uid', entry.get('id')))} depth must be a non-negative integer or null")
    if role not in ALLOWED_ROLES:
        raise WorldBuilderError(f"entry {uid_key(entry.get('uid', entry.get('id')))} role must be system, user, assistant, 0, 1, 2, or null")
    if outlet is not None and (not isinstance(outlet, str) or not outlet.strip()):
        raise WorldBuilderError(f"entry {uid_key(entry.get('uid', entry.get('id')))} outlet must be a non-empty string or null")
    categories = budget_protected_categories(entry, required_edge_uids)
    weight = PROTECTED_ENTRY_WEIGHT if categories else STANDARD_ENTRY_WEIGHT
    return {
        "layer": layer,
        "position": position,
        "insertion_order": order,
        "priority": priority,
        "depth": depth,
        "role": role,
        "outlet": outlet.strip() if isinstance(outlet, str) else None,
        "constant": constant,
        "weight": weight,
        "protected_categories": sorted(categories),
        "defaults": defaults,
    }
