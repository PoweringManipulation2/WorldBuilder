#!/usr/bin/env python3
"""Sealed revision history, rollback, and UID cherry-pick support.

Revisions reuse WorldBuilder's existing content hashes.  Rollback restores an
already-sealed snapshot and resets amendment depth to zero: it is a fresh
baseline, not another forward amendment.  Author locks applied after the target
revision are surfaced as explicit conflicts before any bytes are restored.
"""
from __future__ import annotations

import argparse
import copy
import json
import os
import shutil
from pathlib import Path
from typing import Any, Iterable

from lock_contract import is_locked, lock_reason
from selective_regeneration import prepare as prepare_regeneration, resolve_scope
from wb_common import WorldBuilderError, atomic_write_json, build_identity_index, entry_binding_hash, load_build_state, load_json, normalize_identity, now_iso, resolve_state_path, sha256_file

CONTRACT = "worldbuilder-revision-history-v1"


def _history_path(root: Path, state: dict[str, Any]) -> Path:
    return resolve_state_path(root, state, "revision_history", required=False) or (root / "artifacts/revision-history.json")


def _revision_root(root: Path, state: dict[str, Any]) -> Path:
    return resolve_state_path(root, state, "revisions", required=False) or (root / "artifacts/revisions")


def load_history(root: Path, state: dict[str, Any]) -> dict[str, Any]:
    path = _history_path(root, state)
    if path.exists():
        data = load_json(path)
        if data.get("contract") != CONTRACT:
            raise WorldBuilderError("revision-history.json has an unsupported contract")
        return data
    return {"contract": CONTRACT, "build_id": state.get("build_id"), "revisions": []}


def _copy_if_exists(root: Path, state: dict[str, Any], key: str, dest: Path) -> dict[str, Any] | None:
    path = resolve_state_path(root, state, key, required=False)
    if path is None or not path.is_file():
        return None
    out = dest / f"{key}{path.suffix or '.bin'}"
    shutil.copy2(path, out)
    return {"key": key, "snapshot": str(out.relative_to(root)).replace(os.sep, "/"), "source": str(path.relative_to(root)).replace(os.sep, "/"), "sha256": sha256_file(out)}


def _copy_pipeline_stage_receipts(root: Path, state: dict[str, Any], dest: Path) -> dict[str, Any] | None:
    source = resolve_state_path(root, state, "pipeline_stage_receipts", required=False) or (root / "artifacts" / "pipeline-stage-receipts")
    if not source.is_dir():
        return None
    out = dest / "pipeline-stage-receipts"
    shutil.copytree(source, out)
    inventory = [
        {
            "path": str(path.relative_to(out)).replace(os.sep, "/"),
            "sha256": sha256_file(path),
        }
        for path in sorted(out.rglob("*"))
        if path.is_file()
    ]
    return {
        "key": "pipeline_stage_receipts",
        "snapshot": str(out.relative_to(root)).replace(os.sep, "/"),
        "source": str(source.relative_to(root)).replace(os.sep, "/"),
        "inventory": inventory,
    }


def record_sealed_revision(build_state: str | Path, *, seal: dict[str, Any] | None = None, label: str | None = None) -> dict[str, Any]:
    state_path = Path(build_state).resolve()
    root, state = load_build_state(state_path)
    history = load_history(root, state)
    revisions = history.setdefault("revisions", [])
    revision_id = f"rev-{len(revisions)+1:04d}"
    dest = _revision_root(root, state) / revision_id
    dest.mkdir(parents=True, exist_ok=False)
    files = []
    for key in ("manifest", "merge_input", "final_output", "audit_log", "source_lineage"):
        row = _copy_if_exists(root, state, key, dest)
        if row: files.append(row)
    # Pipeline ledger and the relevant state fragment are required to restore a
    # genuinely sealed baseline, not merely copy the final JSON.
    ledger_rel = (state.get("pipeline_stage_gate") or {}).get("ledger")
    if isinstance(ledger_rel, str) and ledger_rel:
        ledger = (root / ledger_rel).resolve()
        if ledger.is_file():
            out = dest / "pipeline-ledger.json"; shutil.copy2(ledger, out)
            files.append({"key": "pipeline_ledger", "snapshot": str(out.relative_to(root)).replace(os.sep, "/"), "source": ledger_rel, "sha256": sha256_file(out)})
    stage_receipts = _copy_pipeline_stage_receipts(root, state, dest)
    if stage_receipts:
        files.append(stage_receipts)
    fragment = {
        "status": copy.deepcopy(state.get("status", {})),
        "lineage": copy.deepcopy(state.get("lineage", {})),
        "pipeline_stage_gate": copy.deepcopy(state.get("pipeline_stage_gate", {})),
    }
    fragment_path = dest / "state-fragment.json"; atomic_write_json(fragment_path, fragment)
    record = {
        "revision_id": revision_id, "created_at": now_iso(), "label": label,
        "target_sha256": (seal or {}).get("target_sha256") or (sha256_file(resolve_state_path(root, state, "final_output")) if resolve_state_path(root, state, "final_output", required=False) and resolve_state_path(root, state, "final_output", required=False).exists() else None),
        "seal": copy.deepcopy(seal), "files": files,
        "state_fragment": str(fragment_path.relative_to(root)).replace(os.sep, "/"),
    }
    revisions.append(record); history["updated_at"] = now_iso()
    atomic_write_json(_history_path(root, state), history)
    return record


def _revision(history: dict[str, Any], revision_id: str) -> dict[str, Any]:
    row = next((r for r in history.get("revisions", []) if isinstance(r, dict) and r.get("revision_id") == revision_id), None)
    if row is None:
        raise WorldBuilderError(f"unknown revision {revision_id!r}")
    return row


def _locked_conflicts(current_manifest: dict[str, Any], target_manifest: dict[str, Any]) -> list[dict[str, Any]]:
    current = build_identity_index(current_manifest); target = build_identity_index(target_manifest)
    conflicts = []
    for ident, (_path, entry) in current.items():
        if not is_locked(entry):
            continue
        target_entry = target.get(ident, (None, None))[1]
        if target_entry is None or entry_binding_hash(entry) != entry_binding_hash(target_entry):
            conflicts.append({"uid": str(ident), "name": entry.get("name") or entry.get("comment"), "reason": lock_reason(entry), "target_has_entry": target_entry is not None})
    return conflicts


def rollback(build_state: str, revision_id: str, *, approve_lock_conflicts: bool = False, lock_conflict_user_confirmation: str | None = None) -> dict[str, Any]:
    state_path = Path(build_state).resolve(); root, state = load_build_state(state_path)
    history = load_history(root, state); rev = _revision(history, revision_id)
    file_rows = {r.get("key"): r for r in rev.get("files", []) if isinstance(r, dict)}
    target_manifest_row = file_rows.get("manifest")
    if not target_manifest_row:
        raise WorldBuilderError("target revision has no manifest snapshot")
    current_manifest = load_json(resolve_state_path(root, state, "manifest"))
    target_manifest = load_json(root / target_manifest_row["snapshot"])
    conflicts = _locked_conflicts(current_manifest, target_manifest)
    if conflicts:
        names = ", ".join(f"UID {r['uid']} ({r.get('reason') or 'locked'})" for r in conflicts)
        if not approve_lock_conflicts:
            raise WorldBuilderError(
                f"rollback would override author lock(s): {names}; ask the person whether to override these locks before re-running"
            )
        if not isinstance(lock_conflict_user_confirmation, str) or not lock_conflict_user_confirmation.strip():
            raise WorldBuilderError(
                f"rollback would override author lock(s): {names}; --approve-lock-conflicts is insufficient by itself. "
                "Record the person's explicit decision with --lock-conflict-user-confirmation."
            )
    for row in rev.get("files", []):
        if not isinstance(row, dict) or row.get("key") in {"pipeline_ledger", "pipeline_stage_receipts"}:
            continue
        source_rel, snap_rel = row.get("source"), row.get("snapshot")
        if isinstance(source_rel, str) and isinstance(snap_rel, str):
            src = root / snap_rel; dst = root / source_rel
            if sha256_file(src) != row.get("sha256"):
                raise WorldBuilderError(f"revision snapshot is corrupt at {snap_rel}")
            dst.parent.mkdir(parents=True, exist_ok=True); shutil.copy2(src, dst)
    ledger_row = file_rows.get("pipeline_ledger")
    stage_receipts_row = file_rows.get("pipeline_stage_receipts")
    if stage_receipts_row:
        snap_rel = stage_receipts_row.get("snapshot")
        source_rel = stage_receipts_row.get("source")
        inventory = stage_receipts_row.get("inventory")
        if not isinstance(snap_rel, str) or not isinstance(source_rel, str) or not isinstance(inventory, list):
            raise WorldBuilderError("revision's pipeline-stage receipt snapshot metadata is malformed")
        snapshot_dir = root / snap_rel
        for item in inventory:
            if not isinstance(item, dict) or not isinstance(item.get("path"), str) or not isinstance(item.get("sha256"), str):
                raise WorldBuilderError("revision's pipeline-stage receipt inventory is malformed")
            path = snapshot_dir / item["path"]
            if not path.is_file() or sha256_file(path) != item["sha256"]:
                raise WorldBuilderError(f"revision pipeline-stage receipt snapshot is corrupt at {item['path']}")
        destination = root / source_rel
        if destination.exists():
            shutil.rmtree(destination)
        shutil.copytree(snapshot_dir, destination)
    if ledger_row:
        ledger = load_json(root / ledger_row["snapshot"])
        ledger["amendments"] = []
        ledger["updated_at"] = now_iso()
        dst = root / ledger_row["source"]; atomic_write_json(dst, ledger)
    fragment = load_json(root / rev["state_fragment"])
    for key in ("status", "lineage", "pipeline_stage_gate"):
        if key in fragment: state[key] = fragment[key]
    if ledger_row:
        state.setdefault("pipeline_stage_gate", {})["ledger_sha256"] = sha256_file(root / ledger_row["source"])
    state.setdefault("revision", {})["rollback"] = {
        "restored_revision": revision_id, "restored_at": now_iso(), "amendment_depth_reset": True,
        "lock_conflicts_approved": bool(conflicts and approve_lock_conflicts),
        "lock_conflict_user_confirmation": lock_conflict_user_confirmation.strip() if conflicts and lock_conflict_user_confirmation else None,
    }
    atomic_write_json(state_path, state)
    return {"status": "rolled_back", "revision_id": revision_id, "amendment_depth": 0, "lock_conflicts": conflicts}


def cherry_pick(build_state: str, revision_id: str, uids: Iterable[str]) -> dict[str, Any]:
    state_path = Path(build_state).resolve(); root, state = load_build_state(state_path)
    history = load_history(root, state); rev = _revision(history, revision_id)
    manifest_row = next((r for r in rev.get("files", []) if isinstance(r, dict) and r.get("key") == "manifest"), None)
    final_row = next((r for r in rev.get("files", []) if isinstance(r, dict) and r.get("key") == "final_output"), None)
    if not manifest_row or not final_row: raise WorldBuilderError("revision lacks manifest/final-output snapshots")
    current_manifest = load_json(resolve_state_path(root, state, "manifest"))
    scope = resolve_scope(current_manifest, scope_kind="uids", uids=uids)
    prepared = prepare_regeneration(build_state, scope)
    prior = load_json(root / final_row["snapshot"]); prior_idx = build_identity_index(prior)
    selected = []
    for uid in scope["resolved_uids"]:
        ident = normalize_identity(uid)
        if ident not in prior_idx: raise WorldBuilderError(f"revision {revision_id} has no UID {uid}")
        selected.append(copy.deepcopy(prior_idx[ident][1]))
    payload = {"entries": selected}
    plan_path = Path(prepared["plan"]); out = plan_path.parent / f"cherry-pick-{revision_id}.json"; atomic_write_json(out, payload)
    return {"status": "prepared", "plan": prepared["plan"], "regenerated_payload": str(out), "next": "Apply with selective_regeneration.py apply, then run the ordinary scoped audit path."}


def main() -> int:
    p=argparse.ArgumentParser(description=__doc__); p.add_argument("--build-state", required=True)
    sub=p.add_subparsers(dest="command", required=True)
    r=sub.add_parser("record"); r.add_argument("--label")
    rb=sub.add_parser("rollback"); rb.add_argument("--revision", required=True); rb.add_argument("--approve-lock-conflicts", action="store_true"); rb.add_argument("--lock-conflict-user-confirmation", help="Required with --approve-lock-conflicts when a rollback would overwrite author-locked content; record the person's explicit decision.")
    cp=sub.add_parser("cherry-pick"); cp.add_argument("--revision", required=True); cp.add_argument("--uid", action="append", required=True)
    sub.add_parser("list")
    a=p.parse_args()
    try:
        if a.command=="record": result={"status":"recorded","revision":record_sealed_revision(a.build_state,label=a.label)}
        elif a.command=="rollback": result=rollback(a.build_state,a.revision,approve_lock_conflicts=a.approve_lock_conflicts,lock_conflict_user_confirmation=a.lock_conflict_user_confirmation)
        elif a.command=="cherry-pick": result=cherry_pick(a.build_state,a.revision,a.uid)
        else:
            root,state=load_build_state(a.build_state); result=load_history(root,state)
        print(json.dumps(result,ensure_ascii=False,indent=2)); return 0
    except (WorldBuilderError,OSError,ValueError,json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}",file=__import__('sys').stderr); return 1

if __name__=="__main__": raise SystemExit(main())
