#!/usr/bin/env python3
"""Classify MediaWiki/Fandom pages before expensive discovery workers read them.

The filter preserves high recall while separating true world-content pages from
indexes, redirect aliases, transcripts/reference pages, production metadata,
and obvious wiki infrastructure.  It uses cheap batched MediaWiki metadata
queries and only harvests links from index-like pages deterministically.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any, Iterable

from wb_common import WorldBuilderError, atomic_write_json, load_json

PAGE_FILTER_VERSION = 1
USER_AGENT = "WorldBuilder/3.6 (+deterministic MediaWiki prefilter)"

NON_CONTENT_NAMESPACES = re.compile(
    r"^(?:User|User talk|Talk|Template|File|Image|Special|Help|MediaWiki|Forum|Thread|Message Wall):",
    re.I,
)
DISAMBIG_MARKERS = ("disambiguation", "disambig")
INDEX_TITLE_PATTERNS = (
    re.compile(r"^(?:list|index|directory|portal) of\b", re.I),
    re.compile(r"^(?:character|location|episode|song|species|faction) list\b", re.I),
    re.compile(r"\((?:list|index|disambiguation)\)$", re.I),
)
INDEX_CATEGORY_MARKERS = (
    "lists", "indexes", "index pages", "navigation", "navigational pages",
    "disambiguation pages", "portals",
)
# Content articles commonly transclude navboxes. Treating any navbox template as
# proof that the page itself is an index would discard most real wiki articles.
INDEX_TEMPLATE_MARKERS = ("disambiguation", "disambig")
# Quality signals, NOT content signals. Every one of these is a tracking category that
# real articles belong to: "articles needing citations" is a category full of articles.
# Excluding on them removed 79 primary pages from one wiki, including the show's
# protagonist and its world root, because that wiki tags most stubs for cleanup.
#
# A maintenance tag says an article needs work. It does not say the page is not an
# article. Whether a page is content is structural (namespace, redirect status, whether
# it has prose), and that is what the filter is allowed to judge (DR-062).
QUALITY_FLAG_MARKERS = (
    "maintenance", "candidates for deletion", "pages needing", "articles needing",
    "broken file links", "cleanup", "tracking category", "pages with script errors",
)
GALLERY_MARKERS = ("galleries", "gallery pages", "image galleries")
TRANSCRIPT_MARKERS = ("transcripts", "episode transcripts", "scripts")
# A page carrying one of these is *about* a world entity. A production or media marker
# alongside it describes an aspect of that page, not its subject: an episode article
# categorised both "Episodes" and "Voice cast" is still the episode article. Only when a
# page has no content-type category does a production marker identify its subject.
# Same failure shape as the cleanup-tag bug, one category weaker.
# Deliberately excludes episodes, songs, and comics: those are exactly what the
# include_media policy governs, and a user who turns media off is choosing to demote
# them. Overriding that would replace one wrong default with another.
CONTENT_TYPE_MARKERS = (
    "characters", "locations", "items", "objects", "creatures",
    "factions", "organizations", "events", "species", "concepts", "places",
)
PRODUCTION_MARKERS = (
    "voice actors", "voice cast", "cast members", "cast and crew", "crew members",
    "production staff", "production crew", "dubbing", "localization", "localisation",
    "animators", "animation staff", "directors", "screenwriters", "storyboard artists",
    "production studios", "studio staff",
)
MEDIA_MARKERS = (
    "episodes", "songs", "comics", "shorts", "films", "albums", "soundtrack",
)


# ISO 639-1 codes Fandom actually uses for per-language wiki mirrors under
# /<code>/wiki/... on the same host. Deliberately a real, bounded standard
# list, not a loose "any 2-3 letters" heuristic, to keep false-positive risk
# low for a classification that (like non_content_namespace) needs no human
# approval.
FANDOM_LANGUAGE_CODES = frozenset((
    "af", "ar", "bg", "bn", "ca", "cs", "da", "de", "el", "es", "et", "eu", "fa",
    "fi", "fr", "gl", "he", "hi", "hr", "hu", "id", "it", "ja", "ko", "lt", "lv",
    "ms", "nl", "no", "pl", "pt", "ro", "ru", "sk", "sl", "sr", "sv", "th", "tr",
    "uk", "vi", "zh",
))


def default_policy() -> dict[str, Any]:
    return {
        "include_media": True,
        "include_production": False,
        "transcripts_are_reference_only": True,
        "galleries_are_excluded": True,
        "harvest_index_links": True,
        "minimum_content_bytes": 1,
        "maximum_harvest_rounds": 2,
        "maximum_harvest_urls": 50000,
        "target_language": None,
    }


def normalize_policy(value: Any = None) -> dict[str, Any]:
    policy = default_policy()
    if isinstance(value, dict):
        for key in policy:
            if key in value:
                policy[key] = value[key]
    policy["include_media"] = bool(policy["include_media"])
    policy["include_production"] = bool(policy["include_production"])
    policy["transcripts_are_reference_only"] = bool(policy["transcripts_are_reference_only"])
    policy["galleries_are_excluded"] = bool(policy["galleries_are_excluded"])
    policy["harvest_index_links"] = bool(policy["harvest_index_links"])
    policy["minimum_content_bytes"] = max(0, int(policy["minimum_content_bytes"] or 0))
    policy["maximum_harvest_rounds"] = max(0, min(5, int(policy["maximum_harvest_rounds"] or 0)))
    policy["maximum_harvest_urls"] = max(0, min(250000, int(policy["maximum_harvest_urls"] or 0)))
    lang = policy.get("target_language")
    policy["target_language"] = lang.strip().casefold() if isinstance(lang, str) and lang.strip() else None
    return policy


def stable_hash(value: Any) -> str:
    payload = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def text_values(values: Any, keys: tuple[str, ...] = ("title", "name", "category", "*")) -> list[str]:
    result: list[str] = []
    if not isinstance(values, list):
        return result
    for item in values:
        if isinstance(item, str):
            value = item
        elif isinstance(item, dict):
            value = next((item.get(key) for key in keys if isinstance(item.get(key), str)), None)
        else:
            value = None
        if isinstance(value, str) and value.strip():
            result.append(value.strip())
    return result


def marker_text(record: dict[str, Any]) -> tuple[str, str]:
    categories = " | ".join(value.replace("Category:", "") for value in text_values(record.get("categories"))).casefold()
    templates = " | ".join(value.replace("Template:", "") for value in text_values(record.get("templates"))).casefold()
    return categories, templates


def contains_any(text: str, markers: Iterable[str]) -> str | None:
    for marker in markers:
        if marker in text:
            return marker
    return None


def title_from_url(url: str) -> str:
    parsed = urllib.parse.urlsplit(url)
    query = dict(urllib.parse.parse_qsl(parsed.query))
    if query.get("title"):
        return urllib.parse.unquote(query["title"]).replace("_", " ")
    if "/wiki/" in parsed.path:
        return urllib.parse.unquote(parsed.path.split("/wiki/", 1)[1]).replace("_", " ")
    return urllib.parse.unquote(parsed.path.rstrip("/").rsplit("/", 1)[-1]).replace("_", " ")


def article_url(base_url: str, title: str) -> str:
    parsed = urllib.parse.urlsplit(base_url)
    return urllib.parse.urlunsplit((parsed.scheme, parsed.netloc, "/wiki/" + urllib.parse.quote(title.replace(" ", "_"), safe="/:()!'-,._~"), "", ""))


def hard_url_classification(url: str, target_language: str | None = None) -> dict[str, Any] | None:
    parsed_early = urllib.parse.urlsplit(url)
    path_segments = [seg for seg in parsed_early.path.split("/") if seg]
    if (
        path_segments and len(path_segments) >= 2 and path_segments[1].casefold() == "wiki"
        and path_segments[0].casefold() in FANDOM_LANGUAGE_CODES
        and path_segments[0].casefold() != target_language
    ):
        return decision(
            "excluded", "out_of_scope_language",
            f"/{path_segments[0]}/wiki/ is a per-language Fandom mirror outside the target language"
            + (f" ({target_language})" if target_language else ""),
        )
    title = title_from_url(url).strip()
    if NON_CONTENT_NAMESPACES.match(title.replace("_", " ")):
        lowered = title.casefold()
        if lowered.startswith("message wall:") or lowered.startswith("message_wall:"):
            return decision("excluded", "message_wall", "Fandom Message Wall is user discussion, not world content")
        if lowered.startswith(("user:", "user talk:", "user_talk:", "talk:", "forum:", "thread:")):
            return decision("excluded", "user_discussion", "user discussion namespace is not encyclopedic world content")
        if lowered.startswith(("file:", "image:")):
            return decision("excluded", "gallery_or_media_only", "file or image namespace is not a standalone world entity")
        return decision("excluded", "non_content_namespace", "MediaWiki infrastructure namespace is not article content")
    parsed = urllib.parse.urlsplit(url)
    bad_keys = {"oldid", "diff", "action", "printable", "redirect"}
    if any(key.casefold() in bad_keys for key, _ in urllib.parse.parse_qsl(parsed.query)):
        return decision("excluded", "maintenance_page", "history, diff, action, print, and redirect-control URLs are not canonical content")
    return None


def decision(classification: str, code: str | None, reason: str, *, evidence: list[str] | None = None,
             quality_flag: str | None = None) -> dict[str, Any]:
    result = {
        "classification": classification,
        "code": code,
        "reason": reason,
        "evidence": evidence or [],
    }
    if quality_flag:
        # Recorded so an auditor can see the page needs work, without that ever having
        # been the reason it was kept or dropped.
        result["quality_flag"] = quality_flag
    return result


def classify_metadata(record: dict[str, Any], policy_value: Any = None) -> dict[str, Any]:
    policy = normalize_policy(policy_value)
    url = str(record.get("url") or "")
    hard = hard_url_classification(url, policy.get("target_language")) if url else None
    if hard:
        return hard
    title = str(record.get("title") or record.get("requested_title") or title_from_url(url)).strip()
    categories, templates = marker_text(record)
    combined = f"{categories} | {templates}"
    pageprops = record.get("pageprops") if isinstance(record.get("pageprops"), dict) else {}
    ns = record.get("ns")
    length = record.get("length")

    if record.get("missing") is True:
        return decision("excluded", "broken_redirect", "MediaWiki reports that the page does not exist")
    if isinstance(ns, int) and ns != 0:
        return decision("excluded", "non_content_namespace", f"namespace {ns} is outside article content")
    if record.get("redirect_from") and record.get("canonical_url") and record.get("canonical_url") != url:
        return decision("alias_only", "redirect_alias", "redirect title is preserved as an alias for its canonical target", evidence=[str(record.get("canonical_url"))])
    if "disambiguation" in pageprops or title.casefold().endswith("(disambiguation)") or contains_any(combined, DISAMBIG_MARKERS):
        return decision("index_only", "disambiguation_or_index", "disambiguation page is harvested for links but is not a world entity")
    # A quality flag is recorded and carried forward, never used to exclude. Pages that
    # genuinely are maintenance pages are caught structurally by namespace and URL-shape
    # checks above.
    quality_flag = contains_any(combined, QUALITY_FLAG_MARKERS)
    quality_flag = quality_flag if isinstance(quality_flag, str) else None
    gallery = contains_any(combined, GALLERY_MARKERS)
    if gallery or title.casefold().endswith(("/gallery", " gallery", "(gallery)")):
        if policy["galleries_are_excluded"]:
            return decision("excluded", "gallery_or_media_only", "gallery page is media-only and does not create a standalone world entity", evidence=[gallery or "title"])
        return decision("reference_only", "reference_only", "gallery is retained only as a supporting research source")
    transcript = contains_any(combined, TRANSCRIPT_MARKERS) or title.casefold().endswith((" transcript", "/transcript", "(transcript)"))
    if transcript and policy["transcripts_are_reference_only"]:
        return decision("reference_only", "reference_only", "transcript/script is retained for later evidence but does not become its own lore entity", evidence=[transcript if isinstance(transcript, str) else "title"])
    has_content_type = contains_any(categories, CONTENT_TYPE_MARKERS)
    production = contains_any(combined, PRODUCTION_MARKERS)
    if production and not policy["include_production"] and not has_content_type:
        return decision("excluded", "production_metadata", "production, staff, cast, dubbing, or localization metadata is outside the default world-content scope", evidence=[production])
    for pattern in INDEX_TITLE_PATTERNS:
        if pattern.search(title):
            return decision("index_only", "index_or_navigation", "list/index page is harvested for links but is not a standalone world entity", evidence=[pattern.pattern])
    index_marker = contains_any(combined, INDEX_CATEGORY_MARKERS) or contains_any(templates, INDEX_TEMPLATE_MARKERS)
    if index_marker:
        return decision("index_only", "index_or_navigation", "navigation/index page is harvested for links but is not a standalone world entity", evidence=[index_marker])
    media = contains_any(categories, MEDIA_MARKERS)
    if media and not policy["include_media"]:
        return decision("reference_only", "optional_media", "media page is retained as a research source but excluded from the default entity inventory", evidence=[media])
    if isinstance(length, int) and length < policy["minimum_content_bytes"]:
        return decision("excluded", "empty_or_blank_page", "page body is empty or below the configured minimum content length")
    return decision("content", None, "page is a candidate world-content entity", quality_flag=quality_flag)


def classify_fetch(fetch: dict[str, Any], source_url: str, policy_value: Any = None) -> dict[str, Any]:
    record = {
        "url": source_url,
        "requested_title": fetch.get("requested_title") or title_from_url(source_url),
        "title": fetch.get("title") or title_from_url(source_url),
        "ns": 0,
        "length": len(str(fetch.get("wikitext") or fetch.get("rendered_html") or "").encode("utf-8")),
        "categories": fetch.get("categories") if isinstance(fetch.get("categories"), list) else [],
        "templates": fetch.get("templates") if isinstance(fetch.get("templates"), list) else [],
        "pageprops": fetch.get("pageprops") if isinstance(fetch.get("pageprops"), dict) else {},
    }
    requested = str(record["requested_title"]).strip()
    canonical = str(record["title"]).strip()
    if requested and canonical and requested.casefold() != canonical.casefold():
        record["redirect_from"] = requested
        record["canonical_url"] = article_url(source_url, canonical)
    return classify_metadata(record, policy_value)


def request_json(url: str, timeout: float) -> dict[str, Any]:
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT, "Accept": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as response:
        payload = json.loads(response.read().decode("utf-8"))
    if not isinstance(payload, dict):
        raise WorldBuilderError("MediaWiki metadata response is not a JSON object")
    if isinstance(payload.get("error"), dict):
        raise WorldBuilderError(str(payload["error"].get("info") or payload["error"].get("code") or "MediaWiki API error"))
    return payload


def add_params(url: str, params: dict[str, Any]) -> str:
    parsed = urllib.parse.urlsplit(url)
    query = urllib.parse.parse_qsl(parsed.query, keep_blank_values=True)
    query.extend((key, str(value)) for key, value in params.items() if value is not None)
    return urllib.parse.urlunsplit((parsed.scheme, parsed.netloc, parsed.path, urllib.parse.urlencode(query), ""))


def chunks(values: list[str], size: int) -> Iterable[list[str]]:
    for index in range(0, len(values), size):
        yield values[index:index + size]


def query_metadata_chunk(api_url: str, titles: list[str], timeout: float) -> tuple[dict[str, dict[str, Any]], dict[str, str]]:
    continuation: dict[str, Any] = {}
    pages_by_title: dict[str, dict[str, Any]] = {}
    alias_to_target: dict[str, str] = {}
    normalized: dict[str, str] = {}
    while True:
        params: dict[str, Any] = {
            "action": "query", "prop": "info|pageprops|categories|templates",
            "titles": "|".join(titles), "redirects": 1, "inprop": "url",
            "cllimit": "max", "tllimit": "max", "format": "json", "formatversion": 2,
        }
        params.update(continuation)
        payload = request_json(add_params(api_url, params), timeout)
        query = payload.get("query") if isinstance(payload.get("query"), dict) else {}
        for item in query.get("normalized", []) if isinstance(query.get("normalized"), list) else []:
            if isinstance(item, dict) and isinstance(item.get("from"), str) and isinstance(item.get("to"), str):
                normalized[item["from"]] = item["to"]
        for item in query.get("redirects", []) if isinstance(query.get("redirects"), list) else []:
            if isinstance(item, dict) and isinstance(item.get("from"), str) and isinstance(item.get("to"), str):
                alias_to_target[item["from"]] = item["to"]
        pages = query.get("pages") if isinstance(query.get("pages"), list) else []
        for page in pages:
            if not isinstance(page, dict) or not isinstance(page.get("title"), str):
                continue
            key = page["title"].casefold()
            current = pages_by_title.setdefault(key, {})
            for name, value in page.items():
                if name in {"categories", "templates"} and isinstance(value, list):
                    existing = current.setdefault(name, [])
                    seen = {json.dumps(row, sort_keys=True, ensure_ascii=False) for row in existing}
                    for row in value:
                        token = json.dumps(row, sort_keys=True, ensure_ascii=False)
                        if token not in seen:
                            existing.append(row); seen.add(token)
                elif name == "pageprops" and isinstance(value, dict):
                    current.setdefault("pageprops", {}).update(value)
                else:
                    current[name] = value
        continuation = payload.get("continue") if isinstance(payload.get("continue"), dict) else {}
        if not continuation:
            break
    for alias, target in list(alias_to_target.items()):
        alias_to_target[normalized.get(alias, alias)] = normalized.get(target, target)
    return pages_by_title, alias_to_target


def query_links(api_url: str, titles: list[str], timeout: float) -> dict[str, list[str]]:
    continuation: dict[str, Any] = {}
    result: dict[str, list[str]] = {}
    while True:
        params: dict[str, Any] = {
            "action": "query", "prop": "links", "titles": "|".join(titles),
            "plnamespace": 0, "pllimit": "max", "format": "json", "formatversion": 2,
        }
        params.update(continuation)
        payload = request_json(add_params(api_url, params), timeout)
        query = payload.get("query") if isinstance(payload.get("query"), dict) else {}
        for page in query.get("pages", []) if isinstance(query.get("pages"), list) else []:
            if not isinstance(page, dict) or not isinstance(page.get("title"), str):
                continue
            values = result.setdefault(page["title"].casefold(), [])
            for link in page.get("links", []) if isinstance(page.get("links"), list) else []:
                if not isinstance(link, dict) or link.get("ns") not in (None, 0):
                    continue
                title = link.get("title")
                if isinstance(title, str) and title.strip() and title not in values:
                    values.append(title.strip())
        continuation = payload.get("continue") if isinstance(payload.get("continue"), dict) else {}
        if not continuation:
            break
    return result


def prefilter_urls(*, api_url: str, base_url: str, urls: list[str], timeout: float = 20.0, batch_size: int = 40, policy_value: Any = None) -> dict[str, Any]:
    policy = normalize_policy(policy_value)
    batch_size = max(1, min(50, int(batch_size)))
    known_urls = list(dict.fromkeys(url for url in urls if isinstance(url, str) and url.strip()))
    records: dict[str, dict[str, Any]] = {}
    pending = list(known_urls)
    harvested_urls: list[str] = []
    aliases: list[dict[str, str]] = []

    for round_number in range(policy["maximum_harvest_rounds"] + 1):
        if not pending:
            break
        titles = [title_from_url(url) for url in pending]
        metadata: dict[str, dict[str, Any]] = {}
        redirects: dict[str, str] = {}
        for title_chunk in chunks(titles, batch_size):
            pages, alias_map = query_metadata_chunk(api_url, title_chunk, timeout)
            metadata.update(pages); redirects.update(alias_map)
        url_by_title = {title_from_url(url).casefold(): url for url in pending}
        index_titles: list[str] = []
        for requested_title in titles:
            requested_url = url_by_title.get(requested_title.casefold()) or article_url(base_url, requested_title)
            normalized_title = requested_title
            target_title = redirects.get(normalized_title, normalized_title)
            page = dict(metadata.get(target_title.casefold()) or metadata.get(normalized_title.casefold()) or {})
            canonical_title = str(page.get("title") or target_title).strip()
            canonical_url = article_url(base_url, canonical_title) if canonical_title else requested_url
            record = {
                "url": requested_url,
                "requested_title": requested_title,
                "title": canonical_title or requested_title,
                "canonical_url": canonical_url,
                "pageid": page.get("pageid"), "ns": page.get("ns"), "length": page.get("length"),
                "missing": page.get("missing") is True,
                "pageprops": page.get("pageprops") if isinstance(page.get("pageprops"), dict) else {},
                "categories": page.get("categories") if isinstance(page.get("categories"), list) else [],
                "templates": page.get("templates") if isinstance(page.get("templates"), list) else [],
                "prefilter_round": round_number,
            }
            if target_title.casefold() != requested_title.casefold():
                record["redirect_from"] = requested_title
                aliases.append({"alias": requested_title, "alias_url": requested_url, "target": canonical_title, "canonical_url": canonical_url})
            record.update(classify_metadata(record, policy))
            records[requested_url] = record
            if record["classification"] == "index_only":
                index_titles.append(canonical_title)
            if record["classification"] == "alias_only" and canonical_url != requested_url:
                # Redirect aliases are accounted cheaply, but the canonical target
                # must still enter the candidate corpus even when no enumerator
                # listed it separately. The API already returned its metadata, so
                # classify it without another request.
                canonical_record = {
                    "url": canonical_url,
                    "requested_title": canonical_title,
                    "title": canonical_title,
                    "canonical_url": canonical_url,
                    "pageid": page.get("pageid"), "ns": page.get("ns"), "length": page.get("length"),
                    "missing": page.get("missing") is True,
                    "pageprops": page.get("pageprops") if isinstance(page.get("pageprops"), dict) else {},
                    "categories": page.get("categories") if isinstance(page.get("categories"), list) else [],
                    "templates": page.get("templates") if isinstance(page.get("templates"), list) else [],
                    "prefilter_round": round_number,
                    "discovered_via": "redirect_target",
                }
                canonical_record.update(classify_metadata(canonical_record, policy))
                records.setdefault(canonical_url, canonical_record)
                if canonical_url not in known_urls and canonical_url not in harvested_urls:
                    known_urls.append(canonical_url)
                    harvested_urls.append(canonical_url)
                if canonical_record["classification"] == "index_only":
                    index_titles.append(canonical_title)
        if not policy["harvest_index_links"] or not index_titles or round_number >= policy["maximum_harvest_rounds"]:
            break
        newly_harvested: list[str] = []
        for title_chunk in chunks(list(dict.fromkeys(index_titles)), max(1, min(20, batch_size))):
            links = query_links(api_url, title_chunk, timeout)
            for values in links.values():
                for title in values:
                    url = article_url(base_url, title)
                    if url not in records and url not in known_urls and url not in newly_harvested:
                        newly_harvested.append(url)
                        if len(harvested_urls) + len(newly_harvested) >= policy["maximum_harvest_urls"]:
                            break
                if len(harvested_urls) + len(newly_harvested) >= policy["maximum_harvest_urls"]:
                    break
            if len(harvested_urls) + len(newly_harvested) >= policy["maximum_harvest_urls"]:
                break
        harvested_urls.extend(newly_harvested)
        known_urls.extend(newly_harvested)
        pending = newly_harvested

    rows = [records[url] for url in sorted(records)]
    worker_urls = [row["url"] for row in rows if row["classification"] == "content"]
    accounted = [row for row in rows if row["classification"] != "content"]
    counts: dict[str, int] = {}
    code_counts: dict[str, int] = {}
    for row in rows:
        key = str(row["classification"])
        counts[key] = counts.get(key, 0) + 1
        if row["classification"] == "excluded" and row.get("code"):
            code_counts[str(row["code"])] = code_counts.get(str(row["code"]), 0) + 1

    # A filter that drops most of a wiki is far more likely to be misclassifying than
    # to have found a wiki that is mostly junk. The cleanup-tag bug removed 79 primary
    # articles and reported nothing; the counts were in the output but nothing read them.
    total = len(rows) or 1
    content_share = len(worker_urls) / total
    review_flags: list[str] = []
    if content_share < 0.25 and total >= 40:
        review_flags.append(
            f"only {len(worker_urls)} of {total} pages ({content_share:.0%}) classified as content; "
            "confirm the dominant exclusion reasons are correct before dispatching workers"
        )
    for code, count in sorted(code_counts.items(), key=lambda kv: -kv[1]):
        if count / total >= 0.15 and code not in {"broken_redirect", "alias_only"}:
            review_flags.append(
                f"{code} accounts for {count} of {total} pages ({count / total:.0%}); "
                "spot-check a few before accepting the split"
            )
    flagged_content = [row["url"] for row in rows
                       if row["classification"] == "content" and row.get("quality_flag")]
    return {
        "review_flags": review_flags,
        "quality_flagged_content": flagged_content[:50],
        "quality_flagged_content_count": len(flagged_content),
        "exclusion_code_counts": code_counts,
        "kind": "worldbuilder-discovery-page-filter",
        "filter_version": PAGE_FILTER_VERSION,
        "status": "complete",
        "policy": policy,
        "input_url_count": len(urls),
        "input_url_sha256": stable_hash(sorted(set(urls))),
        "record_count": len(rows),
        "records": rows,
        "worker_urls": worker_urls,
        "accounted_without_worker": accounted,
        "reference_only_urls": [row["url"] for row in rows if row["classification"] == "reference_only"],
        "index_only_urls": [row["url"] for row in rows if row["classification"] == "index_only"],
        "excluded_urls": [row["url"] for row in rows if row["classification"] == "excluded"],
        "alias_map": aliases,
        "harvested_urls": harvested_urls,
        "classification_counts": counts,
        "estimated_worker_reduction_ratio": round(len(accounted) / max(1, len(rows)), 6),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--api-url")
    parser.add_argument("--base-url")
    parser.add_argument("--urls-json", help="JSON file containing a list or an object with urls[]")
    parser.add_argument("--fetch-json", help="Classify one wiki_fetch.py JSON record without reading the full page into model context")
    parser.add_argument("--source-url", help="Canonical source URL for --fetch-json")
    parser.add_argument("--assignment", help="Assignment JSON supplying fetch_policy.content_filter_policy")
    parser.add_argument("--output")
    parser.add_argument("--include-production", action="store_true")
    parser.add_argument("--exclude-media", action="store_true")
    parser.add_argument("--timeout", type=float, default=20.0)
    parser.add_argument("--batch-size", type=int, default=40)
    args = parser.parse_args()
    try:
        if args.fetch_json:
            if not args.source_url:
                raise WorldBuilderError("--fetch-json requires --source-url")
            fetched = load_json(Path(args.fetch_json).resolve())
            if not isinstance(fetched, dict):
                raise WorldBuilderError("--fetch-json must contain one JSON object")
            policy: Any = None
            if args.assignment:
                assignment = load_json(Path(args.assignment).resolve())
                fetch_policy = assignment.get("fetch_policy") if isinstance(assignment, dict) else None
                if isinstance(fetch_policy, dict):
                    policy = fetch_policy.get("content_filter_policy")
            result = classify_fetch(fetched, args.source_url, policy)
            if args.output:
                atomic_write_json(Path(args.output).resolve(), result)
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0
        if not args.urls_json or not args.api_url or not args.base_url or not args.output:
            raise WorldBuilderError("batch prefilter mode requires --api-url, --base-url, --urls-json, and --output")
        value = load_json(Path(args.urls_json).resolve())
        urls = value.get("urls") if isinstance(value, dict) else value
        if not isinstance(urls, list):
            raise WorldBuilderError("--urls-json must contain a list or an object with urls[]")
        policy = default_policy()
        policy["include_production"] = args.include_production
        policy["include_media"] = not args.exclude_media
        result = prefilter_urls(api_url=args.api_url, base_url=args.base_url, urls=urls, timeout=args.timeout, batch_size=args.batch_size, policy_value=policy)
        atomic_write_json(Path(args.output).resolve(), result)
        print(json.dumps({"status": "complete", "output": str(Path(args.output).resolve()), "counts": result["classification_counts"], "worker_urls": len(result["worker_urls"])}, indent=2))
        return 0
    except (WorldBuilderError, OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
