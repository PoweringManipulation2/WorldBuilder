#!/usr/bin/env python3
"""World index: a rendered, non-recursive roster of what the world contains.

The index exists because SillyTavern only inserts an entry the chat text
already triggered. Nothing tells the model that an entry it has never seen
exists, so a name that never appears in chat is unreachable forever. A
constant roster of canonical subject names puts those names in front of the
model; the model writes one; the real entry arms on the *next* turn from the
ordinary depth buffer. The index therefore works through model output, not
through recursion, which is why it must carry ``prevent_recursion: true``;
an index whose content fed the recurse buffer would arm every entry it names
on every single turn, which is the opposite of selective retrieval.

Consequences that the rest of this module enforces:

* The index is **rendered from the manifest**, never authored by a generation
  worker. Names must equal real activation keys after case folding or the
  roster is decoration; rendering from the one authority (DR-029) is the only
  way to guarantee that, and the frozen terminology dictionary (DR-106)
  supplies the canonical spelling.
* The index declares **no** ``activation.emits`` and owns no graph edges. Its
  recursion role is ``blocked``, which DR-122 already requires to resolve
  ``prevent_recursion: true``.
* The index is constant, so it costs permanent context on every turn forever.
  It is budgeted against the constant meter, never against corpus size
  (DR-067).
* Multi-era builds carry **one index per era**, not one per build. Each is
  gated on its own era token at cascade level 1 and lists only what exists in
  that era, so the roster itself can never name a subject from outside the
  active timeframe. The era root keeps the token and the negative-state guards;
  the index keeps the roster. Splitting them is what lets the index prevent
  recursion while the token still reaches the cascade.

See references/lorebook-architecture.md and DR-128.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any, Iterable

from wb_common import WorldBuilderError, atomic_write_json, entry_uid, load_json

CONTRACT = "worldbuilder-world-index-v1"
LAYER = "world_index"
KIND = "worldbuilder-world-index-report"
REPORT_VERSION = 1

# Share of the frozen profile's constant meter the index may occupy. The
# index is navigation; the root's laws are the thing it must never crowd out,
# so the sub-cap is deliberately well under half of the constant allowance.
INDEX_TARGET_SHARE = 0.30
INDEX_HARD_SHARE = 0.45

# Roster groups, in render order. Keyed by the naming prefix an entry's layer
# resolves to, so the roster's grouping and the book's visible labels cannot
# drift apart.
GROUP_ORDER: tuple[tuple[str, str], ...] = (
    ("CHARACTER", "PEOPLE"),
    ("FACTION", "FACTIONS"),
    ("ORGANIZATION", "FACTIONS"),
    ("LOCATION", "PLACES"),
    ("SPECIES", "PEOPLES AND KINDS"),
    ("EVENT", "EVENTS"),
    ("EPISODE", "EVENTS"),
    ("ITEM", "THINGS"),
    ("ABILITY", "POWERS"),
    ("SYSTEM", "SYSTEMS"),
    ("CONCEPT", "CONCEPTS"),
    ("RELATIONSHIP", "TIES"),
)

# Layers that never earn a roster line: the index cannot list itself, the
# root's laws are already permanent, and era contexts are the era routing
# surface rather than a subject.
EXCLUDED_LAYERS = {"world_index", "world_core", "world_invariants", "era_context",
                   "scene_reminder", "correction", "dialogue_example", "outlet_module", "anchor"}

HEADER = "THE WORLD CONTAINS"
GLOSS_MAX_WORDS = 6
_GLOSS_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9 ,'’\-]*$")
# Catalog voice, forbidden by DR-127: the roster names the world, it never
# addresses or advertises to a reader.
_READER_VOICE_RE = re.compile(
    r"\b(you|your|yours|this lorebook|this world ?book|this card|this entry|entries|"
    r"contains? \d|lorebook|world ?book|includes the following|read more|see also)\b",
    re.IGNORECASE,
)


def emit_dict(entry: dict[str, Any]) -> dict[str, Any]:
    value = entry.get("emit")
    return value if isinstance(value, dict) else {}


def _logic(emit: dict[str, Any]) -> Any:
    if "selectiveLogic" in emit:
        return emit["selectiveLogic"]
    extensions = emit.get("extensions")
    if isinstance(extensions, dict) and "selective_logic" in extensions:
        return extensions["selective_logic"]
    return emit.get("selective_logic")


def _entry_arch(entry: dict[str, Any]) -> dict[str, Any]:
    value = entry.get("architecture")
    return value if isinstance(value, dict) else {}


def _layer(entry: dict[str, Any]) -> str:
    return str(_entry_arch(entry).get("layer") or "").strip().casefold().replace("-", "_").replace(" ", "_")


def _prefix_for(entry: dict[str, Any]) -> str:
    """Resolve an entry's naming prefix the same way entry_naming does.

    Imported lazily and defensively: this module is staged into worker kits
    for read-only rendering checks, where entry_naming is not present.
    """
    layer = _layer(entry)
    try:  # pragma: no cover - exercised by the parent-side path
        from entry_naming import PREFIX_BY_LAYER

        mapping = PREFIX_BY_LAYER
    except ImportError:  # pragma: no cover - worker-kit path
        mapping = {}
    if layer in mapping:
        return str(mapping[layer])
    etype = str(entry.get("type") or "").strip().casefold()
    fallback = {
        "character": "CHARACTER", "location": "LOCATION", "faction": "FACTION",
        "organization": "ORGANIZATION", "species": "SPECIES", "event": "EVENT",
        "episode": "EPISODE", "object": "ITEM", "item": "ITEM", "ability": "ABILITY",
        "system": "SYSTEM", "concept": "CONCEPT", "relationship": "RELATIONSHIP",
    }
    return fallback.get(etype, "CONCEPT")


def _primary_keys(entry: dict[str, Any]) -> list[str]:
    emit = entry.get("emit")
    emit = emit if isinstance(emit, dict) else {}
    keys = emit.get("keys", emit.get("key", []))
    return [str(item).strip() for item in keys if str(item).strip()] if isinstance(keys, list) else []


def _canonical_name(entry: dict[str, Any], dictionary: dict[str, Any] | None) -> str:
    """The name the roster prints: canonical_name, else the planning name,
    resolved through the frozen terminology dictionary when one is bound."""
    name = str(entry.get("canonical_name") or entry.get("name") or "").strip()
    if not dictionary:
        return name
    terms = dictionary.get("terms")
    if isinstance(terms, dict):
        record = terms.get(name.casefold()) or terms.get(name)
        if isinstance(record, dict) and str(record.get("canonical") or "").strip():
            return str(record["canonical"]).strip()
    return name


def _gloss(entry: dict[str, Any]) -> str:
    value = str(_entry_arch(entry).get("index_gloss") or "").strip()
    if not value:
        return ""
    if len(value.split()) > GLOSS_MAX_WORDS:
        raise WorldBuilderError(
            f"entry {entry_uid(entry, strict=False)}'s architecture.index_gloss is {len(value.split())} words; "
            f"the roster allows at most {GLOSS_MAX_WORDS}; a gloss is an identifier, not a summary"
        )
    if not _GLOSS_RE.match(value):
        raise WorldBuilderError(
            f"entry {entry_uid(entry, strict=False)}'s architecture.index_gloss contains punctuation the roster does not carry: {value!r}"
        )
    return value


def _era_ids(entry: dict[str, Any]) -> list[str]:
    value = _entry_arch(entry).get("era_ids")
    return [str(item) for item in value] if isinstance(value, list) else []


def eligible(entry: dict[str, Any], *, era_mode: str, era_id: str | None = None) -> bool:
    """Whether an entry earns a roster line.

    Opting out is explicit (``architecture.index_member: false``) so that a
    book's roster is complete by construction and a deliberate omission is
    visible in the manifest rather than implied by absence.
    """
    if _layer(entry) in EXCLUDED_LAYERS:
        return False
    if _entry_arch(entry).get("index_member") is False:
        return False
    if not _primary_keys(entry):
        # A roster line for a keyless entry cannot be acted on: writing the
        # name would never arm anything.
        return False
    if era_mode == "multi":
        era_ids = _era_ids(entry)
        # An era-scoped subject belongs only to its own era's roster. A subject
        # with no era scope exists in every era, so it belongs to all of them.
        if era_ids and (era_id is None or era_id not in era_ids):
            return False
    return True


def collect_members(
    entries: Iterable[dict[str, Any]], *, era_mode: str, era_id: str | None = None
) -> list[dict[str, Any]]:
    members: list[dict[str, Any]] = []
    for entry in entries:
        if not isinstance(entry, dict) or not eligible(entry, era_mode=era_mode, era_id=era_id):
            continue
        members.append(entry)
    return members


def render(
    entries: Iterable[dict[str, Any]],
    *,
    era_mode: str = "single",
    era_id: str | None = None,
    dictionary: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Render the roster deterministically from the manifest."""
    members = collect_members(entries, era_mode=era_mode, era_id=era_id)
    grouped: dict[str, list[tuple[str, str, str]]] = {}
    seen: dict[str, str] = {}
    for entry in members:
        name = _canonical_name(entry, dictionary)
        if not name:
            raise WorldBuilderError(f"entry {entry_uid(entry, strict=False)} is an index member with no name to print")
        keys = _primary_keys(entry)
        folded = {key.casefold() for key in keys}
        if name.casefold() not in folded:
            raise WorldBuilderError(
                f"entry {entry_uid(entry, strict=False)}'s index name {name!r} is not one of its own primary keys {keys}; "
                "a roster name that is not a key can never arm the entry it advertises. "
                "Add the canonical name as a primary key or set architecture.index_member false."
            )
        previous = seen.get(name.casefold())
        if previous is not None and previous != entry_uid(entry, strict=False):
            raise WorldBuilderError(
                f"index name {name!r} is claimed by both uid {previous} and uid {entry_uid(entry, strict=False)}; "
                "one canonical name cannot advertise two entries"
            )
        seen[name.casefold()] = entry_uid(entry, strict=False)
        heading = dict(GROUP_ORDER).get(_prefix_for(entry), "CONCEPTS")
        grouped.setdefault(heading, []).append((name, _gloss(entry), entry_uid(entry, strict=False)))

    lines: list[str] = [HEADER, ""]
    ordered_headings: list[str] = []
    for _prefix, heading in GROUP_ORDER:
        if heading in grouped and heading not in ordered_headings:
            ordered_headings.append(heading)
    for heading in ordered_headings:
        rows = sorted(grouped[heading], key=lambda row: row[0].casefold())
        rendered = [f"{name} ({gloss})" if gloss else name for name, gloss, _uid_value in rows]
        lines.append(f"{heading}: " + ", ".join(rendered))
    content = "\n".join(lines).rstrip() + "\n"
    return {
        "contract": CONTRACT,
        "content": content,
        "member_uids": [entry_uid(entry, strict=False) for entry in members],
        "member_count": len(members),
        "groups": {heading: len(grouped[heading]) for heading in ordered_headings},
        "era_mode": era_mode,
        "era_id": era_id,
    }


def index_budget(profile: dict[str, Any]) -> dict[str, int]:
    """Derive the index's sub-cap from the frozen profile's constant meter.

    No new profile field: the index competes with the root for exactly one
    permanent allowance, so it is sized from that allowance rather than given
    a second independent number that could disagree with it.
    """
    constant_target = profile.get("constant_target")
    constant_hard = profile.get("constant_hard")
    if not isinstance(constant_target, int) or not isinstance(constant_hard, int):
        raise WorldBuilderError("budget profile is missing constant_target/constant_hard; cannot size the world index")
    return {
        "constant_target": constant_target,
        "constant_hard": constant_hard,
        "index_target": int(round(constant_target * INDEX_TARGET_SHARE)),
        "index_hard": int(round(constant_hard * INDEX_HARD_SHARE)),
    }


def check_voice(content: str) -> list[str]:
    """DR-127: the roster names the world; it never addresses a reader."""
    return sorted({match.group(0).lower() for match in _READER_VOICE_RE.finditer(content)})


def validate_entry(entry: dict[str, Any], *, era_token: str | None = None) -> list[str]:
    """Structural rules an index entry must satisfy, independent of content.

    Two shapes. A single-era index is constant, because there is one timeframe
    and it is always the active one. An era index is gated on its own era token
    at cascade level 1: it must not be constant, or every era's roster would be
    in context at once and the book would name subjects from outside the active
    timeframe; the exact thing the era gate exists to prevent.
    """
    errors: list[str] = []
    activation = entry.get("activation") if isinstance(entry.get("activation"), dict) else {}
    emit = emit_dict(entry)
    extensions = emit.get("extensions") if isinstance(emit.get("extensions"), dict) else {}
    if era_token is not None:
        if emit.get("constant"):
            errors.append("an era index must not be constant; it is gated on its own era token")
        if activation.get("strategy") != "keyword":
            errors.append("an era index must use activation.strategy 'keyword'")
        if emit.get("selective") is not True or _logic(emit) != 3:
            errors.append("an era index must be selective with AND ALL logic on its era token")
        secondary = emit.get("secondary_keys", emit.get("keysecondary", []))
        if not isinstance(secondary, list) or era_token not in secondary:
            errors.append(f"an era index must carry its era token {era_token!r} in secondary keys")
        if extensions.get("delay_until_recursion") is not True:
            errors.append("an era index must delay until recursion; the token arrives from its era root")
    elif activation.get("strategy") != "constant":
        errors.append("the world index must use activation.strategy 'constant'; it is always present by design")
    if activation.get("recursion_role") != "blocked":
        errors.append("the world index must use activation.recursion_role 'blocked'; it owns no graph edges")
    if activation.get("emits"):
        errors.append(
            "the world index must declare no activation.emits: it reaches entries through the model's next "
            "message, not through the recurse buffer"
        )
    if era_token is None and emit.get("constant") is not True:
        errors.append("the world index must be emitted constant")
    if extensions.get("prevent_recursion") is not True:
        errors.append(
            "the world index must set prevent_recursion true, or its roster arms every entry it names on every turn"
        )
    if emit.get("vectorized"):
        errors.append("the world index cannot be vector-only or vectorized; it is a constant control entry")
    if emit.get("position") not in (None, "before_char"):
        errors.append("the world index must insert before character definitions")
    return errors


def validate(
    entries: list[dict[str, Any]],
    *,
    era_mode: str = "single",
    era_tokens: dict[str, str] | None = None,
    profile: dict[str, Any] | None = None,
    dictionary: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Validate a build's index entries against the manifest they describe.

    Single-era builds carry at most one index. Multi-era builds carry at most
    one per era, each scoped to exactly one era id and gated on that era's own
    token, so no roster can name a subject from outside the active timeframe.
    """
    era_tokens = era_tokens or {}
    index_entries = [entry for entry in entries if isinstance(entry, dict) and _layer(entry) == LAYER]
    others = [entry for entry in entries if _layer(entry) != LAYER]
    errors: list[str] = []
    warnings: list[str] = []
    rosters: list[dict[str, Any]] = []

    if era_mode == "multi":
        by_era: dict[str, list[str]] = {}
        for entry in index_entries:
            ids = _era_ids(entry)
            if len(ids) != 1:
                errors.append(
                    f"era index {entry_uid(entry, strict=False)} must own exactly one era_id, found {ids!r}: "
                    "an index that spans eras would name subjects outside the active timeframe"
                )
                continue
            by_era.setdefault(ids[0], []).append(entry_uid(entry, strict=False))
        for era_id, uids in sorted(by_era.items()):
            if len(uids) > 1:
                raise WorldBuilderError(
                    f"era {era_id} may carry at most one index, found {len(uids)}: " + ", ".join(uids)
                )
        unknown = sorted(set(by_era) - set(era_tokens)) if era_tokens else []
        if unknown:
            errors.append("era index declares unknown era ids: " + ", ".join(unknown))
    elif len(index_entries) > 1:
        raise WorldBuilderError(
            f"a single-era build may carry at most one {LAYER} entry, found {len(index_entries)}: "
            + ", ".join(entry_uid(row, strict=False) for row in index_entries)
        )

    if not index_entries:
        return {"kind": KIND, "report_version": REPORT_VERSION, "contract": CONTRACT,
                "status": "not_present", "errors": [], "warnings": []}

    for entry in index_entries:
        ids = _era_ids(entry)
        era_id = ids[0] if (era_mode == "multi" and len(ids) == 1) else None
        token = era_tokens.get(era_id) if era_id else None
        if era_mode == "multi" and era_id and era_tokens and token is None:
            continue
        errors.extend(
            f"{entry_uid(entry, strict=False)}: {problem}" for problem in validate_entry(entry, era_token=token)
        )
        rendered = render(
            [row for row in others], era_mode=era_mode, era_id=era_id, dictionary=dictionary
        )
        actual = str(entry.get("content") or "")
        if actual.strip() and actual.strip() != rendered["content"].strip():
            errors.append(
                f"{entry_uid(entry, strict=False)}: index content does not match the roster rendered from the current "
                "manifest; re-render it with world_index.py render rather than editing it by hand"
            )
        voice = check_voice(rendered["content"])
        if voice:
            errors.append(f"{entry_uid(entry, strict=False)}: reader-facing catalog voice (DR-127): " + ", ".join(voice))
        row = {
            "uid": entry_uid(entry, strict=False),
            "era_id": era_id,
            "member_count": rendered["member_count"],
            "member_uids": rendered["member_uids"],
            "groups": rendered["groups"],
        }
        if profile:
            budget = index_budget(profile)
            try:
                from budget_contract import estimate_tokens
            except ImportError:  # pragma: no cover - worker-kit path
                def estimate_tokens(value: Any) -> int:  # type: ignore[misc]
                    return int((len(str(value).encode("utf-8")) + 3) // 4)
            measured = estimate_tokens(rendered["content"])
            budget["index_tokens"] = measured
            row["budget"] = budget
            if measured > budget["index_hard"]:
                errors.append(
                    f"{entry_uid(entry, strict=False)}: index costs {measured} permanent tokens against a hard sub-cap of "
                    f"{budget['index_hard']} ({rendered['member_count']} roster names). This is a split "
                    "signal, not a trim instruction: set architecture.index_member false on the entries a "
                    "reader would never name first, or raise the build's context window."
                )
            elif measured > budget["index_target"]:
                warnings.append(
                    f"{entry_uid(entry, strict=False)}: index costs {measured} permanent tokens against a target of "
                    f"{budget['index_target']}"
                )
        rosters.append(row)

    report: dict[str, Any] = {
        "kind": KIND,
        "report_version": REPORT_VERSION,
        "contract": CONTRACT,
        "status": "failed" if errors else "ok",
        "era_mode": era_mode,
        "indexes": rosters,
        "member_count": sum(row["member_count"] for row in rosters),
        "errors": errors,
        "warnings": warnings,
    }
    return report


def _load_entries(manifest: Any) -> list[dict[str, Any]]:
    if isinstance(manifest, dict) and isinstance(manifest.get("entries"), list):
        return [row for row in manifest["entries"] if isinstance(row, dict)]
    raise WorldBuilderError("manifest has no 'entries' list to build a world index from")


def _era_mode(manifest: Any, override: str | None) -> str:
    if override:
        return override
    architecture = manifest.get("architecture") if isinstance(manifest, dict) else None
    era = architecture.get("era") if isinstance(architecture, dict) else None
    mode = era.get("mode") if isinstance(era, dict) else None
    return "multi" if mode == "multi" else "single"


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = parser.add_subparsers(dest="command", required=True)
    for name in ("render", "validate"):
        child = sub.add_parser(name)
        child.add_argument("--manifest", required=True)
        child.add_argument("--era-mode", choices=["single", "multi"])
        child.add_argument("--era-id", help="render or validate one era's index")
        child.add_argument("--era-root-plan", help="era-root plan supplying era ids and tokens")
        child.add_argument("--terminology-dictionary")
        child.add_argument("--budget-plan")
        child.add_argument("--output")
    args = parser.parse_args()
    try:
        manifest = load_json(Path(args.manifest))
        entries = _load_entries(manifest)
        era_mode = _era_mode(manifest, args.era_mode)
        dictionary = load_json(Path(args.terminology_dictionary)) if args.terminology_dictionary else None
        profile = None
        if args.budget_plan:
            plan = load_json(Path(args.budget_plan))
            profile = plan.get("profile") if isinstance(plan, dict) else None
        era_tokens: dict[str, str] = {}
        if args.era_root_plan:
            plan = load_json(Path(args.era_root_plan))
            for era in (plan.get("eras") or []) if isinstance(plan, dict) else []:
                if isinstance(era, dict) and era.get("id") and era.get("token"):
                    era_tokens[str(era["id"])] = str(era["token"])
        if args.command == "render":
            index_uid = next(
                (entry_uid(row, strict=False) for row in entries if _layer(row) == LAYER
                 and (args.era_id is None or args.era_id in _era_ids(row))),
                None,
            )
            result = render([row for row in entries if _layer(row) != LAYER],
                            era_mode=era_mode, era_id=args.era_id, dictionary=dictionary)
            result["uid"] = index_uid
            if args.output:
                atomic_write_json(Path(args.output), result)
            sys.stdout.write(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
            return 0
        report = validate(entries, era_mode=era_mode, era_tokens=era_tokens,
                          profile=profile, dictionary=dictionary)
        if args.output:
            atomic_write_json(Path(args.output), report)
        sys.stdout.write(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
        return 0 if report.get("status") in {"ok", "not_present"} else 2
    except (WorldBuilderError, OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
