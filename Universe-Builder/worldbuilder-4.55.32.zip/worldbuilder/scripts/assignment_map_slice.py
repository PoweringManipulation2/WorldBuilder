#!/usr/bin/env python3
"""Create a generation-assignment activation-map slice for selected UIDs."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from activation_map_gate import build_assignment_slice
from wb_common import WorldBuilderError, atomic_write_json


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--build-state", required=True)
    parser.add_argument("--uids", nargs="+", required=True)
    parser.add_argument("--output", help="Optional JSON output path; stdout is always printed.")
    args = parser.parse_args()
    try:
        result = build_assignment_slice(args.build_state, args.uids)
        if args.output:
            atomic_write_json(Path(args.output).expanduser().resolve(), result)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (WorldBuilderError, OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
