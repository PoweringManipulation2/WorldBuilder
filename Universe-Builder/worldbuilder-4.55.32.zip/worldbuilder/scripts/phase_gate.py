#!/usr/bin/env python3
"""Validate phase artifacts and append content-bound pipeline receipts.

New workflows pass ``--build-state``. Legacy ``--outputs``/``--scratchpad``
arguments remain available for migration, but do not provide the same lineage
assurance.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from evidence_gate import uid_key, validate_assignment_evidence
from audit_gate import validate_audit_run
from audit_gate import validate_saved_receipt

from discovery_contract import DISCOVERY_GATE_RECEIPT_VERSION, saturation_accepted
from entry_cycle_gate import ENTRY_CYCLE_RECEIPT_VERSION
from activation_map_gate import slice_dependency_hash

# Accept the version discovery_gate currently emits, plus older receipts still readable
# by this gate. Derived from the producer's constant so a bump cannot strand consumers:
# hardcoding 3 here while discovery_contract said 4 broke every known-property build.
SUPPORTED_DISCOVERY_RECEIPT_VERSIONS = frozenset({3, DISCOVERY_GATE_RECEIPT_VERSION})

from wb_common import (
    step_driver_pointer,
    WorldBuilderError,
    atomic_write_json,
    count_entries,
    canonical_entry_identity,
    discover_phase_files,
    load_build_state,
    iter_entries,
    load_json,
    preflight_report,
    requirement_rows,
    resolve_state_path,
    sha256_file,
    ensure_inside,
    phase_sort_key,
)
from pipeline_stage_gate import advance as advance_pipeline_stage

ARTIFACT_PREFIX = "WORLDBUILDER-ARTIFACT:"


def parse_artifact_header(path: Path) -> dict[str, Any]:
    text = path.read_text(encoding="utf-8", errors="replace")
    first = next((line.strip() for line in text.splitlines() if line.strip()), "")
    if not first.startswith(ARTIFACT_PREFIX):
        raise WorldBuilderError(f"{path.name} lacks the required {ARTIFACT_PREFIX} JSON header")
    try:
        header = json.loads(first[len(ARTIFACT_PREFIX):].strip())
    except json.JSONDecodeError as exc:
        raise WorldBuilderError(f"{path.name} has an invalid artifact header: {exc}") from exc
    if not isinstance(header, dict):
        raise WorldBuilderError(f"{path.name} artifact header must be an object")
    if len(text.strip()) <= len(first) + 20:
        raise WorldBuilderError(f"{path.name} has a header but no substantive body")
    return header



def require_discovery_lineage(paths: dict[str, Path], state: dict[str, Any], build_id: str) -> str | None:
    discovery = state.get("discovery")
    if not isinstance(discovery, dict) or not discovery.get("required"):
        return None
    receipt_path = paths.get("discovery_receipt")
    if receipt_path is None or not receipt_path.exists():
        raise WorldBuilderError("known-property build lacks a passed breadth-discovery receipt")
    receipt = load_json(receipt_path)
    if not isinstance(receipt, dict) or receipt.get("kind") != "breadth-discovery-gate":
        raise WorldBuilderError("discovery receipt is not a breadth-discovery-gate receipt")
    version = receipt.get("receipt_version")
    if version not in SUPPORTED_DISCOVERY_RECEIPT_VERSIONS:
        raise WorldBuilderError(
            f"discovery receipt version {version!r} is not supported here; this build of "
            f"phase_gate accepts {sorted(SUPPORTED_DISCOVERY_RECEIPT_VERSIONS)} and "
            f"discovery_gate currently emits {DISCOVERY_GATE_RECEIPT_VERSION}. "
            "Re-run discovery rather than editing the receipt."
        )
    if receipt.get("status") not in {"complete", "passed_with_exclusions"} or receipt.get("bounded_coverage_proven", receipt.get("completeness_proven")) is not True or not saturation_accepted(receipt):
        raise WorldBuilderError("discovery receipt does not prove bounded source-set coverage plus an accepted saturation path")
    metrics = receipt.get("metrics")
    if not isinstance(metrics, dict) or metrics.get("completeness", {}).get("passed") is not True or (metrics.get("saturation", {}).get("saturated") is not True and metrics.get("saturation", {}).get("effective_saturated") is not True):
        raise WorldBuilderError("discovery receipt metrics do not pass bounded-coverage/saturation gates")
    if receipt.get("build_id") != build_id:
        raise WorldBuilderError("discovery receipt belongs to another build")
    assignments = receipt.get("assignments")
    if not isinstance(assignments, list) or not assignments:
        raise WorldBuilderError("discovery receipt contains no completed assignments")
    root = receipt_path.parent.parent.parent.resolve()
    for row in assignments:
        if not isinstance(row, dict):
            raise WorldBuilderError("discovery receipt assignment row is invalid")
        for path_key, sha_key in (("assignment_path", "assignment_sha256"), ("output", "output_sha256")):
            value = row.get(path_key)
            if not isinstance(value, str) or not value:
                raise WorldBuilderError(f"discovery receipt row lacks {path_key}")
            target = (root / value).resolve()
            ensure_inside(target, root)
            if not target.exists() or sha256_file(target) != row.get(sha_key):
                raise WorldBuilderError(f"discovery receipt is stale at {value}")
    receipt_sha = sha256_file(receipt_path)
    manifest = load_json(paths["manifest"])
    if not isinstance(manifest, dict) or manifest.get("discovery_receipt_sha256") != receipt_sha:
        raise WorldBuilderError("manifest is not bound to the current breadth-discovery receipt")
    for key in ("build_list", "recursion_map"):
        header = parse_artifact_header(paths[key])
        if header.get("discovery_receipt_sha256") != receipt_sha:
            raise WorldBuilderError(f"{paths[key].name} is not bound to the current breadth-discovery receipt")
    return receipt_sha

def require_planning_lineage(root: Path, state: dict[str, Any], manifest_path: Path, manifest_sha: str) -> dict[str, Any]:
    """Require the current planning-gate receipt before generation proceeds."""
    receipt_path = resolve_state_path(root, state, "planning_receipt")
    if not receipt_path.exists():
        raise WorldBuilderError("planning gate receipt is missing; run planning_gate.py before generation")
    receipt = load_json(receipt_path)
    if not isinstance(receipt, dict) or receipt.get("kind") != "worldbuilder-planning-gate" or receipt.get("status") != "passed":
        raise WorldBuilderError("planning gate receipt has the wrong format or status")
    if receipt.get("build_id") != state.get("build_id"):
        raise WorldBuilderError("planning gate receipt belongs to another build")
    if receipt.get("manifest_sha256") != manifest_sha:
        raise WorldBuilderError("planning gate receipt is stale for the current manifest. The manifest changed after this binding was created. Sanctioned recovery: run pipeline_stage_gate.py --build-state <your build-state.json> --invalidate-from planning_validated, re-run planning_gate.py, and regenerate assignments; never edit or 'sync' the manifest with ad-hoc scripts or file-permission locks.")
    manifest_rel = receipt.get("manifest")
    if isinstance(manifest_rel, str):
        bound = (root / manifest_rel).resolve()
        ensure_inside(bound, root)
        if bound != manifest_path.resolve() or not bound.exists() or sha256_file(bound) != manifest_sha:
            raise WorldBuilderError("planning gate manifest binding is stale. The manifest changed after this binding was created. Sanctioned recovery: run pipeline_stage_gate.py --build-state <your build-state.json> --invalidate-from planning_validated, re-run planning_gate.py, and regenerate assignments; never edit or 'sync' the manifest with ad-hoc scripts or file-permission locks.")
    expected_receipt_sha = (state.get("lineage") or {}).get("planning_receipt_sha256") if isinstance(state.get("lineage"), dict) else None
    if isinstance(expected_receipt_sha, str) and expected_receipt_sha and sha256_file(receipt_path) != expected_receipt_sha:
        raise WorldBuilderError("planning gate receipt hash no longer matches build-state lineage")
    if int(receipt.get("receipt_version", 0) or 0) >= 2:
        bindings = (
            ("recursion_map", "activation_map_sha256"),
            ("field_registry", "field_registry_sha256"),
            ("default_profile", "default_profile_sha256"),
        )
        for path_key, hash_key in bindings:
            path = resolve_state_path(root, state, path_key)
            if not path.exists() or receipt.get(hash_key) != sha256_file(path):
                raise WorldBuilderError(f"planning gate {hash_key} binding is missing or stale")
        activation_receipt = resolve_state_path(root, state, "activation_map_receipt")
        if not activation_receipt.exists() or receipt.get("activation_map_receipt_sha256") != sha256_file(activation_receipt):
            raise WorldBuilderError("planning gate activation-map receipt binding is missing or stale")
        character_plan_sha = receipt.get("character_plan_sha256")
        if character_plan_sha is not None:
            character_plan = resolve_state_path(root, state, "character_plan")
            if not character_plan.exists() or sha256_file(character_plan) != character_plan_sha:
                raise WorldBuilderError("planning gate character-plan binding is missing or stale")
        placement_plan_sha = receipt.get("placement_plan_sha256")
        if placement_plan_sha is not None:
            placement_plan = resolve_state_path(root, state, "placement_plan")
            if not placement_plan.exists() or sha256_file(placement_plan) != placement_plan_sha:
                raise WorldBuilderError("planning gate placement-plan binding is missing or stale")
            placement_receipt = resolve_state_path(root, state, "placement_planning_receipt")
            if not placement_receipt.exists() or receipt.get("placement_receipt_sha256") != sha256_file(placement_receipt):
                raise WorldBuilderError("planning gate placement receipt binding is missing or stale")
        budget_plan_sha = receipt.get("budget_plan_sha256")
        if budget_plan_sha is not None:
            budget_plan = resolve_state_path(root, state, "budget_plan")
            if not budget_plan.exists() or sha256_file(budget_plan) != budget_plan_sha:
                raise WorldBuilderError("planning gate budget-plan binding is missing or stale")
            budget_receipt = resolve_state_path(root, state, "budget_planning_receipt")
            if not budget_receipt.exists() or receipt.get("budget_receipt_sha256") != sha256_file(budget_receipt):
                raise WorldBuilderError("planning gate budget receipt binding is missing or stale")
        dynamic_plan_sha = receipt.get("dynamic_state_plan_sha256")
        if dynamic_plan_sha is not None:
            dynamic_plan = resolve_state_path(root, state, "dynamic_state_plan")
            if not dynamic_plan.exists() or sha256_file(dynamic_plan) != dynamic_plan_sha:
                raise WorldBuilderError("planning gate dynamic-state plan binding is missing or stale")
            dynamic_receipt = resolve_state_path(root, state, "dynamic_state_planning_receipt")
            if not dynamic_receipt.exists() or receipt.get("dynamic_state_receipt_sha256") != sha256_file(dynamic_receipt):
                raise WorldBuilderError("planning gate dynamic-state receipt binding is missing or stale")
    return receipt


def require_pre_generation_audit(state_path: Path, root: Path, state: dict[str, Any]) -> str | None:
    audit = state.get("audit")
    if not isinstance(audit, dict) or not audit.get("pre_generation_required"):
        return None
    receipt_path = resolve_state_path(root, state, "pre_generation_audit_receipt")
    if not receipt_path.exists():
        raise WorldBuilderError("pre-generation audit receipt is missing; run audit_gate.py after all four audit lenses finish")
    stored = load_json(receipt_path)
    if not isinstance(stored, dict) or stored.get("kind") != "worldbuilder-audit-gate":
        raise WorldBuilderError("pre-generation audit receipt has the wrong format")
    current = validate_audit_run(state_path, "pre-generation", write_receipt=False)
    if stored != current:
        raise WorldBuilderError("pre-generation audit receipt is stale or does not match the four current auditor results")
    if stored.get("all_runtime_statuses_completed") is not True or stored.get("all_lenses_validated") is not True:
        raise WorldBuilderError("pre-generation audit did not prove four completed OpenClaw child runs")
    return sha256_file(receipt_path)


def phase_metadata(data: Any) -> dict[str, Any] | None:
    if isinstance(data, dict) and isinstance(data.get("_worldbuilder"), dict):
        return data["_worldbuilder"]
    return None


def append_receipt(path: Path, receipt: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8", newline="\n") as fh:
        fh.write(json.dumps(receipt, ensure_ascii=False, sort_keys=True) + "\n")


def load_receipts(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        return []
    receipts = []
    for line_no, raw in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        if not raw.strip():
            continue
        try:
            item = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise WorldBuilderError(f"receipt line {line_no} is invalid JSON: {exc}") from exc
        if not isinstance(item, dict):
            raise WorldBuilderError(f"receipt line {line_no} must be an object")
        receipts.append(item)
    return receipts


def require_build_files(paths: dict[str, Path], state: dict[str, Any], build_id: str) -> tuple[dict[str, str], str]:
    manifest = paths["manifest"]
    fingerprint = paths["build_id"]
    build_list = paths["build_list"]
    recursion_map = paths["recursion_map"]
    for path in (manifest, fingerprint, build_list, recursion_map):
        if not path.exists():
            raise WorldBuilderError(f"required artifact is missing: {path}")

    manifest_data = load_json(manifest)
    if not isinstance(manifest_data, dict):
        raise WorldBuilderError("manifest.json must be an object")
    if manifest_data.get("build_id") != build_id:
        raise WorldBuilderError("manifest build_id does not match build-state.json")
    if count_entries(manifest_data) <= 0:
        raise WorldBuilderError("manifest has no entries")
    manifest_sha = sha256_file(manifest)

    build_data = load_json(fingerprint)
    if not isinstance(build_data, dict) or build_data.get("build_id") != build_id:
        raise WorldBuilderError("build-id.json does not match build-state.json")
    if str(build_data.get("manifest_sha256", "")).lower() != manifest_sha:
        raise WorldBuilderError("build-id.json manifest_sha256 does not match manifest bytes")
    if build_data.get("entry_count") != count_entries(manifest_data):
        raise WorldBuilderError("build-id.json entry_count does not match manifest")

    hashes: dict[str, str] = {"manifest": manifest_sha, "build_id": sha256_file(fingerprint)}
    for kind, path in (("build_list", build_list), ("recursion_map", recursion_map)):
        header = parse_artifact_header(path)
        if header.get("build_id") != build_id:
            raise WorldBuilderError(f"{path.name} build_id does not match")
        if header.get("kind") != kind:
            raise WorldBuilderError(f"{path.name} header kind must be {kind!r}")
        if str(header.get("manifest_sha256", "")).lower() != manifest_sha:
            raise WorldBuilderError(f"{path.name} is not bound to the current manifest")
        hashes[kind] = sha256_file(path)
    return hashes, manifest_sha


def validate_phase_file(
    path: Path, build_id: str, manifest_sha: str, expected_number: int | None = None,
    *, root: Path | None = None, state: dict[str, Any] | None = None, assignments_dir: Path | None = None,
) -> dict[str, Any]:
    """root/state/assignments_dir are optional and, when omitted, this
    behaves exactly as before (an exact manifest_sha256 match is required).
    When provided (Batch 6, 6.2: pre-merge only; phase 1's pre-dispatch
    check is about freshness before any drift could exist and stays exact),
    a manifest_sha256 mismatch falls back to slice tolerance: this phase's
    bound assignment already carries per-UID entry_hashes (stamped at
    pre-dispatch); if every UID actually present in this phase still
    hash-matches the current manifest, the phase passes as
    slice_tolerated. Mirrors evidence_gate.verify_manifest_binding's exact
    vocabulary and failure message shape; this is the same tolerance
    decision, checked from the phase's side rather than the assignment's."""
    data = load_json(path)
    metadata = phase_metadata(data)
    if metadata is None:
        raise WorldBuilderError(f"{path.name} lacks _worldbuilder phase metadata")
    if metadata.get("build_id") != build_id:
        raise WorldBuilderError(f"{path.name} belongs to another build")
    declared_sha = str(metadata.get("manifest_sha256", "")).lower()
    if declared_sha == manifest_sha:
        metadata["phase_binding"] = "exact"
    else:
        if root is None or state is None or assignments_dir is None:
            raise WorldBuilderError(f"{path.name} is not bound to the current manifest")
        from wb_common import collect_uid_entries, entry_binding_hash
        match = _assignment_for_phase(root, assignments_dir, path)
        hashes = match[1].get("entry_hashes") if match else None
        if not isinstance(hashes, dict) or not hashes:
            # Same message shape assignments already use when they carry no
            # entry_hashes at all; fail closed, do not guess.
            raise WorldBuilderError(f"{path.name} is not bound to the current manifest")
        phase_uids = sorted({str(ref.entry.get("uid")) for ref in iter_entries(data) if ref.entry.get("uid") is not None})
        manifest = load_json(resolve_state_path(root, state, "manifest"))
        lookup = collect_uid_entries(manifest)
        changed = [
            uid for uid in phase_uids
            if lookup.get(uid) is None or entry_binding_hash(lookup[uid]) != hashes.get(uid)
        ]
        if changed:
            raise WorldBuilderError(
                f"{path.name} manifest changed for UIDs " + ", ".join(changed) + ". Only phases touching these UIDs "
                "need re-planning: correct the manifest through planning, re-run planning_gate.py, re-stamp with "
                "phase_gate.py --stage pre-dispatch, and re-dispatch just the affected workers. Phases whose slices "
                "are unchanged remain valid. (Full re-baseline via pipeline_stage_gate.py --invalidate-from "
                "planning_validated remains available; never edit or 'sync' the manifest with ad-hoc scripts.)"
            )
        metadata["phase_binding"] = "slice_tolerated"
    if expected_number is not None and metadata.get("phase") != expected_number:
        raise WorldBuilderError(f"{path.name} metadata phase is not {expected_number}")
    # Bare shells and entry wrappers are both allowed, but an empty object is not.
    if len(data) <= 1:
        raise WorldBuilderError(f"{path.name} contains metadata but no shell or entries")
    return data




def _relative_output_path(build_root: Path, assignment: dict[str, Any]) -> Path:
    value = assignment.get("output")
    if not isinstance(value, str) or not value.strip():
        raise WorldBuilderError("generation assignment output must be a non-empty relative path")
    raw = Path(value)
    if raw.is_absolute():
        raise WorldBuilderError("generation assignment output must be relative to the build root")
    resolved = (build_root / raw).resolve()
    ensure_inside(resolved, build_root)
    return resolved


def check_phase_one_completeness(phase_one: Path, phase_one_assignment: tuple[Path, dict[str, Any]] | None) -> None:
    """Real-world regression: a build once wrote a bare phase-1 shell, ran
    pre-dispatch (binding that incomplete content's hash into the
    receipt), then finished phase 1 for real afterward; the receipt
    stayed bound to the stale, pre-completion bytes, which only surfaced
    much later at delivery as a confusing "receipt hash mismatch"
    requiring a manual restamp. This catches it here, at the point it
    actually happens, using the phase's own assignment
    (map_slice.assigned_uids) as the authoritative "what phase 1 is
    supposed to contain", not a guessed count. A missing assignment or
    assigned_uids list is not itself an error here (older or
    differently-shaped assignments may not carry this field); the
    check simply does not apply when there is nothing authoritative to
    compare against.
    """
    if phase_one_assignment is None:
        return
    map_slice = phase_one_assignment[1].get("map_slice")
    assigned_uids = map_slice.get("assigned_uids") if isinstance(map_slice, dict) else None
    if not isinstance(assigned_uids, list) or not assigned_uids:
        return
    phase_one_data = load_json(phase_one)
    actual_uids = {
        str(ref.entry.get("uid")) for ref in iter_entries(phase_one_data)
        if ref.entry.get("uid") is not None
    }
    missing = [uid for uid in assigned_uids if str(uid) not in actual_uids]
    if missing:
        raise WorldBuilderError(
            f"phase 1 is missing entries for assigned UID(s) {missing}; it looks like a "
            "bare shell, not the completed phase. Finish writing every assigned entry into "
            f"{phase_one.name} BEFORE running pre-dispatch: binding pre-dispatch to an "
            "incomplete phase 1 now will make its receipt stale the moment you finish the "
            "content, and that mismatch will not surface until much later, at delivery, as a "
            "confusing 'receipt hash mismatch' requiring a manual restamp. Complete phase 1 "
            "first, then re-run this exact command."
        )


def _assignment_for_phase(build_root: Path, assignments_dir: Path, phase_path: Path) -> tuple[Path, dict[str, Any]] | None:
    matches: list[tuple[Path, dict[str, Any]]] = []
    for assignment_path in sorted(assignments_dir.glob("*.json")):
        assignment = load_json(assignment_path)
        if not isinstance(assignment, dict) or assignment.get("role") != "generation":
            continue
        if _relative_output_path(build_root, assignment) == phase_path.resolve():
            matches.append((assignment_path, assignment))
    if len(matches) > 1:
        raise WorldBuilderError(f"multiple generation assignments target {phase_path.name}")
    return matches[0] if matches else None


def validate_generation_evidence_lineage(
    *,
    state_path: Path,
    build_root: Path,
    state: dict[str, Any],
    phase_path: Path,
    phase_data: dict[str, Any],
    metadata: dict[str, Any],
    assignments_dir: Path,
    evidence_receipts_dir: Path,
) -> list[dict[str, Any]]:
    """Returns every overflow record (Batch 5, 5.8) found across this phase's
    bound entry-cycle receipt; callers aggregate these across all phases
    being merged to report "N entries had material scoped out" once, not per
    phase. An empty list is the normal case; most entries cut nothing."""
    phase_entries = list(iter_entries(phase_data))
    assignment_match = _assignment_for_phase(build_root, assignments_dir, phase_path)
    if not phase_entries and assignment_match is None:
        # A parent-authored shell-only phase is allowed. Any phase that emits
        # entries must be bound to a validated research assignment.
        return []
    if assignment_match is None:
        raise WorldBuilderError(f"{phase_path.name} emits entries but has no generation assignment")

    assignment_path, assignment = assignment_match
    receipt_expected = validate_assignment_evidence(
        state_path,
        assignment_path,
        write_receipt=False,
    )
    manifest_binding = receipt_expected.get("manifest_binding") if isinstance(receipt_expected.get("manifest_binding"), dict) else {}
    slice_tolerated = manifest_binding.get("manifest_binding") == "slice_tolerated"
    receipt_value = assignment.get("evidence_receipt")
    if not isinstance(receipt_value, str) or not receipt_value.strip():
        raise WorldBuilderError(f"{assignment_path.name} has no evidence_receipt path")
    receipt_path = (build_root / receipt_value).resolve()
    ensure_inside(receipt_path, evidence_receipts_dir)
    if not receipt_path.exists():
        raise WorldBuilderError(
            f"{phase_path.name} has no evidence-gate receipt; run evidence_gate.py before generation"
        )
    receipt = load_json(receipt_path)
    if not isinstance(receipt, dict) or receipt.get("kind") != "evidence-gate":
        raise WorldBuilderError(f"{receipt_path.name} is not an evidence-gate receipt")
    receipt_keys = (
        "build_id",
        "assignment_id",
        "assignment_sha256",
        "manifest_sha256",
        "activation_map_sha256",
        "field_registry_sha256",
        "default_profile_sha256",
        "character_plan_sha256",
        "era_plan_sha256",
        "placement_plan_sha256",
        "budget_plan_sha256",
        "dynamic_state_plan_sha256",
        "evidence_path",
        "evidence_sha256",
        "research_mode",
        "researched_uids",
        "claim_ids_by_uid",
        "statuses_by_uid",
    )
    # On a slice-tolerated assignment, the evidence itself must still validate
    # against the current assignment, but its historical metadata envelope may
    # name the pre-amendment assignment/manifest/planning hashes.  Those fields
    # are safe to carry only if the entry-cycle dependency slice below also
    # proves unchanged.
    tolerant_envelope_keys = {
        "assignment_sha256", "manifest_sha256", "activation_map_sha256",
        "field_registry_sha256", "default_profile_sha256", "character_plan_sha256",
        "era_plan_sha256", "placement_plan_sha256", "budget_plan_sha256",
        "dynamic_state_plan_sha256",
    } if slice_tolerated else set()
    for key in receipt_keys:
        if key in tolerant_envelope_keys:
            continue
        if receipt.get(key) != receipt_expected.get(key):
            raise WorldBuilderError(f"{receipt_path.name} is stale or mismatched at {key}")

    assignment_sha = sha256_file(assignment_path)
    historical_receipt_sha = sha256_file(receipt_path)
    evidence_path = (build_root / str(receipt["evidence_path"])).resolve()
    receipt_sha = sha256_file(receipt_path)

    cycle_value = assignment.get("entry_cycle_receipt")
    if not isinstance(cycle_value, str) or not cycle_value.strip():
        cycle_value = f".work/evidence-receipts/{assignment.get('assignment_id')}.entry-cycle.json"
    cycle_path = (build_root / cycle_value).resolve()
    ensure_inside(cycle_path, evidence_receipts_dir)
    if not cycle_path.exists():
        raise WorldBuilderError(f"{phase_path.name} lacks a completed entry-cycle receipt; run entry_cycle_gate.py --stage status for each assignment to see what is still outstanding, then --stage finalize once its entries are written")
    cycle = load_json(cycle_path)
    ordered_uids = [uid_key(item["uid"]) for item in assignment.get("entries", []) if isinstance(item, dict) and "uid" in item]
    if isinstance(cycle, dict) and cycle.get("status") == "partial_handoff":
        remaining = [uid for uid in ordered_uids if uid not in set(cycle.get("completed_uids") or [])]
        raise WorldBuilderError(
            f"{cycle_path.name} records an unresolved vision-budget handoff with {len(remaining)} UID(s) remaining "
            f"({', '.join(remaining)}): dispatch a replacement worker and finish this assignment; a partial handoff cannot merge"
        )
    cycle_assignment_ok = cycle.get("assignment_sha256") == assignment_sha if isinstance(cycle, dict) else False
    cycle_evidence_ok = cycle.get("aggregate_evidence_receipt_sha256") == receipt_sha if isinstance(cycle, dict) else False
    if slice_tolerated and isinstance(cycle, dict):
        # The cycle and phase envelope are historical, so bind them to the
        # historical evidence receipt that actually existed when generation ran.
        cycle_evidence_ok = cycle.get("aggregate_evidence_receipt_sha256") == historical_receipt_sha
        # Prove that the full assigned dependency slice, own rows, touching
        # edges, and neighbours, is still identical. Entry hashes alone are
        # insufficient for generated prose that may have used neighbour context.
        current_slice = slice_dependency_hash(build_root, state, ordered_uids)
        if cycle.get("slice_sha256") != current_slice.get("slice_sha256"):
            raise WorldBuilderError(
                f"{cycle_path.name} cannot be slice-tolerated: its generation dependency slice changed after the manifest amendment"
            )
        recorded_per_uid = cycle.get("per_uid_sha256") if isinstance(cycle.get("per_uid_sha256"), dict) else {}
        if recorded_per_uid and recorded_per_uid != current_slice.get("per_uid_sha256"):
            raise WorldBuilderError(f"{cycle_path.name} cannot be slice-tolerated: per-UID dependency hashes changed")
        if cycle.get("neighbour_sha256") is not None and cycle.get("neighbour_sha256") != current_slice.get("neighbour_sha256"):
            raise WorldBuilderError(f"{cycle_path.name} cannot be slice-tolerated: neighbour dependency hashes changed")
        cycle_assignment_ok = True
    if (
        not isinstance(cycle, dict)
        or cycle.get("kind") != "entry-cycle-gate"
        or cycle.get("receipt_version") != ENTRY_CYCLE_RECEIPT_VERSION
        or cycle.get("status") != "complete"
        or cycle.get("assignment_id") != assignment.get("assignment_id")
        or not cycle_assignment_ok
        or cycle.get("ordered_uids") != ordered_uids
        or cycle.get("completed_uids") != ordered_uids
        or len(cycle.get("cycles", [])) != len(ordered_uids)
        or not cycle_evidence_ok
    ):
        raise WorldBuilderError(f"{cycle_path.name} is incomplete, stale, or out of order; run entry_cycle_gate.py --stage status to read its resume card, then --stage refresh to restamp the cycle")
    overflow_records: list[dict[str, Any]] = []
    for index, row in enumerate(cycle.get("cycles", []), start=1):
        if not isinstance(row, dict) or row.get("sequence") != index or row.get("uid") != ordered_uids[index - 1]:
            raise WorldBuilderError(f"{cycle_path.name} has invalid entry-cycle ordering")
        checkpoint_value = row.get("checkpoint_path")
        if not isinstance(checkpoint_value, str) or not checkpoint_value:
            raise WorldBuilderError(f"{cycle_path.name} cycle {index} lacks checkpoint_path")
        checkpoint_path = (build_root / checkpoint_value).resolve()
        ensure_inside(checkpoint_path, build_root)
        if not checkpoint_path.exists() or sha256_file(checkpoint_path) != row.get("checkpoint_sha256"):
            raise WorldBuilderError(
                f"{cycle_path.name} cycle {index} checkpoint is missing or stale. If the checkpoint file was "
                "regenerated after it was recorded, refresh just that UID with `entry_cycle_gate.py --build-state "
                f"<build-state.json> --assignment <assignment.json> --stage refresh --uid {row.get('uid')} "
                f"--checkpoint {checkpoint_value}`."
            )
        if assignment.get("budget_plan_sha256") is not None:
            if row.get("budget_plan_sha256") != assignment.get("budget_plan_sha256"):
                raise WorldBuilderError(f"{cycle_path.name} cycle {index} lacks current budget lineage")
            if not isinstance(row.get("estimated_tokens"), int) or not isinstance(row.get("hard_limit"), int):
                raise WorldBuilderError(f"{cycle_path.name} cycle {index} lacks budget checkpoint evidence")
            budget_context = assignment.get("budget_context")
            auto_budget = isinstance(budget_context, dict) and budget_context.get("context_window_mode") == "auto"
            # Auto context-window mode is measurement-first: per-entry hard limits are
            # recorded, not enforced (mirrors entry_cycle_gate.py's auto_budget guard).
            if not auto_budget and row["estimated_tokens"] > row["hard_limit"]:
                raise WorldBuilderError(f"{cycle_path.name} cycle {index} exceeds its hard budget")
        if assignment.get("dynamic_state_plan_sha256") is not None and row.get("dynamic_state_plan_sha256") != assignment.get("dynamic_state_plan_sha256"):
            raise WorldBuilderError(f"{cycle_path.name} cycle {index} lacks current dynamic-state lineage")
        # Batch 5, 5.8: surface overflow at merge. write_stage already validated
        # the shape of each record; this loop only aggregates what is already
        # trustworthy, it does not re-validate it.
        for record in row.get("overflow") or []:
            if isinstance(record, dict):
                overflow_records.append(record)
    expected_metadata = {
        "assignment_id": assignment.get("assignment_id"),
        "assignment_sha256": cycle.get("assignment_sha256") if slice_tolerated else assignment_sha,
        "evidence_sha256": sha256_file(evidence_path),
        "evidence_receipt_sha256": historical_receipt_sha if slice_tolerated else receipt_sha,
        "entry_cycle_receipt_sha256": sha256_file(cycle_path),
    }
    if int(assignment.get("assignment_version", 0) or 0) >= 3 and not slice_tolerated:
        expected_metadata.update({
            "activation_map_sha256": assignment.get("activation_map_sha256"),
            "field_registry_sha256": assignment.get("field_registry_sha256"),
            "default_profile_sha256": assignment.get("default_profile_sha256"),
        })
        if assignment.get("character_plan_sha256") is not None:
            expected_metadata["character_plan_sha256"] = assignment.get("character_plan_sha256")
        if assignment.get("era_plan_sha256") is not None:
            expected_metadata["era_plan_sha256"] = assignment.get("era_plan_sha256")
        if assignment.get("placement_plan_sha256") is not None:
            expected_metadata["placement_plan_sha256"] = assignment.get("placement_plan_sha256")
        if assignment.get("budget_plan_sha256") is not None:
            expected_metadata["budget_plan_sha256"] = assignment.get("budget_plan_sha256")
        if assignment.get("dynamic_state_plan_sha256") is not None:
            expected_metadata["dynamic_state_plan_sha256"] = assignment.get("dynamic_state_plan_sha256")
    for key, value in expected_metadata.items():
        if metadata.get(key) != value:
            raise WorldBuilderError(f"{phase_path.name} metadata {key} does not match validated evidence lineage")

    assigned_uids = {uid_key(item["uid"]): item for item in assignment.get("entries", []) if isinstance(item, dict) and "uid" in item}
    emitted_uids: dict[str, int] = {}
    for ref in phase_entries:
        identity = canonical_entry_identity(ref.entry)
        if identity is None:
            raise WorldBuilderError(f"{phase_path.name} contains an entry without a stable identity")
        key = uid_key(identity)
        emitted_uids[key] = emitted_uids.get(key, 0) + 1
    duplicates = sorted(key for key, count in emitted_uids.items() if count != 1)
    if duplicates:
        raise WorldBuilderError(f"{phase_path.name} repeats entry identities: {', '.join(duplicates)}")
    if set(emitted_uids) != set(assigned_uids):
        missing = sorted(set(assigned_uids) - set(emitted_uids))
        extra = sorted(set(emitted_uids) - set(assigned_uids))
        details = []
        if missing:
            details.append("missing " + ", ".join(missing))
        if extra:
            details.append("extra " + ", ".join(extra))
        raise WorldBuilderError(f"{phase_path.name} assignment coverage mismatch: {'; '.join(details)}")

    claim_usage = metadata.get("evidence_claims")
    if not isinstance(claim_usage, dict):
        raise WorldBuilderError(f"{phase_path.name} metadata must include evidence_claims by UID")
    if set(map(str, claim_usage)) != set(assigned_uids):
        raise WorldBuilderError(f"{phase_path.name} evidence_claims does not cover every assigned UID exactly")
    allowed_claims = receipt.get("claim_ids_by_uid", {})
    statuses = receipt.get("statuses_by_uid", {})
    for uid in assigned_uids:
        used = claim_usage.get(uid)
        if not isinstance(used, list) or any(not isinstance(item, str) for item in used):
            raise WorldBuilderError(f"{phase_path.name} evidence_claims[{uid}] must be a list of claim IDs")
        unknown = sorted(set(used) - set(allowed_claims.get(uid, [])))
        if unknown:
            raise WorldBuilderError(
                f"{phase_path.name} cites unknown evidence claims for UID {uid}: {', '.join(unknown)}"
            )
        if statuses.get(uid) != "not_found" and not used:
            raise WorldBuilderError(f"{phase_path.name} cites no evidence claims for researched UID {uid}")
    unsupported = metadata.get("unsupported_claims")
    if unsupported != []:
        raise WorldBuilderError(f"{phase_path.name} must declare unsupported_claims as an empty list")
    return overflow_records


def legacy_paths(outputs: Path, scratchpad: Path) -> dict[str, Path]:
    return {
        "manifest": scratchpad / "manifest.json",
        "build_id": scratchpad / "build-id.json",
        "build_list": outputs / "artifacts" / "build_list.md",
        "recursion_map": outputs / "artifacts" / "recursion_map.md",
        "phases": scratchpad,
        "receipts": scratchpad / "pipeline-receipts.jsonl",
        "assignments": scratchpad / "assignments",
        "evidence_receipts": scratchpad / "evidence-receipts",
    }


def stamp_generation_assignments(assignments_dir: Path, manifest: dict[str, Any], manifest_sha: str, root: Path, state: dict[str, Any]) -> int:
    """Freeze each generation assignment into a self-contained contract.

    Injects the absolute workspace_root and a per-assigned-UID entry hash so
    child gates verify the slice they own instead of live whole-file bytes.
    Also stamps run_timeout_seconds: a computed liveness bound (DR-064) the
    child reads and passes to sessions_spawn, never a value it estimates
    itself. per_uid_seconds comes from state["timeouts"], frozen at build
    creation like batching and discovery; not re-read from a config.json
    that may have changed since this build started. Idempotent: unchanged
    assignments are not rewritten. Runs before workers exist, so no
    downstream receipt can be invalidated by the stamp itself."""
    from wb_common import collect_uid_entries, compute_run_timeout_seconds, entry_binding_hash
    if not assignments_dir.exists():
        return 0
    lookup = collect_uid_entries(manifest)
    per_uid_seconds = int((state.get("timeouts") or {}).get("per_uid_seconds", 90))
    from phase_summary import ensure_summary
    shared_summary_path, _shared_summary = ensure_summary(root, state)
    shared_summary_rel = str(shared_summary_path.relative_to(root)).replace("\\", "/")
    shared_summary_sha = sha256_file(shared_summary_path)
    stamped = 0
    for path in sorted(assignments_dir.glob("*.json")):
        assignment = load_json(path)
        if not isinstance(assignment, dict) or assignment.get("role") != "generation":
            continue
        declared = str(assignment.get("manifest_sha256", "")).lower()
        uids = [str(row.get("uid")) for row in assignment.get("entries", []) if isinstance(row, dict)]
        if declared != manifest_sha:
            # Batch 40 / Finding 2, option 3: do not regenerate an otherwise
            # valid assignment merely because unrelated manifest bytes changed.
            # Rewriting manifest_sha256 would change the assignment's own hash
            # and strand an already-generated phase that is correctly bound to
            # the historical assignment. Preserve the assignment byte-for-byte
            # only when its pre-dispatch per-UID hashes prove that every UID it
            # owns is unchanged in the live manifest. evidence_gate/phase_gate
            # will record this exact condition as ``slice_tolerated`` later.
            historical_hashes = assignment.get("entry_hashes")
            if not isinstance(historical_hashes, dict) or not historical_hashes:
                raise WorldBuilderError(
                    f"assignment {path.name} was authored against manifest {declared[:12]}... but the planned manifest is "
                    f"{manifest_sha[:12]}... and it has no historical per-UID hashes; regenerate this assignment from "
                    "the current planning outputs before dispatch."
                )
            changed = [
                uid for uid in uids
                if uid not in lookup or entry_binding_hash(lookup[uid]) != historical_hashes.get(uid)
            ]
            if changed:
                raise WorldBuilderError(
                    f"assignment {path.name} was authored against an older manifest and its own assigned UID slice changed "
                    f"({', '.join(changed)}); regenerate only this affected assignment and its phase."
                )
            # Keeping the historical assignment bytes is intentional: its
            # assignment_sha256 is already embedded in the completed phase,
            # evidence ledger, and entry-cycle receipt. Any rewrite here would
            # recreate the exact amendment dead end this tolerance closes.
            stamped += 1
            continue
        missing = [uid for uid in uids if uid not in lookup]
        if missing:
            raise WorldBuilderError(f"assignment {path.name} references UIDs missing from the manifest: {', '.join(missing)}")
        updated = dict(assignment)
        updated["workspace_root"] = str(root)
        updated["entry_hashes"] = {uid: entry_binding_hash(lookup[uid]) for uid in uids}
        # Keep the whole-manifest identity next to the per-UID slice hashes.
        # If a later manifest amendment changes only unrelated entries, the
        # diagnostic can distinguish "assignment was stamped under an older
        # manifest" from "this assignment's own slice changed" immediately.
        updated["entry_hashes_manifest_sha256"] = manifest_sha
        updated["run_timeout_seconds"] = compute_run_timeout_seconds(len(uids), per_uid_seconds)
        updated["requested_model"] = str((state.get("models") or {}).get("generation", (state.get("models") or {}).get("subagent", "inherit")))
        terminology_path = resolve_state_path(root, state, "terminology_dictionary", required=False)
        if terminology_path and terminology_path.exists():
            updated["terminology_dictionary"] = str(terminology_path.relative_to(root)).replace("\\", "/")
            updated["terminology_dictionary_sha256"] = sha256_file(terminology_path)
        prior_summary = assignment.get("shared_state_summary")
        if prior_summary:
            prior_path = (root / str(prior_summary)).resolve()
            if not prior_path.exists() or sha256_file(prior_path) != assignment.get("shared_state_summary_sha256"):
                raise WorldBuilderError(f"assignment {path.name} has a missing or stale immutable shared-state summary")
        else:
            updated["shared_state_summary"] = shared_summary_rel
            updated["shared_state_summary_sha256"] = shared_summary_sha
        if updated != assignment:
            atomic_write_json(path, updated)
        stamped += 1
    return stamped


def _latest_receipt(receipts: list[dict[str, Any]], stage: str, build_id: str) -> dict[str, Any] | None:
    matches = [r for r in receipts if r.get("stage") == stage and r.get("build_id") == build_id]
    if not matches:
        return None
    return max(
        matches,
        key=lambda r: (int(r.get("created_at_unix", 0)), int(r.get("restamp_count", 0) or 0), str(r.get("restamped_at") or "")),
    )


def restamp(build_state: str, stage: str, preserve_created_at: int | None = None) -> dict[str, Any]:
    """Batch 62: re-record one phase-gate receipt against current bytes in place.

    A pre-dispatch receipt that was re-recorded after the wave (for example to
    clear a stale phase_1 binding) stamped a fresh created_at, which then made
    every already-generated phase look older than dispatch. Restamping refreshes
    the receipt's bindings while preserving the dispatch instant the ledger
    already recorded, so verification compares phases against the real dispatch
    time. Append-only: the superseded row stays in the file as history, and the
    stage's own phase-level contract is re-checked before anything is written.
    """
    state_path = Path(build_state).resolve()
    root, state = load_build_state(state_path)
    keys = ("manifest", "build_id", "build_list", "recursion_map", "phases", "receipts", "assignments", "evidence_receipts", "discovery_receipt")
    paths = {key: resolve_state_path(root, state, key) for key in keys}
    build_id = str(state.get("build_id", "")).strip()
    if not build_id:
        raise WorldBuilderError("build-state.json has no build_id")
    receipts = load_receipts(paths["receipts"])
    latest = _latest_receipt(receipts, stage, build_id)
    if latest is None:
        raise WorldBuilderError(
            f"{stage} has never been recorded, so there is nothing to restamp. Run it normally: "
            f"{sys.executable or 'python'} phase_gate.py --stage {stage} --build-state {state_path}"
        )
    instant = int(latest.get("created_at_unix", 0))
    if preserve_created_at is not None:
        recorded = {int(r.get("created_at_unix", 0)) for r in receipts
                    if r.get("stage") == stage and r.get("build_id") == build_id}
        if preserve_created_at not in recorded:
            raise WorldBuilderError(
                f"--preserve-created-at {preserve_created_at} is not an instant this ledger recorded for {stage}; "
                "a restamp may only preserve an instant the ledger itself recorded, never invent one"
            )
        instant = preserve_created_at

    hashes, manifest_sha = require_build_files(paths, state, build_id)
    stage_hashes = dict(hashes)
    discovery_sha = require_discovery_lineage(paths, state, build_id)
    if discovery_sha:
        stage_hashes["discovery_receipt"] = discovery_sha
    if stage == "pre-generation":
        audit_sha = require_pre_generation_audit(state_path, root, state)
        if audit_sha:
            stage_hashes["pre_generation_audit_receipt"] = audit_sha
    if isinstance(latest.get("artifacts"), dict) and "worker_kit_bundle" in latest["artifacts"]:
        bundle = resolve_state_path(root, state, "worker_kit_bundle", required=False)
        if bundle is not None and bundle.is_file():
            stage_hashes["worker_kit_bundle"] = sha256_file(bundle)
    if stage in ("pre-dispatch", "pre-merge"):
        phase_files = discover_phase_files(paths["phases"])
        if stage == "pre-dispatch":
            phase_one = next((path for path in phase_files if phase_sort_key(path)[0] == 1), None)
            if phase_one is None:
                raise WorldBuilderError("pre-dispatch restamp requires phase 1 to exist; nothing to bind")
            validate_phase_file(phase_one, build_id, manifest_sha, expected_number=1)
            phase_one_assignment = _assignment_for_phase(root, paths["assignments"], phase_one)
            check_phase_one_completeness(phase_one, phase_one_assignment)
            stage_hashes["phase_1"] = sha256_file(phase_one)
        else:
            if not phase_files:
                raise WorldBuilderError("pre-merge restamp requires phase files to exist; nothing to bind")
            for path in phase_files:
                number = phase_sort_key(path)[0]
                validate_phase_file(path, build_id, manifest_sha, expected_number=number,
                                    root=root, state=state, assignments_dir=paths["assignments"])
                stage_hashes[path.name] = sha256_file(path)

    now = datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")
    receipt = {
        "receipt_version": int(latest.get("receipt_version", 1) or 1),
        "stage": stage,
        "build_id": build_id,
        "created_at_unix": instant,
        "pipeline_mode": latest.get("pipeline_mode", state.get("pipeline", {}).get("mode", "unknown")),
        "dispatch_count": latest.get("dispatch_count", state.get("pipeline", {}).get("dispatch_count", 0)),
        "artifacts": stage_hashes,
        "overflow_summary": latest.get("overflow_summary"),
        "slice_tolerated_summary": latest.get("slice_tolerated_summary"),
        "phase_quality_summary": latest.get("phase_quality_summary"),
        "worker_kit": latest.get("worker_kit"),
        "restamped_at": now,
        "restamp_count": int(latest.get("restamp_count", 0) or 0) + 1,
        "restamp_reason": "bindings refreshed in place; recorded dispatch instant preserved",
    }
    append_receipt(paths["receipts"], receipt)
    previous_artifacts = latest.get("artifacts") if isinstance(latest.get("artifacts"), dict) else {}
    changed = sorted(
        key for key in set(stage_hashes) | set(previous_artifacts)
        if previous_artifacts.get(key) != stage_hashes.get(key)
    )
    return {
        "status": "restamped",
        "stage": stage,
        "build_id": build_id,
        "created_at_unix": instant,
        "restamp_count": receipt["restamp_count"],
        "changed_bindings": changed,
        "receipt": receipt,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate a WorldBuilder phase boundary.")
    parser.add_argument("--stage", choices=["pre-generation", "pre-dispatch", "pre-merge"])
    parser.add_argument("--build-state")
    parser.add_argument("--outputs")
    parser.add_argument("--scratchpad")
    parser.add_argument("--single-phase", action="store_true")
    parser.add_argument("--restamp", choices=["pre-generation", "pre-dispatch", "pre-merge"],
                        help="Re-record one recorded stage's receipt against current bytes, preserving the recorded dispatch instant.")
    parser.add_argument("--preserve-created-at", type=int,
                        help="Restamp: preserve this previously recorded dispatch instant instead of the latest row's.")
    parser.add_argument("--requirements", action="store_true", help="Read-only preflight: print what this gate checks against the current build state.")
    args = parser.parse_args()
    if args.requirements:
        if not args.build_state:
            parser.error("--requirements needs --build-state")
        root, state = load_build_state(args.build_state)
        print(json.dumps(preflight_report("phase_gate", requirement_rows(Path(__file__), root, state)), ensure_ascii=False, indent=2))
        return 0
    if not args.stage and not args.restamp:
        parser.error("--stage (or --restamp) is required")

    state_path: Path | None = None
    state: dict[str, Any]
    try:
        if args.restamp:
            if not args.build_state:
                parser.error("--restamp requires --build-state")
            result = restamp(args.build_state, args.restamp, args.preserve_created_at)
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0
        if args.build_state:
            root, state = load_build_state(args.build_state)
            state_path = Path(args.build_state).resolve()
            keys = ("manifest", "build_id", "build_list", "recursion_map", "phases", "receipts", "assignments", "evidence_receipts", "discovery_receipt")
            paths = {key: resolve_state_path(root, state, key) for key in keys}
            build_id = str(state.get("build_id", "")).strip()
            if not build_id:
                raise WorldBuilderError("build-state.json has no build_id")
        else:
            if not args.outputs or not args.scratchpad:
                parser.error("use --build-state or both --outputs and --scratchpad")
            paths = legacy_paths(Path(args.outputs).resolve(), Path(args.scratchpad).resolve())
            state = {"build_id": "legacy", "pipeline": {"mode": "sequential"}, "status": {}}
            fingerprint = load_json(paths["build_id"])
            build_id = str(fingerprint.get("build_id", fingerprint.get("world", "legacy")))

        hashes, manifest_sha = require_build_files(paths, state, build_id)
        discovery_sha = require_discovery_lineage(paths, state, build_id)
        stage_hashes = dict(hashes)
        if discovery_sha:
            stage_hashes["discovery_receipt"] = discovery_sha
        if args.stage == "pre-generation" and state_path is not None:
            audit_sha = require_pre_generation_audit(state_path, root, state)
            if audit_sha:
                stage_hashes["pre_generation_audit_receipt"] = audit_sha
        phase_files: list[Path] = []
        worker_kit_summary: dict[str, Any] | None = None

        if args.stage == "pre-generation" and state_path is not None:
            pregen_required = bool(state.get("audit", {}).get("pre_generation_required", False))
            if pregen_required:
                audit_receipt = validate_saved_receipt(state_path, "pre-generation")
                audit_receipt_path = resolve_state_path(root, state, "pre_generation_audit_receipt")
                stage_hashes["pre_generation_audit_receipt"] = sha256_file(audit_receipt_path)
                if audit_receipt.get("target_sha256") != manifest_sha:
                    raise WorldBuilderError("pre-generation auditors did not review the current manifest bytes")

        if args.stage == "pre-dispatch":
            if state_path is not None:
                pregen_plan_path = resolve_state_path(root, state, "pre_generation_audit_plan", required=False)
                if pregen_plan_path is not None and pregen_plan_path.is_file():
                    pregen_plan = load_json(pregen_plan_path)
                    if not isinstance(pregen_plan, dict):
                        raise WorldBuilderError("pre-generation audit plan is not a JSON object; regenerate it before dispatch")
                    planned_manifest = str(pregen_plan.get("manifest_sha256", "")).lower()
                    if planned_manifest != manifest_sha:
                        raise WorldBuilderError(
                            "pre-generation audit plan is stale before dispatch: it was planned against manifest "
                            f"{planned_manifest[:12]}... but the live manifest is {manifest_sha[:12]}.... "
                            "Regenerate and complete the pre-generation audit against the current manifest before dispatch."
                        )
                    for row in pregen_plan.get("assignments", []):
                        if not isinstance(row, dict):
                            continue
                        assignment_rel = row.get("assignment")
                        expected_sha = row.get("assignment_sha256")
                        if not isinstance(assignment_rel, str) or not isinstance(expected_sha, str):
                            continue
                        audit_assignment = (root / assignment_rel).resolve()
                        if not audit_assignment.is_file() or sha256_file(audit_assignment) != expected_sha:
                            raise WorldBuilderError(
                                f"pre-generation audit plan is stale before dispatch: audit assignment {assignment_rel} "
                                "is missing or changed since the plan was written; regenerate the pre-generation audit plan."
                            )
                worker_kit_path = resolve_state_path(root, state, "worker_kit", required=False)
                if worker_kit_path is not None:
                    from init_build import stage_worker_kit, worker_kit_status
                    kit_status = worker_kit_status(root)
                    if kit_status.get("stale"):
                        print(
                            "[worldbuilder] pre-dispatch worker kit is stale: " + "; ".join(kit_status.get("reasons", [])) +
                            "; restaging from the currently installed skill before dispatch.",
                            file=sys.stderr,
                        )
                        full = kit_status.get("staging_mode") == "full"
                        restage = stage_worker_kit(root, full=full, restage=True)
                        kit_status = worker_kit_status(root)
                        worker_kit_summary = {**restage, "auto_restaged": True, "stale_reasons": kit_status.get("reasons", [])}
                    else:
                        worker_kit_summary = {
                            "status": "current",
                            "auto_restaged": False,
                            "skill_release": kit_status.get("skill_release"),
                            "worker_kit_sha256": kit_status.get("worker_kit_sha256"),
                            "staging_mode": kit_status.get("staging_mode"),
                            "added": [], "updated": [], "removed": [],
                        }
                    final_status = worker_kit_status(root)
                    if final_status.get("stale"):
                        raise WorldBuilderError("worker kit is still stale after restage: " + "; ".join(final_status.get("reasons", [])))
                    worker_kit_summary["skill_release"] = final_status.get("skill_release")
                    worker_kit_summary["worker_kit_sha256"] = final_status.get("worker_kit_sha256")
                    bundle_path = resolve_state_path(root, state, "worker_kit_bundle", required=False)
                    if bundle_path is None or not bundle_path.is_file():
                        raise WorldBuilderError("worker-kit bundle is missing after staleness check")
                    stage_hashes["worker_kit_bundle"] = sha256_file(bundle_path)
                    state["worker_kit"] = {
                        "skill_release": final_status.get("skill_release"),
                        "worker_kit_sha256": final_status.get("worker_kit_sha256"),
                        "staging_mode": final_status.get("staging_mode"),
                        "bundle": str(bundle_path.relative_to(root)).replace(os.sep, "/"),
                    }
                    atomic_write_json(state_path, state)
            phase_files = discover_phase_files(paths["phases"])
            phase_one = next((path for path in phase_files if path.name.lower().startswith(("phase-1.", "phase-01.", "phase-001.", "phase-0001."))), None)
            if phase_one is None and phase_files:
                # Numeric discovery is authoritative; the first file must be phase 1.
                first_number = phase_sort_key(phase_files[0])[0]
                phase_one = phase_files[0] if first_number == 1 else None
            if phase_one is None:
                raise WorldBuilderError(
                    "pre-dispatch requires phase 1 (main-agent shell/core output). "
                    "Write phase 1 to .work/phases/ (or wherever paths.phases points) "
                    "before running phase_gate.py --stage pre-dispatch."
                )
            validate_phase_file(phase_one, build_id, manifest_sha, expected_number=1)
            phase_one_assignment = _assignment_for_phase(root, paths["assignments"], phase_one) if state_path is not None else None
            check_phase_one_completeness(phase_one, phase_one_assignment)
            stage_hashes["phase_1"] = sha256_file(phase_one)
            already_stamped = False
            if paths["assignments"].is_dir():
                for assignment_path in sorted(paths["assignments"].glob("*.json")):
                    existing_assignment = load_json(assignment_path)
                    if (isinstance(existing_assignment, dict)
                            and existing_assignment.get("role") == "generation"
                            and isinstance(existing_assignment.get("entry_hashes"), dict)
                            and existing_assignment.get("workspace_root")):
                        already_stamped = True
                        break
            stamped = stamp_generation_assignments(paths["assignments"], load_json(paths["manifest"]), manifest_sha, root, state)
            print(f"[worldbuilder] pre-dispatch stamped {stamped} generation assignment(s) with workspace_root, per-UID entry_hashes, and run_timeout_seconds.", file=sys.stderr)
            if already_stamped:
                pipeline_gate = Path(__file__).resolve().parent / "pipeline_stage_gate.py"
                state_arg = str(state_path) if state_path is not None else "<your build-state.json>"
                print(
                    "[worldbuilder] assignments re-stamped during a pre-dispatch re-run; "
                    f"run {sys.executable or 'python'} {pipeline_gate} --build-state {state_arg} "
                    "--restamp generation_dispatched to realign the chain; this is expected "
                    "after a pre-dispatch re-run, not a failure.",
                    file=sys.stderr,
                )

        if args.stage == "pre-merge":
            phase_files = discover_phase_files(paths["phases"])
            if not phase_files:
                raise WorldBuilderError("no phase-NNNN.json files are available to merge")
            mode = state.get("pipeline", {}).get("mode", "sequential")
            expected = state.get("pipeline", {}).get("expected_phase_count")
            if isinstance(expected, int) and len(phase_files) != expected:
                raise WorldBuilderError(f"expected {expected} phase files, found {len(phase_files)}")
            if not args.single_phase and mode == "parallel" and len(phase_files) < 2:
                raise WorldBuilderError("parallel pipeline has fewer than two phase files")
            all_overflow: list[dict[str, Any]] = []
            slice_tolerated_phases: list[str] = []
            for path in phase_files:
                number = phase_sort_key(path)[0]
                phase_data = validate_phase_file(
                    path, build_id, manifest_sha, expected_number=number,
                    root=root, state=state, assignments_dir=paths["assignments"],
                )
                metadata = phase_metadata(phase_data)
                assert metadata is not None
                if metadata.get("phase_binding") == "slice_tolerated":
                    slice_tolerated_phases.append(path.name)
                if state_path is not None:
                    all_overflow.extend(validate_generation_evidence_lineage(
                        state_path=state_path,
                        build_root=root,
                        state=state,
                        phase_path=path,
                        phase_data=phase_data,
                        metadata=metadata,
                        assignments_dir=paths["assignments"],
                        evidence_receipts_dir=paths["evidence_receipts"],
                    ))
                stage_hashes[path.name] = sha256_file(path)
            # Batch 23 checkpoint 4: cheap, non-authoritative cross-phase quality scan.
            # It records candidates for the later full audit and never mutates phases.
            from phase_quality_check import analyze_build as analyze_phase_quality
            phase_quality = analyze_phase_quality(str(state_path), write=True) if state_path is not None else {"finding_count": 0}
            if mode == "parallel":
                receipts = load_receipts(paths["receipts"])
                if not any(r.get("stage") == "pre-dispatch" and r.get("build_id") == build_id for r in receipts):
                    raise WorldBuilderError("parallel build has no pre-dispatch receipt")

        overflow_summary = None
        slice_tolerated_summary = None
        if args.stage == "pre-merge":
            distinct_sources = sorted({str(r.get("source_uid")) for r in all_overflow})
            overflow_summary = {
                "overflow_count": len(all_overflow),
                "entries_with_overflow": len(distinct_sources),
                "source_uids": distinct_sources,
                "note": (
                    f"{len(distinct_sources)} entries had material scoped out; run a detail pass."
                    if distinct_sources else "No entries had material scoped out."
                ),
            }
            slice_tolerated_summary = {
                "slice_tolerated_count": len(slice_tolerated_phases),
                "phases": sorted(slice_tolerated_phases),
            }
            phase_quality_summary = {
                "finding_count": int(phase_quality.get("finding_count", 0)),
                "report_path": phase_quality.get("report_path"),
                "authoritative": False,
            }
        receipt = {
            "receipt_version": 1,
            "stage": args.stage,
            "build_id": build_id,
            "created_at_unix": int(time.time()),
            "pipeline_mode": state.get("pipeline", {}).get("mode", "unknown"),
            "dispatch_count": state.get("pipeline", {}).get("dispatch_count", 0),
            "artifacts": stage_hashes,
            "overflow_summary": overflow_summary,
            "slice_tolerated_summary": slice_tolerated_summary,
            "phase_quality_summary": phase_quality_summary if args.stage == "pre-merge" else None,
            "worker_kit": worker_kit_summary if args.stage == "pre-dispatch" else None,
        }
        append_receipt(paths["receipts"], receipt)
        print(json.dumps(receipt, ensure_ascii=False, indent=2))
        if state_path:
            state.setdefault("status", {})[args.stage.replace("-", "_")] = "complete"
            atomic_write_json(state_path, state)
            stage_map = {
                "pre-generation": "generation_ready",
                "pre-dispatch": "generation_dispatched",
                "pre-merge": "generation_complete",
            }
            advance_pipeline_stage(state_path, stage_map[args.stage])
        return 0
    except (WorldBuilderError, OSError, json.JSONDecodeError) as exc:
        print(f"PHASE GATE BLOCKED: {exc}", file=sys.stderr)
        print(step_driver_pointer(), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
