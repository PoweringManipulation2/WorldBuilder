#!/usr/bin/env python3
"""Validate discovery-to-planning lineage before generation assignments exist."""
from __future__ import annotations
import argparse
import json
import sys
from pathlib import Path
from typing import Any
from wb_common import step_driver_pointer, WorldBuilderError, atomic_write_json, count_entries, load_build_state, load_json, resolve_state_path, sha256_file
from architecture_gate import validate as validate_architecture
from era_root_contract import run as validate_era_root
from activation_map_gate import validate as validate_activation_map
from activation_test_corpus import check as check_activation_test_corpus
from era_router_contract import validate as validate_era_router
from placement_contract import validate as validate_placement
from budget_contract import validate as validate_budget
from dynamic_state_contract import validate as validate_dynamic_state
from integration_acceptance import validate_build as validate_integration
from entry_naming import validate_manifest_build as validate_entry_naming
from pipeline_stage_gate import advance as advance_pipeline_stage
from discovery_contract import saturation_accepted

PREFIX = "WORLDBUILDER-ARTIFACT:"

def header(path: Path) -> dict[str, Any]:
    text = path.read_text(encoding="utf-8", errors="replace")
    first = next((line.strip() for line in text.splitlines() if line.strip()), "")
    if not first.startswith(PREFIX): raise WorldBuilderError(f"{path.name}'s first non-blank line must start with '{PREFIX}' followed by a JSON object; found: {first[:60]!r}")
    try: value = json.loads(first[len(PREFIX):].strip())
    except json.JSONDecodeError as exc: raise WorldBuilderError(f"{path.name}'s {PREFIX} header line has invalid JSON: {exc}") from exc
    if not isinstance(value, dict): raise WorldBuilderError(f"{path.name}'s {PREFIX} header must be a JSON object, not {type(value).__name__}")
    if len(text.strip()) <= len(first) + 20: raise WorldBuilderError(f"{path.name} has a valid header but no substantive body content after it; author the actual content per references/lorebook-architecture.md")
    return value

def validate_build_conditions(state: dict[str, Any], manifest: dict[str, Any]) -> dict[str, Any]:
    """Prove the accepted free-form build condition was not dropped at planning.

    This intentionally checks exact propagation only. Correct semantic application of
    free-form instructions remains a planning/generation judgment.
    """
    settings = state.get("settings") if isinstance(state.get("settings"), dict) else {}
    conditions = settings.get("conditions", "")
    if conditions is None:
        conditions = ""
    if not isinstance(conditions, str):
        raise WorldBuilderError("build-state settings.conditions must be a string")
    architecture = manifest.get("architecture") if isinstance(manifest.get("architecture"), dict) else {}
    planned = architecture.get("build_conditions")
    if conditions != "" and planned != conditions:
        if planned is None:
            detail = "missing"
        elif planned == "":
            detail = "empty"
        else:
            detail = "different from the accepted settings value"
        raise WorldBuilderError(
            "build conditions were dropped or changed during planning: "
            f"build-state settings.conditions is non-empty but manifest architecture.build_conditions is {detail}. "
            "Re-author the manifest and copy settings.conditions verbatim before generation."
        )
    return {"required": conditions != "", "matched": conditions == "" or planned == conditions}

def validate_effective_image_mode(state: dict[str, Any]) -> dict[str, Any]:
    """Validate the frozen image-analysis resolution when the build records it.

    Legacy builds without Batch 28 fields remain valid. New builds fail closed if
    any recorded value is malformed or the effective boolean disagrees with the
    requested mode/capability pair.
    """
    settings = state.get("settings") if isinstance(state.get("settings"), dict) else {}
    keys = {"image_analysis_mode", "vision_capable", "effective_image_mode"}
    if not (keys & set(settings)):
        return {"recorded": False, "effective": False}
    missing = sorted(keys - set(settings))
    if missing:
        raise WorldBuilderError("incomplete image-analysis resolution in build-state settings: missing " + ", ".join(missing))
    mode = settings.get("image_analysis_mode")
    capability = settings.get("vision_capable")
    effective = settings.get("effective_image_mode")
    if mode not in {"on", "off"}:
        raise WorldBuilderError("settings.image_analysis_mode must be 'on' or 'off'")
    if capability not in {"available", "unavailable", "unknown"}:
        raise WorldBuilderError("settings.vision_capable must be available, unavailable, or unknown")
    if not isinstance(effective, bool):
        raise WorldBuilderError("settings.effective_image_mode must be a boolean")
    expected = mode == "on" and capability == "available"
    if effective != expected:
        raise WorldBuilderError(
            "settings.effective_image_mode is inconsistent with image_analysis_mode and vision_capable; "
            f"expected {expected!r} from mode={mode!r}, capability={capability!r}"
        )
    return {"recorded": True, "effective": effective}


def validate_discovery(root: Path, state: dict[str, Any]) -> tuple[Path | None, str | None, str]:
    discovery = state.get("discovery") if isinstance(state.get("discovery"), dict) else {}
    if not discovery.get("required"): return None, None, "not_required"
    path = resolve_state_path(root, state, "discovery_receipt")
    if not path.exists(): raise WorldBuilderError(f"known-property planning requires a discovery gate receipt. Run: {sys.executable or 'python'} {Path(__file__).resolve().parent}/discovery_gate.py --build-state <your build-state.json>")
    receipt = load_json(path)
    if not isinstance(receipt, dict) or receipt.get("kind") != "breadth-discovery-gate" or int(receipt.get("receipt_version",0) or 0) < 3: raise WorldBuilderError(f"{path.name} has the wrong format (kind={receipt.get('kind') if isinstance(receipt, dict) else type(receipt).__name__!r}, receipt_version={receipt.get('receipt_version') if isinstance(receipt, dict) else 'n/a'}; need kind='breadth-discovery-gate', receipt_version>=3). Run: {sys.executable or 'python'} {Path(__file__).resolve().parent}/discovery_gate.py --build-state <your build-state.json>")
    status = receipt.get("status")
    if status not in {"complete", "passed_with_exclusions"}: raise WorldBuilderError(f"{path.name}'s status is {status!r}, not 'complete' or 'passed_with_exclusions'. Re-run discovery_gate.py until it reports one of those two statuses before planning can proceed.")
    if receipt.get("bounded_coverage_proven", receipt.get("completeness_proven")) is not True: raise WorldBuilderError("discovery receipt does not prove bounded source-set coverage")
    if status == "complete" and not saturation_accepted(receipt):
        raise WorldBuilderError(f"complete discovery receipt is not saturation-accepted: saturation_proven={receipt.get('saturation_proven')!r}, effective_saturation_accepted={receipt.get('effective_saturation_accepted')!r}")
    if status == "passed_with_exclusions":
        approval_rel, approval_sha = receipt.get("exclusion_approval"), receipt.get("exclusion_approval_sha256")
        if not isinstance(approval_rel,str) or not isinstance(approval_sha,str): raise WorldBuilderError(f"{path.name} has status='passed_with_exclusions' but its exclusion_approval/exclusion_approval_sha256 fields are missing; re-run discovery_exclusions.py's approval step and re-run discovery_gate.py to bind it into the receipt")
        approval = (root / approval_rel).resolve()
        if not approval.exists() or sha256_file(approval) != approval_sha: raise WorldBuilderError(f"the discovery exclusion approval file the receipt points to ({approval_rel}) is missing or its hash no longer matches ({approval_sha}); re-approve exclusions with discovery_exclusions.py if the underlying exclusion list changed")
    return path, sha256_file(path), str(status)

def validate(build_state: str) -> dict[str, Any]:
    root, state = load_build_state(build_state); build_id = str(state.get("build_id"))
    discovery_path, discovery_sha, discovery_status = validate_discovery(root,state)
    manifest_path=resolve_state_path(root,state,"manifest"); build_id_path=resolve_state_path(root,state,"build_id")
    build_list_path=resolve_state_path(root,state,"build_list"); recursion_path=resolve_state_path(root,state,"recursion_map"); identity_path=resolve_state_path(root,state,"identity_receipt")
    _sd = Path(__file__).resolve().parent
    _producers = {
        manifest_path: "author it per references/lorebook-architecture.md (planning manifest)",
        build_list_path: "author it per references/lorebook-architecture.md (WORLDBUILDER-ARTIFACT build list)",
        recursion_path: "author it per references/lorebook-architecture.md (WORLDBUILDER-ARTIFACT recursion map)",
        build_id_path: f"generate it with: {sys.executable or 'python'} {_sd}/manifest_identity.py --build-state {Path(build_state).resolve()}",
        identity_path: f"generate it with: {sys.executable or 'python'} {_sd}/manifest_identity.py --build-state {Path(build_state).resolve()}",
    }
    for path in (manifest_path,build_id_path,build_list_path,recursion_path,identity_path):
        if not path.exists(): raise WorldBuilderError(f"planning artifact is missing: {path}. Produce it first; {_producers[path]}")
    manifest=load_json(manifest_path)
    if not isinstance(manifest,dict): raise WorldBuilderError(f"{manifest_path.name} is not a JSON object")
    if manifest.get("build_id") != build_id: raise WorldBuilderError(f"{manifest_path.name}'s build_id ({manifest.get('build_id')!r}) does not match this build's own build_id ({build_id!r}); it was likely authored for a different build")
    if count_entries(manifest)<=0: raise WorldBuilderError(f"{manifest_path.name} has zero entries; author at least one entry before planning can proceed")
    build_conditions_check = validate_build_conditions(state, manifest)
    image_analysis_check = validate_effective_image_mode(state)
    manifest_sha=sha256_file(manifest_path)
    if discovery_sha and manifest.get("discovery_receipt_sha256") != discovery_sha: raise WorldBuilderError(f"{manifest_path.name}'s discovery_receipt_sha256 does not match the current discovery receipt's hash ({discovery_sha}); re-author the manifest against the current discovery receipt, or re-run discovery_gate.py if the manifest is actually current and the receipt is stale")
    architecture_receipt = validate_architecture(build_state, "planning", write_receipt=True)
    architecture_receipt_path = resolve_state_path(root, state, "architecture_planning_receipt")
    activation_receipt = validate_activation_map(build_state, write_receipt=True)
    activation_receipt_path = resolve_state_path(root, state, "activation_map_receipt")
    activation_test_receipt = check_activation_test_corpus(build_state, write_receipt=True, freeze_if_needed=True, enforce=True)
    activation_test_receipt_path = resolve_state_path(root, state, "activation_test_corpus_receipt", required=False)
    era_router_receipt = validate_era_router(build_state, "planning", write_receipt=True)
    era_router_receipt_path = resolve_state_path(root, state, "era_router_receipt", required=False)
    # root_toggle builds were validated only at delivery, so a malformed cascade was not
    # caught until after generation. Both routings now prove themselves at planning; the
    # router contract self-skips when the manifest declares root_toggle routing.
    era_root_receipt = validate_era_root(build_state, "planning", None, write_receipt=True)
    placement_receipt = validate_placement(build_state, "planning", write_receipt=True)
    placement_receipt_path = resolve_state_path(root, state, "placement_planning_receipt")
    budget_receipt = validate_budget(build_state, "planning", write_receipt=True)
    budget_receipt_path = resolve_state_path(root, state, "budget_planning_receipt")
    dynamic_receipt = validate_dynamic_state(build_state, "planning", write_receipt=True)
    dynamic_receipt_path = resolve_state_path(root, state, "dynamic_state_planning_receipt")
    naming_receipt = validate_entry_naming(build_state, write_receipt=True)
    naming_receipt_path = resolve_state_path(root, state, "entry_naming_planning_receipt", required=False) or (root / "artifacts" / "entry-naming-planning-gate.json")
    integration_receipt = validate_integration(build_state, "planning", write_receipt=True)
    integration_receipt_path = resolve_state_path(root, state, "integration_planning_receipt")
    identity=load_json(identity_path)
    if not isinstance(identity,dict) or identity.get("kind") != "worldbuilder-manifest-identity-receipt" or identity.get("build_id") != build_id or identity.get("manifest_sha256") != manifest_sha: raise WorldBuilderError(f"identity receipt is missing or stale. Re-run: {sys.executable or 'python'} {Path(__file__).resolve().parent}/manifest_identity.py --build-state {Path(build_state).resolve()} after any manifest change")
    fingerprint=load_json(build_id_path)
    if not isinstance(fingerprint,dict) or fingerprint.get("build_id") != build_id or fingerprint.get("manifest_sha256") != manifest_sha or fingerprint.get("entry_count") != count_entries(manifest): raise WorldBuilderError(f"build-id.json is stale (does not match the current manifest's build_id/hash/entry count). Re-run: {sys.executable or 'python'} {Path(__file__).resolve().parent}/manifest_identity.py --build-state {Path(build_state).resolve()}")
    artifact_hashes: dict[str,str] = {}
    for kind,path in (("build_list",build_list_path),("recursion_map",recursion_path)):
        value=header(path)
        if value.get("kind") != kind or value.get("build_id") != build_id or value.get("manifest_sha256") != manifest_sha: raise WorldBuilderError(f"{path.name}'s header does not match the current manifest (kind={value.get('kind')!r} expected {kind!r}, build_id={value.get('build_id')!r} expected {build_id!r}, or manifest_sha256 is stale); re-author {path.name} against the current manifest per references/lorebook-architecture.md")
        if discovery_sha and value.get("discovery_receipt_sha256") != discovery_sha: raise WorldBuilderError(f"{path.name}'s header discovery_receipt_sha256 does not match the current discovery receipt; re-author {path.name} against the current discovery receipt")
        artifact_hashes[kind]=sha256_file(path)
    receipt_path=resolve_state_path(root,state,"planning_receipt")
    receipt={"kind":"worldbuilder-planning-gate","receipt_version":2,"status":"passed","build_id":build_id,"discovery_status":discovery_status,
        "discovery_receipt":str(discovery_path.relative_to(root)).replace("\\","/") if discovery_path else None,"discovery_receipt_sha256":discovery_sha,
        "manifest":str(manifest_path.relative_to(root)).replace("\\","/"),"manifest_sha256":manifest_sha,
        "build_conditions_required":build_conditions_check["required"],"build_conditions_matched":build_conditions_check["matched"],
        "image_analysis_recorded":image_analysis_check["recorded"],"effective_image_mode":image_analysis_check["effective"],
        "identity_receipt":str(identity_path.relative_to(root)).replace("\\","/"),"identity_receipt_sha256":sha256_file(identity_path),
        "architecture_receipt":str(architecture_receipt_path.relative_to(root)).replace("\\","/"),
        "architecture_receipt_sha256":sha256_file(architecture_receipt_path),
        "architecture_contract":architecture_receipt.get("contract"),
        "activation_map_receipt":str(activation_receipt_path.relative_to(root)).replace("\\","/"),
        "activation_map_receipt_sha256":sha256_file(activation_receipt_path),
        "activation_contract":activation_receipt.get("contract"),
        "activation_map_sha256":activation_receipt.get("recursion_map_sha256"),
        "activation_test_corpus_contract":activation_test_receipt.get("contract"),
        "activation_test_corpus_status":activation_test_receipt.get("status"),
        "activation_test_corpus":activation_test_receipt.get("corpus"),
        "activation_test_corpus_sha256":activation_test_receipt.get("corpus_sha256"),
        "activation_test_corpus_receipt":str(activation_test_receipt_path.relative_to(root)).replace("\\","/") if activation_test_receipt_path and activation_test_receipt_path.exists() else None,
        "activation_test_corpus_receipt_sha256":sha256_file(activation_test_receipt_path) if activation_test_receipt_path and activation_test_receipt_path.exists() else None,
        "activation_test_case_count":activation_test_receipt.get("case_count",0),
        "era_router_contract":era_router_receipt.get("contract"),
        "era_router_status":era_router_receipt.get("status"),
        "era_router_receipt":str(era_router_receipt_path.relative_to(root)).replace("\\","/") if era_router_receipt_path and era_router_receipt_path.exists() else None,
        "era_router_receipt_sha256":sha256_file(era_router_receipt_path) if era_router_receipt_path and era_router_receipt_path.exists() else None,
        "era_plan_sha256":era_router_receipt.get("era_plan_sha256"),
        "era_count":era_router_receipt.get("era_count",0),
        "era_context_count":era_router_receipt.get("era_context_count",0),
        "era_active_entity_edge_count":era_router_receipt.get("active_entity_edge_count",0),
        "placement_contract":placement_receipt.get("contract"),
        "placement_receipt":str(placement_receipt_path.relative_to(root)).replace("\\","/"),
        "placement_receipt_sha256":sha256_file(placement_receipt_path),
        "placement_plan_sha256":placement_receipt.get("placement_plan_sha256"),
        "placement_entry_count":placement_receipt.get("entry_count",0),
        "placement_extended_count":placement_receipt.get("extended_position_count",0),
        "placement_warnings":placement_receipt.get("warnings",[]),
        "budget_contract":budget_receipt.get("contract"),
        "budget_receipt":str(budget_receipt_path.relative_to(root)).replace("\\","/"),
        "budget_receipt_sha256":sha256_file(budget_receipt_path),
        "budget_plan_sha256":budget_receipt.get("budget_plan_sha256"),
        "budget_profile_id":budget_receipt.get("profile_id"),
        "budget_constant_tokens":budget_receipt.get("constant_tokens",0),
        "budget_corpus_authored_tokens":budget_receipt.get("corpus_authored_tokens",0),
        "budget_simulations":budget_receipt.get("simulations",[]),
        "budget_warnings":budget_receipt.get("warnings",[]),
        "dynamic_state_contract":dynamic_receipt.get("contract"),
        "dynamic_state_receipt":str(dynamic_receipt_path.relative_to(root)).replace("\\","/"),
        "dynamic_state_receipt_sha256":sha256_file(dynamic_receipt_path),
        "dynamic_state_plan_sha256":dynamic_receipt.get("dynamic_state_plan_sha256"),
        "dynamic_state_policy":dynamic_receipt.get("policy"),
        "dynamic_state_operation_count":dynamic_receipt.get("dynamic_entry_count",0),
        "dynamic_state_group_count":dynamic_receipt.get("group_count",0),
        "dynamic_state_warnings":dynamic_receipt.get("warnings",[]),
        "entry_naming_contract":naming_receipt.get("contract"),
        "entry_naming_receipt":str(naming_receipt_path.relative_to(root)).replace("\\","/"),
        "entry_naming_receipt_sha256":sha256_file(naming_receipt_path),
        "entry_naming_entry_count":naming_receipt.get("entry_count",0),
        "full_integration_contract":integration_receipt.get("contract"),
        "integration_receipt":str(integration_receipt_path.relative_to(root)).replace("\\","/"),
        "integration_receipt_sha256":sha256_file(integration_receipt_path),
        "integration_plan_sha256":integration_receipt.get("integration_plan_sha256"),
        "integration_pipeline":integration_receipt.get("pipeline"),
        "integration_required_systems":integration_receipt.get("required_systems",[]),
        "field_registry_sha256":activation_receipt.get("field_registry_sha256"),
        "default_profile_sha256":activation_receipt.get("default_profile_sha256"),
        "activation_edge_count":activation_receipt.get("edge_count"),
        "character_system_contract":architecture_receipt.get("character_system_contract"),
        "character_plan":architecture_receipt.get("character_plan"),
        "character_plan_sha256":architecture_receipt.get("character_plan_sha256"),
        "character_identity_count":architecture_receipt.get("character_identities"),
        "character_state_count":architecture_receipt.get("character_states"),
        "character_relationship_count":architecture_receipt.get("character_relationships"),
        "era_mode":architecture_receipt.get("era_mode"),
        "build_id_sha256":sha256_file(build_id_path),**artifact_hashes,"entry_count":count_entries(manifest)}
    atomic_write_json(receipt_path,receipt); state.setdefault("status",{})["planning"]="complete"; state.setdefault("lineage",{})["planning_receipt_sha256"]=sha256_file(receipt_path); state["lineage"]["manifest_sha256"]=manifest_sha; state["lineage"]["character_plan_sha256"]=architecture_receipt.get("character_plan_sha256"); state["lineage"]["era_plan_sha256"]=era_router_receipt.get("era_plan_sha256"); state["lineage"]["placement_plan_sha256"]=placement_receipt.get("placement_plan_sha256"); state["lineage"]["budget_plan_sha256"]=budget_receipt.get("budget_plan_sha256"); state["lineage"]["dynamic_state_plan_sha256"]=dynamic_receipt.get("dynamic_state_plan_sha256"); state["lineage"]["entry_naming_planning_receipt_sha256"]=sha256_file(naming_receipt_path); state["lineage"]["integration_plan_sha256"]=integration_receipt.get("integration_plan_sha256"); state["lineage"]["integration_planning_receipt_sha256"]=sha256_file(integration_receipt_path); atomic_write_json(Path(build_state).resolve(),state)
    advance_pipeline_stage(Path(build_state).resolve(), "planning_validated")
    return {"status":"passed","receipt":str(receipt_path),"entries":receipt["entry_count"]}

def _projection_checks(root: Path, state: dict[str, Any], build_state: str) -> list[dict[str, Any]]:
    """Report all manifest-bound projection freshness problems at once.

    Legacy/minimal diagnostic states may omit the manifest path entirely; those
    states keep the pre-existing validator sweep and simply skip this modern
    projection check instead of crashing.
    """
    paths = state.get("paths") if isinstance(state.get("paths"), dict) else {}
    if "manifest" not in paths:
        return [{"check": "projection_freshness", "status": "skipped", "reason": "legacy/minimal diagnostic state has no manifest path"}]
    manifest_path = resolve_state_path(root, state, "manifest", required=False)
    if manifest_path is None or not manifest_path.exists():
        return [{"check": "projection_freshness", "status": "failed", "error": f"manifest is missing: {manifest_path}", "fix_command": "restore or author the manifest before rebinding projections"}]
    manifest_sha = sha256_file(manifest_path)
    script_dir = Path(__file__).resolve().parent
    checks: list[dict[str, Any]] = []

    def add_json(key: str, label: str, fix_command: str) -> None:
        path = resolve_state_path(root, state, key, required=False)
        if path is None or not path.exists():
            checks.append({"check": label, "status": "failed", "error": f"{label} is missing", "fix_command": fix_command})
            return
        try:
            data = load_json(path)
            bound = data.get("manifest_sha256") if isinstance(data, dict) else None
            if bound != manifest_sha:
                checks.append({"check": label, "status": "failed", "error": f"{label} is stale or mismatched at manifest_sha256", "fix_command": fix_command})
            else:
                checks.append({"check": label, "status": "ok"})
        except Exception as exc:
            checks.append({"check": label, "status": "failed", "error": f"{type(exc).__name__}: {exc}", "fix_command": fix_command})

    # build-id and identity are JSON projections.
    add_json("build_id", "build_id_projection", f"{sys.executable or 'python'} {script_dir / 'manifest_identity.py'} --build-state {Path(build_state).resolve()}")
    add_json("identity_receipt", "identity_receipt_projection", f"{sys.executable or 'python'} {script_dir / 'manifest_identity.py'} --build-state {Path(build_state).resolve()}")

    # Human-readable projections use the WORLDBUILDER-ARTIFACT JSON header.
    for key, label, fix in (
        ("recursion_map", "recursion_map_projection", f"{sys.executable or 'python'} {script_dir / 'activation_map_gate.py'} --build-state {Path(build_state).resolve()} --render"),
        ("build_list", "build_list_projection", f"{sys.executable or 'python'} {script_dir / 'build_list_rebind.py'} --build-state {Path(build_state).resolve()}"),
    ):
        path = resolve_state_path(root, state, key, required=False)
        if path is None or not path.exists():
            checks.append({"check": label, "status": "failed", "error": f"{label} is missing", "fix_command": fix})
            continue
        try:
            bound = header(path).get("manifest_sha256")
            if bound != manifest_sha:
                checks.append({"check": label, "status": "failed", "error": f"{label} is stale or mismatched at manifest_sha256", "fix_command": fix})
            else:
                checks.append({"check": label, "status": "ok"})
        except (WorldBuilderError, OSError, ValueError, json.JSONDecodeError) as exc:
            checks.append({"check": label, "status": "failed", "error": str(exc), "fix_command": fix})
    return checks


def diagnose(build_state: str) -> dict[str, Any]:
    """Run every planning validator independently and report ALL failures at
    once, instead of the normal fail-on-first-error chain in ``validate()``.

    Read-only: every call passes write_receipt=False, so nothing is written to
    disk. This is a diagnostic aid, never a substitute for a real passing
    ``planning_gate.py`` run; later checks can depend on artifacts an earlier
    check would normally produce, so a failure here does not always mean an
    independent root cause; it may be a downstream echo of the first one.
    Read results top-to-bottom and fix the first failure first."""
    root, state = load_build_state(build_state)
    results: list[dict[str, Any]] = []
    results.extend(_projection_checks(root, state, build_state))

    def attempt(name: str, fn, *fn_args, **fn_kwargs) -> None:
        try:
            fn(*fn_args, write_receipt=False, **fn_kwargs)
            results.append({"check": name, "status": "ok"})
        except WorldBuilderError as exc:
            results.append({"check": name, "status": "failed", "error": str(exc)})
        except Exception as exc:  # a single unexpected crash must not abort the sweep
            results.append({"check": name, "status": "crashed", "error": f"{type(exc).__name__}: {exc}"})

    try:
        validate_discovery(root, state)
        results.append({"check": "discovery_binding", "status": "ok"})
    except WorldBuilderError as exc:
        results.append({"check": "discovery_binding", "status": "failed", "error": str(exc)})

    try:
        image_analysis_check = validate_effective_image_mode(state)
        results.append({"check": "image_analysis_resolution", "status": "ok" if image_analysis_check["recorded"] else "skipped", "effective": image_analysis_check["effective"]})
    except WorldBuilderError as exc:
        results.append({"check": "image_analysis_resolution", "status": "failed", "error": str(exc)})

    state_paths = state.get("paths") if isinstance(state.get("paths"), dict) else {}
    if "manifest" in state_paths:
        manifest_path = resolve_state_path(root, state, "manifest")
        if not manifest_path.exists():
            results.append({"check": "build_conditions", "status": "failed", "error": f"manifest is missing: {manifest_path}"})
        else:
            try:
                manifest = load_json(manifest_path)
                validate_build_conditions(state, manifest)
                results.append({"check": "build_conditions", "status": "ok"})
            except (WorldBuilderError, OSError, ValueError, json.JSONDecodeError) as exc:
                results.append({"check": "build_conditions", "status": "failed", "error": str(exc)})
    else:
        results.append({"check": "build_conditions", "status": "skipped", "reason": "legacy/minimal diagnostic state has no manifest path"})

    attempt("architecture", validate_architecture, build_state, "planning")
    attempt("activation_map", validate_activation_map, build_state)
    if "manifest" in state_paths:
        attempt("activation_test_corpus", check_activation_test_corpus, build_state, freeze_if_needed=False, enforce=True)
    else:
        results.append({"check": "activation_test_corpus", "status": "skipped", "reason": "legacy/minimal diagnostic state has no manifest path"})
    attempt("era_router", validate_era_router, build_state, "planning")
    attempt("placement", validate_placement, build_state, "planning")
    attempt("budget", validate_budget, build_state, "planning")
    attempt("dynamic_state", validate_dynamic_state, build_state, "planning")
    attempt("entry_naming", validate_entry_naming, build_state)
    results.append({"check": "integration", "status": "skipped", "reason": "read-only diagnose does not write the architecture receipt that planning integration acceptance requires"})

    failed = [row for row in results if row["status"] not in {"ok", "skipped"}]
    return {
        "status": "clean" if not failed else "problems_found",
        "contract": "worldbuilder-planning-diagnose-v1",
        "note": (
            "Read-only sweep; nothing was written. Fix checks in the order listed; a later failure "
            "may simply be a downstream echo of an earlier one, not an independent problem. Run "
            "planning_gate.py again without --diagnose once every runnable check here reads ok; intentionally skipped checks are not failures."
        ),
        "checks": results,
        "failed_count": len(failed),
    }


def main() -> int:
    parser=argparse.ArgumentParser(description=__doc__); parser.add_argument("--build-state",required=True)
    parser.add_argument("--diagnose", action="store_true", help="Read-only sweep: run every planning validator and report all failures at once instead of stopping at the first.")
    args=parser.parse_args()
    try:
        if args.diagnose:
            report = diagnose(args.build_state)
            print(json.dumps(report, ensure_ascii=False, indent=2))
            return 0 if report["status"] == "clean" else 1
        print(json.dumps(validate(args.build_state),ensure_ascii=False,indent=2)); return 0
    except (WorldBuilderError,OSError,ValueError,json.JSONDecodeError) as exc: print(f"ERROR: {exc}",file=sys.stderr); print(step_driver_pointer(), file=sys.stderr); return 1
if __name__=="__main__": raise SystemExit(main())
