#!/usr/bin/env python3
"""Batch 7, 7.9: capability tiers.

Inverts the old assumption: the tooling used to assume WorldBuilder lineage
and degrade badly without it. It now assumes any lorebook and adds
capability when lineage is present and verifiable.

    Unbound       any lorebook: hand-made, third-party, or a WorldBuilder
                  delivery whose workspace is gone. structural edit,
                  derived activation graph, diff proof, format validation,
                  import probe.
    Legacy-bound  carries the worldbuilder_provenance marker (7.9,
                  runtime_target_adapter.py) but no live, matching
                  workspace was given to verify it against. Above +
                  lineage reading, entry-naming normalization, migration.
    Bound         the marker matches a live build-state's build_id AND
                  that build's CURRENT manifest_sha256, not just a
                  marker that once existed. Above + manifest authority,
                  declared protected categories, frozen plans, full
                  receipt chain.

The tier is reported up front, not discovered three steps into some other
operation as a gate error; detect_tier is meant to be the first thing
any "audit an existing artifact" workflow calls.

No delivered artifact before this batch carries any marker at all, so
every pre-existing delivery is correctly Unbound until re-exported.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

from wb_common import WorldBuilderError, load_build_state, load_json
from runtime_target_adapter import PROVENANCE_KEY

CONTRACT = "worldbuilder-capability-tiers-v1"

TIER_CAPABILITIES = {
    "unbound": (
        "structural_edit", "derived_activation_graph", "diff_proof", "format_validation", "import_probe",
    ),
    "legacy_bound": (
        "structural_edit", "derived_activation_graph", "diff_proof", "format_validation", "import_probe",
        "worldbuilder_lineage_reading", "entry_naming_normalization", "migration",
    ),
    "bound": (
        "structural_edit", "derived_activation_graph", "diff_proof", "format_validation", "import_probe",
        "worldbuilder_lineage_reading", "entry_naming_normalization", "migration",
        "manifest_authority", "declared_protected_categories", "frozen_plans", "full_receipt_chain",
    ),
}

# 7.9: Unbound has no declared protected set (no manifest to declare one), so
# a heuristic prune could delete something critical it does not recognize (
# an era root, an identity kernel) without knowing it was protected. Prune
# revamp consumes this directly; recorded here since it is a property of the
# tier itself, not of whatever operation later reads it.
UNBOUND_MAX_PRUNE_TIER = 1


def _find_marker(artifact: Any) -> dict[str, Any] | None:
    """The provenance marker, wherever _stamp_provenance put it (card
    extensions, lorebook extensions, or both; checked in that order,
    since a mismatch between the two would itself be a red flag, not
    something to silently resolve by picking one)."""
    if not isinstance(artifact, dict):
        return None
    data = artifact.get("data") if isinstance(artifact.get("data"), dict) else artifact
    candidates: list[Any] = []
    card_ext = data.get("extensions") if isinstance(data.get("extensions"), dict) else None
    if card_ext is not None and PROVENANCE_KEY in card_ext:
        candidates.append(card_ext[PROVENANCE_KEY])
    book = data.get("character_book") if isinstance(data.get("character_book"), dict) else data
    book_ext = book.get("extensions") if isinstance(book, dict) and isinstance(book.get("extensions"), dict) else None
    if book_ext is not None and PROVENANCE_KEY in book_ext:
        candidates.append(book_ext[PROVENANCE_KEY])
    if not candidates:
        return None
    first = candidates[0]
    for other in candidates[1:]:
        if other != first:
            raise WorldBuilderError(
                "provenance markers disagree between card and lorebook extensions: this artifact was "
                "hand-edited or assembled from mismatched pieces after export; treat it as Unbound rather "
                "than trust either marker"
            )
    return first if isinstance(first, dict) else None


def detect_tier(artifact: Any, *, build_state_path: Path | None = None) -> dict[str, Any]:
    """Reports the tier up front. build_state_path is optional; without it,
    a marker can only ever prove Legacy-bound, never Bound; Bound
    requires verifying the marker against a live, matching workspace, not
    just trusting what the marker itself claims."""
    marker = _find_marker(artifact)
    if marker is None:
        return {
            "contract": CONTRACT, "tier": "unbound", "capabilities": list(TIER_CAPABILITIES["unbound"]),
            "reason": "no worldbuilder_provenance marker found",
            "unbound_max_prune_tier": UNBOUND_MAX_PRUNE_TIER,
        }

    if build_state_path is not None:
        try:
            root, state = load_build_state(str(build_state_path))
        except (WorldBuilderError, OSError, json.JSONDecodeError):
            root, state = None, None
        if state is not None:
            live_build_id = str(state.get("build_id"))
            live_manifest_sha256 = state.get("lineage", {}).get("manifest_sha256")
            if marker.get("build_id") == live_build_id and marker.get("manifest_sha256") == live_manifest_sha256 and live_manifest_sha256 is not None:
                return {
                    "contract": CONTRACT, "tier": "bound", "capabilities": list(TIER_CAPABILITIES["bound"]),
                    "reason": f"marker matches live build {live_build_id!r} at its current manifest",
                    "build_id": live_build_id, "manifest_sha256": live_manifest_sha256,
                }
            return {
                "contract": CONTRACT, "tier": "legacy_bound", "capabilities": list(TIER_CAPABILITIES["legacy_bound"]),
                "reason": (
                    f"marker claims build {marker.get('build_id')!r}, but --build-state is "
                    f"{live_build_id!r} at a different manifest. The workspace given does not verify this "
                    "artifact; treated as Legacy-bound, not Bound"
                ),
                "marker": marker,
            }

    return {
        "contract": CONTRACT, "tier": "legacy_bound", "capabilities": list(TIER_CAPABILITIES["legacy_bound"]),
        "reason": "worldbuilder_provenance marker present, but no --build-state was given to verify it against",
        "marker": marker,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--artifact", required=True)
    parser.add_argument("--build-state", help="Optional. Without it, a marker can only prove Legacy-bound.")
    args = parser.parse_args()
    try:
        result = detect_tier(
            load_json(Path(args.artifact)),
            build_state_path=Path(args.build_state) if args.build_state else None,
        )
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (WorldBuilderError, OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
