#!/usr/bin/env python3
"""Repair legacy discovery-result encoding or concatenation with an audit receipt."""
from __future__ import annotations
import argparse
import hashlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from wb_common import WorldBuilderError, atomic_write_json, sha256_file

def now() -> str: return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00","Z")

def decode_bytes(raw: bytes, encoding: str) -> tuple[str,str]:
    choices=[encoding] if encoding!="auto" else ["utf-8-sig","utf-8","cp1252","latin-1"]
    errors=[]
    for choice in choices:
        try: return raw.decode(choice),choice
        except UnicodeDecodeError as exc: errors.append(f"{choice}: {exc}")
    raise WorldBuilderError("could not decode input: "+"; ".join(errors))

def main() -> int:
    parser=argparse.ArgumentParser(description=__doc__); parser.add_argument("--input",required=True); parser.add_argument("--output",required=True); parser.add_argument("--encoding",default="auto"); parser.add_argument("--salvage-first-json",action="store_true"); parser.add_argument("--operator",required=True); args=parser.parse_args()
    try:
        source=Path(args.input).resolve(); output=Path(args.output).resolve(); raw=source.read_bytes(); before=hashlib.sha256(raw).hexdigest(); text,used=decode_bytes(raw,args.encoding); stripped=text.lstrip("\ufeff\t\r\n "); decoder=json.JSONDecoder()
        try: value,end=decoder.raw_decode(stripped)
        except json.JSONDecodeError as exc: raise WorldBuilderError(f"input has no valid first JSON value: {exc}") from exc
        trailing=stripped[end:]; discarded=len(trailing.encode(used,errors="replace")) if trailing.strip() else 0
        if trailing.strip() and not args.salvage_first_json: raise WorldBuilderError("input contains trailing/concatenated data; use --salvage-first-json")
        if not isinstance(value,dict): raise WorldBuilderError("discovery result must be a JSON object")
        atomic_write_json(output,value)
        receipt={"kind":"worldbuilder-discovery-repair","receipt_version":1,"created_at":now(),"operator":args.operator,"input":str(source),"input_sha256":before,"output":str(output),"output_sha256":sha256_file(output),"source_encoding":used,"salvaged_first_json":bool(trailing.strip()),"discarded_byte_count":discarded,"metadata_rebound":False}
        receipt_path=output.with_suffix(output.suffix+".repair.json"); atomic_write_json(receipt_path,receipt); print(json.dumps({"status":"repaired","output":str(output),"receipt":str(receipt_path),"discarded_bytes":discarded},indent=2)); return 0
    except (WorldBuilderError,OSError,ValueError,json.JSONDecodeError) as exc: print(f"ERROR: {exc}",file=sys.stderr); return 1
if __name__=="__main__": raise SystemExit(main())
