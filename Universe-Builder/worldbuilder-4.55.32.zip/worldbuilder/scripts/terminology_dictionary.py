#!/usr/bin/env python3
"""Build and query the project-wide canonical terminology dictionary.

The dictionary freezes preferred spelling/capitalization/title metadata for one
planned build. It never rewrites activation keys and never treats fuzzy matches
or shared titles as identity authority.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from pathlib import Path
from typing import Any

from wb_common import WorldBuilderError, atomic_write_json, canonical_entry_identity, iter_entries, load_json, sha256_file

CONTRACT = "worldbuilder-terminology-dictionary-v1"
KIND = "worldbuilder-terminology-dictionary"
VERSION = 1
SEMANTIC_PREFIX_RE = re.compile(r"^[A-Z][A-Z ]*\s*:\s*(.+)$", re.IGNORECASE)


def normalize_term(value: Any) -> str:
    return re.sub(r"\s+", " ", str(value or "").strip()).casefold()


def clean_term(value: Any) -> str:
    return re.sub(r"\s+", " ", str(value or "").strip())


def _strip_prefix(value: str) -> str:
    match = SEMANTIC_PREFIX_RE.fullmatch(clean_term(value))
    return clean_term(match.group(1)) if match else clean_term(value)


def _string_list(value: Any, field: str) -> list[str]:
    if value in (None, ""):
        return []
    if not isinstance(value, list):
        raise WorldBuilderError(f"terminology field {field!r} must be a list of strings")
    result: list[str] = []
    seen: set[str] = set()
    for raw in value:
        item = clean_term(raw)
        if not item:
            raise WorldBuilderError(f"terminology field {field!r} contains an empty item")
        marker = normalize_term(item)
        if marker not in seen:
            seen.add(marker)
            result.append(item)
    return result


def _canonical_for(entry: dict[str, Any]) -> str:
    for field in ("canonical_name", "name", "title"):
        value = _strip_prefix(clean_term(entry.get(field)))
        if value:
            return value
    display = _strip_prefix(clean_term(entry.get("display_name")))
    if display:
        return display
    identity = canonical_entry_identity(entry)
    if identity is not None:
        return f"Entry {identity}"
    raise WorldBuilderError("manifest entry has no canonical terminology source")


def _term_id(canonical: str) -> str:
    digest = hashlib.sha256(normalize_term(canonical).encode("utf-8")).hexdigest()[:16]
    return f"term-{digest}"


def build_dictionary(manifest: dict[str, Any], *, build_id: str | None = None, manifest_sha256: str | None = None) -> dict[str, Any]:
    rows = list(iter_entries(manifest))
    if not rows:
        raise WorldBuilderError("terminology dictionary requires a non-empty manifest")

    grouped: dict[str, dict[str, Any]] = {}
    alias_owner: dict[str, str] = {}
    title_owners: dict[str, set[str]] = {}

    for ref in rows:
        entry = ref.entry
        canonical = _canonical_for(entry)
        canon_norm = normalize_term(canonical)
        identity = canonical_entry_identity(entry)
        aliases = _string_list(entry.get("aliases"), "aliases")
        titles = _string_list(entry.get("titles"), "titles")

        row = grouped.get(canon_norm)
        if row is None:
            row = {
                "term_id": _term_id(canonical),
                "canonical": canonical,
                "normalized": canon_norm,
                "aliases": [],
                "titles": [],
                "source_uids": [],
            }
            grouped[canon_norm] = row
        # First established canonical spelling/capitalization wins for the
        # normalized term inside this frozen planning cycle.
        if identity is not None and identity not in row["source_uids"]:
            row["source_uids"].append(identity)

        names = [canonical, *aliases]
        for name in names:
            marker = normalize_term(name)
            owner = alias_owner.get(marker)
            if owner is not None and owner != canon_norm:
                raise WorldBuilderError(
                    f"terminology alias {name!r} resolves to more than one canonical term: "
                    f"{grouped[owner]['canonical']!r} and {row['canonical']!r}"
                )
            alias_owner[marker] = canon_norm
            if marker != canon_norm and all(normalize_term(existing) != marker for existing in row["aliases"]):
                row["aliases"].append(name)

        for title in titles:
            marker = normalize_term(title)
            if all(normalize_term(existing) != marker for existing in row["titles"]):
                row["titles"].append(title)
            title_owners.setdefault(marker, set()).add(canon_norm)

    terms = sorted(grouped.values(), key=lambda row: (row["normalized"], row["term_id"]))
    for row in terms:
        row["source_uids"] = sorted(row["source_uids"], key=lambda x: str(x))

    ambiguous_titles = []
    for marker, owners in sorted(title_owners.items()):
        if len(owners) > 1:
            ambiguous_titles.append({
                "title": next(
                    title
                    for row in terms
                    for title in row["titles"]
                    if normalize_term(title) == marker
                ),
                "canonical_terms": sorted(grouped[owner]["canonical"] for owner in owners),
            })

    return {
        "kind": KIND,
        "dictionary_version": VERSION,
        "contract": CONTRACT,
        "build_id": build_id,
        "manifest_sha256": manifest_sha256,
        "terms": terms,
        "ambiguous_titles": ambiguous_titles,
    }


def validate_dictionary(data: Any, *, expected_manifest_sha256: str | None = None) -> dict[str, Any]:
    if not isinstance(data, dict) or data.get("kind") != KIND or data.get("contract") != CONTRACT or data.get("dictionary_version") != VERSION:
        raise WorldBuilderError("terminology dictionary has the wrong kind/contract/version")
    if expected_manifest_sha256 is not None and data.get("manifest_sha256") != expected_manifest_sha256:
        raise WorldBuilderError("terminology dictionary is stale relative to the current manifest")
    terms = data.get("terms")
    if not isinstance(terms, list) or not terms:
        raise WorldBuilderError("terminology dictionary must contain a non-empty terms list")
    seen_aliases: dict[str, str] = {}
    for row in terms:
        if not isinstance(row, dict):
            raise WorldBuilderError("terminology dictionary term must be an object")
        canonical = clean_term(row.get("canonical"))
        if not canonical or row.get("normalized") != normalize_term(canonical) or row.get("term_id") != _term_id(canonical):
            raise WorldBuilderError("terminology dictionary term canonical/normalized/id fields disagree")
        aliases = _string_list(row.get("aliases", []), "aliases")
        _string_list(row.get("titles", []), "titles")
        for value in [canonical, *aliases]:
            marker = normalize_term(value)
            owner = seen_aliases.get(marker)
            if owner is not None and owner != canonical:
                raise WorldBuilderError(f"terminology dictionary alias {value!r} is ambiguous")
            seen_aliases[marker] = canonical
    return data


def resolve_term(data: dict[str, Any], value: str) -> dict[str, Any]:
    validate_dictionary(data)
    marker = normalize_term(value)
    if not marker:
        raise WorldBuilderError("terminology lookup value is empty")
    direct: list[dict[str, Any]] = []
    titled: list[dict[str, Any]] = []
    for row in data["terms"]:
        if marker == row["normalized"] or any(normalize_term(alias) == marker for alias in row.get("aliases", [])):
            direct.append(row)
        if any(normalize_term(title) == marker for title in row.get("titles", [])):
            titled.append(row)
    if len(direct) == 1:
        row = direct[0]
        return {"status": "resolved", "match": "canonical_or_alias", "canonical": row["canonical"], "term_id": row["term_id"]}
    if len(direct) > 1:
        raise WorldBuilderError(f"terminology lookup {value!r} is ambiguous across canonical names/aliases")
    if len(titled) == 1:
        row = titled[0]
        return {"status": "resolved", "match": "unique_title", "canonical": row["canonical"], "term_id": row["term_id"]}
    if len(titled) > 1:
        return {"status": "ambiguous", "match": "shared_title", "canonical_terms": sorted(row["canonical"] for row in titled)}
    return {"status": "not_found", "match": None, "canonical": None}


def canonicalize_term(data: dict[str, Any] | None, value: str) -> str:
    if not isinstance(data, dict) or not clean_term(value):
        return clean_term(value)
    result = resolve_term(data, value)
    return str(result["canonical"]) if result.get("status") == "resolved" else clean_term(value)


def write_dictionary(manifest_path: str | Path, output_path: str | Path, *, build_id: str | None = None) -> dict[str, Any]:
    manifest_file = Path(manifest_path).resolve()
    output_file = Path(output_path).resolve()
    manifest = load_json(manifest_file)
    if not isinstance(manifest, dict):
        raise WorldBuilderError("manifest must be an object")
    manifest_sha = sha256_file(manifest_file)
    data = build_dictionary(manifest, build_id=build_id, manifest_sha256=manifest_sha)
    output_file.parent.mkdir(parents=True, exist_ok=True)
    atomic_write_json(output_file, data)
    return {"status": "passed", "contract": CONTRACT, "dictionary": str(output_file), "dictionary_sha256": sha256_file(output_file), "term_count": len(data["terms"])}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    build = sub.add_parser("build")
    build.add_argument("--manifest", required=True)
    build.add_argument("--output", required=True)
    build.add_argument("--build-id")
    check = sub.add_parser("validate")
    check.add_argument("--dictionary", required=True)
    check.add_argument("--manifest-sha256")
    resolve = sub.add_parser("resolve")
    resolve.add_argument("--dictionary", required=True)
    resolve.add_argument("--value", required=True)
    args = parser.parse_args()
    try:
        if args.command == "build":
            result = write_dictionary(args.manifest, args.output, build_id=args.build_id)
        else:
            data = load_json(Path(args.dictionary).resolve())
            if args.command == "validate":
                validate_dictionary(data, expected_manifest_sha256=args.manifest_sha256)
                result = {"status": "passed", "contract": CONTRACT, "dictionary_sha256": sha256_file(Path(args.dictionary).resolve())}
            else:
                result = resolve_term(data, args.value)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (WorldBuilderError, OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"TERMINOLOGY DICTIONARY BLOCKED: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
