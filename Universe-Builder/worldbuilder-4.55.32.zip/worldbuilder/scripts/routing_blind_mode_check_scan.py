"""Standing regression test for the routing-blind mode-check bug class.

Confirmed across four real, independently-discovered instances this
session (era_router_contract.py, architecture_gate.py x3,
era_router_contract.py's skip-branch receipt, activation_map_gate.py):
`era_cfg.get("mode") == "multi"` used as a requirement/gate condition
without also checking `routing` silently breaks root_toggle builds,
since root_toggle never writes the Scenario-shaped era plan that
"multi" alone implies a need for.

This is a mechanical, line-level scan with a small, explicit allowlist
for confirmed-correct exceptions, not a full static-analysis tool.
Its job is to catch a fifth occurrence of the exact pattern that has
already recurred four times, not to prove correctness generally.
"""
from __future__ import annotations

import re
from pathlib import Path

# Confirmed correct on inspection this session: era_router being a
# required *system* for every multi-era build regardless of routing is
# intentional (Batch 51's own fix depends on this), not an instance of
# the bug this test exists to catch.
ALLOWLIST = {
    ("integration_acceptance.py", 'if era_mode == "multi" and "era_router" not in systems:'),
}

MODE_CHECK_RE = re.compile(r'era_cfg(?:\.get\(\s*["\']mode["\']\s*\)|\[\s*["\']mode["\']\s*\])\s*==\s*["\']multi["\']')
ROUTING_WORD_RE = re.compile(r"\brouting\b")


def find_routing_blind_mode_checks(scripts_dir: Path) -> list[dict[str, object]]:
    """Scan every real .py file under scripts_dir for a mode=="multi"
    check with no mention of "routing" within 2 lines either side, and
    not on the explicit allowlist. Returns real, reviewable hits, not
    just a pass/fail; each includes the file, line number, and text."""
    violations: list[dict[str, object]] = []
    for path in sorted(scripts_dir.glob("*.py")):
        lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
        for i, line in enumerate(lines):
            if not MODE_CHECK_RE.search(line):
                continue
            if (path.name, line.strip()) in ALLOWLIST:
                continue
            window = "\n".join(lines[max(0, i - 2): i + 3])
            if ROUTING_WORD_RE.search(window):
                continue
            violations.append({"file": path.name, "line_number": i + 1, "text": line.strip()})
    return violations
