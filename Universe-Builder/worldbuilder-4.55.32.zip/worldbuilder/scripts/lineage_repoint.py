#!/usr/bin/env python3
"""Sanctioned repoint of post-merge lineage to corrected artifact bytes.

This operation is intentionally narrow: it synchronizes merge_input and the
immutable context-budget snapshot to one reviewed target, records old/new hashes
and reason, and updates build-state lineage. It never edits the manifest or phase
files and cannot be used without a non-empty reason.
"""
from __future__ import annotations
import argparse, json, os, shutil, sys, time
from pathlib import Path
from wb_common import WorldBuilderError, atomic_write_json, load_build_state, resolve_state_path, sha256_file

CONTRACT="worldbuilder-lineage-repoint-v1"

def repoint(build_state: str|Path, target: str|Path, *, reason: str) -> dict:
    if not isinstance(reason,str) or not reason.strip(): raise WorldBuilderError("lineage repoint requires a non-empty reason")
    state_path=Path(build_state).resolve(); root,state=load_build_state(state_path)
    source=Path(target).expanduser().resolve()
    try: source.relative_to(root)
    except ValueError as exc: raise WorldBuilderError("lineage repoint target must stay inside the build workspace") from exc
    if not source.is_file(): raise WorldBuilderError(f"lineage repoint target is missing: {source}")
    merge=resolve_state_path(root,state,"merge_input")
    before=sha256_file(merge) if merge.exists() else None
    if source != merge: shutil.copy2(source,merge)
    context=resolve_state_path(root,state,"context_budget_before",required=False)
    if context is not None:
        context.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(merge,context)
    digest=sha256_file(merge)
    lineage=state.setdefault("lineage",{})
    merge_row=lineage.get("merge") if isinstance(lineage.get("merge"),dict) else {}
    merge_row=dict(merge_row); merge_row["sha256"]=digest; merge_row["repointed_from_sha256"]=before; merge_row["repoint_reason"]=reason.strip(); merge_row["repointed_at_unix"]=int(time.time()); lineage["merge"]=merge_row
    final=resolve_state_path(root,state,"final_output",required=False)
    if final and final.exists() and sha256_file(final)==digest:
        final_row=lineage.get("final") if isinstance(lineage.get("final"),dict) else {}
        final_row=dict(final_row); final_row["sha256"]=digest; final_row["repoint_reason"]=reason.strip(); lineage["final"]=final_row
    receipt_dir=root/".work"/"lineage-repoints"; receipt_dir.mkdir(parents=True,exist_ok=True)
    receipt_path=receipt_dir/f"repoint-{int(time.time())}.json"
    receipt={"kind":CONTRACT,"receipt_version":1,"build_id":state.get("build_id"),"target":str(source.relative_to(root)).replace(os.sep,"/"),"merge_input":str(merge.relative_to(root)).replace(os.sep,"/"),"before_sha256":before,"after_sha256":digest,"context_budget_before":str(context.relative_to(root)).replace(os.sep,"/") if context else None,"reason":reason.strip(),"recorded_at_unix":int(time.time())}
    atomic_write_json(receipt_path,receipt); lineage["last_repoint"]={"path":str(receipt_path.relative_to(root)).replace(os.sep,"/"),"sha256":sha256_file(receipt_path)}; atomic_write_json(state_path,state)
    return {"status":"repointed","receipt":str(receipt_path),"sha256":digest}

def main()->int:
    p=argparse.ArgumentParser(description=__doc__); p.add_argument("--build-state",required=True); p.add_argument("--target",required=True); p.add_argument("--reason",required=True); a=p.parse_args()
    try: print(json.dumps(repoint(a.build_state,a.target,reason=a.reason),indent=2)); return 0
    except (WorldBuilderError,OSError,ValueError,json.JSONDecodeError) as exc: print(f"ERROR: {exc}",file=sys.stderr); return 1
if __name__=="__main__": raise SystemExit(main())
