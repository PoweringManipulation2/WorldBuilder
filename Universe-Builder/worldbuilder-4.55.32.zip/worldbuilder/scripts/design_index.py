#!/usr/bin/env python3
"""Design decision index: the audit-facing projection of design-rationale.md.

An auditor needs each ruling and its regression clause; the amendment-time
reasoning around them belongs to whoever changes a record, not to a
lens-scoped worker. This module renders a compact index from the full
rationale (rendered, never hand-edited) and checks a generated copy against
a fresh render so the two can never drift.

Kept per record: the ``## DR-NNN:`` heading, ``**Class:**``, ``**Decision:**``,
and ``**What would be a regression:**``. A record without a ``**Decision:**``
field predates the field and keeps its entire body instead.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

from wb_common import WorldBuilderError

KIND = "worldbuilder-design-index"
INDEX_VERSION = 1
HEADER = "# Design Decision Index"
NAV = "## Navigation"
KEEP_FIELDS = ("**Class:**", "**Decision:**", "**What would be a regression:**")
DR_RE = re.compile(r"^## (DR-\d{3}):")
FIELD_RE = re.compile(r"^\*\*[^*]+\*\*")


def _records(rationale: str) -> list[list[str]]:
    records: list[list[str]] = []
    current: list[str] | None = None
    for line in rationale.split("\n"):
        if DR_RE.match(line):
            if current is not None:
                records.append(current)
            current = [line]
        elif current is not None:
            current.append(line)
    if current is not None:
        records.append(current)
    if not records:
        raise WorldBuilderError("design-rationale.md contains no DR-NNN headings to index")
    return records


def _kept_field_lines(block: list[str]) -> list[str]:
    kept: list[str] = []
    keep = False
    for line in block[1:]:
        if line.startswith(KEEP_FIELDS):
            kept.append(line)
            keep = True
        elif FIELD_RE.match(line):
            keep = False
        elif keep and line.strip():
            kept.append(line)
    return kept


def render_index(rationale: str) -> str:
    """Render the index deterministically from the rationale text."""
    records = _records(rationale)
    first = DR_RE.match(records[0][0]).group(1)
    last = DR_RE.match(records[-1][0]).group(1)
    out: list[str] = [HEADER, NAV, f"- All {len(records)} decision records, {first} through {last}, in order."]
    for block in records:
        while block and not block[-1].strip():
            block = block[:-1]
        if not block:
            continue
        out.append(block[0])
        if any(line.startswith("**Decision:**") for line in block):
            out.extend(_kept_field_lines(block))
        else:
            out.extend(line for line in block[1:] if line.strip())
    return "\n".join(out).rstrip("\n") + "\n"


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = parser.add_subparsers(dest="command", required=True)
    repo_root = Path(__file__).resolve().parent.parent
    for name in ("render", "check"):
        child = sub.add_parser(name)
        child.add_argument("--rationale", default=None, help="path to design-rationale.md (default: the bundled reference)")
        if name == "check":
            child.add_argument("--index", default=None, help="path to a rendered index to compare (default: references/design-decisions.md when present)")
        else:
            child.add_argument("--output")
    args = parser.parse_args()
    try:
        rationale_path = Path(args.rationale).expanduser().resolve() if args.rationale else repo_root / "references" / "design-rationale.md"
        rationale = rationale_path.read_text(encoding="utf-8")
        rendered = render_index(rationale)
        if args.command == "render":
            if args.output:
                target = Path(args.output).expanduser().resolve()
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_text(rendered, encoding="utf-8", newline="\n")
                print(json.dumps({"status": "rendered", "output": str(target), "lines": len(rendered.splitlines())}, indent=2))
            else:
                sys.stdout.write(rendered)
            return 0
        index_path = Path(args.index).expanduser().resolve() if args.index else repo_root / "references" / "design-decisions.md"
        if not index_path.exists():
            if args.index:
                raise WorldBuilderError(f"index not found: {index_path}")
            print(
                "DESIGN INDEX CHECK: PASSED (no committed index to compare; "
                "the index is generated at worker-kit staging time)"
            )
            return 0
        committed = index_path.read_text(encoding="utf-8")
        if committed != rendered:
            print(
                "ERROR: design index does not match a fresh render; re-render it with "
                "design_index.py render --rationale <path> and re-save",
                file=sys.stderr,
            )
            return 2
        print("DESIGN INDEX CHECK: PASSED")
        return 0
    except (WorldBuilderError, OSError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
