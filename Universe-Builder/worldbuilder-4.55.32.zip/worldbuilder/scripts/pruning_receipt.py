#!/usr/bin/env python3
"""Validate a receipt-bound WorldBuilder pruning operation.

Pruning is a copy workflow: compare explicit before/after artifacts, require a
real reduction, preserve stable identities and non-pruning settings, reject
silent scope loss, and record every affected UID and retrieval-term change.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path
from typing import Any

from budget_contract import (
    CONTRACT as BUDGET_CONTRACT,
    analyze_manifest,
    analyze_output,
    actual_entry_token_measurement,
    estimate_tokens,
    load_bound_plan,
    protected_categories,
    run_simulations,
    uid_key,
)
from budget_semantics import emit_config as _emit, manifest_rows as _manifest_rows, required_edges as _required_edges
from wb_common import (
    WorldBuilderError,
    atomic_write_json,
    canonical_entry_identity,
    iter_entries,
    load_build_state,
    load_json,
    resolve_state_path,
    sha256_file,
)

KIND = "worldbuilder-pruning-receipt"
VERSION = 1

ENVELOPE_KEY = "worldbuilder_dynamic"


def _dynamic_state_membership_reasons(entry: dict[str, Any] | None) -> list[str]:
    """Prune revamp bug fix (3 of 3): PROTECTED_CATEGORIES has no
    dynamic-state membership. A UID in an inclusion group, carrying
    sticky/cooldown/delay, or greeting-bound currently passes removal
    without approval, silently breaking the frozen dynamic-state plan
    despite prune-mode.md claiming it requires explicit review. Read
    directly from the entry's own worldbuilder_dynamic extension envelope
    (dynamic_state_contract.py's own resolved output, embedded per entry,
    never a second, independently-derived notion of what is bound).

    Deliberately a separate function rather than an addition to
    budget_contract.PROTECTED_CATEGORIES (or dynamic_state_contract's own,
    separate copy of the same seven names) itself: both are exact-match
    validated against every already-frozen plan's own declared
    "protected_categories" field (budget_contract.py:409,
    dynamic_state_contract.py:368); adding a category there would
    invalidate every existing plan's validation, not just extend it. This
    function adds a new *kind* of protection check without touching the
    plan-contract vocabulary at all.
    """
    if not isinstance(entry, dict):
        return []
    extensions = entry.get("extensions") if isinstance(entry.get("extensions"), dict) else {}
    envelope = extensions.get(ENVELOPE_KEY)
    if not isinstance(envelope, dict):
        return []
    reasons: list[str] = []
    groups = envelope.get("groups")
    if isinstance(groups, list) and groups:
        reasons.append("dynamic_state_inclusion_group")
    if any(int(envelope.get(key) or 0) > 0 for key in ("sticky", "cooldown", "delay")):
        reasons.append("dynamic_state_timed_effect")
    greeting_variants = envelope.get("greeting_variants")
    if isinstance(greeting_variants, list) and greeting_variants:
        reasons.append("dynamic_state_greeting_bound")
    return reasons
ALLOWED_MUTABLE_FIELDS = {"content", "keys", "secondary_keys", "key", "keysecondary", "comment", "name"}


def _entries(data: dict[str, Any]) -> dict[str, dict[str, Any]]:
    result: dict[str, dict[str, Any]] = {}
    for ref in iter_entries(data):
        identity = canonical_entry_identity(ref.entry)
        if identity is None:
            raise WorldBuilderError(f"entry at {ref.path} lacks a stable identity")
        key = uid_key(identity)
        if key in result:
            raise WorldBuilderError(f"artifact contains duplicate UID {key}")
        result[key] = ref.entry
    return result


def _keywords(entry: dict[str, Any]) -> list[str]:
    values: list[str] = []
    for field in ("keys", "secondary_keys", "key", "keysecondary"):
        value = entry.get(field)
        if isinstance(value, list):
            values.extend(str(item) for item in value)
        elif isinstance(value, str):
            values.append(value)
    return values


def _entry_tokens(entry: dict[str, Any]) -> int:
    return estimate_tokens(entry.get("content", ""))


def _non_pruning_projection(entry: dict[str, Any]) -> dict[str, Any]:
    return {key: value for key, value in entry.items() if key not in ALLOWED_MUTABLE_FIELDS}


def _load_changes(path: Path | None) -> dict[str, dict[str, Any]]:
    if path is None:
        return {}
    value = load_json(path)
    rows = value.get("changes") if isinstance(value, dict) else value
    if not isinstance(rows, list):
        raise WorldBuilderError("pruning change declaration must be an array or {changes:[...]}")
    result: dict[str, dict[str, Any]] = {}
    for index, row in enumerate(rows, start=1):
        if not isinstance(row, dict):
            raise WorldBuilderError(f"pruning change {index} must be an object")
        uid = uid_key(row.get("uid"))
        if uid in result:
            raise WorldBuilderError(f"pruning change declaration repeats UID {uid}")
        for field in ("reason", "activation_impact", "era_impact"):
            if not isinstance(row.get(field), str) or not row[field].strip():
                raise WorldBuilderError(f"pruning change UID {uid} requires {field}")
        absorbs = row.get("merge_absorbs")
        if absorbs is not None:
            if not isinstance(absorbs, list) or not absorbs or any(not str(item).strip() for item in absorbs):
                raise WorldBuilderError(f"pruning change UID {uid} merge_absorbs must be a non-empty list of UIDs")
            row["merge_absorbs"] = [uid_key(item) for item in absorbs]
        result[uid] = row
    return result


def worst_case_after_pruning(plan: dict[str, Any], manifest: dict[str, Any], after_data: dict[str, Any]) -> dict[str, Any]:
    """Prune revamp bug fix (2 of 3): keyword-only pruning was documented
    but rejected; _entry_tokens counts content only, so a pure keyword
    change (which reduces worst-case activation pressure, the metric that
    actually matters) never registers as an improvement. Fixing this
    properly means computing WCSA for the after state, not just comparing
    content-token sums.

    analyze_output cannot be called directly on a post-prune artifact: it
    requires every planned manifest UID to be present, and pruning
    legitimately removes UIDs by design (its own "missing planned UIDs"
    check would fire on every single prune). This calls run_simulations
    directly instead; the lower-level function both analyze_manifest and
    analyze_output themselves use, seeded from _manifest_rows(manifest)
    (matching their own established pattern). An earlier draft passed
    analyze_manifest's own computed detail rows instead, which carry no
    emit.keys at all and would have silently made every keyword-sensitive
    simulation blind, not the same bug as this function exists to fix,
    but it very nearly became a second one, caught only by testing this
    against a real keyword change and finding the result did not move.
    The unused parameter that carried those rows has since been removed.

    Each row's keys are then overridden with the entry's actual, current
    keywords from after_data, not the frozen manifest's original ones,
    since a keyword edit made during pruning must actually be reflected
    for this to mean anything; a removed UID contributes 0 tokens and an
    empty key set, since it cannot activate if it does not exist.
    """
    targets = plan["targets"]
    actual_rows: dict[str, dict[str, Any]] = {}
    for ref in iter_entries(after_data):
        identity = canonical_entry_identity(ref.entry)
        if identity is None:
            continue
        actual_rows[uid_key(identity)] = ref.entry

    rows = []
    token_map: dict[str, int] = {}
    for row in _manifest_rows(manifest):
        uid = uid_key(row.get("uid", row.get("id")))
        row = dict(row)
        row["emit"] = dict(_emit(row))
        actual = actual_rows.get(uid)
        if actual is None:
            row["emit"]["keys"] = []  # removed; cannot activate, contributes nothing
            token_map[uid] = 0
        else:
            actual_keys = actual.get("keys")
            row["emit"]["keys"] = list(actual_keys) if isinstance(actual_keys, list) else []
            tokens, _source = actual_entry_token_measurement(actual)
            token_map[uid] = tokens
        rows.append(row)

    edges, _required = _required_edges(manifest)
    simulations = run_simulations(rows, edges, token_map, targets, plan.get("project_simulations", []))
    worst = next((s for s in simulations if s["name"] == "worst_case_recursion_path"), None)
    if worst is None:
        raise WorldBuilderError("worst_case_recursion_path simulation is missing from the plan's simulation set")
    # worst_case_recursion_path itself is purely graph-structural (emit/require
    # edges) and is not sensitive to keyword changes at all; comparing only
    # it would mean a keyword-only prune could never register as an
    # improvement, the exact bug this function exists to fix. The maximum
    # across every simulation (including common_ambiguous_term, which is
    # directly keyword-driven) is what "worst-case simultaneous activation"
    # actually means.
    max_pressure = max(s["estimated_tokens"] for s in simulations)
    return {"worst_case_recursion_path": worst, "all_simulations": simulations, "max_pressure": max_pressure}


def validate(
    build_state: str,
    before: str,
    after: str,
    *,
    changes: str | None = None,
    output: str | None = None,
    approved_by: str | None = None,
    approval_reason: str | None = None,
) -> dict[str, Any]:
    root, state = load_build_state(build_state)
    before_path = Path(before).expanduser().resolve()
    after_path = Path(after).expanduser().resolve()
    if not before_path.exists() or not after_path.exists():
        raise WorldBuilderError("both before and after pruning artifacts must exist")
    before_data = load_json(before_path)
    after_data = load_json(after_path)
    if not isinstance(before_data, dict) or not isinstance(after_data, dict):
        raise WorldBuilderError("pruning artifacts must be JSON objects")
    before_entries = _entries(before_data)
    after_entries = _entries(after_data)
    manifest_path = resolve_state_path(root, state, "manifest")
    manifest = load_json(manifest_path)
    if not isinstance(manifest, dict):
        raise WorldBuilderError("manifest must be an object")
    plan, plan_path = load_bound_plan(root, state, manifest)
    manifest_detail = analyze_manifest(plan, manifest)
    before_budget = analyze_output(plan, manifest_detail, before_data, manifest)
    # The after artifact may omit unprotected entries. Validate retained entries
    # individually and then compare actual pressure below.
    declared = _load_changes(Path(changes).expanduser().resolve() if changes else None)
    removed = sorted(set(before_entries) - set(after_entries))
    added = sorted(set(after_entries) - set(before_entries))
    if added:
        raise WorldBuilderError("pruning cannot add entry UIDs: " + ", ".join(added))
    changed: list[str] = []
    for uid in sorted(set(before_entries) & set(after_entries)):
        if before_entries[uid] != after_entries[uid]:
            changed.append(uid)
            if _non_pruning_projection(before_entries[uid]) != _non_pruning_projection(after_entries[uid]):
                raise WorldBuilderError(f"pruning UID {uid} changed non-pruning settings")
            absorbs = declared.get(uid, {}).get("merge_absorbs")
            if absorbs:
                # Prune revamp bug fix (1 of 3): merging is documented but was
                # structurally impossible: a survivor absorbing a removed
                # entry's content must grow. Exempted only when explicitly
                # declared, and only for UIDs genuinely being removed in this
                # same operation; never a blanket "just say merge" loophole.
                not_removed = sorted(set(absorbs) - set(removed))
                if not_removed:
                    raise WorldBuilderError(
                        f"pruning UID {uid} declares merge_absorbs {', '.join(not_removed)}, but those UIDs are not "
                        "being removed in this operation; merge_absorbs only exempts growth from content genuinely "
                        "being consolidated here"
                    )
            elif _entry_tokens(after_entries[uid]) > _entry_tokens(before_entries[uid]):
                raise WorldBuilderError(f"pruning UID {uid} increased content size")
    affected = sorted(set(removed) | set(changed))
    if not affected:
        raise WorldBuilderError("pruning receipt requires at least one real change")
    missing_declarations = sorted(set(affected) - set(declared))
    extra_declarations = sorted(set(declared) - set(affected))
    if missing_declarations or extra_declarations:
        detail = []
        if missing_declarations:
            detail.append("missing declarations " + ", ".join(missing_declarations))
        if extra_declarations:
            detail.append("unchanged declarations " + ", ".join(extra_declarations))
        raise WorldBuilderError("pruning declarations do not match actual changes: " + "; ".join(detail))

    manifest_rows = {
        uid_key(row.get("uid", row.get("id"))): row
        for row in manifest.get("entries", []) if isinstance(row, dict)
    }
    _edges, required_edge_uids = _required_edges(manifest)
    protected_removed: dict[str, list[str]] = {}
    for uid in removed:
        row = manifest_rows.get(uid)
        if row is None:
            raise WorldBuilderError(f"removed UID {uid} is not owned by the manifest")
        categories = sorted(protected_categories(row, required_edge_uids))
        categories += _dynamic_state_membership_reasons(before_entries.get(uid))
        if categories:
            protected_removed[uid] = sorted(set(categories))
    if protected_removed:
        if not (isinstance(approved_by, str) and approved_by.strip() and isinstance(approval_reason, str) and approval_reason.strip()):
            pairs = ", ".join(f"{uid} ({'/'.join(categories)})" for uid, categories in protected_removed.items())
            raise WorldBuilderError("protected architecture cannot be removed automatically; explicit human approval is required for " + pairs)
        for uid in protected_removed:
            row = declared[uid]
            if row.get("protected_removal_approved") is not True:
                raise WorldBuilderError(f"protected removal UID {uid} lacks protected_removal_approved=true")

    before_tokens = sum(_entry_tokens(row) for row in before_entries.values())
    after_tokens = sum(_entry_tokens(row) for row in after_entries.values())
    # Prune revamp bug fix (2 of 3) and the batch's central reframe: a prune
    # that reduces worst-case simultaneous activation is a genuine
    # improvement even when total content tokens do not move; a
    # keyword-only tightening is the canonical example. Corpus size alone
    # is still accepted (unchanged from before), but it is no longer the
    # only accepted proof.
    before_pressure = worst_case_after_pruning(plan, manifest, before_data)
    after_pressure = worst_case_after_pruning(plan, manifest, after_data)
    tokens_improved = after_tokens < before_tokens
    pressure_improved = after_pressure["max_pressure"] < before_pressure["max_pressure"]
    if not (tokens_improved or pressure_improved):
        raise WorldBuilderError(
            "pruning must reduce either worst-case activation pressure or total estimated content tokens "
            f"(tokens: {before_tokens} -> {after_tokens}; worst-case pressure: "
            f"{before_pressure['max_pressure']} -> {after_pressure['max_pressure']})"
        )
    before_keywords = sum(len(_keywords(row)) for row in before_entries.values())
    after_keywords = sum(len(_keywords(row)) for row in after_entries.values())

    # Validate every retained UID against its frozen hard budget.
    detail_by_uid = {uid_key(row["uid"]): row for row in manifest_detail["entries"]}
    for uid, entry in after_entries.items():
        planned = detail_by_uid.get(uid)
        if planned and _entry_tokens(entry) > int(planned["hard_limit"]):
            raise WorldBuilderError(f"pruned UID {uid} still exceeds its hard entry budget")

    receipt = {
        "kind": KIND,
        "receipt_version": VERSION,
        "status": "passed",
        "contract": BUDGET_CONTRACT,
        "build_id": state.get("build_id"),
        "manifest_sha256": sha256_file(manifest_path),
        "budget_plan_sha256": sha256_file(plan_path),
        "before": str(before_path),
        "before_sha256": sha256_file(before_path),
        "after": str(after_path),
        "after_sha256": sha256_file(after_path),
        "before_token_estimate": before_tokens,
        "after_token_estimate": after_tokens,
        "token_delta": after_tokens - before_tokens,
        "before_worst_case_pressure": before_pressure["max_pressure"],
        "after_worst_case_pressure": after_pressure["max_pressure"],
        "worst_case_pressure_delta": after_pressure["max_pressure"] - before_pressure["max_pressure"],
        "tokens_improved": tokens_improved,
        "pressure_improved": pressure_improved,
        "before_keyword_count": before_keywords,
        "after_keyword_count": after_keywords,
        "keyword_delta": after_keywords - before_keywords,
        "affected_uids": affected,
        "removed_uids": removed,
        "changed_uids": changed,
        "changes": [declared[uid] for uid in affected],
        "protected_removals": protected_removed,
        "human_approval": {
            "approved_by": approved_by,
            "reason": approval_reason,
        } if protected_removed else None,
        "before_budget": before_budget,
        # Batch 5, 5.6 interaction: before_budget above already respects any
        # approved deviation (analyze_output checks deviation_covers
        # internally); this field makes that fact visible in the receipt
        # itself, rather than requiring a reader to cross-reference the plan
        # separately to understand why a seemingly-over-budget before state
        # did not block.
        "approved_deviations": list(plan.get("approved_deviations") or []),
        "validated_at_unix": int(time.time()),
    }
    if output:
        output_path = Path(output).expanduser().resolve()
    else:
        receipts_dir = resolve_state_path(root, state, "pruning_receipts")
        receipts_dir.mkdir(parents=True, exist_ok=True)
        output_path = receipts_dir / f"pruning-{sha256_file(after_path)[:12]}.json"
    atomic_write_json(output_path, receipt)
    receipt["receipt"] = str(output_path)
    receipt["receipt_sha256"] = sha256_file(output_path)
    return receipt


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--build-state", required=True)
    parser.add_argument("--before", required=True)
    parser.add_argument("--after", required=True)
    parser.add_argument("--changes", required=True, help="JSON array or {changes:[...]} declaring every affected UID.")
    parser.add_argument("--output")
    parser.add_argument("--approved-by")
    parser.add_argument("--approval-reason")
    args = parser.parse_args()
    try:
        result = validate(
            args.build_state, args.before, args.after, changes=args.changes,
            output=args.output, approved_by=args.approved_by,
            approval_reason=args.approval_reason,
        )
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (WorldBuilderError, OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
