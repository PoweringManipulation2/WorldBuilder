#!/usr/bin/env python3
"""Compare predicted World Info activation against observed SillyTavern activation.

Observed mode consumes the JSON returned by WorldInfoInfo's current
``/wi-triggered`` command (or a compatible host adapter).  The extension records
entries active in the last generation; it does *not* expose recursion-round depth,
so this verifier compares closure membership only and reports depth as unobserved.
Without introspection, it degrades to synthetic prediction rather than claiming a
live-runtime observation occurred.
"""
from __future__ import annotations
import argparse, json, re, sys
from pathlib import Path
from typing import Any
from budget_semantics import activation_closure as _closure, entry_is_constant, entry_keys
from wb_common import WorldBuilderError, build_identity_index, load_build_state, load_json, normalize_identity, resolve_state_path

CONTRACT="worldbuilder-runtime-verification-v1"
INTROSPECTION_ADAPTER="worldinfoinfo-wi-triggered-v1"

def _keys(entry:dict[str,Any])->list[str]:
    # Runtime-verification fixtures historically used output-like ``key``/``keys``
    # fields, while the authoritative planning manifest stores retrieval terms in
    # ``emit.keys``. Support both shapes, but keep the manifest semantics owned by
    # budget_semantics rather than duplicating them here.
    for key in ('key','keys'):
        val=entry.get(key)
        if isinstance(val,str): return [val]
        if isinstance(val,list): return [str(x) for x in val if str(x).strip()]
    return entry_keys(entry)

def _constant(entry:dict[str,Any])->bool:
    if entry.get('constant') is True: return True
    return entry_is_constant(entry)

def predict(manifest:dict[str,Any],prompt:str,*,depth:int=8)->dict[str,Any]:
    idx=build_identity_index(manifest); seeds=[]; constants=[]
    lower=prompt.casefold()
    for ident,(_path,e) in idx.items():
        uid=str(ident)
        if _constant(e): constants.append(uid)
        for key in _keys(e):
            k=key.strip()
            if not k: continue
            matched=False
            if len(k)>=2 and k.startswith('/') and k.rfind('/')>0:
                try: matched=re.search(k[1:k.rfind('/')],prompt,re.I) is not None
                except re.error: matched=False
            else: matched=k.casefold() in lower
            if matched: seeds.append(uid); break
    graph=manifest.get('activation_graph') if isinstance(manifest.get('activation_graph'),dict) else {}
    edges=graph.get('edges') if isinstance(graph.get('edges'),list) else []
    closure=sorted(set(constants)|set(_closure(seeds,[e for e in edges if isinstance(e,dict)],depth,include_optional=True)))
    return {'seed_uids':sorted(set(seeds)),'constant_uids':sorted(set(constants)),'activated_uids':closure,'depth_limit':depth}

def parse_observed(data:Any)->dict[str,Any]:
    if isinstance(data,str):
        try: data=json.loads(data)
        except json.JSONDecodeError as exc: raise WorldBuilderError(f'observed activation data is not JSON: {exc}') from exc
    if isinstance(data,dict) and isinstance(data.get('entries'),list): data=data['entries']
    if not isinstance(data,list): raise WorldBuilderError('observed activation data must be the /wi-triggered JSON list')
    uids=[]; rows=[]
    for row in data:
        if not isinstance(row,dict): continue
        uid=row.get('uid',row.get('id'))
        if uid is None: continue
        uids.append(str(normalize_identity(uid)))
        rows.append({'uid':str(normalize_identity(uid)),'world':row.get('world'),'name':row.get('comment') or row.get('name'),'position':row.get('position')})
    return {'adapter':INTROSPECTION_ADAPTER,'activated_uids':sorted(set(uids)),'entries':rows,'recursion_depth_observed':False}

def compare(predicted:dict[str,Any],observed:dict[str,Any])->dict[str,Any]:
    p=set(predicted['activated_uids']); o=set(observed['activated_uids'])
    unexpected=sorted(o-p); missed=sorted(p-o)
    return {'status':'match' if not unexpected and not missed else 'diverged','unexpected_uids':unexpected,'missed_uids':missed,'predicted_count':len(p),'observed_count':len(o),'recursion_depth_comparison':'unavailable: WorldInfoInfo /wi-triggered exposes final active entries, not recursion rounds'}

def verify(build_state:str,prompt:str,*,observed_file:str|None=None,depth:int=8)->dict[str,Any]:
    root,state=load_build_state(build_state); manifest=load_json(resolve_state_path(root,state,'manifest'))
    pred=predict(manifest,prompt,depth=depth)
    if not observed_file:
        return {'contract':CONTRACT,'mode':'synthetic','evidence_strength':'predicted_not_observed','prompt':prompt,'predicted':pred,'status':'synthetic_only','note':'No live World Info introspection result was supplied; do not present this as observed SillyTavern behavior.'}
    obs=parse_observed(load_json(Path(observed_file).resolve()))
    cmp=compare(pred,obs)
    return {'contract':CONTRACT,'mode':'observed','evidence_strength':'live_runtime_observation','prompt':prompt,'predicted':pred,'observed':obs,'comparison':cmp,'status':cmp['status'],'requires_review':cmp['status']=='diverged','auto_corrected':False}

def main()->int:
    p=argparse.ArgumentParser(description=__doc__); p.add_argument('--build-state',required=True); p.add_argument('--prompt',required=True); p.add_argument('--observed-file'); p.add_argument('--depth',type=int,default=8)
    a=p.parse_args()
    try: print(json.dumps(verify(a.build_state,a.prompt,observed_file=a.observed_file,depth=a.depth),ensure_ascii=False,indent=2)); return 0
    except (WorldBuilderError,OSError,ValueError,json.JSONDecodeError) as exc: print(f'ERROR: {exc}',file=sys.stderr); return 1
if __name__=='__main__': raise SystemExit(main())
