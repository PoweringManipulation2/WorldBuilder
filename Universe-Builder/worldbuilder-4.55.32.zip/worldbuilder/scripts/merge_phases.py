#!/usr/bin/env python3
"""Merge WorldBuilder phase files without losing metadata or stable identities.

Canonical producers write ``phase-NNNN.json``. Legacy ``group-N-*.json`` files
are accepted for migration, but duplicate numeric phase numbers are rejected.

Examples:
    python merge_phases.py .work/phases --schema 2 --output .work/merged.json
    python merge_phases.py --build-state build-state.json --schema auto
"""
from __future__ import annotations

import argparse
import copy
import json
import shutil
import sys
from pathlib import Path
from typing import Any

from wb_common import (
    step_driver_pointer,
    WorldBuilderError,
    atomic_write_json,
    canonical_entry_identity,
    detect_artifact,
    discover_phase_files,
    load_build_state,
    load_json,
    resolve_state_path,
    sha256_file,
)
from pipeline_stage_gate import advance as advance_pipeline_stage
from entry_naming import normalize_build_output


_MISSING = object()

# Batch 33: these are the sparse, frozen planning values that have direct
# representations in portable CCv3/lorebook_v3 entry output. Runtime-only
# settings continue to be owned by their neutral envelopes/target adapter.
_PORTABLE_DEFAULT_FIELDS = {
    "enabled": "enabled",
    "insertion_order": "insertion_order",
    "use_regex": "use_regex",
    "constant": "constant",
    "selective": "selective",
    "position": "position",
    "case_sensitive": "case_sensitive",
    "secondary_keywords": "secondary_keys",
}


def _identity_key(value: Any) -> tuple[str, str]:
    return (type(value).__name__, json.dumps(value, ensure_ascii=False, sort_keys=True))


def _registry_defaults(registry: dict[str, Any] | None) -> dict[str, Any]:
    rows = registry.get("fields") if isinstance(registry, dict) else None
    if not isinstance(rows, list):
        return {}
    out: dict[str, Any] = {}
    for row in rows:
        if isinstance(row, dict) and isinstance(row.get("name"), str) and "default" in row:
            out[row["name"]] = copy.deepcopy(row["default"])
    return out


def _manifest_entry_index(manifest: dict[str, Any] | None) -> dict[tuple[str, str], dict[str, Any]]:
    rows = manifest.get("entries") if isinstance(manifest, dict) else None
    if not isinstance(rows, list):
        return {}
    out: dict[tuple[str, str], dict[str, Any]] = {}
    for row in rows:
        if not isinstance(row, dict):
            continue
        identity = canonical_entry_identity(row)
        if identity is not None:
            out[_identity_key(identity)] = row
    return out


def _resolved_default(
    semantic: str,
    manifest_row: dict[str, Any] | None,
    profile: dict[str, Any],
    registry_defaults: dict[str, Any],
) -> Any:
    # Manifest-owned emission is the strongest authority. This prevents a
    # missing root field from being incorrectly filled with the global false
    # default when planning explicitly resolved that root to constant=true.
    emit = manifest_row.get("emit") if isinstance(manifest_row, dict) else None
    if isinstance(emit, dict) and semantic in emit:
        return copy.deepcopy(emit[semantic])

    defaults = profile.get("defaults") if isinstance(profile.get("defaults"), dict) else {}
    layer_overrides = profile.get("layer_overrides") if isinstance(profile.get("layer_overrides"), dict) else {}
    layer = None
    if isinstance(manifest_row, dict) and isinstance(manifest_row.get("architecture"), dict):
        layer = manifest_row["architecture"].get("layer")
    override = layer_overrides.get(layer) if layer is not None else None
    if isinstance(override, dict) and semantic in override:
        return copy.deepcopy(override[semantic])
    if semantic in defaults:
        return copy.deepcopy(defaults[semantic])
    if semantic in registry_defaults:
        return copy.deepcopy(registry_defaults[semantic])
    return _MISSING


def materialize_frozen_defaults(
    entries: list[dict[str, Any]],
    manifest: dict[str, Any] | None,
    profile: dict[str, Any] | None,
    registry: dict[str, Any] | None,
) -> int:
    """Materialize sparse portable entry defaults from the frozen build contract.

    Omission means inheritance; explicit null/None remains explicit and is not
    replaced. Only fields with a direct portable entry representation are
    materialized here. Target-specific/runtime-only settings remain adapter-owned.
    """
    if not isinstance(profile, dict):
        return 0
    manifest_rows = _manifest_entry_index(manifest)
    registry_values = _registry_defaults(registry)
    changed = 0
    for entry in entries:
        identity = canonical_entry_identity(entry)
        manifest_row = manifest_rows.get(_identity_key(identity)) if identity is not None else None
        for semantic, output_field in _PORTABLE_DEFAULT_FIELDS.items():
            if output_field in entry:
                continue
            value = _resolved_default(semantic, manifest_row, profile, registry_values)
            if value is _MISSING or value is None:
                continue
            entry[output_field] = value
            changed += 1
    return changed


def load_frozen_default_contract(root: Path, state: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any]]:
    profile_path = resolve_state_path(root, state, "default_profile")
    registry_path = resolve_state_path(root, state, "field_registry")
    if not profile_path.exists() or not registry_path.exists():
        raise WorldBuilderError("merge requires the frozen default profile and field registry")
    profile = load_json(profile_path)
    registry = load_json(registry_path)
    if profile.get("kind") != "worldbuilder-default-profile":
        raise WorldBuilderError("frozen default profile has the wrong format")
    if registry.get("kind") != "worldbuilder-field-registry":
        raise WorldBuilderError("frozen field registry has the wrong format")
    bound_registry_sha = profile.get("field_registry_sha256")
    if bound_registry_sha and bound_registry_sha != sha256_file(registry_path):
        raise WorldBuilderError("frozen default profile is stale for the field registry")
    return profile, registry


def extract_schema2_entries(data: Any) -> list[dict[str, Any]]:
    if isinstance(data, list):
        values = data
    elif isinstance(data, dict) and isinstance(data.get("data"), dict):
        book = data["data"].get("character_book")
        values = book.get("entries", []) if isinstance(book, dict) else []
    elif isinstance(data, dict):
        values = data.get("entries", [])
    else:
        values = []
    if isinstance(values, dict):
        values = [values[key] for key in sorted(values, key=str)]
    if not isinstance(values, list):
        raise WorldBuilderError("Schema 2 phase entries must be an array or keyed object")
    if any(not isinstance(entry, dict) for entry in values):
        raise WorldBuilderError("every phase entry must be a JSON object")
    return copy.deepcopy(values)


def extract_schema3_entries(data: Any) -> list[tuple[str | None, dict[str, Any]]]:
    if isinstance(data, list):
        return [(None, copy.deepcopy(entry)) for entry in data if isinstance(entry, dict)]
    if not isinstance(data, dict):
        return []
    if data.get("spec") == "lorebook_v3" and isinstance(data.get("data"), dict):
        values = data["data"].get("entries", [])
    else:
        values = data.get("entries", [])
    if isinstance(values, list):
        if any(not isinstance(entry, dict) for entry in values):
            raise WorldBuilderError("every phase entry must be a JSON object")
        return [(None, copy.deepcopy(entry)) for entry in values]
    if isinstance(values, dict):
        if any(not isinstance(entry, dict) for entry in values.values()):
            raise WorldBuilderError("every phase entry must be a JSON object")
        return [(str(key), copy.deepcopy(entry)) for key, entry in values.items()]
    raise WorldBuilderError("Schema 3 phase entries must be an array or keyed object")


def next_integer_identity(used: set[Any], manifest: dict[str, Any] | None) -> int:
    configured = manifest.get("next_uid") if isinstance(manifest, dict) else None
    try:
        candidate = max(0, int(configured)) if configured is not None else 0
    except (TypeError, ValueError):
        candidate = 0
    numeric = [value for value in used if isinstance(value, int) and not isinstance(value, bool)]
    if numeric:
        candidate = max(candidate, max(numeric) + 1)
    while candidate in used:
        candidate += 1
    return candidate


def prepare_identities(
    entries: list[dict[str, Any]],
    identity_field: str,
    manifest: dict[str, Any] | None,
    legacy_mirrors: bool,
) -> list[dict[str, Any]]:
    """Preserve stable identity while emitting only the container-native field.

    Character-book and CCv3 lorebook entries use ``id``. SillyTavern native
    World Info may use ``uid``. A legacy top-level ``uid`` on lorebook_v3 input
    is migrated to ``id`` and removed rather than leaking a non-spec field.
    """
    if identity_field not in {"id", "uid"}:
        raise WorldBuilderError(f"unsupported identity field {identity_field!r}")
    used: set[Any] = set()
    missing: list[dict[str, Any]] = []
    duplicates: list[str] = []
    for entry in entries:
        # Normalize legacy lorebook_v3 uid before canonical conflict checks.
        if identity_field == "id" and "uid" in entry:
            if "id" not in entry:
                entry["id"] = entry["uid"]
            elif entry["id"] != entry["uid"]:
                raise WorldBuilderError(
                    f"entry identity mirrors disagree: id={entry['id']!r}, uid={entry['uid']!r}"
                )
            entry.pop("uid", None)
        identity = canonical_entry_identity(entry)
        if identity is None:
            missing.append(entry)
            continue
        if identity in used:
            # Collect rather than raise. Failing on the first duplicate means a merge
            # with three collisions costs three full cycles to discover them.
            duplicates.append(identity)
        used.add(identity)

    if duplicates:
        raise WorldBuilderError(
            f"merge aborted: {len(duplicates)} duplicate entry identities. "
            f"Fix all of these in one pass: {sorted(set(duplicates))}"
        )

    candidate = next_integer_identity(used, manifest)
    for entry in missing:
        while candidate in used:
            candidate += 1
        identity = candidate
        used.add(identity)
        candidate += 1
        entry[identity_field] = identity

    for entry in entries:
        identity = canonical_entry_identity(entry)
        if identity_field not in entry and identity is not None:
            entry[identity_field] = identity
        if identity_field == "id":
            # CCv3 CharacterBookEntry defines id, not a top-level uid.
            entry.pop("uid", None)
        if legacy_mirrors and identity_field == "id":
            ext = entry.setdefault("extensions", {})
            if not isinstance(ext, dict):
                raise WorldBuilderError("entry.extensions must be an object before legacy mirroring")
            ext.setdefault("uid", entry.get("id"))
    return entries


def merge_schema2(
    phases: list[tuple[Path, Any]],
    manifest: dict[str, Any] | None,
    legacy_mirrors: bool,
    *,
    frozen_profile: dict[str, Any] | None = None,
    frozen_registry: dict[str, Any] | None = None,
) -> dict[str, Any]:
    shell_path, first = phases[0]
    if not isinstance(first, dict) or not isinstance(first.get("data"), dict):
        raise WorldBuilderError(f"{shell_path.name} must contain the full chara_card_v3 shell")
    if first.get("spec") != "chara_card_v3":
        raise WorldBuilderError(f"{shell_path.name} must use spec='chara_card_v3'")
    book = first["data"].get("character_book")
    if not isinstance(book, dict) or "entries" not in book:
        raise WorldBuilderError(f"{shell_path.name} is missing data.character_book.entries")

    out = copy.deepcopy(first)
    out.pop("_worldbuilder", None)  # Build metadata never leaks into the deliverable.
    merged: list[dict[str, Any]] = []
    for path, data in phases:
        entries = extract_schema2_entries(data)
        print(f"  {path.name}: {len(entries)} entries")
        merged.extend(entries)
    prepare_identities(merged, "id", manifest, legacy_mirrors)
    materialize_frozen_defaults(merged, manifest, frozen_profile, frozen_registry)
    out["data"]["character_book"]["entries"] = merged
    return out


def merge_schema3(
    phases: list[tuple[Path, Any]],
    manifest: dict[str, Any] | None,
    legacy_mirrors: bool,
    *,
    frozen_profile: dict[str, Any] | None = None,
    frozen_registry: dict[str, Any] | None = None,
) -> dict[str, Any]:
    del legacy_mirrors  # Schema 3 has no V1/V2 identity mirror step.
    shell_path, first = phases[0]
    if not isinstance(first, dict):
        raise WorldBuilderError(f"{shell_path.name} must contain a lorebook shell")
    info = detect_artifact(first)
    if info.kind not in {"lorebook_v3", "sillytavern_world_info"}:
        raise WorldBuilderError(
            f"{shell_path.name} must be a lorebook_v3 wrapper or a SillyTavern World Info object"
        )

    out = copy.deepcopy(first)  # Preserve all current and future user/application metadata.
    out.pop("_worldbuilder", None)  # Internal phase lineage belongs only in the workspace.
    collected: list[tuple[str | None, dict[str, Any]]] = []
    for path, data in phases:
        values = extract_schema3_entries(data)
        print(f"  {path.name}: {len(values)} entries")
        collected.extend(values)
    entries = [entry for _, entry in collected]
    prepare_identities(entries, "id" if info.kind == "lorebook_v3" else "uid", manifest, False)
    if info.kind == "lorebook_v3":
        materialize_frozen_defaults(entries, manifest, frozen_profile, frozen_registry)

    if info.kind == "lorebook_v3":
        out["data"]["entries"] = entries
    else:
        original_entries = first.get("entries")
        if isinstance(original_entries, list):
            out["entries"] = entries
        else:
            keyed: dict[str, dict[str, Any]] = {}
            for original_key, entry in collected:
                identity = canonical_entry_identity(entry)
                key = original_key if original_key is not None else str(identity)
                if key in keyed:
                    raise WorldBuilderError(f"duplicate Schema 3 entry key {key!r}")
                keyed[key] = entry
            out["entries"] = keyed
    return out


def update_build_state(state_path: Path, state: dict[str, Any], output: Path, phases: list[tuple[Path, Any]]) -> None:
    state.setdefault("status", {})["merge"] = "complete"
    # Batch 6, 6.3: merge_phases.py never checked manifest_sha256 consistency
    # across phases; it was already functionally tolerant of mixed lineage
    # by omission. What was actually missing is recording that fact: which
    # phases were exact-match vs slice_tolerated (Batch 6, 6.2) at the moment
    # they were merged, so a later reader can see the set rather than assume
    # every phase shared one lineage.
    phase_records = []
    binding_counts: dict[str, int] = {}
    for path, data in phases:
        meta = data.get("_worldbuilder") if isinstance(data, dict) else None
        binding = meta.get("phase_binding", "exact") if isinstance(meta, dict) else "unknown"
        manifest_sha256 = meta.get("manifest_sha256") if isinstance(meta, dict) else None
        binding_counts[binding] = binding_counts.get(binding, 0) + 1
        phase_records.append({
            "path": str(path.relative_to(state_path.parent)) if path.is_relative_to(state_path.parent) else str(path),
            "sha256": sha256_file(path),
            "manifest_sha256": manifest_sha256,
            "phase_binding": binding,
        })
    auto_review = bool((state.get("budget") or {}).get("auto_review_required"))
    lineage_output = output
    if auto_review:
        before = resolve_state_path(state_path.parent, state, "context_budget_before")
        before.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(output, before)
        lineage_output = before
    state.setdefault("lineage", {})["merge"] = {
        "output": str(lineage_output.relative_to(state_path.parent)) if lineage_output.is_relative_to(state_path.parent) else str(lineage_output),
        "sha256": sha256_file(lineage_output),
        "phase_files": phase_records,
        "mixed_lineage": len(binding_counts) > 1,
        "binding_counts": binding_counts,
        "snapshot": "context_budget_before" if auto_review else None,
    }
    atomic_write_json(state_path, state)
    advance_pipeline_stage(state_path, "merge_complete")
    if not auto_review:
        advance_pipeline_stage(state_path, "entry_names_normalized", output)


def main() -> int:
    parser = argparse.ArgumentParser(description="Merge WorldBuilder phase JSON files safely.")
    parser.add_argument("directory", nargs="?", help="Directory containing phase-NNNN.json files.")
    parser.add_argument("--schema", choices=["auto", "2", "3"], default="auto")
    parser.add_argument("--output", help="Output JSON path.")
    parser.add_argument("--manifest", help="Optional authoritative manifest.json for next_uid.")
    parser.add_argument("--build-state", help="Use paths.phases, paths.merge_input, and paths.manifest from build-state.json.")
    parser.add_argument("--legacy-mirrors", action="store_true", help="Opt in to legacy Schema 2 extensions.uid mirrors.")
    args = parser.parse_args()

    state_path: Path | None = None
    state: dict[str, Any] | None = None
    try:
        if args.build_state:
            root, state = load_build_state(args.build_state)
            state_path = Path(args.build_state).resolve()
            directory = resolve_state_path(root, state, "phases")
            output = resolve_state_path(root, state, "merge_input")
            manifest_path = resolve_state_path(root, state, "manifest", required=False)
        else:
            if not args.directory:
                parser.error("directory is required unless --build-state is used")
            directory = Path(args.directory).resolve()
            output = Path(args.output).resolve() if args.output else directory / "merged.json"
            manifest_path = Path(args.manifest).resolve() if args.manifest else None

        if not directory.is_dir():
            raise WorldBuilderError(f"phase directory does not exist: {directory}")
        files = discover_phase_files(directory, allow_legacy_group=True)
        if not files:
            raise WorldBuilderError(f"no phase-NNNN.json files found in {directory}")
        phases = [(path, load_json(path)) for path in files]
        manifest = load_json(manifest_path) if manifest_path and manifest_path.exists() else None
        if manifest_path and not manifest_path.exists():
            raise WorldBuilderError(f"manifest path was supplied but does not exist: {manifest_path}")

        schema = args.schema
        if schema == "auto":
            detected = detect_artifact(phases[0][1]).schema
            if detected not in {2, 3}:
                raise WorldBuilderError("could not infer Schema 2 or 3 from the first phase shell")
            schema = str(detected)

        frozen_profile = frozen_registry = None
        if state is not None:
            frozen_profile, frozen_registry = load_frozen_default_contract(root, state)
        merged = (
            merge_schema2(
                phases, manifest, args.legacy_mirrors,
                frozen_profile=frozen_profile, frozen_registry=frozen_registry,
            )
            if schema == "2"
            else merge_schema3(
                phases, manifest, args.legacy_mirrors,
                frozen_profile=frozen_profile, frozen_registry=frozen_registry,
            )
        )
        output.parent.mkdir(parents=True, exist_ok=True)
        atomic_write_json(output, merged)
        print(f"Merged {len(files)} phase file(s) into {output}")
        if state_path and state is not None:
            auto_review = bool((state.get("budget") or {}).get("auto_review_required"))
            if auto_review:
                update_build_state(state_path, state, output, phases)
                print("Auto context budget selected: merged output is preserved for measured review before entry-name normalization.")
            else:
                naming = normalize_build_output(state_path, output, write_receipt=True)
                print(f"Normalized {naming.get('changed_entry_count', 0)} visible entry label(s)")
                _, state = load_build_state(state_path)
                update_build_state(state_path, state, output, phases)
        return 0
    except (WorldBuilderError, json.JSONDecodeError, OSError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        print(step_driver_pointer(), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
