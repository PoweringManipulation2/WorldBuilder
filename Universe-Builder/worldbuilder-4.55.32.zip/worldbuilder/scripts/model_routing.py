#!/usr/bin/env python3
"""Resolve WorldBuilder worker-role model preferences without hard-coded model names.

Persistent config may define one legacy ``models.subagent`` fallback, optional
role overrides (``discovery``, ``generation``, ``audit``), and an optional
routing strategy. Builds freeze the effective role values so later config edits
cannot change an active build.

Strategy names describe routing intent only; they never rank or discover models:
``cheap`` routes every role through the user's configured subagent preference,
``standard`` keeps discovery/generation on that subagent preference and routes
audits through the user's concrete main-model preference, and
``maximum-quality`` routes every child role through that concrete main-model
preference. Explicit role overrides always win. No provider/model is embedded in
WorldBuilder itself.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any

from wb_common import WorldBuilderError

MODEL_RE = re.compile(r"^[A-Za-z0-9._:-]+/[A-Za-z0-9._:/+-]+$")
ROLE_KEYS = ("discovery", "generation", "audit")
MODEL_STRATEGIES = ("cheap", "standard", "maximum-quality")


def _text(value: Any, default: str) -> str:
    if value is None:
        return default
    text = str(value).strip().casefold()
    return text or default


def _normalize_model(value: Any) -> str:
    """Normalize a provider/model reference, casefolding ONLY the provider.

    Batch 58 / A08: a model identifier is case-sensitive after the first slash
    (``Qwen/Qwen3-8B`` is not ``qwen/qwen3-8b``). Casefolding the whole string
    silently rewrote the model a build actually asked for.
    """
    text = "" if value is None else str(value).strip()
    provider, sep, model = text.partition("/")
    if not sep:
        return text.casefold()
    return f"{provider.casefold()}/{model.strip()}"


def _normalize_main(value: Any) -> str:
    """``main`` is either the unresolved sentinel ``default`` or a model id."""
    text = "default" if value is None else str(value).strip()
    if not text or text.casefold() == "default":
        return "default"
    return _normalize_model(text)


def is_concrete_model(value: Any) -> bool:
    return bool(MODEL_RE.fullmatch(_normalize_model(value)))


def validate_worker_model(value: Any, *, field: str = "worker model") -> str:
    raw = "" if value is None else str(value).strip()
    if raw.casefold() in {"inherit", "default"}:
        # Older config_models.py accepted ``default`` for subagents even though
        # the documented child sentinel was ``inherit``. Normalize that legacy
        # value instead of stranding an existing workspace.
        return "inherit"
    model = _normalize_model(raw)
    if not MODEL_RE.fullmatch(model):
        raise WorldBuilderError(
            f"{field} must be 'inherit' or a provider/model reference such as openai/gpt-5.6"
        )
    return model


def _strategy_base(models: dict[str, Any], strategy: str | None) -> dict[str, str]:
    subagent = validate_worker_model(models.get("subagent", "inherit"), field="models.subagent")
    if not strategy:
        return {role: subagent for role in ROLE_KEYS}
    strategy = str(strategy).strip().casefold()
    if strategy not in MODEL_STRATEGIES:
        raise WorldBuilderError(
            "models.strategy must be one of cheap, standard, maximum-quality"
        )
    if strategy == "cheap":
        return {role: subagent for role in ROLE_KEYS}

    main = _normalize_main(models.get("main", "default"))
    # A "default" coordinator is intentionally unresolved. Passing no child
    # model would inherit the subagent default, not necessarily the coordinator
    # model, so pretending that means maximum quality would be false routing.
    if not is_concrete_model(main):
        needed = ("audit",) if strategy == "standard" else ROLE_KEYS
        unresolved = [role for role in needed if role not in models or models.get(role) in (None, "")]
        if unresolved:
            raise WorldBuilderError(
                f"model strategy {strategy!r} needs a concrete models.main provider/model for "
                f"{', '.join(unresolved)}; set --main-model or explicit role model overrides"
            )
    if strategy == "standard":
        return {
            "discovery": subagent,
            "generation": subagent,
            "audit": validate_worker_model(main, field="models.main") if is_concrete_model(main) else subagent,
        }
    quality = validate_worker_model(main, field="models.main") if is_concrete_model(main) else subagent
    return {role: quality for role in ROLE_KEYS}


def resolve_models(models: dict[str, Any] | None) -> dict[str, str]:
    """Return the frozen effective model map for one build.

    Legacy configs with only main/subagent resolve every role to subagent, which
    preserves pre-Item-24 behavior exactly. Explicit role keys override strategy
    defaults, and the subagent key remains present as the backward-compatible
    fallback surface.
    """
    raw = dict(models or {})
    main = _normalize_main(raw.get("main", "default"))
    subagent = validate_worker_model(raw.get("subagent", "inherit"), field="models.subagent")
    strategy_value = raw.get("strategy")
    strategy = str(strategy_value).strip().casefold() if strategy_value not in (None, "") else None
    base = _strategy_base({**raw, "main": main, "subagent": subagent}, strategy)
    resolved: dict[str, str] = {"main": main, "subagent": subagent}
    for role in ROLE_KEYS:
        if role in raw and raw.get(role) not in (None, ""):
            resolved[role] = validate_worker_model(raw.get(role), field=f"models.{role}")
        else:
            resolved[role] = base[role]
    if strategy:
        resolved["strategy"] = strategy
    return resolved


def model_for_role(models: dict[str, Any] | None, role: str) -> str:
    key = str(role).strip().casefold()
    aliases = {"research": "discovery", "discovery": "discovery", "generation": "generation", "audit": "audit"}
    if key not in aliases:
        raise WorldBuilderError(f"unknown worker model role {role!r}")
    resolved = resolve_models(models)
    return resolved[aliases[key]]


def spawn_model_argument(requested_model: Any) -> str | None:
    model = validate_worker_model(requested_model, field="requested_model")
    return None if model == "inherit" else model


def verify_resolved_model(requested_model: Any, resolved_model: Any) -> bool:
    """Validate OpenClaw's returned ``resolvedModel`` for one spawn.

    An inherited route intentionally does not assert which host-selected model
    wins. A concrete request must resolve exactly to that provider/model.
    """
    requested = validate_worker_model(requested_model, field="requested_model")
    resolved_raw = "" if resolved_model is None else str(resolved_model).strip()
    if requested == "inherit":
        return bool(resolved_raw)
    if not resolved_raw:
        raise WorldBuilderError("OpenClaw spawn did not report resolvedModel for an explicit model request")
    # Batch 58 / A08: compare and report the normalized identity; the model
    # portion keeps its exact case rather than being flattened to lowercase.
    resolved = _normalize_model(resolved_raw)
    if resolved != requested:
        raise WorldBuilderError(
            f"OpenClaw resolvedModel mismatch: requested {requested!r}, resolved {resolved!r}"
        )
    return True


def _assignment_route(path: str | Path) -> tuple[Path, dict[str, Any], str]:
    assignment_path = Path(path).expanduser().resolve()
    try:
        assignment = json.loads(assignment_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise WorldBuilderError(f"cannot read assignment {assignment_path}: {exc}") from exc
    if not isinstance(assignment, dict):
        raise WorldBuilderError("assignment must contain a JSON object")
    requested = assignment.get("requested_model", "inherit")
    requested = validate_worker_model(requested, field="assignment.requested_model")
    return assignment_path, assignment, requested


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    route = sub.add_parser("route", help="Resolve the sessions_spawn model argument frozen in one assignment.")
    route.add_argument("--assignment", required=True)
    verify = sub.add_parser("verify", help="Verify OpenClaw's parent-observed resolvedModel for one assignment.")
    verify.add_argument("--assignment", required=True)
    verify.add_argument("--resolved-model", required=True)
    args = parser.parse_args()
    try:
        path, assignment, requested = _assignment_route(args.assignment)
        payload: dict[str, Any] = {
            "assignment": str(path),
            "assignment_id": assignment.get("assignment_id"),
            "role": assignment.get("role"),
            "requested_model": requested,
            "sessions_spawn_model": spawn_model_argument(requested),
        }
        if args.command == "verify":
            verify_resolved_model(requested, args.resolved_model)
            payload["resolved_model"] = str(args.resolved_model).strip()
            payload["verified"] = True
        print(json.dumps(payload, ensure_ascii=False, indent=2))
        return 0
    except (WorldBuilderError, OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
