#!/usr/bin/env python3
"""A faithful port of SillyTavern's real World Info activation algorithm,
built from the actual source (public/scripts/world-info.js), not an
approximation. Confirmed against SillyTavern/SillyTavern's own DeepWiki
source-mapped documentation before writing this; every piece below
cites the real function/constant it's modeling.

Purpose: give subagents (and Claude) a way to empirically verify a
worldbuilding claim, "would this really activate," "does this really
recurse," "is this genuinely an orphan", against the real activation
semantics, not a guess. This is the same "measure the real mechanism,
don't approximate it" discipline `ground_truth_graph.py` established for
content-based edges, extended to the actual scan/logic/budget pipeline.

Deliberately NOT a full SillyTavern reimplementation: no timed effects
(sticky/cooldown/delay), no vector/AI-selection path, no group-scoring
tie-breaks. Those are real, separate pieces; this covers the deterministic
keyword/logic/recursion/budget core precisely, and says so rather than
silently pretending broader coverage than it has.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

# world_info_logic constants (world-info.js:33-38, confirmed exact semantics)
AND_ANY = 0   # primary key found, AND at least one secondary key found
NOT_ALL = 1   # primary key found, AND NOT all secondary keys present
NOT_ANY = 2   # primary key found, AND none of the secondary keys present
AND_ALL = 3   # primary key found, AND all secondary keys present


@dataclass
class WIScanEntry:
    """WIScanEntry schema (world-info.js:116-137)."""
    uid: int
    key: list[str]
    keysecondary: list[str] = field(default_factory=list)
    # Batch 58 / A05: SillyTavern gates secondary-key logic on the entry's own
    # `selective` flag. Without it, an entry carrying secondary keys but not
    # selective was judged by logic it never opted into.
    selective: bool = False
    selective_logic: int = AND_ANY
    content: str = ""
    constant: bool = False
    case_sensitive: bool = False
    match_whole_words: bool = True
    weight: int = 100
    order: int = 100
    disable: bool = False
    non_recursable: bool = False
    prevent_further_recursion: bool = False


def _key_present(text: str, key: str, *, case_sensitive: bool, whole_words: bool) -> bool:
    """Match one key using SillyTavern-compatible literal/regex semantics."""
    if not isinstance(key, str) or not key.strip():
        return False
    stripped = key.strip()
    if stripped.startswith("/"):
        last = stripped.rfind("/")
        if last > 0:
            pattern, flag_text = stripped[1:last], stripped[last + 1:]
            if pattern and all(ch in "ims" for ch in flag_text):
                flags = 0
                if "i" in flag_text: flags |= re.IGNORECASE
                if "m" in flag_text: flags |= re.MULTILINE
                if "s" in flag_text: flags |= re.DOTALL
                try:
                    return re.search(pattern, text, flags) is not None
                except re.error:
                    return False
    haystack = text if case_sensitive else text.lower()
    needle = key if case_sensitive else key.lower()
    # Upstream applies the strict word-boundary path to single-word keys.
    # Multiword phrases are substring-matched, so "New York" also matches
    # "New Yorkshire". Non-word suffixes such as C++ also need substring
    # behavior because JS word-boundary logic cannot sensibly bracket them.
    if whole_words and not any(ch.isspace() for ch in needle) and needle and needle[-1].isalnum() and needle[0].isalnum():
        return re.search(r"(?<!\w)" + re.escape(needle) + r"(?!\w)", haystack) is not None
    return needle in haystack


def _any_key_present(text: str, keys: list[str], *, case_sensitive: bool, whole_words: bool) -> bool:
    return any(_key_present(text, k, case_sensitive=case_sensitive, whole_words=whole_words) for k in keys)


def _all_keys_present(text: str, keys: list[str], *, case_sensitive: bool, whole_words: bool) -> bool:
    return all(_key_present(text, k, case_sensitive=case_sensitive, whole_words=whole_words) for k in keys)


def entry_matches(entry: WIScanEntry, scan_text: str) -> bool:
    """The real activation check for one entry against one buffer's text
    ; constant entries always match (they never even reach this check
    in practice, handled separately in main()), everything else needs a
    primary-key hit at minimum, refined by selective_logic."""
    if entry.disable:
        return False
    primary_hit = _any_key_present(scan_text, entry.key, case_sensitive=entry.case_sensitive, whole_words=entry.match_whole_words)
    # Batch 58 / A05: secondary-key logic applies only to a selective entry that
    # actually has secondary keys.
    if not entry.keysecondary or not entry.selective:
        return primary_hit
    if not primary_hit:
        return False

    secondary_any = _any_key_present(scan_text, entry.keysecondary, case_sensitive=entry.case_sensitive, whole_words=entry.match_whole_words)
    secondary_all = _all_keys_present(scan_text, entry.keysecondary, case_sensitive=entry.case_sensitive, whole_words=entry.match_whole_words)

    # Batch 58 / A05: every selective_logic value requires a primary hit; AND_ANY
    # requires a primary hit AND at least one secondary, matching the constant's
    # own name. It previously returned `primary_hit or secondary_any`, so a
    # secondary key alone activated the entry, and the early-return above had to
    # carve AND_ANY out purely to let that happen.
    if entry.selective_logic == AND_ANY:
        return primary_hit and secondary_any
    if entry.selective_logic == AND_ALL:
        return primary_hit and secondary_all
    if entry.selective_logic == NOT_ALL:
        return primary_hit and not secondary_all
    if entry.selective_logic == NOT_ANY:
        return primary_hit and not secondary_any
    return primary_hit


def scan(
    entries: list[WIScanEntry],
    initial_text: str,
    *,
    recursive: bool = True,
    max_recursion_steps: int = 3,
    entry_tokens: dict[int, int] | None = None,
    token_budget: int | None = None,
) -> dict[str, Any]:
    """The real getWorldInfoPrompt() recursion loop (world-info.js:480-838).

    Reworked to check the depth buffer (real chat text) and recurse
    buffer (other entries' content) SEPARATELY per entry, not as one
    merged string; this is the only way to honor `non_recursable`
    correctly. Confirmed from the real docs wording ("will not be
    activated by OTHER entries"): non_recursable blocks a match found
    only in the recurse buffer, never a match found in the real depth
    buffer. Entries with `prevent_further_recursion` still activate
    normally but never contribute their own content to the recurse
    buffer for later rounds.
    """
    activated: dict[int, WIScanEntry] = {}
    activation_round: dict[int, int] = {}
    depth_buffer = initial_text
    recurse_buffer = ""
    round_num = 0

    for entry in entries:
        if entry.constant and not entry.disable:
            activated[entry.uid] = entry
            activation_round[entry.uid] = 0

    # Batch 57: a constant entry activates in the real engine's first pass and
    # its content joins the recursion buffer like any other activated entry.
    # Seeding constants outside the loop and never adding them to the buffer
    # made every constant silently non-recursing here, which hid the exact
    # failure the world index's prevent_recursion exists to prevent: an
    # always-on roster arming every entry it names on every turn.
    # Batch 58 / A05: with recursion off there is no recursion buffer, so
    # constant content must not activate keyed entries. Seeding it
    # unconditionally did exactly that.
    if recursive:
        seeded = "\n".join(
            entry.content
            for entry in entries
            if entry.constant and not entry.disable and not entry.prevent_further_recursion
        )
        if seeded.strip():
            recurse_buffer = seeded

    # A direct (depth-buffer) match is not a recursion step, so at least one pass
    # always runs. max_recursion_steps=0 previously skipped the loop entirely and
    # silently reported no matches at all.
    while round_num < max(1, max_recursion_steps):
        newly_activated: list[WIScanEntry] = []
        for entry in entries:
            if entry.uid in activated or entry.disable:
                continue
            depth_hit = entry_matches(entry, depth_buffer)
            recurse_hit = bool(recurse_buffer) and entry_matches(entry, recurse_buffer)
            if depth_hit or (recurse_hit and not entry.non_recursable):
                newly_activated.append(entry)
        if not newly_activated:
            break
        for entry in newly_activated:
            activated[entry.uid] = entry
            activation_round[entry.uid] = round_num + 1
        if not recursive:
            break
        recurse_buffer += "\n" + "\n".join(
            e.content for e in newly_activated if not e.prevent_further_recursion
        )
        round_num += 1

    ordered = sorted(activated.values(), key=lambda e: (-e.weight, -e.order, e.uid))
    report: dict[str, Any] = {
        "activated_uids": [e.uid for e in ordered],
        "activation_round": activation_round,
        "rounds_run": round_num,
        "ordered_entries": [{"uid": e.uid, "weight": e.weight, "order": e.order} for e in ordered],
    }
    if token_budget is None:
        return report
    # Budget truncation runs strictly after the sort, mirroring the real
    # algorithm's post-sort budget slice: the structural spine (highest
    # weight/order) survives token pressure before flavor content does.
    tokens = entry_tokens or {}
    kept: list[int] = []
    excluded: list[int] = []
    used = 0
    for e in ordered:
        cost = int(tokens.get(e.uid, max(1, len(e.content) // 4)))
        if used + cost > token_budget:
            excluded.append(e.uid)
            continue
        used += cost
        kept.append(e.uid)
    report["budget_applied"] = True
    report["budget_kept_uids"] = kept
    report["budget_excluded_uids"] = excluded
    report["budget_total_tokens"] = used
    report["ordered_entries"] = [
        {"uid": e.uid, "weight": e.weight, "order": e.order,
         "tokens": int(tokens.get(e.uid, max(1, len(e.content) // 4)))}
        for e in ordered
    ]
    return report


def entries_from_dicts(rows: list[dict[str, Any]]) -> list[WIScanEntry]:
    """Convert manifest/artifact entry dicts (CCv3 or ST-native field
    naming) into scanner entries so any real book can be measured.

    Batch 57: a manifest-stage entry keeps its activation settings under an
    ``emit`` wrapper (and its recursion flags under ``emit.extensions``),
    while a delivered SillyTavern book keeps them at the top level. Reading
    only the top level silently scanned every manifest entry as keyless,
    non-constant and fully recursable, which made the whole scan meaningless
    on exactly the shape planning uses. Both shapes are now read, top level
    first.
    """
    out: list[WIScanEntry] = []
    for row in rows:
        if not isinstance(row, dict):
            continue
        uid = row.get("uid", row.get("id"))
        if uid is None:
            continue
        emit = row.get("emit")
        emit = emit if isinstance(emit, dict) else {}
        extension_sources = [
            source
            for source in (row.get("extensions"), emit.get("extensions"))
            if isinstance(source, dict)
        ]

        def _first(*names: str) -> Any:
            """Top level, then the emit wrapper, then either extensions map."""
            for name in names:
                if name in row and row[name] is not None:
                    return row[name]
            for name in names:
                if name in emit and emit[name] is not None:
                    return emit[name]
            for source in extension_sources:
                for name in names:
                    if name in source and source[name] is not None:
                        return source[name]
            return None

        primary = _first("key", "keys")
        primary = primary if isinstance(primary, list) else []
        secondary = _first("keysecondary", "secondary_keys")
        secondary = secondary if isinstance(secondary, list) else []
        # SillyTavern's preventRecursion: activates normally, but its content
        # never feeds the next recursion round.
        prevent_recursion = bool(
            _first("prevent_further_recursion", "preventRecursion", "prevent_recursion")
        )
        # This scanner's `non_recursable` is SillyTavern's excludeRecursion
        # ("will not be activated by OTHER entries"). excludeRecursion /
        # exclude_recursion is what the field registry, activation_semantics
        # and runtime_target_adapter actually carry and emit, so a scan that
        # only looked for nonRecursable measured every real build as fully
        # recursable and the Batch 46 dampening guidance was unobservable.
        # Real field first, historical spellings kept as accepted aliases.
        non_recursable = bool(
            _first("excludeRecursion", "exclude_recursion", "nonRecursable", "non_recursable")
        )
        weight_raw = _first("weight")
        order_raw = _first("order", "insertion_order")
        enabled = _first("enabled")
        selective_logic = _first("selective_logic", "selectiveLogic")
        whole_words = _first("match_whole_words", "matchWholeWords")
        out.append(WIScanEntry(
            uid=int(uid) if isinstance(uid, bool) or str(uid).lstrip("-").isdigit() else uid,
            key=[str(k) for k in primary],
            keysecondary=[str(k) for k in secondary],
            selective=bool(_first("selective")),
            selective_logic=AND_ANY if selective_logic is None else selective_logic,
            content=str(row.get("content") or ""),
            constant=bool(_first("constant")),
            case_sensitive=bool(_first("case_sensitive", "caseSensitive") or False),
            match_whole_words=whole_words is not False,
            weight=int(weight_raw or 100),
            order=int(order_raw or 100),
            disable=bool(_first("disable")) or enabled is False,
            non_recursable=non_recursable,
            prevent_further_recursion=prevent_recursion,
        ))
    return out


def diagnostic_report(
    entries: list[WIScanEntry],
    messages: list[str],
    *,
    depth_limit: int = 8,
    entry_tokens: dict[int, int] | None = None,
    token_budget: int | None = None,
) -> dict[str, Any]:
    """Universal pre-ship activation-count report (Batch 46): run ordinary,
    innocuous messages through the real scan for any book and flag when a
    single mention activates a majority of eligible entries."""
    eligible = [e for e in entries if not e.disable and not e.constant]
    rows: list[dict[str, Any]] = []
    max_count = 0
    max_fraction = 0.0
    flagged = False
    for message in messages:
        result = scan(entries, message, recursive=True, max_recursion_steps=depth_limit,
                      entry_tokens=entry_tokens, token_budget=token_budget)
        active = {uid for uid in result["activated_uids"]}
        activated_eligible = [e.uid for e in eligible if e.uid in active]
        fraction = (len(activated_eligible) / len(eligible)) if eligible else 0.0
        max_count = max(max_count, len(activated_eligible))
        max_fraction = max(max_fraction, fraction)
        if fraction > 0.5:
            flagged = True
        rows.append({
            "message": message,
            "activated_count": len(activated_eligible),
            "activated_fraction": round(fraction, 4),
            "activated_uids": activated_eligible,
            "total_eligible_entries": len(eligible),
        })
    return {
        "kind": "worldbuilder-activation-scan-report",
        "report_version": 1,
        "entry_count": len(entries),
        "eligible_entry_count": len(eligible),
        "message_count": len(messages),
        "max_activated_count": max_count,
        "max_activated_fraction": round(max_fraction, 4),
        "majority_activation_flagged": flagged,
        "messages": rows,
    }
