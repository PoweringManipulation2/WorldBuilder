#!/usr/bin/env python3
"""Validate and atomically commit one discovery worker result."""
from __future__ import annotations
import argparse
import json
import sys
from pathlib import Path
from typing import Any
from discovery_contract import DISCOVERY_ASSIGNMENT_VERSION, DISCOVERY_RESULT_VERSION, ENTITY_TYPES, canonicalize_url, exclusion_policy, validate_contract
from entity_taxonomy import normalize_entity
from wb_common import WorldBuilderError, atomic_write_json, ensure_inside, load_json, sha256_file

def urls(value: Any, label: str) -> list[str]:
    if value is None:
        return []
    if not isinstance(value, list):
        raise WorldBuilderError(f"{label} must be a list")
    result: list[str] = []
    for item in value:
        raw = item.get("url") if isinstance(item, dict) else item
        url = canonicalize_url(raw)
        if not url:
            raise WorldBuilderError(f"{label} contains invalid URL {raw!r}")
        if url in result:
            raise WorldBuilderError(f"{label} repeats URL {url}")
        result.append(url)
    return result

def validate_candidate(assignment: dict[str, Any], candidate: dict[str, Any], assignment_path: Path) -> dict[str, Any]:
    if assignment.get("assignment_version") != DISCOVERY_ASSIGNMENT_VERSION:
        raise WorldBuilderError(
            f"assignment must use version {DISCOVERY_ASSIGNMENT_VERSION}: this tool commits one breadth-discovery "
            "worker result only. Generation phases are proved by phase_gate.py --stage pre-merge plus per-UID "
            "entry_cycle_gate.py receipts, never by this committer."
        )
    validate_contract(assignment.get("contract"), label="assignment.contract")
    meta = candidate.get("_worldbuilder")
    if not isinstance(meta, dict):
        raise WorldBuilderError("candidate lacks _worldbuilder metadata")
    expected = {
        "kind": "breadth-discovery", "result_version": DISCOVERY_RESULT_VERSION,
        "build_id": assignment.get("build_id"), "assignment_id": assignment.get("assignment_id"),
        "assignment_sha256": sha256_file(assignment_path), "corpus_sha256": assignment.get("corpus_sha256"),
        "worker": assignment.get("worker"), "taskName": assignment.get("taskName"),
        "pass_number": assignment.get("pass_number"), "completed": True,
        "runtime_status": "completed", "end_delimiter": assignment.get("expected_end_delimiter"),
    }
    for key, wanted in expected.items():
        if meta.get(key) != wanted:
            raise WorldBuilderError(f"candidate metadata mismatch at {key}: {meta.get(key)!r} != {wanted!r}")
    validate_contract(meta.get("contract"), label="candidate._worldbuilder.contract", worker_kit_sha256=(assignment.get("contract") or {}).get("worker_kit_sha256"))
    assigned = set(urls(assignment.get("page_urls"), "assignment.page_urls"))
    visited = set(urls(candidate.get("visited_urls"), "candidate.visited_urls"))
    failed = set(urls(candidate.get("failed_urls"), "candidate.failed_urls"))
    excluded_items = candidate.get("excluded_urls") or []
    delegated_items = candidate.get("delegated_urls") or []
    excluded = set(urls(excluded_items, "candidate.excluded_urls"))
    delegated = set(urls(delegated_items, "candidate.delegated_urls"))
    for label, items in (("excluded_urls", excluded_items), ("delegated_urls", delegated_items)):
        if not isinstance(items, list):
            raise WorldBuilderError(f"candidate.{label} must be a list")
        for index, item in enumerate(items):
            if not isinstance(item, dict) or not isinstance(item.get("reason"), str) or len(item["reason"].strip()) < 5:
                raise WorldBuilderError(f"candidate.{label}[{index}] requires url and reason")
            if label == "excluded_urls":
                exclusion_policy(item.get("code"))
    groups = {"visited": visited, "failed": failed, "excluded": excluded, "delegated": delegated}
    labels = list(groups)
    for index, left in enumerate(labels):
        for right in labels[index + 1:]:
            overlap = groups[left] & groups[right]
            if overlap:
                raise WorldBuilderError(f"candidate lists URLs as both {left} and {right}: {sorted(overlap)[:5]}")
    accounted = set().union(*groups.values())
    if accounted != assigned:
        raise WorldBuilderError(f"candidate URL accounting mismatch; missing={sorted(assigned-accounted)[:5]}, extra={sorted(accounted-assigned)[:5]}")
    records = candidate.get("fetch_records")
    if not isinstance(records, list) or len(records) != len(assigned):
        raise WorldBuilderError("candidate must contain exactly one fetch record per assigned URL")
    if set(urls(records, "candidate.fetch_records")) != assigned:
        raise WorldBuilderError("fetch_records do not match assigned URLs")
    entities = candidate.get("entities")
    if not isinstance(entities, list):
        raise WorldBuilderError("candidate.entities must be a list")
    normalized: list[dict[str, Any]] = []
    for item in entities:
        if not isinstance(item, dict):
            raise WorldBuilderError("every candidate entity must be an object")
        entity = normalize_entity(item)
        if entity.get("type") not in ENTITY_TYPES:
            raise WorldBuilderError(f"unsupported entity type {entity.get('type')!r}")
        normalized.append(entity)
    result = dict(candidate)
    result["entities"] = normalized
    if not normalized and result.get("no_results") is not True:
        raise WorldBuilderError("empty candidate must set no_results=true")
    return result

def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--assignment", required=True)
    parser.add_argument("--candidate", required=True)
    parser.add_argument("--output")
    args = parser.parse_args()
    try:
        assignment_path = Path(args.assignment).resolve()
        assignment = load_json(assignment_path)
        candidate = load_json(Path(args.candidate).resolve())
        if not isinstance(assignment, dict) or not isinstance(candidate, dict):
            raise WorldBuilderError("assignment and candidate must be JSON objects")
        output_value = args.output or assignment.get("output_abs") or assignment.get("output")
        if not isinstance(output_value, str) or not output_value:
            raise WorldBuilderError("assignment has no output path")
        output = Path(output_value).expanduser()
        workspace = Path(str(assignment.get("workspace_root"))).resolve()
        if not output.is_absolute():
            output = workspace / output
        output = output.resolve()
        ensure_inside(output, workspace)
        value = validate_candidate(assignment, candidate, assignment_path)
        atomic_write_json(output, value)
        print(json.dumps({"status": "committed", "output": str(output), "output_sha256": sha256_file(output), "entities": len(value.get("entities", []))}, indent=2))
        return 0
    except (WorldBuilderError, OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
if __name__ == "__main__":
    raise SystemExit(main())
