#!/usr/bin/env python3
"""Validate WorldBuilder card and lorebook JSON with explicit rule profiles.

Profiles are cumulative:

``spec``
    Character Card V3 / Lorebook V3 structural requirements only.
``sillytavern`` (default)
    Spec checks plus import/runtime compatibility checks for SillyTavern-native
    World Info data. Optional application settings remain optional.
``worldbuilder``
    Adds non-blocking editorial/style recommendations. These are never labeled
    schema errors.

Exit 0 means no errors, 1 means errors (or warnings with --strict-warnings), and
2 means the input could not be read as JSON.
"""
from __future__ import annotations

import argparse
import json
import math
import re
import sys
from urllib.parse import urlparse
from collections import defaultdict
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

from entry_naming import content_provenance_matches
from wb_common import (
    ArtifactInfo,
    WorldBuilderError,
    canonical_entry_identity,
    detect_artifact,
    iter_entries,
    load_json,
    load_json_strict,
)

CARD_DATA_REQUIRED_TYPES: dict[str, type | tuple[type, ...]] = {
    "name": str,
    "description": str,
    "tags": list,
    "creator": str,
    "character_version": str,
    "mes_example": str,
    "extensions": dict,
    "system_prompt": str,
    "post_history_instructions": str,
    "first_mes": str,
    "alternate_greetings": list,
    "personality": str,
    "scenario": str,
    "creator_notes": str,
    "group_only_greetings": list,
}

CCV3_ENTRY_REQUIRED_TYPES: dict[str, type | tuple[type, ...]] = {
    "keys": list,
    "content": str,
    "extensions": dict,
    "enabled": bool,
    "insertion_order": (int, float),
    "use_regex": bool,
}

ST_NATIVE_TYPES: dict[str, type | tuple[type, ...]] = {
    "key": list,
    "keysecondary": list,
    "content": str,
    "comment": str,
    "constant": bool,
    "vectorized": bool,
    "selective": bool,
    "selectiveLogic": (int, str),
    "order": (int, float),
    "position": (int, str),
    "disable": bool,
    "excludeRecursion": bool,
    "preventRecursion": bool,
    "delayUntilRecursion": (int, float, bool),
    "probability": (int, float),
    "useProbability": bool,
    "depth": (int, float),
    "group": str,
    "groupOverride": bool,
    "groupWeight": (int, float),
    "scanDepth": (int, float),
    "caseSensitive": bool,
    "matchWholeWords": bool,
    "useGroupScoring": bool,
    "automationId": str,
    "role": (int, str),
    "sticky": (int, float),
    "cooldown": (int, float),
    "delay": (int, float),
    "triggers": list,
    "characterFilter": (list, dict),
}

ST_NATIVE_NULLABLE = {
    "delayUntilRecursion", "scanDepth", "caseSensitive", "matchWholeWords",
    "useGroupScoring", "sticky", "cooldown", "delay", "groupWeight",
    "depth", "role", "automationId",
}

CCV3_CARD_ALLOWED = set(CARD_DATA_REQUIRED_TYPES) | {
    "character_book", "assets", "nickname", "creator_notes_multilingual",
    "source", "creation_date", "modification_date",
}
CCV3_ENTRY_ALLOWED = set(CCV3_ENTRY_REQUIRED_TYPES) | {
    "id", "name", "comment", "priority", "case_sensitive", "constant",
    "selective", "secondary_keys", "position",
}
CCV3_BOOK_ALLOWED = {
    "name", "description", "scan_depth", "token_budget", "recursive_scanning",
    "extensions", "entries",
}
STANDARD_ASSET_TYPES = {"icon", "background", "emotion", "user_icon", "other"}
LANGUAGE_CODE_RE = re.compile(r"^[a-z]{2}$")
SOURCE_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:/#@+~-]*$")


@dataclass
class Issue:
    severity: str
    code: str
    path: str
    message: str
    profile: str
    # Optional, structured detail for callers that need more than the
    # message string; added specifically so plan-conformance checking
    # (sillytavern_import_probe.py) can report {uid, field, delivered,
    # planned} directly rather than parsing it back out of prose. None for
    # every pre-existing caller; fully backward compatible.
    context: dict[str, Any] | None = None


class Report:
    def __init__(self, profile: str) -> None:
        self.profile = profile
        self.issues: list[Issue] = []

    def error(self, code: str, path: str, message: str, profile: str = "spec", context: dict[str, Any] | None = None) -> None:
        self.issues.append(Issue("error", code, path, message, profile, context))

    def warning(self, code: str, path: str, message: str, profile: str = "sillytavern", context: dict[str, Any] | None = None) -> None:
        self.issues.append(Issue("warning", code, path, message, profile, context))

    @property
    def errors(self) -> list[Issue]:
        return [issue for issue in self.issues if issue.severity == "error"]

    @property
    def warnings(self) -> list[Issue]:
        return [issue for issue in self.issues if issue.severity == "warning"]


def detect_schema(data: Any) -> int | None:
    """Backwards-compatible helper used by tests and other scripts."""
    return detect_artifact(data).schema


def is_number(value: Any) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(float(value))


def require_type(report: Report, obj: dict, key: str, expected: type | tuple[type, ...], path: str, required: bool = True) -> None:
    if key not in obj:
        if required:
            report.error("missing-field", f"{path}/{key}", f"required field {key!r} is missing")
        return
    value = obj[key]
    if expected == (int, float):
        valid = is_number(value)
    else:
        valid = isinstance(value, expected)
    if not valid:
        if isinstance(expected, tuple):
            label = " or ".join(t.__name__ for t in expected)
        else:
            label = expected.__name__
        report.error("wrong-type", f"{path}/{key}", f"expected {label}, got {type(value).__name__}")


def validate_string_array(report: Report, value: Any, path: str, required: bool = False) -> None:
    if value is None and not required:
        return
    if not isinstance(value, list):
        report.error("wrong-type", path, "expected an array of strings")
        return
    for index, item in enumerate(value):
        if not isinstance(item, str):
            report.error("wrong-type", f"{path}/{index}", "expected a string")


def validate_card(report: Report, data: dict, info: ArtifactInfo) -> None:
    if data.get("spec") != "chara_card_v3":
        report.error("wrong-spec", "/spec", "Character Card V3 requires exactly 'chara_card_v3'")
    version = data.get("spec_version")
    if not isinstance(version, str):
        report.error("wrong-type", "/spec_version", "spec_version must be a string")
    elif version != "3.0":
        try:
            numeric = float(version)
        except ValueError:
            report.error("invalid-version", "/spec_version", "spec_version must be numeric text such as '3.0'")
        else:
            if numeric < 3.0:
                report.error("old-version", "/spec_version", "this validator requires Character Card V3")
            else:
                report.warning("future-version", "/spec_version", "newer V3 version: unknown fields are preserved but not fully validated")

    payload = data.get("data")
    if not isinstance(payload, dict):
        report.error("wrong-type", "/data", "data must be an object")
        return
    for key, expected in CARD_DATA_REQUIRED_TYPES.items():
        require_type(report, payload, key, expected, "/data")
    if isinstance(payload.get("name"), str) and not payload["name"].strip():
        report.error("empty-name", "/data/name", "Character Name must not be empty")
    validate_string_array(report, payload.get("tags"), "/data/tags", required=True)
    validate_string_array(report, payload.get("alternate_greetings"), "/data/alternate_greetings", required=True)
    validate_string_array(report, payload.get("group_only_greetings"), "/data/group_only_greetings", required=True)

    for optional_string in ("nickname",):
        if optional_string in payload and not isinstance(payload[optional_string], str):
            report.error("wrong-type", f"/data/{optional_string}", "expected a string")
    if "source" in payload:
        validate_string_array(report, payload["source"], "/data/source")
        if isinstance(payload["source"], list):
            for index, value in enumerate(payload["source"]):
                if not isinstance(value, str):
                    continue
                parsed = urlparse(value)
                if parsed.scheme and parsed.scheme not in {"http", "https"}:
                    report.error("invalid-source", f"/data/source/{index}", "source URIs must use HTTP or HTTPS")
                elif not parsed.scheme and not SOURCE_ID_RE.fullmatch(value):
                    report.error("invalid-source", f"/data/source/{index}", "source must be an ID or HTTP/HTTPS URL")
    if "creator_notes_multilingual" in payload:
        value = payload["creator_notes_multilingual"]
        if not isinstance(value, dict) or any(not isinstance(k, str) or not isinstance(v, str) for k, v in value.items()):
            report.error("wrong-type", "/data/creator_notes_multilingual", "expected an object of language-code to string")
        elif any(not LANGUAGE_CODE_RE.fullmatch(key) for key in value):
            report.error("invalid-language-code", "/data/creator_notes_multilingual", "keys must be lowercase ISO 639-1 language codes without regions")
    for date_key in ("creation_date", "modification_date"):
        if date_key in payload and (not isinstance(payload[date_key], int) or isinstance(payload[date_key], bool) or payload[date_key] < 0):
            report.error("wrong-type", f"/data/{date_key}", "expected a non-negative Unix timestamp integer in seconds")
    validate_assets(report, payload.get("assets"), "/data/assets")
    for key in sorted(set(payload) - CCV3_CARD_ALLOWED):
        report.error("application-field-outside-extensions", f"/data/{key}", "application-specific CCv3 card data must be stored under extensions")
    for key in sorted(set(data) - {"spec", "spec_version", "data"}):
        report.error("application-field-outside-extensions", f"/{key}", "application-specific CharacterCard wrapper data must be stored under data.extensions")

    if info.schema == 2:
        book = payload.get("character_book")
        if not isinstance(book, dict):
            report.error("wrong-type", "/data/character_book", "character_book must be a Lorebook object")
        else:
            validate_ccv3_lorebook(report, book, "/data/character_book")


def validate_assets(report: Report, assets: Any, path: str) -> None:
    if assets is None:
        return
    if not isinstance(assets, list):
        report.error("wrong-type", path, "assets must be an array")
        return
    counts = {"icon": 0, "background": 0}
    mains = {"icon": 0, "background": 0}
    seen_embed: set[str] = set()
    for index, asset in enumerate(assets):
        apath = f"{path}/{index}"
        if not isinstance(asset, dict):
            report.error("wrong-type", apath, "asset must be an object")
            continue
        for field in ("type", "uri", "name", "ext"):
            require_type(report, asset, field, str, apath)
        asset_type = asset.get("type")
        if isinstance(asset_type, str) and asset_type not in STANDARD_ASSET_TYPES and not asset_type.startswith("x_"):
            report.error("invalid-asset-type", f"{apath}/type", "use a standard type or an application-specific x_ prefix")
        if asset_type in counts:
            counts[asset_type] += 1
            if asset.get("name") == "main":
                mains[asset_type] += 1
        ext = asset.get("ext")
        if isinstance(ext, str) and (not ext or ext.startswith(".") or ext.lower() != ext):
            report.error("invalid-asset-ext", f"{apath}/ext", "asset extension must be lowercase without a leading dot")
        uri = asset.get("uri")
        if isinstance(uri, str):
            if uri == "ccdefault:":
                pass
            elif uri.startswith("embeded://"):
                member = uri[len("embeded://"): ]
                try:
                    from wb_common import safe_archive_path
                    safe_archive_path(member)
                except WorldBuilderError as exc:
                    report.error("invalid-asset-uri", f"{apath}/uri", str(exc))
                folded = member.casefold()
                if folded in seen_embed:
                    report.error("duplicate-asset-uri", f"{apath}/uri", "embedded asset URI is duplicated case-insensitively")
                seen_embed.add(folded)
            else:
                parsed = urlparse(uri)
                if parsed.scheme not in {"http", "https", "data"}:
                    report.error("invalid-asset-uri", f"{apath}/uri", "asset URI must use http, https, data, embeded://, or ccdefault:")
    for kind in ("icon", "background"):
        if counts[kind] > 1 and mains[kind] != 1:
            report.error(f"main-{kind}-count", path, f"multiple {kind} assets require exactly one named 'main'")


def validate_lorebook_container_common(report: Report, book: dict, path: str) -> None:
    for key, expected in {
        "name": str,
        "description": str,
        "scan_depth": (int, float),
        "token_budget": (int, float),
        "recursive_scanning": bool,
    }.items():
        require_type(report, book, key, expected, path, required=False)
    require_type(report, book, "extensions", dict, path)
    require_type(report, book, "entries", list, path)


def validate_ccv3_lorebook(report: Report, book: dict, path: str) -> None:
    validate_lorebook_container_common(report, book, path)
    for key in sorted(set(book) - CCV3_BOOK_ALLOWED):
        report.error("application-field-outside-extensions", f"{path}/{key}", "application-specific Lorebook data must be stored under extensions")
    entries = book.get("entries")
    if not isinstance(entries, list):
        return
    for index, entry in enumerate(entries):
        epath = f"{path}/entries/{index}"
        if not isinstance(entry, dict):
            report.error("wrong-type", epath, "entry must be an object")
            continue
        validate_ccv3_entry(report, entry, epath)


def validate_decorators(report: Report, content: str, path: str) -> None:
    """Batch 9: recognizes @@-prefixed leading decorator lines in an
    entry's content, per the CCv3 spec (kwaroran/character-card-spec-v3,
    SPEC_V3.md). Recognition alone is enough to make budget_contract.py's
    estimator (which reads decorators.parse_leading_decorators the same
    way) correctly exclude decorator lines from token counting; they
    are trimmed before prompting per the spec, and were never real
    content to begin with. This function additionally validates known
    decorator value shapes; a malformed known decorator (@@depth with a
    non-numeric value, @@role with an unrecognized value) is a blocking
    error, not a warning; the spec defines these shapes precisely, and
    a card claiming @@role monster is not a card an application can
    honor, not a stylistic choice to tolerate.
    """
    from decorators import parse_leading_decorators, first_effective_value, KNOWN_DECORATOR_NAMES

    decorators_found, _remaining = parse_leading_decorators(content)
    numeric_decorators = {
        "depth", "instruct_depth", "reverse_depth", "reverse_instruct_depth",
        "scan_depth", "instruct_scan_depth", "is_greeting", "activate_only_after", "activate_only_every",
    }
    for name in numeric_decorators:
        value = first_effective_value(decorators_found, name)
        if value is None:
            continue
        try:
            float(value)
        except ValueError:
            report.error("malformed-decorator-value", f"{path}/content", f"@@{name} requires a numeric value, got {value!r}")
    role_value = first_effective_value(decorators_found, "role")
    if role_value is not None and role_value not in {"assistant", "system", "user"}:
        report.error("malformed-decorator-value", f"{path}/content", f"@@role must be one of assistant/system/user, got {role_value!r}")
    for d in decorators_found:
        if d.name not in KNOWN_DECORATOR_NAMES and not d.is_fallback:
            report.warning(
                "unrecognized-decorator", f"{path}/content",
                f"@@{d.name} is not a decorator this codebase interprets; preserved through round-trip, but no semantic meaning is applied",
            )


def validate_ccv3_entry(report: Report, entry: dict, path: str) -> None:
    for key, expected in CCV3_ENTRY_REQUIRED_TYPES.items():
        require_type(report, entry, key, expected, path)
    validate_string_array(report, entry.get("keys"), f"{path}/keys", required=True)
    if "secondary_keys" in entry:
        value = entry["secondary_keys"]
        if isinstance(value, str):
            report.warning("secondary-keys-string", f"{path}/secondary_keys", "string form is tolerated; arrays round-trip more reliably")
        else:
            validate_string_array(report, value, f"{path}/secondary_keys")
    for key in ("case_sensitive", "constant", "selective"):
        require_type(report, entry, key, bool, path, required=False)
    for key in ("name", "comment"):
        require_type(report, entry, key, str, path, required=False)
    require_type(report, entry, "id", (str, int), path, required=False)
    if "uid" in entry:
        report.error(
            "ccv3-top-level-uid",
            f"{path}/uid",
            "CCv3 lorebook entries use optional 'id'; remove top-level 'uid' or keep application-specific identity under extensions",
        )
    for key in ("priority",):
        require_type(report, entry, key, (int, float), path, required=False)
    if "position" in entry and entry["position"] not in {"before_char", "after_char"}:
        report.error(
            "invalid-core-position",
            f"{path}/position",
            "CCv3 core position is limited to 'before_char' or 'after_char'; store SillyTavern extended placement under extensions",
        )
    for key in sorted(set(entry) - CCV3_ENTRY_ALLOWED):
        report.error("application-field-outside-extensions", f"{path}/{key}", "application-specific lorebook entry data must be stored under extensions")
    ext = entry.get("extensions")
    if isinstance(ext, dict):
        validate_optional_st_extensions(report, ext, f"{path}/extensions")
    validate_activation(report, entry, path, ccv3=True)
    if isinstance(entry.get("content"), str):
        validate_decorators(report, entry["content"], path)



def validate_worldbuilder_dynamic(report: Report, value: Any, path: str) -> None:
    if not isinstance(value, dict):
        report.error("dynamic-envelope-type", path, "worldbuilder_dynamic must be an object", profile="sillytavern")
        return
    if value.get("contract") != "worldbuilder-dynamic-state-v1":
        report.error("dynamic-envelope-contract", f"{path}/contract", "worldbuilder_dynamic has an unsupported contract", profile="sillytavern")
    purpose = value.get("purpose")
    if not isinstance(purpose, str) or not purpose.strip():
        report.error("dynamic-envelope-purpose", f"{path}/purpose", "dynamic entries require a non-empty purpose", profile="sillytavern")
    probability = value.get("probability", 100)
    if not isinstance(probability, int) or isinstance(probability, bool) or not 0 <= probability <= 100:
        report.error("dynamic-envelope-probability", f"{path}/probability", "probability must be an integer from 0 to 100", profile="sillytavern")
    if "probability_enabled" in value and not isinstance(value["probability_enabled"], bool):
        report.error("dynamic-envelope-probability-enabled", f"{path}/probability_enabled", "probability_enabled must be boolean", profile="sillytavern")
    groups = value.get("groups", [])
    if not isinstance(groups, list):
        report.error("dynamic-envelope-groups", f"{path}/groups", "groups must be an array", profile="sillytavern")
    else:
        for index, row in enumerate(groups):
            rpath=f"{path}/groups/{index}"
            if not isinstance(row, dict):
                report.error("dynamic-envelope-group", rpath, "group row must be an object", profile="sillytavern"); continue
            if not isinstance(row.get("group_id"), str) or not row.get("group_id", "").strip(): report.error("dynamic-envelope-group-id", f"{rpath}/group_id", "group_id is required", profile="sillytavern")
            if row.get("selection") not in {"weighted_random", "priority"}: report.error("dynamic-envelope-group-selection", f"{rpath}/selection", "selection must be weighted_random or priority", profile="sillytavern")
            if not isinstance(row.get("weight", 100), int) or isinstance(row.get("weight", 100), bool) or row.get("weight", 100) <= 0: report.error("dynamic-envelope-group-weight", f"{rpath}/weight", "weight must be a positive integer", profile="sillytavern")
            if not isinstance(row.get("group_scoring", False), bool): report.error("dynamic-envelope-group-scoring", f"{rpath}/group_scoring", "group_scoring must be boolean", profile="sillytavern")
    timed = value.get("timed_effects", {})
    if not isinstance(timed, dict):
        report.error("dynamic-envelope-timed", f"{path}/timed_effects", "timed_effects must be an object", profile="sillytavern")
    else:
        for key, amount in timed.items():
            if key not in {"sticky", "cooldown", "delay"} or not isinstance(amount, int) or isinstance(amount, bool) or amount < 0:
                report.error("dynamic-envelope-timed", f"{path}/timed_effects/{key}", "timed effects must be non-negative integer sticky/cooldown/delay values", profile="sillytavern")
    for key in ("matching_sources", "generation_triggers"):
        if key in value and (not isinstance(value[key], list) or any(not isinstance(item, str) or not item for item in value[key])):
            report.error("dynamic-envelope-list", f"{path}/{key}", f"{key} must be an array of non-empty strings", profile="sillytavern")
    char_filter=value.get("character_filter")
    if char_filter is not None:
        if not isinstance(char_filter, dict) or char_filter.get("mode") not in {"include", "exclude"}:
            report.error("dynamic-envelope-filter", f"{path}/character_filter", "character_filter requires include/exclude mode", profile="sillytavern")
        elif not any(isinstance(char_filter.get(key), list) and char_filter.get(key) for key in ("names", "tags")):
            report.error("dynamic-envelope-filter", f"{path}/character_filter", "character_filter requires names or tags", profile="sillytavern")
        else:
            for marker in ("runtime_character_ids", "runtime_tag_ids"):
                if marker in char_filter and not isinstance(char_filter[marker], bool):
                    report.error("dynamic-envelope-filter", f"{path}/character_filter/{marker}", f"{marker} must be boolean", profile="sillytavern")
    for key in ("automation_id", "named_outlet"):
        if key in value and (not isinstance(value[key], str) or not value[key].strip()):
            report.error("dynamic-envelope-string", f"{path}/{key}", f"{key} must be a non-empty string", profile="sillytavern")
    greetings = value.get("greeting_variants", [])
    if not isinstance(greetings, list):
        report.error("dynamic-envelope-greetings", f"{path}/greeting_variants", "greeting_variants must be an array", profile="sillytavern")
    else:
        for index, row in enumerate(greetings):
            rpath = f"{path}/greeting_variants/{index}"
            if not isinstance(row, dict):
                report.error("dynamic-envelope-greeting", rpath, "greeting variant must be an object", profile="sillytavern")
                continue
            if not isinstance(row.get("variant_id"), str) or not row.get("variant_id", "").strip():
                report.error("dynamic-envelope-greeting-id", f"{rpath}/variant_id", "variant_id is required", profile="sillytavern")
            if row.get("scope") not in {"primary", "alternate", "group_only"}:
                report.error("dynamic-envelope-greeting-scope", f"{rpath}/scope", "scope must be primary, alternate, or group_only", profile="sillytavern")
            group = row.get("inclusion_group")
            if group is not None and (not isinstance(group, str) or not group.strip()):
                report.error("dynamic-envelope-greeting-group", f"{rpath}/inclusion_group", "inclusion_group must be a non-empty string or null", profile="sillytavern")


def validate_worldbuilder_runtime(report: Report, value: Any, path: str) -> None:
    if not isinstance(value, dict):
        report.error("runtime-envelope-type", path, "worldbuilder_runtime must be an object", profile="sillytavern")
        return
    if value.get("contract") != "worldbuilder-runtime-semantics-v1":
        report.error("runtime-envelope-contract", f"{path}/contract", "worldbuilder_runtime has an unsupported contract", profile="sillytavern")
    fields = value.get("fields")
    if not isinstance(fields, dict):
        report.error("runtime-envelope-fields", f"{path}/fields", "runtime fields must be an object", profile="sillytavern")
        return
    allowed = {
        "vectorized", "exclude_recursion", "prevent_recursion", "delay_until_recursion",
        "depth", "role", "scan_depth", "match_whole_words", "ignore_budget",
        "position", "selective_logic", "case_sensitive", "display_index",
    }
    for key in sorted(set(fields) - allowed):
        report.error("runtime-envelope-field", f"{path}/fields/{key}", "unsupported neutral runtime semantic", profile="sillytavern")
    for key in ("vectorized", "exclude_recursion", "prevent_recursion", "match_whole_words", "ignore_budget"):
        if key in fields and fields[key] is not None and not isinstance(fields[key], bool):
            report.error("runtime-envelope-type", f"{path}/fields/{key}", f"{key} must be boolean or null", profile="sillytavern")
    if "delay_until_recursion" in fields and fields["delay_until_recursion"] is not None and not isinstance(fields["delay_until_recursion"], (bool, int, float)):
        report.error("runtime-envelope-type", f"{path}/fields/delay_until_recursion", "delayed recursion must be boolean, numeric level, or null", profile="sillytavern")
    for key in ("depth", "scan_depth", "display_index"):
        if key in fields and fields[key] is not None and not is_number(fields[key]):
            report.error("runtime-envelope-type", f"{path}/fields/{key}", f"{key} must be numeric or null", profile="sillytavern")
    if "role" in fields and fields["role"] is not None and not isinstance(fields["role"], (int, str)):
        report.error("runtime-envelope-type", f"{path}/fields/role", "role must be integer, string, or null", profile="sillytavern")
    if "position" in fields and not isinstance(fields["position"], (int, str)):
        report.error("runtime-envelope-type", f"{path}/fields/position", "position must be integer or string", profile="sillytavern")
    if "selective_logic" in fields and fields["selective_logic"] is not None and not isinstance(fields["selective_logic"], (int, str)):
        report.error("runtime-envelope-type", f"{path}/fields/selective_logic", "selective_logic must be integer, string, or null", profile="sillytavern")

def validate_optional_st_extensions(report: Report, ext: dict, path: str) -> None:
    # Optional SillyTavern fields are checked only when present. Both current
    # snake_case and historical/camelCase spellings are preserved, never
    # auto-mirrored as though they were CCv3 requirements.
    bool_keys = {
        "vectorized", "prevent_recursion", "exclude_recursion",
        "case_sensitive", "caseSensitive", "match_whole_words", "matchWholeWords",
        "use_probability", "useProbability", "group_override", "groupOverride",
        "use_group_scoring", "useGroupScoring", "ignore_budget", "ignoreBudget",
    }
    numeric_keys = {
        "depth", "probability", "sticky", "cooldown", "delay", "group_weight",
        "groupWeight", "scan_depth", "scanDepth", "position", "role", "priority",
    }
    for key in bool_keys:
        if key in ext and not isinstance(ext[key], bool):
            report.warning("extension-type", f"{path}/{key}", "SillyTavern extension value is normally boolean")
    for key in numeric_keys:
        if key in ext and ext[key] is not None and not is_number(ext[key]):
            report.warning("extension-type", f"{path}/{key}", "SillyTavern extension value is normally numeric or null")
    for key in ("delay_until_recursion", "delayUntilRecursion"):
        if key in ext and ext[key] is not None and not isinstance(ext[key], (bool, int, float)):
            report.warning("extension-type", f"{path}/{key}", "delayed recursion is false/null or a numeric recursion level")
    if "groupWeight" in ext and "group_weight" in ext and ext["groupWeight"] != ext["group_weight"]:
        report.warning("extension-mirror-drift", path, "groupWeight and group_weight disagree; preserve one target-version mapping")
    if "caseSensitive" in ext and "case_sensitive" in ext and ext["caseSensitive"] != ext["case_sensitive"]:
        report.warning("extension-mirror-drift", path, "caseSensitive and case_sensitive disagree")
    if "worldbuilder_dynamic" in ext:
        validate_worldbuilder_dynamic(report, ext["worldbuilder_dynamic"], f"{path}/worldbuilder_dynamic")
    if "worldbuilder_runtime" in ext:
        validate_worldbuilder_runtime(report, ext["worldbuilder_runtime"], f"{path}/worldbuilder_runtime")


def validate_st_world_info(report: Report, data: dict) -> None:
    entries = data.get("entries")
    if not isinstance(entries, (list, dict)):
        report.error("wrong-type", "/entries", "SillyTavern World Info entries must be an array or object")
        return
    for key, expected in {
        "scan_depth": (int, float),
        "token_budget": (int, float),
        "recursive_scanning": bool,
        "extensions": dict,
    }.items():
        require_type(report, data, key, expected, "", required=False)
    for ref in iter_entries(data):
        entry = ref.entry
        path = ref.path
        require_type(report, entry, "content", str, path)
        for key, expected in ST_NATIVE_TYPES.items():
            if key in ST_NATIVE_NULLABLE and entry.get(key) is None:
                continue
            require_type(report, entry, key, expected, path, required=False)
        if "key" in entry:
            validate_string_array(report, entry["key"], f"{path}/key")
        if "keysecondary" in entry:
            validate_string_array(report, entry["keysecondary"], f"{path}/keysecondary")
        if "probability" in entry and is_number(entry["probability"]):
            if not 0 <= float(entry["probability"]) <= 100:
                report.warning("probability-range", f"{path}/probability", "SillyTavern probability is normally 0-100")
        if "groupWeight" in entry and is_number(entry["groupWeight"]) and float(entry["groupWeight"]) < 0:
            report.warning("group-weight", f"{path}/groupWeight", "group weights should not be negative")
        if isinstance(entry.get("extensions"), dict):
            validate_optional_st_extensions(report, entry["extensions"], f"{path}/extensions")
        validate_activation(report, entry, path, ccv3=False)


def validate_activation(report: Report, entry: dict, path: str, ccv3: bool) -> None:
    enabled = entry.get("enabled", not entry.get("disable", False)) if ccv3 else not entry.get("disable", False)
    if not enabled:
        return
    keys = entry.get("keys") if ccv3 else entry.get("key")
    constant = bool(entry.get("constant", False))
    ext = entry.get("extensions") if isinstance(entry.get("extensions"), dict) else {}
    vectorized = bool(entry.get("vectorized", ext.get("vectorized", False)))
    if not constant and not vectorized and not (isinstance(keys, list) and any(isinstance(k, str) and k.strip() for k in keys)):
        report.warning("no-activation-path", path, "enabled entry has no constant, keyword, or vector activation path")


def validate_identities(report: Report, data: dict) -> None:
    seen: dict[Any, str] = {}
    for ref in iter_entries(data):
        try:
            identity = canonical_entry_identity(ref.entry)
        except WorldBuilderError as exc:
            report.error("identity-mirror-drift", ref.path, str(exc), profile="sillytavern")
            continue
        if identity is None:
            continue
        if identity in seen:
            report.error("duplicate-identity", ref.path, f"identity {identity!r} also appears at {seen[identity]}", profile="sillytavern")
        else:
            seen[identity] = ref.path


def keyword_values(entry: dict) -> list[str]:
    values = entry.get("keys", entry.get("key", []))
    return [value.strip().casefold() for value in values if isinstance(value, str) and value.strip()] if isinstance(values, list) else []


def validate_keyword_collisions(report: Report, data: dict) -> None:
    owners: defaultdict[str, list[str]] = defaultdict(list)
    for ref in iter_entries(data):
        for keyword in keyword_values(ref.entry):
            owners[keyword].append(ref.path)
    for keyword, paths in owners.items():
        if len(paths) > 1:
            report.warning("keyword-collision", ", ".join(paths), f"primary keyword {keyword!r} is shared by {len(paths)} entries")


def manifest_entries(manifest: Any) -> list[tuple[Any, str, dict]]:
    refs = list(iter_entries(manifest))
    result = []
    for ref in refs:
        identity = canonical_entry_identity(ref.entry)
        result.append((identity, ref.path, ref.entry))
    return result


def flatten_expected(entry: dict) -> dict[str, Any]:
    # A manifest may keep output fields under emit/settings or directly on the
    # entry. Only compare declared fields; metadata such as notes/status is ignored.
    expected: dict[str, Any] = {}
    for container_key in ("emit", "settings"):
        value = entry.get(container_key)
        if isinstance(value, dict):
            expected.update(value)
    allowed = {
        "keys", "key", "secondary_keys", "keysecondary", "content", "enabled", "disable",
        "insertion_order", "order", "position", "case_sensitive", "caseSensitive", "use_regex",
        "constant", "selective", "selectiveLogic", "vectorized", "probability", "useProbability",
        "depth", "group", "groupOverride", "groupWeight", "preventRecursion", "excludeRecursion",
        "delayUntilRecursion", "sticky", "cooldown", "delay", "extensions", "comment", "name",
    }
    for key in allowed:
        if key in entry:
            expected[key] = entry[key]
    return expected


def value_at(entry: dict, dotted: str) -> tuple[bool, Any]:
    current: Any = entry
    for part in dotted.split("."):
        if not isinstance(current, dict) or part not in current:
            return False, None
        current = current[part]
    return True, current


def manifest_value_matches_with_naming(key: str, expected: Any, actual: Any, output_entry: dict) -> bool:
    """Allow the parent-owned entry-naming layer to transform visible labels.

    The manifest keeps the canonical subject name. The final artifact may carry a
    semantic editor label such as ``RULE: World Core``. The naming extension
    proves that transformation and preserves the prior label. It is also an
    output-only extension, so it must not cause an otherwise exact manifest
    extension comparison to fail.
    """
    extensions = output_entry.get("extensions")
    naming = extensions.get("worldbuilder_entry_naming") if isinstance(extensions, dict) else None
    if not isinstance(naming, dict) or naming.get("contract") != "worldbuilder-entry-naming-v1":
        return False

    if key in {"name", "comment"}:
        visible = naming.get("visible_label")
        previous = naming.get("previous_labels", [])
        return (
            isinstance(visible, str)
            and actual == visible
            and (expected == actual or (isinstance(previous, list) and expected in previous))
        )

    if key == "extensions" and isinstance(expected, dict) and isinstance(actual, dict):
        reduced = {name: value for name, value in actual.items() if name != "worldbuilder_entry_naming"}
        return reduced == expected

    return False


def _manifest_entry_is_schema1_card_star(data: dict, entry: dict) -> bool:
    """Return True when a manifest row is represented by card-level fields.

    Schema 1 card stars intentionally do not emit a lorebook entry carrying the
    manifest UID. Their identity/content binding is enforced by
    ``architecture_gate.py`` against the card's top-level fields and the frozen
    character plan. Treating them like lorebook rows here makes every valid
    Schema 1 guided build fail delivery with ``manifest-entry-missing``.
    """
    info = detect_artifact(data)
    if info.kind != "card_v3" or info.schema != 1:
        return False
    arch = entry.get("architecture")
    return (
        isinstance(arch, dict)
        and arch.get("layer") == "character"
        and arch.get("character_role") == "card_star"
    )


def validate_manifest(report: Report, data: dict, manifest: Any) -> None:
    output_index: dict[Any, tuple[str, dict]] = {}
    for ref in iter_entries(data):
        try:
            identity = canonical_entry_identity(ref.entry)
        except WorldBuilderError:
            continue
        if identity is not None:
            output_index[identity] = (ref.path, ref.entry)

    seen_manifest: set[Any] = set()
    for identity, mpath, mentry in manifest_entries(manifest):
        if identity is None:
            report.warning("manifest-no-identity", mpath, "manifest entry has no stable identity")
            continue
        if identity in seen_manifest:
            report.error("manifest-duplicate-identity", mpath, f"duplicate manifest identity {identity!r}", context={"uid": identity})
            continue
        seen_manifest.add(identity)
        if identity not in output_index:
            if _manifest_entry_is_schema1_card_star(data, mentry):
                # The card star is represented by Schema 1 card-level fields,
                # not a lorebook entry. architecture_gate validates its
                # character identity and content against the frozen plan.
                continue
            report.error("manifest-entry-missing", mpath, f"identity {identity!r} is absent from output", context={"uid": identity})
            continue
        opath, output_entry = output_index[identity]
        for key, expected in flatten_expected(mentry).items():
            exists, actual = value_at(output_entry, key)
            if not exists and isinstance(output_entry.get("extensions"), dict) and key in output_entry["extensions"]:
                exists, actual = True, output_entry["extensions"][key]
            if not exists:
                report.error("manifest-field-missing", opath, f"manifest declares {key!r}, but output omits it", context={"uid": identity, "field": key, "delivered": None, "planned": expected})
            elif actual != expected and not manifest_value_matches_with_naming(key, expected, actual, output_entry):
                report.error("manifest-mismatch", opath, f"{key!r} is {actual!r}; manifest requires {expected!r}", context={"uid": identity, "field": key, "delivered": actual, "planned": expected})


def worldbuilder_style(report: Report, data: dict, info: ArtifactInfo) -> None:
    if info.kind.startswith("card_v3"):
        payload = data.get("data", {})
        tags = payload.get("tags")
        if isinstance(tags, list) and len(tags) < 3:
            report.warning("wb-tags", "/data/tags", "WorldBuilder style usually adds at least three useful tags", profile="worldbuilder")
        if isinstance(tags, list) and not any(isinstance(tag, str) and tag.casefold() in {"sfw", "nsfw", "nsfl"} for tag in tags):
            report.warning("wb-rating-tag", "/data/tags", "optional WorldBuilder profile has no explicit content-rating tag", profile="worldbuilder")
        creator_notes = payload.get("creator_notes", "")
        system_prompt = payload.get("system_prompt", "")
        if isinstance(creator_notes, str) and creator_notes.strip() and not str(system_prompt).strip():
            report.warning(
                "wb-creator-notes-steering",
                "/data/creator_notes",
                "creator_notes are primarily human-facing; put required model behavior in an enabled prompt field or lorebook entry",
                profile="worldbuilder",
            )
        mes_example = payload.get("mes_example")
        if isinstance(mes_example, str) and mes_example.strip() and "<START>" not in mes_example:
            report.warning("wb-example-delimiter", "/data/mes_example", "WorldBuilder examples normally separate dialogue blocks with <START>", profile="worldbuilder")

    for ref in iter_entries(data):
        entry = ref.entry
        comment = entry.get("comment")
        name = entry.get("name")
        if isinstance(comment, str) and isinstance(name, str) and comment and name and comment != name:
            report.warning("wb-name-comment", ref.path, "name and comment differ; this is valid but may reduce editor consistency", profile="worldbuilder")


def validate_content_provenance(report: Report, data: dict[str, Any]) -> None:
    for ref in iter_entries(data):
        matches = content_provenance_matches(ref.entry.get("content"))
        if matches:
            report.warning(
                "source-provenance-content",
                f"{ref.path}/content",
                "entry content contains source/provenance text that belongs in evidence or metadata: " + ", ".join(repr(m) for m in matches),
                profile="worldbuilder",
                context={"matches": matches, "uid": canonical_entry_identity(ref.entry)},
            )


def validate(data: Any, profile: str = "sillytavern", manifest: Any | None = None) -> tuple[Report, ArtifactInfo]:
    report = Report(profile)
    info = detect_artifact(data)
    if not isinstance(data, dict):
        report.error("root-type", "", "root JSON value must be an object")
        return report, info
    if info.kind == "card_v2":
        report.error("ccv2-not-v3", "/spec", "chara_card_v2 is not Character Card V3; convert explicitly before V3 validation")
        return report, info
    if info.kind in {"card_v3", "card_v3_embedded"}:
        validate_card(report, data, info)
    elif info.kind == "lorebook_v3":
        if data.get("spec") != "lorebook_v3":
            report.error("wrong-spec", "/spec", "standalone CCv3 lorebook requires spec='lorebook_v3'")
        payload = data.get("data")
        if not isinstance(payload, dict):
            report.error("wrong-type", "/data", "lorebook_v3 data must be an object")
        else:
            validate_ccv3_lorebook(report, payload, "/data")
    elif info.kind == "sillytavern_world_info":
        if profile == "spec":
            report.error("native-not-ccv3", "", "top-level SillyTavern World Info is not the CCv3 lorebook_v3 wrapper")
        else:
            validate_st_world_info(report, data)
    else:
        report.error("unknown-format", "", "unrecognized card or lorebook JSON shape")
        return report, info

    validate_identities(report, data)
    if profile in {"sillytavern", "worldbuilder"}:
        validate_keyword_collisions(report, data)
        validate_content_provenance(report, data)
    if manifest is not None:
        validate_manifest(report, data, manifest)
    if profile == "worldbuilder":
        worldbuilder_style(report, data, info)
    return report, info


def print_report(report: Report, info: ArtifactInfo) -> None:
    print(f"Artifact: {info.kind}; schema={info.schema}; profile={report.profile}")
    for issue in report.issues:
        print(f"[{issue.severity.upper()}][{issue.profile}][{issue.code}] {issue.path or '/'}: {issue.message}")
    print(f"Summary: {len(report.errors)} error(s), {len(report.warnings)} warning(s)")


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate Character Card V3 and SillyTavern lorebook JSON.")
    parser.add_argument("path", nargs="?", help="JSON artifact path (legacy positional form).")
    parser.add_argument("--path", dest="path_flag", help="JSON artifact path; flag form aligned with sibling gates.")
    parser.add_argument("--manifest")
    parser.add_argument("--profile", choices=["spec", "sillytavern", "worldbuilder"], default="sillytavern")
    parser.add_argument("--strict-warnings", action="store_true")
    parser.add_argument("--allow-input-bom", action="store_true", help="accept a legacy BOM-bearing input for inspection/repair only")
    parser.add_argument("--json-report")
    args = parser.parse_args()
    if args.path and args.path_flag and Path(args.path).resolve() != Path(args.path_flag).resolve():
        parser.error("positional path and --path refer to different files")
    artifact_path = args.path_flag or args.path
    if not artifact_path:
        parser.error("provide the artifact path positionally or with --path")

    try:
        data = load_json(artifact_path) if args.allow_input_bom else load_json_strict(artifact_path)
        manifest = load_json(args.manifest) if args.manifest else None
    except (OSError, json.JSONDecodeError, WorldBuilderError) as exc:
        print(f"ERROR: cannot read JSON: {exc}", file=sys.stderr)
        return 2
    try:
        report, info = validate(data, args.profile, manifest)
    except WorldBuilderError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    print_report(report, info)
    if args.json_report:
        payload = {
            "artifact": asdict(info),
            "profile": args.profile,
            "errors": len(report.errors),
            "warnings": len(report.warnings),
            "issues": [asdict(issue) for issue in report.issues],
        }
        Path(args.json_report).write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return 1 if report.errors or (args.strict_warnings and report.warnings) else 0


if __name__ == "__main__":
    raise SystemExit(main())
