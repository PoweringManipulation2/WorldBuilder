#!/usr/bin/env python3
"""Ordered, content-bound WorldBuilder pipeline stage gates.

Each successful workflow transition writes one immutable receipt under
``artifacts/pipeline-stage-receipts``. Receipts form a SHA-256 chain and bind the
actual files or structured gate receipts that prove the stage completed. Later
stages cannot be recorded while an earlier applicable stage is missing, stale,
or reordered.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
from pathlib import Path
from typing import Any

from entry_naming import validate_artifact_labels
from wb_common import (
    WorldBuilderError,
    atomic_write_json,
    discover_phase_files,
    load_build_state,
    load_json,
    step_driver_pointer,
    now_iso,
    resolve_state_path,
    sha256_file,
)

CONTRACT = "worldbuilder-pipeline-stage-gates-v1"
RECEIPT_KIND = "worldbuilder-pipeline-stage-receipt"
RECEIPT_VERSION = 1
LEDGER_KIND = "worldbuilder-pipeline-stage-ledger"
LEDGER_VERSION = 2

STAGES: tuple[str, ...] = (
    "workspace_initialized",
    "research_discovery",
    "planning_validated",
    "pre_generation_audit",
    "generation_ready",
    "generation_dispatched",
    "generation_complete",
    "merge_complete",
    "context_budget_review",
    "entry_names_normalized",
    "post_generation_audit",
    "output_contracts",
    "runtime_adapter",
    "integration_output",
    "delivery_permitted",
)

# Authoritative stage -> recording command map. Gate errors and --next print
# these so a blocked run is always told the exact next command instead of a
# bare ledger stage name. ``{py}`` is the interpreter, ``{sd}`` the scripts
# directory, ``{bs}`` the build-state path.
STAGE_COMMANDS: dict[str, tuple[str, str]] = {
    "workspace_initialized": (
        "{py} {sd}/init_build.py ... (workspace bootstrap; normally already recorded)",
        "SKILL.md § Build workspace contract; references/pipeline-stage-gates.md",
    ),
    "research_discovery": (
        "{py} {sd}/discovery_gate.py --build-state {bs}",
        "references/parallel-research-pipeline.md",
    ),
    "planning_validated": (
        "{py} {sd}/planning_gate.py --build-state {bs}",
        "references/pre-gen-workflow.md",
    ),
    "pre_generation_audit": (
        "{py} {sd}/audit_gate.py --build-state {bs} --stage pre-generation  (plan the four auditors first with: {py} {sd}/audit_plan.py --build-state {bs} --stage pre-generation)",
        "references/parallel-audit-pipeline.md",
    ),
    "generation_ready": (
        "{py} {sd}/phase_gate.py --build-state {bs} --stage pre-generation",
        "references/pre-gen-workflow.md",
    ),
    "generation_dispatched": (
        "{py} {sd}/phase_gate.py --build-state {bs} --stage pre-dispatch",
        "references/parallel-batch-pipeline.md",
    ),
    "generation_complete": (
        "{py} {sd}/phase_gate.py --build-state {bs} --stage pre-merge",
        "references/batch-pipeline.md",
    ),
    "merge_complete": (
        "{py} {sd}/merge_phases.py --build-state {bs}",
        "references/batch-pipeline.md",
    ),
    "context_budget_review": (
        "{py} {sd}/context_budget_review.py --build-state {bs} report  (then record --decision keep, or prune externally with prune_workflow.py and record --decision prune --target-tokens N)",
        "references/context-budget-pruning.md",
    ),
    "entry_names_normalized": (
        "{py} {sd}/entry_naming.py --build-state {bs} --stage normalize-output  (merge_phases.py records this automatically after merge)",
        "references/entry-naming.md",
    ),
    "post_generation_audit": (
        "{py} {sd}/audit_gate.py --build-state {bs} --stage post-generation  (plan the four auditors first with: {py} {sd}/audit_plan.py --build-state {bs} --stage post-generation)",
        "references/post-gen-audit.md",
    ),
    "output_contracts": (
        "{py} {sd}/delivery_gate.py --build-state {bs}  (run {py} {sd}/runtime_target_adapter.py export/validate and {py} {sd}/integration_acceptance.py validate --build-state {bs} --stage output first; delivery_gate records output_contracts, runtime_adapter, and integration_output together)",
        "references/full-integration-acceptance.md",
    ),
    "runtime_adapter": (
        "{py} {sd}/delivery_gate.py --build-state {bs}  (records output_contracts, runtime_adapter, and integration_output together)",
        "references/sillytavern-import-contract.md",
    ),
    "integration_output": (
        "{py} {sd}/delivery_gate.py --build-state {bs}  (records output_contracts, runtime_adapter, and integration_output together)",
        "references/full-integration-acceptance.md",
    ),
    "delivery_permitted": (
        "{py} {sd}/delivery_gate.py --build-state {bs} --seal",
        "SKILL.md § validate integrated output, seal, and release",
    ),
}


def _command_for(stage: str, build_state: str | Path | None = None) -> tuple[str, str]:
    template, reading = STAGE_COMMANDS[stage]
    interpreter = sys.executable or "python"
    script_dir = str(Path(__file__).resolve().parent)
    bs = str(Path(build_state).resolve()) if build_state else "<build-state.json>"
    return template.format(py=interpreter, sd=script_dir, bs=bs), reading


def stage_hint(stage: str, build_state: str | Path | None = None) -> str:
    command, reading = _command_for(stage, build_state)
    return f"Record it with: {command} | Re-read first: {reading}"


def canonical_hash(value: Any) -> str:
    payload = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def relative(path: Path, root: Path) -> str:
    return str(path.resolve().relative_to(root.resolve())).replace("\\", "/")


def stage_index(stage: str) -> int:
    try:
        return STAGES.index(stage)
    except ValueError as exc:
        raise WorldBuilderError(f"unknown pipeline stage {stage!r}; valid stages are {list(STAGES)}") from exc



def runtime_adapter_required(state: dict[str, Any]) -> bool:
    settings = state.get("settings") if isinstance(state.get("settings"), dict) else {}
    runtime_format = str(settings.get("runtime_format", "preserve"))
    runtime_target = str(settings.get("runtime_target", "portable"))
    return runtime_format != "preserve" or runtime_target == "sillytavern-1.18.0"

def route_fingerprint(state: dict[str, Any]) -> dict[str, Any]:
    artifact = state.get("artifact") if isinstance(state.get("artifact"), dict) else {}
    source = state.get("source") if isinstance(state.get("source"), dict) else {}
    pipeline = state.get("pipeline") if isinstance(state.get("pipeline"), dict) else {}
    audit = state.get("audit") if isinstance(state.get("audit"), dict) else {}
    integration = state.get("integration") if isinstance(state.get("integration"), dict) else {}
    dynamic = state.get("dynamic_state") if isinstance(state.get("dynamic_state"), dict) else {}
    return {
        "artifact_type": artifact.get("type"),
        "schema": artifact.get("schema"),
        "source_kind": source.get("kind"),
        "pipeline_mode": pipeline.get("mode"),
        "requires_phase_gates": bool(pipeline.get("requires_phase_gates")),
        "custom_pipeline": bool((state.get("custom_pipeline") or {}).get("active")),
        "context_window_mode": (state.get("budget") or {}).get("context_window_mode"),
        "pre_generation_audit_required": bool(audit.get("pre_generation_required")),
        "post_generation_audit_required": bool(audit.get("post_generation_required")),
        "dynamic_state_applicable": bool(dynamic.get("applicable")),
        "runtime_adapter_required": runtime_adapter_required(state),
        "integration_contract": integration.get("contract"),
        "integration_plan_sha256": integration.get("plan_sha256"),
    }


def stage_applicable(stage: str, state: dict[str, Any]) -> tuple[bool, str]:
    if stage == "research_discovery":
        required = bool(state.get("discovery", {}).get("required"))
        return required, "known-property breadth discovery required" if required else "source does not require breadth discovery"
    if stage == "pre_generation_audit":
        required = bool(state.get("audit", {}).get("pre_generation_required"))
        return required, "four pre-generation auditors required" if required else "pre-generation audit not required for this route"
    if stage == "generation_ready":
        custom = bool((state.get("custom_pipeline") or {}).get("active"))
        required = (not custom) and (bool(state.get("pipeline", {}).get("requires_phase_gates")) or str(state.get("status", {}).get("pre_generation", "not_required")) != "not_required")
        return required, "pre-generation phase gate required" if required else ("custom pipeline uses conversational/freeform generation after the ordinary pre-generation audit" if custom else "route does not use generation phase gates")
    if stage == "generation_dispatched":
        custom = bool((state.get("custom_pipeline") or {}).get("active"))
        parallel = (not custom) and str(state.get("pipeline", {}).get("mode", "sequential")) == "parallel"
        return parallel, "parallel generation requires dispatch proof" if parallel else ("custom freeform generation has no child dispatch stage" if custom else "sequential generation has no child dispatch stage")
    if stage == "generation_complete":
        custom = bool((state.get("custom_pipeline") or {}).get("active"))
        required = bool(state.get("pipeline", {}).get("requires_phase_gates")) and not custom
        return required, "phase-gated generation completion required" if required else ("custom freeform generation is proven by merge_complete/custom generation receipt" if custom else "route does not use phase generation gates")
    if stage == "merge_complete":
        custom = bool((state.get("custom_pipeline") or {}).get("active"))
        required = bool(state.get("pipeline", {}).get("requires_phase_gates")) or custom
        return required, "merged output required" if required else "route does not use phase merge"
    if stage == "context_budget_review":
        required = bool((state.get("budget") or {}).get("auto_review_required"))
        return required, "auto context-window mode requires measured post-merge review" if required else "fixed/legacy budget has no post-merge auto review"
    if stage == "entry_names_normalized":
        artifact = state.get("artifact") if isinstance(state.get("artifact"), dict) else {}
        required = artifact.get("type") in {"world", "lorebook", "group"} or artifact.get("schema") in {2, 3}
        return required, "lorebook-bearing output requires semantic entry labels" if required else "route has no lorebook entry labels"
    if stage == "post_generation_audit":
        required = bool(state.get("audit", {}).get("post_generation_required"))
        return required, "four post-generation auditors required" if required else "post-generation audit not required for this route"
    if stage == "runtime_adapter":
        required = runtime_adapter_required(state)
        return required, "named runtime target or explicit conversion requires adapter" if required else "portable preserve output does not require an adapter"
    return True, "required"


def receipt_dir(root: Path, state: dict[str, Any]) -> Path:
    path = resolve_state_path(root, state, "pipeline_stage_receipts", required=False)
    if path is None:
        path = root / "artifacts" / "pipeline-stage-receipts"
    path.mkdir(parents=True, exist_ok=True)
    return path


def ledger_path(root: Path, state: dict[str, Any]) -> Path:
    path = resolve_state_path(root, state, "pipeline_stage_ledger", required=False)
    return path if path is not None else root / "artifacts" / "pipeline-stage-ledger.json"


def stage_receipt_path(root: Path, state: dict[str, Any], stage: str) -> Path:
    return receipt_dir(root, state) / f"{stage_index(stage) + 1:02d}-{stage}.json"


def add_file(files: dict[str, dict[str, str]], root: Path, state: dict[str, Any], key: str, *, required: bool = True) -> Path | None:
    path = resolve_state_path(root, state, key, required=False)
    if path is None:
        fallback = {
            "entry_naming_planning_receipt": "artifacts/entry-naming-planning-gate.json",
            "entry_naming_output_receipt": "artifacts/entry-naming-output-gate.json",
        }.get(key)
        path = (root / fallback).resolve() if fallback else None
    if path is None or not path.exists():
        if required:
            raise WorldBuilderError(f"pipeline stage requires evidence for {key!r}, but no path is configured for it in paths.* or its configured/fallback file does not exist; produce it before advancing this stage")
        return None
    if not path.is_file():
        raise WorldBuilderError(f"pipeline stage evidence {key} is not a file: {path}")
    files[key] = {"path": relative(path, root), "sha256": sha256_file(path)}
    return path


def file_inventory(path: Path, root: Path, *, suffix: str | None = None) -> list[dict[str, str]]:
    if not path.exists() or not path.is_dir():
        return []
    rows: list[dict[str, str]] = []
    for item in sorted(path.rglob("*")):
        if not item.is_file() or (suffix and item.suffix.lower() != suffix.lower()):
            continue
        rows.append({"path": relative(item, root), "sha256": sha256_file(item)})
    return rows


def read_pipeline_receipts(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        raise WorldBuilderError(f"pipeline receipt ledger does not exist at {path}; no phase-level receipt has been recorded for this build yet")
    rows: list[dict[str, Any]] = []
    for line_no, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        try:
            value = json.loads(line)
        except json.JSONDecodeError as exc:
            raise WorldBuilderError(f"{path.name} line {line_no} is invalid JSON: {exc}. Content: {line[:200]!r}") from exc
        if not isinstance(value, dict):
            raise WorldBuilderError(f"{path.name} line {line_no} must be a JSON object, found {type(value).__name__}: {line[:200]!r}")
        rows.append(value)
    return rows


def latest_pipeline_receipt(root: Path, state: dict[str, Any], stage: str) -> dict[str, Any]:
    path = resolve_state_path(root, state, "receipts")
    build_id = state.get("build_id")
    rows = [row for row in read_pipeline_receipts(path) if row.get("stage") == stage and row.get("build_id") == build_id]
    if not rows:
        raise WorldBuilderError(f"no pipeline receipt for stage {stage!r} with this build_id was found in the receipt ledger; the phase this stage represents has not recorded a receipt yet")
    return max(rows, key=lambda row: int(row.get("created_at_unix", 0)))


def target_path(root: Path, state: dict[str, Any], target: str | Path | None) -> Path:
    path = Path(target).resolve() if target else resolve_state_path(root, state, "final_output")
    if not path.exists() or not path.is_file():
        raise WorldBuilderError(f"pipeline output target does not exist at {path} (explicit --target argument, or paths.final_output if none was given); produce it before this stage can validate it")
    return path


def validate_named_receipt(path: Path, *, kinds: set[str] | None = None, statuses: set[str] | None = None) -> dict[str, Any]:
    value = load_json(path)
    if not isinstance(value, dict):
        raise WorldBuilderError(f"{path} must contain a JSON object, found {type(value).__name__}")
    if kinds and value.get("kind") not in kinds:
        raise WorldBuilderError(f"{path.name}'s kind is {value.get('kind')!r}, expected one of {sorted(kinds)}")
    if statuses and value.get("status") not in statuses:
        raise WorldBuilderError(f"{path.name}'s status is {value.get('status')!r}, expected one of {sorted(statuses)}; re-run whatever produces this receipt until it reports a passing status")
    return value


def entry_naming_output_target(
    root: Path,
    state: dict[str, Any],
    receipt: dict[str, Any],
    target: str | Path | None = None,
) -> Path:
    """The artifact entry-naming normalized, resolved identically at record and verify time.

    An explicit --target wins. Otherwise the entry-naming receipt's own recorded
    target wins, because that receipt binds the file entry_naming actually wrote.
    Falling back to the merge input here made verify-time compare the receipt
    against a file entry-naming never touched, so a correct build could never
    re-verify its entry_names_normalized stage.
    """
    if target:
        return Path(target).resolve()
    recorded = receipt.get("target")
    if isinstance(recorded, str) and recorded:
        candidate = Path(recorded)
        return candidate if candidate.is_absolute() else root / candidate
    return resolve_state_path(root, state, "merge_input")


def collect_evidence(
    root: Path,
    state: dict[str, Any],
    stage: str,
    target: str | Path | None = None,
) -> tuple[dict[str, dict[str, str]], dict[str, Any]]:
    applicable, reason = stage_applicable(stage, state)
    files: dict[str, dict[str, str]] = {}
    values: dict[str, Any] = {
        "route_fingerprint": route_fingerprint(state),
        "applicable": applicable,
        "reason": reason,
    }
    if not applicable:
        return files, values

    status = state.get("status") if isinstance(state.get("status"), dict) else {}
    systems = set(state.get("integration", {}).get("required_systems", []))

    if stage == "workspace_initialized":
        for key in (
            "effective_config", "field_registry", "default_profile", "card_shell_plan",
            "placement_plan", "budget_plan", "dynamic_state_plan", "pipeline_registry", "integration_plan",
        ):
            add_file(files, root, state, key)
    elif stage == "research_discovery":
        path = add_file(files, root, state, "discovery_receipt")
        assert path is not None
        receipt = validate_named_receipt(path, kinds={"breadth-discovery-gate"}, statuses={"complete", "passed_with_exclusions"})
        if receipt.get("bounded_coverage_proven", receipt.get("completeness_proven")) is not True:
            raise WorldBuilderError("discovery stage does not prove bounded source-set coverage")
        values["discovery_status"] = receipt.get("status")
        values["assignment_count"] = receipt.get("assignment_count")
        values["unique_child_session_count"] = receipt.get("unique_child_session_count")
    elif stage == "planning_validated":
        if status.get("planning") != "complete":
            raise WorldBuilderError("planning status is not complete")
        for key in (
            "planning_receipt", "manifest", "build_id", "build_list", "recursion_map", "identity_receipt", "entry_naming_planning_receipt",
            "architecture_planning_receipt", "activation_map_receipt", "placement_planning_receipt",
            "budget_planning_receipt", "dynamic_state_planning_receipt", "integration_planning_receipt",
        ):
            add_file(files, root, state, key)
        add_file(files, root, state, "era_router_receipt", required=False)
    elif stage == "pre_generation_audit":
        if status.get("pre_generation") != "complete":
            raise WorldBuilderError("pre-generation audit status is not complete")
        add_file(files, root, state, "pre_generation_audit_plan")
        path = add_file(files, root, state, "pre_generation_audit_receipt")
        assert path is not None
        receipt = validate_named_receipt(path, kinds={"worldbuilder-audit-gate"})
        if receipt.get("all_runtime_statuses_completed") is not True or receipt.get("all_lenses_validated") is not True:
            raise WorldBuilderError(f"{path.name} does not prove all four pre-generation auditor workers completed (all_runtime_statuses_completed={receipt.get('all_runtime_statuses_completed')!r}, all_lenses_validated={receipt.get('all_lenses_validated')!r}); re-run audit_gate.py for this stage")
        if len(receipt.get("auditors", [])) != 4:
            raise WorldBuilderError(f"{path.name} has {len(receipt.get('auditors', []))} auditors recorded, not the required 4; re-run audit_gate.py once all four lenses have completed")
    elif stage == "generation_ready":
        if status.get("pre_generation") != "complete":
            raise WorldBuilderError("this build's pre-generation phase gate has not completed; run: phase_gate.py --stage pre-generation --build-state <this build-state.json>")
        receipt = latest_pipeline_receipt(root, state, "pre-generation")
        values["phase_receipt"] = receipt
        values["phase_receipt_sha256"] = canonical_hash(receipt)
    elif stage == "generation_dispatched":
        if status.get("pre_dispatch") != "complete":
            raise WorldBuilderError("pre-dispatch gate has not completed; run: phase_gate.py --stage pre-dispatch --build-state <this build-state.json>")
        dispatch_count = state.get("pipeline", {}).get("dispatch_count")
        if not isinstance(dispatch_count, int) or dispatch_count <= 0:
            raise WorldBuilderError("state.pipeline.dispatch_count is missing or not a positive integer; pre-dispatch should have recorded how many workers were dispatched")
        receipt = latest_pipeline_receipt(root, state, "pre-dispatch")
        values["phase_receipt"] = receipt
        values["phase_receipt_sha256"] = canonical_hash(receipt)
        assignments = resolve_state_path(root, state, "assignments")
        inventory = file_inventory(assignments, root, suffix=".json")
        if not inventory:
            raise WorldBuilderError(f"no .json assignment files were found under {assignments}; dispatch should have written one assignment file per worker there")
        values["assignment_inventory"] = inventory
        values["dispatch_count"] = dispatch_count
    elif stage == "generation_complete":
        if status.get("pre_merge") != "complete":
            raise WorldBuilderError("this build's pre-merge phase gate has not completed; run: phase_gate.py --stage pre-merge --build-state <this build-state.json>")
        receipt = latest_pipeline_receipt(root, state, "pre-merge")
        values["phase_receipt"] = receipt
        values["phase_receipt_sha256"] = canonical_hash(receipt)
        phases = resolve_state_path(root, state, "phases")
        inventory = [{"path": relative(path, root), "sha256": sha256_file(path)} for path in discover_phase_files(phases)]
        if not inventory:
            raise WorldBuilderError(f"no phase output files were found under {phases}; generation should have written at least one phase file there before this stage can advance")
        values["phase_inventory"] = inventory
        evidence = resolve_state_path(root, state, "evidence_receipts")
        values["evidence_receipt_inventory"] = file_inventory(evidence, root, suffix=".json")
    elif stage == "merge_complete":
        if status.get("merge") != "complete":
            raise WorldBuilderError("state.status.merge is not 'complete'; run the merge step and record its completion in build-state.json before advancing this stage")
        auto_review = bool((state.get("budget") or {}).get("auto_review_required"))
        evidence_key = "context_budget_before" if auto_review else "merge_input"
        merge = add_file(files, root, state, evidence_key)
        assert merge is not None
        lineage = state.get("lineage", {}).get("merge")
        if not isinstance(lineage, dict) or lineage.get("sha256") != sha256_file(merge):
            raise WorldBuilderError(f"state.lineage.merge.sha256 does not match the immutable merge evidence file's actual hash at {merge}; merge lineage is stale")
        values["phase_files"] = lineage.get("phase_files")
        values["evidence_mode"] = "immutable_pre_review_snapshot" if auto_review else "merge_input"
        if bool((state.get("custom_pipeline") or {}).get("active")):
            add_file(files, root, state, "custom_generation_receipt")
    elif stage == "context_budget_review":
        if status.get("context_budget_review") != "complete":
            raise WorldBuilderError("auto context-budget review is not complete; report measured stats, record keep/prune decision, then advance this stage")
        before = add_file(files, root, state, "context_budget_before")
        after = add_file(files, root, state, "context_budget_after")
        receipt_path = add_file(files, root, state, "context_budget_review_receipt")
        assert before is not None and after is not None and receipt_path is not None
        receipt = validate_named_receipt(receipt_path, kinds={"worldbuilder-context-budget-review"}, statuses={"passed"})
        if receipt.get("before_sha256") != sha256_file(before) or receipt.get("after_sha256") != sha256_file(after):
            raise WorldBuilderError("context-budget review receipt does not match its immutable before/after snapshots")
        values["decision"] = receipt.get("decision")
        values["target_tokens"] = receipt.get("target_tokens")
        values["before_tokens"] = receipt.get("before_tokens")
        values["after_tokens"] = receipt.get("after_tokens")
        if receipt.get("decision") == "prune":
            proof_ref = receipt.get("prune_proof")
            if not isinstance(proof_ref, dict) or not isinstance(proof_ref.get("path"), str) or not isinstance(proof_ref.get("sha256"), str):
                raise WorldBuilderError("pruned auto context-budget review is missing its bound prune_workflow proof")
            proof_path = (root / proof_ref["path"]).resolve()
            try:
                proof_path.relative_to(root)
            except ValueError as exc:
                raise WorldBuilderError("context-budget prune proof resolves outside the build workspace") from exc
            if not proof_path.is_file() or sha256_file(proof_path) != proof_ref["sha256"]:
                raise WorldBuilderError("context-budget prune proof is missing or changed after the review receipt was recorded")
            proof_value = validate_named_receipt(proof_path)
            if proof_value.get("contract") != "worldbuilder-prune-prove-v1" or int(proof_value.get("max_pressure_delta", 0)) >= 0:
                raise WorldBuilderError("context-budget prune proof no longer demonstrates a valid prune_workflow pressure reduction")
            files["prune_proof"] = {"path": relative(proof_path, root), "sha256": sha256_file(proof_path)}
    elif stage == "entry_names_normalized":
        if status.get("entry_naming") != "complete":
            raise WorldBuilderError("state.status.entry_naming is not 'complete'; run entry_naming.py's normalization step before advancing this stage")
        path = add_file(files, root, state, "entry_naming_output_receipt")
        assert path is not None
        receipt = validate_named_receipt(path, kinds={"worldbuilder-entry-naming-receipt"}, statuses={"passed"})
        output = entry_naming_output_target(root, state, receipt, target)
        if not output.exists() or not output.is_file():
            raise WorldBuilderError(f"entry-naming target does not exist at {output} (explicit --target, the entry-naming receipt's own recorded target, or paths.merge_input if neither is available)")
        files["target"] = {"path": relative(output, root), "sha256": sha256_file(output)}
        if receipt.get("after_sha256") != sha256_file(output):
            raise WorldBuilderError(f"{path.name}'s after_sha256 does not match the current target's actual hash; the target changed after entry-naming ran; re-run entry_naming.py's normalization against the current target")
        values["changed_entry_count"] = receipt.get("changed_entry_count", 0)
        values["entry_count"] = receipt.get("entry_count", 0)
    elif stage == "post_generation_audit":
        if status.get("post_generation_audit") not in {"complete", "sealed"}:
            raise WorldBuilderError("post-generation audit status is not complete")
        add_file(files, root, state, "post_generation_audit_plan")
        path = add_file(files, root, state, "post_generation_audit_receipt")
        assert path is not None
        receipt = validate_named_receipt(path, kinds={"worldbuilder-audit-gate"})
        if receipt.get("all_runtime_statuses_completed") is not True or receipt.get("all_lenses_validated") is not True:
            raise WorldBuilderError(f"{path.name} does not prove all four post-generation auditor workers completed (all_runtime_statuses_completed={receipt.get('all_runtime_statuses_completed')!r}, all_lenses_validated={receipt.get('all_lenses_validated')!r}); re-run audit_gate.py for this stage")
        if len(receipt.get("auditors", [])) != 4:
            raise WorldBuilderError(f"{path.name} has {len(receipt.get('auditors', []))} auditors recorded, not the required 4; re-run audit_gate.py once all four lenses have completed")
    elif stage == "output_contracts":
        output = target_path(root, state, target)
        files["target"] = {"path": relative(output, root), "sha256": sha256_file(output)}
        output_data = load_json(output)
        if isinstance(output_data, dict):
            naming_result = validate_artifact_labels(output_data)
            values["entry_naming_contract"] = naming_result.get("contract")
            values["entry_naming_entry_count"] = naming_result.get("entry_count")
        add_file(files, root, state, "entry_naming_output_receipt", required=False)
        if "card_shell" in systems or "character_architecture" in systems:
            add_file(files, root, state, "architecture_output_receipt")
        if "placement" in systems:
            add_file(files, root, state, "placement_output_receipt")
        if "budget" in systems:
            add_file(files, root, state, "budget_output_receipt")
        if bool(state.get("dynamic_state", {}).get("applicable")):
            add_file(files, root, state, "dynamic_state_output_receipt")
    elif stage == "runtime_adapter":
        if status.get("runtime_adapter") != "complete":
            raise WorldBuilderError("runtime adapter status is not complete")
        add_file(files, root, state, "runtime_adapter_receipt")
        add_file(files, root, state, "adapter_output")
        add_file(files, root, state, "compatibility_report")
    elif stage == "integration_output":
        output = target_path(root, state, target)
        files["target"] = {"path": relative(output, root), "sha256": sha256_file(output)}
        add_file(files, root, state, "integration_output_receipt")
        if status.get("integration_output") != "complete":
            raise WorldBuilderError("integration output status is not complete")
    elif stage == "delivery_permitted":
        output = target_path(root, state, target)
        files["target"] = {"path": relative(output, root), "sha256": sha256_file(output)}
        add_file(files, root, state, "integration_output_receipt")
        add_file(files, root, state, "audit_log", required=bool(state.get("audit", {}).get("post_generation_required")))
        values["final_sha256"] = sha256_file(output)
    else:
        raise WorldBuilderError(f"collect_evidence has no case for stage {stage!r}: this is an internal contract gap, not a build problem; every entry in STAGES needs a matching branch here")
    return files, values


def load_ledger(root: Path, state: dict[str, Any]) -> dict[str, Any]:
    path = ledger_path(root, state)
    if not path.exists():
        return {
            "kind": LEDGER_KIND,
            "ledger_version": LEDGER_VERSION,
            "contract": CONTRACT,
            "build_id": state.get("build_id"),
            "stages": [],
            "current_stage": None,
        }
    value = load_json(path)
    if not isinstance(value, dict) or value.get("kind") != LEDGER_KIND or value.get("contract") != CONTRACT:
        raise WorldBuilderError(f"{path} has the wrong format (expected kind={LEDGER_KIND!r}, contract={CONTRACT!r}); if this predates a ledger-format upgrade, it cannot be salvaged; a fresh build must start a new ledger")
    if value.get("build_id") != state.get("build_id"):
        raise WorldBuilderError(f"{path} belongs to build_id {value.get('build_id')!r}, not this build's own {state.get('build_id')!r}; check paths.pipeline_stage_ledger points at the right build's own ledger file")
    return value


def verify_receipt(root: Path, state: dict[str, Any], receipt: dict[str, Any], target: str | Path | None = None) -> None:
    stage = receipt.get("stage")
    if stage not in STAGES or receipt.get("kind") != RECEIPT_KIND or receipt.get("contract") != CONTRACT:
        raise WorldBuilderError(f"receipt for stage {stage!r} has the wrong format (expected kind={RECEIPT_KIND!r}, contract={CONTRACT!r}, stage in {list(STAGES)})")
    if receipt.get("build_id") != state.get("build_id"):
        raise WorldBuilderError(f"{stage} receipt belongs to build_id {receipt.get('build_id')!r}, not this build's own {state.get('build_id')!r}")
    applicable, reason = stage_applicable(stage, state)
    if receipt.get("applicable") is not applicable or receipt.get("reason") != reason:
        raise WorldBuilderError(f"{stage}'s applicability changed since this receipt was recorded (receipt says applicable={receipt.get('applicable')!r}, reason={receipt.get('reason')!r}; currently applicable={applicable!r}, reason={reason!r}); re-record this stage's receipt")
    receipt_target = receipt.get("target")
    if isinstance(receipt_target, str) and receipt_target:
        candidate = Path(receipt_target)
        receipt_target = candidate if candidate.is_absolute() else root / candidate
    if stage == "entry_names_normalized":
        # The entry-naming receipt binds the artifact it normalized. The stage
        # receipt's own target may point at the merge input, so resolve this
        # stage from the entry-naming receipt instead of that recorded target.
        effective_target = target
    elif target is not None and stage in {"output_contracts", "integration_output", "delivery_permitted"}:
        effective_target = target
    else:
        effective_target = receipt_target
    current_files, current_values = collect_evidence(root, state, stage, effective_target)
    if receipt.get("evidence_files") != current_files:
        raise WorldBuilderError(f"pipeline stage evidence files are stale: {stage}; something this stage depends on changed since it was recorded; re-record this stage's receipt")
    if receipt.get("evidence_values") != current_values:
        raise WorldBuilderError(f"pipeline stage evidence values are stale: {stage}; something this stage depends on changed since it was recorded; re-record this stage's receipt")


def _verify_amendment_ledger(root: Path, ledger: dict[str, Any]) -> list[str]:
    amendments = ledger.get("amendments") if isinstance(ledger.get("amendments"), list) else []
    base_rows = {row.get("stage"): row for row in (ledger.get("stages") or []) if isinstance(row, dict)}
    verified: list[str] = []
    for amendment in amendments:
        if not isinstance(amendment, dict):
            raise WorldBuilderError("pipeline amendment ledger contains a non-object entry")
        change_raw = amendment.get("change_set")
        if not isinstance(change_raw, str) or not change_raw:
            raise WorldBuilderError("pipeline amendment has no change_set path")
        change_path = Path(change_raw)
        if not change_path.is_absolute():
            change_path = root / change_path
        if not change_path.exists() or sha256_file(change_path) != amendment.get("change_set_sha256"):
            raise WorldBuilderError(f"{amendment.get('amendment_id')} change-set file is missing or hash-mismatched")
        for decision in amendment.get("stage_decisions", []):
            if not isinstance(decision, dict):
                raise WorldBuilderError(f"{amendment.get('amendment_id')} contains an invalid stage decision")
            stage = decision.get("stage")
            if decision.get("status") == "carried_forward":
                row = base_rows.get(stage)
                if row is None or row.get("sha256") != decision.get("prior_receipt_sha256"):
                    raise WorldBuilderError(f"{amendment.get('amendment_id')} carried-forward receipt for {stage} no longer matches the immutable base chain")
                if decision.get("justifying_hash") != amendment.get("change_set_sha256"):
                    raise WorldBuilderError(f"{amendment.get('amendment_id')} carried-forward decision for {stage} is not bound to its change set")
            elif decision.get("status") == "re_proven":
                receipt_raw = decision.get("receipt")
                if not isinstance(receipt_raw, str):
                    raise WorldBuilderError(f"{amendment.get('amendment_id')} re-proven decision for {stage} lacks a receipt")
                receipt_path = Path(receipt_raw)
                if not receipt_path.is_absolute():
                    receipt_path = root / receipt_path
                if not receipt_path.exists() or sha256_file(receipt_path) != decision.get("receipt_sha256"):
                    raise WorldBuilderError(f"{amendment.get('amendment_id')} re-proven receipt for {stage} is missing or hash-mismatched")
            else:
                raise WorldBuilderError(f"{amendment.get('amendment_id')} has an invalid decision for {stage}")
        verified.append(str(amendment.get("amendment_id")))
    return verified


def verify_chain(build_state: str | Path, *, through: str | None = None, target: str | Path | None = None) -> dict[str, Any]:
    root, state = load_build_state(build_state)
    ledger = load_ledger(root, state)
    entries = ledger.get("stages")
    if not isinstance(entries, list):
        raise WorldBuilderError(f"{ledger_path(root, state)}'s 'stages' field must be a list, found {type(entries).__name__}")
    limit = stage_index(through) if through else len(STAGES) - 1
    amendments = ledger.get("amendments") if isinstance(ledger.get("amendments"), list) else []
    historical_base = bool(amendments)
    previous_sha: str | None = None
    verified: list[str] = []
    seen: set[str] = set()
    by_stage = {row.get("stage"): row for row in entries if isinstance(row, dict)}
    for idx, stage in enumerate(STAGES[: limit + 1]):
        applicable, _ = stage_applicable(stage, state)
        row = by_stage.get(stage)
        if row is None:
            if applicable:
                raise WorldBuilderError(f"applicable pipeline stage has no receipt: {stage}. {stage_hint(stage, build_state)}")
            raise WorldBuilderError(f"non-applicable pipeline stage lacks an explicit not-required receipt: {stage}. {stage_hint(stage, build_state)}")
        if stage in seen:
            raise WorldBuilderError(f"{stage} appears more than once in the pipeline stage ledger; this ledger is corrupt and cannot be trusted; investigate what wrote a duplicate entry")
        seen.add(stage)
        path = root / str(row.get("receipt"))
        if not path.exists() or sha256_file(path) != row.get("sha256"):
            raise WorldBuilderError(f"{stage}'s receipt file at {path} is missing or its hash no longer matches the ledger's own record. {stage_hint(stage, build_state)}")
        receipt = load_json(path)
        if receipt.get("sequence") != idx + 1 or receipt.get("previous_receipt_sha256") != previous_sha:
            if idx > 0 and receipt.get("previous_receipt_sha256") != previous_sha:
                producer = STAGES[idx - 1]
                repair = f"{sys.executable or 'python'} {Path(__file__).resolve()} --build-state {Path(build_state).resolve()} --restamp {producer} --cascade"
                raise WorldBuilderError(
                    f"{stage}'s receipt chain is broken at its predecessor link (previous_receipt_sha256={receipt.get('previous_receipt_sha256')!r}, expected {previous_sha!r}). "
                    f"Repair the producer-side link, not the consumer stage: {repair}"
                )
            raise WorldBuilderError(f"{stage}'s receipt chain is broken (sequence={receipt.get('sequence')!r}, expected {idx + 1}); do not hand-edit receipts; {stage_hint(stage, build_state)}")
        # A named runtime adapter may change the output path between the
        # pre-adapter output-contract stage and the final integration/delivery
        # stages. Historical receipts must always revalidate their own bound
        # target. Apply a caller-supplied target only to the final stage being
        # verified, never retroactively to earlier target-bearing stages.
        stage_target = target if idx == limit else None
        if not historical_base:
            verify_receipt(root, state, receipt, stage_target)
        previous_sha = sha256_file(path)
        verified.append(stage)
    verified_amendments = _verify_amendment_ledger(root, ledger) if historical_base else []
    return {"status": "passed", "contract": CONTRACT, "build_id": state.get("build_id"), "verified_stages": verified, "verified_amendments": verified_amendments, "historical_base_chain": historical_base, "current_stage": verified[-1] if verified else None}


def verify_chain_links(build_state: str | Path, *, through: str | None = None) -> dict[str, Any]:
    """Verify only receipt presence, hashes, ordering, and predecessor links.

    Pending amendments deliberately make some historical stage evidence stale.
    ``--next`` still needs to surface a *broken receipt chain* in that state,
    without re-running evidence validation that the amendment is expected to
    supersede.  This helper is therefore intentionally narrower than
    :func:`verify_chain` and never treats stale stage evidence as acceptable on
    an ordinary, non-amendment verification path.
    """
    root, state = load_build_state(build_state)
    ledger = load_ledger(root, state)
    entries = ledger.get("stages")
    if not isinstance(entries, list):
        raise WorldBuilderError(f"{ledger_path(root, state)}'s 'stages' field must be a list, found {type(entries).__name__}")
    limit = stage_index(through) if through else len(STAGES) - 1
    by_stage = {row.get("stage"): row for row in entries if isinstance(row, dict)}
    previous_sha: str | None = None
    verified: list[str] = []
    for idx, stage in enumerate(STAGES[: limit + 1]):
        row = by_stage.get(stage)
        if row is None:
            raise WorldBuilderError(f"pipeline stage has no receipt while checking chain integrity: {stage}. {stage_hint(stage, build_state)}")
        path = root / str(row.get("receipt"))
        if not path.exists() or sha256_file(path) != row.get("sha256"):
            raise WorldBuilderError(f"{stage}'s receipt file at {path} is missing or its hash no longer matches the ledger's own record. {stage_hint(stage, build_state)}")
        receipt = load_json(path)
        if receipt.get("sequence") != idx + 1:
            raise WorldBuilderError(f"{stage}'s receipt chain is broken (sequence={receipt.get('sequence')!r}, expected {idx + 1}); do not hand-edit receipts; {stage_hint(stage, build_state)}")
        if receipt.get("previous_receipt_sha256") != previous_sha:
            producer = STAGES[idx - 1] if idx else None
            if producer:
                repair = f"{sys.executable or 'python'} {Path(__file__).resolve()} --build-state {Path(build_state).resolve()} --restamp {producer} --cascade"
                raise WorldBuilderError(
                    f"{stage}'s receipt chain is broken at its predecessor link (previous_receipt_sha256={receipt.get('previous_receipt_sha256')!r}, expected {previous_sha!r}). "
                    f"Repair the producer-side link, not the consumer stage: {repair}"
                )
            raise WorldBuilderError(f"{stage}'s first receipt unexpectedly points at a predecessor; do not hand-edit receipts")
        previous_sha = sha256_file(path)
        verified.append(stage)
    return {"status": "passed", "contract": CONTRACT, "build_id": state.get("build_id"), "verified_chain_links": verified}


def next_step(build_state: str | Path) -> dict[str, Any]:
    """Report the single next required pipeline command for this build.

    This is the step driver: run it after every pipeline command and execute
    exactly the command it prints. It also revalidates the recorded chain, so
    stale or reordered receipts surface here with repair guidance instead of
    at a later gate.
    """
    state_path = Path(build_state).resolve()
    root, state = load_build_state(state_path)
    ledger = load_ledger(root, state)
    entries = ledger.get("stages") if isinstance(ledger.get("stages"), list) else []
    recorded = [row.get("stage") for row in entries if isinstance(row, dict)]
    pending = (state.get("amendment") or {}).get("pending") if isinstance(state.get("amendment"), dict) else None
    if recorded:
        if isinstance(pending, dict):
            verify_chain_links(state_path, through=recorded[-1])
        else:
            verify_chain(state_path, through=recorded[-1])
    auto_before: list[str] = []
    for stage in STAGES[len(recorded):]:
        applicable, reason = stage_applicable(stage, state)
        if not applicable:
            auto_before.append(stage)
            continue
        command, reading = _command_for(stage, state_path)
        return {
            "status": "next",
            "contract": CONTRACT,
            "build_id": state.get("build_id"),
            "progress": f"{len(recorded)}/{len(STAGES)} stages recorded",
            "next_stage": stage,
            "reason": reason,
            "command": command,
            "read_first": reading,
            "auto_recorded_before": auto_before,
            "note": "Execute exactly this command. Re-read the listed material before running it. Non-applicable stages listed in auto_recorded_before are recorded automatically as not_required.",
        }
    if isinstance(pending, dict):
        change_set = pending.get("change_set")
        change_path = Path(change_set) if isinstance(change_set, str) else None
        if change_path is not None and not change_path.is_absolute():
            change_path = root / change_path
        phase = pending.get("phase", "metadata_reemit")
        if phase == "metadata_reemit":
            command = f"{sys.executable or 'python'} {Path(__file__).resolve().parent / 'selective_regeneration.py'} --build-state {state_path} metadata-reemit --change-set {change_path}"
            note = "The immutable base 15-stage chain remains sealed. Re-emit only the changed activation metadata; do not regenerate prose."
        elif phase == "changed_scope_audit":
            command = f"{sys.executable or 'python'} {Path(__file__).resolve().parent / 'audit_plan.py'} --build-state {state_path} --stage post-generation --scope changed --change-set {change_path}"
            note = "Re-prove only the changed UID slice with the normal deterministic full-book checks still active."
        elif phase == "amendment_seal":
            command = f"{sys.executable or 'python'} {Path(__file__).resolve().parent / 'delivery_gate.py'} --build-state {state_path} --seal"
            note = "Seal the amended target as seal_version 4 against the changed-scope audit while leaving the immutable base stage chain untouched."
        else:
            command = f"{sys.executable or 'python'} {Path(__file__).resolve()} --build-state {state_path} --record-amendment --change-set {change_path} --decisions-file <amendment-stage-decisions.json>"
            note = "Finalize the additive amendment ledger only after every affected stage is either freshly re-proven or explicitly carried forward as slice-unaffected."
        return {"status": "amendment_pending", "contract": CONTRACT, "build_id": state.get("build_id"), "phase": phase, "change_set": str(change_path), "command": command, "note": note}
    return {
        "status": "complete",
        "contract": CONTRACT,
        "build_id": state.get("build_id"),
        "progress": f"{len(recorded)}/{len(STAGES)} stages recorded",
        "note": "All pipeline stages are recorded and verified. Deliver only the sealed artifact from the build's creations/ path and quote the delivery seal hash and receipt path in the completion message.",
    }


def _guidance(state_path: Path, stage: str) -> None:
    try:
        idx = stage_index(stage)
        root, state = load_build_state(state_path)
        for candidate in STAGES[idx + 1:]:
            applicable, _ = stage_applicable(candidate, state)
            if applicable:
                command, reading = _command_for(candidate, state_path)
                print(
                    f"[worldbuilder] pipeline stage recorded: {stage} ({idx + 1}/{len(STAGES)}).\n"
                    f"[worldbuilder] NEXT STEP -> {command}\n"
                    f"[worldbuilder] Re-read before running it: {reading}\n"
                    f"[worldbuilder] If unsure at any point, run: {sys.executable or 'python'} {Path(__file__).resolve()} --build-state {state_path} --next",
                    file=sys.stderr,
                )
                return
        print(
            f"[worldbuilder] pipeline stage recorded: {stage} ({idx + 1}/{len(STAGES)}).\n"
            f"[worldbuilder] Pipeline chain is complete. Deliver only the sealed artifact from creations/ and quote the delivery seal hash and receipt path.",
            file=sys.stderr,
        )
    except Exception:  # guidance must never break a successful transition
        pass


def _write_stage(root: Path, state: dict[str, Any], state_path: Path, ledger: dict[str, Any], stage: str, target: str | Path | None) -> dict[str, Any]:
    idx = stage_index(stage)
    entries = ledger.get("stages") if isinstance(ledger.get("stages"), list) else []
    previous_sha: str | None = None
    if idx:
        previous = entries[-1] if entries else None
        if not isinstance(previous, dict) or previous.get("stage") != STAGES[idx - 1]:
            raise WorldBuilderError(f"cannot record {stage}; previous stage {STAGES[idx - 1]} is missing. {stage_hint(STAGES[idx - 1], state_path)}")
        previous_path = root / str(previous.get("receipt"))
        if not previous_path.exists() or sha256_file(previous_path) != previous.get("sha256"):
            raise WorldBuilderError(f"the receipt for the previous stage ({STAGES[idx - 1]}) at {previous_path} is missing or its hash no longer matches the ledger's record; something changed since it was recorded. {stage_hint(STAGES[idx - 1], state_path)}")
        previous_sha = sha256_file(previous_path)
    files, values = collect_evidence(root, state, stage, target)
    applicable, reason = stage_applicable(stage, state)
    target_value = None
    if stage == "entry_names_normalized":
        # Record exactly the target collect_evidence validated, so verify-time
        # resolution cannot drift from record time.
        target_value = (files.get("target") or {}).get("path")
    elif stage in {"output_contracts", "integration_output", "delivery_permitted"}:
        target_value = relative(target_path(root, state, target), root)
    receipt = {
        "kind": RECEIPT_KIND,
        "receipt_version": RECEIPT_VERSION,
        "contract": CONTRACT,
        "build_id": state.get("build_id"),
        "sequence": idx + 1,
        "stage": stage,
        "status": "passed" if applicable else "not_required",
        "applicable": applicable,
        "reason": reason,
        "target": target_value,
        "previous_stage": STAGES[idx - 1] if idx else None,
        "previous_receipt_sha256": previous_sha,
        "evidence_files": files,
        "evidence_values": values,
        "created_at": now_iso(),
    }
    path = stage_receipt_path(root, state, stage)
    atomic_write_json(path, receipt)
    entries.append({"stage": stage, "status": receipt["status"], "receipt": relative(path, root), "sha256": sha256_file(path)})
    ledger["stages"] = entries
    ledger["current_stage"] = stage
    ledger["updated_at"] = now_iso()
    atomic_write_json(ledger_path(root, state), ledger)
    state.setdefault("pipeline_stage_gate", {}).update({
        "contract": CONTRACT,
        "current_stage": stage,
        "ledger": relative(ledger_path(root, state), root),
        "ledger_sha256": sha256_file(ledger_path(root, state)),
    })
    state.setdefault("status", {})[f"stage_{stage}"] = receipt["status"]
    atomic_write_json(state_path, state)
    receipt["receipt"] = relative(path, root)
    receipt["receipt_sha256"] = sha256_file(path)
    return receipt


def advance(build_state: str | Path, stage: str, target: str | Path | None = None) -> dict[str, Any]:
    idx = stage_index(stage)
    state_path = Path(build_state).resolve()
    root, state = load_build_state(state_path)
    ledger = load_ledger(root, state)
    entries = ledger.get("stages") if isinstance(ledger.get("stages"), list) else []
    existing = {row.get("stage"): row for row in entries if isinstance(row, dict)}
    if stage in existing:
        verify_chain(state_path, through=stage, target=target)
        path = root / str(existing[stage]["receipt"])
        result = load_json(path)
        result["receipt"] = relative(path, root)
        result["receipt_sha256"] = sha256_file(path)
        return result

    expected_count = len(entries)
    if expected_count > idx:
        raise WorldBuilderError(f"the pipeline stage ledger already has {expected_count} stages recorded, past {stage} (index {idx}); this stage was already advanced; use restamp() to re-hash it instead of advance()")
    if expected_count:
        # The target supplied to this transition belongs to the new stage. The
        # already-recorded chain must be checked against each receipt's own
        # target, especially across the runtime-adapter boundary.
        verify_chain(state_path, through=STAGES[expected_count - 1])

    # Fill only non-applicable gaps. Applicable gaps are proof of a skipped step.
    while len(entries) < idx:
        missing = STAGES[len(entries)]
        applicable, _ = stage_applicable(missing, state)
        # Legacy/manual build states may predate the stage ledger. Reconstruct
        # only the immutable initialization checkpoint from its exact files;
        # every later applicable stage still requires its normal gate script.
        if applicable and missing != "workspace_initialized":
            raise WorldBuilderError(f"cannot record {stage}; applicable stage was skipped: {missing}. {stage_hint(missing, state_path)}")
        _write_stage(root, state, state_path, ledger, missing, target)  # not_required gap fill: no guidance
        root, state = load_build_state(state_path)
        ledger = load_ledger(root, state)
        entries = ledger.get("stages") if isinstance(ledger.get("stages"), list) else []
    receipt = _write_stage(root, state, state_path, ledger, stage, target)
    _guidance(state_path, stage)
    return receipt


def _receipt_evidence_is_archived(root: Path, state: dict[str, Any], receipt: dict[str, Any]) -> bool:
    """Return True only when every missing evidence file is hash-preserved in a trusted invalidation archive.

    ``--tolerate-archived`` is for a very specific recovery case: a deliberate
    lineage invalidation moved evidence out of the live tree, and a later
    cascade only needs to repair predecessor hashes.  It must not turn an
    arbitrary stale receipt into a valid one.  Accordingly, this helper:

    * requires at least one receipt-bound evidence file to be absent live;
    * trusts only indexes bound by their invalidation receipt and build_id;
    * requires the archived bytes to match the receipt's original SHA-256; and
    * refuses tolerance if any receipt-bound live file exists with different
      bytes (that is real drift, not archival).
    """
    evidence_files = receipt.get("evidence_files")
    if not isinstance(evidence_files, dict) or not evidence_files:
        return False

    missing: list[tuple[str, str]] = []
    for row in evidence_files.values():
        if not isinstance(row, dict):
            return False
        rel = row.get("path")
        expected = row.get("sha256")
        if not isinstance(rel, str) or not isinstance(expected, str):
            return False
        live = (root / rel).resolve()
        try:
            live.relative_to(root)
        except ValueError:
            return False
        if live.is_file():
            if sha256_file(live) != expected:
                return False
        else:
            missing.append((rel.replace(os.sep, "/"), expected))
    if not missing:
        return False

    trusted: dict[tuple[str, str], Path] = {}
    invalidated = root / ".work" / "invalidated"
    if not invalidated.is_dir():
        return False
    for archive in sorted((p for p in invalidated.iterdir() if p.is_dir()), reverse=True):
        index_path = archive / "index.json"
        receipt_path = archive / "invalidation-receipt.json"
        if not index_path.is_file() or not receipt_path.is_file():
            continue
        try:
            invalidation = load_json(receipt_path)
            index = load_json(index_path)
        except (OSError, json.JSONDecodeError, UnicodeDecodeError):
            continue
        if not isinstance(invalidation, dict) or not isinstance(index, dict):
            continue
        if invalidation.get("build_id") != state.get("build_id") or index.get("build_id") != state.get("build_id"):
            continue
        if invalidation.get("archive_index_sha256") != sha256_file(index_path):
            continue
        for item in index.get("entries", []):
            if not isinstance(item, dict):
                continue
            source = item.get("source_path")
            archived_raw = item.get("archive_path")
            recorded_sha = item.get("sha256")
            if not all(isinstance(value, str) for value in (source, archived_raw, recorded_sha)):
                continue
            archived = (root / archived_raw).resolve()
            try:
                archived.relative_to(root)
            except ValueError:
                continue
            if archived.is_file() and sha256_file(archived) == recorded_sha:
                trusted[(source.replace(os.sep, "/"), recorded_sha)] = archived

    return all((rel, expected) in trusted for rel, expected in missing)



def restamp(build_state: str | Path, stage: str, *, target: str | Path | None = None, cascade: bool = False, allow_sealed_edit: bool = False, tolerate_archived: bool = False) -> dict[str, Any]:
    """Re-hash one stage's evidence without invalidating anything downstream.

    A stage receipt records the SHA of every evidence file. Any edit to one of those
    files, including a correction the user was told to make, made the stage stale,
    and the only recovery was `--invalidate-from`, which discards every downstream
    stage too. A single receipt fix therefore cost a full pipeline re-run, repeatedly.

    Restamp re-records the current evidence for one stage. It is deliberately narrow:

    - The stage must still be applicable, and its contract must still be satisfied,
      so this cannot stamp a stage whose gate would now fail.
    - Only the *stage's own* evidence is re-hashed. Downstream receipts keep their
      recorded values, so anything that genuinely depended on the old bytes still
      shows as stale on the next verify and is caught rather than papered over.
    - It reports which hashes moved, so a user can see whether the change was the
      non-semantic one they intended.

    This is not `--force`. It re-proves the stage against its own contract; it just
    does not punish the rest of the pipeline for a change that may not affect it.
    """
    if stage not in STAGES:
        raise WorldBuilderError(f"unknown pipeline stage {stage!r}; valid stages are {list(STAGES)}")
    state_path = Path(build_state).resolve()
    root, state = load_build_state(state_path)
    ledger = load_ledger(root, state)
    entries = ledger.get("stages") if isinstance(ledger.get("stages"), list) else []
    sealed = any(isinstance(r, dict) and r.get("stage") == "delivery_permitted" for r in entries) and state.get("status", {}).get("delivery") == "permitted"
    if sealed and not allow_sealed_edit:
        raise WorldBuilderError(
            "refusing to restamp a sealed pipeline chain. Sealed receipts are immutable; use a scoped "
            "record_amendment flow for a post-delivery change, or pass --allow-sealed-edit only for an explicit forensic repair."
        )

    row = next((r for r in entries if isinstance(r, dict) and r.get("stage") == stage), None)
    if row is None:
        raise WorldBuilderError(
            f"stage {stage} has never been recorded, so there is nothing to restamp. "
            f"Run it normally: {stage_hint(stage, state_path)}"
        )

    applicable, reason = stage_applicable(stage, state)
    if not applicable:
        raise WorldBuilderError(f"stage {stage} is no longer applicable ({reason}); invalidate instead of restamping")

    receipt_path = root / str(row.get("receipt"))
    if not receipt_path.exists():
        raise WorldBuilderError(f"{stage}'s ledger entry points to a receipt file that does not exist at {receipt_path}; the ledger and the actual receipt files on disk have diverged; this cannot be safely restamped")
    receipt = load_json(receipt_path)
    if not isinstance(receipt, dict):
        raise WorldBuilderError(f"{receipt_path} must contain a JSON object, found {type(receipt).__name__}; this cannot be safely restamped")

    effective_target = target if target is not None else receipt.get("target")
    if isinstance(effective_target, str) and effective_target:
        candidate = Path(effective_target)
        effective_target = candidate if candidate.is_absolute() else root / candidate

    # Recollecting evidence re-runs the stage's own contract checks, so a stage whose
    # gate would now fail cannot be restamped into looking valid.
    current_files, current_values = collect_evidence(root, state, stage, effective_target)

    previous_files = receipt.get("evidence_files") if isinstance(receipt.get("evidence_files"), dict) else {}
    changed = sorted(
        key for key in set(previous_files) | set(current_files)
        if previous_files.get(key) != current_files.get(key)
    )
    values_changed = receipt.get("evidence_values") != current_values

    receipt["evidence_files"] = current_files
    receipt["evidence_values"] = current_values
    receipt["restamped_at"] = now_iso()
    receipt["restamp_count"] = int(receipt.get("restamp_count", 0)) + 1
    atomic_write_json(receipt_path, receipt)

    # verify_chain reads row["sha256"] (written at record time, line ~648). Writing only
    # receipt_sha256 left the row carrying the pre-restamp hash, so the stage stayed
    # stale forever and the recovery path silently did nothing.
    fresh = sha256_file(receipt_path)
    row["sha256"] = fresh
    row["receipt_sha256"] = fresh
    row["restamped_at"] = receipt["restamped_at"]
    atomic_write_json(ledger_path(root, state), ledger)

    downstream = [s for s in STAGES if stage_index(s) > stage_index(stage)
                  and any(isinstance(r, dict) and r.get("stage") == s for r in entries)]
    repaired: list[str] = []
    archived_tolerated: list[str] = []
    if cascade and downstream:
        previous_sha = fresh
        for downstream_stage in downstream:
            downstream_row = next(r for r in entries if isinstance(r, dict) and r.get("stage") == downstream_stage)
            downstream_path = root / str(downstream_row.get("receipt"))
            if not downstream_path.exists():
                raise WorldBuilderError(f"cannot cascade chain repair: {downstream_stage}'s receipt is missing at {downstream_path}")
            downstream_receipt = load_json(downstream_path)
            # Re-prove the downstream receipt against its own evidence before changing
            # only the cryptographic link to the newly-restamped predecessor.
            try:
                verify_receipt(root, state, downstream_receipt, None)
            except WorldBuilderError as exc:
                if not tolerate_archived or not _receipt_evidence_is_archived(root, state, downstream_receipt):
                    raise WorldBuilderError(
                        f"cannot cascade the chain repair through {downstream_stage}: its own evidence is stale "
                        f"({exc}). Re-prove {downstream_stage} against its current inputs first, then re-run this "
                        "restamp with --cascade. Working order: consumer evidence first, then the producer restamp "
                        "(see references/runtime-recovery.md)."
                    ) from exc
                archived_tolerated.append(downstream_stage)
            downstream_receipt["previous_receipt_sha256"] = previous_sha
            downstream_receipt["chain_repaired_at"] = now_iso()
            if downstream_stage in archived_tolerated:
                downstream_receipt["chain_repair_evidence"] = "archived_hash_index_verified"
            atomic_write_json(downstream_path, downstream_receipt)
            downstream_fresh = sha256_file(downstream_path)
            downstream_row["sha256"] = downstream_fresh
            downstream_row["receipt_sha256"] = downstream_fresh
            repaired.append(downstream_stage)
            previous_sha = downstream_fresh
        ledger["updated_at"] = now_iso()
        atomic_write_json(ledger_path(root, state), ledger)
        state.setdefault("pipeline_stage_gate", {})["ledger_sha256"] = sha256_file(ledger_path(root, state))
        atomic_write_json(state_path, state)
    return {
        "stage": stage,
        "changed_evidence_files": changed,
        "evidence_values_changed": values_changed,
        "downstream_stages_untouched": [] if cascade else downstream,
        "chain_links_repaired": repaired,
        "archived_evidence_tolerated": archived_tolerated,
        "note": (
            "Cascade repaired only previous_receipt_sha256 chain links after re-verifying each downstream stage's own evidence; archived evidence was accepted only when a recorded invalidation index preserved every missing file at its original SHA-256."
            if cascade else
            "Downstream receipts keep their recorded values. Run --verify to confirm none of them genuinely depended on what changed; anything that did will still report stale."
        ),
    }


def invalidate_from(build_state: str | Path, stage: str, *, allow_sealed_edit: bool = False) -> dict[str, Any]:
    idx = stage_index(stage)
    state_path = Path(build_state).resolve()
    root, state = load_build_state(state_path)
    ledger = load_ledger(root, state)
    entries = ledger.get("stages") if isinstance(ledger.get("stages"), list) else []
    sealed = any(isinstance(r, dict) and r.get("stage") == "delivery_permitted" for r in entries) and state.get("status", {}).get("delivery") == "permitted"
    if sealed and not allow_sealed_edit:
        raise WorldBuilderError(
            "refusing to invalidate a sealed pipeline chain. Use record_amendment for post-delivery scoped changes; "
            "--allow-sealed-edit is reserved for explicit forensic repair."
        )
    kept: list[dict[str, Any]] = []
    removed: list[str] = []
    for row in entries:
        name = row.get("stage") if isinstance(row, dict) else None
        if name not in STAGES:
            continue
        if stage_index(name) >= idx:
            path = root / str(row.get("receipt"))
            if path.exists():
                path.unlink()
            removed.append(name)
            state.get("status", {}).pop(f"stage_{name}", None)
        else:
            kept.append(row)
    ledger["stages"] = kept
    ledger["current_stage"] = kept[-1]["stage"] if kept else None
    ledger["updated_at"] = now_iso()
    atomic_write_json(ledger_path(root, state), ledger)
    state.setdefault("pipeline_stage_gate", {}).update({
        "contract": CONTRACT,
        "current_stage": ledger["current_stage"],
        "ledger": relative(ledger_path(root, state), root),
        "ledger_sha256": sha256_file(ledger_path(root, state)),
    })
    atomic_write_json(state_path, state)
    return {"status": "invalidated", "from_stage": stage, "removed": removed, "current_stage": ledger["current_stage"]}


AMENDMENT_DEPTH_CAP = 3
AMENDMENT_TOUCHED_FRACTION_CAP = 0.2

# Stages before this one are about the original plan/research, which a
# post-seal, non-structural entry edit cannot retroactively affect;
# they are always carried_forward for a non-structural amendment. A
# structural change set (change_set.py's own "structural" flag: the
# pipeline registry, default profile, or lineage roots themselves
# changed) starts the affected range earlier, at planning_validated,
# since the plan itself is what changed.
FIRST_AMENDABLE_STAGE_NONSTRUCTURAL = "pre_generation_audit"
FIRST_AMENDABLE_STAGE_STRUCTURAL = "planning_validated"


def amendment_scope_details(change_set_data: dict[str, Any], manifest_entry_count: int, existing_amendment_count: int) -> dict[str, Any]:
    """Return the exact arithmetic behind the amendment safety caps.

    This is intentionally usable by planning code as a warning-only preflight.
    The hard refusal remains in :func:`amendment_scope_check`.  Neighbours count
    one-for-one toward the touched-entry cap, but an accidental overlap with a
    directly changed UID is counted only once in the total.
    """
    if manifest_entry_count <= 0:
        raise WorldBuilderError(
            "cannot evaluate amendment scope: the manifest resolved to zero entries; either "
            "paths.manifest does not point at a real manifest for this build, or the manifest itself is genuinely empty"
        )
    changed = {str(uid) for uid in change_set_data.get("changed_uids", [])}
    neighbours = {str(uid) for uid in change_set_data.get("neighbour_affected_uids", [])}
    neighbour_only = neighbours - changed
    touched = changed | neighbours
    cap_entries = int(manifest_entry_count * AMENDMENT_TOUCHED_FRACTION_CAP)
    touched_count = len(touched)
    fraction = touched_count / manifest_entry_count
    if touched_count == 0:
        amendments_needed = 0
    elif cap_entries <= 0:
        amendments_needed = touched_count
    else:
        amendments_needed = (touched_count + cap_entries - 1) // cap_entries
    return {
        "manifest_entry_count": manifest_entry_count,
        "changed_uid_count": len(changed),
        "neighbour_uid_count": len(neighbour_only),
        "touched_uid_count": touched_count,
        "touched_fraction": fraction,
        "cap_fraction": AMENDMENT_TOUCHED_FRACTION_CAP,
        "cap_entry_count": cap_entries,
        "existing_amendment_count": existing_amendment_count,
        "depth_cap": AMENDMENT_DEPTH_CAP,
        "remaining_amendment_slots": max(0, AMENDMENT_DEPTH_CAP - existing_amendment_count),
        "amendments_needed_for_this_scope": amendments_needed,
        "over_fraction_cap": fraction > AMENDMENT_TOUCHED_FRACTION_CAP,
        "depth_cap_reached": existing_amendment_count >= AMENDMENT_DEPTH_CAP,
    }


def amendment_scope_message(details: dict[str, Any]) -> str:
    touched = int(details["touched_uid_count"])
    total = int(details["manifest_entry_count"])
    changed = int(details["changed_uid_count"])
    neighbours = int(details["neighbour_uid_count"])
    cap_entries = int(details["cap_entry_count"])
    needed = int(details["amendments_needed_for_this_scope"])
    return (
        f"touched {touched}/{total} ({changed} changed + {neighbours} neighbours); "
        f"cap is {cap_entries}/{total} ({AMENDMENT_TOUCHED_FRACTION_CAP:.0%}); "
        f"this change would need >={needed} amendment{'s' if needed != 1 else ''} "
        f"(depth cap {AMENDMENT_DEPTH_CAP})"
    )


def amendment_scope_check(change_set_data: dict[str, Any], manifest_entry_count: int, existing_amendment_count: int) -> None:
    """Batch 12 guards with Batch 40 actionable arithmetic."""
    details = amendment_scope_details(change_set_data, manifest_entry_count, existing_amendment_count)
    if details["depth_cap_reached"]:
        raise WorldBuilderError(
            f"amendment depth cap reached ({existing_amendment_count} >= {AMENDMENT_DEPTH_CAP}); "
            f"{amendment_scope_message(details)} -> re-baseline required"
        )
    if details["over_fraction_cap"]:
        raise WorldBuilderError(
            f"amendment scope exceeds the safety cap: {amendment_scope_message(details)} -> re-baseline required"
        )


def first_amendable_stage(change_set_data: dict[str, Any]) -> str:
    return FIRST_AMENDABLE_STAGE_STRUCTURAL if change_set_data.get("structural") else FIRST_AMENDABLE_STAGE_NONSTRUCTURAL


def record_amendment(
    build_state: str | Path, *, change_set_path: str | Path,
    stage_decisions: dict[str, dict[str, Any]],
) -> dict[str, Any]:
    """Batch 12: an amendment_N sub-ledger entry instead of rolling back
    to a fixed stage via invalidate_from; the sealed chain's own
    receipts are never touched or removed. Each stage from
    first_amendable_stage onward is either "re_proven" (a fresh receipt
    for this change set) or "carried_forward: slice_unaffected" (the
    prior receipt still holds, justified by this amendment's own change-
    set hash). Guarded by amendment_scope_check before anything is
    written; a rejected amendment leaves the ledger completely
    unchanged.
    """
    state_path = Path(build_state).resolve()
    root, state = load_build_state(state_path)
    ledger = load_ledger(root, state)
    change_set_full_path = Path(change_set_path).resolve()
    if not change_set_full_path.exists():
        raise WorldBuilderError(f"amendment change set does not exist: {change_set_full_path}")
    change_set_data = load_json(change_set_full_path)
    change_set_sha = sha256_file(change_set_full_path)

    manifest_path = resolve_state_path(root, state, "manifest", required=False)
    manifest_entry_count = len(load_json(manifest_path).get("entries", [])) if manifest_path and manifest_path.exists() else 0

    existing_amendments = ledger.get("amendments") if isinstance(ledger.get("amendments"), list) else []
    amendment_scope_check(change_set_data, manifest_entry_count, len(existing_amendments))

    start_stage = first_amendable_stage(change_set_data)
    start_idx = stage_index(start_stage)
    affected_stages = STAGES[start_idx:]

    missing = sorted(set(affected_stages) - set(stage_decisions))
    if missing:
        raise WorldBuilderError(f"amendment is missing a decision for stage(s): {', '.join(missing)}")
    extra = sorted(set(stage_decisions) - set(affected_stages))
    if extra:
        raise WorldBuilderError(f"amendment declares decisions for stage(s) outside the affected range: {', '.join(extra)}")

    # Validate every decision before creating any amendment-owned snapshots.
    validated_reproofs: dict[str, Path] = {}
    carried_rows: dict[str, dict[str, Any]] = {}
    for stage in affected_stages:
        decision = stage_decisions[stage]
        status = decision.get("status")
        if status == "re_proven":
            receipt_raw = decision.get("receipt_path")
            if not isinstance(receipt_raw, str) or not receipt_raw:
                raise WorldBuilderError(f"amendment stage {stage!r} is declared 're_proven' but its receipt_path ({receipt_raw!r}) is empty or does not exist; write the fresh receipt for this stage before declaring it re_proven")
            receipt_path = Path(receipt_raw)
            if not receipt_path.is_absolute():
                receipt_path = root / receipt_path
            if not receipt_path.exists():
                raise WorldBuilderError(f"amendment stage {stage!r} is declared 're_proven' but its receipt_path ({receipt_raw!r}) is empty or does not exist; write the fresh receipt for this stage before declaring it re_proven")
            validated_reproofs[stage] = receipt_path
        elif status == "carried_forward":
            prior_row = next((row for row in ledger.get("stages", []) if isinstance(row, dict) and row.get("stage") == stage), None)
            if prior_row is None:
                raise WorldBuilderError(f"amendment stage {stage!r} is declared 'carried_forward' but this build's ledger has no prior sealed receipt for it to carry forward; this stage has never been recorded, so it must be 're_proven' instead")
            carried_rows[stage] = prior_row
        else:
            raise WorldBuilderError(f"amendment stage {stage!r} has an invalid status {status!r} (must be re_proven or carried_forward)")

    amendment_number = len(existing_amendments) + 1
    amendment_id = f"amendment_{amendment_number}"
    snapshot_dir = root / ".work" / "amendments" / amendment_id
    resolved_decisions: list[dict[str, Any]] = []
    for stage in affected_stages:
        decision = stage_decisions[stage]
        if decision.get("status") == "re_proven":
            source = validated_reproofs[stage]
            snapshot_dir.mkdir(parents=True, exist_ok=True)
            suffix = source.suffix if source.suffix else ".receipt"
            snapshot = snapshot_dir / f"{stage}{suffix}"
            snapshot.write_bytes(source.read_bytes())
            resolved_decisions.append({
                "stage": stage, "status": "re_proven",
                "receipt": relative(snapshot, root),
                "receipt_sha256": sha256_file(snapshot),
                "source_receipt": relative(source, root) if _is_within(source, root) else str(source),
            })
        else:
            prior_row = carried_rows[stage]
            resolved_decisions.append({
                "stage": stage, "status": "carried_forward", "reason": "slice_unaffected",
                "justifying_hash": change_set_sha, "prior_receipt_sha256": prior_row.get("sha256"),
            })

    amendment_entry = {
        "amendment_id": amendment_id,
        "created_at": now_iso(),
        "change_set": relative(change_set_full_path, root) if _is_within(change_set_full_path, root) else str(change_set_full_path),
        "change_set_sha256": change_set_sha,
        "first_amended_stage": start_stage,
        "structural": bool(change_set_data.get("structural")),
        "manifest_entry_count": manifest_entry_count,
        "touched_uid_count": len(set(change_set_data.get("changed_uids", [])) | set(change_set_data.get("neighbour_affected_uids", []))),
        "stage_decisions": resolved_decisions,
    }
    ledger.setdefault("amendments", []).append(amendment_entry)
    ledger["updated_at"] = now_iso()
    atomic_write_json(ledger_path(root, state), ledger)
    state.setdefault("pipeline_stage_gate", {}).update({
        "contract": CONTRACT,
        "ledger": relative(ledger_path(root, state), root),
        "ledger_sha256": sha256_file(ledger_path(root, state)),
    })
    if isinstance(state.get("amendment"), dict):
        state["amendment"].pop("pending", None)
    atomic_write_json(state_path, state)
    return {"status": "amended", "amendment_id": amendment_entry["amendment_id"], "amendment_number": amendment_number, "stage_decisions": resolved_decisions}


def abandon_amendment(build_state: str | Path) -> dict[str, Any]:
    """Clear a stuck pending amendment without pretending the build is deliverable.

    Once amendment work has started, files may already have been archived or
    metadata may have been re-emitted. Abandoning therefore clears the state
    machine deadlock but deliberately marks delivery invalidated and requires a
    re-baseline/recovery decision instead of silently restoring trust.
    """
    state_path = Path(build_state).resolve()
    root, state = load_build_state(state_path)
    amendment = state.get("amendment") if isinstance(state.get("amendment"), dict) else {}
    pending = amendment.get("pending") if isinstance(amendment, dict) else None
    if not isinstance(pending, dict):
        raise WorldBuilderError("there is no pending amendment to abandon")
    abandoned = dict(pending)
    amendment.pop("pending", None)
    amendment.setdefault("abandoned", []).append({**abandoned, "abandoned_at": now_iso()})
    state.setdefault("status", {})["delivery"] = "invalidated"
    state.setdefault("lineage", {})["amendment_abandoned"] = {
        "at": now_iso(),
        "change_set": abandoned.get("change_set"),
        "rebaseline_required": True,
    }
    atomic_write_json(state_path, state)
    return {
        "status": "amendment_abandoned",
        "change_set": abandoned.get("change_set"),
        "rebaseline_required": True,
        "next": "Recover/restore any archived artifacts you need, then start a fresh re-baseline before delivery.",
    }


def _is_within(path: Path, root: Path) -> bool:
    try:
        path.relative_to(root)
        return True
    except ValueError:
        return False


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--build-state", required=True)
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--stage", choices=STAGES)
    group.add_argument("--verify", action="store_true")
    group.add_argument("--invalidate-from", choices=STAGES)
    group.add_argument("--restamp", choices=STAGES, help="Re-hash one stage's evidence without invalidating downstream stages.")
    group.add_argument("--record-amendment", action="store_true", help="Finalize an additive scoped amendment using a change set and explicit per-stage decisions.")
    group.add_argument("--abandon-amendment", action="store_true", help="Clear a stuck pending amendment and require re-baselining before delivery.")
    group.add_argument("--next", action="store_true", help="Print the single next required pipeline command and its required reading.")
    parser.add_argument("--through", choices=STAGES)
    parser.add_argument("--target")
    parser.add_argument("--cascade", action="store_true", help="With --restamp, repair downstream previous_receipt_sha256 links after independently re-verifying their own evidence.")
    parser.add_argument("--allow-sealed-edit", action="store_true", help="Explicit forensic override allowing restamp/invalidate on an already delivered chain.")
    parser.add_argument("--tolerate-archived", action="store_true", help="With --restamp --cascade, permit chain-link repair across stages whose evidence is recorded as archived by lineage invalidation.")
    parser.add_argument("--change-set", help="Change-set JSON for --record-amendment.")
    parser.add_argument("--decisions-file", help="JSON object mapping affected stage names to re_proven/carried_forward decisions.")
    args = parser.parse_args()
    try:
        if args.stage:
            normal, _ = _command_for(args.stage, args.build_state)
            print(f"[worldbuilder] note: --stage records the ledger receipt only. The normal recorder for {args.stage} is: {normal}", file=sys.stderr)
            result = advance(args.build_state, args.stage, args.target)
        elif getattr(args, 'next', False):
            result = next_step(args.build_state)
            next_stage = result.get("next_stage") if isinstance(result, dict) else None
            if isinstance(next_stage, str):
                import phase_contract
                result["exit_contract"] = phase_contract.next_contract_payload(args.build_state, next_stage)
        elif args.invalidate_from:
            result = invalidate_from(args.build_state, args.invalidate_from, allow_sealed_edit=args.allow_sealed_edit)
        elif args.restamp:
            result = restamp(args.build_state, args.restamp, target=args.target, cascade=args.cascade, allow_sealed_edit=args.allow_sealed_edit, tolerate_archived=args.tolerate_archived)
        elif args.abandon_amendment:
            result = abandon_amendment(args.build_state)
        elif args.record_amendment:
            if not args.change_set or not args.decisions_file:
                raise WorldBuilderError("--record-amendment requires --change-set and --decisions-file")
            decisions = load_json(Path(args.decisions_file).expanduser().resolve())
            if not isinstance(decisions, dict):
                raise WorldBuilderError("--decisions-file must contain a JSON object keyed by stage")
            result = record_amendment(args.build_state, change_set_path=args.change_set, stage_decisions=decisions)
        else:
            result = verify_chain(args.build_state, through=args.through, target=args.target)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (WorldBuilderError, OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"PIPELINE STAGE GATE BLOCKED: {exc}", file=sys.stderr)
        print(step_driver_pointer(), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
