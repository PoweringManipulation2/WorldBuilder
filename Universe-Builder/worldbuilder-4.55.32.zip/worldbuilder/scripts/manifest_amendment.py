#!/usr/bin/env python3
"""Batch 7, 7.11: the sanctioned manifest amendment path for Update/Merge.

Replaces "update the manifest transactionally" (references/update-merge.md,
step 7, an instruction with no mechanism behind it) with a concrete,
receipt-bound path: compute the change set first, refuse anything
structural outright, then write the manifest and selectively invalidate
only what the change set says is actually affected; never grow a second,
parallel notion of "what changed" independent of change_set.py.

The 8 structural hashes are read from their confirmed authoritative
sources, not re-derived by guesswork:
    - era/character/placement/budget/dynamic_state_plan_sha256: from
      state["lineage"], written by planning_gate.py's own final update
      after a successful planning run, exactly the state an amendment
      target must already be in.
    - discovery_receipt_sha256: from the manifest's own field (its binding
      to discovery), read per-manifest; prior and amended can genuinely
      differ here if the amendment also touches discovery binding, which
      would correctly register as structural.
    - registry_sha256, default_profile_sha256: hashed fresh from their live
      files (pipeline_registry.json, default_profile.json). Neither is
      tracked in state["lineage"]; hashing the live file directly can never
      be stale, unlike trusting a snapshot that might not exist.

registry_sha256 refers specifically to pipeline_registry.json, not
field_registry.json; field_registry's own hash is embedded inside
default_profile.json's content, so a field_registry change already
surfaces transitively through default_profile_sha256 without needing its
own separate key.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path
from typing import Any

from wb_common import WorldBuilderError, atomic_write_json, load_build_state, load_json, resolve_state_path, sha256_file
from change_set import compute_change_set
from lineage_invalidate import invalidate

CONTRACT = "worldbuilder-manifest-amendment-v1"


def _live_structural_hashes(root: Path, state: dict[str, Any], manifest: dict[str, Any]) -> dict[str, Any]:
    lineage = state.get("lineage", {}) if isinstance(state.get("lineage"), dict) else {}
    registry_path = resolve_state_path(root, state, "pipeline_registry", required=False)
    default_profile_path = resolve_state_path(root, state, "default_profile", required=False)
    return {
        "registry_sha256": sha256_file(registry_path) if registry_path and registry_path.exists() else None,
        "default_profile_sha256": sha256_file(default_profile_path) if default_profile_path and default_profile_path.exists() else None,
        "era_plan_sha256": lineage.get("era_plan_sha256"),
        "character_plan_sha256": lineage.get("character_plan_sha256"),
        "placement_plan_sha256": lineage.get("placement_plan_sha256"),
        "budget_plan_sha256": lineage.get("budget_plan_sha256"),
        "dynamic_state_plan_sha256": lineage.get("dynamic_state_plan_sha256"),
        "discovery_receipt_sha256": manifest.get("discovery_receipt_sha256"),
    }


def apply_manifest_amendment(
    build_state_path: str, amended_manifest: dict[str, Any], *, reason: str, approved_by: str,
) -> dict[str, Any]:
    """The one sanctioned path. Never a direct file write to the live
    manifest; always change-set-checked first, and the change set itself
    becomes a permanent, auditable artifact alongside the receipt, not a
    disposable intermediate."""
    if not isinstance(reason, str) or not reason.strip():
        raise WorldBuilderError("manifest amendment requires a non-empty reason")
    if not isinstance(approved_by, str) or not approved_by.strip():
        raise WorldBuilderError("manifest amendment requires a non-empty approved_by")

    root, state = load_build_state(build_state_path)
    manifest_path = resolve_state_path(root, state, "manifest")
    prior_manifest = load_json(manifest_path)

    prior_hashes = _live_structural_hashes(root, state, prior_manifest)
    current_hashes = _live_structural_hashes(root, state, amended_manifest)
    result = compute_change_set(
        prior_manifest, amended_manifest,
        prior_structural_hashes=prior_hashes, current_structural_hashes=current_hashes,
    )

    if result["structural"]:
        raise WorldBuilderError(
            "this amendment changes a structural artifact ("
            + ", ".join(result["structural_diffs"])
            + "); it cannot be applied as a sanctioned amendment. Use lineage_invalidate.py "
            "--from-stage manifest (whole-stage, no --change-set) and re-plan from scratch."
        )
    if not (result["changed_uids"] or result["neighbour_affected_uids"]):
        raise WorldBuilderError("amended manifest is identical to the live one: nothing to amend")

    # The change set is written before the manifest itself, so it exists on
    # disk (and can be inspected) even if something fails between here and
    # the receipt: never silently lost mid-amendment.
    stamp = time.strftime("%Y%m%dT%H%M%SZ", time.gmtime())
    change_set_dir = root / ".work" / "change-sets"
    change_set_dir.mkdir(parents=True, exist_ok=True)
    change_set_path = change_set_dir / f"{stamp}.json"
    atomic_write_json(change_set_path, result)

    atomic_write_json(manifest_path, amended_manifest)

    invalidation = invalidate(
        build_state_path, "manifest",
        f"manifest amendment: {reason.strip()}", change_set_path=str(change_set_path),
        preserve_pipeline_chain=True,
    )

    receipt = {
        "kind": CONTRACT, "receipt_version": 1,
        "build_id": state.get("build_id"),
        "reason": reason.strip(), "approved_by": approved_by.strip(),
        "change_set_path": str(change_set_path.relative_to(root)).replace("\\", "/"),
        "change_set": result,
        "invalidation": invalidation,
        "additive_amendment": True,
        "next": f"Run selective_regeneration.py --build-state {Path(build_state_path).resolve()} metadata-reemit --change-set {change_set_path}",
        "amended_at_unix": int(time.time()),
    }
    receipt_dir = root / ".work" / "manifest-amendments"
    receipt_dir.mkdir(parents=True, exist_ok=True)
    receipt_path = receipt_dir / f"{stamp}.json"
    atomic_write_json(receipt_path, receipt)
    receipt["receipt_path"] = str(receipt_path.relative_to(root)).replace("\\", "/")
    return receipt


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--build-state", required=True)
    parser.add_argument("--amended-manifest", required=True, help="Path to the proposed, already-merged manifest JSON")
    parser.add_argument("--reason", required=True)
    parser.add_argument("--approved-by", required=True)
    args = parser.parse_args()
    try:
        result = apply_manifest_amendment(
            args.build_state, load_json(Path(args.amended_manifest)),
            reason=args.reason, approved_by=args.approved_by,
        )
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (WorldBuilderError, OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
