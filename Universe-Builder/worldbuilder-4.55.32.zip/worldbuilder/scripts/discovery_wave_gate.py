#!/usr/bin/env python3
"""Validate one staged discovery wave and unlock the next 4 -> 10 -> 20 wave."""
from __future__ import annotations

import argparse
import json
import statistics
import sys
from datetime import datetime
from pathlib import Path
from typing import Any

from wb_common import WorldBuilderError, atomic_write_json, load_build_state, load_json, preflight_report, requirement_rows, resolve_state_path, step_driver_pointer
from discovery_gate import validate_discovery, validate_runtime_receipt



def classify_failure(message: str) -> str:
    text = str(message or "").casefold()
    if any(token in text for token in ("no such file", "file not found", "assignment not found", "worker-kit", "path access", "permission denied")):
        return "path_access"
    if any(token in text for token in ("schema", "contract mismatch", "assignment_version", "result_version", "hash mismatch")):
        return "contract_mismatch"
    if any(token in text for token in ("timed out", "timeout", "connection", "network", "dns", "http ", "fandom", "searxng")):
        return "network_transport"
    if any(token in text for token in ("json", "decode", "delimiter", "empty output", "candidate")):
        return "output_format"
    return "unknown"

def parse_time(value: Any) -> datetime | None:
    if not isinstance(value, str):
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--build-state", required=True)
    parser.add_argument("--wave", type=int)
    parser.add_argument("--max-terminal-failure-ratio", type=float, default=0.20)
    parser.add_argument("--requirements", action="store_true", help="Read-only preflight: print what this gate checks against the current build state.")
    args = parser.parse_args()
    if args.requirements:
        root, state = load_build_state(args.build_state)
        print(json.dumps(preflight_report("discovery_wave_gate", requirement_rows(Path(__file__), root, state)), ensure_ascii=False, indent=2))
        return 0
    if args.wave is None:
        parser.error("--wave is required")
    try:
        root, state = load_build_state(args.build_state)
        plan_path = resolve_state_path(root, state, "discovery_plan")
        plan = load_json(plan_path)
        if not isinstance(plan, dict) or plan.get("kind") != "breadth-discovery-plan":
            raise WorldBuilderError(
                f"{plan_path.name} is not a valid discovery plan (expected kind 'breadth-discovery-plan', "
                f"found {plan.get('kind') if isinstance(plan, dict) else type(plan).__name__!r}). "
                "Regenerate it with discovery_plan.py before running this gate."
            )
        waves = plan.get("dispatch_waves")
        if not isinstance(waves, list):
            raise WorldBuilderError(
                f"{plan_path.name} has no staged dispatch_waves list; this gate only applies to a plan "
                "staged for the 4 -> 10 -> 20 wave ramp. Re-run discovery_plan.py with wave staging enabled, "
                "or skip this gate if this build's discovery is not wave-staged at all."
            )
        wave = next((row for row in waves if isinstance(row, dict) and row.get("wave") == args.wave), None)
        if not isinstance(wave, dict):
            valid_waves = sorted(row.get("wave") for row in waves if isinstance(row, dict) and row.get("wave") is not None)
            raise WorldBuilderError(f"wave {args.wave} does not exist in this plan; valid wave numbers are {valid_waves}")
        if wave.get("status") not in {"unlocked", "running", "complete"}:
            raise WorldBuilderError(
                f"wave {args.wave} is still locked (status={wave.get('status')!r}). Waves unlock sequentially: "
                f"run this same gate on wave {args.wave - 1} first; it unlocks wave {args.wave} on success."
            )
        assignment_rows = [row for row in plan.get("assignments", []) if isinstance(row, dict) and row.get("dispatch_wave") == args.wave]
        if not assignment_rows:
            raise WorldBuilderError(
                f"wave {args.wave} has no assignments in {plan_path.name}'s own assignments list; check "
                f"whether any assignment's dispatch_wave field was actually set to {args.wave}, or whether "
                "this wave number was intended at all."
            )

        total_owned = 0
        total_failed = 0
        total_delegated = 0
        runtimes: list[float] = []
        methods: dict[str, int] = {}
        details: list[dict[str, Any]] = []
        for row in assignment_rows:
            assignment_path = (root / str(row["path"])).resolve()
            assignment = load_json(assignment_path)
            result_path = (root / str(assignment["output"])).resolve()
            validated = validate_discovery(result_path, assignment_path, assignment, state["build_id"], plan["corpus_sha256"])
            runtime_path = (root / str(assignment["runtime_receipt"])).resolve()
            runtime = validate_runtime_receipt(runtime_path, assignment=assignment, assignment_path=assignment_path, result_path=result_path)
            owned = len(validated["assigned"])
            failed = len(validated["failed"])
            delegated = len(validated["delegated"])
            total_owned += owned
            total_failed += failed
            total_delegated += delegated
            started = parse_time(runtime.get("spawned_at"))
            completed = parse_time(runtime.get("completed_at"))
            if started and completed:
                runtimes.append(max(0.0, (completed - started).total_seconds()))
            data = validated["data"]
            fetch_records = data.get("fetch_records") if isinstance(data.get("fetch_records"), list) else []
            for record in fetch_records:
                if isinstance(record, dict) and isinstance(record.get("method"), str):
                    methods[record["method"]] = methods.get(record["method"], 0) + 1
            details.append({"assignment_id": assignment["assignment_id"], "worker": assignment["worker"], "owned": owned, "failed": failed, "delegated": delegated})

        terminal_ratio = (total_failed + total_delegated) / max(1, total_owned)
        if terminal_ratio > max(0.0, args.max_terminal_failure_ratio):
            raise WorldBuilderError(
                f"wave {args.wave} terminal failure/delegation ratio {terminal_ratio:.3f} exceeds {args.max_terminal_failure_ratio:.3f}; recover or repair transport before ramping"
            )
        if methods and not any(name.startswith("mediawiki_") for name in methods):
            raise WorldBuilderError("wave completed without proving a MediaWiki API transport; inspect Cloudflare/page-fetch behavior before ramping")

        wave["status"] = "complete"
        wave["health"] = {
            "owned_urls": total_owned,
            "failed_urls": total_failed,
            "delegated_urls": total_delegated,
            "terminal_failure_ratio": terminal_ratio,
            "fetch_methods": methods,
            "median_runtime_seconds": statistics.median(runtimes) if runtimes else None,
            "assignments": details,
        }
        next_wave = next((row for row in waves if isinstance(row, dict) and row.get("wave") == args.wave + 1), None)
        if isinstance(next_wave, dict):
            next_wave["status"] = "unlocked"
            next_wave["unlocked_by_wave"] = args.wave
        atomic_write_json(plan_path, plan)
        state.setdefault("discovery", {})["active_wave"] = args.wave + 1 if isinstance(next_wave, dict) else None
        state["discovery"]["last_completed_wave"] = args.wave
        atomic_write_json(Path(args.build_state).resolve(), state)
        print(json.dumps({"status": "passed", "wave": args.wave, "next_wave": next_wave.get("wave") if isinstance(next_wave, dict) else None, "health": wave["health"]}, indent=2))
        return 0
    except (WorldBuilderError, OSError, KeyError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        print(step_driver_pointer(), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
