#!/usr/bin/env python3
"""Shared source/canon semantics for evidence conflict handling.

The deterministic gate does not attempt to infer semantic contradiction from
freeform prose. Workers already classify required topics as supported,
conflicted, not_found, or not_applicable. A declared conflicted topic is the
stable signal used here to materialize a structured conflict and, when a
manifest canon-precedence policy can distinguish the cited source types, to
resolve it deterministically.
"""
from __future__ import annotations

import re
from typing import Any

from wb_common import WorldBuilderError

CONFLICT_KIND = "canon_claim_conflict"
SOURCE_QUALITY_CONTRACT = "worldbuilder-source-quality-v1"
CONFIDENCE_VALUES = {"high": 1.0, "medium": 0.65, "low": 0.35}


def normalize_source_type(value: Any) -> str:
    return re.sub(r"\s+", "_", str(value or "").strip().casefold().replace("-", "_"))


def validate_canon_precedence(value: Any) -> list[str]:
    if value in (None, []):
        return []
    if not isinstance(value, list):
        raise WorldBuilderError(
            f"manifest architecture.canon_precedence must be a list of source-type names, found {type(value).__name__}"
        )
    result: list[str] = []
    seen: set[str] = set()
    for index, item in enumerate(value):
        if not isinstance(item, str) or not item.strip():
            raise WorldBuilderError(
                f"manifest architecture.canon_precedence[{index}] must be a non-empty string, found {item!r}"
            )
        normalized = normalize_source_type(item)
        if normalized in seen:
            raise WorldBuilderError(
                f"manifest architecture.canon_precedence repeats source type {item!r}; each tier must appear once"
            )
        seen.add(normalized)
        result.append(normalized)
    return result




def validate_source_type_weights(value: Any) -> dict[str, float]:
    """Validate optional per-source-type trust multipliers without inventing defaults."""
    if value in (None, {}):
        return {}
    if not isinstance(value, dict):
        raise WorldBuilderError(
            f"manifest architecture.source_type_weights must be an object mapping source types to numbers from 0 to 1, found {type(value).__name__}"
        )
    result: dict[str, float] = {}
    for raw_name, raw_weight in value.items():
        if not isinstance(raw_name, str) or not raw_name.strip():
            raise WorldBuilderError(
                f"manifest architecture.source_type_weights keys must be non-empty strings, found {raw_name!r}"
            )
        name = normalize_source_type(raw_name)
        if name in result:
            raise WorldBuilderError(
                f"manifest architecture.source_type_weights repeats normalized source type {name!r}"
            )
        if isinstance(raw_weight, bool) or not isinstance(raw_weight, (int, float)):
            raise WorldBuilderError(
                f"manifest architecture.source_type_weights[{raw_name!r}] must be numeric from 0 to 1, found {raw_weight!r}"
            )
        weight = float(raw_weight)
        if not 0.0 <= weight <= 1.0:
            raise WorldBuilderError(
                f"manifest architecture.source_type_weights[{raw_name!r}] must be between 0 and 1 inclusive, found {raw_weight!r}"
            )
        result[name] = weight
    return result


def _canon_rank_map(
    canon_precedence: list[str] | None,
    source_type_weights: dict[str, float] | None,
) -> dict[str, int]:
    explicit = validate_canon_precedence(canon_precedence)
    if explicit:
        return {source_type: index for index, source_type in enumerate(explicit)}
    weights = validate_source_type_weights(source_type_weights)
    if not weights:
        return {}
    distinct = sorted(set(weights.values()), reverse=True)
    weight_rank = {weight: index for index, weight in enumerate(distinct)}
    return {source_type: weight_rank[weight] for source_type, weight in weights.items()}


def weighted_claim_confidence(
    claim: dict[str, Any],
    *,
    source_types: dict[str, str],
    source_type_weights: dict[str, float] | None,
) -> float:
    """Return the existing confidence label scaled by cited source-type trust.

    Unconfigured source types are neutral (1.0), preserving legacy behavior.
    """
    label = str(claim.get("confidence", "")).strip().casefold()
    if label not in CONFIDENCE_VALUES:
        raise WorldBuilderError(f"claim confidence {claim.get('confidence')!r} is not one of {sorted(CONFIDENCE_VALUES)}")
    weights = validate_source_type_weights(source_type_weights)
    if not weights:
        return CONFIDENCE_VALUES[label]
    cited_weights: list[float] = []
    for ref in claim.get("source_refs", []) if isinstance(claim.get("source_refs"), list) else []:
        source_type = normalize_source_type(source_types.get(str(ref)))
        cited_weights.append(weights.get(source_type, 1.0))
    multiplier = sum(cited_weights) / len(cited_weights) if cited_weights else 1.0
    return round(CONFIDENCE_VALUES[label] * multiplier, 4)


def _claim_source_tier(
    claim: dict[str, Any],
    *,
    source_types: dict[str, str],
    rank: dict[str, int],
) -> tuple[int, str] | None:
    candidates: list[tuple[int, str]] = []
    for ref in claim.get("source_refs", []) if isinstance(claim.get("source_refs"), list) else []:
        source_type = normalize_source_type(source_types.get(str(ref)))
        if source_type in rank:
            candidates.append((rank[source_type], source_type))
    if not candidates:
        return None
    return min(candidates, key=lambda row: (row[0], row[1]))


def derive_canon_conflicts(
    record: dict[str, Any],
    *,
    canon_precedence: list[str] | None = None,
    source_type_weights: dict[str, float] | None = None,
) -> list[dict[str, Any]]:
    """Derive structured conflicts from topics explicitly marked conflicted.

    The topic classification is semantic worker evidence; this function's job
    is deterministic structure and precedence resolution, not prose judgment.
    """
    rank = _canon_rank_map(canon_precedence, source_type_weights)

    sources = record.get("sources") if isinstance(record.get("sources"), list) else []
    source_types: dict[str, str] = {}
    for source in sources:
        if not isinstance(source, dict):
            continue
        source_id = source.get("source_id")
        if isinstance(source_id, str) and source_id.strip():
            source_types[source_id] = normalize_source_type(source.get("source_type"))

    claims = record.get("claims") if isinstance(record.get("claims"), list) else []
    claims_by_topic: dict[str, list[dict[str, Any]]] = {}
    display_topic: dict[str, str] = {}
    for claim in claims:
        if not isinstance(claim, dict):
            continue
        topic = claim.get("topic")
        if not isinstance(topic, str) or not topic.strip():
            continue
        key = topic.strip().casefold()
        claims_by_topic.setdefault(key, []).append(claim)
        display_topic.setdefault(key, topic.strip())

    conflicted_topics: list[str] = []
    for topic_record in record.get("topics", []) if isinstance(record.get("topics"), list) else []:
        if not isinstance(topic_record, dict) or topic_record.get("status") != "conflicted":
            continue
        topic = topic_record.get("topic")
        if isinstance(topic, str) and topic.strip():
            conflicted_topics.append(topic.strip().casefold())
            display_topic.setdefault(topic.strip().casefold(), topic.strip())

    derived: list[dict[str, Any]] = []
    for topic_key in sorted(set(conflicted_topics)):
        topic_claims = claims_by_topic.get(topic_key, [])
        if len(topic_claims) < 2:
            raise WorldBuilderError(
                f"evidence topic {display_topic.get(topic_key, topic_key)!r} is marked 'conflicted' but has fewer than two claims; a conflict needs competing claims"
            )
        claim_ids = [str(claim.get("claim_id")) for claim in topic_claims]
        resolution: str | None = None
        resolution_source: str | None = None
        ranked: list[tuple[int, str, str]] = []
        for claim in topic_claims:
            tier = _claim_source_tier(claim, source_types=source_types, rank=rank)
            if tier is not None:
                ranked.append((tier[0], str(claim.get("claim_id")), tier[1]))
        if ranked:
            best_rank = min(row[0] for row in ranked)
            winners = [row for row in ranked if row[0] == best_rank]
            if len(winners) == 1:
                resolution = winners[0][1]
                resolution_source = winners[0][2]
        derived.append({
            "kind": CONFLICT_KIND,
            "topic": display_topic.get(topic_key, topic_key),
            "claim_ids": claim_ids,
            "resolution": resolution,
            "resolution_source": resolution_source,
        })
    return derived


def merge_derived_conflicts(record: dict[str, Any], derived: list[dict[str, Any]]) -> bool:
    """Replace only prior deterministic canon-conflict rows; preserve others."""
    existing = record.get("conflicts", [])
    if not isinstance(existing, list):
        raise WorldBuilderError(
            f"evidence record's 'conflicts' must be a list, found {type(existing).__name__}"
        )
    preserved = [
        row for row in existing
        if not (isinstance(row, dict) and row.get("kind") == CONFLICT_KIND)
    ]
    merged = preserved + derived
    if merged == existing:
        return False
    record["conflicts"] = merged
    return True
