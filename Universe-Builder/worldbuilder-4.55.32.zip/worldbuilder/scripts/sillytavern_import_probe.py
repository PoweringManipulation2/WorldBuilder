#!/usr/bin/env python3
"""Probe SillyTavern 1.18.0 character-book and World Info JSON imports.

This deterministic probe mirrors the release branch's ``convertCharacterBook``
field mapping and the native World Info import boundary.  It is intentionally
stricter than the server's minimal ``entries`` check so WorldBuilder can catch
settings that SillyTavern would preserve as inert JSON, default, or silently
ignore at runtime.
"""
from __future__ import annotations

import argparse
import copy
import json
import re
import sys
import zipfile
from pathlib import Path
from typing import Any, Iterable

from wb_common import WorldBuilderError, canonical_entry_identity, iter_entries, load_json_strict

CONTRACT = "sillytavern-world-info-import-1.18.0"
SOURCE_CONTRACT = "SillyTavern/release@1.18.0:public/scripts/world-info.js#convertCharacterBook"
WORLD_INFO_IMPORT_CONTRACT = "SillyTavern/release@1.18.0:src/endpoints/worldinfo.js#/import"

WORLD_INFO_LOGIC = {
    0: "AND_ANY",
    1: "NOT_ALL",
    2: "NOT_ANY",
    3: "AND_ALL",
}

# Exact application-extension spellings read by convertCharacterBook.
EMBEDDED_EXTENSION_MAP: dict[str, str] = {
    "position": "position",
    "excludeRecursion": "exclude_recursion",
    "preventRecursion": "prevent_recursion",
    "delayUntilRecursion": "delay_until_recursion",
    "displayIndex": "display_index",
    "probability": "probability",
    "useProbability": "useProbability",
    "depth": "depth",
    "selectiveLogic": "selectiveLogic",
    "outletName": "outlet_name",
    "group": "group",
    "groupOverride": "group_override",
    "groupWeight": "group_weight",
    "scanDepth": "scan_depth",
    "caseSensitive": "case_sensitive",
    "matchWholeWords": "match_whole_words",
    "useGroupScoring": "use_group_scoring",
    "automationId": "automation_id",
    "role": "role",
    "vectorized": "vectorized",
    "sticky": "sticky",
    "cooldown": "cooldown",
    "delay": "delay",
    "matchPersonaDescription": "match_persona_description",
    "matchCharacterDescription": "match_character_description",
    "matchCharacterPersonality": "match_character_personality",
    "matchCharacterDepthPrompt": "match_character_depth_prompt",
    "matchScenario": "match_scenario",
    "matchCreatorNotes": "match_creator_notes",
    "triggers": "triggers",
    "ignoreBudget": "ignore_budget",
}

# Similar-looking fields that are not read from an embedded CCv3 entry.
EMBEDDED_NEAR_MISSES = {
    "use_probability": "useProbability",
    "selective_logic": "selectiveLogic",
    "excludeRecursion": "exclude_recursion",
    "preventRecursion": "prevent_recursion",
    "delayUntilRecursion": "delay_until_recursion",
    "displayIndex": "display_index",
    "outletName": "outlet_name",
    "groupOverride": "group_override",
    "groupWeight": "group_weight",
    "scanDepth": "scan_depth",
    "caseSensitive": "case_sensitive",
    "matchWholeWords": "match_whole_words",
    "useGroupScoring": "use_group_scoring",
    "automationId": "automation_id",
    "ignoreBudget": "ignore_budget",
    "characterFilter": "no embedded mapping; use native World Info",
}

DEFAULT_NATIVE_ENTRY: dict[str, Any] = {
    "key": [],
    "keysecondary": [],
    "comment": "",
    "content": "",
    "constant": False,
    "vectorized": False,
    "selective": True,
    "selectiveLogic": 0,
    "addMemo": False,
    "order": 100,
    "position": 0,
    "disable": False,
    "ignoreBudget": False,
    "excludeRecursion": False,
    "preventRecursion": False,
    "matchPersonaDescription": False,
    "matchCharacterDescription": False,
    "matchCharacterPersonality": False,
    "matchCharacterDepthPrompt": False,
    "matchScenario": False,
    "matchCreatorNotes": False,
    "delayUntilRecursion": 0,
    "probability": 100,
    "useProbability": True,
    "depth": 4,
    "outletName": "",
    "group": "",
    "groupOverride": False,
    "groupWeight": 100,
    "scanDepth": None,
    "caseSensitive": None,
    "matchWholeWords": None,
    "useGroupScoring": None,
    "automationId": "",
    "role": 0,
    "sticky": None,
    "cooldown": None,
    "delay": None,
    "triggers": [],
}

NATIVE_BOOLEAN_FIELDS = {
    "constant", "vectorized", "selective", "addMemo", "disable", "ignoreBudget",
    "excludeRecursion", "preventRecursion", "useProbability", "groupOverride",
    "matchPersonaDescription", "matchCharacterDescription", "matchCharacterPersonality",
    "matchCharacterDepthPrompt", "matchScenario", "matchCreatorNotes",
}
NATIVE_NULLABLE_BOOLEAN_FIELDS = {"caseSensitive", "matchWholeWords", "useGroupScoring"}
NATIVE_NUMBER_FIELDS = {
    "selectiveLogic", "order", "position", "probability", "displayIndex",
}
NATIVE_NULLABLE_NUMBER_FIELDS = {
    "depth", "groupWeight", "scanDepth", "sticky", "cooldown", "delay",
}
NATIVE_ROLE_FIELDS = {"role"}
NATIVE_STRING_FIELDS = {"comment", "content", "outletName", "group"}
NATIVE_NULLABLE_STRING_FIELDS = {"automationId"}
NATIVE_ARRAY_FIELDS = {"key", "keysecondary", "triggers"}

BOOK_LEVEL_CC_FIELDS = ("scan_depth", "token_budget", "recursive_scanning")
REGEX_LITERAL_RE = re.compile(r"^/([\s\S]+?)/([gimsuy]*)$")

RUNTIME_ENVELOPE_KEY = "worldbuilder_runtime"
DYNAMIC_ENVELOPE_KEY = "worldbuilder_dynamic"
RUNTIME_NEUTRAL_TO_EMBEDDED = {
    "position": "position",
    "selective_logic": "selectiveLogic",
    "case_sensitive": "case_sensitive",
    "vectorized": "vectorized",
    "exclude_recursion": "exclude_recursion",
    "prevent_recursion": "prevent_recursion",
    "delay_until_recursion": "delay_until_recursion",
    "display_index": "display_index",
    "depth": "depth",
    "role": "role",
    "scan_depth": "scan_depth",
    "match_whole_words": "match_whole_words",
    "ignore_budget": "ignore_budget",
}
DYNAMIC_MATCHING_TO_EMBEDDED = {
    "persona_description": "match_persona_description",
    "character_description": "match_character_description",
    "character_personality": "match_character_personality",
    "character_note": "match_character_depth_prompt",
    "scenario": "match_scenario",
    "creator_notes": "match_creator_notes",
}


def plan_conformance_check(artifact: dict[str, Any], manifest: dict[str, Any]) -> dict[str, Any]:
    """Batch 13, import-fidelity audit enhancement: beyond "would
    SillyTavern's importer accept this file," confirms no manifest entry
    silently went missing during merge/adapt/naming, and that no entry's
    delivered fields silently diverged from what planning actually decided
    for it.

    Deliberately reuses validate_output.py's existing validate_manifest
    (already-correct, already exercised by this exact class of real-world
    bug; the debug log this batch was built from shows it catching a
    real 50-name manifest mismatch) rather than re-deriving the same
    manifest-vs-delivered comparison independently a second time, which is
    exactly the class of maintenance risk that produced Batch 13's own
    four-separate-copies bug in runtime_target_adapter.py. This function
    is a translation layer onto that existing check's structured Issue
    context, not a new comparison.
    """
    from validate_output import manifest_entries, validate as validate_json

    report, _info = validate_json(artifact, profile="sillytavern", manifest=manifest)
    missing_uids: list[Any] = []
    extra_uids: list[Any] = []
    duplicate_uids: list[Any] = []
    field_mismatches: list[dict[str, Any]] = []
    for issue in report.issues:
        ctx = issue.context or {}
        if issue.code == "manifest-entry-missing":
            missing_uids.append(ctx.get("uid"))
        elif issue.code == "manifest-duplicate-identity":
            duplicate_uids.append(ctx.get("uid"))
        elif issue.code in {"manifest-field-missing", "manifest-mismatch"}:
            field_mismatches.append({
                "uid": ctx.get("uid"), "field": ctx.get("field"),
                "delivered": ctx.get("delivered"), "planned": ctx.get("planned"),
            })
    # "Extra" (delivered but not in the manifest at all) is not something
    # validate_manifest itself reports; it only walks the manifest's own
    # entries, by construction, since an extra delivered entry isn't a
    # manifest violation in the same sense a missing one is. Computed here
    # directly, reusing the same identity machinery validate_manifest uses
    # internally, so both sides of the comparison stay consistent.
    manifest_uids = {identity for identity, _p, _e in manifest_entries(manifest) if identity is not None}
    delivered_uids: set[Any] = set()
    for ref in iter_entries(artifact):
        try:
            identity = canonical_entry_identity(ref.entry)
        except WorldBuilderError:
            continue
        if identity is not None:
            delivered_uids.add(identity)
    extra_uids = sorted(delivered_uids - manifest_uids, key=str)
    return {
        "kind": "worldbuilder-plan-conformance",
        "contract": CONTRACT,
        "manifest_entry_count": len(manifest_uids),
        "delivered_entry_count": len(delivered_uids),
        "missing_uids": sorted((u for u in missing_uids if u is not None), key=str),
        "extra_uids": extra_uids,
        "duplicate_uids": sorted((u for u in duplicate_uids if u is not None), key=str),
        "field_mismatches": field_mismatches,
        "conformant": not missing_uids and not extra_uids and not duplicate_uids and not field_mismatches,
    }


def _type_ok(value: Any, expected: type | tuple[type, ...]) -> bool:
    if isinstance(value, bool):
        expected_types = expected if isinstance(expected, tuple) else (expected,)
        if int in expected_types or float in expected_types:
            return bool in expected_types
    return isinstance(value, expected)


def _require(value: Any, expected: type | tuple[type, ...], path: str) -> None:
    if not _type_ok(value, expected):
        raise WorldBuilderError(f"{path} has the wrong type")


def _string_array(value: Any, path: str) -> list[str]:
    _require(value, list, path)
    if any(not isinstance(item, str) for item in value):
        raise WorldBuilderError(f"{path} must contain only strings")
    return list(value)


def _nullish(source: dict[str, Any], key: str, default: Any) -> Any:
    value = source.get(key)
    return copy.deepcopy(default if value is None else value)


def _activation_mode(entry: dict[str, Any]) -> str:
    if bool(entry.get("constant", False)):
        return "constant"
    if bool(entry.get("vectorized", False)):
        return "vectorized"
    return "keyword"


def _valid_st_regex_literal(value: str) -> bool:
    match = REGEX_LITERAL_RE.fullmatch(value)
    if not match:
        return False
    pattern = match.group(1)
    # SillyTavern rejects an unescaped slash inside the pattern.
    escaped = False
    for char in pattern:
        if char == "/" and not escaped:
            return False
        if char == "\\":
            escaped = not escaped
        else:
            escaped = False
    return True


def _book_setting_warnings(book: dict[str, Any], location: str) -> list[str]:
    warnings: list[str] = []
    for key in BOOK_LEVEL_CC_FIELDS:
        if key in book:
            warnings.append(
                f"{location}.{key} is portable lorebook metadata; SillyTavern 1.18.0 uses global "
                f"World Info settings and does not apply this value per imported book"
            )
    return warnings


def _neutral_envelope_losses(ext: dict[str, Any], content: str = "") -> list[str]:
    from decorators import parse_leading_decorators, has_decorator

    found_decorators, _remaining = parse_leading_decorators(content)
    """Report neutral WorldBuilder semantics that lack an active ST mirror.

    Portable WorldBuilder envelopes are useful for round-tripping, but
    SillyTavern does not execute them.  This check distinguishes a harmless
    recovery copy from a setting that would silently default after import.
    """
    losses: list[str] = []
    runtime = ext.get(RUNTIME_ENVELOPE_KEY)
    if runtime is not None:
        if not isinstance(runtime, dict) or not isinstance(runtime.get("fields"), dict):
            losses.append(f"extensions.{RUNTIME_ENVELOPE_KEY} is malformed and is not executable")
        else:
            for semantic, value in runtime["fields"].items():
                target = RUNTIME_NEUTRAL_TO_EMBEDDED.get(semantic)
                if target is None:
                    losses.append(
                        f"extensions.{RUNTIME_ENVELOPE_KEY}.fields.{semantic} has no SillyTavern mapping"
                    )
                elif target not in ext or ext.get(target) != value:
                    if has_decorator(found_decorators, semantic):
                        losses.append(
                            f"extensions.{target} is absent because {semantic} is expressed as a "
                            f"@@{semantic} decorator instead (Batch 9's single-owner rule for the "
                            f"portable path); SillyTavern's convertCharacterBook does not parse "
                            f"decorators, so this semantic will not be applied on direct import"
                        )
                    else:
                        losses.append(
                            f"extensions.{RUNTIME_ENVELOPE_KEY}.fields.{semantic} is recovery metadata only; "
                            f"mirror it as extensions.{target} for active SillyTavern behavior"
                        )

    dynamic = ext.get(DYNAMIC_ENVELOPE_KEY)
    if dynamic is None:
        return losses
    if not isinstance(dynamic, dict):
        losses.append(f"extensions.{DYNAMIC_ENVELOPE_KEY} is malformed and is not executable")
        return losses

    probability = dynamic.get("probability", 100)
    probability_enabled = dynamic.get("probability_enabled", probability != 100)
    if "probability" in dynamic or "probability_enabled" in dynamic:
        if ext.get("probability") != probability:
            losses.append(
                f"extensions.{DYNAMIC_ENVELOPE_KEY}.probability is recovery metadata only; "
                "mirror it as extensions.probability"
            )
        if ext.get("useProbability") != probability_enabled:
            losses.append(
                f"extensions.{DYNAMIC_ENVELOPE_KEY}.probability_enabled is recovery metadata only; "
                "mirror it as extensions.useProbability"
            )

    groups = dynamic.get("groups", [])
    if isinstance(groups, list) and groups:
        expected_group = ", ".join(str(row.get("group_id")) for row in groups if isinstance(row, dict))
        if ext.get("group") != expected_group:
            losses.append(
                f"extensions.{DYNAMIC_ENVELOPE_KEY}.groups is recovery metadata only; mirror group names "
                "as extensions.group"
            )
        if "group_override" not in ext:
            losses.append("dynamic group selection is missing active extensions.group_override")
        if "group_weight" not in ext:
            losses.append("dynamic group weight is missing active extensions.group_weight")
        if "use_group_scoring" not in ext:
            losses.append("dynamic group scoring is missing active extensions.use_group_scoring")

    timed = dynamic.get("timed_effects", {})
    if isinstance(timed, dict):
        for field in ("sticky", "cooldown", "delay"):
            if field in timed and ext.get(field) != timed[field]:
                if field == "delay" and has_decorator(found_decorators, "activate_only_after"):
                    losses.append(
                        f"extensions.{field} is absent because delay is expressed as a "
                        f"@@activate_only_after decorator instead (Batch 9's single-owner rule for the "
                        f"portable path); SillyTavern's convertCharacterBook does not parse "
                        f"decorators, so this semantic will not be applied on direct import"
                    )
                else:
                    losses.append(
                        f"extensions.{DYNAMIC_ENVELOPE_KEY}.timed_effects.{field} is recovery metadata only; "
                        f"mirror it as extensions.{field}"
                    )

    matching = dynamic.get("matching_sources", [])
    if isinstance(matching, list):
        for semantic, target in DYNAMIC_MATCHING_TO_EMBEDDED.items():
            if semantic in matching and ext.get(target) is not True:
                losses.append(
                    f"dynamic matching source {semantic!r} is missing active extensions.{target}"
                )

    triggers = dynamic.get("generation_triggers", [])
    if isinstance(triggers, list) and triggers and ext.get("triggers") != triggers:
        losses.append("dynamic generation triggers are missing active extensions.triggers")
    if dynamic.get("automation_id") and ext.get("automation_id") != dynamic.get("automation_id"):
        losses.append("dynamic automation_id is missing active extensions.automation_id")
    if dynamic.get("named_outlet") and ext.get("outlet_name") != dynamic.get("named_outlet"):
        losses.append("dynamic named_outlet is missing active extensions.outlet_name")
    if dynamic.get("character_filter"):
        losses.append(
            "dynamic character_filter cannot be activated by embedded character-book import; "
            "export native World Info instead"
        )
    if dynamic.get("greeting_variants"):
        losses.append("dynamic greeting_variants have no tested SillyTavern World Info field")
    return losses


def _validate_embedded_entry(entry: Any, index: int) -> tuple[dict[str, Any], list[str]]:
    path = f"data.character_book.entries[{index}]"
    if not isinstance(entry, dict):
        raise WorldBuilderError(f"{path} must be an object")
    for key, expected in {
        "keys": list,
        "content": str,
        "enabled": bool,
        "insertion_order": int,
        "use_regex": bool,
        "constant": bool,
        "selective": bool,
    }.items():
        if key not in entry:
            raise WorldBuilderError(f"{path}.{key} is required")
        _require(entry[key], expected, f"{path}.{key}")
    keys = _string_array(entry["keys"], f"{path}.keys")
    secondary = _string_array(entry.get("secondary_keys", []), f"{path}.secondary_keys")
    if "comment" in entry:
        _require(entry["comment"], str, f"{path}.comment")
    if "position" in entry and entry["position"] not in {"before_char", "after_char"}:
        raise WorldBuilderError(f"{path}.position must be before_char or after_char")
    ext = entry.get("extensions", {})
    _require(ext, dict, f"{path}.extensions")

    ignored: list[str] = []
    for wrong, correct in EMBEDDED_NEAR_MISSES.items():
        if wrong in ext and wrong not in EMBEDDED_EXTENSION_MAP.values():
            ignored.append(f"extensions.{wrong} is not read; expected {correct}")
    if "character_filter" in ext:
        ignored.append(
            "extensions.character_filter is retained in originalData/extensions but convertCharacterBook "
            "does not create active native characterFilter data"
        )
    if entry.get("use_regex") is True:
        if not keys or not all(_valid_st_regex_literal(key) for key in keys):
            ignored.append(
                "use_regex is ignored; non-delimited patterns become ordinary keyword strings in SillyTavern"
            )
    if "case_sensitive" in entry and "case_sensitive" not in ext:
        ignored.append("top-level case_sensitive is ignored unless mirrored as extensions.case_sensitive")
    if "priority" in entry:
        ignored.append("top-level priority is preserved in originalData but has no active SillyTavern World Info field")
    ignored.extend(_neutral_envelope_losses(ext, str(entry.get("content", ""))))

    return {
        "entry": entry,
        "keys": keys,
        "secondary": secondary,
        "extensions": ext,
        "path": path,
    }, ignored


def convert_character_book(character_book: Any) -> tuple[dict[str, Any], list[dict[str, Any]], list[str]]:
    """Mirror SillyTavern 1.18.0 ``convertCharacterBook`` without mutating input."""
    if not isinstance(character_book, dict):
        raise WorldBuilderError("data.character_book must be an object")
    entries = character_book.get("entries")
    if not isinstance(entries, list):
        raise WorldBuilderError("data.character_book.entries must be an array")

    converted: dict[str, Any] = {"entries": {}, "originalData": copy.deepcopy(character_book)}
    summaries: list[dict[str, Any]] = []
    warnings = _book_setting_warnings(character_book, "data.character_book")

    for index, raw in enumerate(entries):
        checked, ignored = _validate_embedded_entry(raw, index)
        entry = checked["entry"]
        ext = checked["extensions"]
        identity = entry.get("id", index)
        if identity is None or isinstance(identity, bool) or not isinstance(identity, (str, int)):
            raise WorldBuilderError(f"{checked['path']}.id must be a string or integer when present")

        native = copy.deepcopy(DEFAULT_NATIVE_ENTRY)
        native.update({
            "uid": identity,
            "key": checked["keys"],
            "keysecondary": checked["secondary"],
            "comment": entry.get("comment") or "",
            "content": entry["content"],
            "constant": entry.get("constant") or False,
            "selective": entry.get("selective") or False,
            "order": entry["insertion_order"],
            "position": _nullish(ext, "position", 0 if entry.get("position") == "before_char" else 1),
            "excludeRecursion": _nullish(ext, "exclude_recursion", False),
            "preventRecursion": _nullish(ext, "prevent_recursion", False),
            "delayUntilRecursion": _nullish(ext, "delay_until_recursion", False),
            "disable": not entry["enabled"],
            "addMemo": bool(entry.get("comment")),
            "displayIndex": _nullish(ext, "display_index", index),
            "probability": _nullish(ext, "probability", 100),
            "useProbability": _nullish(ext, "useProbability", True),
            "depth": _nullish(ext, "depth", 4),
            "selectiveLogic": _nullish(ext, "selectiveLogic", 0),
            "outletName": _nullish(ext, "outlet_name", ""),
            "group": _nullish(ext, "group", ""),
            "groupOverride": _nullish(ext, "group_override", False),
            "groupWeight": _nullish(ext, "group_weight", 100),
            "scanDepth": _nullish(ext, "scan_depth", None),
            "caseSensitive": _nullish(ext, "case_sensitive", None),
            "matchWholeWords": _nullish(ext, "match_whole_words", None),
            "useGroupScoring": _nullish(ext, "use_group_scoring", None),
            "automationId": _nullish(ext, "automation_id", ""),
            "role": _nullish(ext, "role", 0),
            "vectorized": _nullish(ext, "vectorized", False),
            "sticky": _nullish(ext, "sticky", None),
            "cooldown": _nullish(ext, "cooldown", None),
            "delay": _nullish(ext, "delay", None),
            "matchPersonaDescription": _nullish(ext, "match_persona_description", False),
            "matchCharacterDescription": _nullish(ext, "match_character_description", False),
            "matchCharacterPersonality": _nullish(ext, "match_character_personality", False),
            "matchCharacterDepthPrompt": _nullish(ext, "match_character_depth_prompt", False),
            "matchScenario": _nullish(ext, "match_scenario", False),
            "matchCreatorNotes": _nullish(ext, "match_creator_notes", False),
            "extensions": copy.deepcopy(ext),
            "triggers": copy.deepcopy(ext.get("triggers") or []),
            "ignoreBudget": _nullish(ext, "ignore_budget", False),
        })
        if native["selectiveLogic"] not in WORLD_INFO_LOGIC:
            raise WorldBuilderError(f"{checked['path']}.extensions.selectiveLogic must be 0, 1, 2, or 3")
        if not isinstance(native["triggers"], list) or any(not isinstance(value, str) for value in native["triggers"]):
            raise WorldBuilderError(f"{checked['path']}.extensions.triggers must be an array of strings")
        # addMissingWorldInfoFields creates an empty active filter because the
        # embedded converter itself does not map extensions.character_filter.
        native["characterFilter"] = {"isExclude": False, "names": [], "tags": []}
        converted["entries"][str(identity)] = native
        summaries.append(_summarize_native_entry(native, ignored=ignored, source_index=index))
    return converted, summaries, warnings


def _validate_native_entry(entry: Any, identity: str) -> dict[str, Any]:
    path = f"entries[{identity!r}]"
    if not isinstance(entry, dict):
        raise WorldBuilderError(f"{path} must be an object")
    out = copy.deepcopy(DEFAULT_NATIVE_ENTRY)
    out.update(copy.deepcopy(entry))
    out.setdefault("uid", identity)
    for field in NATIVE_BOOLEAN_FIELDS:
        if field in out:
            _require(out[field], bool, f"{path}.{field}")
    for field in NATIVE_NULLABLE_BOOLEAN_FIELDS:
        if out.get(field) is not None:
            _require(out[field], bool, f"{path}.{field}")
    for field in NATIVE_NUMBER_FIELDS:
        if field in out:
            _require(out[field], (int, float), f"{path}.{field}")
    for field in NATIVE_NULLABLE_NUMBER_FIELDS:
        if out.get(field) is not None:
            _require(out[field], (int, float), f"{path}.{field}")
    for field in NATIVE_ROLE_FIELDS:
        if out.get(field) is not None:
            _require(out[field], (int, str), f"{path}.{field}")
    delay_until = out.get("delayUntilRecursion")
    if delay_until is not None and not isinstance(delay_until, (bool, int, float)):
        raise WorldBuilderError(f"{path}.delayUntilRecursion must be boolean or numeric")
    for field in NATIVE_STRING_FIELDS:
        if field in out:
            _require(out[field], str, f"{path}.{field}")
    for field in NATIVE_NULLABLE_STRING_FIELDS:
        if out.get(field) is not None:
            _require(out[field], str, f"{path}.{field}")
    for field in NATIVE_ARRAY_FIELDS:
        _string_array(out.get(field, []), f"{path}.{field}")
    if out.get("selectiveLogic") not in WORLD_INFO_LOGIC:
        raise WorldBuilderError(f"{path}.selectiveLogic must be 0, 1, 2, or 3")
    filt = out.get("characterFilter")
    if filt is None:
        filt = {"isExclude": False, "names": [], "tags": []}
        out["characterFilter"] = filt
    if not isinstance(filt, dict):
        raise WorldBuilderError(f"{path}.characterFilter must be an object")
    _require(filt.get("isExclude", False), bool, f"{path}.characterFilter.isExclude")
    _string_array(filt.get("names", []), f"{path}.characterFilter.names")
    _string_array(filt.get("tags", []), f"{path}.characterFilter.tags")
    if "extensions" in out:
        _require(out["extensions"], dict, f"{path}.extensions")
    return out


def _summarize_native_entry(entry: dict[str, Any], *, ignored: Iterable[str] = (), source_index: int | None = None) -> dict[str, Any]:
    logic = int(entry.get("selectiveLogic", 0))
    filt = entry.get("characterFilter") if isinstance(entry.get("characterFilter"), dict) else {}
    summary = {
        "id": entry.get("uid"),
        "uid": entry.get("uid"),
        "comment": entry.get("comment", ""),
        "constant": bool(entry.get("constant", False)),
        "vectorized": bool(entry.get("vectorized", False)),
        "activation_mode": _activation_mode(entry),
        "primary_key_count": len(entry.get("key", [])) if isinstance(entry.get("key"), list) else 0,
        "secondary_key_count": len(entry.get("keysecondary", [])) if isinstance(entry.get("keysecondary"), list) else 0,
        "selective": bool(entry.get("selective", False)),
        "selective_logic": logic,
        "selective_logic_name": WORLD_INFO_LOGIC.get(logic, "UNKNOWN"),
        "scan_depth": entry.get("scanDepth"),
        "position": entry.get("position"),
        "depth": entry.get("depth"),
        "role": entry.get("role"),
        "probability": entry.get("probability"),
        "use_probability": entry.get("useProbability"),
        "exclude_recursion": entry.get("excludeRecursion"),
        "prevent_recursion": entry.get("preventRecursion"),
        "delay_until_recursion": entry.get("delayUntilRecursion"),
        "group": entry.get("group"),
        "group_override": entry.get("groupOverride"),
        "group_weight": entry.get("groupWeight"),
        "use_group_scoring": entry.get("useGroupScoring"),
        "ignore_budget": entry.get("ignoreBudget"),
        "character_filter_active": bool(filt.get("isExclude") or filt.get("names") or filt.get("tags")),
        "ignored_or_inactive": list(ignored),
        "native_entry": copy.deepcopy(entry),
    }
    if source_index is not None:
        summary["source_index"] = source_index
    return summary


def _finish_counts(result: dict[str, Any]) -> dict[str, Any]:
    rows = result.get("entries", [])
    result["entry_count"] = len(rows)
    result["vectorized_count"] = sum(1 for row in rows if row.get("activation_mode") == "vectorized")
    result["keyword_only_count"] = sum(1 for row in rows if row.get("activation_mode") == "keyword")
    result["constant_count"] = sum(1 for row in rows if row.get("activation_mode") == "constant")
    result["ignored_setting_count"] = sum(len(row.get("ignored_or_inactive", [])) for row in rows)
    result["semantic_loss"] = result["ignored_setting_count"] > 0 or bool(result.get("warnings"))
    if result.get("status") == "passed" and result["semantic_loss"]:
        result["status"] = "warning"
    return result


def _probe_character_card(data: dict[str, Any]) -> dict[str, Any]:
    payload = data.get("data")
    if not isinstance(payload, dict):
        raise WorldBuilderError("character card data must be an object")
    result: dict[str, Any] = {
        "status": "passed",
        "contract": CONTRACT,
        "source_contract": SOURCE_CONTRACT,
        "import_route": "character-json",
        "direct_import_compatible": True,
        "spec": data.get("spec"),
        "spec_version": data.get("spec_version"),
        "embedded_lorebook": False,
        "entries": [],
        "warnings": [],
    }
    book = payload.get("character_book")
    if book is None:
        return _finish_counts(result)
    converted, summaries, warnings = convert_character_book(book)
    result["embedded_lorebook"] = True
    result["entries"] = summaries
    result["warnings"] = warnings
    result["converted_world_info"] = converted
    return _finish_counts(result)


def _probe_native_world_info(data: dict[str, Any]) -> dict[str, Any]:
    entries = data.get("entries")
    if not isinstance(entries, (dict, list)):
        raise WorldBuilderError("native World Info requires a top-level entries object")
    canonical = isinstance(entries, dict)
    rows: list[dict[str, Any]] = []
    iterator = entries.items() if isinstance(entries, dict) else enumerate(entries)
    for key, raw in iterator:
        native = _validate_native_entry(raw, str(key))
        rows.append(_summarize_native_entry(native))
    warnings = _book_setting_warnings(data, "world_info")
    if not canonical:
        warnings.append(
            "entries is an array: the server accepts it, but SillyTavern edits entries by UID-keyed object access; "
            "use an object keyed by uid for canonical native World Info"
        )
    result = {
        "status": "passed" if canonical else "warning",
        "contract": CONTRACT,
        "source_contract": WORLD_INFO_IMPORT_CONTRACT,
        "import_route": "world-info-json",
        "direct_import_compatible": True,
        "canonical_native_shape": canonical,
        "embedded_lorebook": False,
        "entries": rows,
        "warnings": warnings,
    }
    return _finish_counts(result)


def probe_artifact(data: Any) -> dict[str, Any]:
    if not isinstance(data, dict):
        raise WorldBuilderError("SillyTavern JSON import requires an object root")
    spec = data.get("spec")
    if spec in {"chara_card_v2", "chara_card_v3"}:
        return _probe_character_card(data)
    if spec == "lorebook_v3":
        return {
            "status": "blocked",
            "contract": CONTRACT,
            "source_contract": WORLD_INFO_IMPORT_CONTRACT,
            "import_route": "world-info-json",
            "direct_import_compatible": False,
            "embedded_lorebook": False,
            "entry_count": 0,
            "entries": [],
            "warnings": [],
            "semantic_loss": True,
            "reason": (
                "SillyTavern 1.18.0 direct World Info import requires top-level entries; "
                "the portable lorebook_v3 wrapper stores entries under data.entries"
            ),
        }
    if "entries" in data:
        return _probe_native_world_info(data)
    raise WorldBuilderError(
        "unsupported SillyTavern JSON shape: expected a character card or native World Info with top-level entries"
    )


def probe_file(path: str | Path) -> dict[str, Any]:
    target = Path(path).expanduser().resolve()
    if target.suffix.casefold() == ".charx":
        with zipfile.ZipFile(target, "r") as archive:
            try:
                raw = archive.read("card.json")
            except KeyError as exc:
                raise WorldBuilderError("CHARX lacks card.json") from exc
        if raw.startswith(b"\xef\xbb\xbf"):
            raise WorldBuilderError("CHARX card.json begins with a UTF-8 BOM")
        try:
            data = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise WorldBuilderError(f"CHARX card.json is not strict UTF-8 JSON: {exc}") from exc
        return probe_artifact(data)
    return probe_artifact(load_json_strict(target))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("path")
    parser.add_argument("--json-report")
    args = parser.parse_args()
    try:
        result = probe_file(args.path)
    except (OSError, zipfile.BadZipFile, WorldBuilderError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    text = json.dumps(result, ensure_ascii=False, indent=2)
    print(text)
    if args.json_report:
        Path(args.json_report).write_text(text + "\n", encoding="utf-8")
    return 0 if result.get("direct_import_compatible") is not False else 1


if __name__ == "__main__":
    raise SystemExit(main())
