#!/usr/bin/env python3
"""Freeze and validate WorldBuilder context budgets and pruning safeguards.

The contract is deliberately target-neutral. It prefers approved measured token
counts, then declared planning estimates, and otherwise falls back to
``ceil(UTF-8 bytes / 4)``. It validates the same frozen policy against generated
output without claiming tokenizer parity with any model or SillyTavern build.
"""
from __future__ import annotations

import argparse
import copy
import json
import math
import sys
from collections import defaultdict, deque
from pathlib import Path
from typing import Any, Iterable

from wb_common import (
    WorldBuilderError,
    atomic_write_json,
    canonical_entry_identity,
    iter_entries,
    load_build_state,
    load_json,
    preflight_report,
    requirement_rows,
    resolve_state_path,
    sha256_file,
)
from pruning_objectives import objective_plan_rows, validate_plan_rows as validate_pruning_objective_rows
from budget_semantics import (
    activation_closure as _closure,
    emit_config as _emit,
    entry_is_constant as _is_constant,
    entry_keys as _keys,
    manifest_rows as _manifest_rows,
    required_edges as _required_edges,
    uid_key,
)

CONTRACT = "worldbuilder-budget-pruning-v1"
PLAN_KIND = "worldbuilder-budget-plan"
PLAN_VERSION = 1
RECEIPT_KIND = "worldbuilder-budget-gate"
RECEIPT_VERSION = 1

PROFILE_ALIASES = {
    "quick": "compact",
    "compact": "compact",
    "recommended": "recommended",
    "default": "recommended",
    "full": "maximum_detail",
    "full-detail": "maximum_detail",
    "full_detail": "maximum_detail",
    "maximum": "maximum_detail",
    "maximum-detail": "maximum_detail",
    "maximum_detail": "maximum_detail",
}

# These are WorldBuilder planning profiles, not target-runtime guarantees.
BUDGET_PROFILES: dict[str, dict[str, Any]] = {
    "compact": {
        "label": "Compact",
        "lorebook_token_budget": 4096,
        "permanent_card_target": 550,
        "permanent_card_hard": 850,
        "constant_target": 650,
        "constant_hard": 1000,
        "entry_soft": 260,
        "entry_hard": 450,
        "direct_activation_target": 950,
        "direct_activation_hard": 1500,
        "recursive_activation_target": 1500,
        "recursive_activation_hard": 2300,
        "worst_case_target": 2100,
        "worst_case_hard": 3200,
        "simulation_depth": 2,
        "layer_allocations": {
            "world_core": 0.12, "world_invariants": 0.10, "era_context": 0.13,
            "character": 0.20, "relationship": 0.10, "location": 0.10,
            "faction": 0.08, "event": 0.08, "anchor": 0.04, "other": 0.05,
        },
    },
    "recommended": {
        "label": "Recommended",
        "lorebook_token_budget": 8192,
        "permanent_card_target": 850,
        "permanent_card_hard": 1300,
        "constant_target": 1050,
        "constant_hard": 1600,
        "entry_soft": 420,
        "entry_hard": 700,
        "direct_activation_target": 1700,
        "direct_activation_hard": 2600,
        "recursive_activation_target": 2900,
        "recursive_activation_hard": 4300,
        "worst_case_target": 4000,
        "worst_case_hard": 6000,
        "simulation_depth": 3,
        "layer_allocations": {
            "world_core": 0.11, "world_invariants": 0.09, "era_context": 0.12,
            "character": 0.22, "relationship": 0.11, "location": 0.10,
            "faction": 0.08, "event": 0.09, "anchor": 0.03, "other": 0.05,
        },
    },
    "maximum_detail": {
        "label": "Maximum Detail",
        "lorebook_token_budget": 16384,
        "permanent_card_target": 1250,
        "permanent_card_hard": 1900,
        "constant_target": 1700,
        "constant_hard": 2600,
        "entry_soft": 650,
        "entry_hard": 1050,
        "direct_activation_target": 3100,
        "direct_activation_hard": 4600,
        "recursive_activation_target": 5700,
        "recursive_activation_hard": 8200,
        "worst_case_target": 7600,
        "worst_case_hard": 11200,
        "simulation_depth": 4,
        "layer_allocations": {
            "world_core": 0.10, "world_invariants": 0.08, "era_context": 0.11,
            "character": 0.24, "relationship": 0.12, "location": 0.10,
            "faction": 0.08, "event": 0.10, "anchor": 0.02, "other": 0.05,
        },
    },
}

PROTECTED_CATEGORIES = {
    "world_invariants",
    "era_isolation",
    "knowledge_boundary",
    "status_change",
    "identity_state",
    "required_relationship",
    "required_activation_path",
}
PRUNE_FIRST = (
    "duplicate_facts",
    "repeated_aliases",
    "redundant_anchors",
    "broad_keywords",
    "low_value_edges",
    "repeated_invariant_prose",
)
SIMULATION_NAMES = (
    "major_character",
    "major_location",
    "faction",
    "era_keyword",
    "common_ambiguous_term",
    "relationship_cluster",
    "worst_case_recursion_path",
)

# Batch 5, DR "Context window and detail level are independent axes". Axis 1
# (context_window) sets the total; Axis 2 (detail/profile_id) sets distribution
# only. See derive_profile().
GENERATION_RESERVE_SHARE = 0.15  # ~15% per the plan; response headroom, not static content.
# Not specified by the plan: a documented default, not a first-principles number.
# "How much conversation should survive" as a share of the window; user-facing
# and overridable per build (settings-menu.md), same spirit as Batch 2's and
# Batch 3's similarly-flagged choices.
DEFAULT_HISTORY_RESERVE_SHARE = 0.30

# 5.4's shell-by-artifact-shape table, midpoint of each documented range. Used
# here only to size permanent_card_hard as a share of available_for_static;
# the full slot-priority cutting order (identity kernel never cut, etc.) is
# separate work, not yet built.
SHELL_SHARE_BY_ARTIFACT_TYPE = {
    ("card", False): 0.65,   # Schema 1 character, no book: everything, 60-70%
    ("card", True): 0.30,    # Schema 1 character + book: identity kernel + voice, 25-35%
    ("world", False): 0.125, # Schema 2 World: world identity + interaction contract, 10-15%
    ("world", True): 0.125,
    ("group", False): 0.25,  # Group member cards: per-character identity kernel, 20-30%
    ("group", True): 0.25,
    # Not in 5.4's table: a standalone lorebook carries no card-shell fields at
    # all (no description/personality/scenario/system_prompt), so its shell
    # share is a technical floor, not a real allocation.
    ("lorebook", False): 0.0,
    ("lorebook", True): 0.0,
}




def normalize_profile(value: str | None) -> str:
    key = str(value or "recommended").strip().casefold().replace(" ", "-")
    result = PROFILE_ALIASES.get(key)
    if result is None:
        raise WorldBuilderError("budget profile must be Compact, Recommended, or Maximum Detail")
    return result


def estimate_tokens(value: Any) -> int:
    """Return the deterministic planning estimate ceil(UTF-8 bytes / 4)."""
    if value is None:
        return 0
    if not isinstance(value, str):
        value = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return int(math.ceil(len(value.encode("utf-8")) / 4.0))


def _deep_merge(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    result = json.loads(json.dumps(base))
    for key, value in override.items():
        if isinstance(value, dict) and isinstance(result.get(key), dict):
            result[key] = _deep_merge(result[key], value)
        else:
            result[key] = value
    return result


def _validate_positive_ints(profile: dict[str, Any]) -> None:
    required = (
        "lorebook_token_budget", "permanent_card_target", "permanent_card_hard",
        "constant_target", "constant_hard", "entry_soft", "entry_hard",
        "direct_activation_target", "direct_activation_hard",
        "recursive_activation_target", "recursive_activation_hard",
        "worst_case_target", "worst_case_hard", "simulation_depth",
    )
    for key in required:
        value = profile.get(key)
        if not isinstance(value, int) or isinstance(value, bool) or value <= 0:
            raise WorldBuilderError(f"budget profile {key} must be a positive integer")
    for target, hard in (
        ("permanent_card_target", "permanent_card_hard"),
        ("constant_target", "constant_hard"),
        ("entry_soft", "entry_hard"),
        ("direct_activation_target", "direct_activation_hard"),
        ("recursive_activation_target", "recursive_activation_hard"),
        ("worst_case_target", "worst_case_hard"),
    ):
        if profile[target] > profile[hard]:
            raise WorldBuilderError(f"budget profile {target} cannot exceed {hard}")
    layers = profile.get("layer_allocations")
    if not isinstance(layers, dict) or not layers:
        raise WorldBuilderError("budget profile layer_allocations must be an object")
    total = 0.0
    for key, value in layers.items():
        if not isinstance(key, str) or not isinstance(value, (int, float)) or isinstance(value, bool) or value < 0:
            raise WorldBuilderError("budget layer allocations must be non-negative numbers")
        total += float(value)
    if abs(total - 1.0) > 0.001:
        raise WorldBuilderError("budget layer allocations must total 1.0")


def derive_profile(
    context_window: int,
    detail: str,
    artifact_type: str,
    has_embedded_book: bool = False,
    *,
    history_reserve: int | None = None,
) -> dict[str, Any]:
    """Axis 1 (context_window) sets the total; Axis 2 (detail) sets
    distribution only; it never changes the total (Batch 5, 5.1/5.2).

    Derives a profile dict with the identical shape BUDGET_PROFILES entries
    have, so every existing consumer (run_simulations, analyze_manifest,
    analyze_output) needs no changes at all. worst_case_recursion_path
    becomes the primary budget object: permanent_card_hard is sized directly
    from the artifact's shell share of available_for_static (5.4), and
    everything else is the existing profile's own internal ratios (its
    tuned relationships between constant/direct/recursive/worst_case),
    rescaled against the new worst_case_hard rather than replaced.
    """
    if not isinstance(context_window, int) or isinstance(context_window, bool) or context_window <= 0:
        raise WorldBuilderError("context_window must be a positive integer")
    detail = normalize_profile(detail)
    base = BUDGET_PROFILES[detail]

    generation_reserve = max(1, round(context_window * GENERATION_RESERVE_SHARE))
    if history_reserve is None:
        history_reserve = max(1, round(context_window * DEFAULT_HISTORY_RESERVE_SHARE))
    elif not isinstance(history_reserve, int) or isinstance(history_reserve, bool) or history_reserve <= 0:
        raise WorldBuilderError("history_reserve must be a positive integer")
    available_for_static = context_window - generation_reserve - history_reserve
    if available_for_static < 200:
        raise WorldBuilderError(
            f"context window {context_window} leaves only {available_for_static} tokens for static "
            f"content after generation_reserve ({generation_reserve}) and history_reserve ({history_reserve}); "
            "raise the window or reduce history_reserve"
        )

    shell_share = SHELL_SHARE_BY_ARTIFACT_TYPE.get((artifact_type, bool(has_embedded_book)))
    if shell_share is None:
        raise WorldBuilderError(f"no shell share is defined for artifact_type={artifact_type!r}")
    permanent_card_hard = max(1, round(available_for_static * shell_share))
    worst_case_hard = max(1, available_for_static - permanent_card_hard)
    scale = worst_case_hard / base["worst_case_hard"]

    def scaled(key: str) -> int:
        return max(1, round(base[key] * scale))

    derived = dict(base)
    derived["permanent_card_hard"] = permanent_card_hard
    derived["permanent_card_target"] = min(
        max(1, round(permanent_card_hard * base["permanent_card_target"] / base["permanent_card_hard"])),
        permanent_card_hard - 1 if permanent_card_hard > 1 else permanent_card_hard,
    )
    for key in ("constant_target", "constant_hard", "entry_soft", "entry_hard",
                "direct_activation_target", "direct_activation_hard",
                "recursive_activation_target", "recursive_activation_hard"):
        derived[key] = scaled(key)
    derived["worst_case_hard"] = worst_case_hard
    derived["worst_case_target"] = min(scaled("worst_case_target"), worst_case_hard - 1 if worst_case_hard > 1 else worst_case_hard)
    # Guard every target/hard pair the same way _validate_positive_ints will check.
    for target_key, hard_key in (
        ("constant_target", "constant_hard"), ("entry_soft", "entry_hard"),
        ("direct_activation_target", "direct_activation_hard"),
        ("recursive_activation_target", "recursive_activation_hard"),
    ):
        if derived[target_key] >= derived[hard_key]:
            derived[target_key] = max(1, derived[hard_key] - 1)
    # corpus_authored_tokens (5.2) stays reported-only and is not activation-scoped,
    # so it is not rescaled with everything else; it is sized off the whole
    # available_for_static, generously, purely as an FYI ceiling for authored volume.
    derived["lorebook_token_budget"] = max(base["lorebook_token_budget"], available_for_static * 2)
    derived["context_window"] = context_window
    derived["generation_reserve"] = generation_reserve
    derived["history_reserve"] = history_reserve
    derived["available_for_static"] = available_for_static
    derived["shell_share"] = shell_share
    return derived


def build_plan(
    *,
    build_id: str,
    artifact_type: str,
    schema: int | str,
    profile_id: str = "recommended",
    policy: str = "automatic",
    default_profile_sha256: str,
    custom_overrides: dict[str, Any] | None = None,
    context_window: int | None = None,
    history_reserve: int | None = None,
    context_window_mode: str = "legacy",
    pruning_objectives: Iterable[str] | None = None,
) -> dict[str, Any]:
    """context_window is Axis 1 (Batch 5, 5.1/5.2): when declared, targets are
    derived from the user's actual model window via derive_profile() instead
    of the frozen absolute BUDGET_PROFILES table. Migration: a plan with no
    declared window falls back to the legacy static profile unchanged;
    only new builds are required to declare one."""
    profile_id = normalize_profile(profile_id)
    if context_window_mode not in {"legacy", "fixed", "auto"}:
        raise WorldBuilderError("context_window_mode must be legacy, fixed, or auto")
    if context_window_mode == "auto" and context_window is not None:
        raise WorldBuilderError("auto context-window mode cannot also declare a fixed context_window")
    if context_window_mode == "fixed" and context_window is None:
        raise WorldBuilderError("fixed context-window mode requires context_window")
    if policy not in {"automatic", "review", "custom"}:
        raise WorldBuilderError("budget policy must be automatic, review, or custom")
    overrides = custom_overrides or {}
    if not isinstance(overrides, dict):
        raise WorldBuilderError("budget overrides must be an object")
    if policy != "custom" and overrides:
        raise WorldBuilderError("budget overrides require custom policy")
    if context_window is None:
        base_profile = BUDGET_PROFILES[profile_id]
    else:
        has_embedded_book = artifact_type == "card" and schema == 3
        base_profile = derive_profile(
            context_window, profile_id, artifact_type, has_embedded_book, history_reserve=history_reserve
        )
    profile = _deep_merge(base_profile, overrides)
    _validate_positive_ints(profile)
    lore_bearing = artifact_type in {"world", "lorebook", "group"} or schema in {2, 3}
    result = {
        "kind": PLAN_KIND,
        "plan_version": PLAN_VERSION,
        "contract": CONTRACT,
        "build_id": build_id,
        "applicable": bool(lore_bearing),
        "artifact_type": artifact_type,
        "schema": schema,
        "policy": policy,
        "profile_id": profile_id,
        "profile_label": profile["label"],
        "default_profile_sha256": default_profile_sha256,
        "estimator": {"kind": "utf8_bytes_div_4_ceiling", "exact_tokenizer": False},
        "coverage_policy": "additive discovery remains independent from active-context pressure",
        "targets": profile,
        "protected_categories": sorted(PROTECTED_CATEGORIES),
        "prune_first": list(PRUNE_FIRST),
        "activation_simulations": list(SIMULATION_NAMES),
        "project_simulations": [],
        "pruning_objectives": objective_plan_rows(pruning_objectives),
        "custom_overrides": overrides,
    }
    if context_window is None:
        result["context_window_assumption"] = (
            "No model context window was declared for this build; the "
            f"{profile['label']} ceilings are the frozen planning-profile defaults, "
            "not values derived from any real setup. Confirm the actual model context "
            "size and SillyTavern's World Info budget / budget-cap settings before "
            "relying on any ceiling."
        )
    # Keep legacy/fixed plan shape backward-compatible. Only auto needs a new
    # frozen semantic because its generation limits intentionally become measurement-only.
    if context_window_mode == "auto":
        result["context_window_mode"] = "auto"
        result["generation_unconstrained"] = True
    return result


def validate_plan(
    plan: Any,
    *,
    expected_build_id: str | None = None,
    expected_profile_sha256: str | None = None,
) -> None:
    if not isinstance(plan, dict) or plan.get("kind") != PLAN_KIND or plan.get("plan_version") != PLAN_VERSION:
        raise WorldBuilderError("budget plan has the wrong kind/version")
    if plan.get("contract") != CONTRACT:
        raise WorldBuilderError(f"budget plan contract must be {CONTRACT}")
    if expected_build_id is not None and plan.get("build_id") != expected_build_id:
        raise WorldBuilderError("budget plan belongs to another build")
    if expected_profile_sha256 is not None and plan.get("default_profile_sha256") != expected_profile_sha256:
        raise WorldBuilderError("budget plan is stale for the frozen default profile")
    normalize_profile(str(plan.get("profile_id", "")))
    mode = plan.get("context_window_mode", "legacy")
    if mode not in {"legacy", "fixed", "auto"}:
        raise WorldBuilderError("budget plan has an invalid context_window_mode")
    if mode == "auto" and plan.get("generation_unconstrained") is not True:
        raise WorldBuilderError("auto budget plan must declare generation_unconstrained=true")
    if mode != "auto" and plan.get("generation_unconstrained") not in {None, False}:
        raise WorldBuilderError("generation_unconstrained is only valid in auto context-window mode")
    if plan.get("policy") not in {"automatic", "review", "custom"}:
        raise WorldBuilderError("budget plan has an invalid policy")
    if plan.get("policy") != "custom" and plan.get("custom_overrides"):
        raise WorldBuilderError("non-custom budget plan cannot contain overrides")
    targets = plan.get("targets")
    if not isinstance(targets, dict):
        raise WorldBuilderError("budget plan targets must be an object")
    _validate_positive_ints(targets)
    if set(plan.get("protected_categories", [])) != PROTECTED_CATEGORIES:
        raise WorldBuilderError("budget plan protected categories are incomplete")
    if tuple(plan.get("activation_simulations", [])) != SIMULATION_NAMES:
        raise WorldBuilderError("budget plan baseline activation simulations are incomplete")
    validate_pruning_objective_rows(plan.get("pruning_objectives", []))
    project = plan.get("project_simulations", [])
    if not isinstance(project, list):
        raise WorldBuilderError("budget plan project_simulations must be a list")
    seen_project: set[str] = set()
    for row in project:
        if not isinstance(row, dict):
            raise WorldBuilderError("project simulations must be objects")
        name = str(row.get("name", "")).strip()
        if not name or name in SIMULATION_NAMES or name.casefold() in seen_project:
            raise WorldBuilderError("project simulation names must be unique and must not replace baseline simulations")
        seen_project.add(name.casefold())
        seeds = row.get("seed_uids")
        if not isinstance(seeds, list) or not seeds:
            raise WorldBuilderError(f"project simulation {name!r} needs seed_uids")
        for value in seeds:
            uid_key(value)
        if row.get("target_class", "recursive") not in {"direct", "recursive", "worst_case"}:
            raise WorldBuilderError(f"project simulation {name!r} has invalid target_class")
        if not isinstance(row.get("include_optional", True), bool):
            raise WorldBuilderError(f"project simulation {name!r} include_optional must be boolean")


def load_bound_plan(root: Path, state: dict[str, Any], manifest: dict[str, Any] | None = None) -> tuple[dict[str, Any], Path]:
    path = resolve_state_path(root, state, "budget_plan")
    if not path.exists():
        raise WorldBuilderError("budget plan is missing")
    plan = load_json(path)
    default_profile_path = resolve_state_path(root, state, "default_profile")
    validate_plan(plan, expected_build_id=str(state.get("build_id", "")), expected_profile_sha256=sha256_file(default_profile_path))
    if manifest is not None:
        expected = manifest.get("budget_plan_sha256")
        architecture = manifest.get("architecture") if isinstance(manifest.get("architecture"), dict) else {}
        budget_cfg = architecture.get("budget") if isinstance(architecture.get("budget"), dict) else {}
        if plan.get("applicable"):
            if expected != sha256_file(path):
                raise WorldBuilderError("manifest budget_plan_sha256 is missing or stale")
            if budget_cfg.get("contract") != CONTRACT or budget_cfg.get("plan_sha256") != expected:
                raise WorldBuilderError("manifest architecture.budget binding is missing or stale")
    return plan, path




def _entry_arch(entry: dict[str, Any]) -> dict[str, Any]:
    value = entry.get("architecture")
    return value if isinstance(value, dict) else {}


def _activation(entry: dict[str, Any]) -> dict[str, Any]:
    value = entry.get("activation")
    return value if isinstance(value, dict) else {}




def _explicit_estimate(entry: dict[str, Any]) -> int | None:
    candidates: list[Any] = [entry.get("estimated_tokens")]
    for container in (_entry_arch(entry), _activation(entry), _emit(entry)):
        candidates.extend([container.get("estimated_tokens"), container.get("token_estimate")])
        budget = container.get("budget")
        if isinstance(budget, dict):
            candidates.extend([budget.get("estimated_tokens"), budget.get("token_estimate")])
    for value in candidates:
        if isinstance(value, int) and not isinstance(value, bool) and value >= 0:
            return value
    return None


def _planned_text(entry: dict[str, Any]) -> str:
    activation = _activation(entry)
    emit = _emit(entry)
    values: list[str] = [str(entry.get("name", "")), str(entry.get("type", ""))]
    for key in ("required_terms", "emits", "forbidden_emits"):
        value = activation.get(key)
        if isinstance(value, list):
            values.extend(str(item) for item in value)
    for key in ("keys", "secondary_keys"):
        value = emit.get(key)
        if isinstance(value, list):
            values.extend(str(item) for item in value)
    return "\n".join(values)


def _explicit_measured_tokens(entry: dict[str, Any]) -> int | None:
    candidates: list[Any] = [entry.get("measured_tokens"), entry.get("token_count")]
    extensions = entry.get("extensions")
    if isinstance(extensions, dict):
        budget = extensions.get("worldbuilder_budget")
        if isinstance(budget, dict):
            candidates.extend([budget.get("measured_tokens"), budget.get("token_count")])
    for value in candidates:
        if isinstance(value, int) and not isinstance(value, bool) and value >= 0:
            return value
    return None


def planned_token_measurement(entry: dict[str, Any], targets: dict[str, Any]) -> tuple[int, str]:
    measured = _explicit_measured_tokens(entry)
    if measured is not None:
        return measured, "measured_tokens"
    explicit = _explicit_estimate(entry)
    if explicit is not None:
        return explicit, "declared_estimate"
    estimate = estimate_tokens(_planned_text(entry))
    return max(estimate, min(120, int(targets["entry_soft"]))), "utf8_bytes_div_4_ceiling"


def planned_tokens(entry: dict[str, Any], targets: dict[str, Any]) -> int:
    return planned_token_measurement(entry, targets)[0]


def actual_entry_token_measurement(entry: dict[str, Any]) -> tuple[int, str]:
    measured = _explicit_measured_tokens(entry)
    if measured is not None:
        return measured, "measured_tokens"
    content = entry.get("content")
    content = content if isinstance(content, str) else (content or "")
    # Batch 9: decorators are trimmed from content before prompting per the
    # CCv3 spec: they were never real content to begin with, and counting
    # them would overstate this entry's actual runtime cost. Only the
    # estimate_tokens fallback is affected; an externally-supplied
    # measured_tokens value (a worker's own tokenizer count) is not this
    # function's responsibility to correct.
    from decorators import parse_leading_decorators
    _decorators, content = parse_leading_decorators(content)
    return estimate_tokens(content), "utf8_bytes_div_4_ceiling"


def actual_entry_tokens(entry: dict[str, Any]) -> int:
    return actual_entry_token_measurement(entry)[0]


# Batch 5, 5.7. ceil(UTF-8 bytes / 4) is honest but coarse: fine for English
# prose, badly off for names and CJK. token_count_precedence already declares
# measured -> declared -> fallback (see _explicit_measured_tokens); nothing
# previously produced a measured value at all. tiktoken is optional, on
# purpose: importing it inside the function (not at module load) means a
# host without it never fails to import budget_contract.py at all, so the
# anyBins install story is unchanged either way.
_TIKTOKEN_ENCODING_NAME = "cl100k_base"


def probe_measured_tokens(text: str) -> int | None:
    """Returns None (never raises) when tiktoken is not installed or the
    probe fails for any reason; ceil(UTF-8 bytes/4) remains the correct
    fallback in that case, exactly as before this batch."""
    if not isinstance(text, str) or not text:
        return 0 if text == "" else None
    try:
        import tiktoken
    except ImportError:
        return None
    try:
        encoding = tiktoken.get_encoding(_TIKTOKEN_ENCODING_NAME)
        return len(encoding.encode(text))
    except Exception:
        return None


def annotate_measured_tokens(data: Any) -> tuple[Any, int]:
    """5.7: returns a deep copy of data with measured_tokens populated on
    every lorebook entry tiktoken could probe (never mutates the original).
    The second return value is how many entries were actually annotated, so
    a caller can report 0 honestly rather than imply the probe ran when
    tiktoken was never installed."""
    annotated = copy.deepcopy(data)
    count = 0
    for ref in iter_entries(annotated):
        content = ref.entry.get("content")
        if not isinstance(content, str):
            continue
        measured = probe_measured_tokens(content)
        if measured is not None:
            ref.entry["measured_tokens"] = measured
            count += 1
    return annotated, count


def _layer(entry: dict[str, Any]) -> str:
    return str(_entry_arch(entry).get("layer") or entry.get("type") or "other").strip().casefold().replace(" ", "_")


def _era_ids(entry: dict[str, Any]) -> list[str]:
    arch = _entry_arch(entry)
    value = arch.get("era_ids", arch.get("era_id"))
    if isinstance(value, list):
        return [str(item) for item in value if str(item)]
    if value not in {None, "", "single"}:
        return [str(value)]
    return ["single"]






def protected_categories(entry: dict[str, Any], required_edge_uids: set[str]) -> set[str]:
    uid = uid_key(entry.get("uid", entry.get("id")))
    arch = _entry_arch(entry)
    layer = _layer(entry)
    categories: set[str] = set()
    if layer in {"world_core", "world_invariants"}:
        categories.add("world_invariants")
    # Batch 57: pruning the index does not shrink activation pressure the way
    # pruning a triggered entry does; it removes the only signal that the
    # surviving entries exist. Same automatic-reason treatment as constant
    # factions/organizations below, so old frozen plans stay valid.
    if layer == "world_index":
        categories.add("world_invariants")
    # Batch 14: factions/organizations marked constant are structural world facts
    # just like world_core constants. Keep this as an internal automatic reason,
    # not a new member of PROTECTED_CATEGORIES, so old frozen plans stay valid.
    if layer in {"faction", "organization"}:
        categories.add("faction_or_organization")
    if layer == "era_context" or arch.get("era_isolation") or arch.get("future_prohibition"):
        categories.add("era_isolation")
    if arch.get("knowledge_boundary") or arch.get("knowledge_restrictions"):
        categories.add("knowledge_boundary")
    if arch.get("status_change") or arch.get("life_status_change"):
        categories.add("status_change")
    if layer == "character" and (arch.get("character_state_id") or arch.get("identity_state")):
        categories.add("identity_state")
    if layer == "relationship" and (arch.get("required") is not False):
        categories.add("required_relationship")
    if uid in required_edge_uids:
        categories.add("required_activation_path")
    declared = arch.get("protected_categories")
    if isinstance(declared, list):
        categories.update(str(item) for item in declared if str(item) in PROTECTED_CATEGORIES)
    return categories




def _row_map(rows: Iterable[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    result: dict[str, dict[str, Any]] = {}
    for row in rows:
        key = uid_key(row.get("uid", row.get("id")))
        if key in result:
            raise WorldBuilderError(f"budget analysis found duplicate UID {key}")
        result[key] = row
    return result


def _largest_uid(rows: list[dict[str, Any]], token_map: dict[str, int], *, layers: set[str] | None = None, types: set[str] | None = None) -> list[str]:
    candidates = []
    for row in rows:
        if layers is not None and _layer(row) not in layers:
            continue
        if types is not None and str(row.get("type", "")).casefold() not in types:
            continue
        candidates.append(uid_key(row.get("uid", row.get("id"))))
    if not candidates:
        return []
    return [max(candidates, key=lambda uid: token_map.get(uid, 0))]


# Batch 5, 5.3: target = clamp(source_tokens * ratio, floor, ceiling), split-not-trim.
# Ratio is from the detail axis; Maximum Detail has none at all (5.8's structural-
# ceiling rule); a per-entry ratio target on Maximum would make the model
# self-censor mid-entry, which is exactly what 5.8 exists to prevent.
COMPRESSION_RATIO_BY_DETAIL = {"compact": 0.15, "recommended": 0.30, "maximum_detail": None}
# "Floor stops a 200-token stub vanishing": the plan's own number, not a choice.
ENTRY_TARGET_FLOOR = 200

# Batch 5, 5.8. Tier 0 is never cut; a breach is a split signal, not a trim.
# Tiers 1-3 are cut in this order (3 first) when an entry must shrink to fit
# entry_hard. This is guidance surfaced to the worker that writes the entry's
# actual prose. Classifying a specific sentence into a tier is a content
# judgment no script can make; what this codebase can do is state the rule
# and check the *mechanical* consequence (the overflow record's shape).
RETENTION_LADDER = {
    "0": {
        "content": (
            "Required emitted terms (outgoing-edge triggers); purpose-required structure "
            "(VITALS/voice/CURRENT/CONNECTIONS for characters, constraint statement for rules, "
            "era token for roots); stable identity facts."
        ),
        "rule": "Never cut. Breach = split signal. Cutting an emitted term silently darkens a subtree.",
    },
    "1": {
        "content": (
            "Falsifiable specifics with dependents: a date, name, or state another entry "
            "references or keys on; era state assertions."
        ),
        "rule": "Cut last.",
    },
    "2": {
        "content": "Falsifiable specifics without dependents.",
        "rule": "Cut before Tier 1.",
    },
    "3": {
        "content": (
            "Atmospheric prose beyond one anchoring image; anything a neighbour entry owns; "
            "generic characterization and hedging; restatement of permanent card-shell content."
        ),
        "rule": "Cut first.",
    },
}


def compute_entry_target(source_tokens: int, compression_ratio: float | None, floor: int, ceiling: int) -> dict[str, Any]:
    """5.3/5.8: target = clamp(source_tokens * ratio, floor, ceiling). When the
    raw computed value would exceed ceiling, that is a split signal, not a
    truncation instruction. Dense source material is often entirely
    important; stratify by depth instead of cutting it.

    compression_ratio=None is 5.8's Maximum Detail case: no per-entry target
    is derived from source size at all. entry_hard (passed as ceiling) is a
    planning-time split trigger applied once actual written length is known,
    never a trim instruction, never a block; method="structural_ceiling"
    lets a caller tell the two cases apart.
    """
    if floor > ceiling:
        raise WorldBuilderError(f"entry target floor {floor} exceeds ceiling {ceiling}")
    if not isinstance(source_tokens, int) or isinstance(source_tokens, bool) or source_tokens < 0:
        raise WorldBuilderError("source_tokens must be a non-negative integer")
    if compression_ratio is None:
        return {
            "target": ceiling, "split_signal": False, "method": "structural_ceiling",
            "note": (
                "Maximum Detail: no ratio. Write exhaustively; entry_hard is a split trigger "
                "applied once written length is known, never a trim instruction, never a block."
            ),
        }
    if compression_ratio <= 0:
        raise WorldBuilderError("compression_ratio must be positive")
    raw = source_tokens * compression_ratio
    target = max(floor, min(round(raw), ceiling))
    return {
        "target": target,
        "split_signal": raw > ceiling,
        "method": "compression_ratio",
        "raw_computed": round(raw),
    }


# Batch 5, 5.6. A hard block on a planning *preference* is the wrong shape
# for this problem (philosophy point 9): spec and compatibility errors
# still block outright; a measured budget overage gets structural options
# instead of a bare failure, and an explicit human choice to ship anyway is
# recorded into the frozen plan, never silently auto-approved and never a
# runtime override.
DEVIATION_OPTIONS = (
    {"option": "deepen_graph", "description": "Deepen the activation graph so more content moves out of the worst-case path."},
    {"option": "add_inclusion_groups", "description": "Group mutually-exclusive entries so only one of each group ever activates at once."},
    {"option": "tighten_keywords", "description": "Narrow overly-broad keys so fewer entries co-activate at once."},
    {"option": "raise_window_or_detail", "description": "Raise the declared context window, or move to a less detailed profile."},
    {"option": "accept_and_record", "description": "Accept this measured overage as an approved deviation, recorded into the frozen plan."},
)


def propose_deviation_options(overage_kind: str, measured: int, limit: int) -> dict[str, Any]:
    """5.6: present structural remediation options rather than a bare
    failure when a planning preference (not a spec or compatibility rule)
    is exceeded. Never itself a decision; the human chooses."""
    if measured <= limit:
        raise WorldBuilderError(f"{overage_kind} measured {measured} does not exceed limit {limit}; there is no overage to propose options for")
    return {
        "overage_kind": overage_kind, "measured": measured, "limit": limit, "over_by": measured - limit,
        "options": [dict(option) for option in DEVIATION_OPTIONS],
    }


def record_approved_deviation(
    plan: dict[str, Any], *, overage_kind: str, measured: int, limit: int, approved_by: str, reason: str,
) -> dict[str, Any]:
    """5.6: recorded INTO the frozen plan at approval time, never a
    runtime override, never silent. Returns the updated plan; a plan is
    otherwise immutable once built, so callers must persist this themselves
    (write_json over the plan file) for the deviation to actually take
    effect on a later analyze_manifest/analyze_output call."""
    if not isinstance(approved_by, str) or not approved_by.strip():
        raise WorldBuilderError("record_approved_deviation requires a non-empty approved_by")
    if not isinstance(reason, str) or not reason.strip():
        raise WorldBuilderError("record_approved_deviation requires a non-empty reason")
    if measured <= limit:
        raise WorldBuilderError(f"{overage_kind} measured {measured} does not exceed limit {limit}; nothing to approve")
    deviation = {
        "overage_kind": overage_kind, "measured": measured, "limit": limit, "over_by": measured - limit,
        "approved_by": approved_by.strip(), "reason": reason.strip(),
    }
    updated = dict(plan)
    updated["approved_deviations"] = list(plan.get("approved_deviations") or []) + [deviation]
    return updated


def deviation_covers(plan: dict[str, Any], overage_kind: str, measured: int) -> bool:
    """Does an already-recorded approved deviation cover this specific
    measured overage? Only up to what was actually approved. A worse
    overage than what was approved needs its own new approval; an old
    deviation never silently waves through a regression past what a human
    actually saw and accepted."""
    deviations = plan.get("approved_deviations")
    if not isinstance(deviations, list):
        return False
    return any(
        isinstance(dev, dict) and dev.get("overage_kind") == overage_kind and measured <= dev.get("measured", -1)
        for dev in deviations
    )




def _simulation(name: str, seeds: list[str], uids: list[str], token_map: dict[str, int], target: int, hard: int) -> dict[str, Any]:
    tokens = sum(token_map.get(uid, 0) for uid in uids)
    return {
        "name": name,
        "seed_uids": seeds,
        "activated_uids": uids,
        "estimated_tokens": tokens,
        "target": target,
        "hard_limit": hard,
        "pressure": "blocked" if tokens > hard else ("warning" if tokens > target else "ok"),
    }


def _era_branch_links(rows: list[dict[str, Any]]) -> dict[str, set[str]]:
    """Mandatory co-firing links for era-branch books: an entry carrying
    ``era_branch_of`` shares its character's primary key and activates in
    the same pass, so the pair is one activation unit for cost purposes.
    A character's real worst-case cost is character-cost-plus-branch-cost,
    always; without this, worst-case estimates are systematically low for
    every book using this architecture."""
    links: dict[str, set[str]] = defaultdict(set)
    for row in rows:
        uid = uid_key(row.get("uid", row.get("id")))
        target = row.get("era_branch_of")
        if target is None:
            continue
        partner = uid_key(target)
        if partner == uid:
            continue
        links[uid].add(partner)
        links[partner].add(uid)
    return links


def run_simulations(
    rows: list[dict[str, Any]],
    edges: list[dict[str, Any]],
    token_map: dict[str, int],
    targets: dict[str, Any],
    project_simulations: list[dict[str, Any]] | None = None,
    *,
    memo: dict[Any, list[str]] | None = None,
) -> list[dict[str, Any]]:
    depth = int(targets["simulation_depth"])
    constants = [uid_key(row.get("uid", row.get("id"))) for row in rows if _is_constant(row)]
    mandatory_links = _era_branch_links(rows)

    def activated(seed: list[str], include_optional: bool = True) -> list[str]:
        # Batch 55: the closure walk is pure over (seed, edges, depth,
        # include_optional); only the token re-sum differs between the
        # planning pass and the output-stage re-estimation. A shared memo
        # lets the second pass reuse memberships instead of walking again.
        memo_key = (tuple(sorted(str(value) for value in seed)), bool(include_optional)) if memo is not None else None
        if memo_key is not None and memo_key in memo:
            return list(memo[memo_key])
        resolved = set(constants) | set(_closure(seed, edges, depth, include_optional=include_optional))
        expanded = True
        while expanded:
            expanded = False
            for uid in list(resolved):
                for partner in mandatory_links.get(uid, ()):
                    if partner not in resolved:
                        resolved.add(partner)
                        expanded = True
        result = sorted(resolved)
        if memo_key is not None:
            memo[memo_key] = result
        return list(result)

    char = _largest_uid(rows, token_map, layers={"character"}, types={"character"})
    loc = _largest_uid(rows, token_map, layers={"location"}, types={"location"})
    faction = _largest_uid(rows, token_map, layers={"faction", "organization"}, types={"faction", "organization"})
    era = _largest_uid(rows, token_map, layers={"era_context"})

    key_owners: dict[str, list[str]] = defaultdict(list)
    for row in rows:
        uid = uid_key(row.get("uid", row.get("id")))
        for key in _keys(row):
            key_owners[key].append(uid)
    ambiguous = max(key_owners.values(), key=lambda values: (len(values), sum(token_map.get(uid, 0) for uid in values)), default=[])

    relationships = [uid_key(row.get("uid", row.get("id"))) for row in rows if _layer(row) == "relationship"]
    if relationships:
        relationships = sorted(relationships, key=lambda uid: token_map.get(uid, 0), reverse=True)[:5]

    all_sources = [uid_key(row.get("uid", row.get("id"))) for row in rows]
    worst_seed: list[str] = []
    worst_uids: list[str] = constants.copy()
    worst_tokens = sum(token_map.get(uid, 0) for uid in worst_uids)
    for source in all_sources:
        values = activated([source], include_optional=True)
        total = sum(token_map.get(uid, 0) for uid in values)
        if total > worst_tokens:
            worst_seed, worst_uids, worst_tokens = [source], values, total

    normal_target = int(targets["direct_activation_target"])
    normal_hard = int(targets["direct_activation_hard"])
    recursive_target = int(targets["recursive_activation_target"])
    recursive_hard = int(targets["recursive_activation_hard"])
    worst_target = int(targets["worst_case_target"])
    worst_hard = int(targets["worst_case_hard"])
    simulations = [
        _simulation("major_character", char, activated(char), token_map, normal_target, normal_hard),
        _simulation("major_location", loc, activated(loc), token_map, normal_target, normal_hard),
        _simulation("faction", faction, activated(faction), token_map, normal_target, normal_hard),
        _simulation("era_keyword", era, activated(era), token_map, recursive_target, recursive_hard),
        _simulation("common_ambiguous_term", ambiguous, activated(ambiguous), token_map, recursive_target, recursive_hard),
        _simulation("relationship_cluster", relationships, activated(relationships), token_map, recursive_target, recursive_hard),
        _simulation("worst_case_recursion_path", worst_seed, worst_uids, token_map, worst_target, worst_hard),
    ]
    target_classes = {
        "direct": (normal_target, normal_hard),
        "recursive": (recursive_target, recursive_hard),
        "worst_case": (worst_target, worst_hard),
    }
    known_uids = {uid_key(row.get("uid", row.get("id"))) for row in rows}
    for row in project_simulations or []:
        name = str(row["name"]).strip()
        seeds = [uid_key(value) for value in row["seed_uids"]]
        missing = sorted(set(seeds) - known_uids)
        if missing:
            raise WorldBuilderError(f"project simulation {name!r} references unknown UIDs: {', '.join(missing)}")
        include_optional = bool(row.get("include_optional", True))
        target, hard = target_classes[str(row.get("target_class", "recursive"))]
        simulations.append(_simulation(name, seeds, activated(seeds, include_optional=include_optional), token_map, target, hard))
    return simulations


def _card_token_breakdown(data: dict[str, Any]) -> dict[str, int]:
    """Three independent card-cost meters, not one blended total.

    permanent_tokens: description/personality/scenario/system_prompt/
    post_history_instructions. The only fields SillyTavern keeps present in
    the prompt on every turn, so this is the only one of the three capped
    against permanent_card_hard.

    opening_tokens: first_mes + the single active alternate_greetings entry
    (max, never the sum; only one swipe is ever live) + mes_example. All
    three are chat history or example dialogue that scrolls or pushes out
    over the conversation rather than a fixed permanent cost. Reported and
    soft-warned, never hard-capped.

    non_prompt_tokens: creator_notes. Display-only in the character panel;
    SillyTavern never puts it in the prompt at all. Reported only, never
    capped or warned.
    """
    zero = {"permanent_tokens": 0, "opening_tokens": 0, "non_prompt_tokens": 0}
    if data.get("spec") not in {"chara_card_v2", "chara_card_v3"} or not isinstance(data.get("data"), dict):
        return zero
    payload = data["data"]

    permanent_fields = ("description", "personality", "scenario", "system_prompt", "post_history_instructions")
    permanent_tokens = sum(estimate_tokens(payload.get(field, "")) for field in permanent_fields)

    alternates = payload.get("alternate_greetings")
    max_alternate = 0
    if isinstance(alternates, list):
        alt_tokens = [estimate_tokens(value) for value in alternates if isinstance(value, str)]
        max_alternate = max(alt_tokens, default=0)
    opening_tokens = (
        estimate_tokens(payload.get("first_mes", ""))
        + max_alternate
        + estimate_tokens(payload.get("mes_example", ""))
    )

    non_prompt_tokens = estimate_tokens(payload.get("creator_notes", ""))

    return {
        "permanent_tokens": permanent_tokens,
        "opening_tokens": opening_tokens,
        "non_prompt_tokens": non_prompt_tokens,
    }


def analyze_manifest(plan: dict[str, Any], manifest: dict[str, Any], *, memo: dict[Any, list[str]] | None = None) -> dict[str, Any]:
    targets = plan["targets"]
    measurement_only = plan.get("context_window_mode") == "auto"
    rows = _manifest_rows(manifest)
    edges, required_uids = _required_edges(manifest)
    row_map = _row_map(rows)
    measurements = {uid: planned_token_measurement(row, targets) for uid, row in row_map.items()}
    token_map = {uid: value[0] for uid, value in measurements.items()}
    details: list[dict[str, Any]] = []
    layer_totals: dict[str, int] = defaultdict(int)
    era_totals: dict[str, int] = defaultdict(int)
    warnings: list[str] = []
    for uid, row in row_map.items():
        tokens = token_map[uid]
        layer = _layer(row)
        categories = protected_categories(row, required_uids)
        budget_cfg = _entry_arch(row).get("budget") if isinstance(_entry_arch(row).get("budget"), dict) else {}
        prunable = budget_cfg.get("prunable", row.get("prunable"))
        if categories and prunable is True:
            raise WorldBuilderError(f"entry UID {uid} is protected ({', '.join(sorted(categories))}) and cannot be marked prunable")
        if not measurement_only and tokens > int(targets["entry_hard"]):
            raise WorldBuilderError(f"entry UID {uid} estimated tokens {tokens} exceed hard per-entry limit {targets['entry_hard']}")
        if not measurement_only and tokens > int(targets["entry_soft"]):
            warnings.append(f"entry UID {uid} estimated tokens {tokens} exceed soft target {targets['entry_soft']}")
        layer_totals[layer] += tokens
        for era in _era_ids(row):
            era_totals[era] += tokens
        details.append({
            "uid": row.get("uid", row.get("id")), "name": row.get("name", ""),
            "layer": layer, "era_ids": _era_ids(row), "estimated_tokens": tokens,
            "token_count_source": measurements[uid][1],
            "soft_target": targets["entry_soft"], "hard_limit": targets["entry_hard"],
            "priority": _emit(row).get("priority", _emit(row).get("insertion_order")),
            "constant": _is_constant(row), "protected_categories": sorted(categories),
            "prunable": False if categories else (prunable is not False),
        })
    constant_tokens = sum(token_map[uid] for uid, row in row_map.items() if _is_constant(row))
    constant_deviation_covers = deviation_covers(plan, "constant_hard", constant_tokens)
    if not measurement_only and constant_tokens > int(targets["constant_hard"]) and not constant_deviation_covers:
        raise WorldBuilderError(f"constant lore cost {constant_tokens} exceeds hard limit {targets['constant_hard']}")
    if not measurement_only and constant_tokens > int(targets["constant_hard"]) and constant_deviation_covers:
        warnings.append(
            f"constant lore cost {constant_tokens} exceeds hard limit {targets['constant_hard']} "
            "but is covered by an approved deviation recorded in the plan"
        )
    if not measurement_only and constant_tokens > int(targets["constant_target"]):
        warnings.append(f"constant lore cost {constant_tokens} exceeds target {targets['constant_target']}")
    simulations = run_simulations(rows, edges, token_map, targets, plan.get("project_simulations", []), memo=memo)
    blocked = [row for row in simulations if row["pressure"] == "blocked"]
    still_blocked = [row for row in blocked if not deviation_covers(plan, row["name"], row["estimated_tokens"])]
    if still_blocked and not measurement_only:
        row = next((value for value in still_blocked if value["name"] == "worst_case_recursion_path"), None)
        row = row or max(still_blocked, key=lambda value: value["estimated_tokens"] - value["hard_limit"])
        raise WorldBuilderError(f"{row['name']} activation estimate {row['estimated_tokens']} exceeds hard limit {row['hard_limit']}")
    if not measurement_only:
        warnings.extend(
            f"{row['name']} activation estimate {row['estimated_tokens']} exceeds hard limit {row['hard_limit']} "
            "but is covered by an approved deviation recorded in the plan"
            for row in blocked if row not in still_blocked
        )
        warnings.extend(
            f"{row['name']} activation estimate {row['estimated_tokens']} exceeds target {row['target']}"
            for row in simulations if row["pressure"] == "warning"
        )
    else:
        warnings.append("auto context-window mode: planning limits are measurement-only until post-merge review")
    # corpus_authored_tokens is reported, never compared to an activation budget and
    # never blocked on (Batch 5, 5.2, DR "Corpus size is reported; activation pressure
    # is budgeted"). Storage is not a runtime cost; what matters for context pressure
    # is worst_case_recursion_path, above, not how much lore exists in total.
    corpus_authored_tokens = sum(token_map.values())
    return {
        "entry_count": len(rows), "entries": details, "constant_tokens": constant_tokens,
        "corpus_authored_tokens": corpus_authored_tokens, "layer_totals": dict(sorted(layer_totals.items())),
        "era_totals": dict(sorted(era_totals.items())), "simulations": simulations,
        "warnings": warnings,
    }


def analyze_output(
    plan: dict[str, Any], manifest_detail: dict[str, Any], data: dict[str, Any],
    manifest: dict[str, Any] | None = None,
    *, memo: dict[Any, list[str]] | None = None,
) -> dict[str, Any]:
    targets = plan["targets"]
    measurement_only = plan.get("context_window_mode") == "auto"
    actual_rows: dict[str, dict[str, Any]] = {}
    for ref in iter_entries(data):
        identity = canonical_entry_identity(ref.entry)
        if identity is None:
            continue
        actual_rows[uid_key(identity)] = ref.entry
    expected = {uid_key(row["uid"]): row for row in manifest_detail["entries"]}
    missing = sorted(set(expected) - set(actual_rows))
    if missing:
        raise WorldBuilderError("budget output is missing planned UIDs: " + ", ".join(missing))
    token_map: dict[str, int] = {}
    token_sources: dict[str, str] = {}
    warnings: list[str] = []
    for uid, planned in expected.items():
        tokens, source = actual_entry_token_measurement(actual_rows[uid])
        token_map[uid] = tokens
        token_sources[uid] = source
        if not measurement_only and tokens > int(planned["hard_limit"]):
            raise WorldBuilderError(f"entry UID {uid} actual tokens {tokens} exceed hard per-entry limit {planned['hard_limit']}")
        if not measurement_only and tokens > int(planned["soft_target"]):
            warnings.append(f"entry UID {uid} actual tokens {tokens} exceed soft target {planned['soft_target']}")
    constant_tokens = sum(token_map[uid] for uid, row in expected.items() if row["constant"])
    if not measurement_only and constant_tokens > int(targets["constant_hard"]) and not deviation_covers(plan, "constant_hard", constant_tokens):
        raise WorldBuilderError(f"output constant lore cost {constant_tokens} exceeds hard limit {targets['constant_hard']}")
    card_tokens = _card_token_breakdown(data)
    permanent_tokens = card_tokens["permanent_tokens"]
    opening_tokens = card_tokens["opening_tokens"]
    non_prompt_tokens = card_tokens["non_prompt_tokens"]
    if not measurement_only and permanent_tokens > int(targets["permanent_card_hard"]) and not deviation_covers(plan, "permanent_card_hard", permanent_tokens):
        raise WorldBuilderError(f"permanent card cost {permanent_tokens} exceeds hard limit {targets['permanent_card_hard']}")
    if not measurement_only and permanent_tokens > int(targets["permanent_card_target"]):
        warnings.append(f"permanent card cost {permanent_tokens} exceeds target {targets['permanent_card_target']}")
    if not measurement_only and opening_tokens > int(targets["permanent_card_target"]):
        warnings.append(
            f"opening cost (first message, one active alternate greeting, and example dialogue) "
            f"{opening_tokens} exceeds {targets['permanent_card_target']}; this is chat history, not a "
            f"permanent cost, so it is reported but never blocks delivery"
        )
    if manifest is not None:
        source_rows = _manifest_rows(manifest)
        source_edges, _required = _required_edges(manifest)
        simulations = run_simulations(source_rows, source_edges, token_map, targets, plan.get("project_simulations", []), memo=memo)
        blocked = [row for row in simulations if row["pressure"] == "blocked"]
        still_blocked = [row for row in blocked if not deviation_covers(plan, row["name"], row["estimated_tokens"])]
        if still_blocked and not measurement_only:
            row = next((value for value in still_blocked if value["name"] == "worst_case_recursion_path"), None)
            row = row or max(still_blocked, key=lambda value: value["estimated_tokens"] - value["hard_limit"])
            raise WorldBuilderError(f"output {row['name']} activation estimate {row['estimated_tokens']} exceeds hard limit {row['hard_limit']}")
        if not measurement_only:
            warnings.extend(
                f"output {row['name']} activation estimate {row['estimated_tokens']} exceeds target {row['target']}"
                for row in simulations if row["pressure"] == "warning"
            )
            warnings.extend(
                f"output {row['name']} activation estimate {row['estimated_tokens']} exceeds hard limit {row['hard_limit']} "
                "but is covered by an approved deviation recorded in the plan"
                for row in blocked if row not in still_blocked
            )
        else:
            warnings.append("auto context-window mode: output limits are measurement-only until the post-merge review is recorded")
    else:
        simulations = []
    return {
        "entries_checked": len(expected), "entry_tokens": token_map, "entry_token_sources": token_sources,
        "constant_tokens": constant_tokens,
        "permanent_tokens": permanent_tokens, "opening_tokens": opening_tokens, "non_prompt_tokens": non_prompt_tokens,
        "total_authored_tokens": sum(token_map.values()), "simulations": simulations, "warnings": warnings,
    }


def predict_drop_order(entries: list[dict[str, Any]], token_budget: int, detail_level: str | None = None) -> dict[str, Any]:
    """Replicates SillyTavern's own runtime drop algorithm (weight desc,
    then order desc, then uid asc, verified against the engine's own
    documented sort) to predict, before generation, exactly what a given
    token_budget would keep and drop from an activation set. Constant
    entries are inserted first, unconditionally, ahead of the sort that
    applies to the rest (also the engine's own documented behavior).

    Each entry needs: uid, tokens, weight, insertion_order, constant,
    protected_categories (from placement_contract.py's per-entry detail;
    weight and protected_categories did not exist before Batch 5's 5.5 fix).
    This is a prediction, not a guarantee about any specific SillyTavern
    build's exact runtime behavior; it exists to catch a protected entry
    sorting below the line before the user ever sees it happen live.
    """
    if not isinstance(token_budget, int) or isinstance(token_budget, bool) or token_budget <= 0:
        raise WorldBuilderError("token_budget must be a positive integer")
    constant_entries = [e for e in entries if e.get("constant")]
    conditional_entries = [e for e in entries if not e.get("constant")]
    normalized_detail = (detail_level or "runtime").strip().casefold().replace("-", "_").replace(" ", "_")
    if normalized_detail in {"maximum", "maximum_detail", "full_detail"}:
        key_fn = lambda e: (-int(e["weight"]), -int(e.get("tokens") or 0), -int(e.get("insertion_order") or 0), str(e["uid"]))
        scoring_mode = "maximum_detail_prefers_richer_ties"
    elif normalized_detail in {"compact", "quick"}:
        key_fn = lambda e: (-int(e["weight"]), int(e.get("tokens") or 0), -int(e.get("insertion_order") or 0), str(e["uid"]))
        scoring_mode = "compact_prefers_smaller_ties"
    else:
        key_fn = lambda e: (-int(e["weight"]), -int(e.get("insertion_order") or 0), str(e["uid"]))
        scoring_mode = "sillytavern_runtime_order"
    ordered = sorted(conditional_entries, key=key_fn)
    kept: list[dict[str, Any]] = []
    dropped: list[dict[str, Any]] = []
    running = sum(int(e["tokens"]) for e in constant_entries)
    for entry in ordered:
        tokens = int(entry["tokens"])
        if running + tokens <= token_budget:
            kept.append(entry)
            running += tokens
        else:
            dropped.append(entry)
    dropped_protected = [e for e in dropped if e.get("protected_categories")]
    return {
        "token_budget": token_budget,
        "constant_tokens": sum(int(e["tokens"]) for e in constant_entries),
        "kept_uids": [e["uid"] for e in constant_entries] + [e["uid"] for e in kept],
        "kept_tokens": running,
        "dropped": [
            {
                "uid": e["uid"], "name": e.get("name", ""), "tokens": int(e["tokens"]),
                "weight": e["weight"], "insertion_order": e.get("insertion_order"),
                "protected_categories": list(e.get("protected_categories", [])),
            }
            for e in dropped
        ],
        "dropped_count": len(dropped),
        "any_protected_dropped": bool(dropped_protected),
        "protected_uids_dropped": [e["uid"] for e in dropped_protected],
        "detail_level": detail_level,
        "scoring_mode": scoring_mode,
    }


def recommend_token_budget(entries: list[dict[str, Any]], worst_case_hard: int, detail_level: str | None = None) -> dict[str, Any]:
    """5.5: recommend token_budget at the worst-case cost when it fits;
    otherwise the largest value that fits, plus the predicted drops. Never
    silently over-provisions: the number shipped in Creator Notes is
    exactly what this specific build was measured against, not a round
    default."""
    worst_case_cost = sum(int(e["tokens"]) for e in entries)
    if worst_case_cost <= 0:
        raise WorldBuilderError("recommend_token_budget requires at least one entry with a positive token cost")
    if worst_case_cost <= worst_case_hard:
        # The recommendation IS the build's actual measured worst case: exactly
        # calibrated, nothing over-provisioned. Testing the prediction against
        # that same total necessarily drops nothing (the budget equals the sum
        # of everything in it); that emptiness is the point, not a no-op.
        prediction = predict_drop_order(entries, worst_case_cost, detail_level)
        return {"recommended_token_budget": worst_case_cost, "fits_worst_case": True, "prediction": prediction}
    # Defensive only: analyze_manifest/analyze_output already block a worst case
    # that exceeds worst_case_hard, so this should not occur post-delivery. If
    # called somewhere that guarantee does not hold, recommend the hard ceiling
    # and report exactly what it drops; never claim a number this build
    # cannot actually deliver on.
    prediction = predict_drop_order(entries, worst_case_hard, detail_level)
    return {"recommended_token_budget": worst_case_hard, "fits_worst_case": False, "prediction": prediction}


def build_assignment_context(plan: dict[str, Any], detail: dict[str, Any], uids: list[Any]) -> dict[str, Any]:
    wanted = [uid_key(uid) for uid in uids]
    by_uid = {uid_key(row["uid"]): row for row in detail["entries"]}
    missing = [uid for uid in wanted if uid not in by_uid]
    if missing:
        raise WorldBuilderError("budget assignment context requests unknown UIDs: " + ", ".join(missing))
    result = {
        "contract": CONTRACT,
        "profile_id": plan["profile_id"],
        "profile_label": plan["profile_label"],
        "estimator": plan["estimator"],
        "lorebook_token_budget": plan["targets"]["lorebook_token_budget"],
        "entries": [by_uid[uid] for uid in wanted],
        "warnings": [warning for warning in detail["warnings"] if any(f"UID {uid} " in warning for uid in wanted)],
    }
    if plan.get("context_window_mode") == "auto":
        result["context_window_mode"] = "auto"
        result["generation_unconstrained"] = True
    return result


def declared_fan_out_ceiling(plan: dict[str, Any], manifest: dict[str, Any]) -> dict[str, Any]:
    """The build's declared activation fan-out ceiling, empty when none is declared.

    A ceiling is optional so a build that declares none is unaffected. When one is
    declared the output stage refuses to pass an artifact whose measured fan-out
    exceeds it. Measured fan-out is what the runtime does, not what the declared
    activation graph says: on a real 390-entry multi-era card the manifest declared
    81 edges, yet enabling a single era root activated 92 entries from an empty
    message. The graph gates all passed while that gap stayed invisible.
    """
    candidates: list[dict[str, Any]] = []
    architecture = manifest.get("architecture") if isinstance(manifest, dict) else None
    if isinstance(architecture, dict) and isinstance(architecture.get("fan_out_ceiling"), dict):
        candidates.append(architecture["fan_out_ceiling"])
    if isinstance(plan.get("fan_out_ceiling"), dict):
        candidates.append(plan["fan_out_ceiling"])
    merged: dict[str, Any] = {}
    for candidate in candidates:
        for key in ("max_activated_count", "max_activated_fraction"):
            if candidate.get(key) is not None:
                merged[key] = candidate[key]
    return merged


def evaluate_fan_out_ceiling(
    scan_check: dict[str, Any] | None,
    ceiling: dict[str, Any],
) -> dict[str, Any]:
    """Compare a measured activation scan against the declared fan-out ceiling.

    Three honest outcomes: `skipped` when the build declares no ceiling, `unmeasured`
    when one is declared but no scan report is bound to the current artifact bytes
    (an absent measurement must never read as a pass), and `passed` or `exceeded`
    once a real measurement exists.
    """
    if not ceiling:
        return {"status": "skipped", "reason": "no fan_out_ceiling declared"}
    if scan_check is None:
        return {
            "status": "unmeasured",
            "ceiling": ceiling,
            "reason": "no activation scan report is bound to the current artifact bytes",
        }
    count = scan_check.get("max_activated_count")
    eligible = scan_check.get("eligible_entry_count")
    fraction = scan_check.get("max_activated_fraction")
    if fraction is None and isinstance(count, int) and isinstance(eligible, int) and eligible:
        fraction = count / eligible
    exceeded: list[str] = []
    limit_count = ceiling.get("max_activated_count")
    if limit_count is not None and isinstance(count, int) and count > int(limit_count):
        exceeded.append(f"max_activated_count {count} exceeds {int(limit_count)}")
    limit_fraction = ceiling.get("max_activated_fraction")
    if limit_fraction is not None and fraction is not None and fraction > float(limit_fraction):
        exceeded.append(f"max_activated_fraction {fraction:.4f} exceeds {float(limit_fraction):.4f}")
    return {
        "status": "exceeded" if exceeded else "passed",
        "ceiling": ceiling,
        "measured": {
            "max_activated_count": count,
            "max_activated_fraction": fraction,
            "eligible_entry_count": eligible,
        },
        "exceeded": exceeded,
    }


def load_activation_scan_check(root: Path, state: dict[str, Any], target_path: Path) -> dict[str, Any] | None:
    """Batch 55: reuse a real st_activation_scanner report when one was
    already computed for this exact artifact. The empirical numbers are
    recorded as a cross-check beside the declared-graph estimates. The
    declared worst case still gates; nothing here weakens a limit."""
    path = resolve_state_path(root, state, "activation_scan_report", required=False)
    if path is None:
        fallback = root / "artifacts" / "activation-scan-report.json"
        path = fallback if fallback.exists() else None
    if path is None or not path.exists():
        return None
    try:
        report = load_json(path)
    except (WorldBuilderError, OSError, ValueError):
        return None
    if not isinstance(report, dict) or report.get("target_sha256") != sha256_file(target_path):
        return None
    return {
        "report": str(path.relative_to(root)).replace("\\", "/"),
        "report_sha256": sha256_file(path),
        "max_activated_count": report.get("max_activated_count"),
        "max_activated_fraction": report.get("max_activated_fraction"),
        "eligible_entry_count": report.get("eligible_entry_count"),
        "message_count": report.get("message_count"),
        "majority_activation_flagged": report.get("majority_activation_flagged"),
        "reused": True,
    }


def validate(build_state: str, stage: str = "planning", output: str | None = None, *, write_receipt: bool = True) -> dict[str, Any]:
    root, state = load_build_state(build_state)
    manifest_path = resolve_state_path(root, state, "manifest")
    if not manifest_path.exists():
        raise WorldBuilderError("manifest is missing")
    manifest = load_json(manifest_path)
    if not isinstance(manifest, dict):
        raise WorldBuilderError("manifest must be an object")
    plan, plan_path = load_bound_plan(root, state, manifest)
    # Batch 55: one shared closure memo per validation call. The output
    # stage re-estimates the same simulations with measured tokens; without
    # this it re-walks the entire graph the planning pass just walked.
    simulation_memo: dict[Any, list[str]] = {}
    detail = analyze_manifest(plan, manifest, memo=simulation_memo) if plan.get("applicable") else {
        "entry_count": len(_manifest_rows(manifest)), "entries": [], "constant_tokens": 0,
        "corpus_authored_tokens": 0, "layer_totals": {}, "era_totals": {},
        "simulations": [_simulation(name, [], [], {}, 0, 1) for name in SIMULATION_NAMES], "warnings": [],
    }
    output_detail = None
    target_path: Path | None = None
    if stage == "output":
        target_path = Path(output).resolve() if output else resolve_state_path(root, state, "final_output")
        if not target_path.exists():
            raise WorldBuilderError("budget output target is missing")
        data = load_json(target_path)
        if not isinstance(data, dict):
            raise WorldBuilderError("budget output target must be a JSON object")
        if plan.get("applicable"):
            output_detail = analyze_output(plan, detail, data, manifest, memo=simulation_memo)
            scan_check = load_activation_scan_check(root, state, target_path)
            if scan_check is not None:
                output_detail["activation_scan_check"] = scan_check
            output_detail["fan_out_ceiling"] = evaluate_fan_out_ceiling(
                scan_check, declared_fan_out_ceiling(plan, manifest)
            )
    elif stage != "planning":
        raise WorldBuilderError("budget stage must be planning or output")
    receipt = {
        "kind": RECEIPT_KIND, "receipt_version": RECEIPT_VERSION, "status": "passed",
        "stage": stage, "contract": CONTRACT, "build_id": state.get("build_id"),
        "profile_id": plan["profile_id"], "profile_label": plan["profile_label"],
        "manifest": str(manifest_path.relative_to(root)).replace("\\", "/"),
        "manifest_sha256": sha256_file(manifest_path),
        "budget_plan": str(plan_path.relative_to(root)).replace("\\", "/"),
        "budget_plan_sha256": sha256_file(plan_path),
        "default_profile_sha256": sha256_file(resolve_state_path(root, state, "default_profile")),
        "entry_count": detail["entry_count"], "constant_tokens": detail["constant_tokens"],
        "corpus_authored_tokens": detail["corpus_authored_tokens"],
        "layer_totals": detail["layer_totals"], "era_totals": detail["era_totals"],
        "simulations": detail["simulations"], "warnings": detail["warnings"],
        "target": str(target_path.relative_to(root)).replace("\\", "/") if target_path else None,
        "target_sha256": sha256_file(target_path) if target_path else None,
        "fan_out_ceiling": declared_fan_out_ceiling(plan, manifest),
        "output": output_detail,
    }
    if stage == "output" and (output_detail or {}).get("fan_out_ceiling", {}).get("status") == "exceeded":
        receipt["status"] = "failed"
    if write_receipt:
        key = "budget_output_receipt" if stage == "output" else "budget_planning_receipt"
        receipt_path = resolve_state_path(root, state, key)
        atomic_write_json(receipt_path, receipt)
        receipt["receipt"] = str(receipt_path.relative_to(root)).replace("\\", "/")
        receipt["receipt_sha256"] = sha256_file(receipt_path)
    if receipt["status"] == "failed":
        raise WorldBuilderError(
            "budget output gate: measured activation fan-out exceeds the declared fan_out_ceiling ("
            + "; ".join((output_detail or {}).get("fan_out_ceiling", {}).get("exceeded") or [])
            + ")"
        )
    return receipt


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--build-state", required=True)
    parser.add_argument("--stage", choices=("planning", "output"), default="planning")
    parser.add_argument("--output")
    parser.add_argument("--probe-measured-tokens", action="store_true",
                         help="5.7: optional tiktoken probe for the output stage. No effect on "
                              "planning (manifests carry no prose yet) or when tiktoken is not "
                              "installed; ceil(UTF-8 bytes/4) remains correct either way.")
    parser.add_argument("--requirements", action="store_true", help="Read-only preflight: print what this gate checks against the current build state.")
    args = parser.parse_args()
    if args.requirements:
        root, state = load_build_state(args.build_state)
        print(json.dumps(preflight_report("budget_contract", requirement_rows(Path(__file__), root, state)), ensure_ascii=False, indent=2))
        return 0
    try:
        if args.probe_measured_tokens and args.stage == "output":
            root, state = load_build_state(args.build_state)
            target_path = Path(args.output).resolve() if args.output else resolve_state_path(root, state, "final_output")
            data = load_json(target_path)
            annotated, probed_count = annotate_measured_tokens(data)
            if probed_count:
                atomic_write_json(target_path, annotated)
                print(f"[worldbuilder] tiktoken probed {probed_count} entries; measured_tokens written to {target_path}", file=sys.stderr)
            else:
                print("[worldbuilder] tiktoken unavailable or produced nothing; falling back to ceil(UTF-8 bytes/4) as before", file=sys.stderr)
        print(json.dumps(validate(args.build_state, args.stage, args.output, write_receipt=True), ensure_ascii=False, indent=2))
        return 0
    except (WorldBuilderError, OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
