#!/usr/bin/env python3
"""Prune revamp: ancestor-redundancy candidates.

Wires dominator_analysis.py's structural algorithm to a real manifest's
activation graph. This module's job stops at a purely structural fact:
for a given entry, which other entries are GUARANTEED to also be in
context whenever it is. It never inspects prose, never compares content,
never decides whether any specific overlap is worth cutting; per
DR-062, that reading-comprehension question belongs to an auditor. This
module's output is, at most, the list of places to look.

Card-shell redundancy (the second free win: the permanent card shell is
always in context, so anything an entry restates from Description /
Personality / System Prompt is guaranteed waste) is the same idea with a
trivial "dominator set": every entry's dominator set implicitly includes
the permanent shell, unconditionally, since it needs no graph path at
all.
"""
from __future__ import annotations

from typing import Any

from activation_semantics import manifest_entries as _entries, profile_defaults as _profile_defaults, resolved_emit as _resolved_emit, uid_key
from budget_semantics import required_edges as _required_edges
from dominator_analysis import VIRTUAL_ROOT, build_virtual_rooted_edges, compute_dominators, dominator_set


def resolve_entry_flags(manifest: dict[str, Any], profile: dict[str, Any]) -> dict[str, dict[str, Any]]:
    """Per-UID resolved constant/vectorized/delay_until_recursion, via the
    same _profile_defaults/_resolved_emit primitives activation_map_gate.py
    itself uses: never a second, independently-derived reading of what
    these fields resolve to."""
    resolved: dict[str, dict[str, Any]] = {}
    for row in _entries(manifest):
        uid = uid_key(row.get("uid", row.get("id")))
        arch = row.get("architecture") if isinstance(row.get("architecture"), dict) else {}
        layer = str(arch.get("layer", ""))
        defaults = _profile_defaults(profile, layer)
        resolved[uid] = _resolved_emit(row, defaults)
    return resolved


CARD_SHELL_FIELDS = ("description", "personality", "system_prompt")


def card_shell_redundancy_targets(manifest: dict[str, Any], card_data: dict[str, Any]) -> dict[str, Any]:
    """Prune revamp's second free win: the permanent card shell (name
    Description / Personality / System Prompt specifically, always in
    context for every message, unlike first_mes/mes_example/
    alternate_greetings, which are turn-specific) is always in context,
    needing no activation graph path at all. Unlike ancestor_redundancy_
    candidates, this has no delay_until_recursion or vectorized
    eligibility restriction: those exceptions exist because they
    determine whether an entry's GRAPH-based ancestors are guaranteed,
    and the shell's presence does not depend on the graph in any way.
    Every entry with real content is eligible, unconditionally.

    Same discipline as ancestor_redundancy_candidates: this returns the
    shell text and the set of eligible UIDs, structure only. It does not,
    and must not, try to detect whether any entry's prose actually
    restates anything from the shell; per DR-062, that reading-
    comprehension question belongs to an auditor. This function's job is
    at most to hand that auditor the shell text and the list of entries
    to check it against.
    """
    from activation_semantics import manifest_entries as _entries, uid_key

    shell_text = {
        field: str(card_data.get(field, "")) for field in CARD_SHELL_FIELDS
        if isinstance(card_data.get(field), str) and card_data.get(field).strip()
    }
    eligible_uids = sorted(
        uid_key(row.get("uid", row.get("id"))) for row in _entries(manifest)
    )
    return {
        "shell_text": shell_text,
        "eligible_uids": eligible_uids,
        "note": (
            "The shell fields listed here are unconditionally in context for every entry above, "
            "regardless of activation state; this is a structural guarantee, not a claim that any "
            "specific entry actually repeats shell content. Whether an entry's prose restates "
            "anything from the shell is a reading-comprehension question for an auditor."
        ),
    }
def ancestor_redundancy_candidates(manifest: dict[str, Any], profile: dict[str, Any]) -> dict[str, Any]:
    """For every entry that can safely participate as C (the entry whose
    own redundancy is being checked): its full dominator set.

    Three conditions from the plan, applied here:
      - Vectorized entries are skipped entirely: excluded from the
        graph, never a C, never a dominator of anything. Vector retrieval
        is a path this graph does not model at all, so no edge touching
        one is a real edge for dominance purposes.
      - Only entries with delay_until_recursion=True are eligible as C.
        An entry without it could fire directly from chat, bypassing the
        graph path entirely: C being in context would then not
        guarantee anything about its would-be dominators.
      - excludeRecursion/preventRecursion need no separate handling here:
        activation_map_gate.py's own manifest validation already
        guarantees the graph's edges never violate either constraint
        (an excludeRecursion entry cannot have incoming edges; a
        preventRecursion entry cannot have outgoing ones), so the edges
        read from the manifest are already "real" with respect to both.

    Entries NOT eligible as C are still fully valid as ancestors of
    something else's dominator set: the exception is about whether C's
    own presence is guaranteed via the graph, not about the properties of
    entries elsewhere in the chain.
    """
    resolved = resolve_entry_flags(manifest, profile)
    vectorized_uids = {uid for uid, r in resolved.items() if r.get("vectorized")}
    constant_uids = [uid for uid, r in resolved.items() if r.get("constant")]
    delay_uids = {uid for uid, r in resolved.items() if r.get("delay_until_recursion")}

    graph_edges_raw, _required = _required_edges(manifest)
    graph_edges = [
        edge for edge in graph_edges_raw
        if uid_key(edge.get("source_uid")) not in vectorized_uids
        and uid_key(edge.get("target_uid")) not in vectorized_uids
    ]

    # Seeds: any non-vectorized entry that could fire directly from chat,
    # i.e. everything except delay_until_recursion entries, which can only
    # be reached via recursion, never as a direct seed themselves.
    direct_seed_uids = [uid for uid in resolved if uid not in vectorized_uids and uid not in delay_uids]

    virtual_edges = build_virtual_rooted_edges(direct_seed_uids, constant_uids, graph_edges)
    idom = compute_dominators(VIRTUAL_ROOT, virtual_edges)

    candidates: dict[str, list[str]] = {}
    for uid in delay_uids:
        if uid in vectorized_uids:
            continue
        chain = dominator_set(uid, idom)
        if not chain:
            continue  # unreachable from any seed/constant: nothing to report
        # Ancestors only: everything above uid in its own chain, excluding
        # uid itself and the virtual root (not a real entry to compare against).
        ancestors = [node for node in chain[1:] if node != VIRTUAL_ROOT]
        if ancestors:
            candidates[uid] = ancestors

    return {
        "candidates": candidates,
        "vectorized_excluded": sorted(vectorized_uids),
        "eligible_as_c": sorted(delay_uids - vectorized_uids),
        "note": (
            "Each candidate's ancestor list is a structural guarantee (these entries are "
            "provably in context whenever the candidate is), not a claim that any specific "
            "content is actually repeated. Whether the candidate's prose repeats anything from "
            "an ancestor is a reading-comprehension question for an auditor."
        ),
    }
