#!/usr/bin/env python3
"""Create immutable, read-only phase-boundary knowledge summaries for workers."""
from __future__ import annotations
import json, os
from pathlib import Path
from typing import Any
from wb_common import WorldBuilderError, atomic_write_json, discover_phase_files, iter_entries, load_json, now_iso, resolve_state_path, sha256_bytes, sha256_file

CONTRACT="worldbuilder-shared-state-summary-v1"


def _facts(data: Any) -> list[dict[str, Any]]:
    out=[]
    for ref in iter_entries(data):
        e = ref.entry
        if not isinstance(e,dict): continue
        uid=e.get('uid',e.get('id')); name=e.get('name') or e.get('comment')
        if uid is None or not isinstance(name,str) or not name.strip(): continue
        arch=e.get('architecture') if isinstance(e.get('architecture'),dict) else {}
        aliases=e.get('key') or e.get('keys') or []
        if isinstance(aliases,str): aliases=[aliases]
        out.append({'uid':str(uid),'name':name.strip(),'layer':arch.get('layer') or e.get('layer'),'aliases':[str(x) for x in aliases[:8]] if isinstance(aliases,list) else []})
    return out

def build_summary(root: Path,state:dict[str,Any])->dict[str,Any]:
    phases=resolve_state_path(root,state,'phases',required=False)
    source=[]; facts=[]
    if phases and phases.is_dir():
        for path in discover_phase_files(phases):
            try: data=load_json(path)
            except Exception: continue
            source.append({'path':str(path.relative_to(root)).replace(os.sep,'/'),'sha256':sha256_file(path)})
            facts.extend(_facts(data))
    # deterministic dedupe by UID; completed-phase facts are authoritative for this snapshot.
    by_uid={r['uid']:r for r in facts}
    return {'contract':CONTRACT,'created_at':now_iso(),'build_id':state.get('build_id'),'source_phases':source,'facts':[by_uid[k] for k in sorted(by_uid,key=str)],'read_only':True,'note':'Neutral named facts only; never sibling prose or in-progress output.'}

def ensure_summary(root:Path,state:dict[str,Any])->tuple[Path,dict[str,Any]]:
    data=build_summary(root,state)
    signature=sha256_bytes(json.dumps({'source_phases':data['source_phases'],'facts':data['facts']},sort_keys=True,separators=(',',':')).encode('utf-8'))[:16]
    directory=root/'.work'/'shared-state'; directory.mkdir(parents=True,exist_ok=True)
    path=directory/f'phase-boundary-{signature}.json'
    if not path.exists(): atomic_write_json(path,data)
    else:
        existing=load_json(path)
        if existing.get('facts')!=data.get('facts') or existing.get('source_phases')!=data.get('source_phases'):
            raise WorldBuilderError('immutable shared-state summary path collision')
    return path,load_json(path)
