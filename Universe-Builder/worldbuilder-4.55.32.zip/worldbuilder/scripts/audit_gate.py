#!/usr/bin/env python3
"""Prove that all four hash-bound WorldBuilder auditor jobs completed."""
from __future__ import annotations

import argparse
import json
import re
import sys
from datetime import datetime, timezone
from pathlib import Path
from dispatch_observation import (
    CHILD_RUN_COMPLETION, CHILD_RUNTIME_PARTIAL_KIND, CHILD_RUNTIME_RECEIPT_KIND,
    PARENT_EXEC_COMPLETION, PARENT_OBSERVED_CHILD_RUN, PARENT_OBSERVED_EXEC, RECORDED_BY_PARENT,
)
from typing import Any

from record_audit_runtime import AUDIT_RUNTIME_RECEIPT_VERSION

# Derived from the producer's constant rather than repeated as a literal.
SUPPORTED_AUDIT_RUNTIME_VERSIONS = frozenset({AUDIT_RUNTIME_RECEIPT_VERSION})

from audit_plan import AUDIT_ASSIGNMENT_VERSION, AUDIT_PLAN_VERSION

# Batch 59: plans and assignments written before the iteration ledger are version 3;
# both 3 and the current version must keep validating so in-flight builds continue.
SUPPORTED_AUDIT_PLAN_VERSIONS = frozenset({3, AUDIT_PLAN_VERSION})
SUPPORTED_AUDIT_ASSIGNMENT_VERSIONS = frozenset({3, AUDIT_ASSIGNMENT_VERSION})
from card_text_collision import REPORT_KIND as CARD_TEXT_COLLISION_REPORT_KIND, REPORT_VERSION as CARD_TEXT_COLLISION_REPORT_VERSION
from graphics_designer import REGEX_REPORT_KIND, REGEX_REPORT_VERSION
from ground_truth_graph import REPORT_KIND as GROUND_TRUTH_GRAPH_REPORT_KIND, REPORT_VERSION as GROUND_TRUTH_GRAPH_REPORT_VERSION
from plan_reconciliation import REPORT_KIND as PLAN_RECONCILIATION_REPORT_KIND, REPORT_VERSION as PLAN_RECONCILIATION_REPORT_VERSION
from wb_common import (
    step_driver_pointer,
    AUDIT_LENSES,
    WorldBuilderError,
    atomic_write_json,
    ensure_inside,
    load_build_state,
    load_json,
    normalize_identity,
    normalize_child_session_id,
    preflight_report,
    requirement_rows,
    resolve_state_path,
    sha256_file,
)
from pipeline_stage_gate import advance as advance_pipeline_stage

VALID_SEVERITIES = {"critical", "high", "medium", "low", "info"}
VALID_CHECK_STATUS = {"pass", "warning", "fail", "not_applicable"}
_DURABLE_FINDING_PREFIXES = ("artifacts/", "input/", "creations/", ".work/findings/")
_EPHEMERAL_PATH_RE = re.compile(r"(?i)(?:^|[\s\"'`(])((?:\.work/|/tmp/|/var/tmp/|[A-Z]:/[^\s]*/temp/)[^\s,;)\]}]*)")


def validate_finding_evidence_paths(finding: dict[str, Any], result_name: str, finding_id: str) -> None:
    """Reject audit evidence pointers that cleanup would make unverifiable."""
    evidence_paths = finding.get("evidence_paths")
    if evidence_paths is not None:
        if not isinstance(evidence_paths, list):
            raise WorldBuilderError(f"{result_name} finding {finding_id}: evidence_paths must be a list of durable build-relative paths")
        for raw in evidence_paths:
            if not isinstance(raw, str) or not raw.strip():
                raise WorldBuilderError(f"{result_name} finding {finding_id}: evidence_paths contains an invalid path")
            normalized = raw.replace("\\", "/")
            if normalized.startswith("./"):
                normalized = normalized[2:]
            if normalized.startswith("/") or ".." in Path(normalized).parts or not normalized.startswith(_DURABLE_FINDING_PREFIXES):
                raise WorldBuilderError(
                    f"{result_name} finding {finding_id}: evidence path {raw!r} is not durable; copy proof into "
                    "artifacts/ or .work/findings/<lens>-evidence/ and cite that path instead"
                )
    for field in ("summary", "recommended_action"):
        value = finding.get(field)
        if not isinstance(value, str):
            continue
        normalized_text = value.replace("\\", "/")
        for match in _EPHEMERAL_PATH_RE.finditer(normalized_text):
            cited = match.group(1)
            if cited.startswith(".work/findings/"):
                continue
            raise WorldBuilderError(
                f"{result_name} finding {finding_id}: {field} cites ephemeral evidence path {cited!r}; "
                "copy it into .work/findings/<lens>-evidence/ (or artifacts/) and cite the durable copy"
            )



def rel(path: Path, root: Path) -> str:
    return str(path.relative_to(root)).replace("\\", "/")


def parse_timestamp(value: Any, field: str) -> datetime:
    if not isinstance(value, str) or not value.strip():
        raise WorldBuilderError(f"{field} is missing")
    text = value.strip().replace("Z", "+00:00")
    try:
        parsed = datetime.fromisoformat(text)
    except ValueError as exc:
        raise WorldBuilderError(f"{field} is not a valid ISO timestamp") from exc
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def path_from_root(root: Path, value: Any, allowed_root: Path) -> Path:
    if not isinstance(value, str) or not value.strip():
        raise WorldBuilderError("audit path is missing")
    raw = Path(value)
    if raw.is_absolute():
        raise WorldBuilderError("audit paths must be relative to the build root")
    path = (root / raw).resolve()
    ensure_inside(path, allowed_root)
    return path


def uid_set(value: Any, field: str) -> set[Any]:
    if not isinstance(value, list):
        raise WorldBuilderError(f"{field} must be a list")
    result: set[Any] = set()
    for item in value:
        raw = item.get("uid", item.get("id")) if isinstance(item, dict) else item
        uid = normalize_identity(raw)
        if uid is None:
            raise WorldBuilderError(f"{field} contains an item without uid/id")
        if uid in result:
            raise WorldBuilderError(f"{field} repeats UID {uid!r}")
        result.add(uid)
    return result


def validate_runtime(
    runtime_path: Path,
    *,
    assignment: dict[str, Any],
    assignment_path: Path,
    result_path: Path,
) -> dict[str, Any]:
    if not runtime_path.exists():
        raise WorldBuilderError(f"missing parent-observed runtime receipt: {runtime_path}. After the child completion event, record it with record_audit_runtime.py (--stage/--lens per this assignment)")
    runtime = load_json(runtime_path)
    if not isinstance(runtime, dict) or runtime.get("kind") != CHILD_RUNTIME_RECEIPT_KIND or runtime.get("receipt_version") not in SUPPORTED_AUDIT_RUNTIME_VERSIONS:
        raise WorldBuilderError(f"{runtime_path.name} is not a WorldBuilder child runtime receipt v2")
    if runtime.get("runtime_source") != PARENT_OBSERVED_CHILD_RUN or runtime.get("recorded_by") != RECORDED_BY_PARENT:
        raise WorldBuilderError(f"{runtime_path.name} does not identify a parent-observed child-run completion")
    expected = {
        "build_id": assignment.get("build_id"),
        "audit_run_id": assignment.get("audit_run_id"),
        "assignment_id": assignment.get("assignment_id"),
        "assignment_sha256": sha256_file(assignment_path),
        "lens": assignment.get("lens"),
        "auditor": assignment.get("auditor"),
        "taskName": assignment.get("taskName"),
        "status": "completed",
        "result": assignment.get("output"),
        "result_sha256": sha256_file(result_path),
        "terminal_delimiter": assignment.get("expected_end_delimiter"),
    }
    for key, value in expected.items():
        if runtime.get(key) != value:
            raise WorldBuilderError(f"{runtime_path.name} mismatch at {key}: {runtime.get(key)!r} != {value!r}")
    session_id = runtime.get("child_session_id")
    if not isinstance(session_id, str) or not session_id.strip():
        raise WorldBuilderError(f"{runtime_path.name} has no child_session_id")
    spawned_at = parse_timestamp(runtime.get("spawned_at"), f"{runtime_path.name}.spawned_at")
    completed_at = parse_timestamp(runtime.get("completed_at"), f"{runtime_path.name}.completed_at")
    created_raw = assignment.get("created_at")
    if created_raw is not None:
        created_at = parse_timestamp(created_raw, f"{assignment_path.name}.created_at")
        if spawned_at < created_at:
            raise WorldBuilderError(f"{runtime_path.name} spawned_at precedes assignment creation")
    if completed_at < spawned_at:
        raise WorldBuilderError(f"{runtime_path.name} completed_at precedes spawned_at")
    if runtime.get("source") != CHILD_RUN_COMPLETION:
        raise WorldBuilderError(f"{runtime_path.name} was not recorded from a parent-observed child completion event")
    event_id = runtime.get("runtime_event_id")
    if not isinstance(event_id, str) or not event_id.strip():
        raise WorldBuilderError(f"{runtime_path.name} has no runtime_event_id")
    run_id = runtime.get("run_id")
    if not isinstance(run_id, str) or not run_id.strip():
        raise WorldBuilderError(f"{runtime_path.name} has no child-run run_id")
    parent_id = runtime.get("parent_session_id")
    if not isinstance(parent_id, str) or not parent_id.strip():
        raise WorldBuilderError(f"{runtime_path.name} has no parent_session_id")
    if normalize_child_session_id(parent_id) == normalize_child_session_id(session_id):
        raise WorldBuilderError(f"{runtime_path.name} parent_session_id equals child_session_id")
    return runtime


def validate_result(
    result_path: Path,
    *,
    assignment: dict[str, Any],
    assignment_path: Path,
) -> dict[str, Any]:
    if not result_path.exists():
        raise WorldBuilderError(f"missing audit result: {result_path}. Dispatch this auditor from the audit plan assignment, wait for its completion event, then re-run this gate")
    result = load_json(result_path)
    if not isinstance(result, dict) or result.get("kind") != "worldbuilder-audit-result" or result.get("result_version") != 2:
        raise WorldBuilderError(f"{result_path.name} is not a structured audit result v2")
    meta = result.get("_worldbuilder")
    if not isinstance(meta, dict):
        raise WorldBuilderError(f"{result_path.name} lacks _worldbuilder metadata")
    expected = {
        "build_id": assignment.get("build_id"),
        "audit_run_id": assignment.get("audit_run_id"),
        "assignment_id": assignment.get("assignment_id"),
        "assignment_sha256": sha256_file(assignment_path),
        "stage": assignment.get("stage"),
        "lens": assignment.get("lens"),
        "auditor": assignment.get("auditor"),
        "taskName": assignment.get("taskName"),
        "scope_sha256": assignment.get("scope_sha256"),
        "target": assignment.get("target"),
        "target_sha256": assignment.get("target_sha256"),
        "manifest_sha256": assignment.get("manifest_sha256"),
        "completed": True,
        "runtime_status": "completed",
        "terminal_delimiter": assignment.get("expected_end_delimiter"),
    }
    for key, value in expected.items():
        if meta.get(key) != value:
            raise WorldBuilderError(f"{result_path.name} metadata mismatch at {key}")
    echoed_session_id = meta.get("child_session_id")
    if echoed_session_id is not None and (not isinstance(echoed_session_id, str) or not echoed_session_id.strip()):
        raise WorldBuilderError(f"{result_path.name} has an invalid optional child_session_id")

    expected_uids = uid_set(assignment.get("entries", []), f"{assignment_path.name}.entries")
    coverage = result.get("coverage")
    if not isinstance(coverage, dict):
        raise WorldBuilderError(f"{result_path.name} lacks coverage; the audit result must carry coverage.assigned_uids and coverage.reviewed_uids listing every UID the assignment assigned")
    assigned_uids = uid_set(coverage.get("assigned_uids"), f"{result_path.name}.coverage.assigned_uids")
    reviewed_uids = uid_set(coverage.get("reviewed_uids"), f"{result_path.name}.coverage.reviewed_uids")
    if assigned_uids != expected_uids or reviewed_uids != expected_uids:
        raise WorldBuilderError(f"{result_path.name} does not prove exact UID coverage")

    expected_artifacts = assignment.get("required_artifacts")
    inspected_artifacts = result.get("artifacts_inspected")
    if not isinstance(expected_artifacts, list) or not isinstance(inspected_artifacts, list):
        raise WorldBuilderError(f"{result_path.name} must report required artifacts inspected")
    expected_artifact_map = {
        str(row.get("path")): str(row.get("sha256"))
        for row in expected_artifacts if isinstance(row, dict) and row.get("path") and row.get("sha256")
    }
    observed_artifact_map: dict[str, str] = {}
    for row in inspected_artifacts:
        if not isinstance(row, dict) or not isinstance(row.get("path"), str) or not isinstance(row.get("sha256"), str):
            raise WorldBuilderError(f"{result_path.name} has an invalid artifacts_inspected row")
        if row["path"] in observed_artifact_map:
            raise WorldBuilderError(f"{result_path.name} repeats inspected artifact {row['path']}")
        observed_artifact_map[row["path"]] = row["sha256"]
    if observed_artifact_map != expected_artifact_map:
        missing = sorted(set(expected_artifact_map) - set(observed_artifact_map))
        extra = sorted(set(observed_artifact_map) - set(expected_artifact_map))
        mismatched = sorted(
            key for key in set(expected_artifact_map) & set(observed_artifact_map)
            if expected_artifact_map[key] != observed_artifact_map[key]
        )

        def _cap(rows: list[str]) -> str:
            shown = ", ".join(str(row) for row in rows[:6])
            return shown + (f" (+{len(rows) - 6} more)" if len(rows) > 6 else "")

        detail: list[str] = []
        if missing:
            detail.append("missing rows: " + _cap(missing))
        if extra:
            detail.append("extra rows the assignment did not require: " + _cap(extra))
        if mismatched:
            detail.append(
                "sha256 mismatches: " + _cap(
                    [f"{key} expected {str(expected_artifact_map[key])[:12]} found {str(observed_artifact_map[key])[:12]}" for key in mismatched]
                )
            )
        raise WorldBuilderError(
            f"{result_path.name} does not prove exact supporting-artifact inspection: " + "; ".join(detail)
            + ". Every required row must appear exactly once with the exact SHA-256, and no additional row is allowed."
        )

    expected_entries = {
        normalize_identity(row.get("uid")): str(row.get("path"))
        for row in assignment.get("entries", []) if isinstance(row, dict)
    }
    reviewed_entries = result.get("reviewed_entries")
    if not isinstance(reviewed_entries, list):
        raise WorldBuilderError(f"{result_path.name} reviewed_entries must be a list")
    reviewed_entry_map: dict[Any, str] = {}
    for row in reviewed_entries:
        if not isinstance(row, dict):
            raise WorldBuilderError(f"{result_path.name} reviewed_entries rows must be objects")
        uid = normalize_identity(row.get("uid", row.get("id")))
        path = row.get("path")
        status = row.get("status")
        note = row.get("note")
        if uid is None or uid in reviewed_entry_map or not isinstance(path, str):
            raise WorldBuilderError(f"{result_path.name} has invalid/duplicate reviewed entry")
        if status not in VALID_CHECK_STATUS:
            raise WorldBuilderError(f"{result_path.name} reviewed entry {uid!r} has invalid status")
        if not isinstance(note, str) or len(note.strip()) < 20:
            raise WorldBuilderError(f"{result_path.name} reviewed entry {uid!r} lacks a substantive note")
        reviewed_entry_map[uid] = path
    if reviewed_entry_map != expected_entries:
        missing_uids = sorted((set(expected_entries) - set(reviewed_entry_map)), key=str)
        extra_uids = sorted((set(reviewed_entry_map) - set(expected_entries)), key=str)
        path_mismatches = sorted(
            (uid, reviewed_entry_map[uid], expected_entries[uid])
            for uid in (set(reviewed_entry_map) & set(expected_entries))
            if reviewed_entry_map[uid] != expected_entries[uid]
        )
        detail_parts = []
        if missing_uids:
            detail_parts.append(f"missing UID(s) {missing_uids} (assigned but not in reviewed_entries)")
        if extra_uids:
            detail_parts.append(f"unexpected UID(s) {extra_uids} (in reviewed_entries but not assigned)")
        if path_mismatches:
            detail_parts.append(
                "path mismatch on UID(s): " + "; ".join(f"{uid!r} reviewed {rp!r} vs assigned {ep!r}" for uid, rp, ep in path_mismatches)
            )
        detail = "; ".join(detail_parts) if detail_parts else "sets match but comparison still failed: check for non-comparable UID types"
        raise WorldBuilderError(
            f"{result_path.name} reviewed_entries do not exactly match assigned UID/path scope: {detail}. "
            "This is a set/mapping comparison (row order in the file does not matter); fix the auditor's "
            "output to cover exactly the assigned UIDs at exactly their assigned paths, then re-save the "
            "result file and re-run audit_gate.py; do not assume this is an ordering problem."
        )

    expected_checks = assignment.get("expected_checks")
    if not isinstance(expected_checks, list) or not expected_checks:
        raise WorldBuilderError(f"{assignment_path.name} has no expected_checks")
    checks = result.get("checks")
    if not isinstance(checks, list):
        raise WorldBuilderError(f"{result_path.name} checks must be a list")
    observed: dict[str, str] = {}
    for check in checks:
        if not isinstance(check, dict):
            raise WorldBuilderError(f"{result_path.name} check rows must be objects")
        check_id = check.get("check_id")
        status = check.get("status")
        if not isinstance(check_id, str) or check_id in observed:
            raise WorldBuilderError(f"{result_path.name} has invalid/duplicate check_id")
        if status not in VALID_CHECK_STATUS:
            raise WorldBuilderError(f"{result_path.name} check {check_id!r} has invalid status")
        note = check.get("note")
        if not isinstance(note, str) or len(note.strip()) < 20:
            raise WorldBuilderError(f"{result_path.name} check {check_id!r} has no substantive note")
        observed[check_id] = status
    if set(observed) != set(expected_checks):
        raise WorldBuilderError(f"{result_path.name} check coverage mismatch")

    findings = result.get("findings")
    if not isinstance(findings, list):
        raise WorldBuilderError(f"{result_path.name} findings must be a list")
    finding_ids: set[str] = set()
    for finding in findings:
        if not isinstance(finding, dict):
            raise WorldBuilderError(f"{result_path.name} findings must contain objects")
        finding_id = finding.get("finding_id")
        if not isinstance(finding_id, str) or not finding_id.strip() or finding_id in finding_ids:
            raise WorldBuilderError(
                f"{result_path.name}: every finding needs a non-empty finding_id that is unique "
                f"within the result (e.g. COMPASS-001, COMPASS-002); got {finding_id!r}"
            )
        finding_ids.add(finding_id)
        if finding.get("severity") not in VALID_SEVERITIES:
            raise WorldBuilderError(
                f"{result_path.name} finding {finding_id}: severity {finding.get('severity')!r} is not "
                f"one of {sorted(VALID_SEVERITIES)}. 'warning' is a check status, not a finding severity"
            )
        for key in ("category", "summary", "recommended_action"):
            if not isinstance(finding.get(key), str) or not finding[key].strip():
                raise WorldBuilderError(f"{result_path.name} finding {finding_id} lacks {key}")
        validate_finding_evidence_paths(finding, result_path.name, finding_id)
        target = finding.get("target")
        if target is not None and (not isinstance(target, str) or (target and not target.startswith("/"))):
            hint = ""
            if isinstance(target, str) and "," in target:
                hint = " Several pointers were joined with commas; use one pointer, or null."
            elif isinstance(target, str) and not target.startswith("/"):
                hint = (" This looks like a file path. findings[].target is a JSON Pointer *into* the "
                        "target file; the file path itself belongs in _worldbuilder.target.")
            elif isinstance(target, list):
                hint = " A list was supplied; use one pointer, or null."
            raise WorldBuilderError(
                f"{result_path.name} finding {finding_id}: target must be a JSON Pointer starting with "
                f"'/' or null; got {target!r}.{hint}"
            )

    verify_ids = assignment.get("verify_ids") or []
    if verify_ids:
        verifications = result.get("verifications")
        if not isinstance(verifications, list):
            raise WorldBuilderError(
                f"{result_path.name} is missing the required verifications array for verify_ids "
                f"{sorted(verify_ids)}; confirm each prior finding as resolved or still open"
            )
        observed_verifications: dict[str, str] = {}
        for row in verifications:
            if not isinstance(row, dict):
                raise WorldBuilderError(f"{result_path.name} verifications rows must be objects")
            verified_id = row.get("finding_id")
            status = row.get("status")
            note = row.get("note")
            if not isinstance(verified_id, str) or not verified_id.strip() or verified_id in observed_verifications:
                raise WorldBuilderError(f"{result_path.name} has an invalid/duplicate verification finding_id")
            if status not in {"resolved", "still_open"}:
                raise WorldBuilderError(
                    f"{result_path.name} verification {verified_id} status must be 'resolved' or 'still_open'"
                )
            if not isinstance(note, str) or len(note.strip()) < 20:
                raise WorldBuilderError(f"{result_path.name} verification {verified_id} lacks a substantive note")
            observed_verifications[verified_id] = status
        expected_verify_ids = {str(item) for item in verify_ids}
        missing = sorted(expected_verify_ids - set(observed_verifications))
        extra = sorted(set(observed_verifications) - expected_verify_ids)
        if missing or extra:
            raise WorldBuilderError(
                f"{result_path.name} verifications do not exactly cover verify_ids (missing={missing}, extra={extra}); "
                "every prior finding must be confirmed resolved or still open"
            )
        still_open = sorted(fid for fid, value in observed_verifications.items() if value == "still_open")
        unreported = sorted(set(still_open) - finding_ids)
        if unreported:
            raise WorldBuilderError(
                f"{result_path.name} verifications mark {unreported} still_open but the findings list does not "
                "re-report them with the same finding_id; a re-audit must not quietly drop a finding it was asked to verify"
            )

    deterministic = assignment.get("deterministic_findings")
    if isinstance(deterministic, dict) and "card_text_key_collisions" in deterministic:
        report = deterministic.get("card_text_key_collisions")
        if not isinstance(report, dict) or report.get("kind") != CARD_TEXT_COLLISION_REPORT_KIND or report.get("report_version") != CARD_TEXT_COLLISION_REPORT_VERSION:
            raise WorldBuilderError(f"{assignment_path.name} has an invalid card-text collision report")
        collisions = report.get("collisions")
        if not isinstance(collisions, list):
            raise WorldBuilderError(f"{assignment_path.name} card-text collision report lacks collisions")
        expected_status = "warning" if collisions else ("pass" if report.get("applicable") else "not_applicable")
        if observed.get("card-text-key-collisions") != expected_status:
            raise WorldBuilderError(
                f"{result_path.name} card-text-key-collisions must be {expected_status!r} for the deterministic report"
            )
        expected_collision_map: dict[Any, dict[str, Any]] = {}
        for row in collisions:
            if not isinstance(row, dict):
                raise WorldBuilderError(f"{assignment_path.name} card-text collision rows must be objects")
            uid = normalize_identity(row.get("uid"))
            if uid is None or uid in expected_collision_map:
                raise WorldBuilderError(f"{assignment_path.name} has invalid/duplicate card-text collision UID")
            expected_collision_map[uid] = row
        observed_collision_map: dict[Any, dict[str, Any]] = {}
        for finding in findings:
            if finding.get("category") != "card_text_key_collision":
                continue
            uid = normalize_identity(finding.get("uid"))
            if uid is None or uid in observed_collision_map:
                raise WorldBuilderError(f"{result_path.name} has invalid/duplicate card_text_key_collision finding UID")
            observed_collision_map[uid] = finding
        if set(observed_collision_map) != set(expected_collision_map):
            raise WorldBuilderError(
                f"{result_path.name} card_text_key_collision findings do not exactly match the deterministic collision UIDs"
            )
        for uid, expected_row in expected_collision_map.items():
            finding = observed_collision_map[uid]
            expected_name = str(expected_row.get("name", ""))
            if finding.get("entry_name") != expected_name:
                raise WorldBuilderError(
                    f"{result_path.name} card-text collision finding for UID {uid!r} must name entry {expected_name!r}"
                )
            if finding.get("target") != expected_row.get("path"):
                raise WorldBuilderError(
                    f"{result_path.name} card-text collision finding for UID {uid!r} must target {expected_row.get('path')!r}"
                )

    if isinstance(deterministic, dict) and "regex_authoring" in deterministic:
        report = deterministic.get("regex_authoring")
        if not isinstance(report, dict) or report.get("kind") != REGEX_REPORT_KIND or report.get("report_version") != REGEX_REPORT_VERSION:
            raise WorldBuilderError(f"{assignment_path.name} has an invalid Regex authoring report")
        expected_findings = report.get("findings")
        if not isinstance(expected_findings, list):
            raise WorldBuilderError(f"{assignment_path.name} Regex authoring report lacks findings")
        expected_status = "warning" if expected_findings else ("pass" if report.get("applicable") else "not_applicable")
        if observed.get("regex-authoring-safety") != expected_status:
            raise WorldBuilderError(f"{result_path.name} regex-authoring-safety must be {expected_status!r} for the deterministic report")
        expected_rows = sorted(
            (str(row.get("category")), str(row.get("script_id")), str(row.get("path")))
            for row in expected_findings if isinstance(row, dict)
        )
        observed_rows = sorted(
            (str(row.get("category")), str(row.get("script_id")), str(row.get("target")))
            for row in findings if isinstance(row, dict) and str(row.get("category", "")).startswith("regex_")
        )
        if observed_rows != expected_rows:
            raise WorldBuilderError(f"{result_path.name} Regex findings do not exactly match the deterministic Regex diagnostics")

    if isinstance(deterministic, dict) and "ground_truth_activation_graph" in deterministic:
        report = deterministic.get("ground_truth_activation_graph")
        if (
            not isinstance(report, dict)
            or report.get("kind") != GROUND_TRUTH_GRAPH_REPORT_KIND
            or report.get("report_version") != GROUND_TRUTH_GRAPH_REPORT_VERSION
        ):
            raise WorldBuilderError(f"{assignment_path.name} has an invalid ground-truth activation-graph report")
        orphans = report.get("orphans")
        if not isinstance(orphans, list):
            raise WorldBuilderError(f"{assignment_path.name} ground-truth activation-graph report lacks orphans")
        declared_diff = report.get("declared_diff")
        divergence = False
        if isinstance(declared_diff, dict):
            for key in ("undeclared_edges", "declared_but_absent_in_content"):
                rows = declared_diff.get(key)
                if not isinstance(rows, list):
                    raise WorldBuilderError(f"{assignment_path.name} ground-truth activation-graph report has invalid {key}")
                divergence = divergence or bool(rows)
        expected_status = "warning" if (orphans or divergence) else ("pass" if report.get("applicable") else "not_applicable")
        if observed.get("ground-truth-activation-graph") != expected_status:
            raise WorldBuilderError(
                f"{result_path.name} ground-truth-activation-graph must be {expected_status!r} for the deterministic report"
            )
        expected_orphans: dict[Any, dict[str, Any]] = {}
        for row in orphans:
            if not isinstance(row, dict):
                raise WorldBuilderError(f"{assignment_path.name} ground-truth orphan rows must be objects")
            uid = normalize_identity(row.get("uid"))
            if uid is None or uid in expected_orphans:
                raise WorldBuilderError(f"{assignment_path.name} has invalid/duplicate ground-truth orphan UID")
            expected_orphans[uid] = row
        observed_orphans: dict[Any, dict[str, Any]] = {}
        for finding in findings:
            if finding.get("category") != "ground_truth_orphan":
                continue
            uid = normalize_identity(finding.get("uid"))
            if uid is None or uid in observed_orphans:
                raise WorldBuilderError(f"{result_path.name} has invalid/duplicate ground_truth_orphan finding UID")
            observed_orphans[uid] = finding
        if set(observed_orphans) != set(expected_orphans):
            raise WorldBuilderError(
                f"{result_path.name} ground_truth_orphan findings do not exactly match the deterministic orphan UIDs"
            )
        for uid, expected_row in expected_orphans.items():
            finding = observed_orphans[uid]
            expected_name = str(expected_row.get("name") or "")
            if finding.get("entry_name") != expected_name:
                raise WorldBuilderError(
                    f"{result_path.name} ground-truth orphan finding for UID {uid!r} must name entry {expected_name!r}"
                )
            if finding.get("target") != expected_row.get("path"):
                raise WorldBuilderError(
                    f"{result_path.name} ground-truth orphan finding for UID {uid!r} must target {expected_row.get('path')!r}"
                )
        divergence_findings = [f for f in findings if f.get("category") == "ground_truth_graph_divergence"]
        if divergence and len(divergence_findings) != 1:
            raise WorldBuilderError(
                f"{result_path.name} must emit exactly one ground_truth_graph_divergence finding when declared/content edges diverge"
            )
        if not divergence and divergence_findings:
            raise WorldBuilderError(
                f"{result_path.name} emitted ground_truth_graph_divergence even though the deterministic graphs agree"
            )

    if isinstance(deterministic, dict) and "plan_reconciliation" in deterministic:
        report = deterministic.get("plan_reconciliation")
        if (
            not isinstance(report, dict)
            or report.get("kind") != PLAN_RECONCILIATION_REPORT_KIND
            or report.get("report_version") != PLAN_RECONCILIATION_REPORT_VERSION
        ):
            raise WorldBuilderError(f"{assignment_path.name} has an invalid plan-reconciliation report")
        if assignment.get("lens") == "scout":
            entry_count = report.get("entry_count")
            if not isinstance(entry_count, dict):
                raise WorldBuilderError(f"{assignment_path.name} plan-reconciliation report lacks entry_count")
            expected = "not_applicable" if entry_count.get("status") == "no_declared_plan_found" else None
            observed_status = observed.get("plan-entry-count-reconciliation")
            if expected is not None:
                if observed_status != expected:
                    raise WorldBuilderError(
                        f"{result_path.name} plan-entry-count-reconciliation must be {expected!r} when no declared plan is available"
                    )
            elif observed_status not in {"pass", "warning"}:
                raise WorldBuilderError(
                    f"{result_path.name} plan-entry-count-reconciliation must be pass or warning after evaluating the measured delta; "
                    "the deterministic delta is advisory and cannot be auto-failed"
                )
        elif assignment.get("lens") == "weaver":
            token_budget = report.get("token_budget")
            if not isinstance(token_budget, dict):
                raise WorldBuilderError(f"{assignment_path.name} plan-reconciliation report lacks token_budget")
            expected = "not_applicable" if token_budget.get("status") == "not_applicable" else None
            observed_status = observed.get("token-budget-reconciliation")
            if expected is not None:
                if observed_status != expected:
                    raise WorldBuilderError(
                        f"{result_path.name} token-budget-reconciliation must be {expected!r} when no applicable budget measurement exists"
                    )
            elif observed_status not in {"pass", "warning"}:
                raise WorldBuilderError(
                    f"{result_path.name} token-budget-reconciliation must be pass or warning after evaluating the measured over-target rows; "
                    "the deterministic measurements are advisory and cannot be auto-failed"
                )

    summary = result.get("summary")
    if not isinstance(summary, str) or len(summary.strip()) < 100:
        raise WorldBuilderError(f"{result_path.name} summary is too short")
    terminal = result.get("terminal_report")
    delimiter = str(assignment.get("expected_end_delimiter"))
    if not isinstance(terminal, str) or terminal.rstrip().splitlines()[-1:] != [delimiter]:
        actual_last_line = terminal.rstrip().splitlines()[-1] if isinstance(terminal, str) and terminal.strip() else "(empty or missing)"
        raise WorldBuilderError(
            f"{result_path.name} terminal_report lacks the exact final delimiter. Expected the LAST line "
            f"(after trailing whitespace is stripped) to be exactly {delimiter!r}; the actual last line was "
            f"{actual_last_line!r}. The delimiter must be on its own line at the very end, not appended "
            "inline after other text on that line. Add a newline before the delimiter and re-save the "
            "result file, then re-run audit_gate.py."
        )
    return result


def validate_audit_run(state_path: Path, stage: str, *, write_receipt: bool = True, advance_stage: bool = True) -> dict[str, Any]:
    root, state = load_build_state(state_path)
    plan_key = "pre_generation_audit_plan" if stage == "pre-generation" else "post_generation_audit_plan"
    receipt_key = "pre_generation_audit_receipt" if stage == "pre-generation" else "post_generation_audit_receipt"
    plan_path = resolve_state_path(root, state, plan_key)
    if not plan_path.exists():
        raise WorldBuilderError(
            f"missing audit plan: {plan_path}. Create it first with: "
            f"{sys.executable or 'python'} {Path(__file__).resolve().parent}/audit_plan.py --build-state {state_path} --stage {stage}"
        )
    plan = load_json(plan_path)
    if not isinstance(plan, dict) or plan.get("kind") != "worldbuilder-audit-plan" or plan.get("plan_version") not in SUPPORTED_AUDIT_PLAN_VERSIONS:
        raise WorldBuilderError(
            f"{plan_path.name} is not a supported audit plan version: got plan_version "
            f"{plan.get('plan_version') if isinstance(plan, dict) else None!r}, supported "
            f"{sorted(SUPPORTED_AUDIT_PLAN_VERSIONS)}"
        )
    if plan.get("build_id") != state.get("build_id") or plan.get("stage") != stage:
        raise WorldBuilderError("audit plan build/stage mismatch")
    execution_mode = str(plan.get("execution_mode", "independent"))
    if execution_mode not in {"independent", "consolidated"}:
        raise WorldBuilderError("audit plan execution_mode must be independent or consolidated")
    required = plan.get("required_lenses")
    if required != list(AUDIT_LENSES):
        raise WorldBuilderError("audit plan must require exactly Compass, Weaver, Scout, and Warden")
    target = (root / str(plan.get("target"))).resolve()
    ensure_inside(target, root)
    if not target.exists() or sha256_file(target) != plan.get("target_sha256"):
        raise WorldBuilderError("audit target bytes changed after assignments were planned")

    assignments_root = resolve_state_path(root, state, "audit_assignments", required=False) or (root / ".work/audit-assignments")
    findings_root = resolve_state_path(root, state, "findings")
    runtime_root = resolve_state_path(root, state, "audit_runtime", required=False) or (root / ".work/audit-runtime")
    rows = plan.get("assignments")
    if not isinstance(rows, list) or len(rows) != 4:
        raise WorldBuilderError("audit plan must contain four assignment rows")
    observed_lenses: set[str] = set()
    observed_sessions: set[str] = set()
    observed_events: set[str] = set()
    observed_runs: set[str] = set()
    observed_parent_sessions: set[str] = set()
    validated: list[dict[str, Any]] = []
    for row in rows:
        if not isinstance(row, dict):
            raise WorldBuilderError("audit plan assignment row is invalid")
        lens = row.get("lens")
        if lens not in AUDIT_LENSES or lens in observed_lenses:
            raise WorldBuilderError("audit plan has missing/duplicate lens")
        observed_lenses.add(lens)
        assignment_path = path_from_root(root, row.get("assignment"), assignments_root)
        assignment = load_json(assignment_path)
        if not isinstance(assignment, dict) or assignment.get("assignment_version") not in SUPPORTED_AUDIT_ASSIGNMENT_VERSIONS:
            raise WorldBuilderError(
                f"{assignment_path.name} is not a supported audit assignment version: got assignment_version "
                f"{assignment.get('assignment_version') if isinstance(assignment, dict) else None!r}, supported "
                f"{sorted(SUPPORTED_AUDIT_ASSIGNMENT_VERSIONS)}"
            )
        if sha256_file(assignment_path) != row.get("assignment_sha256"):
            raise WorldBuilderError(f"{assignment_path.name} hash changed after planning")
        if assignment.get("lens") != lens or assignment.get("audit_run_id") != plan.get("audit_run_id"):
            raise WorldBuilderError(f"{assignment_path.name} lens/run mismatch")
        result_path = path_from_root(root, assignment.get("output"), findings_root)
        runtime_path = path_from_root(root, assignment.get("runtime_receipt"), runtime_root)
        result = validate_result(result_path, assignment=assignment, assignment_path=assignment_path)
        runtime = validate_runtime(runtime_path, assignment=assignment, assignment_path=assignment_path, result_path=result_path)
        echoed_child = result["_worldbuilder"].get("child_session_id")
        if echoed_child not in (None, "") and normalize_child_session_id(echoed_child) != normalize_child_session_id(runtime["child_session_id"]):
            raise WorldBuilderError(f"{lens} result and runtime receipt session IDs differ")
        if execution_mode == "independent":
            normalized_runtime_child = normalize_child_session_id(runtime["child_session_id"])
            if normalized_runtime_child in observed_sessions:
                raise WorldBuilderError("one child session cannot satisfy multiple audit lenses in independent mode")
            if runtime["runtime_event_id"] in observed_events:
                raise WorldBuilderError("one runtime completion event cannot satisfy multiple audit lenses in independent mode")
            if runtime["run_id"] in observed_runs:
                raise WorldBuilderError("one sessions_spawn run_id cannot satisfy multiple audit lenses in independent mode")
        observed_sessions.add(normalize_child_session_id(runtime["child_session_id"]))
        observed_events.add(runtime["runtime_event_id"])
        observed_runs.add(runtime["run_id"])
        observed_parent_sessions.add(runtime["parent_session_id"])
        validated.append({
            "lens": lens,
            "auditor": assignment.get("auditor"),
            "assignment": rel(assignment_path, root),
            "assignment_sha256": sha256_file(assignment_path),
            "result": rel(result_path, root),
            "result_sha256": sha256_file(result_path),
            "runtime_receipt": rel(runtime_path, root),
            "runtime_receipt_sha256": sha256_file(runtime_path),
            "finding_count": len(result.get("findings", [])),
            "failed_check_count": sum(1 for check in result.get("checks", []) if check.get("status") == "fail"),
        })
    if observed_lenses != set(AUDIT_LENSES):
        raise WorldBuilderError("not all four audit lenses completed")
    if len(observed_parent_sessions) != 1:
        raise WorldBuilderError("all four audit lenses in one audit run must be observed by the same parent session")

    plan_conformance = None
    if stage == "post-generation":
        # Batch 13, import-fidelity audit enhancement: confirms no manifest
        # entry silently went missing during merge/adapt/naming, and no
        # entry's delivered fields silently diverged from what planning
        # actually decided; before delivery_permitted, not bolted on
        # after. Hard-blocks on a genuine mismatch, the same enforcement
        # principle as delivery_gate.py's check_direct_import_compatible:
        # a known-bad condition must stop the build, not just get reported
        # into a file nobody is required to read.
        manifest_path = resolve_state_path(root, state, "manifest", required=False)
        if manifest_path is not None and manifest_path.exists():
            from sillytavern_import_probe import plan_conformance_check
            target_data = load_json(target)
            manifest_data = load_json(manifest_path)
            if isinstance(target_data, dict) and isinstance(manifest_data, dict):
                plan_conformance = plan_conformance_check(target_data, manifest_data)
                if not plan_conformance["conformant"]:
                    raise WorldBuilderError(
                        "post-generation audit blocked: the delivered artifact does not conform to the "
                        f"manifest. missing_uids={plan_conformance['missing_uids']}, "
                        f"extra_uids={plan_conformance['extra_uids']}, "
                        f"duplicate_uids={plan_conformance['duplicate_uids']}, "
                        f"field_mismatches={plan_conformance['field_mismatches']}. "
                        "Each field_mismatch entry names the exact uid, field, delivered value, and planned "
                        "value; fix the divergence at its actual source (merge, entry-naming, or a stale "
                        "patch) and re-run this audit; do not patch the mismatch directly without "
                        "understanding why planning and delivery disagreed."
                    )

    receipt = {
        "kind": "worldbuilder-audit-gate",
        "receipt_version": 2,
        "build_id": state.get("build_id"),
        "audit_run_id": plan.get("audit_run_id"),
        "stage": stage,
        "plan": rel(plan_path, root),
        "plan_sha256": sha256_file(plan_path),
        "target": plan.get("target"),
        "target_sha256": plan.get("target_sha256"),
        "manifest_sha256": plan.get("manifest_sha256"),
        "plan_conformance": plan_conformance,
        "required_lenses": list(AUDIT_LENSES),
        "execution_mode": execution_mode,
        "auditors": validated,
        "all_runtime_statuses_completed": True,
        "all_lenses_validated": True,
        "independence_proven": execution_mode == "independent" and len(observed_sessions) == 4 and len(observed_runs) == 4 and len(observed_events) == 4,
        "topology_validated": True,
        "unique_child_session_count": len(observed_sessions),
        "unique_run_id_count": len(observed_runs),
        "unique_runtime_event_count": len(observed_events),
        "distinct_child_session_count": len(observed_sessions),
        "distinct_spawn_run_count": len(observed_runs),
        "distinct_runtime_event_count": len(observed_events),
        "parent_session_id": next(iter(observed_parent_sessions)),
        "parent_session_count": len(observed_parent_sessions),
    }
    receipt_path = resolve_state_path(root, state, receipt_key)
    if write_receipt:
        atomic_write_json(receipt_path, receipt)
        audit_state = state.setdefault("audit", {}).setdefault(stage.replace("-", "_"), {})
        audit_state.update({
            "status": "complete",
            "audit_run_id": plan.get("audit_run_id"),
            "receipt": rel(receipt_path, root),
            "receipt_sha256": sha256_file(receipt_path),
        })
        status_key = "pre_generation" if stage == "pre-generation" else "post_generation_audit"
        state.setdefault("status", {})[status_key] = "complete"
        pending_amendment = (state.get("amendment") or {}).get("pending") if isinstance(state.get("amendment"), dict) else None
        additive_changed_scope = isinstance(pending_amendment, dict) and plan.get("scope_mode") == "changed"
        if additive_changed_scope:
            pending_amendment.update({
                "phase": "amendment_seal",
                "scoped_audit_receipt": rel(receipt_path, root),
                "scoped_audit_receipt_sha256": sha256_file(receipt_path),
            })
        atomic_write_json(state_path, state)
        if advance_stage and not additive_changed_scope:
            advance_pipeline_stage(state_path, "pre_generation_audit" if stage == "pre-generation" else "post_generation_audit")
    return receipt


def validate_saved_receipt(state_path: Path, stage: str) -> dict[str, Any]:
    """Recompute the audit proof and require the saved gate receipt to match.

    Consumers such as phase_gate.py and delivery_gate.py call this rather than
    trusting a report-shaped file or a stale receipt by itself.
    """
    root, state = load_build_state(state_path)
    receipt_key = "pre_generation_audit_receipt" if stage == "pre-generation" else "post_generation_audit_receipt"
    receipt_path = resolve_state_path(root, state, receipt_key)
    if not receipt_path.exists():
        raise WorldBuilderError(f"missing {stage} audit gate receipt: {receipt_path}")
    saved = load_json(receipt_path)
    expected = validate_audit_run(state_path, stage, write_receipt=False)
    if saved != expected:
        raise WorldBuilderError(f"{stage} audit gate receipt is stale or does not match the four current lens proofs")
    return expected


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--build-state", required=True)
    parser.add_argument("--stage", choices=["pre-generation", "post-generation"])
    parser.add_argument("--requirements", action="store_true", help="Read-only preflight: print what this gate checks against the current build state.")
    args = parser.parse_args()
    if args.requirements:
        root, state = load_build_state(args.build_state)
        print(json.dumps(preflight_report("audit_gate", requirement_rows(Path(__file__), root, state)), ensure_ascii=False, indent=2))
        return 0
    if not args.stage:
        parser.error("--stage is required")
    try:
        receipt = validate_audit_run(Path(args.build_state).resolve(), args.stage, write_receipt=True)
        print(json.dumps({"status": "passed", "stage": args.stage, "audit_run_id": receipt["audit_run_id"], "auditors": receipt["auditors"]}, indent=2))
        return 0
    except (WorldBuilderError, OSError, json.JSONDecodeError, ValueError) as exc:
        print(f"AUDIT GATE BLOCKED: {exc}", file=sys.stderr)
        print(step_driver_pointer(), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
