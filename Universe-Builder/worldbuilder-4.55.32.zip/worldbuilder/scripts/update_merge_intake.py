#!/usr/bin/env python3
"""Update/Merge intake diagnostic: assess an incoming book before the merge runs.

Update/Merge historically assumed the incoming artifact was a known quantity.
In practice it may be a WorldBuilder book from any point in a long, evolving
history, a book from a different tool, or hand-authored content. This runs the
`references/update-merge-intake-checklist.md` pass once, upfront, and returns a
real, itemized list of what needs doing: not a pass/fail gate, and not a
mandate to fix everything found. Scope stays a judgment call; this makes it
visible.

Every item that names an existing tool calls that tool here rather than
describing it in prose: ground_truth_graph.py (graph), st_activation_scanner.py
(fan-out), prevent_recursion_candidates.py (recursion caps and the character
cascade rule), budget_contract.py (sizing), writing_quality.py (prose).
"""
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Any

import budget_contract as B
import ground_truth_graph as G
import prevent_recursion_candidates as P
import st_activation_scanner as S
import writing_quality as W

REPORT_KIND = "worldbuilder-update-merge-intake"
REPORT_VERSION = 1

# WorldBuilder's own markers. Presence of any one identifies an authored book.
WORLDBUILDER_EXTENSION_KEYS = (
    "worldbuilder_entry_naming",
    "worldbuilder_dynamic",
    "worldbuilder_situational_voice",
    "worldbuilder",
)
CORE_LABEL_PATTERN = re.compile(r"\bCore\s*$", re.IGNORECASE)
SEMANTIC_LABEL_PATTERN = re.compile(r"^[A-Za-z][A-Za-z /&'-]*:\s+\S")
ROOT_BRANCH_PATTERN = re.compile(r"\((?:Root|Branch)\)\s*$", re.IGNORECASE)

# An ordinary, innocuous message for the fan-out probe (the Batch 46 diagnostic).
DEFAULT_PROBE_MESSAGES = ("Hello there.", "What happens next?")
DEFAULT_CONTEXT_WINDOW = 8192


def entries_of(data: Any) -> list[dict[str, Any]]:
    """Entries from any real incoming shape: CCv3, CCv2, or bare World Info."""
    if not isinstance(data, dict):
        return []
    for path in (("data", "character_book", "entries"), ("character_book", "entries"), ("entries",)):
        node: Any = data
        for key in path:
            node = node.get(key) if isinstance(node, dict) else None
        if isinstance(node, dict):  # ST exports a uid-keyed object as well as a list
            node = [v for v in node.values() if isinstance(v, dict)]
        if isinstance(node, list):
            return [e for e in node if isinstance(e, dict)]
    return []


def schema_shape(data: Any) -> str:
    if not isinstance(data, dict):
        return "unknown"
    if isinstance(data.get("data"), dict) and "character_book" in data["data"]:
        return "ccv3"
    if "character_book" in data:
        return "ccv2"
    if "entries" in data:
        return "world_info"
    return "unknown"


def _field_names(entries: list[dict[str, Any]]) -> dict[str, str]:
    """The real field spelling each convention actually uses in this file."""
    names: dict[str, str] = {}
    for label, options in (
        ("uid", ("uid", "id")),
        ("keys", ("keys", "key")),
        ("secondary_keys", ("secondary_keys", "keysecondary")),
    ):
        for option in options:
            if any(option in entry for entry in entries):
                names[label] = option
                break
    return names


def selective_logic_location(entries: list[dict[str, Any]]) -> str:
    for entry in entries:
        if "selectiveLogic" in entry or "selective_logic" in entry:
            return "emit"
    for entry in entries:
        extensions = entry.get("extensions")
        if isinstance(extensions, dict) and any(k in extensions for k in ("selectiveLogic", "selective_logic")):
            return "extensions"
    return "absent"


def worldbuilder_markers(entries: list[dict[str, Any]]) -> list[str]:
    markers: list[str] = []
    if any(
        isinstance(entry.get("extensions"), dict)
        and any(k in entry["extensions"] for k in WORLDBUILDER_EXTENSION_KEYS)
        for entry in entries
    ):
        markers.append("worldbuilder_extension")
    if any(
        entry.get("era_branch_of") is not None
        or (entry.get("extensions") or {}).get("era_branch_of") is not None
        for entry in entries
    ):
        markers.append("era_branch_of")
    if any(CORE_LABEL_PATTERN.search(P.entry_label(entry)) for entry in entries):
        markers.append("core_convention")
    labelled = [P.entry_label(entry) for entry in entries if P.entry_label(entry)]
    if labelled and all(SEMANTIC_LABEL_PATTERN.match(label) for label in labelled):
        markers.append("semantic_prefix_labels")
    return markers


def connectivity_tiered(entries: list[dict[str, Any]]) -> bool | None:
    """Tiered order/weight (Batch 49/53) leaves more than one distinct weight."""
    weights = {str(e.get("weight")) for e in entries if e.get("weight") is not None}
    orders = {str(e.get("order")) for e in entries if e.get("order") is not None}
    if not weights and not orders:
        return None
    return len(weights) > 1 or len(orders) > 1


def external_convention(entries: list[dict[str, Any]]) -> str:
    labelled = [P.entry_label(e) for e in entries if P.entry_label(e)]
    if not labelled:
        return "no_consistent_structure"
    if all(SEMANTIC_LABEL_PATTERN.match(label) for label in labelled):
        return "semantic_prefix_labels"
    return "plain_titles_or_other_generator"


def era_tree_pairs(entries: list[dict[str, Any]]) -> int:
    return sum(
        1 for e in entries
        if e.get("era_branch_of") is not None or (e.get("extensions") or {}).get("era_branch_of") is not None
    )


def root_branch_named(entries: list[dict[str, Any]]) -> bool:
    return any(ROOT_BRANCH_PATTERN.search(label) for label in (P.entry_label(e) for e in entries) if label)


def analyze(
    data: Any,
    *,
    context_window: int = DEFAULT_CONTEXT_WINDOW,
    probe_messages: tuple[str, ...] = DEFAULT_PROBE_MESSAGES,
) -> dict[str, Any]:
    entries = entries_of(data)
    edges = G.build_ground_truth_edges(entries)
    in_degree: dict[str, int] = {}
    for _source, target in edges:
        in_degree[str(target)] = in_degree.get(str(target), 0) + 1

    scan_entries = S.entries_from_dicts(entries)
    fan_out = S.diagnostic_report(scan_entries, list(probe_messages), depth_limit=8)

    worst_case = sum(int(B.estimate_tokens(str(e.get("content") or ""))) for e in entries)
    cliche_entries = [P.entry_label(e) for e in entries if W.find_cliches(str(e.get("content") or ""))]
    trait_entries = [
        P.entry_label(e) for e in entries if W.find_trait_adjective_runs(str(e.get("content") or ""))
    ]
    description = (data.get("data") or {}).get("description") if isinstance(data, dict) else None
    description_text = description if isinstance(description, str) else str((data or {}).get("description") or "")
    markers = worldbuilder_markers(entries)

    return {
        "kind": REPORT_KIND,
        "report_version": REPORT_VERSION,
        "entry_count": len(entries),
        "provenance": {
            "worldbuilder_authored": bool(markers),
            "markers": markers,
            "connectivity_tiered": connectivity_tiered(entries),
            "external_convention": None if markers else external_convention(entries),
        },
        "schema": {
            "shape": schema_shape(data),
            "field_names": _field_names(entries),
            "selective_logic_location": selective_logic_location(entries),
        },
        "keywording": {
            "bare_name_high_in_degree": P.find_cascade_keyword_risks(entries, in_degree),
            "and_all_gated_entries": sum(
                1 for e in entries
                if str(e.get("selectiveLogic", e.get("selective_logic", ""))) in {"3", "AND_ALL"}
            ),
        },
        "activation": {
            "orphans": G.find_orphans(entries, edges),
            "circular_chains": G.find_circular_chains(entries, edges),
            "fan_out": fan_out,
            "prevent_recursion_candidates": P.find_prevent_recursion_candidates(entries, in_degree),
        },
        "writing": {
            "cliche_entries": cliche_entries,
            "trait_adjective_entries": trait_entries,
            "second_person_matches": W.find_description_second_person(description_text),
        },
        "architecture": {
            "era_tree_pairs": era_tree_pairs(entries),
            "root_branch_named": root_branch_named(entries),
        },
        "budget": {
            "worst_case_tokens": worst_case,
            "context_window": context_window,
            "over_ceiling": worst_case > context_window,
        },
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True, help="Incoming book (card, merged, or bare World Info JSON)")
    parser.add_argument("--context-window", type=int, default=DEFAULT_CONTEXT_WINDOW)
    parser.add_argument("--output", help="Optional JSON report path")
    args = parser.parse_args()
    data = json.loads(Path(args.input).read_text(encoding="utf-8"))
    report = analyze(data, context_window=args.context_window)
    rendered = json.dumps(report, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        Path(args.output).write_text(rendered, encoding="utf-8", newline="\n")
        print(f"wrote {args.output} ({report['entry_count']} entries)")
    else:
        print(rendered)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
