#!/usr/bin/env python3
"""Public artifact entry lookup helpers.

Promoted from ``artifact_edit.py`` so pruning and future callers do not import
another module's private implementation detail.
"""
from __future__ import annotations

from typing import Any

from wb_common import WorldBuilderError, build_identity_index, normalize_identity
from verify_patches import resolve_pointer


def locate_entry(data: Any, *, uid: Any = None, pointer: str | None = None) -> dict[str, Any]:
    if (uid is None) == (pointer is None):
        raise WorldBuilderError("exactly one of uid or pointer must be given")
    if pointer is not None:
        found, value = resolve_pointer(data, pointer)
        if not found:
            raise WorldBuilderError(f"pointer {pointer!r} does not resolve")
        if not isinstance(value, dict):
            raise WorldBuilderError(f"pointer {pointer!r} does not resolve to an entry object")
        return value
    index = build_identity_index(data)
    key = normalize_identity(uid)
    if key not in index:
        raise WorldBuilderError(f"no entry with uid {uid!r}")
    return index[key][1]
