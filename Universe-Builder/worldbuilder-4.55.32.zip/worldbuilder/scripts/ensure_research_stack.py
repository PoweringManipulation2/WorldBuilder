#!/usr/bin/env python3
"""Start, repair, and verify WorldBuilder's configured research stack.

The script is copied into the approved WorldBuilder workspace during first-time
setup. It never writes to the OpenClaw or installed-skill directories.
"""
from __future__ import annotations

import argparse
import json
import os
import platform
import shutil
import re
import signal
import subprocess
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

CONNECTED_LINE = re.compile(r"^\s*(?:status(?:\s+update)?\s*:\s*)?connected(?:\s+.*)?$", re.I)
DISCONNECTED_LINE = re.compile(r"^\s*(?:status(?:\s+update)?\s*:\s*)?disconnected(?:\s+.*)?$", re.I)


def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def run(cmd: list[str], *, cwd: Path | None = None, check: bool = True, timeout: float | None = 120.0) -> subprocess.CompletedProcess[str]:
    proc = subprocess.run(cmd, cwd=cwd, text=True, capture_output=True, check=False, timeout=timeout)
    if check and proc.returncode != 0:
        raise RuntimeError(f"Command failed ({proc.returncode}): {' '.join(cmd)}\n{proc.stdout}\n{proc.stderr}")
    return proc


def parse_warp_connected(text: str) -> bool:
    """Parse exact WARP state; never let 'Disconnected' match 'connected'."""
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    if any(DISCONNECTED_LINE.fullmatch(line) for line in lines):
        return False
    return any(CONNECTED_LINE.fullmatch(line) for line in lines)


def parse_warp_service_mode(text: str) -> dict[str, Any]:
    """Parse the service mode reported by ``warp-cli settings`` without guessing."""
    compact = re.sub(r"\s+", " ", text).strip()
    folded = compact.casefold()
    if "warpproxy" in folded or re.search(r"\bmode\s*:\s*(?:local[- ]?)?proxy\b", folded):
        match = re.search(r"(?:warpproxy|proxy).*?\bport\b\s*[:=]?\s*(\d{2,5})", compact, re.I)
        if not match:
            match = re.search(r"\bwarpproxy\b\s+(?:on\s+port\s+)?(\d{2,5})", compact, re.I)
        port = int(match.group(1)) if match else None
        return {
            "mode": "local-proxy", "service_mode": "WarpProxy", "proxy_port": port,
            "proxy_url": f"socks5h://127.0.0.1:{port}" if port else None,
        }
    if any(token in folded for token in ("warpwithdnsoverhttps", "warpwithdnsovertls", "tunnelonly", "warp+doh", "warp+dot")):
        return {"mode": "tunnel", "service_mode": "tunnel", "proxy_port": None, "proxy_url": None}
    if any(token in folded for token in ("dnsoverhttps", "dnsovertls")) or re.search(r"\bmode\s*:\s*do[ht]\b", folded):
        return {"mode": "dns-only", "service_mode": "dns-only", "proxy_port": None, "proxy_url": None}
    return {"mode": "unknown", "service_mode": "unknown", "proxy_port": None, "proxy_url": None}


def warp_mode_status() -> dict[str, Any]:
    executable = executable_path("warp-cli")
    if not executable:
        return {"available": False, "mode": "unavailable", "proxy_url": None, "detail": "warp-cli not found"}
    try:
        proc = run([executable, "settings"], check=False, timeout=20.0)
    except (OSError, subprocess.TimeoutExpired) as exc:
        return {"available": True, "mode": "error", "proxy_url": None, "detail": str(exc)}
    detail = (proc.stdout + "\n" + proc.stderr).strip()
    parsed = parse_warp_service_mode(detail)
    return {"available": True, "returncode": proc.returncode, "detail": detail[:4000], **parsed}


def desired_proxy_for_backend(mode_status: dict[str, Any], backend: str) -> dict[str, Any]:
    mode = mode_status.get("mode")
    if mode != "local-proxy":
        return {"proxy_url": None, "settings_supported": mode not in {"unknown", "error", "unavailable"}, "reason": mode}
    proxy_url = mode_status.get("proxy_url")
    if backend == "python" and isinstance(proxy_url, str) and proxy_url:
        return {"proxy_url": proxy_url, "settings_supported": True, "reason": "native SearXNG shares the WARP proxy host"}
    return {
        "proxy_url": None, "settings_supported": False,
        "reason": "WARP local-proxy loopback is not reachable as 127.0.0.1 from the managed Docker network namespace",
    }


def sync_settings_proxy(settings_file: Path, proxy_url: str | None) -> dict[str, Any]:
    """Replace only ``outgoing.proxies`` in a managed SearXNG settings file."""
    path = settings_file.resolve()
    text = path.read_text(encoding="utf-8")
    lines = text.splitlines()
    try:
        start = next(i for i, line in enumerate(lines) if re.fullmatch(r"outgoing:\s*", line))
    except StopIteration as exc:
        raise RuntimeError(f"SearXNG settings has no top-level outgoing block: {path}") from exc
    end = len(lines)
    for i in range(start + 1, len(lines)):
        line = lines[i]
        if line.strip() and not line.startswith((" ", "\t")):
            end = i
            break
    body = lines[start + 1:end]
    cleaned: list[str] = []
    skipping = False
    for line in body:
        stripped = line.strip()
        indent = len(line) - len(line.lstrip(" "))
        if stripped == '# WorldBuilder: grep for "proxy" will not find the YAML key "proxies" below.':
            continue
        if indent == 2 and re.match(r"proxies\s*:", stripped):
            skipping = True
            continue
        if skipping and stripped and indent <= 2:
            skipping = False
        if skipping:
            continue
        cleaned.append(line)
    while cleaned and not cleaned[-1].strip():
        cleaned.pop()
    if proxy_url:
        cleaned.extend([
            '  # WorldBuilder: grep for "proxy" will not find the YAML key "proxies" below.',
            "  proxies:",
            "    all://:",
            f'      - "{proxy_url}"',
        ])
    updated_lines = lines[:start + 1] + cleaned + lines[end:]
    updated = "\n".join(updated_lines) + "\n"
    changed = updated != text
    if changed:
        path.write_text(updated, encoding="utf-8", newline="\n")
    return {"changed": changed, "settings_file": str(path), "proxy_url": proxy_url}


def sync_proxy_for_warp_mode(paths: dict[str, Any], backend: str, mode_status: dict[str, Any]) -> dict[str, Any]:
    settings_value = paths.get("settings_file")
    if not isinstance(settings_value, str) or not settings_value:
        return {"changed": False, "status": "no-settings-file"}
    mode = str(mode_status.get("mode", "unknown"))
    if mode in {"unknown", "error", "unavailable"}:
        return {"changed": False, "status": "unchanged-unknown-mode", "mode": mode}
    desired = desired_proxy_for_backend(mode_status, backend)
    result = sync_settings_proxy(Path(settings_value), desired.get("proxy_url"))
    result.update({"status": "synchronized", "mode": mode, "settings_supported": desired.get("settings_supported"), "reason": desired.get("reason")})
    return result


def executable_path(name: str) -> str | None:
    found = shutil.which(name)
    if found:
        return found
    if name == "warp-cli":
        candidates: list[Path] = []
        for env_name in ("ProgramFiles", "ProgramFiles(x86)"):
            base = os.environ.get(env_name)
            if base:
                candidates.append(Path(base) / "Cloudflare" / "Cloudflare WARP" / "warp-cli.exe")
        candidates.extend([
            Path("/Applications/Cloudflare WARP.app/Contents/Resources/warp-cli"),
            Path("/opt/homebrew/bin/warp-cli"), Path("/usr/local/bin/warp-cli"), Path("/usr/bin/warp-cli"),
        ])
        for candidate in candidates:
            if candidate.is_file():
                return str(candidate)
    return None


def warp_status() -> dict[str, Any]:
    try:
        executable = executable_path("warp-cli")
        if not executable:
            return {"available": False, "connected": False, "detail": "warp-cli not found"}
        proc = run([executable, "status"], check=False, timeout=20.0)
    except (FileNotFoundError, subprocess.TimeoutExpired) as exc:
        return {"available": False, "connected": False, "detail": str(exc)}
    detail = (proc.stdout + "\n" + proc.stderr).strip()
    return {
        "available": proc.returncode != 127,
        "connected": proc.returncode == 0 and parse_warp_connected(detail),
        "returncode": proc.returncode,
        "detail": detail[:2000],
    }


def ensure_warp(attempts: int = 4) -> dict[str, Any]:
    """Ensure the consumer WARP client is registered and exactly connected."""
    status = warp_status()
    if status["connected"]:
        status["registration_action"] = "not-needed"
        return status
    if not status["available"]:
        return status

    executable = executable_path("warp-cli")
    if not executable:
        return {"available": False, "connected": False, "detail": "warp-cli not found"}
    registration = run([executable, "registration", "show"], check=False, timeout=30.0)
    registration_detail = (registration.stdout + "\n" + registration.stderr).strip()
    registration_action = "existing"
    if registration.returncode != 0:
        created = run([executable, "registration", "new"], check=False, timeout=60.0)
        if created.returncode != 0:
            # Compatibility fallback for older client releases.
            created = run([executable, "register"], check=False, timeout=60.0)
        if created.returncode != 0:
            status.update({
                "registration_action": "failed",
                "registration_detail": (created.stdout + created.stderr)[-2000:],
            })
            return status
        registration_action = "created"
        registration_detail = (created.stdout + created.stderr).strip()

    # Explicit full-tunnel mode prevents a stale DNS-only configuration from
    # passing a superficial connection check. Older clients may not expose mode.
    run([executable, "mode", "warp+doh"], check=False, timeout=30.0)
    connect = run([executable, "connect"], check=False, timeout=30.0)
    for attempt in range(attempts):
        time.sleep(min(1.0 + attempt, 4.0))
        status = warp_status()
        status["registration_action"] = registration_action
        status["registration_detail"] = registration_detail[-2000:]
        if status["connected"]:
            status["connect_output"] = (connect.stdout + connect.stderr)[-2000:]
            return status
    status["registration_action"] = registration_action
    status["registration_detail"] = registration_detail[-2000:]
    status["connect_output"] = (connect.stdout + connect.stderr)[-2000:]
    return status


def process_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def process_matches(pid: int, expected_fragment: str) -> bool:
    if not process_alive(pid):
        return False
    if os.name == "nt":
        # There is no dependency-free portable command-line inspection API on
        # Windows. The PID file also records the exact executable and source dir;
        # endpoint health is the final authority before this process is trusted.
        return True
    cmdline = Path(f"/proc/{pid}/cmdline")
    if cmdline.exists():
        try:
            text = cmdline.read_bytes().replace(b"\0", b" ").decode("utf-8", errors="replace")
            return expected_fragment in text and "searx.webapp" in text
        except OSError:
            return False
    return True


def read_pid_record(path: Path) -> dict[str, Any] | None:
    if not path.exists():
        return None
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        # Migrate the early v3.6 plain-integer PID format.
        try:
            return {"pid": int(path.read_text(encoding="utf-8").strip())}
        except (ValueError, OSError):
            return None
    return value if isinstance(value, dict) else None


def launch_docker_desktop() -> dict[str, Any]:
    system = platform.system().lower()
    if system == "windows":
        candidates: list[Path] = []
        for env_name in ("ProgramFiles", "ProgramFiles(x86)"):
            base = os.environ.get(env_name)
            if base:
                candidates.append(Path(base) / "Docker" / "Docker" / "Docker Desktop.exe")
        executable = next((path for path in candidates if path.is_file()), None)
        if executable is None:
            return {"attempted": False, "detail": "Docker Desktop executable not found in standard locations"}
        subprocess.Popen([str(executable)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return {"attempted": True, "method": str(executable)}
    if system == "darwin":
        proc = run(["open", "-a", "Docker"], check=False, timeout=30.0)
        return {"attempted": True, "method": "open -a Docker", "returncode": proc.returncode}
    proc = run(["systemctl", "start", "docker"], check=False, timeout=30.0)
    return {"attempted": True, "method": "systemctl start docker", "returncode": proc.returncode, "detail": (proc.stdout + proc.stderr)[-1000:]}


def wait_for_docker(timeout: float = 120.0) -> tuple[bool, str]:
    deadline = time.monotonic() + timeout
    last = "not attempted"
    while time.monotonic() < deadline:
        proc = run(["docker", "info"], check=False, timeout=30.0)
        if proc.returncode == 0:
            return True, (proc.stdout + proc.stderr)[-1000:]
        last = (proc.stdout + proc.stderr)[-2000:]
        time.sleep(3.0)
    return False, last


def start_docker(paths: dict[str, str], *, reload_config: bool = False) -> dict[str, Any]:
    compose = Path(paths["compose_file"]).resolve()
    if not compose.exists():
        raise RuntimeError(f"SearXNG Compose file is missing: {compose}")
    info = run(["docker", "info"], check=False, timeout=30.0)
    launch: dict[str, Any] | None = None
    if info.returncode != 0:
        launch = launch_docker_desktop()
        ready, detail = wait_for_docker()
        if not ready:
            raise RuntimeError(
                "Docker is installed but its daemon could not be started. Enable Docker Desktop/Engine at login and retry.\n"
                + detail
            )
    proc = run(["docker", "compose", "-f", str(compose), "up", "-d"], timeout=180.0)
    restarted = None
    if reload_config:
        restarted = run(["docker", "compose", "-f", str(compose), "restart", "searxng"], timeout=120.0)
    return {
        "backend": "docker", "compose_file": str(compose), "docker_launch": launch,
        "config_reloaded": reload_config, "detail": ((restarted or proc).stdout)[-2000:],
    }


def docker_searxng_egress_receipt(paths: dict[str, str], base_url: str, output: Path) -> dict[str, Any]:
    """Probe Cloudflare trace from inside the SearXNG container.

    A host-side WARP check is insufficient when the search service has its own
    network namespace. The official image is Python-based, so use its runtime
    to fetch the trace endpoint and bind the result to the configured base URL.
    """
    compose = Path(paths["compose_file"]).resolve()
    code = (
        "import urllib.request;"
        "print(urllib.request.urlopen('https://www.cloudflare.com/cdn-cgi/trace',timeout=15).read().decode())"
    )
    proc = run(
        ["docker", "compose", "-f", str(compose), "exec", "-T", "searxng", "python", "-c", code],
        check=False,
        timeout=30.0,
    )
    trace: dict[str, str] = {}
    for line in proc.stdout.splitlines():
        if "=" in line:
            key, value = line.split("=", 1)
            trace[key.strip()] = value.strip()
    verified = proc.returncode == 0 and trace.get("warp") == "on"
    receipt = {
        "verified": verified,
        "base_url": base_url.rstrip("/"),
        "egress_mode": "warp",
        "evidence": "Cloudflare trace fetched from inside the SearXNG container network namespace",
        "trace": trace,
        "returncode": proc.returncode,
        "stderr": proc.stderr[-2000:],
        "checked_at": utc_now(),
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    if not verified:
        raise RuntimeError("SearXNG container egress is not verified through WARP")
    return receipt


def stop_managed_python(pid: int) -> None:
    try:
        os.kill(pid, signal.SIGTERM)
    except OSError:
        return
    for _ in range(30):
        if not process_alive(pid):
            return
        time.sleep(0.1)
    if process_alive(pid):
        raise RuntimeError(f"Managed SearXNG process {pid} did not stop for configuration reload")


def start_python(paths: dict[str, str], *, reload_config: bool = False) -> dict[str, Any]:
    pid_file = Path(paths["pid_file"]).resolve()
    source = Path(paths["source_dir"]).resolve()
    venv = Path(paths["venv_dir"]).resolve()
    py = venv / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
    settings = Path(paths["settings_file"]).resolve()
    if not source.is_dir() or not py.exists() or not settings.exists():
        raise RuntimeError("Native SearXNG installation is incomplete; rerun first_time_setup.py --apply.")

    record = read_pid_record(pid_file)
    if record and isinstance(record.get("pid"), int) and process_matches(int(record["pid"]), str(source)):
        if not reload_config:
            return {"backend": "python", "pid": int(record["pid"]), "reused": True, "config_reloaded": False}
        stop_managed_python(int(record["pid"]))

    env = os.environ.copy()
    env["SEARXNG_SETTINGS_PATH"] = str(settings)
    log_path = Path(paths["log_file"]).resolve()
    log_path.parent.mkdir(parents=True, exist_ok=True)
    log_handle = log_path.open("ab")
    kwargs: dict[str, Any] = {
        "cwd": str(source),
        "env": env,
        "stdout": log_handle,
        "stderr": subprocess.STDOUT,
        "creationflags": subprocess.CREATE_NEW_PROCESS_GROUP if os.name == "nt" else 0,
    }
    if os.name != "nt":
        kwargs["start_new_session"] = True
    try:
        proc = subprocess.Popen([str(py), "-m", "searx.webapp"], **kwargs)
    finally:
        log_handle.close()
    pid_file.parent.mkdir(parents=True, exist_ok=True)
    pid_file.write_text(json.dumps({
        "pid": proc.pid,
        "python": str(py),
        "source_dir": str(source),
        "started_at": utc_now(),
    }, indent=2) + "\n", encoding="utf-8")
    return {"backend": "python", "pid": proc.pid, "reused": False, "config_reloaded": reload_config}


def endpoint_ready(base_url: str, timeout: float = 90.0) -> dict[str, Any]:
    deadline = time.monotonic() + timeout
    query = urllib.parse.urlencode({"q": "WorldBuilder startup health check", "format": "json", "categories": "general"})
    url = f"{base_url.rstrip('/')}/search?{query}"
    last_error = "not attempted"
    attempts = 0
    while time.monotonic() < deadline:
        attempts += 1
        try:
            request = urllib.request.Request(url, headers={"User-Agent": "WorldBuilder-Research-Startup/3.6"})
            with urllib.request.urlopen(request, timeout=12.0) as response:
                payload = json.loads(response.read().decode("utf-8", errors="strict"))
            if int(getattr(response, "status", 200)) == 200 and isinstance(payload.get("results"), list):
                return {"ready": True, "attempts": attempts, "url": url, "result_count": len(payload["results"])}
            last_error = "endpoint returned non-JSON-search payload"
        except (OSError, urllib.error.URLError, TimeoutError, json.JSONDecodeError) as exc:
            last_error = str(exc)
        time.sleep(min(1.0 + attempts * 0.35, 5.0))
    return {"ready": False, "attempts": attempts, "url": url, "detail": last_error}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", required=True)
    parser.add_argument("--start", action="store_true")
    parser.add_argument("--preflight", action="store_true")
    parser.add_argument("--skip-warp-start", action="store_true")
    parser.add_argument("--startup-timeout", type=float, default=90.0)
    args = parser.parse_args()

    try:
        config_path = Path(args.config).expanduser().resolve()
        config = json.loads(config_path.read_text(encoding="utf-8"))
        if not isinstance(config, dict) or not isinstance(config.get("research"), dict):
            raise RuntimeError("WorldBuilder config has no research object")
        research = config["research"]
        backend = research.get("backend")
        paths = research.get("paths")
        if not isinstance(paths, dict):
            raise RuntimeError("WorldBuilder research config has no paths object")
        report: dict[str, Any] = {
            "kind": "worldbuilder-research-stack-status",
            "checked_at": utc_now(),
            "backend": backend,
            "started": False,
            "warp": None,
            "endpoint": None,
            "preflight": None,
            "serving_directory": paths.get("stack_dir") or paths.get("source_dir") or str(config_path.parent),
        }

        egress = research.get("egress", "warp")
        proxy_sync = {"changed": False, "status": "not-applicable"}
        if egress == "warp" and not args.skip_warp_start:
            report["warp"] = ensure_warp()
            if not report["warp"].get("connected"):
                raise RuntimeError("Cloudflare WARP is required but did not reach the exact Connected state")
            report["warp_mode"] = warp_mode_status()
            proxy_sync = sync_proxy_for_warp_mode(paths, str(backend), report["warp_mode"])
            report["searxng_proxy_sync"] = proxy_sync

        if args.start:
            reload_config = bool(proxy_sync.get("changed"))
            if backend == "docker":
                report["start"] = start_docker(paths, reload_config=reload_config)
            elif backend == "python":
                report["start"] = start_python(paths, reload_config=reload_config)
            else:
                raise RuntimeError(f"Unknown research backend: {backend!r}")
            report["started"] = True
            report["endpoint"] = endpoint_ready(str(research["base_url"]), args.startup_timeout)
            if not report["endpoint"].get("ready"):
                raise RuntimeError(f"SearXNG did not become ready: {report['endpoint']}")

        if args.preflight:
            configured = paths.get("preflight_script")
            preflight = Path(configured).resolve() if configured else Path(__file__).with_name("searxng_preflight.py")
            output = config_path.parent / "research-preflight.json"
            cmd = [sys.executable, str(preflight), "--base-url", str(research["base_url"]), "--output", str(output)]
            if backend == "python":
                cmd.append("--searxng-colocated")
                proxy_url = proxy_sync.get("proxy_url")
                if egress == "warp" and isinstance(proxy_url, str) and proxy_url:
                    cmd.extend(["--warp-proxy", proxy_url])
            elif backend == "docker":
                receipt_path = config_path.parent / "searxng-egress-receipt.json"
                report["searxng_egress_receipt"] = docker_searxng_egress_receipt(
                    paths, str(research["base_url"]), receipt_path,
                )
                cmd.extend(["--searxng-egress-receipt", str(receipt_path)])
            elif research.get("searxng_colocated") is True:
                cmd.append("--searxng-colocated")
            elif research.get("searxng_egress_receipt"):
                cmd.extend(["--searxng-egress-receipt", str(research["searxng_egress_receipt"])])
            else:
                raise RuntimeError(
                    "SearXNG upstream egress is unbound; configure searxng_colocated or searxng_egress_receipt"
                )
            if egress != "warp":
                note = str(research.get("egress_note", "administrator-approved replacement egress"))
                cmd.extend(["--egress", "replacement", "--egress-note", note])
            proc = run(cmd, check=False, timeout=max(30.0, args.startup_timeout))
            report["preflight"] = {
                "returncode": proc.returncode,
                "stdout": proc.stdout[-4000:],
                "stderr": proc.stderr[-4000:],
                "report": str(output),
            }
            if proc.returncode != 0:
                raise RuntimeError("SearXNG/WARP preflight failed")

        print(json.dumps(report, indent=2))
        return 0
    except (OSError, KeyError, json.JSONDecodeError, RuntimeError, subprocess.TimeoutExpired, ValueError) as exc:
        print(json.dumps({"status": "failed", "error": str(exc)}, indent=2), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
