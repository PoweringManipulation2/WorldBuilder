#!/usr/bin/env python3
"""Fetch one MediaWiki/Fandom page through resilient, auditable transports.

Transport order is API-first because normal Fandom article HTML is frequently
challenged by Cloudflare while ``api.php?action=parse`` remains available.  The
script writes a compact JSON record that child workers can inspect without
embedding a full browser page in the assignment prompt.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any

USER_AGENT = "WorldBuilder/3.6 (+local research worker; respectful MediaWiki client)"


def request_bytes(url: str, timeout: float) -> tuple[int, bytes, str, str]:
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT, "Accept": "application/json,text/html;q=0.9,*/*;q=0.5"})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return int(resp.status), resp.read(), str(resp.headers.get("Content-Type", "")), str(resp.geturl())


def request_json(url: str, timeout: float) -> dict[str, Any]:
    status, body, _content_type, _final = request_bytes(url, timeout)
    if status != 200:
        raise RuntimeError(f"HTTP {status}")
    value = json.loads(body.decode("utf-8"))
    if not isinstance(value, dict):
        raise RuntimeError("JSON response is not an object")
    if isinstance(value.get("error"), dict):
        code = value["error"].get("code", "api-error")
        info = value["error"].get("info", "unknown MediaWiki error")
        raise RuntimeError(f"{code}: {info}")
    return value


def add_params(url: str, params: dict[str, Any]) -> str:
    parsed = urllib.parse.urlsplit(url)
    query = urllib.parse.parse_qsl(parsed.query, keep_blank_values=True)
    query.extend((key, str(value)) for key, value in params.items() if value is not None)
    return urllib.parse.urlunsplit((parsed.scheme, parsed.netloc, parsed.path, urllib.parse.urlencode(query), ""))


def infer_api_url(page_url: str) -> str:
    parsed = urllib.parse.urlsplit(page_url)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        raise ValueError("page URL must be absolute HTTP(S)")
    return urllib.parse.urlunsplit((parsed.scheme, parsed.netloc, "/api.php", "", ""))


def title_from_url(page_url: str) -> str:
    parsed = urllib.parse.urlsplit(page_url)
    query = dict(urllib.parse.parse_qsl(parsed.query))
    if query.get("title"):
        return urllib.parse.unquote(query["title"]).replace("_", " ")
    marker = "/wiki/"
    if marker in parsed.path:
        return urllib.parse.unquote(parsed.path.split(marker, 1)[1]).replace("_", " ")
    last = parsed.path.rstrip("/").rsplit("/", 1)[-1]
    if last:
        return urllib.parse.unquote(last).replace("_", " ")
    raise ValueError("could not infer MediaWiki title from page URL")


def extract_parse_text(value: Any) -> str:
    if isinstance(value, str):
        return value
    if isinstance(value, dict):
        star = value.get("*")
        if isinstance(star, str):
            return star
    return ""


def api_parse(api_url: str, title: str, timeout: float) -> dict[str, Any]:
    url = add_params(api_url, {
        "action": "parse",
        "page": title,
        "redirects": 1,
        "prop": "text|wikitext|links|categories|templates|tocdata|revid|displaytitle",
        "format": "json",
        "formatversion": 2,
        "disableeditsection": 1,
        "disablelimitreport": 1,
    })
    payload = request_json(url, timeout)
    parsed = payload.get("parse")
    if not isinstance(parsed, dict):
        raise RuntimeError("action=parse returned no parse object")
    html = extract_parse_text(parsed.get("text"))
    wikitext = extract_parse_text(parsed.get("wikitext"))
    if not html and not wikitext:
        raise RuntimeError("action=parse returned neither rendered HTML nor wikitext")
    return {
        "method": "mediawiki_action_parse",
        "request_url": url,
        "title": parsed.get("title") or title,
        "pageid": parsed.get("pageid"),
        "revid": parsed.get("revid"),
        "displaytitle": parsed.get("displaytitle"),
        "rendered_html": html,
        "wikitext": wikitext,
        "links": parsed.get("links") if isinstance(parsed.get("links"), list) else [],
        "categories": parsed.get("categories") if isinstance(parsed.get("categories"), list) else [],
        "templates": parsed.get("templates") if isinstance(parsed.get("templates"), list) else [],
        "tocdata": parsed.get("tocdata") if isinstance(parsed.get("tocdata"), list) else [],
    }


def api_revision(api_url: str, title: str, timeout: float) -> dict[str, Any]:
    url = add_params(api_url, {
        "action": "query",
        "prop": "revisions|info|categories|links",
        "titles": title,
        "rvprop": "ids|timestamp|content",
        "rvslots": "main",
        "cllimit": "max",
        "pllimit": "max",
        "redirects": 1,
        "format": "json",
        "formatversion": 2,
    })
    payload = request_json(url, timeout)
    pages = payload.get("query", {}).get("pages", []) if isinstance(payload.get("query"), dict) else []
    if not isinstance(pages, list) or not pages or not isinstance(pages[0], dict) or pages[0].get("missing") is True:
        raise RuntimeError("revision query returned no page")
    page = pages[0]
    revisions = page.get("revisions") if isinstance(page.get("revisions"), list) else []
    revision = revisions[0] if revisions and isinstance(revisions[0], dict) else {}
    slots = revision.get("slots") if isinstance(revision.get("slots"), dict) else {}
    main = slots.get("main") if isinstance(slots.get("main"), dict) else {}
    content = main.get("content") or main.get("*") or revision.get("*") or ""
    if not isinstance(content, str) or not content:
        raise RuntimeError("revision query returned no wikitext")
    return {
        "method": "mediawiki_revision_wikitext",
        "request_url": url,
        "title": page.get("title") or title,
        "pageid": page.get("pageid"),
        "revid": revision.get("revid"),
        "timestamp": revision.get("timestamp"),
        "rendered_html": "",
        "wikitext": content,
        "links": page.get("links") if isinstance(page.get("links"), list) else [],
        "categories": page.get("categories") if isinstance(page.get("categories"), list) else [],
        "templates": [],
        "tocdata": [],
    }


def normal_html(page_url: str, timeout: float) -> dict[str, Any]:
    status, body, content_type, final_url = request_bytes(page_url, timeout)
    if status != 200:
        raise RuntimeError(f"HTTP {status}")
    if "html" not in content_type.casefold():
        raise RuntimeError(f"unexpected content type {content_type!r}")
    text = body.decode("utf-8", errors="replace")
    if not text.strip():
        raise RuntimeError("empty HTML response")
    return {
        "method": "normal_page_html",
        "request_url": page_url,
        "final_url": final_url,
        "title": title_from_url(final_url),
        "rendered_html": text,
        "wikitext": "",
        "links": [],
        "categories": [],
        "templates": [],
        "tocdata": [],
    }


def fetch_page(page_url: str, api_url: str | None, timeout: float, retries: int) -> dict[str, Any]:
    title = title_from_url(page_url)
    endpoint = api_url or infer_api_url(page_url)
    attempts: list[dict[str, str]] = []
    methods = (
        ("mediawiki_action_parse", lambda: api_parse(endpoint, title, timeout)),
        ("mediawiki_revision_wikitext", lambda: api_revision(endpoint, title, timeout)),
        ("normal_page_html", lambda: normal_html(page_url, timeout)),
    )
    for method_name, method in methods:
        for attempt in range(1, max(1, retries) + 1):
            try:
                result = method()
                result.update({
                    "kind": "worldbuilder-page-fetch",
                    "fetch_version": 1,
                    "source_url": page_url,
                    "api_url": endpoint,
                    "requested_title": title,
                    "attempts": attempts,
                })
                return result
            except (OSError, RuntimeError, ValueError, urllib.error.URLError, json.JSONDecodeError) as exc:
                attempts.append({"method": method_name, "attempt": str(attempt), "error": str(exc)})
                if attempt < max(1, retries):
                    time.sleep(min(2.0, 0.25 * (2 ** (attempt - 1))))
    raise RuntimeError(json.dumps({"source_url": page_url, "api_url": endpoint, "attempts": attempts}, ensure_ascii=False))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--url", required=True, help="Canonical wiki article URL")
    parser.add_argument("--api-url", help="Known MediaWiki api.php endpoint")
    parser.add_argument("--output", help="Write complete fetch JSON to this path")
    parser.add_argument("--cache-dir", help="Optional cache directory; key is URL+API URL")
    parser.add_argument("--timeout", type=float, default=25.0)
    parser.add_argument("--retries", type=int, default=2)
    args = parser.parse_args()
    try:
        cache_path: Path | None = None
        if args.cache_dir:
            key = hashlib.sha256(f"{args.url}\n{args.api_url or ''}".encode("utf-8")).hexdigest()
            cache_path = Path(args.cache_dir).expanduser().resolve() / f"{key}.json"
            if cache_path.exists():
                value = json.loads(cache_path.read_text(encoding="utf-8"))
                print(json.dumps({"status": "cached", "method": value.get("method"), "path": str(cache_path)}, ensure_ascii=False))
                if args.output:
                    Path(args.output).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
                return 0
        result = fetch_page(args.url, args.api_url, args.timeout, args.retries)
        if cache_path:
            cache_path.parent.mkdir(parents=True, exist_ok=True)
            cache_path.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        if args.output:
            out = Path(args.output)
            out.parent.mkdir(parents=True, exist_ok=True)
            out.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        print(json.dumps({
            "status": "fetched",
            "method": result.get("method"),
            "title": result.get("title"),
            "html_chars": len(result.get("rendered_html", "")),
            "wikitext_chars": len(result.get("wikitext", "")),
            "attempt_count": len(result.get("attempts", [])) + 1,
            "output": args.output,
        }, ensure_ascii=False))
        return 0
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
