#!/usr/bin/env python3
"""Conservatively repair card/lorebook entry compatibility issues.

The default path never invents optional SillyTavern fields and never treats an
application extension key as a CCv3 requirement. Legacy alias mirroring is
available only through the explicit ``--legacy-mirrors`` option.
"""
from __future__ import annotations

import argparse
import json
import shutil
import sys
from pathlib import Path
from typing import Any

from wb_common import WorldBuilderError, atomic_write_json, detect_artifact, iter_entries

CORE_POSITIONS = {0: "before_char", 1: "after_char"}
# Canonical vocabulary matches scripts/placement_contract.py SEMANTIC_POSITIONS.
# Values are the SillyTavern world_info_position enum:
# before=0, after=1, ANTop=2, ANBottom=3, atDepth=4, EMTop=5, EMBottom=6, outlet=7.
EXTENDED_POSITIONS = {
    "before_char": 0,
    "after_char": 1,
    "authors_note_top": 2,
    "authors_note_bottom": 3,
    "depth": 4,
    "before_examples": 5,
    "after_examples": 6,
    "outlet": 7,
}
# Superseded spellings accepted on input only; never emitted.
LEGACY_POSITION_ALIASES = {
    "before_an": "authors_note_top",
    "after_an": "authors_note_bottom",
    "at_depth": "depth",
    "before_em": "before_examples",
    "after_em": "after_examples",
}
LEGACY_ALIAS_PAIRS = {
    "preventRecursion": "prevent_recursion",
    "excludeRecursion": "exclude_recursion",
    "delayUntilRecursion": "delay_until_recursion",
    "caseSensitive": "case_sensitive",
    "matchWholeWords": "match_whole_words",
    "useGroupScoring": "use_group_scoring",
    "scanDepth": "scan_depth",
    "groupOverride": "group_override",
    "groupWeight": "group_weight",
}


def load_json_strip_bom(path: Path) -> Any:
    raw = path.read_bytes()
    if raw.startswith(b"\xef\xbb\xbf"):
        raw = raw[3:]
    return json.loads(raw.decode("utf-8"))


def dedupe_casefold(values: list[Any]) -> tuple[list[Any], int]:
    seen: set[str] = set()
    output: list[Any] = []
    removed = 0
    for value in values:
        if not isinstance(value, str):
            output.append(value)
            continue
        marker = value.casefold()
        if marker in seen:
            removed += 1
            continue
        seen.add(marker)
        output.append(value)
    return output, removed


def repair_entry(entry: dict[str, Any], embedded: bool, legacy_mirrors: bool) -> list[str]:
    fixes: list[str] = []
    for field in ("keys", "key", "secondary_keys", "keysecondary"):
        if isinstance(entry.get(field), list):
            repaired, removed = dedupe_casefold(entry[field])
            if removed:
                entry[field] = repaired
                fixes.append(f"deduplicated {removed} case-insensitive {field} value(s)")

    if embedded:
        ext = entry.get("extensions")
        if ext is None:
            ext = {}
            entry["extensions"] = ext
            fixes.append("created missing extensions object")
        elif not isinstance(ext, dict):
            raise WorldBuilderError("embedded entry.extensions is not an object")

        position = entry.get("position")
        if isinstance(position, int) and not isinstance(position, bool):
            ext.setdefault("position", position)
            if position in CORE_POSITIONS:
                entry["position"] = CORE_POSITIONS[position]
                fixes.append(f"converted core position {position} to {entry['position']!r}")
            else:
                entry.pop("position", None)
                fixes.append(f"moved extended position {position} into extensions.position")
        elif isinstance(position, str) and position not in {"before_char", "after_char"}:
            canonical = LEGACY_POSITION_ALIASES.get(position, position)
            mapped = EXTENDED_POSITIONS.get(canonical)
            if mapped is not None:
                ext.setdefault("position", mapped)
                entry.pop("position", None)
                if canonical != position:
                    fixes.append(
                        f"normalized legacy position {position!r} to {canonical!r} "
                        f"and moved it into extensions.position={mapped}"
                    )
                else:
                    fixes.append(f"moved extended position {position!r} into extensions.position={mapped}")

        for camel, snake in LEGACY_ALIAS_PAIRS.items():
            if camel in ext and snake in ext and ext[camel] != ext[snake]:
                raise WorldBuilderError(f"extensions aliases disagree: {camel}={ext[camel]!r}, {snake}={ext[snake]!r}")
            if legacy_mirrors:
                if camel in ext and snake not in ext:
                    ext[snake] = ext[camel]
                    fixes.append(f"added requested legacy alias extensions.{snake}")
                elif snake in ext and camel not in ext:
                    ext[camel] = ext[snake]
                    fixes.append(f"added requested legacy alias extensions.{camel}")
    return fixes


def main() -> int:
    parser = argparse.ArgumentParser(description="Repair conservative WorldBuilder compatibility issues.")
    parser.add_argument("path")
    parser.add_argument("--output")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--no-backup", action="store_true")
    parser.add_argument(
        "--legacy-mirrors",
        action="store_true",
        help="Opt in to historical camelCase/snake_case alias duplication for older target runtimes.",
    )
    args = parser.parse_args()

    source = Path(args.path).expanduser().resolve()
    output = Path(args.output).expanduser().resolve() if args.output else source
    if not source.exists():
        print(f"ERROR: file not found: {source}", file=sys.stderr)
        return 2
    try:
        data = load_json_strip_bom(source)
        info = detect_artifact(data)
        embedded = info.kind == "card_v3_embedded"
        changes: list[tuple[str, list[str]]] = []
        for ref in iter_entries(data):
            fixes = repair_entry(ref.entry, embedded, args.legacy_mirrors)
            if fixes:
                changes.append((ref.path, fixes))
    except (OSError, json.JSONDecodeError, WorldBuilderError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2

    for path, fixes in changes:
        print(path)
        for fix in fixes:
            print(f"  - {fix}")
    print(f"Repairs: {sum(len(items) for _, items in changes)} across {len(changes)} entry/entries")
    if args.dry_run:
        return 0
    if output == source and not args.no_backup:
        backup = source.with_suffix(source.suffix + ".pre-repair.json")
        shutil.copy2(source, backup)
        print(f"Backup: {backup}")
    atomic_write_json(output, data)
    print(f"Wrote: {output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
