#!/usr/bin/env python3
"""Materialize or retry WorldBuilder's conversational/custom generation path."""
from __future__ import annotations
import argparse, json, shutil, sys
from pathlib import Path
from pipeline_stage_gate import advance as advance_pipeline_stage
from repair_loop_guard import attempt as repair_attempt, clear as repair_clear
from lock_contract import is_locked, lock_reason
from transformation_map import mapping_context
from wb_common import WorldBuilderError, atomic_write_json, build_identity_index, load_build_state, load_json, normalize_identity, resolve_state_path, sha256_file

CONTRACT = "worldbuilder-custom-pipeline-v1"
RECEIPT_KIND = "worldbuilder-custom-generation-receipt"
REPAIR_GATE = "custom-pipeline-freeform-generation"

def _require_active(state: dict) -> None:
    custom = state.get("custom_pipeline") if isinstance(state.get("custom_pipeline"), dict) else {}
    if custom.get("active") is not True:
        raise WorldBuilderError("custom_pipeline.py is only valid for a build initialized with --custom-pipeline")
    if not str(custom.get("trigger_reason") or "").strip():
        raise WorldBuilderError("custom pipeline state has no trigger_reason")

def record_failure(build_state: str, detail: str) -> dict:
    _root, state = load_build_state(build_state); _require_active(state)
    return repair_attempt(build_state, REPAIR_GATE, detail)

def complete_generation(build_state: str, input_path: str, transformation_ids: list[str] | None = None) -> dict:
    state_path = Path(build_state).resolve(); root, state = load_build_state(state_path); _require_active(state)
    source = Path(input_path).expanduser().resolve()
    if not source.is_file(): raise WorldBuilderError(f"custom generation input does not exist: {source}")
    try: source.relative_to(root)
    except ValueError as exc: raise WorldBuilderError("custom generation input must be inside this build workspace") from exc
    data=load_json(source)
    if not isinstance(data, dict): raise WorldBuilderError("custom generation input must be a JSON object")
    transformation_context = mapping_context(root, state, transformation_ids or [])
    manifest_path = resolve_state_path(root, state, "manifest")
    manifest = load_json(manifest_path)
    manifest_index = build_identity_index(manifest)
    output_index = build_identity_index(data)
    blocked = []
    for identity, (_path, planned_entry) in manifest_index.items():
        if identity in output_index and is_locked(planned_entry):
            blocked.append((identity, lock_reason(planned_entry)))
    if blocked:
        detail = "; ".join(f"UID {uid}: {reason}" for uid, reason in blocked)
        raise WorldBuilderError(
            "guided/custom generation would overwrite author-locked entries: " + detail +
            ". Unlock them explicitly before retrying; Guided Mode never overrides a lock."
        )
    target=resolve_state_path(root,state,"merge_input"); target.parent.mkdir(parents=True,exist_ok=True)
    if source != target: shutil.copy2(source,target)
    auto_review=bool((state.get("budget") or {}).get("auto_review_required"))
    lineage_target=target
    if auto_review:
        before=resolve_state_path(root,state,"context_budget_before"); before.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(target,before); lineage_target=before
    state.setdefault("status",{})["merge"]="complete"
    state.setdefault("lineage",{})["merge"]={"output":str(lineage_target.relative_to(root)).replace("\\","/"),"sha256":sha256_file(lineage_target),"phase_files":[],"mixed_lineage":False,"binding_counts":{"custom_freeform":1},"snapshot":"context_budget_before" if auto_review else None}
    receipt={"kind":RECEIPT_KIND,"receipt_version":1,"contract":CONTRACT,"status":"passed","build_id":state.get("build_id"),"trigger_reason":state.get("custom_pipeline",{}).get("trigger_reason"),"input":str(source.relative_to(root)).replace("\\","/"),"input_sha256":sha256_file(source),"merged":str(target.relative_to(root)).replace("\\","/"),"merged_sha256":sha256_file(target),"generation_means":"freeform","transformation_context":transformation_context,"downstream_contract":"ordinary WorldBuilder gates remain mandatory"}
    rp=resolve_state_path(root,state,"custom_generation_receipt"); atomic_write_json(rp,receipt); state["lineage"]["custom_generation_receipt_sha256"]=sha256_file(rp); atomic_write_json(state_path,state)
    repair_clear(str(state_path),REPAIR_GATE); advance_pipeline_stage(state_path,"merge_complete")
    receipt["receipt"]=str(rp.relative_to(root)).replace("\\","/"); receipt["receipt_sha256"]=sha256_file(rp); return receipt

def main()->int:
    p=argparse.ArgumentParser(description=__doc__); p.add_argument("--build-state",required=True); sub=p.add_subparsers(dest="command",required=True)
    f=sub.add_parser("failure"); f.add_argument("--detail",required=True)
    c=sub.add_parser("complete-generation"); c.add_argument("--input",required=True); c.add_argument("--transformation-id",action="append",default=[])
    a=p.parse_args()
    try:
        result=record_failure(a.build_state,a.detail) if a.command=="failure" else complete_generation(a.build_state,a.input,a.transformation_id)
        print(json.dumps(result,ensure_ascii=False,indent=2)); return 0
    except (WorldBuilderError,OSError,ValueError,json.JSONDecodeError) as exc: print(f"ERROR: {exc}",file=sys.stderr); return 1
if __name__=="__main__": raise SystemExit(main())
