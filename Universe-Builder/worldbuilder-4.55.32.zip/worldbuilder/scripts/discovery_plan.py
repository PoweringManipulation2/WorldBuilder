#!/usr/bin/env python3
"""Create an additive, high-recall breadth-discovery plan.

Unlike the legacy single-tier planner, this planner never lets a technically
valid sitemap suppress a larger AllPages, category, SearXNG, or link corpus.
Every usable source contributes to one canonical URL union with provenance,
independent baselines, bird-named worker ownership, and mandatory verification
rounds used later to measure completeness and saturation.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
import sys
import urllib.parse
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

from facet_inference import candidate_names, validate_candidates
from discovery_contract import (
    normalize_mediawiki_title,
    normalize_path_component,
    DISCOVERY_ASSIGNMENT_VERSION, DISCOVERY_PLAN_VERSION, DISCOVERY_RESULT_VERSION,
    DISCOVERY_RUNTIME_RECEIPT_VERSION, WORKER_PROMPT_VERSION, contract_block,
)
from wb_common import (
    WorldBuilderError,
    atomic_write_json,
    compute_run_timeout_seconds,
    load_build_state,
    load_json,
    resolve_state_path,
    sha256_file,
    worker_bird_name,
    worker_slug,
)

MAX_SITEMAP_AGE_DAYS = 183
JUNK_NAMESPACE = re.compile(
    r"(?:^|/)(?:User|User_talk|Talk|Template|File|Image|Special|Help|MediaWiki):",
    re.I,
)
JUNK_QUERY_KEYS = {"oldid", "diff", "action", "printable", "redirect"}
SOURCE_ORDER = (
    "allpages", "redirects", "alllinks", "special_allpages", "sitemap",
    "categories", "search_harvest", "internal_links", "bfs_seeds", "index_harvest",
)

SATURATION_PROFILES: dict[str, dict[str, int]] = {
    # Batch 55: the saturation knobs are a real speed/thoroughness trade-off
    # the person gets to choose. `standard` matches the historical defaults
    # exactly; `thorough` deepens the saturation proof for large books;
    # `fast` suits small, simple worlds (minimum rounds keep their floor of 2).
    "fast": {"minimum_verification_rounds": 2, "consecutive_low_yield_rounds": 2, "confirmed_dead_after_rounds": 1},
    "standard": {"minimum_verification_rounds": 2, "consecutive_low_yield_rounds": 2, "confirmed_dead_after_rounds": 2},
    "thorough": {"minimum_verification_rounds": 3, "consecutive_low_yield_rounds": 3, "confirmed_dead_after_rounds": 3},
}


def parse_time(value: Any) -> datetime | None:
    if not isinstance(value, str) or not value.strip():
        return None
    text = value.strip().replace("Z", "+00:00")
    try:
        parsed = datetime.fromisoformat(text)
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def canonicalize_url(value: Any, *, allow_category: bool = False) -> str | None:
    if isinstance(value, dict):
        value = value.get("url")
    if not isinstance(value, str):
        return None
    raw = value.strip()
    if not raw:
        return None
    try:
        parsed = urllib.parse.urlsplit(raw)
    except ValueError:
        return None
    if parsed.scheme.casefold() not in {"http", "https"} or not parsed.netloc:
        return None
    path = urllib.parse.unquote(parsed.path or "/")
    if JUNK_NAMESPACE.search(path):
        return None
    if not allow_category and re.search(r"(?:^|/)Category:", path, re.I):
        return None
    query = urllib.parse.parse_qsl(parsed.query, keep_blank_values=False)
    if any(key.casefold() in JUNK_QUERY_KEYS for key, _ in query):
        return None
    # Keep only identity-bearing MediaWiki title query values; drop tracking.
    kept: list[tuple[str, str]] = []
    for key, val in query:
        if key.casefold() == "title" and val:
            if not allow_category and val.casefold().startswith("category:"):
                return None
            if JUNK_NAMESPACE.search("/" + val):
                return None
            kept.append(("title", normalize_mediawiki_title(urllib.parse.unquote(val))))
    normalized_path = normalize_path_component(parsed.path or "/")
    netloc = parsed.netloc.casefold()
    scheme = parsed.scheme.casefold()
    normalized_query = urllib.parse.urlencode(kept, doseq=True)
    return urllib.parse.urlunsplit((scheme, netloc, normalized_path, normalized_query, ""))


def clean_urls(values: Any, *, allow_category: bool = False) -> list[str]:
    if isinstance(values, dict):
        values = values.get("urls", [])
    if not isinstance(values, list):
        return []
    seen: set[str] = set()
    cleaned: list[str] = []
    for item in values:
        url = canonicalize_url(item, allow_category=allow_category)
        if url and url not in seen:
            seen.add(url)
            cleaned.append(url)
    return cleaned


def category_urls(value: Any) -> tuple[dict[str, list[str]], list[str]]:
    mapping: dict[str, list[str]] = {}
    seeds: list[str] = []
    if isinstance(value, dict):
        for name, items in value.items():
            if str(name).startswith("_") or name in {"urls", "members", "category_pages", "spot_checks"}:
                continue
            members = clean_urls(items)
            if members:
                mapping[str(name)] = members
        for key in ("urls", "members"):
            members = clean_urls(value.get(key))
            if members:
                mapping.setdefault("uncategorized", []).extend(members)
        seeds.extend(clean_urls(value.get("category_pages"), allow_category=True))
    elif isinstance(value, list):
        members = clean_urls(value)
        if members:
            mapping["uncategorized"] = members
    # Stable dedupe inside every category.
    for key, values in list(mapping.items()):
        mapping[key] = list(dict.fromkeys(values))
    return mapping, list(dict.fromkeys(seeds))


def sitemap_metadata(sitemap: dict[str, Any], now: datetime) -> dict[str, Any]:
    lastmods: list[datetime] = []
    raw_urls = sitemap.get("urls")
    total_urls = len(raw_urls) if isinstance(raw_urls, list) else 0
    if isinstance(raw_urls, list):
        for item in raw_urls:
            if isinstance(item, dict):
                stamp = parse_time(item.get("lastmod"))
                if stamp:
                    lastmods.append(stamp)
    for key in ("newest_lastmod", "oldest_lastmod", "index_lastmod"):
        stamp = parse_time(sitemap.get(key))
        if stamp:
            lastmods.append(stamp)
    newest = max(lastmods) if lastmods else None
    oldest = min(lastmods) if lastmods else None
    ages = sorted(max(0, (now - stamp).days) for stamp in lastmods)
    current_count = sum(age <= MAX_SITEMAP_AGE_DAYS for age in ages)
    dated_ratio = len(lastmods) / max(1, total_urls)
    current_ratio = current_count / max(1, len(lastmods))
    median_age = ages[len(ages) // 2] if ages else None
    # Trust requires broad freshness, not one recently touched URL. The sitemap
    # remains additive regardless of trust state.
    broadly_current = bool(
        newest is not None
        and (now - newest).days <= MAX_SITEMAP_AGE_DAYS
        and median_age is not None
        and median_age <= MAX_SITEMAP_AGE_DAYS
        and current_ratio >= 0.80
    )
    return {
        "url_count": total_urls,
        "dated_url_count": len(lastmods),
        "dated_ratio": dated_ratio,
        "current_dated_ratio": current_ratio,
        "newest_lastmod": newest.isoformat().replace("+00:00", "Z") if newest else None,
        "oldest_lastmod": oldest.isoformat().replace("+00:00", "Z") if oldest else None,
        "newest_age_days": (now - newest).days if newest else None,
        "median_age_days": median_age,
        "freshness": "current" if broadly_current else ("mixed_or_stale" if newest else "undated"),
        "authoritative_candidate": broadly_current,
        "additive_only": True,
    }


def stable_hash(value: Any) -> str:
    payload = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def suggested_workers(page_count: int, target_pages_per_worker: int = 75) -> int:
    """Return total assignment count independently of concurrent child capacity.

    Concurrency limits how many assignments run at once; it must not collapse a
    1,000-page corpus into a handful of oversized prompts.
    """
    if page_count <= 0:
        return 1
    target = max(25, min(200, target_pages_per_worker))
    return max(1, min(page_count, math.ceil(page_count / target)))


def ramp_wave_sizes(
    total_assignments: int,
    max_concurrent: int,
    *,
    initial_wave: int = 4,
    expansion_wave: int = 10,
) -> list[int]:
    """Create health-gated dispatch waves with conservative tested defaults.

    The values are per-wave dispatch counts, not a cap on total assignments.
    ``4 -> 10 -> 20`` remains the default when the runtime cap is 20, but the
    first two wave sizes are explicit heuristics rather than compatibility laws.
    """
    remaining = max(0, total_assignments)
    cap = max(1, min(20, max_concurrent))
    first = max(1, min(cap, initial_wave))
    second = max(first, min(cap, expansion_wave))
    sizes: list[int] = []
    for desired in (first, second):
        if remaining <= 0:
            break
        size = min(remaining, desired, cap)
        sizes.append(size)
        remaining -= size
    while remaining > 0:
        size = min(remaining, cap)
        sizes.append(size)
        remaining -= size
    return sizes or [1]


def url_cost(url: str, provenance: Iterable[str]) -> float:
    parsed = urllib.parse.urlsplit(url)
    depth = len([part for part in parsed.path.split("/") if part])
    title_len = len(urllib.parse.unquote(parsed.path.rsplit("/", 1)[-1]))
    # Pages appearing in multiple source systems are more central and often
    # denser; slightly weight them so greedy partitioning balances real effort.
    return 1.0 + min(depth, 8) * 0.12 + min(title_len, 120) / 240.0 + max(0, len(set(provenance)) - 1) * 0.18


def balanced_partitions(urls: list[str], provenance: dict[str, list[str]], count: int) -> list[list[str]]:
    count = max(1, min(count, max(1, len(urls))))
    buckets: list[list[str]] = [[] for _ in range(count)]
    loads = [0.0 for _ in range(count)]
    weighted = sorted(((url_cost(url, provenance.get(url, [])), url) for url in urls), key=lambda item: (-item[0], item[1]))
    for cost, url in weighted:
        idx = min(range(count), key=lambda i: (loads[i], i))
        buckets[idx].append(url)
        loads[idx] += cost
    for bucket in buckets:
        bucket.sort()
    return [bucket for bucket in buckets if bucket]


def normalize_rounds(probe: dict[str, Any], corpus: set[str]) -> list[dict[str, Any]]:
    rounds: list[dict[str, Any]] = []

    def add_round(kind: str, number: int, values: Any) -> None:
        urls = clean_urls(values)
        if not urls:
            return
        rounds.append({"kind": kind, "source_round": number, "urls": urls})

    random_value = probe.get("random_samples")
    if isinstance(random_value, dict):
        random_value = random_value.get("rounds", [])
    if isinstance(random_value, list):
        if random_value and all(isinstance(item, str) or isinstance(item, dict) and "url" in item for item in random_value):
            add_round("random", 1, random_value)
        else:
            for index, values in enumerate(random_value, start=1):
                add_round("random", index, values)

    category_checks = probe.get("category_spot_checks")
    if isinstance(category_checks, dict):
        category_checks = category_checks.get("rounds", category_checks.get("urls", []))
    if isinstance(category_checks, list):
        if category_checks and all(isinstance(item, str) or isinstance(item, dict) and "url" in item for item in category_checks):
            add_round("category", 1, category_checks)
        else:
            for index, values in enumerate(category_checks, start=1):
                add_round("category", index, values)

    # Combine independent kinds by round number, while retaining provenance.
    combined: dict[int, dict[str, Any]] = {}
    for item in rounds:
        number = int(item["source_round"])
        row = combined.setdefault(number, {"round": number, "kinds": [], "urls": []})
        row["kinds"].append(item["kind"])
        row["urls"].extend(item["urls"])
    normalized: list[dict[str, Any]] = []
    for number in sorted(combined):
        row = combined[number]
        row["kinds"] = sorted(set(row["kinds"]))
        row["urls"] = list(dict.fromkeys(row["urls"]))
        row["outside_primary_count"] = sum(url not in corpus for url in row["urls"])
        normalized.append(row)
    return normalized


def source_metrics(
    source_lists: dict[str, list[str]],
    reported_total: int | None,
    independent_estimates: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Measure additive yield separately from independent completeness baselines.

    ``union_count`` is the result being evaluated, so it must never be used as
    its own independent denominator.  The lower bound is derived only from
    separately observed counts: MediaWiki statistics, complete/listed page
    enumerations, sitemap rows, category members, search results, and graph
    traversals.  The final discovery gate additionally requires independent
    verification saturation.
    """
    union: set[str] = set()
    rows: list[dict[str, Any]] = []
    for name in SOURCE_ORDER:
        urls = source_lists.get(name, [])
        before = len(union)
        union.update(urls)
        added = len(union) - before
        rows.append({
            "source": name,
            "listed_count": len(urls),
            "marginal_unique": added,
            "marginal_ratio": (added / max(1, before)) if before else (1.0 if added else 0.0),
        })
    estimates = independent_estimates if isinstance(independent_estimates, dict) else {}
    independent_keys = {
        "mediawiki_article_count", "allpages_listed_count", "special_allpages_count",
        "sitemap_count", "category_union_count", "searxng_union_count",
        "alllinks_count", "redirect_count", "bfs_union_count",
        "independent_lower_bound_page_count", "lower_bound_page_count",
    }
    numeric_estimates = [
        int(value) for key, value in estimates.items()
        if key in independent_keys and isinstance(value, int) and value >= 0 and not isinstance(value, bool)
    ]
    source_max = max((len(set(values)) for values in source_lists.values()), default=0)
    lower_bound = max([reported_total or 0, source_max] + numeric_estimates)
    independent_sources = sum(1 for name in SOURCE_ORDER if source_lists.get(name))
    families = {
        "enumeration": any(source_lists.get(name) for name in ("allpages", "special_allpages", "sitemap")),
        "graph": any(source_lists.get(name) for name in ("alllinks", "categories", "internal_links", "bfs_seeds")),
        "external_search": bool(source_lists.get("search_harvest")),
    }
    independent_families = sum(bool(value) for value in families.values())
    capture_ratio = min(1.0, len(union) / lower_bound) if lower_bound else 0.0
    return {
        "union_count": len(union),
        "reported_allpages_total": reported_total,
        "independent_estimates": estimates,
        "independent_source_count": independent_sources,
        "independent_source_families": families,
        "independent_family_count": independent_families,
        "largest_independent_source_count": source_max,
        "lower_bound_page_count": lower_bound,
        "lower_bound_is_independent_of_union": True,
        "estimated_capture_ratio": capture_ratio,
        "marginal_yield": rows,
        # Source-level saturation is a planning signal only. Final saturation is
        # measured from independently spawned verification workers.
        "source_saturated": independent_families >= 2 and capture_ratio >= 0.995,
    }

def assignment_payload(
    *,
    build_id: str,
    source_stance: str,
    stage: str,
    pass_number: int,
    index: int,
    urls: list[str],
    corpus_sha: str,
    method: str,
    label_suffix: str,
    root: Path | None = None,
    fetch_policy: dict[str, Any] | None = None,
    dispatch_wave: int | None = None,
    wave_position: int | None = None,
    run_timeout_seconds: int | None = None,
    facet_filter: dict[str, Any] | None = None,
    requested_model: str | None = None,
) -> tuple[str, dict[str, Any], str]:
    worker = worker_bird_name(index)
    slug = worker_slug(index)
    assignment_id = f"discovery-p{pass_number:02d}-{slug}"
    task_name = f"discovery_p{pass_number:02d}_{slug.replace('-', '_')}"
    output = f"artifacts/discoveries/p{pass_number:02d}-{slug}.json"
    runtime_receipt = f".work/discovery-runtime/{assignment_id}.json"
    delimiter = f"WORLDBUILDER_DISCOVERY_COMPLETE:{build_id}:{assignment_id}"
    created_at = datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")
    assignment = {
        "assignment_version": DISCOVERY_ASSIGNMENT_VERSION,
        "created_at": created_at,
        "assignment_id": assignment_id,
        "build_id": build_id,
        "role": "research",
        "stage": stage,
        "pass_number": pass_number,
        "worker": worker,
        "taskName": task_name,
        "label": f"{worker}: {label_suffix}",
        "source_stance": source_stance,
        "discovery_method": method,
        "corpus_sha256": corpus_sha,
        "scope": [f"exact URL ownership: {len(urls)} page(s)"],
        "page_urls": urls,
        "seed_urls": urls[: min(3, len(urls))],
        "output": output,
        "runtime_receipt": runtime_receipt,
        "expected_end_delimiter": delimiter,
        "planner_version": f"discovery-plan-v{DISCOVERY_PLAN_VERSION}",
        "worker_prompt_version": WORKER_PROMPT_VERSION,
        "result_schema_version": DISCOVERY_RESULT_VERSION,
        "runtime_receipt_version": DISCOVERY_RUNTIME_RECEIPT_VERSION,
    }
    if run_timeout_seconds is not None:
        assignment["run_timeout_seconds"] = run_timeout_seconds
    if requested_model is not None:
        assignment["requested_model"] = requested_model
    if facet_filter:
        assignment["facet_filter"] = dict(facet_filter)
        selectors = list(facet_filter.get("category_names", [])) + list(facet_filter.get("template_names", []))
        assignment["scope"].append("facet filter: " + str(facet_filter.get("requested_facet")) + " -> " + ", ".join(selectors))
    if fetch_policy:
        assignment["fetch_policy"] = dict(fetch_policy)
    if root is not None:
        root = root.resolve()
        assignment["workspace_root"] = str(root)
        assignment_abs = (root / ".work" / "assignments" / f"{assignment_id}.json").resolve()
        assignment["assignment_path_hint"] = str(assignment_abs)
        assignment["assignment_abs"] = str(assignment_abs)
        assignment["candidate_abs"] = str((root / ".work" / "discovery-candidates" / f"{assignment_id}.json").resolve())
        assignment["output_abs"] = str((root / output).resolve())
        assignment["runtime_receipt_abs"] = str((root / runtime_receipt).resolve())
        assignment["worker_kit_root"] = str((root / ".work" / "worker-kit").resolve())
        assignment["worker_prompt_abs"] = str((root / ".work" / "worker-kit" / "prompts" / "sweep-worker.md").resolve())
        assignment["commit_worker_result_abs"] = str((root / ".work" / "worker-kit" / "scripts" / "commit_worker_result.py").resolve())
        assignment["run_discovery_worker_abs"] = str((root / ".work" / "worker-kit" / "scripts" / "run_discovery_worker.py").resolve())
        bundle_path = root / ".work" / "worker-kit" / "bundle.json"
        bundle_sha = sha256_file(bundle_path) if bundle_path.exists() else None
        assignment["contract"] = contract_block(bundle_sha)
        if isinstance(assignment.get("fetch_policy"), dict):
            cache_rel = assignment["fetch_policy"].get("cache_directory") or assignment["fetch_policy"].get("cache_dir") or ".work/page-cache"
            assignment["fetch_policy"]["cache_directory_abs"] = str((root / cache_rel).resolve())
    if dispatch_wave is not None:
        assignment["dispatch_wave"] = dispatch_wave
        assignment["wave_position"] = wave_position
    return assignment_id, assignment, output


def build_argument_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--build-state", required=True)
    parser.add_argument("--probe", help="Probe JSON created by source_probe.py; defaults to build-state paths.discovery_probe.")
    parser.add_argument("--runtime-cap", "--max-concurrent", dest="runtime_cap", type=int, default=20, help="Maximum concurrent discovery children; hard-capped at 20")
    parser.add_argument("--initial-wave", type=int, default=4, help="Health-gated first-wave heuristic; default 4")
    parser.add_argument("--expansion-wave", type=int, default=10, help="Health-gated second-wave heuristic; default 10")
    parser.add_argument("--target-pages-per-worker", type=int, default=75, help="Partition target; concurrency does not reduce total assignment count")
    parser.add_argument("--saturation-profile", choices=tuple(SATURATION_PROFILES), default="standard",
                        help="Speed/thoroughness preset for the saturation policy (Batch 55). standard = historical defaults; thorough deepens the proof; fast suits small simple worlds. Explicit round flags below still override it.")
    parser.add_argument("--minimum-verification-rounds", type=int, default=None)
    parser.add_argument("--consecutive-low-yield-rounds", type=int, default=None)
    parser.add_argument("--confirmed-dead-after-rounds", type=int, default=None, help="Independent recovery-stage failures before a URL is treated as confirmed dead and excluded from further retry (0-5). Defaults to the value frozen into this build at creation (config discovery.confirmed_dead_after_rounds, default 2); an explicit value here overrides it for this plan only.")
    parser.add_argument("--replace-plan", action="store_true", help="Replace an existing undispatched plan only when no results or runtime receipts exist")
    parser.add_argument("--facet", help="Requested source-side facet, e.g. weapons or lore.")
    parser.add_argument("--facet-category", action="append", default=[], help="One real wiki category confirmed for the requested facet; repeat as needed.")
    parser.add_argument("--facet-template", action="append", default=[], help="One real infobox/navbox template confirmed for the requested facet; repeat as needed.")
    parser.add_argument("--facet-candidates-file", help="Candidate artifact produced by facet_inference.py; required when confirming template-based facet signals.")
    parser.add_argument("--facet-confirmed", action="store_true", help="Assert the proposed category/template mapping was shown to and confirmed by the user.")
    return parser


def validate_arguments(args) -> None:
    """Validate cross-argument planning options before build-state I/O."""
    facet = getattr(args, "facet", None)
    categories = list(getattr(args, "facet_category", None) or [])
    templates = list(getattr(args, "facet_template", None) or [])
    candidates_file = getattr(args, "facet_candidates_file", None)
    confirmed = bool(getattr(args, "facet_confirmed", False))
    selectors = categories + templates
    if facet or selectors or candidates_file:
        if not facet or not selectors:
            raise WorldBuilderError("facet-scoped discovery requires both --facet and at least one confirmed category or template")
        if templates and not candidates_file:
            raise WorldBuilderError("template-based facet filtering requires --facet-candidates-file from facet_inference.py")
        if not confirmed:
            raise WorldBuilderError("facet category/template mapping must be shown to and confirmed by the user before filtering")


def orchestrate(args) -> int:

    try:
        state_path = Path(args.build_state).resolve()
        root, state = load_build_state(state_path)
        if not isinstance(state.get("discovery"), dict) or not state["discovery"].get("required"):
            raise WorldBuilderError("discovery planning is only valid when discovery.required=true")
        probe_path = Path(args.probe).resolve() if args.probe else resolve_state_path(root, state, "discovery_probe")
        try:
            probe_path.relative_to(root)
        except ValueError as exc:
            raise WorldBuilderError("probe file must be inside the build workspace") from exc
        probe = load_json(probe_path)
        if not isinstance(probe, dict):
            raise WorldBuilderError("probe must contain a JSON object")
        if probe.get("kind") != "worldbuilder-source-probe" or int(probe.get("probe_version", 0) or 0) < 3:
            raise WorldBuilderError("probe must be a WorldBuilder source probe v3 or newer")
        if probe.get("build_id") != state.get("build_id"):
            raise WorldBuilderError("probe build_id does not match build-state.json")
        search_meta = probe.get("search_harvest") if isinstance(probe.get("search_harvest"), dict) else {}
        if not search_meta.get("attempted") and not clean_urls(search_meta.get("urls")):
            raise WorldBuilderError(
                "known-property planning requires the mandatory SearXNG harvest; run source_probe.py with --searxng-base-url"
            )
        if search_meta.get("attempted") and int(search_meta.get("successful_request_count", 0) or 0) <= 0:
            raise WorldBuilderError("SearXNG harvest has no successful requests")

        now = datetime.now(timezone.utc)
        sitemap = probe.get("sitemap") if isinstance(probe.get("sitemap"), dict) else {}
        allpages = probe.get("allpages") if isinstance(probe.get("allpages"), dict) else {}
        category_map, category_seed_urls = category_urls(probe.get("categories"))
        facet_filter = None
        if args.facet or args.facet_category or args.facet_template:
            def _cat_norm(value: str) -> str:
                value = str(value).strip()
                if value.casefold().startswith("category:"):
                    value = value.split(":", 1)[1]
                return re.sub(r"[_\s]+", " ", value).strip().casefold()
            real_by_norm = {_cat_norm(name): name for name in category_map}
            selected_categories, unknown = [], []
            for requested in args.facet_category:
                canonical = real_by_norm.get(_cat_norm(requested))
                if canonical is None:
                    unknown.append(requested)
                elif canonical not in selected_categories:
                    selected_categories.append(canonical)
            if unknown:
                raise WorldBuilderError("facet categories are not present in the probed wiki category list: " + ", ".join(unknown))
            selected_templates: list[str] = []
            candidates_sha = None
            candidates_path_value = None
            if args.facet_template:
                candidates_path = Path(args.facet_candidates_file).resolve()
                try:
                    candidates_path.relative_to(root)
                except ValueError as exc:
                    raise WorldBuilderError("facet candidates file must remain inside the build workspace") from exc
                candidates = validate_candidates(load_json(candidates_path), requested_facet=args.facet)
                allowed_templates = candidate_names(candidates, {"infobox_template", "navbox_template"})
                unknown_templates: list[str] = []
                for requested in args.facet_template:
                    raw_template = str(requested).strip()
                    if raw_template.casefold().startswith("template:"):
                        raw_template = raw_template.split(":", 1)[1]
                    normed = re.sub(r"[_\s]+", " ", raw_template).strip().casefold()
                    canonical = allowed_templates.get(normed)
                    if canonical is None:
                        unknown_templates.append(str(requested))
                    elif canonical not in selected_templates:
                        selected_templates.append(canonical)
                if unknown_templates:
                    raise WorldBuilderError("facet templates are not present in the proposed infobox/navbox candidate set: " + ", ".join(unknown_templates))
                candidates_sha = sha256_file(candidates_path)
                candidates_path_value = str(candidates_path.relative_to(root)).replace("\\", "/")
            facet_filter = {
                "requested_facet": args.facet.strip(),
                "category_names": selected_categories,
                "template_names": selected_templates,
                "mapping_confirmed": True,
                "matching": "exact_normalized_wiki_category_or_template",
                "facet_candidates": candidates_path_value,
                "facet_candidates_sha256": candidates_sha,
            }
        source_lists: dict[str, list[str]] = {
            "sitemap": clean_urls(sitemap.get("urls")),
            "allpages": clean_urls(allpages.get("urls")),
            "redirects": clean_urls(probe.get("redirects")),
            "alllinks": clean_urls(probe.get("alllinks")),
            "special_allpages": clean_urls(probe.get("special_allpages")),
            "categories": list(dict.fromkeys(url for values in category_map.values() for url in values)),
            "search_harvest": clean_urls(probe.get("search_harvest")),
            "internal_links": clean_urls(probe.get("internal_links")),
            "bfs_seeds": clean_urls(probe.get("bfs_seeds")),
            "index_harvest": [],
        }
        page_filter = probe.get("page_filter") if isinstance(probe.get("page_filter"), dict) else {}
        if page_filter.get("status") == "complete":
            source_lists["index_harvest"] = clean_urls(page_filter.get("harvested_urls"))
        if not any(source_lists.values()):
            raise WorldBuilderError("probe contains no usable sitemap, AllPages, redirects, AllLinks, Special:AllPages, category, search, internal-link, or BFS URLs")

        provenance_sets: dict[str, set[str]] = defaultdict(set)
        for source, urls in source_lists.items():
            for url in urls:
                provenance_sets[url].add(source)
        expected_urls = sorted(provenance_sets)
        provenance = {url: sorted(values) for url, values in sorted(provenance_sets.items())}

        filter_records: dict[str, dict[str, Any]] = {}
        if page_filter.get("status") == "complete":
            for row in page_filter.get("records", []):
                if not isinstance(row, dict):
                    continue
                url = canonicalize_url(row.get("url"))
                if url:
                    filter_records[url] = row
        worker_urls: list[str] = []
        prefilter_accounting: list[dict[str, Any]] = []
        for url in expected_urls:
            row = filter_records.get(url)
            classification = str(row.get("classification")) if isinstance(row, dict) else "content"
            if classification == "content":
                worker_urls.append(url)
                continue
            code = row.get("code") if isinstance(row, dict) else None
            reason = row.get("reason") if isinstance(row, dict) else None
            if not isinstance(code, str) or not isinstance(reason, str):
                # Unknown/incomplete filter records fail open to a normal worker.
                worker_urls.append(url)
                continue
            prefilter_accounting.append({
                "url": url,
                "classification": classification,
                "code": code,
                "reason": reason,
                "canonical_url": row.get("canonical_url"),
                "requested_title": row.get("requested_title"),
                "title": row.get("title"),
                "evidence": row.get("evidence") if isinstance(row.get("evidence"), list) else [],
            })

        reported_total_raw = allpages.get("reported_total", allpages.get("total"))
        try:
            reported_total = int(reported_total_raw) if reported_total_raw is not None else None
        except (TypeError, ValueError):
            reported_total = None
        if reported_total is not None and reported_total < len(source_lists["allpages"]):
            reported_total = len(source_lists["allpages"])

        metrics = source_metrics(source_lists, reported_total, probe.get("independent_estimates"))
        verification_rounds = normalize_rounds(probe, set(worker_urls))
        profile = SATURATION_PROFILES[args.saturation_profile]
        minimum_rounds = args.minimum_verification_rounds if args.minimum_verification_rounds is not None else profile["minimum_verification_rounds"]
        minimum_rounds = max(2, minimum_rounds)
        consecutive_low_yield_rounds = args.consecutive_low_yield_rounds if args.consecutive_low_yield_rounds is not None else profile["consecutive_low_yield_rounds"]
        if consecutive_low_yield_rounds < 1:
            raise WorldBuilderError("--consecutive-low-yield-rounds must be at least 1")
        if args.confirmed_dead_after_rounds is not None:
            confirmed_dead_after_rounds = args.confirmed_dead_after_rounds
        else:
            confirmed_dead_after_rounds = int((state.get("discovery") or {}).get("confirmed_dead_after_rounds", profile["confirmed_dead_after_rounds"]))
        if not 0 <= confirmed_dead_after_rounds <= 5:
            raise WorldBuilderError("--confirmed-dead-after-rounds must be between 0 and 5")
        if len(verification_rounds) < minimum_rounds:
            raise WorldBuilderError(
                f"probe provides {len(verification_rounds)} independent verification round(s); "
                f"at least {minimum_rounds} random/category rounds are required"
            )

        corpus_basis = {
            "build_id": state["build_id"],
            "probe_sha256": sha256_file(probe_path),
            "expected_urls": expected_urls,
            "provenance": provenance,
            "reported_allpages_total": reported_total,
            "independent_estimates": probe.get("independent_estimates", {}),
            "page_filter_status": page_filter.get("status"),
            "page_filter_policy": page_filter.get("policy") if isinstance(page_filter.get("policy"), dict) else {},
            "prefilter_accounting": prefilter_accounting,
            "worker_urls": worker_urls,
        }
        corpus_sha = stable_hash(corpus_basis)
        cap = max(1, min(20, args.runtime_cap))
        primary_count = suggested_workers(len(worker_urls), args.target_pages_per_worker)
        primary_partitions = balanced_partitions(worker_urls, provenance, primary_count) if worker_urls else []
        total_planned_assignments = len(primary_partitions) + minimum_rounds
        wave_sizes = ramp_wave_sizes(total_planned_assignments, cap, initial_wave=args.initial_wave, expansion_wave=args.expansion_wave)
        wave_for_index: dict[int, tuple[int, int]] = {}
        cursor = 0
        for wave_number, wave_size in enumerate(wave_sizes, start=1):
            for position in range(1, wave_size + 1):
                wave_for_index[cursor] = (wave_number, position)
                cursor += 1
        mediawiki = probe.get("mediawiki") if isinstance(probe.get("mediawiki"), dict) else {}
        base_host = urllib.parse.urlsplit(str(probe.get("base_url") or "")).netloc.casefold()
        fetch_policy = {
            "adapter": "mediawiki_api_first",
            "api_url": mediawiki.get("api_url"),
            "allowed_host": base_host,
            "language_scope": "exact_host",
            "transport_order": [
                "mediawiki_action_parse",
                "mediawiki_revision_wikitext",
                "normal_page_html",
            ],
            "cache_directory": ".work/page-cache",
            "normal_html_is_last_resort": True,
            "content_filter_policy": page_filter.get("policy") if isinstance(page_filter.get("policy"), dict) else {
                "include_media": True,
                "include_production": False,
                "transcripts_are_reference_only": True,
                "galleries_are_excluded": True,
                "harvest_index_links": True,
            },
            "page_filter_version": page_filter.get("filter_version", 1),
        }

        assignments_dir = resolve_state_path(root, state, "assignments")
        plan_path = resolve_state_path(root, state, "discovery_plan")
        assignments_dir.mkdir(parents=True, exist_ok=True)
        if plan_path.exists():
            existing = load_json(plan_path)
            same_probe = isinstance(existing, dict) and existing.get("probe_sha256") == sha256_file(probe_path)
            if same_probe and not args.replace_plan:
                # Plans and assignment hashes are immutable after first materialization.
                for row in existing.get("assignments", []):
                    ap = root / row.get("path", "")
                    if not ap.exists() or sha256_file(ap) != row.get("assignment_sha256"):
                        raise WorldBuilderError("existing discovery plan has a missing or modified assignment; repair it instead of regenerating")
                print(json.dumps({"status": "existing_plan_reused", "plan": str(plan_path), "assignments": len(existing.get("assignments", []))}, indent=2))
                return 0
            discoveries = resolve_state_path(root, state, "discoveries")
            runtimes = resolve_state_path(root, state, "discovery_runtime")
            has_outputs = any(discoveries.glob("*.json")) or any(runtimes.glob("*.json"))
            if has_outputs:
                raise WorldBuilderError("refusing to replace a dispatched discovery plan; create recovery assignments or a new build")
            if not args.replace_plan:
                raise WorldBuilderError("a discovery plan already exists for a different probe; use --replace-plan only before dispatch")
            for stale in assignments_dir.glob("discovery-p*.json"):
                stale.unlink()

        plan: dict[str, Any] = {
            "kind": "breadth-discovery-plan",
            "created_at": now.replace(microsecond=0).isoformat().replace("+00:00", "Z"),
            "plan_version": DISCOVERY_PLAN_VERSION,
            "assignment_version": DISCOVERY_ASSIGNMENT_VERSION,
            "result_version": DISCOVERY_RESULT_VERSION,
            "runtime_receipt_version": DISCOVERY_RUNTIME_RECEIPT_VERSION,
            "worker_prompt_version": WORKER_PROMPT_VERSION,
            "build_id": state["build_id"],
            "probe": str(probe_path.relative_to(root)).replace("\\", "/"),
            "probe_sha256": sha256_file(probe_path),
            "method": "additive_hybrid",
            "corpus_sha256": corpus_sha,
            "sources": {
                name: {"listed_count": len(urls), "urls": urls}
                for name, urls in source_lists.items()
            },
            "sitemap": sitemap_metadata(sitemap, now),
            "probe_health": {
                "mediawiki_api_available": bool((probe.get("mediawiki") or {}).get("api_url")) if isinstance(probe.get("mediawiki"), dict) else False,
                "allpages_complete": bool(allpages.get("complete")),
                "allpages_truncated": bool(allpages.get("truncated")),
                "redirects_complete": bool((probe.get("redirects") or {}).get("complete")) if isinstance(probe.get("redirects"), dict) else False,
                "redirects_truncated": bool((probe.get("redirects") or {}).get("truncated")) if isinstance(probe.get("redirects"), dict) else False,
                "alllinks_complete": bool((probe.get("alllinks") or {}).get("complete")) if isinstance(probe.get("alllinks"), dict) else False,
                "alllinks_truncated": bool((probe.get("alllinks") or {}).get("truncated")) if isinstance(probe.get("alllinks"), dict) else False,
                "special_allpages_complete": bool((probe.get("special_allpages") or {}).get("complete")) if isinstance(probe.get("special_allpages"), dict) else False,
                "sitemap_complete": bool(sitemap.get("complete")),
                "category_enumeration_complete": bool(((probe.get("categories") or {}).get("_meta") or {}).get("complete")) if isinstance(probe.get("categories"), dict) else False,
                "category_enumeration_truncated": not bool(((probe.get("categories") or {}).get("_meta") or {}).get("complete")) if isinstance(probe.get("categories"), dict) else True,
                "bfs_complete": bool((probe.get("internal_links") or {}).get("complete")) if isinstance(probe.get("internal_links"), dict) else False,
                "probe_error_count": len(probe.get("errors", [])) if isinstance(probe.get("errors"), list) else 0,
                "searxng_attempted": bool(search_meta.get("attempted") or source_lists.get("search_harvest")),
                "searxng_successful_request_count": int(search_meta.get("successful_request_count", 0) or (1 if source_lists.get("search_harvest") else 0)),
                "enumeration_channels": sum(bool(source_lists.get(name)) for name in ("allpages", "special_allpages", "sitemap")),
                "supplemental_channels": sum(bool(source_lists.get(name)) for name in ("redirects", "alllinks", "categories", "search_harvest", "internal_links", "bfs_seeds", "index_harvest")),
            },
            "category_map": category_map,
            "facet_filter": facet_filter,
            "category_seed_urls": category_seed_urls,
            "expected_urls": expected_urls,
            "worker_urls": worker_urls,
            "prefilter_accounting": prefilter_accounting,
            "page_filter": {
                "status": page_filter.get("status", "unavailable"),
                "filter_version": page_filter.get("filter_version"),
                "policy": page_filter.get("policy") if isinstance(page_filter.get("policy"), dict) else {},
                "classification_counts": page_filter.get("classification_counts") if isinstance(page_filter.get("classification_counts"), dict) else {},
                "input_url_sha256": page_filter.get("input_url_sha256"),
                "estimated_worker_reduction_ratio": page_filter.get("estimated_worker_reduction_ratio", 0.0),
            },
            "reference_only_urls": clean_urls(page_filter.get("reference_only_urls")) if page_filter.get("status") == "complete" else [],
            "alias_map": page_filter.get("alias_map") if isinstance(page_filter.get("alias_map"), list) else [],
            "url_provenance": provenance,
            "url_owners": {},
            "metrics_at_plan": {
                **metrics,
                "raw_union_count": len(expected_urls),
                "worker_candidate_count": len(worker_urls),
                "prefilter_accounted_count": len(prefilter_accounting),
                "estimated_worker_reduction_ratio": round(len(prefilter_accounting) / max(1, len(expected_urls)), 6),
            },
            "coverage_claim": {
                "kind": "bounded_source_set",
                "universal_web_completeness_claimed": False,
                "denominator": "expected_urls from declared enumerators, source families, and exclusions",
            },
            "coverage_policy": {
                "primary_url_ratio": 1.0,
                "allpages_reconciliation_ratio": 0.995,
                "special_allpages_reconciliation_ratio": 0.995,
                "sitemap_reconciliation_ratio": 0.995,
                "category_reconciliation_ratio": 0.98,
                "verification_url_ratio": 1.0,
                "recovery_required_for_any_gap": True,
            },
            "saturation_policy": {
                "saturation_profile": args.saturation_profile,
                "minimum_verification_rounds": minimum_rounds,
                "confirmed_dead_after_rounds": confirmed_dead_after_rounds,
                "consecutive_low_yield_rounds": consecutive_low_yield_rounds,
                "low_yield_entity_ratio": 0.002,
                "low_yield_new_url_count": 0,
                # Matches discovery_gate's own default. A floor of 0 made the effective
                # threshold `max(0, floor(entities * 0.002))`, which is 0 for any corpus
                # under 500 entities: a single first-contact entity in a verification
                # round then failed saturation on a fully covered wiki. The ratio is
                # correct for large corpora; the floor is what makes it survivable for
                # small ones, and it does not weaken large-corpus behaviour because the
                # ratio already exceeds 2 there.
                "minimum_new_entities_floor": 2,
                "minimum_independent_source_count": 3,
                "require_enumerator_and_supplemental": True,
            },
            "verification_rounds": verification_rounds,
            "ramp_policy": {
                "strategy": "health_gated_adaptive",
                "tested_defaults": {"initial_wave": 4, "expansion_wave": 10, "runtime_cap": 20},
                "configured_initial_wave": max(1, min(cap, args.initial_wave)),
                "configured_expansion_wave": max(1, min(cap, args.expansion_wave)),
                "max_concurrent": cap,
                "target_pages_per_worker": max(25, min(200, args.target_pages_per_worker)),
                "wave_sizes": wave_sizes,
                "require_wave_gate": True,
                "next_wave_unlock_command": "discovery_wave_gate.py",
            },
            "dispatch_waves": [
                {
                    "wave": number,
                    "planned_size": size,
                    "status": "unlocked" if number == 1 else "locked",
                    "assignment_ids": [],
                }
                for number, size in enumerate(wave_sizes, start=1)
            ],
            "assignments": [],
        }

        worker_index = 0
        per_page_seconds = int((state.get("timeouts") or {}).get("per_page_seconds", 20))
        for part in primary_partitions:
            assignment_id, assignment, output = assignment_payload(
                build_id=state["build_id"],
                source_stance=state.get("source", {}).get("stance", "source-canonical"),
                stage="breadth_discovery",
                pass_number=1,
                index=worker_index,
                urls=part,
                corpus_sha=corpus_sha,
                method="additive_hybrid",
                label_suffix="breadth discovery pass 1",
                root=root,
                fetch_policy=fetch_policy,
                dispatch_wave=wave_for_index[worker_index][0],
                wave_position=wave_for_index[worker_index][1],
                run_timeout_seconds=compute_run_timeout_seconds(len(part), per_page_seconds),
                facet_filter=facet_filter,
                requested_model=str((state.get("models") or {}).get("discovery", (state.get("models") or {}).get("subagent", "inherit"))),
            )
            path = assignments_dir / f"{assignment_id}.json"
            atomic_write_json(path, assignment)
            for url in part:
                if url in plan["url_owners"]:
                    raise WorldBuilderError(f"primary URL has duplicate owner: {url}")
                plan["url_owners"][url] = assignment_id
            plan["assignments"].append({
                "assignment_id": assignment_id,
                "worker": assignment["worker"],
                "taskName": assignment["taskName"],
                "stage": assignment["stage"],
                "pass_number": 1,
                "path": str(path.relative_to(root)).replace("\\", "/"),
                "assignment_sha256": sha256_file(path),
                "page_count": len(part),
                "output": output,
                "runtime_receipt": assignment["runtime_receipt"],
                "dispatch_wave": assignment["dispatch_wave"],
                "wave_position": assignment["wave_position"],
            })
            plan["dispatch_waves"][assignment["dispatch_wave"] - 1]["assignment_ids"].append(assignment_id)
            worker_index += 1

        # Verification rounds are independent re-checks. Their URLs may overlap
        # primary ownership, but each verification assignment has exact ownership
        # within its own pass and cannot claim another worker's pages.
        for round_offset, round_info in enumerate(verification_rounds[:minimum_rounds], start=2):
            urls = list(round_info["urls"])
            assignment_id, assignment, output = assignment_payload(
                build_id=state["build_id"],
                source_stance=state.get("source", {}).get("stance", "source-canonical"),
                stage="breadth_verification",
                pass_number=round_offset,
                index=worker_index,
                urls=urls,
                corpus_sha=corpus_sha,
                method="independent_spot_check",
                label_suffix=f"independent verification pass {round_offset - 1}",
                root=root,
                fetch_policy=fetch_policy,
                dispatch_wave=wave_for_index[worker_index][0],
                wave_position=wave_for_index[worker_index][1],
                run_timeout_seconds=compute_run_timeout_seconds(len(urls), per_page_seconds),
                facet_filter=facet_filter,
                requested_model=str((state.get("models") or {}).get("discovery", (state.get("models") or {}).get("subagent", "inherit"))),
            )
            assignment["verification_kind"] = round_info["kinds"]
            assignment["source_round"] = round_info["round"]
            path = assignments_dir / f"{assignment_id}.json"
            atomic_write_json(path, assignment)
            plan["assignments"].append({
                "assignment_id": assignment_id,
                "worker": assignment["worker"],
                "taskName": assignment["taskName"],
                "stage": assignment["stage"],
                "pass_number": round_offset,
                "path": str(path.relative_to(root)).replace("\\", "/"),
                "assignment_sha256": sha256_file(path),
                "page_count": len(urls),
                "output": output,
                "runtime_receipt": assignment["runtime_receipt"],
                "verification_kind": round_info["kinds"],
                "dispatch_wave": assignment["dispatch_wave"],
                "wave_position": assignment["wave_position"],
            })
            plan["dispatch_waves"][assignment["dispatch_wave"] - 1]["assignment_ids"].append(assignment_id)
            worker_index += 1

        plan["primary_worker_count"] = len(primary_partitions)
        plan["total_assignment_count"] = len(plan["assignments"])
        plan["runtime_cap"] = cap
        plan["max_concurrent"] = cap
        plan["assignment_manifest_sha256"] = stable_hash(plan["assignments"])
        atomic_write_json(plan_path, plan)

        state.setdefault("discovery", {})["plan_sha256"] = sha256_file(plan_path)
        state["discovery"]["corpus_sha256"] = corpus_sha
        state["discovery"]["status"] = "planned"
        state["discovery"]["max_concurrent"] = cap
        state["discovery"]["active_wave"] = 1
        state["discovery"]["ramp_strategy"] = "health_gated_adaptive"
        atomic_write_json(state_path, state)
        print(json.dumps({
            "status": "planned",
            "method": "additive_hybrid",
            "pages": len(expected_urls),
            "worker_pages": len(worker_urls),
            "prefilter_accounted": len(prefilter_accounting),
            "primary_workers": len(primary_partitions),
            "verification_rounds": minimum_rounds,
            "max_concurrent": cap,
            "dispatch_waves": wave_sizes,
            "sources": {name: len(urls) for name, urls in source_lists.items()},
            "plan": str(plan_path),
        }, indent=2))
        return 0
    except (WorldBuilderError, OSError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


def main() -> int:
    parser = build_argument_parser()
    args = parser.parse_args()
    try:
        validate_arguments(args)
    except WorldBuilderError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    return orchestrate(args)

if __name__ == "__main__":
    raise SystemExit(main())
