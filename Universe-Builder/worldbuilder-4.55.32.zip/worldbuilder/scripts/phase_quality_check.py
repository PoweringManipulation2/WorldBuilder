#!/usr/bin/env python3
"""Cheap non-authoritative duplicate/contradiction checks at phase boundaries."""
from __future__ import annotations
import argparse, json, re
from pathlib import Path
from typing import Any
from wb_common import WorldBuilderError, atomic_write_json, discover_phase_files, entry_uid, iter_entries, load_build_state, load_json, resolve_state_path

CONTRACT = "worldbuilder-phase-quality-v1"
TOKEN_RE = re.compile(r"[A-Za-z0-9']+")
NEGATIONS = {"not", "never", "no", "none", "cannot", "can't", "isn't", "wasn't", "doesn't", "didn't"}
STOP = {"the","a","an","and","or","of","to","in","on","for","with","as","at","by","from","that","this","these","those","is","are","was","were","be","been","being","it","its"}


def _name(entry: dict[str, Any]) -> str:
    for key in ("name", "comment"):
        value = entry.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    keys = entry.get("key", entry.get("keys"))
    if isinstance(keys, list) and keys:
        return str(keys[0])
    return entry_uid(entry, strict=False)


def _content(entry: dict[str, Any]) -> str:
    for key in ("content", "description", "personality"):
        value = entry.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return ""


def _tokens(text: str, *, strip_negation: bool = False) -> set[str]:
    out=set()
    for raw in TOKEN_RE.findall(text.casefold()):
        if raw in STOP:
            continue
        if strip_negation and raw in NEGATIONS:
            continue
        out.add(raw)
    return out


def _jaccard(a: set[str], b: set[str]) -> float:
    if not a or not b:
        return 0.0
    return len(a & b) / len(a | b)


def _sentences(text: str) -> list[str]:
    return [s.strip() for s in re.split(r"(?<=[.!?])\s+|[\r\n]+", text) if len(_tokens(s)) >= 3]


def analyze_entries(entries: list[dict[str, Any]], duplicate_threshold: float = 0.82, contradiction_threshold: float = 0.80) -> dict[str, Any]:
    findings=[]
    for i,left in enumerate(entries):
        lu=entry_uid(left, strict=False); lc=_content(left); lt=_tokens(lc)
        if not lu or not lc:
            continue
        for right in entries[i+1:]:
            ru=entry_uid(right, strict=False); rc=_content(right); rt=_tokens(rc)
            if not ru or not rc or ru==lu:
                continue
            sim=_jaccard(lt,rt)
            if sim >= duplicate_threshold:
                findings.append({"kind":"near_duplicate","uids":[lu,ru],"names":[_name(left),_name(right)],"similarity":round(sim,4),"action":"defer_to_audit"})
            for ls in _sentences(lc):
                lneg=bool(_tokens(ls) & NEGATIONS); lbase=_tokens(ls,strip_negation=True)
                for rs in _sentences(rc):
                    rneg=bool(_tokens(rs) & NEGATIONS)
                    if lneg == rneg:
                        continue
                    score=_jaccard(lbase,_tokens(rs,strip_negation=True))
                    if score >= contradiction_threshold:
                        findings.append({"kind":"possible_contradiction","uids":[lu,ru],"names":[_name(left),_name(right)],"similarity":round(score,4),"left":ls,"right":rs,"action":"defer_to_audit"})
                        break
                else:
                    continue
                break
    return {"contract":CONTRACT,"finding_count":len(findings),"findings":findings,"authoritative":False,"note":"Intermediate detector only. Findings are queued for full audit; nothing is merged or rewritten automatically."}


def analyze_build(build_state: str, *, write: bool = True) -> dict[str, Any]:
    root,state=load_build_state(build_state)
    phases=resolve_state_path(root,state,"phases")
    entries=[]
    for path in discover_phase_files(phases):
        data=load_json(path)
        for ref in iter_entries(data):
            if isinstance(ref.entry,dict):
                entries.append(ref.entry)
    report=analyze_entries(entries)
    report["phase_count"]=len(discover_phase_files(phases))
    report["entry_count"]=len(entries)
    if write:
        out=root/".work"/"findings"/"phase-quality-pre-merge.json"
        out.parent.mkdir(parents=True,exist_ok=True)
        atomic_write_json(out,report)
        report["report_path"]=str(out.relative_to(root)).replace("\\","/")
    return report


def main()->int:
    p=argparse.ArgumentParser(description="Run cheap duplicate/contradiction checks across completed phases.")
    p.add_argument("--build-state",required=True)
    p.add_argument("--no-write",action="store_true")
    args=p.parse_args()
    try:
        print(json.dumps(analyze_build(args.build_state,write=not args.no_write),ensure_ascii=False,indent=2))
        return 0
    except (WorldBuilderError,OSError,ValueError,json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}",file=__import__('sys').stderr); return 1
if __name__=="__main__": raise SystemExit(main())
