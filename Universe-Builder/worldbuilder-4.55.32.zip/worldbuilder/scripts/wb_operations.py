#!/usr/bin/env python3
"""Stable high-level Python operations for WorldBuilder callers.

This module is intentionally host-neutral. It wraps existing deterministic CLI
surfaces so a future standalone frontend or alternate agent host does not need
to know which script owns each pipeline operation. Worker dispatch remains a
host concern and is deliberately absent from this API.
"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
from datetime import datetime, timezone
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping

from wb_common import WorldBuilderError, atomic_write_json, load_build_state, resolve_state_path

SCRIPTS = Path(__file__).resolve().parent


@dataclass(frozen=True)
class CapabilitySet:
    """Host-neutral capability view returned by :func:`probe_capabilities`."""
    report: Mapping[str, Any]

    def status(self, name: str) -> str:
        row = self.report.get("capabilities", {}).get(name, {}) if isinstance(self.report, Mapping) else {}
        return str(row.get("status", "unknown")) if isinstance(row, Mapping) else "unknown"

    def available(self, name: str) -> bool:
        return self.status(name) == "available"

    @property
    def hard_stop(self) -> bool:
        return bool(self.report.get("hard_stop")) if isinstance(self.report, Mapping) else True


@dataclass(frozen=True)
class OperationResult:
    operation: str
    returncode: int
    stdout: str
    stderr: str
    data: Any | None

    @property
    def ok(self) -> bool:
        return self.returncode == 0


_OPERATION_SCRIPTS = {
    "create_build": "init_build.py",
    "probe_source": "source_probe.py",
    "plan_discovery": "discovery_plan.py",
    "gate_discovery": "discovery_gate.py",
    "validate_planning": "planning_gate.py",
    "prepare_generation": "phase_gate.py",
    "merge_generation": "merge_phases.py",
    "plan_audit": "audit_plan.py",
    "gate_audit": "audit_gate.py",
    "validate_output": "validate_output.py",
    "seal_delivery": "delivery_gate.py",
    "author_lock": "lock_contract.py",
    "selective_regeneration": "selective_regeneration.py",
    "update_sources": "source_sync.py",
    "revision_history": "revision_history.py",
    "package_plan": "package_plan.py",
    "runtime_verify": "runtime_verification.py",
    "decision_log": "decision_log.py",
    "terminology_dictionary": "terminology_dictionary.py",
    "transformation_map": "transformation_map.py",
    "runtime_bundle": "runtime_target_adapter.py",
    "extension_adapter": "extension_adapter.py",
    "behavioral_testdrive": "behavioral_testdrive.py",
    "settings_preset": "settings_preset.py",
    "public_diagnostics": "diagnostics_bundle.py",
}


def operation_names() -> tuple[str, ...]:
    return tuple(_OPERATION_SCRIPTS)


def invoke(operation: str, args: Iterable[str], *, check: bool = False) -> OperationResult:
    """Invoke one named WorldBuilder operation and parse JSON output when possible."""
    script = _OPERATION_SCRIPTS.get(operation)
    if script is None:
        raise ValueError(f"unknown WorldBuilder operation {operation!r}; expected one of {', '.join(operation_names())}")
    cmd = [sys.executable, str(SCRIPTS / script), *[str(x) for x in args]]
    proc = subprocess.run(cmd, text=True, capture_output=True, encoding="utf-8")
    data: Any | None = None
    text = proc.stdout.strip()
    if text:
        try:
            data = json.loads(text)
        except json.JSONDecodeError:
            data = None
    result = OperationResult(operation, proc.returncode, proc.stdout, proc.stderr, data)
    if check and not result.ok:
        raise RuntimeError(f"WorldBuilder operation {operation} failed ({result.returncode}): {result.stderr.strip()}")
    return result


def create_build(project_name: str, *, artifact_type: str, schema: int = 3, source_kind: str = "original", extra_args: Iterable[str] = ()) -> OperationResult:
    return invoke("create_build", [project_name, "--artifact-type", artifact_type, "--schema", str(schema), "--source-kind", source_kind, *extra_args])


def plan_discovery(build_state: str, probe: str, *, extra_args: Iterable[str] = ()) -> OperationResult:
    return invoke("plan_discovery", ["--build-state", build_state, "--probe", probe, *extra_args])


def validate_planning(build_state: str, *, diagnose: bool = False) -> OperationResult:
    args = ["--build-state", build_state]
    if diagnose:
        args.append("--diagnose")
    return invoke("validate_planning", args)


def plan_audit(build_state: str, stage: str, *, extra_args: Iterable[str] = ()) -> OperationResult:
    return invoke("plan_audit", ["--build-state", build_state, "--stage", stage, *extra_args])


def gate_audit(build_state: str, stage: str) -> OperationResult:
    return invoke("gate_audit", ["--build-state", build_state, "--stage", stage])


def probe_capabilities(**kwargs: Any) -> CapabilitySet:
    """Return the unified capability probe through one stable Python surface.

    This is additive to the host-neutral receipt vocabulary: it does not dispatch
    workers.  Callers may pass the same keyword arguments accepted by
    ``capability_probe.probe``.
    """
    from capability_probe import probe
    return CapabilitySet(probe(**kwargs))


VISION_TRANSITION_CHOICES = ("rerun_all", "new_work_only", "stay_text_only")
VISION_TRANSITION_PROMPT = (
    "Vision analysis became available after text-only generation work already exists. Choose one: "
    "[rerun_all] re-run all previously researched/generated entries with image analysis; "
    "[new_work_only] keep existing text-only work and use images only for new work; "
    "[stay_text_only] keep this build text-only."
)


def _iso_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def _generation_work_exists(root: Path, state: Mapping[str, Any]) -> bool:
    """Return true only for materialized generation work, not merely assignments/stage intent."""
    fallbacks = {"entry_checkpoints": root / ".work" / "entry-checkpoints"}
    for key in ("entry_checkpoints", "evidence_receipts", "phases"):
        try:
            path = resolve_state_path(root, dict(state), key, required=False)
        except WorldBuilderError:
            path = None
        path = path or fallbacks.get(key)
        if path and path.exists() and path.is_dir() and any(item.is_file() for item in path.rglob("*")):
            return True
    return False


def _validate_vision_limits(value: Any) -> dict[str, int]:
    if not isinstance(value, dict):
        raise WorldBuilderError("vision_limits must be an object")
    out: dict[str, int] = {}
    for key in ("max_images_per_request", "max_image_dimension_px", "max_image_bytes"):
        number = value.get(key)
        if not isinstance(number, int) or isinstance(number, bool) or number < 1:
            raise WorldBuilderError(f"vision_limits.{key} must be a positive integer")
        out[key] = number
    session = value.get("max_images_per_session")
    if session is not None:
        if not isinstance(session, int) or isinstance(session, bool) or session < 1:
            raise WorldBuilderError("vision_limits.max_images_per_session must be a positive integer when present")
        out["max_images_per_session"] = session
    return out


def reresolve_generation_vision(
    build_state: str,
    *,
    resolved_generation_model: str,
    vision_capable: str,
    transition_policy: str | None = None,
    checked_at: str | None = None,
    vision_limits: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Re-check agent-reported vision immediately before generation dispatch.

    The caller owns capability determination. This function never infers support from a
    model name. If vision becomes available after text-only generation work exists, it
    records a pending decision and refuses to silently choose how old work is handled.
    """
    model = str(resolved_generation_model).strip()
    if not model:
        raise WorldBuilderError("resolved_generation_model must name the actual model about to run generation")
    capability = str(vision_capable).strip().casefold()
    if capability not in {"available", "unavailable"}:
        raise WorldBuilderError("vision_capable must be explicitly reported as available or unavailable before generation dispatch")
    if transition_policy is not None:
        transition_policy = str(transition_policy).strip().casefold()
        if transition_policy not in VISION_TRANSITION_CHOICES:
            raise WorldBuilderError(f"transition_policy must be one of {', '.join(VISION_TRANSITION_CHOICES)}")

    new_limits = _validate_vision_limits(vision_limits) if vision_limits is not None else None

    state_path = Path(build_state).expanduser().resolve()
    root, state = load_build_state(state_path)
    settings = state.setdefault("settings", {})
    image = state.setdefault("image_analysis", {})
    mode = str(settings.get("image_analysis_mode", image.get("mode", "on"))).strip().casefold()
    if mode not in {"on", "off"}:
        raise WorldBuilderError("settings.image_analysis_mode must be 'on' or 'off'")
    old_capability = str(settings.get("vision_capable", image.get("vision_capable", "unknown"))).strip().casefold()
    old_effective = bool(settings.get("effective_image_mode", image.get("effective", False)))
    proposed_effective = mode == "on" and capability == "available"
    checked = checked_at or _iso_now()
    prior_work = _generation_work_exists(root, state)
    flip_with_prior_work = (not old_effective) and proposed_effective and prior_work

    check_record = {
        "checked_at": checked,
        "resolved_generation_model": model,
        "reported_vision_capable": capability,
        "previous_vision_capable": old_capability,
        "previous_effective_image_mode": old_effective,
        "proposed_effective_image_mode": proposed_effective,
        "prior_generation_work": prior_work,
    }
    settings["vision_capability_checked_at"] = checked
    settings["vision_capability_checked_model"] = model
    image["last_capability_check"] = check_record
    stored_limits = image.get("vision_limits") if isinstance(image.get("vision_limits"), dict) else None
    if new_limits is not None:
        image["vision_limits"] = {**new_limits, "model": model, "recorded_at": checked}
        image.pop("vision_limits_reprobe_required", None)
    elif stored_limits is not None and str(stored_limits.get("model", "")).strip() != model:
        image.pop("vision_limits", None)
        image["vision_limits_reprobe_required"] = True

    if flip_with_prior_work and transition_policy is None:
        pending = {
            "kind": "worldbuilder-vision-transition-decision-v1",
            "status": "decision_required",
            "prompt": VISION_TRANSITION_PROMPT,
            "options": list(VISION_TRANSITION_CHOICES),
            "proposed_vision_capable": capability,
            "proposed_effective_image_mode": True,
            "resolved_generation_model": model,
            "detected_at": checked,
        }
        image["pending_transition"] = pending
        atomic_write_json(state_path, state)
        return {**pending, "build_state": str(state_path)}

    if transition_policy is not None and not flip_with_prior_work and not image.get("pending_transition"):
        raise WorldBuilderError("transition_policy is only valid when a text-only to vision-enabled mid-build transition is pending")

    decision = transition_policy
    if decision == "stay_text_only":
        mode = "off"
        proposed_effective = False
        settings["image_analysis_mode"] = "off"
        image["mode"] = "off"
    settings["vision_capable"] = capability
    settings["effective_image_mode"] = proposed_effective
    image["vision_capable"] = capability
    image["effective"] = proposed_effective
    image["last_capability_check"] = {**check_record, "applied": True, "effective_image_mode": proposed_effective}
    if decision:
        image["last_transition_decision"] = {
            "kind": "worldbuilder-vision-transition-decision-v1",
            "decision": decision,
            "decided_at": checked,
            "resolved_generation_model": model,
            "requires_rerun_all": decision == "rerun_all",
        }
    image.pop("pending_transition", None)
    atomic_write_json(state_path, state)
    return {
        "status": "updated",
        "build_state": str(state_path),
        "resolved_generation_model": model,
        "vision_capable": capability,
        "effective_image_mode": proposed_effective,
        "transition_policy": decision,
        "requires_rerun_all": decision == "rerun_all",
        "vision_limits_recorded": new_limits is not None,
        "vision_limits_reprobe_required": bool(image.get("vision_limits_reprobe_required")),
    }


def update_sources(build_state: str, *, extra_args: Iterable[str] = ()) -> OperationResult:
    return invoke("update_sources", ["--build-state", build_state, "check", *extra_args])


def trace_sources(build_state: str, *, uid: str | None = None, claim_id: str | None = None, locator: str | None = None) -> OperationResult:
    selectors = [("--uid", uid), ("--claim-id", claim_id), ("--locator", locator)]
    active = [(flag, value) for flag, value in selectors if value is not None]
    if len(active) != 1:
        raise ValueError("trace_sources requires exactly one of uid, claim_id, or locator")
    flag, value = active[0]
    return invoke("update_sources", ["--build-state", build_state, "trace", flag, str(value)])

def discover_sources(build_state: str, probe: str, *, extra_args: Iterable[str] = ()) -> OperationResult:
    """Stable alias for discovery planning used by host/front-end callers."""
    return plan_discovery(build_state, probe, extra_args=extra_args)


def rollback_revision(build_state: str, revision_id: str, *, approve_lock_conflicts: bool = False) -> OperationResult:
    return invoke("revision_history", ["--build-state", build_state, "rollback", "--revision", revision_id, *(["--approve-lock-conflicts"] if approve_lock_conflicts else [])])





def resolve_terminology(dictionary: str, value: str) -> OperationResult:
    return invoke("terminology_dictionary", ["resolve", "--dictionary", dictionary, "--value", value])

def record_guided_decision(build_state: str, kind: str, payload: Mapping[str, Any]) -> OperationResult:
    return invoke("decision_log", ["--build-state", build_state, "record", "--kind", kind, "--payload-json", json.dumps(dict(payload), ensure_ascii=False)])


def consult_guided_decision(build_state: str, kind: str, identity: Mapping[str, Any]) -> OperationResult:
    return invoke("decision_log", ["--build-state", build_state, "consult", "--kind", kind, "--identity-json", json.dumps(dict(identity), ensure_ascii=False)])


def resolve_transformation(build_state: str, source_concept: str, target_concept: str, transformation_type: str, *, rationale: str | None = None) -> OperationResult:
    args = [
        "--build-state", build_state, "resolve",
        "--source-concept", source_concept,
        "--target-concept", target_concept,
        "--transformation-type", transformation_type,
    ]
    if rationale is not None:
        args += ["--rationale", rationale]
    return invoke("transformation_map", args)

def package_runtime_bundle(build_state: str) -> OperationResult:
    return invoke("runtime_bundle", ["bundle", "--build-state", build_state])



def serialize_extension(input_file: str, target_format: str, *, output_file: str | None = None) -> OperationResult:
    args = ["serialize", "--input", input_file, "--target", target_format]
    if output_file:
        args += ["--output", output_file]
    return invoke("extension_adapter", args)


def extension_capabilities() -> OperationResult:
    return invoke("extension_adapter", ["capabilities"])


def export_public_diagnostics(build_state: str, *, gate_output: str | None = None, include_generated_content: bool = False, output: str | None = None) -> OperationResult:
    args = ["--build-state", build_state]
    if gate_output:
        args += ["--gate-output", gate_output]
    if include_generated_content:
        args.append("--include-generated-content")
    if output:
        args += ["--output", output]
    return invoke("public_diagnostics", args)



def verify_runtime(build_state: str, prompt: str, *, observed_file: str | None = None) -> OperationResult:
    args = ["--build-state", build_state, "--prompt", prompt]
    if observed_file:
        args += ["--observed-file", observed_file]
    return invoke("runtime_verify", args)

def prepare_behavioral_testdrive(build_state: str, prompt: str, *, depth: int = 8, case_label: str | None = None) -> OperationResult:
    args = ["prepare", "--build-state", build_state, "--prompt", prompt, "--depth", str(depth)]
    if case_label:
        args += ["--case-label", case_label]
    return invoke("behavioral_testdrive", args)


def bind_behavioral_response(build_state: str, plan: str, *, response_file: str | None = None) -> OperationResult:
    args = ["bind-response", "--build-state", build_state, "--plan", plan]
    if response_file:
        args += ["--response-file", response_file]
    return invoke("behavioral_testdrive", args)


def finalize_behavioral_testdrive(build_state: str, plan: str, *, response_file: str | None = None, lens_verdict: str | None = None) -> OperationResult:
    args = ["finalize", "--build-state", build_state, "--plan", plan]
    if response_file:
        args += ["--response-file", response_file]
    if lens_verdict:
        args += ["--lens-verdict", lens_verdict]
    return invoke("behavioral_testdrive", args)



def validate_settings_preset(preset: str) -> OperationResult:
    return invoke("settings_preset", ["validate", "--preset", preset])


def export_settings_preset(build_state: str, output: str) -> OperationResult:
    return invoke("settings_preset", ["export", "--build-state", build_state, "--output", output])


def _main() -> int:
    parser = argparse.ArgumentParser(description="WorldBuilder host-neutral operation facade")
    sub = parser.add_subparsers(dest="command", required=True)
    vision = sub.add_parser("vision-recheck", help="Re-report generation-model vision immediately before dispatch")
    vision.add_argument("--build-state", required=True)
    vision.add_argument("--resolved-generation-model", required=True)
    vision.add_argument("--vision-capable", required=True, choices=("available", "unavailable"))
    vision.add_argument("--transition-policy", choices=VISION_TRANSITION_CHOICES)
    vision.add_argument("--checked-at")
    vision.add_argument("--vision-limits", help="Researched per-model image limits JSON (max_images_per_request, max_image_dimension_px, max_image_bytes, max_images_per_session (optional))")
    args = parser.parse_args()
    try:
        if args.command == "vision-recheck":
            result = reresolve_generation_vision(
                args.build_state,
                resolved_generation_model=args.resolved_generation_model,
                vision_capable=args.vision_capable,
                transition_policy=args.transition_policy,
                checked_at=args.checked_at,
                vision_limits=(json.loads(args.vision_limits) if args.vision_limits else None),
            )
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 2 if result.get("status") == "decision_required" else 0
        return 1
    except (WorldBuilderError, OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(_main())
