#!/usr/bin/env python3
"""Create a governed exclusion approval for terminal discovery leftovers."""
from __future__ import annotations
import argparse
import json
import re
import sys
import urllib.parse
from datetime import datetime, timezone
from discovery_contract import EXCLUSION_CODES, exclusion_policy
from discovery_plan import canonicalize_url
from write_discovery_approval import DISCOVERY_APPROVAL_VERSION
from wb_common import WorldBuilderError, atomic_write_json, load_build_state, load_json, resolve_state_path, sha256_file

def now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")

def infer_code(url: str) -> str | None:
    path = urllib.parse.unquote(urllib.parse.urlsplit(url).path).casefold()
    if "/message_wall:" in path: return "message_wall"
    if re.search(r"/(?:user|user_talk|talk|forum|thread):", path): return "user_discussion"
    if re.search(r"/(?:special|help|mediawiki|template):", path): return "non_content_namespace"
    if re.search(r"/(?:file|image):", path) or "/gallery" in path: return "gallery_or_media_only"
    return None

def parse_manual(values: list[str]) -> list[dict[str, str]]:
    result: list[dict[str, str]] = []
    for raw in values:
        parts = raw.split("|", 2)
        if len(parts) != 3: raise WorldBuilderError("--approve must be URL|CODE|REASON")
        url = canonicalize_url(parts[0]); code = parts[1].strip(); reason = parts[2].strip()
        if not url or len(reason) < 5: raise WorldBuilderError("manual approval requires valid URL and reason")
        exclusion_policy(code); result.append({"url": url, "code": code, "reason": reason})
    return result

def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--build-state", required=True); parser.add_argument("--operator", required=True)
    parser.add_argument("--approve-low-value", action="store_true"); parser.add_argument("--approve", action="append", default=[], metavar="URL|CODE|REASON")
    parser.add_argument("--note", default=""); parser.add_argument("--approve-saturation-stop", action="store_true")
    args = parser.parse_args()
    try:
        root, state = load_build_state(args.build_state)
        plan_path = resolve_state_path(root, state, "discovery_plan"); recovery_path = resolve_state_path(root, state, "discovery_recovery_plan")
        output = resolve_state_path(root, state, "discovery_exclusion_approval", required=False) or (root / "artifacts" / "discoveries" / "exclusion-approval.json")
        plan = load_json(plan_path); recovery = load_json(recovery_path)
        if not isinstance(plan, dict) or not isinstance(recovery, dict): raise WorldBuilderError("plan/recovery must be objects")
        if recovery.get("plan_sha256") != sha256_file(plan_path): raise WorldBuilderError("recovery plan is stale")
        rows = recovery.get("candidate_urls")
        if not isinstance(rows, list): raise WorldBuilderError("recovery plan has no candidate_urls")
        candidates = {canonicalize_url(row.get("url")): row for row in rows if isinstance(row, dict) and canonicalize_url(row.get("url"))}
        approved: dict[str, dict[str, str]] = {}
        if args.approve_low_value:
            for url in sorted(candidates):
                code = infer_code(url)
                if code and EXCLUSION_CODES[code]["low_value"]:
                    approved[url] = {"url": url, "code": code, "reason": f"governed low-value exclusion: {code.replace('_', ' ')}"}
        for row in parse_manual(args.approve):
            if row["url"] not in candidates: raise WorldBuilderError(f"URL is not in current recovery plan: {row['url']}")
            approved[row["url"]] = row
        if not approved and not args.approve_saturation_stop: raise WorldBuilderError("no URL or saturation decision was approved")
        high = [row for row in approved.values() if not EXCLUSION_CODES[row["code"]]["low_value"]]
        value = {
            "kind": "worldbuilder-discovery-exclusion-approval", "approval_version": DISCOVERY_APPROVAL_VERSION,
            "build_id": state.get("build_id"), "created_at": now(), "operator": args.operator, "user_approved": True,
            "note": args.note, "plan_sha256": sha256_file(plan_path), "corpus_sha256": plan.get("corpus_sha256"),
            "recovery_plan_sha256": sha256_file(recovery_path), "approved_urls": [approved[url] for url in sorted(approved)],
            "high_value_approval_count": len(high), "approve_saturation_stop": bool(args.approve_saturation_stop),
        }
        atomic_write_json(output, value)
        print(json.dumps({"status": "approved", "output": str(output), "url_count": len(approved), "high_value": len(high)}, indent=2)); return 0
    except (WorldBuilderError, OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr); return 1
if __name__ == "__main__": raise SystemExit(main())
