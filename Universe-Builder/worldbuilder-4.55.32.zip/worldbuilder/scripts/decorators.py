#!/usr/bin/env python3
"""Batch 9: CCv3 decorators; shared parsing, the single primitive every
consumer imports rather than reimplementing.

Per the spec (kwaroran/character-card-spec-v3, SPEC_V3.md, Decorators):
"Decorators are a string that starts with @@ and ends with a newline...
If the content field contains decorators, the application SHOULD follow
the rules defined in the decorators, and trim the decorators from the
content field before adding it to the prompt. the newlines before and
after the decorators SHOULD be trimmed as well."

The spec's own worked example shows decorators as a contiguous block at
the START of content, followed by a blank line, then prose. This module
follows that shape: it scans leading lines only, stopping at the first
non-decorator, non-blank line, and treats everything before that as the
decorator block.

Fallback decorators use three @ ("@@@") immediately after the decorator
they fall back from: a continuation of the same conceptual decorator
for an application that does not recognize the primary name, not a
second, independent decorator. Two decorators, `@@risu_only_decorator 4`
`@@@activate_after 4`, means: use risu_only_decorator if recognized,
otherwise fall back to activate_after.

DR (see design-rationale.md): "Decorators are the portable emission
form; native keys are the profile form." This module only parses and
serializes. It holds no opinion about ownership between the IR's
canonical value and either emission form; that decision belongs to each
consumer (placement_contract.py, dynamic_state_contract.py,
runtime_target_adapter.py), one owner per semantic, never both.
"""
from __future__ import annotations

import re
from typing import Any, NamedTuple

DECORATOR_PREFIX = "@@"
FALLBACK_PREFIX = "@@@"

# Recognized names this codebase actively interprets for ownership
# purposes (Batch 9's three named overlaps). Every other @@-prefixed name
# is still recognized as A decorator (parsed, trimmed, preserved through
# round-trip), just not one this codebase assigns semantic meaning to
# beyond "an entry declared this."
KNOWN_DECORATOR_NAMES = frozenset({
    "activate_only_after", "activate_only_every", "keep_activate_after_match", "dont_activate_after_match",
    "depth", "instruct_depth", "reverse_depth", "reverse_instruct_depth", "role",
    "scan_depth", "instruct_scan_depth", "is_greeting", "position", "ignore_on_max_context",
    "additional_keys", "exclude_keys", "is_user_icon", "dont_activate", "activate", "disable_ui_prompt",
})

# Batch 58 / A10: names whose value must be an integer. An unusable value here is
# an explicit, reportable outcome rather than a ValueError from a consumer's
# int() call several frames away.
INTEGER_DECORATOR_NAMES = frozenset({
    "activate_only_after", "activate_only_every", "depth", "instruct_depth", "reverse_depth",
    "reverse_instruct_depth", "scan_depth", "instruct_scan_depth",
})

_DECORATOR_LINE_RE = re.compile(r"^(@{2,3})([A-Za-z_][A-Za-z0-9_]*)(?:\s+(.*))?$")


class Decorator(NamedTuple):
    name: str
    value: str | None  # raw value text, comma-split by the caller if multi-valued; None for a bare decorator
    is_fallback: bool  # True for an @@@ line: a fallback for the immediately preceding decorator


def parse_leading_decorators(content: str) -> tuple[list[Decorator], str]:
    """Returns (decorators, remaining_content). remaining_content has the
    leading decorator block AND the blank line(s) separating it from
    prose removed, matching the spec's "newlines before and after the
    decorators SHOULD be trimmed as well" exactly. A line that starts
    with @@ but does not match NAME [VALUE] shape is not a decorator (the
    spec requires latin letters/underscores, snake_case); parsing stops
    there and that line is treated as the start of prose, not silently
    dropped or misparsed.
    """
    if not content:
        return [], content
    lines = content.split("\n")
    decorators: list[Decorator] = []
    consumed = 0
    for line in lines:
        stripped = line.strip()
        if not stripped:
            if decorators:
                consumed += 1
                continue
            break  # a leading blank line before any decorator is just leading whitespace in prose, not ours to eat
        match = _DECORATOR_LINE_RE.match(stripped)
        if not match:
            break
        at_symbols, name, value = match.groups()
        decorators.append(Decorator(name=name, value=value, is_fallback=(at_symbols == FALLBACK_PREFIX)))
        consumed += 1
    remaining = "\n".join(lines[consumed:])
    return decorators, remaining.lstrip("\n")


def decorator_chains(decorators: list[Decorator]) -> list[list[Decorator]]:
    """Group the flat decorator stream into directive+fallback chains, in source
    order. A fallback (@@@) continues the chain of the directive before it; a
    fallback with no preceding directive forms its own chain."""
    chains: list[list[Decorator]] = []
    for decorator in decorators:
        if decorator.is_fallback and chains:
            chains[-1].append(decorator)
        else:
            chains.append([decorator])
    return chains


def _unusable_reason(member: Decorator) -> str | None:
    """None when this declaration is usable on its own, else the reason it is not.
    An unrecognized name is unusable, which is what makes a fallback stand in."""
    if member.name not in KNOWN_DECORATOR_NAMES:
        return "unrecognized name"
    if member.name in INTEGER_DECORATOR_NAMES:
        value = (member.value or "").strip()
        if not value.lstrip("-").isdigit():
            return f"expects an integer, found {member.value!r}"
    return None


def resolved_decorator_values(decorators: list[Decorator]) -> dict[str, str | None]:
    """Resolve directive+fallback chains to at most one value per name.

    Batch 58 / A10. The previous implementation searched every non-fallback
    line first and every fallback line second, ignoring each fallback's own
    predecessor, so `@@depth 4` followed by `@@@role assistant` yielded
    ``role assistant`` even though that fallback belongs to ``depth``.

    Chains are resolved in source order. Within a chain the first declaration
    that is usable on its own wins; a fallback is consulted only when the
    declaration before it is unusable (unrecognized name or invalid value). The
    first effective declaration of a *name* wins across the whole stream,
    matching the spec's "only consider the first decorator with the name".

    This never raises. When no member of a chain is usable on its own, the
    final member (or the primary when there is no fallback) is still the
    declaration that was written, so its value stays readable and a consumer
    reports it as malformed. Raising here would pre-empt
    validate_output.validate_decorators, which is the component that turns a
    bad value into a reported ``malformed-decorator-value`` error.
    """
    resolved: dict[str, str | None] = {}
    for chain in decorator_chains(decorators):
        if chain[0].is_fallback:
            # Nothing precedes it, so there is nothing for it to stand in for.
            continue
        chosen: Decorator | None = None
        for member in chain:
            if _unusable_reason(member) is None:
                chosen = member
                break
        if chosen is None:
            chosen = chain[-1]
        if chosen.name not in resolved:
            resolved[chosen.name] = chosen.value if chosen.value is not None else ""
    return resolved


def first_effective_value(decorators: list[Decorator], name: str) -> str | None:
    """The resolved value for one decorator name, or None when it is absent.

    Returns the associated value (an empty string for a bare, valueless
    decorator that is nonetheless present). See resolved_decorator_values for the
    chain rules."""
    return resolved_decorator_values(decorators).get(name)


def has_decorator(decorators: list[Decorator], name: str) -> bool:
    return any(d.name == name for d in decorators)


def render_decorator_block(entries: list[tuple[str, Any]]) -> str:
    """The inverse of parse_leading_decorators: given [(name, value_or_None), ...],
    returns the decorator block text (each on its own line, no trailing
    blank line; the caller joins this with prose using a single blank
    line separator, matching the spec's own worked example)."""
    lines = []
    for name, value in entries:
        if value is None:
            lines.append(f"{DECORATOR_PREFIX}{name}")
        else:
            lines.append(f"{DECORATOR_PREFIX}{name} {value}")
    return "\n".join(lines)


def prepend_decorators(content: str, entries: list[tuple[str, Any]]) -> str:
    """Builds content with a fresh decorator block prepended, blank-line
    separated from whatever content already there; the exact inverse
    operation of parse_leading_decorators, so round-tripping through
    parse then prepend (with the same entries) is stable."""
    if not entries:
        return content
    block = render_decorator_block(entries)
    if not content:
        return block
    return f"{block}\n\n{content}"
