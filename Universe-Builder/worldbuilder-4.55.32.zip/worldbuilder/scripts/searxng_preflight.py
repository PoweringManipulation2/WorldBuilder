#!/usr/bin/env python3
"""Validate WorldBuilder's mandatory SearXNG research stack."""

from __future__ import annotations

import argparse
import json
import platform
import re
import shutil
import subprocess
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any

# Read once, dynamically, never hardcoded (see DR-065).
VERSION = (Path(__file__).resolve().parent.parent / "VERSION").read_text(encoding="utf-8").strip()

MIN_OPENCLAW_VERSION = (2026, 6, 9)


def fetch_text(url: str, timeout: float) -> tuple[int, str]:
    request = urllib.request.Request(url, headers={"User-Agent": "WorldBuilder-Research-Preflight/3.6"})
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return int(response.status), response.read().decode("utf-8", errors="replace")


def validate_base_url(value: str) -> str:
    parsed = urllib.parse.urlparse(value)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        raise ValueError("base URL must be an absolute http:// or https:// URL")
    return value.rstrip("/")


def parse_warp_state(text: str) -> str:
    lowered = text.casefold()
    for pattern in (
        r"(?:^|\n)\s*(?:status|state)(?:\s+update)?\s*:\s*([a-z_-]+)",
        r"(?:^|\n)\s*([a-z_-]+)\s*$",
    ):
        for match in re.finditer(pattern, lowered):
            token = match.group(1).replace("_", "-")
            if token in {"connected", "disconnected", "connecting", "paused", "degraded", "error"}:
                return token
    for token in ("disconnected", "connecting", "paused", "degraded", "error", "connected"):
        if re.search(rf"(?<![a-z]){token}(?![a-z])", lowered):
            return token
    return "unknown"


CONNECTED_LINE = re.compile(r"^\s*(?:status(?:\s+update)?\s*:\s*)?connected(?:\s+.*)?$", re.I)
DISCONNECTED_LINE = re.compile(r"^\s*(?:status(?:\s+update)?\s*:\s*)?disconnected(?:\s+.*)?$", re.I)


def parse_warp_connected(text: str) -> bool:
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    if any(DISCONNECTED_LINE.fullmatch(line) for line in lines):
        return False
    return any(CONNECTED_LINE.fullmatch(line) for line in lines)


def warp_cli_status(timeout: float) -> dict[str, Any]:
    executable = shutil.which("warp-cli")
    if not executable:
        return {"available": False, "state": "unavailable", "connected": False, "detail": "warp-cli not found"}
    try:
        completed = subprocess.run(
            [executable, "status"], check=False, capture_output=True, text=True, timeout=timeout,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        return {"available": True, "state": "error", "connected": False, "detail": str(exc)}
    detail = (completed.stdout + "\n" + completed.stderr).strip()
    state = parse_warp_state(detail)
    connected = completed.returncode == 0 and state == "connected"
    return {"available": True, "state": state, "connected": connected, "returncode": completed.returncode, "detail": detail[:2000]}


def cloudflare_trace(timeout: float) -> dict[str, Any]:
    try:
        status, body = fetch_text("https://www.cloudflare.com/cdn-cgi/trace", timeout)
    except (OSError, urllib.error.URLError, TimeoutError) as exc:
        return {"reachable": False, "warp_on": False, "detail": str(exc)}
    values: dict[str, str] = {}
    for line in body.splitlines():
        if "=" in line:
            key, value = line.split("=", 1)
            values[key.strip()] = value.strip()
    return {"reachable": status == 200, "warp_on": values.get("warp") == "on", "trace": values}


def searxng_engine_errors(payload: dict[str, Any]) -> list[dict[str, str]]:
    """Normalize SearXNG's JSON ``unresponsive_engines`` diagnostics."""
    raw = payload.get("unresponsive_engines")
    if not isinstance(raw, list):
        return []
    errors: list[dict[str, str]] = []
    for item in raw:
        engine: Any = None
        reason: Any = None
        if isinstance(item, (list, tuple)) and len(item) >= 2:
            engine, reason = item[0], item[1]
        elif isinstance(item, dict):
            engine = item.get("engine") or item.get("name")
            reason = item.get("error") or item.get("reason") or item.get("message")
        if engine is None or reason is None:
            continue
        errors.append({"engine": str(engine)[:120], "reason": str(reason)[:300]})
    return errors


def searxng_probe(base_url: str, query: str, timeout: float) -> dict[str, Any]:
    params = urllib.parse.urlencode({"q": query, "format": "json", "categories": "general"})
    url = f"{base_url}/search?{params}"
    started = time.monotonic()
    try:
        status, body = fetch_text(url, timeout)
        payload = json.loads(body)
    except (OSError, urllib.error.URLError, TimeoutError, json.JSONDecodeError) as exc:
        return {"ok": False, "url": url, "detail": str(exc)}
    results = payload.get("results")
    valid_results = isinstance(results, list)
    engine_errors = searxng_engine_errors(payload)
    failure_reasons = sorted({row["reason"] for row in engine_errors})
    return {
        "ok": status == 200 and valid_results and len(results) > 0,
        "url": url,
        "http_status": status,
        "elapsed_ms": round((time.monotonic() - started) * 1000),
        "results_array": valid_results,
        "result_count": len(results) if valid_results else None,
        "engine_errors": engine_errors,
        "failure_reasons": failure_reasons,
    }


def parse_openclaw_version(text: str) -> tuple[int, int, int] | None:
    match = re.search(r"(?<!\d)(20\d{2})[.\-](\d{1,2})[.\-](\d{1,2})(?!\d)", text)
    if not match:
        return None
    return tuple(int(part) for part in match.groups())


def openclaw_host_status(timeout: float, override: str | None = None) -> dict[str, Any]:
    detail = override or ""
    executable = shutil.which("openclaw")
    if not detail and executable:
        try:
            completed = subprocess.run(
                [executable, "--version"], check=False, capture_output=True, text=True, timeout=timeout,
            )
            detail = (completed.stdout + "\n" + completed.stderr).strip()
        except (OSError, subprocess.TimeoutExpired) as exc:
            return {"available": True, "compatible": False, "detail": str(exc)}
    version = parse_openclaw_version(detail)
    return {
        "available": bool(executable or override),
        "version": ".".join(str(part) for part in version) if version else None,
        "minimum": ".".join(str(part) for part in MIN_OPENCLAW_VERSION),
        "compatible": bool(version and version >= MIN_OPENCLAW_VERSION),
        "detail": detail[:1000] if detail else "openclaw executable/version unavailable",
    }



def warp_proxy_trace(proxy: str, timeout: int) -> dict[str, Any]:
    """Fetch the Cloudflare trace *through* a proxy to prove that proxy's egress.

    A host can run SearXNG behind a WARP SOCKS5 listener while the host itself stays
    outside the tunnel. Checking only the host's own trace reports warp=off and blocks
    `--egress warp`, even though every search request genuinely leaves through WARP.

    Fetching through the proxy proves the property that actually matters, and is
    stronger evidence than a colocation assertion: it observes the egress rather than
    asserting a topology.
    """
    if not proxy.startswith(("socks5://", "socks5h://", "http://", "https://")):
        return {"verified": False, "detail": f"unsupported proxy scheme in {proxy!r}"}
    try:
        import urllib.request
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({
            "http": proxy, "https": proxy,
        }))
        with opener.open("https://www.cloudflare.com/cdn-cgi/trace", timeout=timeout) as response:
            body = response.read().decode("utf-8", errors="replace")
            status = response.status
    except Exception as exc:  # noqa: BLE001 - any failure is simply unverified evidence
        return {"verified": False, "proxy": proxy, "detail": str(exc)[:300]}

    values = dict(
        line.split("=", 1) for line in body.splitlines() if "=" in line
    )
    warp_on = values.get("warp") == "on"
    return {
        "verified": status == 200 and warp_on,
        "proxy": proxy,
        "warp": values.get("warp"),
        "detail": ("proxy egress is inside the WARP tunnel" if warp_on else
                   "proxy reachable but its egress is not WARP"),
    }


def validate_egress_receipt(path: Path | None, base_url: str, mode: str) -> dict[str, Any]:
    if path is None:
        return {"provided": False, "verified": False}
    try:
        payload = json.loads(path.expanduser().read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        return {"provided": True, "verified": False, "detail": str(exc)}
    verified = (
        isinstance(payload, dict)
        and payload.get("verified") is True
        and payload.get("base_url") == base_url
        and payload.get("egress_mode") == mode
        and isinstance(payload.get("evidence"), str)
        and bool(payload["evidence"].strip())
    )
    return {"provided": True, "verified": verified, "receipt": payload}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-url", required=True, help="SearXNG instance base URL")
    parser.add_argument("--query", default="WorldBuilder research health check", help="Probe query")
    parser.add_argument("--timeout", type=float, default=15.0, help="Per-request timeout in seconds")
    parser.add_argument("--egress", choices=("warp", "replacement"), default="warp")
    parser.add_argument("--egress-note", help="Required description for administrator-approved replacement egress")
    parser.add_argument(
        "--warp-proxy",
        help="SOCKS5/HTTP proxy SearXNG egresses through, e.g. socks5h://127.0.0.1:40000. "
             "The trace is fetched through it, proving that proxy's egress even when the host "
             "itself is outside the WARP tunnel.",
    )
    parser.add_argument("--openclaw-version", help="Override OpenClaw version text when the CLI is unavailable")
    parser.add_argument(
        "--searxng-colocated", action="store_true",
        help="Assert that SearXNG shares the OpenClaw host network namespace and therefore the checked egress",
    )
    parser.add_argument(
        "--searxng-egress-receipt", type=Path,
        help="JSON evidence from the SearXNG host proving its upstream search egress",
    )
    parser.add_argument("--output", type=Path, help="Write JSON report to this path")
    parser.add_argument("--build-state", help="If passed and the preflight succeeds, record a receipt into this build's state so discovery can point to a verified, already-running SearXNG without the full ensure_research_stack.py install ceremony")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    try:
        base_url = validate_base_url(args.base_url)
    except ValueError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    if args.egress == "replacement" and not (args.egress_note or "").strip():
        print("ERROR: --egress-note is required for replacement egress", file=sys.stderr)
        return 2

    report: dict[str, Any] = {
        "schema": "worldbuilder.research-preflight.v1",
        "worldbuilder_version": VERSION,
        "platform": platform.platform(),
        "base_url": base_url,
        "egress": {"mode": args.egress, "note": args.egress_note},
    }
    report["openclaw_host"] = openclaw_host_status(args.timeout, args.openclaw_version)
    if args.egress == "warp":
        report["warp_cli"] = warp_cli_status(args.timeout)
        report["cloudflare_trace"] = cloudflare_trace(args.timeout)
        host_egress_ok = bool(report["cloudflare_trace"].get("warp_on"))
        if args.warp_proxy:
            report["warp_proxy_trace"] = warp_proxy_trace(args.warp_proxy, args.timeout)
            # Either route is acceptable evidence: the host being inside the tunnel, or
            # the proxy SearXNG actually uses being inside it.
            host_egress_ok = host_egress_ok or bool(report["warp_proxy_trace"].get("verified"))
    else:
        host_egress_ok = True

    report["searxng_egress_binding"] = validate_egress_receipt(
        args.searxng_egress_receipt, base_url, args.egress,
    )
    binding_ok = bool(args.searxng_colocated or report["searxng_egress_binding"].get("verified"))
    report["searxng_egress_binding"]["colocated_assertion"] = bool(args.searxng_colocated)
    report["searxng_egress_binding"]["warning"] = (
        "Host egress and SearXNG endpoint health are independent unless colocation or a SearXNG-host receipt is provided."
    )

    report["searxng"] = searxng_probe(base_url, args.query, args.timeout)
    report["passed"] = bool(
        report["openclaw_host"].get("compatible")
        and host_egress_ok
        and binding_ok
        and report["searxng"].get("ok")
    )

    rendered = json.dumps(report, indent=2, sort_keys=True) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(rendered, encoding="utf-8")
    print(rendered, end="")
    if args.build_state and report["passed"]:
        from datetime import datetime, timezone
        from wb_common import atomic_write_json, load_build_state, resolve_state_path
        root, state = load_build_state(args.build_state)
        receipt_path = resolve_state_path(root, state, "searxng_preflight_receipt", required=False) \
            or (root / ".work" / "searxng-preflight-receipt.json")
        atomic_write_json(receipt_path, {
            "kind": "worldbuilder-searxng-preflight-receipt",
            "receipt_version": 1,
            "build_id": state.get("build_id"),
            "base_url": base_url,
            "passed": True,
            "checked_at": datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z"),
        })
        print(f"[worldbuilder] recorded verified SearXNG receipt at {receipt_path}", file=sys.stderr)
        print(
            "[worldbuilder] this is a lighter alternative to the full ensure_research_stack.py install ceremony "
            "for an already-running, independently-managed SearXNG instance; see references/searxng-setup.md",
            file=sys.stderr,
        )
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
