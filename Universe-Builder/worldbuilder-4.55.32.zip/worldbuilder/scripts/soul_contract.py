#!/usr/bin/env python3
"""Bind a soul profile into a build and check emitted prose against it.

`soul-extractor.md` already specifies that a finished profile is stored under the
build workspace, hashed into build lineage, and referenced from assignments, and
that a world soul acts as a global editorial constraint across entries. None of
that was implemented: no script read a profile, no manifest key bound one, and no
gate compared output to one. This closes that gap.

Two halves:

1. **Binding.** The profile becomes a frozen, hash-bound artifact like the era plan
   and the character plan, so generation assignments carry the approved voice
   instead of workers inferring it.
2. **Enforcement.** Output is checked against the profile. The checks here are
   deliberately limited to properties a script can measure exactly across the whole
   corpus at once: cross-entry repetition, opener monotony, declared
   anti-patterns, sentence-length collapse. These are the failures a model-driven
   editor is structurally worst at catching, because it never sees all entries
   together.

No check here scores "good writing." Editorial preference produces warnings;
only what the creator explicitly declared forbidden or required produces errors.

Commands:
    profile   validate a soul profile in isolation
    planning  validate the profile against the manifest and assignments
    output    check emitted entries against the profile
"""
from __future__ import annotations

import argparse
import json
import re
import statistics
import sys
from collections import Counter
from pathlib import Path
from typing import Any

from wb_common import (
    WorldBuilderError,
    atomic_write_json,
    load_build_state,
    load_json,
    preflight_report,
    raise_error,
    requirement_rows,
    resolve_state_path,
    sha256_file,
)

KIND = "worldbuilder-soul-profile"
PROFILE_VERSION = 1
CONTRACT = "worldbuilder-soul-voice-v1"
RECEIPT_KIND = "worldbuilder-soul-gate"
RECEIPT_VERSION = 1

TARGET_TYPES = {"world", "character", "authorial", "mixed"}
# Where the runtime guide may live. `description` is accepted because it is a real
# prompt field, but it sits furthest from the generation point, so the contract
# records the choice rather than assuming it.
RUNTIME_PLACEMENTS = {"description", "post_history_instructions", "depth_entry", "system_prompt", "world_core_entry"}

# Heuristic defaults. Tunable per profile; see DR-058.
DEFAULT_THRESHOLDS = {
    "repetition_ngram": 6,
    "max_shared_ngram_ratio": 0.12,
    "min_opener_diversity": 0.55,
    "min_sentence_length_stdev": 4.0,
    "min_entries_for_corpus_checks": 8,
}

_SENTENCE_SPLIT = re.compile(r"[.!?]+(?:\s|$)")
_WORD = re.compile(r"[A-Za-z']+")


def _obj(value: Any, label: str) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise_error(f"{label} must be an object")
    return value


def _strlist(value: Any, label: str, *, allow_empty: bool = True) -> list[str]:
    if not isinstance(value, list) or any(not isinstance(v, str) for v in value):
        raise_error(f"{label} must be a list of strings")
    if not value and not allow_empty:
        raise_error(f"{label} must not be empty")
    return [v.strip() for v in value if v.strip()]


# ------------------------------------------------------------------------ profile


def validate_profile(profile: dict[str, Any], *, build_id: str | None = None) -> dict[str, Any]:
    _obj(profile, "soul profile")
    if profile.get("kind") != KIND:
        raise_error(f"soul profile kind must be {KIND!r}")
    if profile.get("profile_version") != PROFILE_VERSION:
        raise_error(f"soul profile profile_version must be {PROFILE_VERSION}")
    if profile.get("contract") != CONTRACT:
        raise_error(f"soul profile contract must be {CONTRACT!r}")
    if build_id is not None and profile.get("build_id") != build_id:
        raise_error(f"soul profile build_id {profile.get('build_id')!r} does not match build {build_id!r}")
    if profile.get("user_approved") is not True:
        raise_error("soul profile requires explicit user approval before it can constrain generation")

    target = profile.get("target_type")
    if target not in TARGET_TYPES:
        raise_error(f"target_type must be one of {sorted(TARGET_TYPES)}, got {target!r}")

    # Operational instructions, not description. A profile that cannot be acted on
    # cannot constrain a worker.
    voice_rules = _strlist(profile.get("voice_rules"), "voice_rules", allow_empty=False)
    anti_patterns = _strlist(profile.get("anti_patterns", []), "anti_patterns")
    required_markers = _strlist(profile.get("required_markers", []), "required_markers")

    overlap = sorted({a.casefold() for a in anti_patterns} & {r.casefold() for r in required_markers})
    if overlap:
        raise_error(f"terms declared both required and forbidden: {overlap}")

    runtime = _obj(profile.get("runtime_guide"), "runtime_guide")
    text = runtime.get("text")
    if not isinstance(text, str) or not text.strip():
        raise_error("runtime_guide.text must be the prose guide that ships with the artifact")
    placement = runtime.get("placement")
    if placement not in RUNTIME_PLACEMENTS:
        raise_error(f"runtime_guide.placement must be one of {sorted(RUNTIME_PLACEMENTS)}, got {placement!r}")
    if runtime.get("placement_rationale") in (None, ""):
        raise_error(
            "runtime_guide.placement_rationale is required. A prose guide steers generation, and "
            "the fields differ in distance from the generation point; record why this one was chosen"
        )

    thresholds = dict(DEFAULT_THRESHOLDS)
    declared = profile.get("thresholds")
    if declared is not None:
        declared = _obj(declared, "thresholds")
        for key, value in declared.items():
            if key not in DEFAULT_THRESHOLDS:
                raise_error(f"unknown threshold {key!r}")
            if not isinstance(value, (int, float)) or isinstance(value, bool) or value < 0:
                raise_error(f"threshold {key!r} must be a non-negative number")
            thresholds[key] = value

    return {
        "target_type": target,
        "voice_rule_count": len(voice_rules),
        "anti_pattern_count": len(anti_patterns),
        "required_marker_count": len(required_markers),
        "runtime_placement": placement,
        "thresholds": thresholds,
    }


# ----------------------------------------------------------------------- manifest


def _entries(manifest: dict[str, Any]) -> list[dict[str, Any]]:
    rows = manifest.get("entries")
    if not isinstance(rows, list):
        raise_error("manifest entries must be a list")
    return [r for r in rows if isinstance(r, dict)]


def validate_manifest(profile: dict[str, Any], manifest: dict[str, Any]) -> dict[str, Any]:
    """The profile must be bound and actually reachable by the workers it governs."""
    detail = validate_profile(profile)
    if not manifest.get("soul_profile_sha256"):
        raise_error(
            "manifest does not bind soul_profile_sha256. An unbound profile cannot constrain "
            "generation, which is the state this contract exists to prevent"
        )
    arch = manifest.get("architecture")
    arch = arch if isinstance(arch, dict) else {}
    if arch.get("soul_voice") != CONTRACT:
        raise_error(f"manifest architecture.soul_voice must bind {CONTRACT!r}")

    rows = _entries(manifest)
    prose_bearing = [r for r in rows if r.get("type") not in {"control", "system"}]
    missing = [
        str(r.get("uid", r.get("id")))
        for r in prose_bearing
        if not (isinstance(r.get("generation"), dict) and r["generation"].get("soul_voice_bound") is True)
    ]
    if missing:
        raise_error(
            "these prose-bearing entries do not carry the soul voice binding, so their workers "
            f"would write to an inferred voice: {missing[:12]}"
        )
    return {**detail, "bound_entries": len(prose_bearing)}


# ------------------------------------------------------------------------- output


def _output_entries(data: Any) -> list[dict[str, Any]]:
    container = data
    if isinstance(data, dict) and isinstance(data.get("data"), dict):
        container = data["data"]
    if isinstance(container, dict) and isinstance(container.get("character_book"), dict):
        container = container["character_book"]
    rows = container.get("entries") if isinstance(container, dict) else None
    if isinstance(rows, dict):
        rows = list(rows.values())
    if not isinstance(rows, list):
        raise_error("could not locate lorebook entries in the artifact")
    return [r for r in rows if isinstance(r, dict)]


def _text(entry: dict[str, Any]) -> str:
    value = entry.get("content")
    return value if isinstance(value, str) else ""


def _words(text: str) -> list[str]:
    return [w.casefold() for w in _WORD.findall(text)]


def _ngrams(words: list[str], n: int) -> set[tuple[str, ...]]:
    return {tuple(words[i:i + n]) for i in range(max(0, len(words) - n + 1))}


def _sentences(text: str) -> list[str]:
    return [s.strip() for s in _SENTENCE_SPLIT.split(text) if s.strip()]


def check_prose(profile: dict[str, Any], entries: list[dict[str, Any]]) -> dict[str, Any]:
    """Corpus-wide checks. These are the ones an LLM editor cannot perform.

    A model reviewing entries in batches cannot see that forty of them open the same
    way or recycle the same phrasing, because it never holds the corpus at once.
    A script does it exactly.
    """
    detail = validate_profile(profile)
    thresholds = detail["thresholds"]
    anti = [a for a in profile.get("anti_patterns", []) if a.strip()]
    required = [r for r in profile.get("required_markers", []) if r.strip()]

    errors: list[str] = []
    warnings: list[str] = []

    # Creator-declared constraints are errors: they were explicitly approved.
    for entry in entries:
        uid = entry.get("uid", entry.get("id"))
        folded = _text(entry).casefold()
        for pattern in anti:
            if pattern.casefold() in folded:
                errors.append(f"entry {uid}: declared anti-pattern present: {pattern!r}")
    if required:
        corpus = " ".join(_text(e) for e in entries).casefold()
        for marker in required:
            if marker.casefold() not in corpus:
                errors.append(f"required voice marker never appears in the corpus: {marker!r}")

    metrics: dict[str, Any] = {"entry_count": len(entries)}
    if len(entries) < thresholds["min_entries_for_corpus_checks"]:
        metrics["corpus_checks"] = "skipped: too few entries to be meaningful"
        return {"errors": errors, "warnings": warnings, "metrics": metrics, **detail}

    # 1. Cross-entry repetition.
    n = int(thresholds["repetition_ngram"])
    per_entry = [(e.get("uid", e.get("id")), _ngrams(_words(_text(e)), n)) for e in entries]
    counts: Counter[tuple[str, ...]] = Counter()
    for _, grams in per_entry:
        counts.update(grams)
    shared = {g for g, c in counts.items() if c > 1}
    ratios = []
    for uid, grams in per_entry:
        if not grams:
            continue
        ratio = len(grams & shared) / len(grams)
        ratios.append((ratio, uid))
    ratios.sort(reverse=True)
    worst = ratios[:5]
    mean_ratio = statistics.fmean(r for r, _ in ratios) if ratios else 0.0
    metrics["shared_ngram_ratio_mean"] = round(mean_ratio, 4)
    metrics["most_repetitive_entries"] = [{"uid": u, "ratio": round(r, 4)} for r, u in worst]
    if mean_ratio > thresholds["max_shared_ngram_ratio"]:
        warnings.append(
            f"cross-entry repetition is high: {mean_ratio:.1%} of {n}-grams are reused across entries "
            f"(threshold {thresholds['max_shared_ngram_ratio']:.1%}). Worst: "
            + ", ".join(f"{u} at {r:.1%}" for r, u in worst[:3])
        )

    # 2. Opener monotony.
    openers = [tuple(_words(_text(e))[:3]) for e in entries if _words(_text(e))]
    if openers:
        diversity = len(set(openers)) / len(openers)
        metrics["opener_diversity"] = round(diversity, 4)
        if diversity < thresholds["min_opener_diversity"]:
            common = Counter(openers).most_common(3)
            metrics["repeated_openers"] = [{"opener": " ".join(o), "count": c} for o, c in common]
            worst_openers = {o for o, _ in common}
            metrics["monotonous_opener_entries"] = [
                str(e.get("uid", e.get("id")))
                for e in entries
                if tuple(_words(_text(e))[:3]) in worst_openers
            ][:8]
            warnings.append(
                f"entry openings are monotonous: {diversity:.0%} distinct (threshold "
                f"{thresholds['min_opener_diversity']:.0%}). Most repeated: "
                + ", ".join(f"{' '.join(o)!r} x{c}" for o, c in common)
            )

    # 3. Sentence-length collapse.
    lengths = [len(_words(s)) for e in entries for s in _sentences(_text(e))]
    if len(lengths) > 20:
        stdev = statistics.pstdev(lengths)
        metrics["sentence_length_stdev"] = round(stdev, 2)
        metrics["sentence_length_mean"] = round(statistics.fmean(lengths), 2)
        if stdev < thresholds["min_sentence_length_stdev"]:
            warnings.append(
                f"sentence rhythm is flat: length stdev {stdev:.1f} below {thresholds['min_sentence_length_stdev']}. "
                "Uniform sentence length reads as machine-generated regardless of word choice"
            )

    return {"errors": errors, "warnings": warnings, "metrics": metrics, **detail}


# Severity mapping. Creator-declared constraints are high because the creator
# explicitly approved them; corpus metrics are low because they are editorial and
# a world may legitimately repeat phrasing for effect (DR-058).
FINDING_SEVERITY = {"declared": "high", "corpus": "low"}


def prose_findings(result: dict[str, Any], *, entry_pointer: str = "/data/entries") -> list[dict[str, Any]]:
    """Convert prose results into audit findings.

    Warnings printed at the delivery gate are read once and acted on never. Findings
    enter reconciliation, get grouped by UID and pointer, become patch operations, and
    are byte-verified and re-audited. Same information, a machine that acts on it.
    """
    findings: list[dict[str, Any]] = []

    for index, message in enumerate(result.get("errors", []), start=1):
        uid = _uid_from_message(message)
        findings.append({
            "finding_id": f"soul-declared-{index:03d}",
            "severity": FINDING_SEVERITY["declared"],
            "category": "soul_voice_declared",
            "summary": message,
            "recommended_action": (
                "Rewrite the offending phrasing to satisfy the approved soul profile. "
                "The constraint was declared by the creator, so the profile is authority, not the prose."
            ),
            "target": f"{entry_pointer}/{uid}" if uid is not None else None,
        })

    metrics = result.get("metrics", {})
    for index, message in enumerate(result.get("warnings", []), start=1):
        worst = _worst_targets(message, metrics)
        findings.append({
            "finding_id": f"soul-corpus-{index:03d}",
            "severity": FINDING_SEVERITY["corpus"],
            "category": "soul_voice_corpus",
            "summary": message,
            "recommended_action": (
                "Vary the flagged entries rather than rewriting the corpus. Corpus metrics are "
                "editorial: confirm the repetition is unintentional before patching, since a world "
                "may repeat phrasing deliberately."
            ),
            # A corpus property has no single owner, so the finding targets the worst
            # offender and names the rest, rather than inventing a whole-book pointer.
            "target": f"{entry_pointer}/{worst[0]}" if worst else None,
            "also_affects": [f"{entry_pointer}/{uid}" for uid in worst[1:]],
        })
    return findings


def _uid_from_message(message: str) -> str | None:
    match = re.search(r"entry ([^\s:]+)", message)
    return match.group(1) if match else None


def _worst_targets(message: str, metrics: dict[str, Any]) -> list[str]:
    if "repetition" in message:
        return [str(row["uid"]) for row in metrics.get("most_repetitive_entries", [])][:5]
    if "openings" in message:
        return metrics.get("monotonous_opener_entries", [])
    # Sentence rhythm is a property of the whole corpus with no single owner. A
    # fabricated target would send the patch loop at an arbitrary entry.
    return []


def validate_output(profile: dict[str, Any], data: Any, *, require_clean: bool = False) -> dict[str, Any]:
    entries = _output_entries(data)
    result = check_prose(profile, entries)
    if result["errors"]:
        raise_error("soul voice violations:\n  - " + "\n  - ".join(result["errors"]))
    if require_clean and result["warnings"]:
        raise_error("prose warnings present and --require-clean was set:\n  - " + "\n  - ".join(result["warnings"]))
    result["findings"] = prose_findings(result)
    return result


# ---------------------------------------------------------------------------- cli


def _load_bound(root: Path, state: dict[str, Any], manifest: dict[str, Any]) -> tuple[dict[str, Any], Path]:
    path = resolve_state_path(root, state, "soul_profile", required=False)
    if path is None or not path.exists():
        path = root / "artifacts" / "soul-profile.json"
    if not path.exists():
        raise_error(f"soul profile not found at {path}")
    profile = load_json(path)
    if not isinstance(profile, dict):
        raise_error("soul profile must be an object")
    bound = manifest.get("soul_profile_sha256")
    if bound and bound != sha256_file(path):
        raise_error("soul profile hash does not match the manifest binding; regenerate assignments")
    return profile, path


def _required(manifest: dict[str, Any]) -> bool:
    arch = manifest.get("architecture")
    return isinstance(arch, dict) and arch.get("soul_voice") == CONTRACT


def run(build_state: str, stage: str, artifact: str | None, *, write_receipt: bool = True,
        require_clean: bool = False) -> dict[str, Any]:
    root, state = load_build_state(build_state)
    manifest_path = resolve_state_path(root, state, "manifest")
    manifest = load_json(manifest_path)
    if not isinstance(manifest, dict):
        raise_error("manifest must be an object")

    if not _required(manifest):
        return {"kind": RECEIPT_KIND, "receipt_version": RECEIPT_VERSION, "contract": CONTRACT,
                "status": "not_required", "stage": stage, "build_id": state.get("build_id")}

    profile, profile_path = _load_bound(root, state, manifest)
    if stage == "planning":
        detail = validate_manifest(profile, manifest)
        target_sha = sha256_file(manifest_path)
    else:
        target = Path(artifact).resolve() if artifact else resolve_state_path(root, state, "final_output")
        detail = validate_output(profile, load_json(target), require_clean=require_clean)
        target_sha = sha256_file(target)

    receipt = {
        "kind": RECEIPT_KIND, "receipt_version": RECEIPT_VERSION, "contract": CONTRACT,
        "status": "passed", "stage": stage, "build_id": state.get("build_id"),
        "soul_profile_sha256": sha256_file(profile_path), "target_sha256": target_sha,
        "detail": detail,
    }
    if write_receipt:
        out = root / "artifacts" / f"soul-gate-{stage}.json"
        out.parent.mkdir(parents=True, exist_ok=True)
        atomic_write_json(out, receipt)
        receipt["receipt_path"] = str(out)
    return receipt


def main() -> int:
    parser = argparse.ArgumentParser(description="Bind and enforce a WorldBuilder soul profile.")
    parser.add_argument("--build-state", help="Build-state path for the read-only --requirements preflight.")
    parser.add_argument("--requirements", action="store_true", help="Read-only preflight: print what this gate checks against the current build state.")
    sub = parser.add_subparsers(dest="command")

    p = sub.add_parser("profile", help="validate a soul profile in isolation")
    p.add_argument("--soul-profile", required=True)
    p.add_argument("--build-id")

    for name, helptext in (("planning", "validate against the manifest"),
                           ("output", "check emitted prose against the profile")):
        s = sub.add_parser(name, help=helptext)
        s.add_argument("--build-state", required=True)
        s.add_argument("--artifact")
        s.add_argument("--require-clean", action="store_true",
                       help="treat editorial warnings as failures")
        s.add_argument("--no-write-receipt", action="store_true")

    args = parser.parse_args()
    if args.requirements:
        if not args.build_state:
            parser.error("--requirements needs --build-state")
        root, state = load_build_state(args.build_state)
        print(json.dumps(preflight_report("soul_contract", requirement_rows(Path(__file__), root, state)), ensure_ascii=False, indent=2))
        return 0
    if args.command is None:
        parser.error("a command is required")
    try:
        if args.command == "profile":
            profile = load_json(Path(args.soul_profile).expanduser().resolve())
            print(json.dumps(validate_profile(profile, build_id=args.build_id), ensure_ascii=False, indent=2))
        else:
            result = run(args.build_state, args.command, args.artifact,
                         write_receipt=not args.no_write_receipt,
                         require_clean=args.require_clean)
            print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (WorldBuilderError, OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
