#!/usr/bin/env python3
"""Track active, completed, failed, and abandoned worker runs idempotently."""
from __future__ import annotations
import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from wb_common import WorldBuilderError, atomic_write_json, ensure_inside, load_build_state, load_json, resolve_state_path

def now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")

def ledger_path(root: Path, state: dict[str, Any]) -> Path:
    return resolve_state_path(root, state, "worker_run_ledger", required=False) or (root / ".work" / "worker-runs.json")

def read_ledger(path: Path, build_id: str) -> dict[str, Any]:
    if not path.exists():
        return {"kind": "worldbuilder-worker-run-ledger", "ledger_version": 1, "build_id": build_id, "runs": {}}
    data = load_json(path)
    if not isinstance(data, dict) or data.get("kind") != "worldbuilder-worker-run-ledger" or data.get("build_id") != build_id or not isinstance(data.get("runs"), dict):
        raise WorldBuilderError("worker run ledger is invalid or belongs to another build")
    return data


def resolve_record(runs: dict[str, Any], run_id: str, assignment_id: str | None) -> tuple[str, Any]:
    """Find the logical run, whichever identifier the caller used.

    A spawned worker is observed under at least two identities: the parent registers it
    by assignment_id, while the runtime observer records completion under the spawn
    runId, and an event id may match neither. Keying only by run_id produced duplicate
    entries for one worker and left the parent's entry `active` forever.

    An exact run_id match wins. Otherwise an entry with the same assignment_id is the
    same worker, and the incoming identifier is recorded as an alias.
    """
    if run_id in runs:
        return run_id, runs[run_id]
    if assignment_id:
        for key, record in runs.items():
            if not isinstance(record, dict):
                continue
            if record.get("assignment_id") == assignment_id or run_id in (record.get("aliases") or []):
                record.setdefault("aliases", [])
                if run_id not in record["aliases"]:
                    record["aliases"].append(run_id)
                return key, record
    return run_id, None


def reconcile(build_state: str) -> dict[str, Any]:
    """Merge duplicate entries for one assignment and close orphaned actives.

    Recovery for ledgers already split by the two conventions. An `active` entry whose
    assignment has a completed sibling is the parent's copy of a worker that finished:
    the work happened, only the bookkeeping is doubled.
    """
    root, state = load_build_state(build_state)
    path = ledger_path(root, state)
    ensure_inside(path, root)
    data = read_ledger(path, str(state.get("build_id")))
    runs = data["runs"]

    by_assignment: dict[str, list[str]] = {}
    for key, record in runs.items():
        assignment = record.get("assignment_id") if isinstance(record, dict) else None
        if assignment:
            by_assignment.setdefault(assignment, []).append(key)

    merged, closed = [], []
    for assignment, keys in by_assignment.items():
        if len(keys) < 2:
            continue
        records = [(k, runs[k]) for k in keys]
        winner_key, winner = next(
            ((k, r) for k, r in records if r.get("status") == "completed"), records[0])
        for key, record in records:
            if key == winner_key:
                continue
            winner.setdefault("aliases", [])
            if key not in winner["aliases"]:
                winner["aliases"].append(key)
            for event in record.get("events", []) or []:
                if event not in (winner.get("events") or []):
                    winner.setdefault("events", []).append(event)
            if record.get("status") == "active" and winner.get("status") == "completed":
                closed.append(key)
            merged.append(key)
            del runs[key]
        winner["reconciled_at"] = now()

    if merged:
        atomic_write_json(path, data)
    return {
        "status": "reconciled",
        "assignments_merged": sorted({runs[k].get("assignment_id") for k in runs
                                      if isinstance(runs.get(k), dict)} & set(by_assignment)) if merged else [],
        "duplicate_entries_removed": sorted(merged),
        "orphaned_active_closed": sorted(closed),
        "ledger": str(path),
        "note": ("Duplicate entries came from the parent and the runtime observer keying "
                 "the same worker differently; the completed record wins and absorbs the "
                 "other's aliases and events." if merged else "No duplicates found."),
    }


def update(build_state: str, action: str, run_id: str, assignment_id: str | None, backend: str | None, reason: str | None, event_id: str | None) -> dict[str, Any]:
    root, state = load_build_state(build_state)
    path = ledger_path(root, state)
    ensure_inside(path, root)
    data = read_ledger(path, str(state.get("build_id")))
    runs = data["runs"]
    run_key, record = resolve_record(runs, run_id, assignment_id)
    if action == "register":
        if record and record.get("status") not in {"abandoned", "failed"}:
            raise WorldBuilderError(f"run_id {run_id} already has status {record.get('status')}")
        record = {"run_id": run_id, "assignment_id": assignment_id, "backend": backend, "status": "active", "registered_at": now(), "events": []}
        runs[run_key] = record
    elif action == "abandon":
        if not record:
            record = {"run_id": run_id, "assignment_id": assignment_id, "backend": backend, "events": []}
            runs[run_key] = record
        if record.get("status") == "completed":
            raise WorldBuilderError("a completed run cannot be abandoned")
        record.update({"status": "abandoned", "abandoned_at": now(), "abandon_reason": reason or "superseded by parent orchestrator"})
    elif action == "complete":
        if not record:
            raise WorldBuilderError("completion cannot be recorded for an unregistered run")
        if record.get("status") == "abandoned":
            return {"status": "quarantined", "run_id": run_id, "reason": record.get("abandon_reason")}
        if record.get("status") == "completed":
            if event_id and event_id in record.get("events", []):
                return {"status": "duplicate_ignored", "run_id": run_id}
            raise WorldBuilderError("run already completed with another event")
        record.update({"status": "completed", "completed_at": now()})
        if event_id:
            record.setdefault("events", []).append(event_id)
    elif action == "fail":
        if not record:
            raise WorldBuilderError("failure cannot be recorded for an unregistered run")
        if record.get("status") == "abandoned":
            return {"status": "quarantined", "run_id": run_id, "reason": record.get("abandon_reason")}
        record.update({"status": "failed", "failed_at": now(), "failure_reason": reason or "worker failed"})
    elif action == "check":
        return {"status": record.get("status") if record else "unknown", "run_id": run_id, "record": record}
    else:
        raise WorldBuilderError(f"unsupported action {action}")
    data["updated_at"] = now()
    atomic_write_json(path, data)
    return {"status": record.get("status"), "run_id": run_id, "ledger": str(path), "record": record}

def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--build-state", required=True)
    parser.add_argument("--action", required=True, choices=("register", "abandon", "complete", "fail", "check", "reconcile"))
    parser.add_argument("--run-id")
    parser.add_argument("--assignment-id")
    parser.add_argument("--backend", choices=("sessions_spawn", "exec"))
    parser.add_argument("--reason")
    parser.add_argument("--event-id")
    args = parser.parse_args()
    try:
        if args.action == "reconcile":
            print(json.dumps(reconcile(args.build_state), ensure_ascii=False, indent=2))
            return 0
        if not args.run_id:
            raise WorldBuilderError("--run-id is required for this action")
        print(json.dumps(update(args.build_state, args.action, args.run_id, args.assignment_id, args.backend, args.reason, args.event_id), ensure_ascii=False, indent=2))
        return 0
    except (WorldBuilderError, OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
if __name__ == "__main__":
    raise SystemExit(main())
