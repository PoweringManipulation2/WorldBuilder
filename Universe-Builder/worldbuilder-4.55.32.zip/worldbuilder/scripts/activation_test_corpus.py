#!/usr/bin/env python3
"""Freeze and check representative activation expectations for a WorldBuilder plan."""
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path
from typing import Any

from runtime_verification import predict
from wb_common import (
    WorldBuilderError,
    atomic_write_json,
    build_identity_index,
    load_build_state,
    load_json,
    normalize_identity,
    resolve_state_path,
    sha256_file,
    uid_label,
)

CONTRACT = "worldbuilder-activation-test-corpus-v1"
KIND = "worldbuilder-activation-test-corpus"
RECEIPT_KIND = "worldbuilder-activation-test-corpus-gate"
CORPUS_VERSION = 1
RECEIPT_VERSION = 1
DEFAULT_DEPTH = 8


def _uid_list(value: Any, *, field: str, case_number: int, known: set[str]) -> list[str]:
    if not isinstance(value, list):
        raise WorldBuilderError(f"activation_tests[{case_number}].{field} must be a list of manifest UIDs")
    result: list[str] = []
    seen: set[str] = set()
    for raw in value:
        uid = uid_label(raw)
        if uid in seen:
            raise WorldBuilderError(f"activation_tests[{case_number}].{field} repeats UID {uid!r}")
        if uid not in known:
            raise WorldBuilderError(f"activation_tests[{case_number}].{field} references unknown manifest UID {uid!r}")
        seen.add(uid)
        result.append(uid)
    return result


def normalize_cases(manifest: dict[str, Any]) -> list[dict[str, Any]] | None:
    """Return the optional manifest activation-test declaration in canonical form."""
    if "activation_tests" not in manifest:
        return None
    raw_cases = manifest.get("activation_tests")
    if raw_cases is None:
        return None
    if not isinstance(raw_cases, list):
        raise WorldBuilderError("manifest activation_tests must be a list when present")
    if not raw_cases:
        raise WorldBuilderError("manifest activation_tests is present but empty; omit the field when no corpus is desired")
    known = {str(uid) for uid in build_identity_index(manifest)}
    cases: list[dict[str, Any]] = []
    for index, raw in enumerate(raw_cases, start=1):
        if not isinstance(raw, dict):
            raise WorldBuilderError(f"activation_tests[{index}] must be an object")
        unknown = sorted(set(raw) - {"prompt", "should_activate", "should_not_activate"})
        if unknown:
            raise WorldBuilderError(f"activation_tests[{index}] has unsupported field(s): {', '.join(unknown)}")
        prompt = raw.get("prompt")
        if not isinstance(prompt, str) or not prompt.strip():
            raise WorldBuilderError(f"activation_tests[{index}].prompt must be non-empty text")
        positive = _uid_list(raw.get("should_activate", []), field="should_activate", case_number=index, known=known)
        negative = _uid_list(raw.get("should_not_activate", []), field="should_not_activate", case_number=index, known=known)
        if not positive and not negative:
            raise WorldBuilderError(f"activation_tests[{index}] must declare at least one positive or negative expectation")
        overlap = sorted(set(positive) & set(negative))
        if overlap:
            raise WorldBuilderError(f"activation_tests[{index}] puts the same UID in positive and negative expectations: {', '.join(overlap)}")
        cases.append({
            "case_id": f"at-{index:03d}",
            "prompt": prompt,
            "should_activate": positive,
            "should_not_activate": negative,
        })
    return cases


def _paths(root: Path, state: dict[str, Any]) -> tuple[Path, Path]:
    corpus = resolve_state_path(root, state, "activation_test_corpus", required=False)
    receipt = resolve_state_path(root, state, "activation_test_corpus_receipt", required=False)
    if corpus is None:
        corpus = root / "artifacts" / "activation-test-corpus.json"
    if receipt is None:
        receipt = root / "artifacts" / "activation-test-corpus-gate.json"
    return corpus, receipt


def _build_corpus(build_id: str, manifest_sha: str, cases: list[dict[str, Any]], depth: int) -> dict[str, Any]:
    return {
        "kind": KIND,
        "contract": CONTRACT,
        "corpus_version": CORPUS_VERSION,
        "build_id": build_id,
        "created_from_manifest_sha256": manifest_sha,
        "depth_limit": depth,
        "cases": cases,
    }


def _load_corpus(path: Path, *, build_id: str) -> dict[str, Any]:
    data = load_json(path)
    if not isinstance(data, dict):
        raise WorldBuilderError(f"{path.name} must be a JSON object")
    if data.get("kind") != KIND or data.get("contract") != CONTRACT or data.get("corpus_version") != CORPUS_VERSION:
        raise WorldBuilderError(f"{path.name} has the wrong activation-test corpus contract/version")
    if data.get("build_id") != build_id:
        raise WorldBuilderError(f"{path.name}'s build_id does not match this build")
    depth = data.get("depth_limit")
    if not isinstance(depth, int) or isinstance(depth, bool) or depth < 0:
        raise WorldBuilderError(f"{path.name}.depth_limit must be a non-negative integer")
    cases = data.get("cases")
    if not isinstance(cases, list) or not cases:
        raise WorldBuilderError(f"{path.name}.cases must be a non-empty list")
    return data


def freeze(build_state: str, *, replace: bool = False, depth: int = DEFAULT_DEPTH) -> dict[str, Any]:
    if depth < 0:
        raise WorldBuilderError("depth must be non-negative")
    root, state = load_build_state(build_state)
    manifest_path = resolve_state_path(root, state, "manifest")
    manifest = load_json(manifest_path)
    if not isinstance(manifest, dict):
        raise WorldBuilderError("manifest must be a JSON object")
    cases = normalize_cases(manifest)
    if cases is None:
        raise WorldBuilderError("manifest does not declare activation_tests; there is no corpus to freeze")
    corpus_path, _ = _paths(root, state)
    if corpus_path.exists() and not replace:
        raise WorldBuilderError(f"{corpus_path.name} already exists; refusing to rewrite regression expectations implicitly. Use replace only for an intentional expectation change.")
    corpus = _build_corpus(str(state.get("build_id")), sha256_file(manifest_path), cases, depth)
    atomic_write_json(corpus_path, corpus)
    return {
        "status": "replaced" if replace else "frozen",
        "contract": CONTRACT,
        "corpus": str(corpus_path.relative_to(root)).replace(os.sep, "/"),
        "corpus_sha256": sha256_file(corpus_path),
        "case_count": len(cases),
    }


def check(
    build_state: str,
    *,
    write_receipt: bool = True,
    freeze_if_needed: bool = False,
    enforce: bool = True,
) -> dict[str, Any]:
    root, state = load_build_state(build_state)
    build_id = str(state.get("build_id"))
    manifest_path = resolve_state_path(root, state, "manifest")
    manifest = load_json(manifest_path)
    if not isinstance(manifest, dict):
        raise WorldBuilderError("manifest must be a JSON object")
    declared = normalize_cases(manifest)
    corpus_path, receipt_path = _paths(root, state)

    corpus_is_frozen = corpus_path.exists()
    if not corpus_is_frozen:
        if declared is None:
            return {
                "status": "not_configured",
                "contract": CONTRACT,
                "case_count": 0,
                "corpus": None,
                "corpus_sha256": None,
                "receipt": None,
                "receipt_sha256": None,
            }
        if freeze_if_needed:
            freeze(build_state, depth=DEFAULT_DEPTH)
            corpus_is_frozen = True
        elif not write_receipt:
            # Read-only diagnose can evaluate the declaration without creating
            # its persistent oracle. A real planning pass freezes it.
            corpus = _build_corpus(build_id, sha256_file(manifest_path), declared, DEFAULT_DEPTH)
        else:
            raise WorldBuilderError(f"manifest declares activation_tests but {corpus_path.name} has not been frozen yet")

    if corpus_is_frozen:
        corpus = _load_corpus(corpus_path, build_id=build_id)
    corpus_cases = corpus["cases"]
    if declared is not None and declared != corpus_cases:
        raise WorldBuilderError(
            "manifest activation_tests no longer match the frozen activation-test corpus; "
            "do not mutate the oracle beside the graph. If the expectation change is intentional, run activation_test_corpus.py replace explicitly."
        )

    known = {str(uid) for uid in build_identity_index(manifest)}
    outcomes: list[dict[str, Any]] = []
    failed = 0
    depth = int(corpus["depth_limit"])
    for raw in corpus_cases:
        if not isinstance(raw, dict):
            raise WorldBuilderError(f"{corpus_path.name} contains a non-object test case")
        prompt = raw.get("prompt")
        if not isinstance(prompt, str) or not prompt.strip():
            raise WorldBuilderError(f"{corpus_path.name} contains a case with invalid prompt text")
        expected_on = {uid_label(value) for value in raw.get("should_activate", [])}
        expected_off = {uid_label(value) for value in raw.get("should_not_activate", [])}
        stale = sorted((expected_on | expected_off) - known)
        if stale:
            raise WorldBuilderError(f"{corpus_path.name} references UID(s) no longer present in the manifest: {', '.join(stale)}; update expectations explicitly")
        if expected_on & expected_off:
            raise WorldBuilderError(f"{corpus_path.name} contains overlapping positive/negative expectations in case {raw.get('case_id')!r}")
        predicted = predict(manifest, prompt, depth=depth)
        active = set(predicted["activated_uids"])
        missing = sorted(expected_on - active)
        forbidden = sorted(expected_off & active)
        status = "passed" if not missing and not forbidden else "failed"
        failed += int(status == "failed")
        outcomes.append({
            "case_id": raw.get("case_id"),
            "prompt": prompt,
            "status": status,
            "should_activate": sorted(expected_on),
            "should_not_activate": sorted(expected_off),
            "predicted_activated_uids": predicted["activated_uids"],
            "missing_required_uids": missing,
            "forbidden_activated_uids": forbidden,
        })

    receipt = {
        "kind": RECEIPT_KIND,
        "contract": CONTRACT,
        "receipt_version": RECEIPT_VERSION,
        "status": "passed" if failed == 0 else "failed",
        "build_id": build_id,
        "manifest": str(manifest_path.relative_to(root)).replace(os.sep, "/"),
        "manifest_sha256": sha256_file(manifest_path),
        "corpus": str(corpus_path.relative_to(root)).replace(os.sep, "/") if corpus_is_frozen else None,
        "corpus_sha256": sha256_file(corpus_path) if corpus_is_frozen else None,
        "depth_limit": depth,
        "case_count": len(outcomes),
        "failed_case_count": failed,
        "cases": outcomes,
    }
    if write_receipt:
        atomic_write_json(receipt_path, receipt)
        receipt["receipt"] = str(receipt_path.relative_to(root)).replace(os.sep, "/")
        receipt["receipt_sha256"] = sha256_file(receipt_path)
    else:
        receipt["receipt"] = None
        receipt["receipt_sha256"] = None
    if failed and enforce:
        failed_ids = ", ".join(str(row.get("case_id")) for row in outcomes if row["status"] == "failed")
        raise WorldBuilderError(f"activation-test corpus failed {failed} case(s): {failed_ids}; inspect {receipt_path.name} for missing/forbidden activations")
    return receipt


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    for command in ("freeze", "replace", "check"):
        p = sub.add_parser(command)
        p.add_argument("--build-state", required=True)
        if command in {"freeze", "replace"}:
            p.add_argument("--depth", type=int, default=DEFAULT_DEPTH)
    args = parser.parse_args()
    try:
        if args.command == "freeze":
            result = freeze(args.build_state, depth=args.depth)
        elif args.command == "replace":
            result = freeze(args.build_state, replace=True, depth=args.depth)
        else:
            result = check(args.build_state, write_receipt=True, freeze_if_needed=True, enforce=False)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0 if result.get("status") in {"frozen", "replaced", "passed", "not_configured"} else 1
    except (WorldBuilderError, OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
