#!/usr/bin/env python3
"""Persistent source lineage and approval-gated incremental source synchronization.

The sealed artifact keeps only provenance pointers in ``artifacts/source-lineage.json``;
model-facing content never receives URLs/citations.  A sync check is read-only.  Only
``approve`` turns changed source pointers into the existing selective-regeneration
scope, so author locks and scoped lineage invalidation remain single-sourced.
"""
from __future__ import annotations

import argparse
import json
import os
import urllib.parse
from pathlib import Path
from typing import Any, Iterable

from selective_regeneration import prepare as prepare_regeneration, resolve_scope
from wb_common import (
    WorldBuilderError,
    atomic_write_json,
    canonical_entry_identity,
    entry_binding_hash,
    iter_entries,
    load_build_state,
    load_json,
    now_iso,
    resolve_state_path,
    sha256_file,
)

LEGACY_CONTRACT = "worldbuilder-source-lineage-v1"
CONTRACT = "worldbuilder-source-lineage-v2"
SUPPORTED_CONTRACTS = {LEGACY_CONTRACT, CONTRACT}
REPORT_CONTRACT = "worldbuilder-source-sync-report-v1"
APPROVAL_CONTRACT = "worldbuilder-source-sync-approval-v1"


def _norm_locator(value: Any) -> str | None:
    if not isinstance(value, str) or not value.strip():
        return None
    return value.strip()


def _evidence_files(root: Path, state: dict[str, Any]) -> list[Path]:
    files: set[Path] = set()
    assignments = resolve_state_path(root, state, "assignments", required=False)
    if assignments and assignments.is_dir():
        for path in assignments.glob("*.json"):
            try:
                row = load_json(path)
            except Exception:
                continue
            rel = row.get("evidence_output") if isinstance(row, dict) else None
            if isinstance(rel, str) and rel:
                candidate = (root / rel).resolve()
                try:
                    candidate.relative_to(root)
                except ValueError:
                    continue
                if candidate.is_file():
                    files.add(candidate)
    evidence_dir = resolve_state_path(root, state, "evidence_receipts", required=False)
    if evidence_dir and evidence_dir.is_dir():
        for path in evidence_dir.rglob("*.json"):
            try:
                data = load_json(path)
            except Exception:
                continue
            if isinstance(data, dict) and isinstance(data.get("entries"), list):
                files.add(path)
    return sorted(files)


def _discovery_metadata(root: Path, state: dict[str, Any]) -> dict[str, dict[str, Any]]:
    by_url: dict[str, dict[str, Any]] = {}
    directory = resolve_state_path(root, state, "discoveries", required=False)
    if directory and directory.is_dir():
        for path in (directory / "results").glob("*.json") if (directory / "results").is_dir() else []:
            try:
                data = load_json(path)
            except Exception:
                continue
            for row in data.get("fetch_records", []) if isinstance(data, dict) else []:
                if not isinstance(row, dict):
                    continue
                url = _norm_locator(row.get("url"))
                if url:
                    by_url[url] = {
                        "page_id": row.get("pageid"), "revision_id": row.get("revid"),
                        "title": row.get("title"), "fetch_method": row.get("method"),
                    }
    api_url = None
    plan_path = resolve_state_path(root, state, "discovery_plan", required=False)
    if plan_path and plan_path.is_file():
        try:
            plan = load_json(plan_path)
            source = plan.get("source") if isinstance(plan, dict) else None
            if isinstance(source, dict):
                api_url = source.get("api_url")
            if not api_url and isinstance(plan, dict):
                api_url = plan.get("api_url")
            if not api_url:
                assignments = plan.get("assignments") if isinstance(plan, dict) else None
                if isinstance(assignments, list):
                    for item in assignments:
                        fp = item.get("fetch_policy") if isinstance(item, dict) else None
                        if isinstance(fp, dict) and fp.get("api_url"):
                            api_url = fp["api_url"]; break
        except Exception:
            pass
    if api_url:
        for row in by_url.values():
            row.setdefault("api_url", api_url)
    return by_url


def _entry_name(entry: dict[str, Any]) -> str | None:
    for key in ("comment", "name", "title"):
        value = entry.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return None


def _merged_phase_usage(root: Path, state: dict[str, Any]) -> tuple[dict[str, dict[str, Any]], list[str]]:
    """Recover the claim IDs actually used by entries from the exact merged phases.

    The merge receipt is the authority for which phase files produced the merged
    artifact.  Never scan arbitrary phase files: stale/superseded phases may still
    exist in scratch.  A missing or hash-drifted phase degrades trace strength rather
    than causing source lineage to invent usage.
    """
    merge = (state.get("lineage") or {}).get("merge") if isinstance(state.get("lineage"), dict) else None
    rows = merge.get("phase_files") if isinstance(merge, dict) else None
    if not isinstance(rows, list):
        return {}, ["merge phase lineage is unavailable; used-claim trace degraded to evidence-only"]
    usage: dict[str, dict[str, Any]] = {}
    conflicted: set[str] = set()
    warnings: list[str] = []
    for row in rows:
        if not isinstance(row, dict) or not isinstance(row.get("path"), str):
            warnings.append("merge phase lineage contains an invalid phase record")
            continue
        raw = Path(row["path"])
        path = raw if raw.is_absolute() else (root / raw)
        path = path.resolve()
        try:
            path.relative_to(root)
        except ValueError:
            warnings.append(f"merged phase path escapes build root: {row['path']}")
            continue
        if not path.is_file():
            warnings.append(f"merged phase is missing: {row['path']}")
            continue
        expected = row.get("sha256")
        actual = sha256_file(path)
        if isinstance(expected, str) and expected and expected.lower() != actual.lower():
            warnings.append(f"merged phase hash drift: {row['path']}")
            continue
        try:
            data = load_json(path)
        except Exception:
            warnings.append(f"merged phase is unreadable JSON: {row['path']}")
            continue
        metadata = data.get("_worldbuilder") if isinstance(data, dict) else None
        claims_by_uid = metadata.get("evidence_claims") if isinstance(metadata, dict) else None
        if not isinstance(claims_by_uid, dict):
            warnings.append(f"merged phase lacks validated evidence_claims metadata: {row['path']}")
            continue
        for ref in iter_entries(data):
            identity = canonical_entry_identity(ref.entry)
            if identity is None:
                continue
            uid = str(identity)
            claims = claims_by_uid.get(uid)
            if claims is None:
                claims = claims_by_uid.get(identity)
            if not isinstance(claims, list) or any(not isinstance(item, str) for item in claims):
                warnings.append(f"merged phase has invalid evidence_claims for UID {uid}: {row['path']}")
                continue
            candidate = {
                "used_claim_ids": sorted(set(claims)),
                "generated_entry_sha256": entry_binding_hash(ref.entry),
                "generated_content_sha256": entry_binding_hash(ref.entry.get("content")),
                "phase_path": str(path.relative_to(root)).replace(os.sep, "/"),
                "phase_sha256": actual,
            }
            prior = usage.get(uid)
            if prior is not None and prior != candidate:
                conflicted.add(uid)
                warnings.append(f"conflicting merged phase provenance for UID {uid}; used-claim trace suppressed")
                continue
            usage[uid] = candidate
    for uid in conflicted:
        usage.pop(uid, None)
    return usage, warnings


def _sealed_entry_index(root: Path, state: dict[str, Any]) -> tuple[dict[str, dict[str, Any]], dict[str, Any] | None]:
    path = resolve_state_path(root, state, "final_output", required=False)
    if not path or not path.is_file():
        return {}, None
    try:
        data = load_json(path)
    except Exception:
        return {}, {"path": str(path.relative_to(root)).replace(os.sep, "/"), "sha256": sha256_file(path), "entry_hashes_available": False}
    entries: dict[str, dict[str, Any]] = {}
    for ref in iter_entries(data):
        identity = canonical_entry_identity(ref.entry)
        if identity is None:
            continue
        uid = str(identity)
        entries[uid] = {
            "sealed_entry_sha256": entry_binding_hash(ref.entry),
            "sealed_content_sha256": entry_binding_hash(ref.entry.get("content")),
            "name": _entry_name(ref.entry),
        }
    return entries, {
        "path": str(path.relative_to(root)).replace(os.sep, "/"),
        "sha256": sha256_file(path),
        "entry_hashes_available": True,
    }


def _sealed_target(state: dict[str, Any]) -> dict[str, Any] | None:
    lineage = state.get("lineage") if isinstance(state.get("lineage"), dict) else {}
    audit = lineage.get("audit") if isinstance(lineage, dict) else None
    seal = audit.get("seal") if isinstance(audit, dict) else None
    if not isinstance(seal, dict):
        return None
    target = seal.get("target")
    digest = seal.get("target_sha256")
    if not isinstance(target, str) or not isinstance(digest, str):
        return None
    return {"path": target, "sha256": digest}


def build_source_lineage(root: Path, state: dict[str, Any]) -> dict[str, Any]:
    discovery = _discovery_metadata(root, state)
    pages: dict[str, dict[str, Any]] = {}
    evidence_uids: set[str] = set()
    claim_sources: dict[str, dict[str, list[dict[str, Any]]]] = {}
    for path in _evidence_files(root, state):
        try:
            data = load_json(path)
        except Exception:
            continue
        for entry in data.get("entries", []) if isinstance(data, dict) else []:
            if not isinstance(entry, dict) or entry.get("uid") is None:
                continue
            uid = str(entry["uid"])
            evidence_uids.add(uid)
            sources = {str(src.get("source_id")): src for src in entry.get("sources", []) if isinstance(src, dict) and src.get("source_id")}
            for claim in entry.get("claims", []) if isinstance(entry.get("claims"), list) else []:
                if not isinstance(claim, dict):
                    continue
                cid = str(claim.get("claim_id") or claim.get("id") or "").strip()
                for ref in claim.get("source_refs", []) if isinstance(claim.get("source_refs"), list) else []:
                    src = sources.get(str(ref))
                    if not isinstance(src, dict):
                        continue
                    locator = _norm_locator(src.get("locator") or src.get("url"))
                    if not locator:
                        continue
                    pointer = {
                        "source_id": str(src.get("source_id")),
                        "locator": locator,
                        "page_id": src.get("page_id") or src.get("pageid"),
                        "revision_id": src.get("revision_id") or src.get("revid"),
                        "title": src.get("title"),
                    }
                    row = pages.setdefault(locator, {
                        "locator": locator, "page_id": src.get("page_id") or src.get("pageid"),
                        "revision_id": src.get("revision_id") or src.get("revid"), "title": src.get("title"),
                        "api_url": src.get("api_url"), "claims": {}, "uids": [],
                    })
                    meta = discovery.get(locator, {})
                    for key in ("page_id", "revision_id", "title", "api_url", "fetch_method"):
                        if row.get(key) is None and meta.get(key) is not None:
                            row[key] = meta[key]
                    pointer.update({key: row.get(key) for key in ("page_id", "revision_id", "title")})
                    if uid not in row["uids"]:
                        row["uids"].append(uid)
                    if cid:
                        row["claims"].setdefault(cid, [])
                        if uid not in row["claims"][cid]:
                            row["claims"][cid].append(uid)
                        bucket = claim_sources.setdefault(uid, {}).setdefault(cid, [])
                        if pointer not in bucket:
                            bucket.append(pointer)

    phase_usage, trace_warnings = _merged_phase_usage(root, state)
    sealed_entries, final_output = _sealed_entry_index(root, state)

    for row in pages.values():
        used_claims: dict[str, list[str]] = {}
        for claim_id, uids in row.get("claims", {}).items():
            matched = [uid for uid in uids if claim_id in set((phase_usage.get(uid) or {}).get("used_claim_ids", []))]
            if matched:
                used_claims[claim_id] = sorted(set(matched), key=str)
        row["used_claims"] = {key: used_claims[key] for key in sorted(used_claims)}
        row["used_uids"] = sorted({uid for uids in used_claims.values() for uid in uids}, key=str)

    entry_rows: list[dict[str, Any]] = []
    all_uids = sorted(evidence_uids | set(phase_usage), key=lambda value: (not value.lstrip("-").isdigit(), value))
    for uid in all_uids:
        usage = phase_usage.get(uid)
        sealed = sealed_entries.get(uid)
        used_claim_ids = list(usage.get("used_claim_ids", [])) if usage else None
        source_map: dict[tuple[str, str], dict[str, Any]] = {}
        if usage:
            for claim_id in used_claim_ids or []:
                for pointer in claim_sources.get(uid, {}).get(claim_id, []):
                    key = (str(pointer.get("source_id")), str(pointer.get("locator")))
                    source_row = source_map.setdefault(key, {**pointer, "claim_ids": []})
                    if claim_id not in source_row["claim_ids"]:
                        source_row["claim_ids"].append(claim_id)
        for source_row in source_map.values():
            source_row["claim_ids"].sort()
        if usage and sealed:
            if usage["generated_entry_sha256"] == sealed["sealed_entry_sha256"]:
                trace_status = "exact_generated_to_sealed"
            elif usage["generated_content_sha256"] == sealed["sealed_content_sha256"]:
                trace_status = "model_facing_content_exact"
            else:
                trace_status = "post_generation_content_changed"
        elif usage:
            trace_status = "generated_only"
        else:
            trace_status = "evidence_only"
        entry_rows.append({
            "uid": uid,
            "name": sealed.get("name") if sealed else None,
            "claim_usage_status": "verified" if usage else "unavailable",
            "used_claim_ids": used_claim_ids,
            "sources": sorted(source_map.values(), key=lambda row: (str(row.get("locator")), str(row.get("source_id")))),
            "generated_entry_sha256": usage.get("generated_entry_sha256") if usage else None,
            "sealed_entry_sha256": sealed.get("sealed_entry_sha256") if sealed else None,
            "generated_content_sha256": usage.get("generated_content_sha256") if usage else None,
            "sealed_content_sha256": sealed.get("sealed_content_sha256") if sealed else None,
            "phase_path": usage.get("phase_path") if usage else None,
            "phase_sha256": usage.get("phase_sha256") if usage else None,
            "trace_status": trace_status,
        })

    normalized = []
    for locator, row in sorted(pages.items()):
        row["uids"] = sorted(row["uids"], key=str)
        row["claims"] = {k: sorted(v, key=str) for k, v in sorted(row["claims"].items())}
        normalized.append(row)
    summary: dict[str, int] = {}
    for row in entry_rows:
        summary[row["trace_status"]] = summary.get(row["trace_status"], 0) + 1
    return {
        "contract": CONTRACT, "source_lineage_version": 2, "build_id": state.get("build_id"), "created_at": now_iso(),
        "pages": normalized, "page_count": len(normalized),
        "entries": entry_rows, "entry_count": len(entry_rows), "trace_summary": summary,
        "final_output": final_output, "sealed_target": _sealed_target(state), "trace_warnings": sorted(set(trace_warnings)),
        "note": "Persistent provenance pointers and hashes only; raw evidence/entry prose remains outside this artifact and it is never model-facing content.",
    }


def write_source_lineage(build_state: str | Path) -> dict[str, Any]:
    root, state = load_build_state(build_state)
    path = resolve_state_path(root, state, "source_lineage", required=False) or (root / "artifacts/source-lineage.json")
    data = build_source_lineage(root, state)
    atomic_write_json(path, data)
    state.setdefault("lineage", {})["source_lineage"] = {"path": str(path.relative_to(root)).replace(os.sep, "/"), "sha256": sha256_file(path)}
    atomic_write_json(Path(build_state).resolve(), state)
    return data


def _snapshot_rows(snapshot: dict[str, Any]) -> list[dict[str, Any]]:
    rows = snapshot.get("pages") if isinstance(snapshot, dict) else None
    if not isinstance(rows, list):
        raise WorldBuilderError("source snapshot must contain pages: []")
    return [r for r in rows if isinstance(r, dict)]


def classify(lineage: dict[str, Any], snapshot: dict[str, Any]) -> dict[str, Any]:
    old = {str(r.get("locator")): r for r in lineage.get("pages", []) if isinstance(r, dict) and r.get("locator")}
    new_rows = _snapshot_rows(snapshot)
    new = {str(r.get("locator")): r for r in new_rows if r.get("locator")}
    new_by_page = {str(r.get("page_id")): r for r in new_rows if r.get("page_id") is not None}
    statuses: list[dict[str, Any]] = []
    seen_new: set[str] = set()
    for locator, prev in sorted(old.items()):
        current = new.get(locator)
        status = "unchanged"
        current_locator = locator
        if current is None and prev.get("page_id") is not None:
            moved = new_by_page.get(str(prev.get("page_id")))
            if moved is not None:
                current = moved; current_locator = str(moved.get("locator")); status = "moved"
        if current is None:
            status = "deleted"
        elif current.get("deleted") is True or current.get("status") == "deleted":
            status = "deleted"
        elif status != "moved" and prev.get("revision_id") is not None and current.get("revision_id") is not None and str(prev.get("revision_id")) != str(current.get("revision_id")):
            status = "modified"
        if current is not None:
            seen_new.add(current_locator)
        statuses.append({
            "status": status, "locator": locator, "current_locator": current_locator if current is not None else None,
            "page_id": prev.get("page_id"), "old_revision_id": prev.get("revision_id"),
            "new_revision_id": current.get("revision_id") if current else None,
            "uids": sorted({str(x) for x in prev.get("uids", [])}), "claims": prev.get("claims", {}),
        })
    for locator, current in sorted(new.items()):
        if locator in seen_new or locator in old:
            continue
        if current.get("relevant", True):
            statuses.append({"status": "newly-relevant", "locator": locator, "current_locator": locator, "page_id": current.get("page_id"), "old_revision_id": None, "new_revision_id": current.get("revision_id"), "uids": [], "claims": {}})
    counts: dict[str, int] = {}
    for row in statuses:
        counts[row["status"]] = counts.get(row["status"], 0) + 1
    return {"statuses": statuses, "counts": counts}


def _live_snapshot(lineage: dict[str, Any], timeout: float = 20.0) -> dict[str, Any]:
    from wiki_fetch import fetch_page
    pages = []
    for row in lineage.get("pages", []):
        if not isinstance(row, dict) or not row.get("locator"):
            continue
        locator = str(row["locator"])
        api_url = row.get("api_url")
        try:
            fetched = fetch_page(locator, api_url, timeout, 1)
            pages.append({"locator": locator, "page_id": fetched.get("pageid"), "revision_id": fetched.get("revid"), "title": fetched.get("title"), "relevant": True})
        except Exception as exc:
            pages.append({"locator": locator, "page_id": row.get("page_id"), "revision_id": row.get("revision_id"), "status": "unreachable", "error": str(exc)[:300], "relevant": True})
    return {"pages": pages, "source": "live-refetch"}


def check(build_state: str, *, snapshot_path: str | None = None, timeout: float = 20.0) -> dict[str, Any]:
    root, state = load_build_state(build_state)
    lineage_path = resolve_state_path(root, state, "source_lineage", required=False) or (root / "artifacts/source-lineage.json")
    if not lineage_path.exists():
        raise WorldBuilderError("source-lineage.json is missing; seal a source-backed build with the current WorldBuilder first")
    lineage = load_json(lineage_path)
    contract = lineage.get("contract") if isinstance(lineage, dict) else None
    if contract is not None and contract not in SUPPORTED_CONTRACTS:
        raise WorldBuilderError(f"unsupported source-lineage contract {contract!r}")
    snapshot = load_json(Path(snapshot_path).resolve()) if snapshot_path else _live_snapshot(lineage, timeout)
    classified = classify(lineage, snapshot)
    affected = sorted({uid for row in classified["statuses"] if row["status"] in {"modified", "moved", "deleted"} for uid in row.get("uids", [])})
    report = {
        "contract": REPORT_CONTRACT, "build_id": state.get("build_id"), "created_at": now_iso(),
        "source_lineage_sha256": sha256_file(lineage_path), **classified, "affected_uids": affected,
        "approval_required": True, "approved": False,
    }
    report_path = resolve_state_path(root, state, "source_sync_report", required=False) or (root / "artifacts/source-update-report.json")
    atomic_write_json(report_path, report)
    return {"status": "review_required", "report": str(report_path), "report_data": report}


def trace(build_state: str, *, uid: str | None = None, claim_id: str | None = None, locator: str | None = None) -> dict[str, Any]:
    selectors = [("uid", uid), ("claim_id", claim_id), ("locator", locator)]
    active = [(name, str(value)) for name, value in selectors if value is not None]
    if len(active) != 1:
        raise WorldBuilderError("trace requires exactly one selector: --uid, --claim-id, or --locator")
    root, state = load_build_state(build_state)
    lineage_path = resolve_state_path(root, state, "source_lineage", required=False) or (root / "artifacts/source-lineage.json")
    if not lineage_path.is_file():
        raise WorldBuilderError("source-lineage.json is missing; seal a source-backed build first")
    lineage = load_json(lineage_path)
    contract = lineage.get("contract") if isinstance(lineage, dict) else None
    if contract not in SUPPORTED_CONTRACTS:
        raise WorldBuilderError(f"unsupported source-lineage contract {contract!r}")
    kind, value = active[0]
    pages = [row for row in lineage.get("pages", []) if isinstance(row, dict)]
    entries = [row for row in lineage.get("entries", []) if isinstance(row, dict)] if contract == CONTRACT else []
    if kind == "uid":
        matched_pages = [row for row in pages if value in {str(x) for x in row.get("uids", [])}]
        matched_entries = [row for row in entries if str(row.get("uid")) == value]
    elif kind == "claim_id":
        matched_pages = [row for row in pages if value in (row.get("claims") or {})]
        matched_entries = [row for row in entries if value in (row.get("used_claim_ids") or [])]
    else:
        matched_pages = [row for row in pages if str(row.get("locator")) == value]
        matched_entries = [row for row in entries if any(str(src.get("locator")) == value for src in row.get("sources", []) if isinstance(src, dict))]
    evidence_level = "used-claim-bound" if contract == CONTRACT and any(row.get("claim_usage_status") == "verified" for row in matched_entries) else "evidence-only"
    return {
        "status": "ok", "contract": contract, "source_lineage_sha256": sha256_file(lineage_path),
        "selector": {kind: value}, "evidence_level": evidence_level,
        "entries": matched_entries, "pages": matched_pages,
    }


def approve(build_state: str, report_path: str, *, approved_by: str = "user") -> dict[str, Any]:
    root, state = load_build_state(build_state)
    report_file = Path(report_path).resolve()
    report = load_json(report_file)
    if report.get("contract") != REPORT_CONTRACT or report.get("build_id") != state.get("build_id"):
        raise WorldBuilderError("source update report is invalid or belongs to another build")
    affected = [str(x) for x in report.get("affected_uids", [])]
    if not affected:
        return {"status": "no_regeneration_needed", "affected_uids": []}
    manifest = load_json(resolve_state_path(root, state, "manifest"))
    scope = resolve_scope(manifest, scope_kind="uids", uids=affected)
    approval_path = resolve_state_path(root, state, "source_sync_approval", required=False) or (root / "artifacts/source-update-approval.json")
    approval = {"contract": APPROVAL_CONTRACT, "build_id": state.get("build_id"), "approved_at": now_iso(), "approved_by": approved_by, "report_sha256": sha256_file(report_file), "affected_uids": affected}
    atomic_write_json(approval_path, approval)
    prepared = prepare_regeneration(build_state, scope)
    return {"status": "approved_and_prepared", "approval": str(approval_path), "regeneration": prepared, "locked_exclusions": scope.get("locked_exclusions", [])}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--build-state", required=True)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("lineage")
    c = sub.add_parser("check"); c.add_argument("--snapshot"); c.add_argument("--timeout", type=float, default=20.0)
    a = sub.add_parser("approve"); a.add_argument("--report", required=True); a.add_argument("--approved-by", default="user")
    t = sub.add_parser("trace"); group = t.add_mutually_exclusive_group(required=True); group.add_argument("--uid"); group.add_argument("--claim-id"); group.add_argument("--locator")
    args = parser.parse_args()
    try:
        if args.command == "lineage": result = {"status": "written", "data": write_source_lineage(args.build_state)}
        elif args.command == "check": result = check(args.build_state, snapshot_path=args.snapshot, timeout=args.timeout)
        elif args.command == "approve": result = approve(args.build_state, args.report, approved_by=args.approved_by)
        else: result = trace(args.build_state, uid=args.uid, claim_id=args.claim_id, locator=args.locator)
        print(json.dumps(result, ensure_ascii=False, indent=2)); return 0
    except (WorldBuilderError, OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=__import__('sys').stderr); return 1

if __name__ == "__main__":
    raise SystemExit(main())
