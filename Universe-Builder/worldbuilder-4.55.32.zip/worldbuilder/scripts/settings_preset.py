#!/usr/bin/env python3
"""Portable, allowlisted WorldBuilder build-setting presets.

Presets are project/build defaults only. They never carry workspace paths,
models, autonomy/debug preferences, source files, audit bypasses, or arbitrary
custom override blobs. Existing build contracts remain the validators after a
preset is applied.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any, Iterable, Mapping

from pruning_objectives import OBJECTIVE_DEFINITIONS, validate_plan_rows as validate_pruning_objective_rows
from wb_common import WorldBuilderError, atomic_write_json, load_build_state, load_json, sha256_bytes, sha256_file

CONTRACT = "worldbuilder-settings-preset-v1"
KIND = "worldbuilder-settings-preset"
PRESET_VERSION = 1

# This list is intentionally narrow. Adding a build flag elsewhere does not
# automatically make it shareable; a future preset revision must opt it in.
FIELD_SPECS: dict[str, dict[str, Any]] = {
    "source_stance": {
        "dest": "source_stance", "flag": "--source-stance",
        "choices": {"user-canonical", "source-canonical", "hybrid"},
    },
    "source_kind": {
        "dest": "source_kind", "flag": "--source-kind",
        "choices": {"original", "known-property", "provided-corpus", "existing-lorebook"},
    },
    "retrieval": {
        "dest": "retrieval", "flag": "--retrieval",
        "choices": {"keyword", "hybrid", "vector-first", "auto"},
    },
    "recursion": {
        "dest": "recursion", "flag": "--recursion",
        "choices": {"off", "controlled", "expansive", "custom"},
    },
    "era_mode": {
        "dest": "era_mode", "flag": "--era-mode",
        "choices": {"single", "multi"},
    },
    "era_isolation": {
        "dest": "era_isolation", "flag": "--era-isolation",
        "choices": {"strict", "balanced"},
    },
    "audit_max_iterations": {
        "dest": "audit_max_iterations", "flag": "--audit-max-iterations",
        "integer": True, "minimum": 1, "maximum": 5,
    },
    "vision_soft_percent": {
        "dest": "vision_soft_percent", "flag": "--vision-soft-percent",
        "integer": True, "minimum": 10, "maximum": 100,
    },
    "vision_session_cap": {
        "dest": "vision_session_cap", "flag": "--vision-session-cap",
        "integer": True, "minimum": 1, "maximum": 1000,
    },
    # Exact custom override files are deliberately not part of preset v1.
    "placement_policy": {
        "dest": "placement_policy", "flag": "--placement-policy",
        "choices": {"automatic", "review"},
    },
    "budget_profile": {
        "dest": "budget_profile", "flag": "--budget-profile",
        "choices": {"compact", "recommended", "maximum_detail"},
    },
    "budget_policy": {
        "dest": "budget_policy", "flag": "--budget-policy",
        "choices": {"automatic", "review"},
    },
    "pruning_objectives": {
        "dest": "pruning_objective", "flag": "--pruning-objective",
        "list": True, "choices": set(OBJECTIVE_DEFINITIONS),
    },
    "dynamic_policy": {
        "dest": "dynamic_policy", "flag": "--dynamic-policy",
        "choices": {"off", "review", "preserve"},
    },
    "runtime_target": {
        "dest": "runtime_target", "flag": "--runtime-target",
        "choices": {"portable", "sillytavern-1.18.0", "preserve"},
    },
    "runtime_format": {
        "dest": "runtime_format", "flag": "--runtime-format",
        "choices": {
            "preserve", "schema1-character", "ccv3-embedded", "lorebook-v3",
            "sillytavern-native", "charx", "group-set", "persona-lorebook",
        },
    },
}

FORBIDDEN_EXAMPLES = (
    "no_pre_gen_audit", "skip_audit", "autonomy", "debug", "verification",
    "workspace", "build_dir", "export_root", "source_file", "models",
    "custom_pipeline", "placement_overrides", "budget_overrides",
    "dynamic_overrides", "context_window", "pipeline",
)


def _canonical_bytes(data: Mapping[str, Any]) -> bytes:
    return (json.dumps(data, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n").encode("utf-8")


def normalized_sha256(preset: Mapping[str, Any]) -> str:
    return sha256_bytes(_canonical_bytes(preset))


def _normalize_budget_profile(value: str) -> str:
    aliases = {
        "quick": "compact",
        "full-detail": "maximum_detail",
        "full_detail": "maximum_detail",
        "maximum-detail": "maximum_detail",
        "maximum_detail": "maximum_detail",
        "maximum": "maximum_detail",
    }
    return aliases.get(value.strip().casefold(), value.strip().casefold())


def validate_preset(data: Any) -> dict[str, Any]:
    if not isinstance(data, dict):
        raise WorldBuilderError("settings preset must contain one JSON object")
    allowed_top = {"kind", "contract", "preset_version", "settings"}
    unknown_top = sorted(set(data) - allowed_top)
    if unknown_top:
        raise WorldBuilderError(f"settings preset has unknown top-level fields: {', '.join(unknown_top)}")
    if data.get("kind") != KIND:
        raise WorldBuilderError(f"settings preset kind must be {KIND!r}")
    if data.get("contract") != CONTRACT:
        raise WorldBuilderError(f"settings preset contract must be {CONTRACT!r}")
    if data.get("preset_version") != PRESET_VERSION:
        raise WorldBuilderError(f"settings preset version must be {PRESET_VERSION}")
    settings = data.get("settings")
    if not isinstance(settings, dict):
        raise WorldBuilderError("settings preset settings must be an object")
    unknown = sorted(set(settings) - set(FIELD_SPECS))
    if unknown:
        examples = ", ".join(FORBIDDEN_EXAMPLES[:4])
        raise WorldBuilderError(
            f"settings preset contains unsupported fields: {', '.join(unknown)}; "
            f"preset v1 is allowlisted and cannot carry safety/host controls such as {examples}"
        )

    normalized: dict[str, Any] = {}
    for key in FIELD_SPECS:
        if key not in settings:
            continue
        spec = FIELD_SPECS[key]
        value = settings[key]
        if spec.get("list"):
            if not isinstance(value, list) or any(not isinstance(item, str) for item in value):
                raise WorldBuilderError(f"settings preset {key} must be a list of strings")
            items = sorted(set(item.strip().casefold() for item in value if item.strip()))
            bad = [item for item in items if item not in spec["choices"]]
            if bad:
                raise WorldBuilderError(f"settings preset {key} has unsupported values: {', '.join(bad)}")
            normalized[key] = items
            continue
        if spec.get("integer"):
            if isinstance(value, bool) or not isinstance(value, int) or not (spec["minimum"] <= value <= spec["maximum"]):
                raise WorldBuilderError(
                    f"settings preset {key} must be an integer between {spec['minimum']} and {spec['maximum']}"
                )
            normalized[key] = value
            continue
        if not isinstance(value, str) or not value.strip():
            raise WorldBuilderError(f"settings preset {key} must be a non-empty string")
        item = value.strip().casefold()
        if key == "budget_profile":
            item = _normalize_budget_profile(item)
        if item not in spec["choices"]:
            raise WorldBuilderError(f"settings preset {key} has unsupported value {value!r}")
        normalized[key] = item

    return {
        "kind": KIND,
        "contract": CONTRACT,
        "preset_version": PRESET_VERSION,
        "settings": normalized,
    }


def load_preset(path: str | Path) -> dict[str, Any]:
    target = Path(path).expanduser().resolve()
    try:
        data = load_json(target)
    except OSError as exc:
        raise WorldBuilderError(f"cannot read settings preset {target}: {exc}") from exc
    return validate_preset(data)


def _portable_policy(name: str, value: Any, supported: set[str]) -> str:
    text = str(value or "").strip().casefold()
    if text not in supported:
        raise WorldBuilderError(
            f"cannot export preset v1: build uses non-portable {name}={text or '<missing>'!r}; "
            "custom/file-backed policy data is deliberately not serialized"
        )
    return text


def preset_from_build_state(state: Mapping[str, Any]) -> dict[str, Any]:
    try:
        objective_rows = state.get("budget", {}).get("pruning_objectives", [])
        if not isinstance(objective_rows, list):
            raise WorldBuilderError("build state budget.pruning_objectives must be a list")
        validate_pruning_objective_rows(objective_rows)
        objective_names = [str(row["name"]) for row in objective_rows]
        settings = {
            "source_stance": str(state["source"]["stance"]),
            "source_kind": str(state["source"]["kind"]),
            "retrieval": str(state["retrieval"]["profile"]),
            "recursion": str(state["recursion"]["profile"]),
            "era_mode": str(state["content_architecture"]["era_mode"]),
            "era_isolation": str(state["content_architecture"]["era_isolation"]),
            "audit_max_iterations": int((state.get("settings") or {}).get("audit_max_iterations", 3)),
            "vision_soft_percent": int((state.get("settings") or {}).get("vision_soft_percent", 75)),
            "placement_policy": _portable_policy(
                "placement_policy", state["placement"]["policy"], {"automatic", "review"}
            ),
            "budget_profile": str(state["budget"]["profile_id"]),
            "budget_policy": _portable_policy(
                "budget_policy", state["budget"]["policy"], {"automatic", "review"}
            ),
            "pruning_objectives": objective_names,
            "dynamic_policy": _portable_policy(
                "dynamic_policy", state["dynamic_state"]["policy"], {"off", "review", "preserve"}
            ),
            "runtime_target": str(
                state["settings"].get("runtime_target_requested", state["settings"]["runtime_target"])
            ),
            "runtime_format": str(
                state["settings"].get("runtime_format_requested", state["settings"]["runtime_format"])
            ),
        }
        vision_session_cap = (state.get("settings") or {}).get("vision_session_cap")
        if vision_session_cap is not None:
            settings["vision_session_cap"] = int(vision_session_cap)
    except (KeyError, TypeError) as exc:
        raise WorldBuilderError(f"build state is missing preset-exportable settings: {exc}") from exc
    return validate_preset({
        "kind": KIND,
        "contract": CONTRACT,
        "preset_version": PRESET_VERSION,
        "settings": settings,
    })


def explicit_option_names(argv: Iterable[str]) -> set[str]:
    result: set[str] = set()
    for token in argv:
        if not isinstance(token, str) or not token.startswith("--"):
            continue
        result.add(token.split("=", 1)[0])
    return result


def apply_preset_to_namespace(args: Any, argv: Iterable[str]) -> dict[str, Any] | None:
    source = getattr(args, "settings_preset", None)
    if not source:
        return None
    source_path = Path(source).expanduser().resolve()
    preset = load_preset(source_path)
    explicit = explicit_option_names(argv)
    applied: list[str] = []
    overridden: list[str] = []
    for key, value in preset["settings"].items():
        spec = FIELD_SPECS[key]
        if spec["flag"] in explicit:
            overridden.append(key)
            continue
        setattr(args, spec["dest"], list(value) if spec.get("list") else value)
        applied.append(key)
    return {
        "contract": CONTRACT,
        "source_sha256": sha256_file(source_path),
        "normalized_sha256": normalized_sha256(preset),
        "applied_fields": sorted(applied),
        "overridden_fields": sorted(overridden),
        "preset": preset,
    }


def export_preset(build_state: str | Path, output: str | Path) -> dict[str, Any]:
    _root, state = load_build_state(str(Path(build_state).expanduser().resolve()))
    preset = preset_from_build_state(state)
    target = Path(output).expanduser().resolve()
    atomic_write_json(target, preset)
    return {
        "status": "exported",
        "contract": CONTRACT,
        "output": str(target),
        "sha256": sha256_file(target),
        "normalized_sha256": normalized_sha256(preset),
        "settings": preset["settings"],
    }


def set_build_setting(build_state: str | Path, *, audit_max_iterations: int | None = None) -> dict[str, Any]:
    """Change one adjustable setting on an existing build.

    The audit loop ceiling is the one preset field that legitimately needs a
    mid-build adjustment; its documented band still binds here, so this can
    never silently raise the ceiling past the band or lower it below one.
    """
    if audit_max_iterations is None:
        raise WorldBuilderError(
            "set requires --audit-max-iterations; it is the only adjustable build setting this command owns"
        )
    spec = FIELD_SPECS["audit_max_iterations"]
    value = audit_max_iterations
    if isinstance(value, bool) or not isinstance(value, int) or not (spec["minimum"] <= value <= spec["maximum"]):
        raise WorldBuilderError(f"audit_max_iterations must be an integer between {spec['minimum']} and {spec['maximum']}")
    state_path = Path(build_state).expanduser().resolve()
    _root, state = load_build_state(str(state_path))
    settings = state.setdefault("settings", {})
    previous = settings.get("audit_max_iterations")
    settings["audit_max_iterations"] = value
    atomic_write_json(state_path, state)
    return {
        "status": "set",
        "contract": CONTRACT,
        "build_state": str(state_path),
        "setting": "audit_max_iterations",
        "previous": previous,
        "current": value,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate or export safe WorldBuilder settings presets.")
    sub = parser.add_subparsers(dest="command", required=True)
    validate = sub.add_parser("validate", help="Validate one settings_preset.json file.")
    validate.add_argument("--preset", required=True)
    export = sub.add_parser("export", help="Export portable settings from a frozen build state.")
    export.add_argument("--build-state", required=True)
    export.add_argument("--output", required=True)
    set_parser = sub.add_parser("set", help="Change one adjustable setting on an existing build (currently --audit-max-iterations, 1-5).")
    set_parser.add_argument("--build-state", required=True)
    set_parser.add_argument("--audit-max-iterations", type=int, help="New audit iteration ceiling (1-5). Applied to the existing build's settings.")
    args = parser.parse_args()
    try:
        if args.command == "validate":
            path = Path(args.preset).expanduser().resolve()
            preset = load_preset(path)
            result = {
                "status": "valid",
                "contract": CONTRACT,
                "preset": str(path),
                "sha256": sha256_file(path),
                "normalized_sha256": normalized_sha256(preset),
                "settings": preset["settings"],
            }
        elif args.command == "export":
            result = export_preset(args.build_state, args.output)
        else:
            result = set_build_setting(args.build_state, audit_max_iterations=args.audit_max_iterations)
        print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
        return 0
    except (WorldBuilderError, OSError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
