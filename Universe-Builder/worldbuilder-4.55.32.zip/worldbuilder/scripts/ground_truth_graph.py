#!/usr/bin/env python3
"""Recompute lorebook activation edges from generated entry content.

The declared manifest graph is planning evidence. This module independently
scans the delivered/generated entry content for other entries' real keys so an
audit can detect drift between the planned graph and the graph the prose can
actually induce. Results are advisory: an orphan or cycle is a review signal,
not an automatic defect or rewrite instruction.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any

from wb_common import canonical_entry_identity, entry_uid, iter_entries, load_json

REPORT_KIND = "worldbuilder-ground-truth-activation-graph"
REPORT_VERSION = 1

CONNECTIVITY_TIER_SPEC: dict[str, dict[str, int]] = {
    # The index shares the root's weight floor deliberately: a truncated
    # roster is worse than no roster, because it silently misrepresents what
    # the world contains rather than merely omitting it (Batch 57, DR-128).
    "world_index": {"weight": 400, "order": 10},
    "world_core": {"weight": 400, "order": 0},
    "hub": {"weight": 300, "order": 25},
    "ordinary": {"weight": 200, "order": 50},
    "leaf": {"weight": 100, "order": 75},
}
DEFAULT_HUB_IN_DEGREE_THRESHOLD = 2

# Batch 49: type-aware order bands. Entries of the same semantic type share
# a contiguous order neighborhood so SillyTavern's order-descending priority
# view groups them together instead of scattering one type across the list
# (the real-file pattern: ERA 80/82/84/125, ITEM 95/112-122, ...). Band
# bases descend by display priority; rank 0..TYPE_ORDER_BAND_SPAN-1 orders
# entries inside a band by root-first, then connectivity tier, then stable
# uid. Weights (the truncation-survival signal) are unchanged.
TYPE_ORDER_BANDS: dict[str, int] = {
    "WORLD": 500,
    "INDEX": 485,
    "RULE": 470,
    "ERA": 440,
    "CHARACTER": 410,
    "RELATIONSHIP": 380,
    "LOCATION": 350,
    "FACTION": 320,
    "ORGANIZATION": 290,
    "SPECIES": 260,
    "EVENT": 230,
    "EPISODE": 200,
    "ITEM": 170,
    "ABILITY": 140,
    "SYSTEM": 110,
    "CONCEPT": 80,
}
TYPE_ORDER_BAND_SPAN = 30

# Local copies of the naming maps (entry_naming is parent-only and not
# staged into worker kits; these keep this module self-contained there).
_ORDER_TYPE_BY_LAYER = {
    "world_index": "INDEX",
    "world_core": "RULE",
    "world_invariants": "RULE",
    "control": "RULE",
    "era_context": "ERA",
    "character": "CHARACTER",
    "relationship": "RELATIONSHIP",
    "location": "LOCATION",
    "faction": "FACTION",
    "organization": "ORGANIZATION",
    "species": "SPECIES",
    "event": "EVENT",
    "episode": "EPISODE",
    "object": "ITEM",
    "item": "ITEM",
    "ability": "ABILITY",
    "system": "SYSTEM",
    "concept": "CONCEPT",
    "detail": "CONCEPT",
}
_ORDER_TYPE_BY_ENTRY_TYPE = {
    "character": "CHARACTER",
    "location": "LOCATION",
    "faction": "FACTION",
    "organization": "ORGANIZATION",
    "species": "SPECIES",
    "event": "EVENT",
    "object": "ITEM",
    "item": "ITEM",
    "artifact": "ITEM",
    "ability": "ABILITY",
    "power": "ABILITY",
    "relationship": "RELATIONSHIP",
    "system": "SYSTEM",
    "mechanic": "SYSTEM",
    "rule": "RULE",
    "concept": "CONCEPT",
    "episode": "EPISODE",
    "other": "CONCEPT",
}
_ORDER_LABEL_RE = re.compile(
    r"^(RULE|ITEM|CHARACTER|LOCATION|FACTION|ORGANIZATION|SPECIES|EVENT|EPISODE|ERA|RELATIONSHIP|ABILITY|SYSTEM|CONCEPT|WORLD|INDEX)\s*:",
    re.IGNORECASE,
)


def _strings(value: Any) -> list[str]:
    if not isinstance(value, list):
        return []
    out: list[str] = []
    seen: set[str] = set()
    for item in value:
        if not isinstance(item, str):
            continue
        text = item.strip()
        folded = text.casefold()
        if text and folded not in seen:
            seen.add(folded)
            out.append(text)
    return out


def _entry_keys(entry: dict[str, Any]) -> list[str]:
    """Primary and secondary keys that generated prose may reference."""
    primary = entry.get("keys") if isinstance(entry.get("keys"), list) else entry.get("key")
    secondary = entry.get("secondary_keys")
    if not isinstance(secondary, list):
        secondary = entry.get("keysecondary")
    return _strings(primary) + [k for k in _strings(secondary) if k.casefold() not in {x.casefold() for x in _strings(primary)}]


def _matches(key: str, content: str, target: dict[str, Any]) -> bool:
    case_sensitive = bool(target.get("case_sensitive", target.get("caseSensitive", False)))
    use_regex = bool(target.get("use_regex", target.get("useRegex", False)))
    flags = 0 if case_sensitive else re.IGNORECASE
    if use_regex:
        try:
            return re.search(key, content, flags) is not None
        except re.error:
            return False
    whole_words = target.get("match_whole_words", target.get("matchWholeWords", True)) is not False
    if whole_words:
        pattern = r"(?<!\w)" + re.escape(key) + r"(?!\w)"
        return re.search(pattern, content, flags) is not None
    if case_sensitive:
        return key in content
    return key.casefold() in content.casefold()


def build_ground_truth_edges(entries: list[dict[str, Any]]) -> list[tuple[str, str]]:
    """Return distinct ``(source_uid, target_uid)`` content-derived edges."""
    keyed: list[tuple[str, dict[str, Any], list[str]]] = []
    for entry in entries:
        uid = entry_uid(entry, strict=False)
        if uid:
            keyed.append((uid, entry, _entry_keys(entry)))

    found: set[tuple[str, str]] = set()
    for source in entries:
        source_uid = entry_uid(source, strict=False)
        if not source_uid:
            continue
        content = str(source.get("content") or "")
        for target_uid, target, keys in keyed:
            if target_uid == source_uid or not keys:
                continue
            if any(_matches(key, content, target) for key in keys):
                found.add((source_uid, target_uid))
    return sorted(found)


def compute_degrees(entries: list[dict[str, Any]], edges: list[tuple[str, str]]) -> dict[str, dict[str, int]]:
    """Real per-entry in/out degree from content-derived edges."""
    uids = [str(uid) for entry in entries if (uid := entry_uid(entry, strict=False))]
    in_degree = {uid: 0 for uid in uids}
    out_degree = {uid: 0 for uid in uids}
    for source, target in edges:
        out_degree[source] = out_degree.get(source, 0) + 1
        in_degree[target] = in_degree.get(target, 0) + 1
    return {"in_degree": in_degree, "out_degree": out_degree}


def world_index_uids(entries: list[dict[str, Any]]) -> set[str]:
    """The world index entry, identified by architecture layer."""
    found: set[str] = set()
    for entry in entries:
        arch = entry.get("architecture")
        layer = arch.get("layer") if isinstance(arch, dict) else None
        uid = entry_uid(entry, strict=False)
        if uid and layer == "world_index":
            found.add(str(uid))
    return found


def world_core_uids(entries: list[dict[str, Any]]) -> set[str]:
    """Root entries identified by architecture layer, matching
    architecture_gate's world_core/world_invariants contract."""
    core: set[str] = set()
    for entry in entries:
        arch = entry.get("architecture")
        layer = arch.get("layer") if isinstance(arch, dict) else None
        uid = entry_uid(entry, strict=False)
        if uid and layer in {"world_core", "world_invariants"}:
            core.add(str(uid))
    return core


def classify_connectivity_tiers(
    entries: list[dict[str, Any]],
    edges: list[tuple[str, str]],
    *,
    hub_in_degree_threshold: int = DEFAULT_HUB_IN_DEGREE_THRESHOLD,
) -> dict[str, str]:
    """Connectivity tiers for default order/weight floors (Batch 46):
    world core > hubs (many others depend on them) > ordinary > genuine
    leaves (nothing downstream). Connectivity is a proxy for structural
    importance, not scene relevance: tiers set a floor under real
    keyword-driven relevance, they never override it."""
    degrees = compute_degrees(entries, edges)
    core = world_core_uids(entries)
    index = world_index_uids(entries)
    tiers: dict[str, str] = {}
    for entry in entries:
        uid = entry_uid(entry, strict=False)
        if not uid:
            continue
        key = str(uid)
        if key in index:
            tiers[key] = "world_index"
        elif key in core:
            tiers[key] = "world_core"
        elif degrees["in_degree"].get(key, 0) >= hub_in_degree_threshold:
            tiers[key] = "hub"
        elif degrees["out_degree"].get(key, 0) == 0:
            tiers[key] = "leaf"
        else:
            tiers[key] = "ordinary"
    return tiers


def _order_type(entry: dict[str, Any]) -> str:
    """Semantic type for order banding: manifest layer, then manifest type,
    then an existing PREFIX: label, then CONCEPT."""
    arch = entry.get("architecture") if isinstance(entry.get("architecture"), dict) else {}
    layer = str(arch.get("layer") or "").strip().casefold().replace("-", "_").replace(" ", "_")
    if layer in _ORDER_TYPE_BY_LAYER:
        return _ORDER_TYPE_BY_LAYER[layer]
    etype = str(entry.get("type") or entry.get("entry_type") or "").strip().casefold().replace("-", "_").replace(" ", "_")
    if etype in _ORDER_TYPE_BY_ENTRY_TYPE:
        return _ORDER_TYPE_BY_ENTRY_TYPE[etype]
    label = str(entry.get("comment") or entry.get("name") or "")
    match = _ORDER_LABEL_RE.match(label.strip())
    if match:
        return match.group(1).upper()
    return "CONCEPT"


def _order_rank_key(uid: str) -> tuple[int, str]:
    return (int(uid), "") if uid.lstrip("-").isdigit() else (1 << 30, uid)


def _is_root_entry(entry: dict[str, Any]) -> bool:
    label = str(entry.get("comment") or entry.get("name") or "")
    if label.rstrip().endswith("(Root)"):
        return True
    if bool(entry.get("constant")):
        return True
    emit = entry.get("emit") if isinstance(entry.get("emit"), dict) else {}
    return bool(emit.get("constant"))


def assign_type_aware_orders(
    entries: list[dict[str, Any]],
    edges: list[tuple[str, str]],
    *,
    hub_in_degree_threshold: int = DEFAULT_HUB_IN_DEGREE_THRESHOLD,
) -> dict[str, Any]:
    """Deterministic type-aware order assignment (Batch 49): every entry of
    the same semantic type shares one contiguous band (ranked root-first,
    then connectivity tier, then uid), so same-type entries land together in
    SillyTavern's order-descending priority view."""
    tiers = classify_connectivity_tiers(entries, edges, hub_in_degree_threshold=hub_in_degree_threshold)
    tier_rank = {"world_index": 0, "world_core": 0, "hub": 1, "ordinary": 2, "leaf": 3}
    groups: dict[str, list[tuple[tuple[int, int, tuple[int, str]], str, int]]] = {}
    for entry in entries:
        uid = entry_uid(entry, strict=False)
        if not uid:
            continue
        key = str(uid)
        band_type = _order_type(entry)
        band = TYPE_ORDER_BANDS.get(band_type, TYPE_ORDER_BANDS["CONCEPT"])
        rank_key = (
            (0 if _is_root_entry(entry) else 1),
            tier_rank.get(tiers.get(key, "ordinary"), 2),
            _order_rank_key(key),
        )
        groups.setdefault(band_type, []).append((rank_key, key, band))
    orders: dict[str, int] = {}
    counts: dict[str, int] = {}
    for band_type, rows in groups.items():
        rows.sort(key=lambda row: row[0])
        for index, (_rank, uid_key, band) in enumerate(rows):
            # rank ascending (root first, then tier, then uid) => order
            # descending within the band, so the priority view shows the
            # band's own head first while the band stays contiguous.
            orders[uid_key] = band + (TYPE_ORDER_BAND_SPAN - 1 - min(index, TYPE_ORDER_BAND_SPAN - 1))
        counts[band_type] = len(rows)
    return {
        "orders": orders,
        "type_counts": counts,
        "bands": dict(TYPE_ORDER_BANDS),
        "span": TYPE_ORDER_BAND_SPAN,
        "rule": "same semantic type shares one contiguous order neighborhood; rank is root-first, then connectivity tier, then uid",
    }


def assign_connectivity_order_weight(
    entries: list[dict[str, Any]],
    edges: list[tuple[str, str]],
    *,
    hub_in_degree_threshold: int = DEFAULT_HUB_IN_DEGREE_THRESHOLD,
) -> dict[str, Any]:
    """Advisory tier assignment: per-uid tier, weight, and insertion order
    without mutating anything. Higher weight wins the real post-sort budget
    slice, so the structural spine survives truncation ahead of flavor."""
    tiers = classify_connectivity_tiers(entries, edges, hub_in_degree_threshold=hub_in_degree_threshold)
    degrees = compute_degrees(entries, edges)
    type_orders = assign_type_aware_orders(entries, edges, hub_in_degree_threshold=hub_in_degree_threshold)
    assignments: dict[str, dict[str, Any]] = {}
    tier_counts: dict[str, int] = {}
    for entry in entries:
        uid = entry_uid(entry, strict=False)
        if not uid:
            continue
        key = str(uid)
        tier = tiers.get(key, "ordinary")
        spec = CONNECTIVITY_TIER_SPEC[tier]
        assignments[key] = {
            "tier": tier,
            "weight": spec["weight"],
            "order": type_orders["orders"].get(key, spec["order"]),
            "order_type": _order_type(entry),
            "in_degree": degrees["in_degree"].get(key, 0),
            "out_degree": degrees["out_degree"].get(key, 0),
        }
        tier_counts[tier] = tier_counts.get(tier, 0) + 1
    return {
        "assignments": assignments,
        "tier_counts": tier_counts,
        "type_counts": type_orders["type_counts"],
        "rule": "connectivity tiers set default weight floors; type-aware order bands keep same-type entries contiguous; explicit or protected values are never overridden",
    }


def apply_connectivity_tier_defaults_in_place(
    entries: list[dict[str, Any]],
    edges: list[tuple[str, str]],
    *,
    hub_in_degree_threshold: int = DEFAULT_HUB_IN_DEGREE_THRESHOLD,
    reassign_orders: bool = False,
) -> dict[str, Any]:
    """Stamp tiered weight/insertion_order onto entries whose current value
    is missing or the standard default (100). Explicit author-set values and
    protected weights are preserved: the floor, not an override. With
    reassign_orders=True, insertion orders are recomputed to the type-aware
    bands even when previously set (repair mode for an existing scatter)."""
    plan = assign_connectivity_order_weight(entries, edges, hub_in_degree_threshold=hub_in_degree_threshold)
    assigned: dict[str, dict[str, Any]] = {}
    preserved: list[dict[str, Any]] = []
    reassigned: list[dict[str, Any]] = []
    for entry in entries:
        uid = entry_uid(entry, strict=False)
        if not uid:
            continue
        key = str(uid)
        assignment = plan["assignments"].get(key)
        if assignment is None:
            continue
        # A final, delivered card stores weight/order directly at the top
        # level ("order", "weight"): confirmed against a real, real-world
        # SillyTavern export, which has no "emit" wrapper at all. "emit" is
        # a manifest-stage-only convention (confirmed against
        # activation_semantics.py's own manifest_entries()/emit_config()).
        # Using "emit" unconditionally silently wrote a new, extraneous
        # field onto real cards without ever touching the real "order"/
        # "weight" fields SillyTavern itself reads; the fix reports would
        # claim success while the real card stayed unchanged.
        is_final_card = "emit" not in entry and ("order" in entry or "weight" in entry)
        if is_final_card:
            target = entry
            order_field, weight_field = "order", "weight"
        else:
            emit = entry.get("emit")
            if not isinstance(emit, dict):
                emit = {}
                entry["emit"] = emit
            target = emit
            order_field, weight_field = "insertion_order", "weight"
        existing_weight = target.get(weight_field)
        existing_order = target.get(order_field, target.get("order") if order_field != "order" else None)
        applied: dict[str, int] = {}
        if existing_weight is None or existing_weight == 100:
            target[weight_field] = assignment["weight"]
            applied[weight_field] = assignment["weight"]
        else:
            preserved.append({"uid": key, "field": weight_field, "value": existing_weight, "tier": assignment["tier"]})
        if existing_order is None or existing_order == 100 or reassign_orders:
            if reassign_orders and existing_order is not None and existing_order != 100 and existing_order != assignment["order"]:
                reassigned.append({"uid": key, "previous_order": existing_order, "order": assignment["order"], "order_type": assignment.get("order_type")})
            target[order_field] = assignment["order"]
            applied[order_field] = assignment["order"]
        else:
            preserved.append({"uid": key, "field": order_field, "value": existing_order, "tier": assignment["tier"]})
        if applied:
            row = dict(assignment)
            row["applied"] = applied
            assigned[key] = row
    return {
        "kind": "worldbuilder-connectivity-tiering-application",
        "report_version": 1,
        "assigned": assigned,
        "preserved_explicit": preserved,
        "reassigned_explicit_orders": reassigned,
        "tier_counts": plan["tier_counts"],
        "type_counts": plan.get("type_counts", {}),
        "rule": plan["rule"],
    }


def find_orphans(entries: list[dict[str, Any]], edges: list[tuple[str, str]]) -> list[dict[str, Any]]:
    """Non-constant entries with no content-derived incoming recursion edge."""
    targets_reached = {target for _, target in edges}
    out: list[dict[str, Any]] = []
    for entry in entries:
        uid = entry_uid(entry, strict=False)
        if not uid or bool(entry.get("constant")) or uid in targets_reached:
            continue
        out.append({
            "uid": uid,
            "name": entry.get("comment") or entry.get("name"),
            "reason": "no entry in the book's real content references this entry's own keys",
        })
    return out


def find_dead_ends(entries: list[dict[str, Any]], edges: list[tuple[str, str]]) -> list[dict[str, Any]]:
    """Reached entries whose own content has no outgoing content-derived edge."""
    sources = {source for source, _ in edges}
    targets = {target for _, target in edges}
    out: list[dict[str, Any]] = []
    for entry in entries:
        uid = entry_uid(entry, strict=False)
        if uid and uid in targets and uid not in sources:
            out.append({
                "uid": uid,
                "name": entry.get("comment") or entry.get("name"),
                "reason": "reached by other entries' content, but its own content routes to nothing further",
            })
    return out


def _era_branch_pairs(entries: list[dict[str, Any]]) -> set[frozenset[str]]:
    """Sanctioned ``era_branch_of`` pairs whose mutual co-firing is designed
    behavior, not drift: an era-branch shares its character's primary key and
    activates in the same pass at any recursion depth, so the pair's own
    two-node cycle is expected and excluded before cycle reporting."""
    pairs: set[frozenset[str]] = set()
    for entry in entries:
        uid = entry_uid(entry, strict=False)
        target = entry.get("era_branch_of")
        if not uid or target is None:
            continue
        target_uid = str(target).strip()
        if target_uid and target_uid != uid:
            pairs.add(frozenset((uid, target_uid)))
    return pairs


def find_circular_chains(entries: list[dict[str, Any]], edges: list[tuple[str, str]]) -> list[list[str]]:
    """Return strongly-connected components of size >1 using Tarjan's algorithm.

    Sanctioned era-branch pairs (an entry carrying ``era_branch_of`` and the
    character it belongs to) are expected mutual co-firing, so their own
    two-node cycle is excluded before reporting; a genuinely unplanned cycle
    elsewhere still reports.
    """
    sanctioned = _era_branch_pairs(entries)
    adjacency: dict[str, list[str]] = {}
    for source, target in edges:
        if frozenset((source, target)) in sanctioned:
            continue
        adjacency.setdefault(source, []).append(target)
    all_uids = [uid for entry in entries if (uid := entry_uid(entry, strict=False))]
    counter = [0]
    stack: list[str] = []
    lowlink: dict[str, int] = {}
    index: dict[str, int] = {}
    on_stack: set[str] = set()
    result: list[list[str]] = []

    def strongconnect(node: str) -> None:
        index[node] = counter[0]
        lowlink[node] = counter[0]
        counter[0] += 1
        stack.append(node)
        on_stack.add(node)
        for neighbor in adjacency.get(node, []):
            if neighbor not in index:
                strongconnect(neighbor)
                lowlink[node] = min(lowlink[node], lowlink[neighbor])
            elif neighbor in on_stack:
                lowlink[node] = min(lowlink[node], index[neighbor])
        if lowlink[node] == index[node]:
            component: list[str] = []
            while True:
                value = stack.pop()
                on_stack.remove(value)
                component.append(value)
                if value == node:
                    break
            if len(component) > 1:
                result.append(sorted(component))

    for uid in all_uids:
        if uid not in index:
            strongconnect(uid)
    return sorted(result, key=lambda row: (len(row), row))


def recommend_vectorization_candidates(
    entries: list[dict[str, Any]],
    edges: list[tuple[str, str]],
    keyword_hostile_uids: list[str] | set[str] | tuple[str, ...],
) -> dict[str, Any]:
    """Compose the Batch-40 candidate filter without pretending keyword hostility is mechanical.

    ``keyword_hostile_uids`` is deliberately supplied by an auditor/planner judgment
    pass. This function only combines that judgment with deterministic graph facts:
    orphan AND keyword-hostile is a candidate; orphan-but-keyword-friendly is not.
    Cycle membership is a secondary scrutiny flag, never a standalone reason to
    vectorize an entry.
    """
    hostile = {str(uid) for uid in keyword_hostile_uids}
    orphans = find_orphans(entries, edges)
    cycles = find_circular_chains(entries, edges)
    cycle_members = {uid for component in cycles for uid in component}
    candidates: list[dict[str, Any]] = []
    excluded_keyword_friendly: list[dict[str, Any]] = []
    for row in orphans:
        item = dict(row)
        uid = str(item["uid"])
        item["keyword_hostile"] = uid in hostile
        item["in_circular_chain"] = uid in cycle_members
        if uid in hostile:
            item["recommendation"] = "review_for_vectorization"
            candidates.append(item)
        else:
            item["recommendation"] = "keep_keyword_first"
            excluded_keyword_friendly.append(item)
    return {
        "candidates": candidates,
        "excluded_keyword_friendly_orphans": excluded_keyword_friendly,
        "rule": "orphan AND keyword-hostile; cycle membership is secondary scrutiny only",
    }


def diff_against_declared(
    entries: list[dict[str, Any]],
    ground_truth_edges: list[tuple[str, str]],
    declared_edges: list[tuple[str, str]],
) -> dict[str, Any]:
    """Compare content-derived edges with the manifest's declared edge pairs."""
    gt_set = set(ground_truth_edges)
    declared_set = set(declared_edges)
    return {
        "undeclared_edges": sorted(gt_set - declared_set),
        "declared_but_absent_in_content": sorted(declared_set - gt_set),
        "ground_truth_edge_count": len(gt_set),
        "declared_edge_count": len(declared_set),
    }


def declared_edges_from_manifest(manifest: Any) -> list[tuple[str, str]]:
    graph = manifest.get("activation_graph") if isinstance(manifest, dict) else None
    rows = graph.get("edges") if isinstance(graph, dict) else None
    if not isinstance(rows, list):
        return []
    out: set[tuple[str, str]] = set()
    for row in rows:
        if not isinstance(row, dict):
            continue
        source, target = row.get("source_uid"), row.get("target_uid")
        if source is not None and target is not None:
            out.add((str(source), str(target)))
    return sorted(out)


def analyze(data: Any, manifest: Any | None = None) -> dict[str, Any]:
    refs = list(iter_entries(data))
    entries = [ref.entry for ref in refs]
    paths: dict[str, str] = {}
    names: dict[str, str] = {}
    for ref in refs:
        identity = canonical_entry_identity(ref.entry)
        if identity is None:
            continue
        uid = str(identity)
        paths[uid] = ref.path
        names[uid] = str(ref.entry.get("comment") or ref.entry.get("name") or ref.entry.get("title") or uid)

    edges = build_ground_truth_edges(entries)
    orphans = find_orphans(entries, edges)
    dead_ends = find_dead_ends(entries, edges)
    for row in orphans + dead_ends:
        row["path"] = paths.get(str(row["uid"]))
        if not row.get("name"):
            row["name"] = names.get(str(row["uid"]))
    declared = declared_edges_from_manifest(manifest)
    divergence = diff_against_declared(entries, edges, declared) if manifest is not None else None
    cycles = find_circular_chains(entries, edges)
    degrees = compute_degrees(entries, edges)
    tiers = classify_connectivity_tiers(entries, edges)
    tier_counts: dict[str, int] = {}
    for tier in tiers.values():
        tier_counts[tier] = tier_counts.get(tier, 0) + 1
    return {
        "kind": REPORT_KIND,
        "report_version": REPORT_VERSION,
        "applicable": bool(entries),
        "entry_count": len(entries),
        "ground_truth_edge_count": len(edges),
        "edges": [list(edge) for edge in edges],
        "in_degree": degrees["in_degree"],
        "out_degree": degrees["out_degree"],
        "connectivity_tiers": tiers,
        "connectivity_tier_counts": tier_counts,
        "orphan_count": len(orphans),
        "orphans": orphans,
        "dead_end_count": len(dead_ends),
        "dead_ends": dead_ends,
        "circular_chain_count": len(cycles),
        "circular_chains": cycles,
        "declared_graph_available": manifest is not None,
        "declared_diff": divergence,
        "advisory_only": True,
        "auto_fix": False,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True, help="Generated card/lorebook JSON to scan")
    parser.add_argument("--manifest", help="Optional manifest JSON whose declared graph should be diffed")
    parser.add_argument("--output", help="Optional JSON report path")
    args = parser.parse_args()
    try:
        data = load_json(Path(args.input))
        manifest = load_json(Path(args.manifest)) if args.manifest else None
        report = analyze(data, manifest)
        rendered = json.dumps(report, ensure_ascii=False, indent=2) + "\n"
        if args.output:
            Path(args.output).write_text(rendered, encoding="utf-8")
        sys.stdout.write(rendered)
        return 0
    except (OSError, json.JSONDecodeError, ValueError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
