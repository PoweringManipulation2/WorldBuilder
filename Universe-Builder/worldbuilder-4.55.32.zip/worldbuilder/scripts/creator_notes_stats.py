#!/usr/bin/env python3
"""Generate, upsert, and verify the Creator Notes lorebook stats block.

The block is the human-facing summary DR-004 requires for lorebook-bearing
cards: entry statistics computed from the artifact itself plus recommended
context settings. It is delimited by stable markers so regeneration is
idempotent, and ``verify_notes_block`` lets ``architecture_gate`` fail closed
when the block is missing or stale instead of trusting prose.
"""
from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path
from typing import Any

from wb_common import WorldBuilderError, load_json, step_driver_pointer
import budget_contract

BLOCK_BEGIN = "── Lorebook Stats & Recommended Settings (WorldBuilder) ──"
BLOCK_END = "── End Lorebook Stats ──"
CONTRACT = "worldbuilder-creator-notes-stats-v1"

# Ships in every artifact a user opens, so a placeholder here becomes a placeholder
# in every card. `verify_notes_block` refuses to pass a block containing one.
PROJECT_URL = "https://github.com/PoweringManipulation2/WorldBuilder"
PLACEHOLDER_MARKERS = ("REPLACE-ME", "REPLACE_ME", "example.com", "TODO", "<url>")
INITIAL_VERSION = "1.0.0"

# Version scheme, mapped to the operations that produce each change.
VERSION_SCHEME = (
    ("MAJOR", "architecture, format, or era-routing change; entries removed"),
    ("MINOR", "content added: new entries or a new era (Update/Merge)"),
    ("PATCH", "corrections and repairs (Audit patches, keyword or prose fixes)"),
)


def bump_version(current: str, level: str) -> str:
    """Increment a semver-shaped lorebook version.

    Tolerant of a missing or malformed prior value: an artifact that was never
    versioned starts at the initial version rather than failing a release.
    """
    parts = str(current or "").strip().split(".")
    try:
        major, minor, patch = (int(parts[i]) for i in range(3))
    except (ValueError, IndexError):
        return INITIAL_VERSION
    if level == "major":
        return f"{major + 1}.0.0"
    if level == "minor":
        return f"{major}.{minor + 1}.0"
    if level == "patch":
        return f"{major}.{minor}.{patch + 1}"
    raise WorldBuilderError(f"unknown version bump level {level!r}")


def collect_era_stats(entries: list[dict[str, Any]]) -> dict[str, Any]:
    """Derive era structure from the artifact itself.

    An era root is the one shape that is unambiguous without the plan: a constant
    entry carrying an absence roster. Deriving rather than requiring the plan means
    the block still renders for an imported or hand-edited book.
    """
    roots: list[dict[str, Any]] = []
    for entry in entries:
        if entry.get("constant") is not True:
            continue
        if "ABSENT THIS ERA:" not in str(entry.get("content", "")):
            continue
        label = str(entry.get("comment") or entry.get("name") or "Era").strip()
        enabled = entry.get("disable") is not True and entry.get("enabled") is not False
        roots.append({"label": label, "enabled": enabled})

    levels = []
    for entry in entries:
        ext = entry.get("extensions") if isinstance(entry.get("extensions"), dict) else {}
        for key in ("recursion_level", "recursionLevel"):
            value = ext.get(key, entry.get(key))
            if isinstance(value, int) and not isinstance(value, bool):
                levels.append(value)
    return {
        "era_count": len(roots),
        "eras": roots,
        "enabled_eras": [r["label"] for r in roots if r["enabled"]],
        "max_recursion_steps": (max(levels) + 1) if levels else None,
    }


def estimate_tokens(value: Any) -> int:
    """DR-043-consistent fallback estimator: ceil(utf-8 bytes / 4)."""
    if not isinstance(value, str) or not value:
        return 0
    return math.ceil(len(value.encode("utf-8")) / 4)


def _entries_from_artifact(data: dict[str, Any]) -> tuple[list[dict[str, Any]], str]:
    """Return (entries, container_kind) for card, lorebook_v3, or native input."""
    if data.get("spec") in {"chara_card_v2", "chara_card_v3"} and isinstance(data.get("data"), dict):
        book = data["data"].get("character_book")
        if not isinstance(book, dict) or not isinstance(book.get("entries"), list):
            return [], "card_without_book"
        return [e for e in book["entries"] if isinstance(e, dict)], "card"
    if data.get("spec") == "lorebook_v3" and isinstance(data.get("data"), dict):
        entries = data["data"].get("entries")
        return ([e for e in entries if isinstance(e, dict)] if isinstance(entries, list) else []), "lorebook_v3"
    if isinstance(data.get("entries"), dict):
        return [e for e in data["entries"].values() if isinstance(e, dict)], "native_world_info"
    return [], "unknown"


def _is_vectorized(entry: dict[str, Any]) -> bool:
    ext = entry.get("extensions") if isinstance(entry.get("extensions"), dict) else {}
    return bool(ext.get("vectorized") or entry.get("vectorized"))


def _keys(entry: dict[str, Any]) -> list[str]:
    keys = entry.get("keys", entry.get("key"))
    return [k for k in keys if isinstance(k, str) and k.strip()] if isinstance(keys, list) else []


def _secondary(entry: dict[str, Any]) -> list[str]:
    keys = entry.get("secondary_keys", entry.get("keysecondary"))
    return [k for k in keys if isinstance(k, str) and k.strip()] if isinstance(keys, list) else []


def collect_stats(entries: list[dict[str, Any]]) -> dict[str, Any]:
    stats: dict[str, Any] = {
        "entry_count": len(entries), "enabled_count": 0, "constant_count": 0,
        "vectorized_count": 0, "keyword_count": 0, "selective_count": 0,
        "recursion_flagged_count": 0, "timed_effect_count": 0,
        "constant_tokens": 0, "total_tokens": 0,
        "largest_entry_tokens": 0, "largest_entry_label": "",
    }
    for entry in entries:
        enabled = entry.get("enabled", not entry.get("disable", False))
        if enabled:
            stats["enabled_count"] += 1
        tokens = estimate_tokens(entry.get("content", ""))
        stats["total_tokens"] += tokens
        label = str(entry.get("comment") or entry.get("name") or entry.get("uid") or entry.get("id") or "")
        if tokens > stats["largest_entry_tokens"]:
            stats["largest_entry_tokens"], stats["largest_entry_label"] = tokens, label
        constant = bool(entry.get("constant"))
        if constant:
            stats["constant_count"] += 1
            if enabled:
                stats["constant_tokens"] += tokens
        if _is_vectorized(entry):
            stats["vectorized_count"] += 1
        if _keys(entry) and not constant:
            stats["keyword_count"] += 1
        if entry.get("selective") and _secondary(entry):
            stats["selective_count"] += 1
        ext = entry.get("extensions") if isinstance(entry.get("extensions"), dict) else {}
        if any(ext.get(k) or entry.get(k) for k in ("exclude_recursion", "prevent_recursion", "delay_until_recursion", "excludeRecursion", "preventRecursion", "delayUntilRecursion")):
            stats["recursion_flagged_count"] += 1
        if any((ext.get(k) or entry.get(k)) for k in ("sticky", "cooldown", "delay")):
            stats["timed_effect_count"] += 1
    stats["average_entry_tokens"] = round(stats["total_tokens"] / len(entries)) if entries else 0
    return stats


def _drop_order_lines(budget_receipt: dict[str, Any] | None, placement_receipt: dict[str, Any] | None) -> tuple[list[str], int | None]:
    """5.5: derive the recommended token_budget from the measured worst case
    and predict, before generation, exactly what a lower runtime setting
    would drop, and whether any of it is protected. Returns (lines,
    recommended_token_budget); recommended_token_budget is None when either
    receipt is missing or predates the fields this needs (weight did not
    exist on placement entries before Batch 5's 5.5 fix), so callers can
    fall back to the older heuristic rather than silently show nothing.
    """
    if not isinstance(budget_receipt, dict) or not isinstance(placement_receipt, dict):
        return [], None
    sims = budget_receipt.get("simulations")
    budget_entries = budget_receipt.get("entries")
    placement_entries = placement_receipt.get("entries")
    if not isinstance(sims, list) or not isinstance(budget_entries, list) or not isinstance(placement_entries, list):
        return [], None
    worst = next((s for s in sims if isinstance(s, dict) and s.get("name") == "worst_case_recursion_path"), None)
    if not isinstance(worst, dict) or not isinstance(worst.get("activated_uids"), list):
        return [], None

    activated = {str(uid) for uid in worst["activated_uids"]}
    tokens_by_uid = {str(e.get("uid")): e.get("estimated_tokens", 0) for e in budget_entries if isinstance(e, dict)}
    placement_by_uid = {str(e.get("uid")): e for e in placement_entries if isinstance(e, dict)}

    combined = []
    for uid in activated:
        placement_row = placement_by_uid.get(uid)
        if placement_row is None or uid not in tokens_by_uid or placement_row.get("weight") is None:
            # Cannot predict without both halves of the data (an older placement
            # receipt predating the weight field, or a UID absent from one side);
            # skip that entry rather than guess a value for it.
            continue
        combined.append({
            "uid": uid, "tokens": tokens_by_uid[uid],
            "weight": placement_row.get("weight"), "insertion_order": placement_row.get("insertion_order"),
            "constant": bool(placement_row.get("constant", False)),
            "protected_categories": list(placement_row.get("protected_categories") or []),
        })
    if not combined:
        return [], None

    try:
        result = budget_contract.recommend_token_budget(combined, int(worst.get("hard_limit", 0)))
    except WorldBuilderError:
        return [], None
    prediction = result["prediction"]
    recommended = result["recommended_token_budget"]

    if prediction["any_protected_dropped"]:
        lines = [
            f"WARNING: at the recommended {recommended}-token setting, "
            f"{len(prediction['protected_uids_dropped'])} protected entries would drop before the runtime budget "
            "is exhausted; this must be fixed before shipping, not just noted.",
        ]
    else:
        lines = [
            f"Predicted at {recommended} tokens: {len(prediction['kept_uids'])} of "
            f"{len(prediction['kept_uids']) + prediction['dropped_count']} worst-case entries kept; "
            "no protected entry is ever in the dropped set.",
        ]
    if prediction["dropped"]:
        preview = ", ".join(row["name"] or row["uid"] for row in prediction["dropped"][:5])
        more = f" (+{prediction['dropped_count'] - 5} more)" if prediction["dropped_count"] > 5 else ""
        lines.append(f"  First to drop if the runtime setting is lower than recommended: {preview}{more}")
    return lines, recommended


def _budget_lines(budget_receipt: dict[str, Any] | None) -> list[str]:
    if not isinstance(budget_receipt, dict):
        return []
    sims = budget_receipt.get("simulations")
    if not isinstance(sims, list) or not sims:
        return []
    valid = [s for s in sims if isinstance(s, dict) and isinstance(s.get("estimated_tokens"), int)]
    if not valid:
        return []
    worst = max(valid, key=lambda s: s["estimated_tokens"])
    pressures = {str(s.get("pressure")) for s in valid}
    lines = [
        f"Budget simulations ({len(valid)}): worst activation ≈ {worst['estimated_tokens']} tokens ('{worst.get('name')}').",
    ]
    if pressures <= {"ok"}:
        lines.append(f"All simulations pass at the planned target of {worst.get('target')} lorebook tokens.")
    else:
        lines.append("Some simulations report warning/blocked pressure; see the budget receipt before raising entry sizes.")
    return lines


def render_block(
    stats: dict[str, Any],
    budget_receipt: dict[str, Any] | None = None,
    *,
    placement_receipt: dict[str, Any] | None = None,
    era_stats: dict[str, Any] | None = None,
    version: str | None = None,
    artifact_kind: str | None = None,
    deferred: list[str] | None = None,
) -> str:
    era_stats = era_stats or {}
    lines = [
        BLOCK_BEGIN,
        f"Built with WorldBuilder: {PROJECT_URL}",
        f"Lorebook version: {version or INITIAL_VERSION}",
    ]
    lines += [f"  {level}  {meaning}" for level, meaning in VERSION_SCHEME]
    lines.append("")

    lines.append(
        f"Entries: {stats['entry_count']} total ({stats['enabled_count']} enabled): "
        f"{stats['constant_count']} constant, {stats['keyword_count']} keyword-triggered, "
        f"{stats['vectorized_count']} vectorized, {stats['selective_count']} with secondary-key logic."
    )

    if era_stats.get("era_count"):
        labels = ", ".join(e["label"] for e in era_stats["eras"])
        enabled = era_stats.get("enabled_eras") or []
        lines.append(f"Eras: {era_stats['era_count']} ({labels})")
        if len(enabled) == 1:
            lines.append(f"  Currently enabled: {enabled[0]}")
        elif not enabled:
            # Shipping with no era enabled yields the thinnest possible book and no
            # error, so it is called out rather than left for the user to discover.
            lines.append("  WARNING: no era root is enabled. Enable exactly one before playing.")
        else:
            lines.append(f"  WARNING: {len(enabled)} era roots are enabled at once ({', '.join(enabled)}). Enable exactly one.")
        lines.append("  Switch era by enabling one Era root entry and disabling the rest.")

    lines.append(
        f"Estimated size (ceil(bytes/4)): {stats['total_tokens']} tokens total; "
        f"constant footprint {stats['constant_tokens']} tokens; average entry {stats['average_entry_tokens']} tokens; "
        f"largest entry {stats['largest_entry_tokens']} tokens ({stats['largest_entry_label']})."
    )
    lines += _budget_lines(budget_receipt)
    drop_order_lines, recommended_budget = _drop_order_lines(budget_receipt, placement_receipt)

    lines.append("")
    lines.append("Recommended SillyTavern settings")
    if recommended_budget is not None:
        lines.append(
            f"  Free lorebook budget ....... {recommended_budget} tokens "
            "(measured worst-case activation for this build, not an estimate)"
        )
        lines += [f"  {line}" if not line.startswith("  ") else line for line in drop_order_lines]
    else:
        lines.append(
            f"  Free lorebook budget ....... {stats['constant_tokens'] + stats['largest_entry_tokens']}+ tokens "
            "(constant footprint plus the largest single entry, so every entry can activate)"
        )
    steps = era_stats.get("max_recursion_steps")
    if era_stats.get("era_count") or stats["recursion_flagged_count"] or steps:
        lines.append("  Recursive Scan ............. ON  (required; entries activate through recursion)")
    if steps:
        lines.append(f"  Max Recursion Steps ........ {steps} or more  (cascade depth in this book)")
        lines.append("  Min Activations ............ 0   (mutually exclusive with Max Recursion Steps)")
    if stats["vectorized_count"]:
        lines.append(
            f"  Vector Storage ............. ON  ({stats['vectorized_count']} vectorized entries; "
            "in SillyTavern 1.18.0 these keep keyword matching when they have keys)"
        )
    if stats["timed_effect_count"]:
        lines.append(f"  Timed effects .............. {stats['timed_effect_count']} entries use sticky/cooldown/delay")

    if era_stats.get("era_count"):
        lines.append("")
        lines.append(
            "  Without Recursive Scan you get the era frame only; correct, but far thinner "
            "than intended. Book-level scan_depth/token_budget/recursive_scanning are portable "
            "metadata; SillyTavern 1.18.0 uses your global World Info settings."
        )

    if artifact_kind:
        lines.append("")
        lines.append("Format and compatibility")
        lines.append(f"  {_compatibility_line(artifact_kind)}")
        if era_stats.get("era_count") and artifact_kind in PORTABLE_KINDS:
            # The enforcement layer is SillyTavern-native. A portable export keeps the
            # content and loses the gates, so the era claim must not travel with it.
            lines.append(
                "  Era isolation is NOT enforced in this portable format. The gating fields "
                "(selectiveLogic, delayUntilRecursion, group) are SillyTavern-native and absent "
                "here; convert to a named SillyTavern target for enforced era separation."
            )

    if era_stats.get("era_count"):
        lines.append("")
        lines.append("Check it is working")
        lines.append("  1. Enable exactly one Era root entry; disable the rest.")
        lines.append("  2. Send one message.")
        lines.append("  3. Open the World Info activation log.")
        lines.append(
            "  Expected: the era root plus its context. Root only means Recursive Scan is off "
            "or Max Recursion Steps is too low. Nothing at all means no root is enabled."
        )
    elif stats["recursion_flagged_count"]:
        lines.append("")
        lines.append("Check it is working")
        lines.append(
            "  1. Nothing to switch on: this is a single-era world, so the one constant "
            "root entry is always active."
        )
        lines.append("  2. Send one message.")
        lines.append("  3. Open the World Info activation log.")
        lines.append(
            "  Expected: the world core plus whichever entry the message triggered."
        )

    if deferred:
        lines.append("")
        lines.append("Deliberately not covered")
        lines += [f"  - {item}" for item in deferred]

    lines.append(BLOCK_END)
    return "\n".join(lines)


PORTABLE_KINDS = {"lorebook_v3", "card_without_book", "card"}

_COMPATIBILITY = {
    "lorebook_v3": "Portable lorebook_v3. This is NOT a SillyTavern World Info file and will "
                   "not import as one; SillyTavern expects top-level entries.",
    "native_world_info": "SillyTavern-native World Info. Import directly through World Info.",
    "card": "Character Card V3 with an embedded character_book. Import as a character card.",
    "card_without_book": "Character Card V3, no embedded lorebook.",
}


def _compatibility_line(kind: str) -> str:
    return _COMPATIBILITY.get(kind, f"Artifact kind: {kind}. Verify import before relying on it.")


def upsert_block(notes: str, block: str) -> str:
    notes = notes or ""
    if BLOCK_BEGIN in notes and BLOCK_END in notes:
        head, rest = notes.split(BLOCK_BEGIN, 1)
        _, tail = rest.split(BLOCK_END, 1)
        return f"{head}{block}{tail}"
    if not notes.strip():
        return block
    return f"{notes.rstrip()}\n\n{block}"


def verify_notes_block(payload: dict[str, Any]) -> list[str]:
    """Content check for card ``data`` payloads. Returns a list of problems."""
    book = payload.get("character_book")
    if not isinstance(book, dict) or not isinstance(book.get("entries"), list) or not book["entries"]:
        return []
    notes = payload.get("creator_notes")
    notes = notes if isinstance(notes, str) else ""
    command = f"{sys.executable or 'python'} {Path(__file__).resolve()} --input <final card json> --write"
    if BLOCK_BEGIN not in notes or BLOCK_END not in notes:
        return [f"Creator Notes lack the lorebook stats block. Generate it with: {command}"]
    problems: list[str] = []
    # An unreplaced placeholder ships in every card a user opens, so it blocks release
    # rather than warning. This is the one string in the artifact that advertises the
    # project, and a broken link is worse than no link.
    found = [m for m in PLACEHOLDER_MARKERS if m.casefold() in notes.casefold()]
    if found:
        problems.append(
            f"Creator Notes contain an unreplaced placeholder {found}. Set PROJECT_URL in "
            "creator_notes_stats.py to the published repository before release."
        )
    stats = collect_stats([e for e in book["entries"] if isinstance(e, dict)])
    expected = f"Entries: {stats['entry_count']} total"
    if expected not in notes:
        problems.append(f"Creator Notes stats block is stale (expected '{expected}'). Refresh it with: {command}")
    return problems


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True, help="Final card, lorebook_v3, or native World Info JSON")
    parser.add_argument("--budget-receipt", help="Optional budget receipt JSON to include simulation-based guidance")
    parser.add_argument("--placement-receipt", help="Optional placement receipt JSON; combined with --budget-receipt "
                                                      "to derive the measured (not heuristic) recommended token_budget")
    parser.add_argument("--write", action="store_true", help="Upsert the block into the artifact's notes field in place")
    parser.add_argument("--check", action="store_true", help="Exit non-zero when the block is missing or stale (cards only)")
    parser.add_argument("--version", help="Set the lorebook version explicitly (default: preserve, else 1.0.0)")
    parser.add_argument("--bump", choices=("major", "minor", "patch"),
                        help="Increment the lorebook version. Use after a Tools-mode operation: "
                             "patch for audit fixes, minor for merged content, major for architecture changes.")
    args = parser.parse_args()
    if args.version and args.bump:
        parser.error("--version and --bump are mutually exclusive")
    try:
        path = Path(args.input).resolve()
        data = load_json(path)
        if not isinstance(data, dict):
            raise WorldBuilderError("input is not a JSON object")
        entries, kind = _entries_from_artifact(data)
        if kind in {"card_without_book", "unknown"} or not entries:
            raise WorldBuilderError(f"no lorebook entries found in input ({kind})")
        budget = load_json(Path(args.budget_receipt).resolve()) if args.budget_receipt else None
        placement = load_json(Path(args.placement_receipt).resolve()) if args.placement_receipt else None

        # Version lives in character_version for cards; a standalone lorebook has no
        # equivalent field, so the block itself is the record.
        holder = data.get("data") if isinstance(data.get("data"), dict) else data
        current = str(holder.get("character_version") or "").strip() or None
        if args.version:
            version = args.version
        elif args.bump:
            version = bump_version(current or INITIAL_VERSION, args.bump)
        else:
            version = current or INITIAL_VERSION

        block = render_block(
            collect_stats(entries),
            budget if isinstance(budget, dict) else None,
            placement_receipt=placement if isinstance(placement, dict) else None,
            era_stats=collect_era_stats(entries),
            version=version,
        )
        if args.check:
            if kind != "card":
                raise WorldBuilderError("--check applies to card inputs with data.creator_notes")
            problems = verify_notes_block(data["data"])
            if problems:
                raise WorldBuilderError("; ".join(problems))
            print(json.dumps({"status": "passed", "contract": CONTRACT}, ensure_ascii=False, indent=2))
            return 0
        if args.write:
            if kind == "card":
                payload = data["data"]
                payload["creator_notes"] = upsert_block(str(payload.get("creator_notes") or ""), block)
                payload["character_version"] = version
            elif kind == "lorebook_v3":
                data["data"]["description"] = upsert_block(str(data["data"].get("description") or ""), block)
            else:
                raise WorldBuilderError("--write supports card and lorebook_v3 inputs; native World Info has no standard notes field")
            path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
            print(json.dumps({"status": "written", "contract": CONTRACT, "target": str(path),
                              "container": kind, "version": version}, ensure_ascii=False, indent=2))
            return 0
        print(block)
        return 0
    except (WorldBuilderError, OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"CREATOR NOTES STATS BLOCKED: {exc}", file=sys.stderr)
        print(step_driver_pointer(), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
