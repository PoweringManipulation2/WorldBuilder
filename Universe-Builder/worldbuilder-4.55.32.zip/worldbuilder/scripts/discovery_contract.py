#!/usr/bin/env python3
"""Shared discovery assignment, result, runtime, and exclusion contracts."""
from __future__ import annotations

import argparse
import json
import re
import urllib.parse
from pathlib import Path
from typing import Any

from wb_common import WorldBuilderError, load_build_state, preflight_report, requirement_rows

DISCOVERY_PLAN_VERSION = 5
DISCOVERY_ASSIGNMENT_VERSION = 7
DISCOVERY_RESULT_VERSION = 2
DISCOVERY_RUNTIME_RECEIPT_VERSION = 3
DISCOVERY_GATE_RECEIPT_VERSION = 4
DISCOVERY_RECOVERY_VERSION = 3
WORKER_PROMPT_VERSION = 7
PAGE_FILTER_VERSION = 1
CONTRACT_VERSION = 3


def saturation_accepted(receipt: dict[str, Any]) -> bool:
    """Single DR-083 authority for sanctioned discovery saturation paths.

    A current receipt may prove saturation directly (yield-based) or may carry
    ``effective_saturation_accepted`` for another discovery_gate-sanctioned
    terminal path such as frontier closure. Downstream gates must honor either.
    """
    return receipt.get("saturation_proven") is True or receipt.get("effective_saturation_accepted") is True


ENTITY_TYPES: tuple[str, ...] = (
    "character", "species", "population", "rank", "faction", "organization",
    "location", "event", "era", "concept", "system", "object", "ability",
    "media", "production", "other",
)

EXCLUSION_CODES: dict[str, dict[str, Any]] = {
    "non_content_namespace": {"low_value": True, "approval_required": False},
    "user_discussion": {"low_value": True, "approval_required": False},
    "message_wall": {"low_value": True, "approval_required": False},
    "maintenance_page": {"low_value": True, "approval_required": False},
    "gallery_or_media_only": {"low_value": True, "approval_required": False},
    "duplicate_canonical": {"low_value": True, "approval_required": False},
    "redirect_loop": {"low_value": True, "approval_required": False},
    "broken_redirect": {"low_value": True, "approval_required": False},
    "out_of_scope_language": {"low_value": True, "approval_required": False},
    "unsupported_media": {"low_value": True, "approval_required": False},
    "redirect_alias": {"low_value": True, "approval_required": False},
    "disambiguation_or_index": {"low_value": True, "approval_required": False},
    "index_or_navigation": {"low_value": True, "approval_required": False},
    "reference_only": {"low_value": True, "approval_required": False},
    "production_metadata": {"low_value": True, "approval_required": False},
    "optional_media": {"low_value": True, "approval_required": False},
    "empty_or_blank_page": {"low_value": True, "approval_required": False},
    "empty_page": {"low_value": False, "approval_required": True},
    "robots_or_access_denied": {"low_value": False, "approval_required": True},
    "http_terminal_failure": {"low_value": False, "approval_required": True},
    "manual_scope_exclusion": {"low_value": False, "approval_required": True},
    "facet_filter_mismatch": {"low_value": True, "approval_required": False},
}

def normalize_mediawiki_title(title: str) -> str:
    """MediaWiki canonical title form: spaces become underscores, runs of
    underscores collapse, and the first letter is uppercased (MediaWiki treats
    the first character case-insensitively). Case in the rest of the title is
    preserved because it is significant."""
    text = title.replace(" ", "_")
    text = re.sub(r"_{2,}", "_", text).lstrip("_")
    for index, char in enumerate(text):
        if char.isalpha():
            return text[:index] + char.upper() + text[index + 1:]
        if char in "%/":
            break
    return text


def normalize_path_component(raw_path: str) -> str:
    """Single authority for URL-path canonical form: decode, re-encode with a
    stable safe set, collapse duplicate slashes, and strip the trailing slash.
    Every discovery module MUST use this so %27 and ', 'The_X' and 'the X',
    converge to one form."""
    decoded = urllib.parse.unquote(raw_path or "/")
    if decoded.startswith("/wiki/"):
        decoded = "/wiki/" + normalize_mediawiki_title(decoded[len("/wiki/"):])
    path = urllib.parse.quote(decoded, safe="/%:@!$&'()*+,;=-._~")
    path = re.sub(r"/{2,}", "/", path)
    if path != "/":
        path = path.rstrip("/")
    return path


def canonicalize_url(value: Any) -> str | None:
    if not isinstance(value, str) or not value.strip():
        return None
    parsed = urllib.parse.urlsplit(value.strip())
    if parsed.scheme.lower() not in {"http", "https"} or not parsed.netloc:
        return None
    path = normalize_path_component(parsed.path or "/")
    query = urllib.parse.urlencode(sorted(urllib.parse.parse_qsl(parsed.query, keep_blank_values=True)))
    return urllib.parse.urlunsplit((parsed.scheme.lower(), parsed.netloc.lower(), path, query, ""))

def contract_block(worker_kit_sha256: str | None = None) -> dict[str, Any]:
    value: dict[str, Any] = {
        "contract_version": CONTRACT_VERSION,
        "assignment_schema_version": DISCOVERY_ASSIGNMENT_VERSION,
        "result_schema_version": DISCOVERY_RESULT_VERSION,
        "runtime_receipt_version": DISCOVERY_RUNTIME_RECEIPT_VERSION,
        "worker_prompt_version": WORKER_PROMPT_VERSION,
        "page_filter_version": PAGE_FILTER_VERSION,
        "gate_receipt_version": DISCOVERY_GATE_RECEIPT_VERSION,
    }
    if worker_kit_sha256:
        value["worker_kit_sha256"] = worker_kit_sha256
    return value

def validate_contract(value: Any, *, label: str, worker_kit_sha256: str | None = None) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise WorldBuilderError(f"{label} is missing the discovery contract block")
    expected = contract_block(worker_kit_sha256)
    for key, wanted in expected.items():
        if value.get(key) != wanted:
            raise WorldBuilderError(f"{label}.{key} mismatch: {value.get(key)!r} != {wanted!r}")
    return value

def exclusion_policy(code: Any) -> dict[str, Any]:
    if not isinstance(code, str) or code not in EXCLUSION_CODES:
        raise WorldBuilderError("unknown exclusion code; use one of: " + ", ".join(sorted(EXCLUSION_CODES)))
    return EXCLUSION_CODES[code]


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--build-state", help="Build-state path for the read-only --requirements preflight.")
    parser.add_argument("--requirements", action="store_true", help="Read-only preflight: print what this gate checks against the current build state.")
    args = parser.parse_args()
    if not args.requirements:
        parser.error("this module has no standalone run mode; use --requirements for the read-only preflight")
    if not args.build_state:
        parser.error("--requirements needs --build-state")
    root, state = load_build_state(args.build_state)
    print(json.dumps(preflight_report("discovery_contract", requirement_rows(Path(__file__), root, state)), ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
