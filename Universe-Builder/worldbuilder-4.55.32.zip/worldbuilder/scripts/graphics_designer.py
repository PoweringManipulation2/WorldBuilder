#!/usr/bin/env python3
"""Author and verify WorldBuilder character-scoped Regex, MVU state, and greeting HTML.

Regex is high-impact: empirical verification and explicit person approval are both
required before WorldBuilder bundles it. Tracker authoring emits only the source-
pinned MVU [InitVar] state contract. Greeting HTML is structurally verified and may
ship without a second approval.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import re
import subprocess
import sys
from html.parser import HTMLParser
from pathlib import Path
from typing import Any

from extension_adapter import serialize_to_target
from wb_common import WorldBuilderError, atomic_write_json, load_json

CONTRACT = "worldbuilder-graphics-designer-v1"
REGEX_REPORT_KIND = "worldbuilder-regex-diagnostics"
REGEX_REPORT_VERSION = 1
VOID_TAGS = frozenset({"area","base","br","col","embed","hr","img","input","link","meta","param","source","track","wbr"})


def _sha(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _regex_parts(pattern: str) -> tuple[str, int]:
    text = str(pattern)
    flags = 0
    if len(text) >= 2 and text.startswith("/"):
        escaped = False
        closing = None
        for i in range(len(text) - 1, 0, -1):
            if text[i] != "/":
                continue
            backslashes = 0; j = i - 1
            while j >= 0 and text[j] == "\\":
                backslashes += 1; j -= 1
            if backslashes % 2 == 0:
                closing = i; break
        if closing is not None:
            body, raw_flags = text[1:closing], text[closing + 1:]
            unknown = set(raw_flags) - set("gimsuy")
            if unknown:
                raise WorldBuilderError(f"unsupported Regex flag(s) for verifier: {''.join(sorted(unknown))}")
            if "i" in raw_flags: flags |= re.IGNORECASE
            if "m" in raw_flags: flags |= re.MULTILINE
            if "s" in raw_flags: flags |= re.DOTALL
            return body, flags
    return text, flags


def _replacement_for_python(value: str) -> str:
    value = str(value).replace("$&", r"\g<0>")
    return re.sub(r"\$(\d+)", r"\\g<\1>", value)


def greedy_quantifier_risk(pattern: str) -> bool:
    body, _ = _regex_parts(pattern)
    for m in re.finditer(r"(?<!\\)(?:\.\*|\.\+)(?!\?)", body):
        left, right = body[:m.start()], body[m.end():]
        delimiters = [r"\*", r"\"", "'", '"', r"\)", r"\(", r"\]", r"\["]
        if any(token in left and token in right for token in delimiters):
            return True
    return False


def catastrophic_backtracking_risk(pattern: str) -> bool:
    body, _ = _regex_parts(pattern)
    # Nested quantified groups such as (a+)+ / (.*)* and stacked quantifiers.
    if re.search(r"\((?:\\.|[^()])*[+*](?:\\.|[^()])*\)\s*(?:[+*]|\{\d*,?\d*\})", body):
        return True
    if re.search(r"(?:[+*]|\{\d+,?\d*\})\s*(?:[+*]|\{\d+,?\d*\})", body):
        return True
    return False


def _run_adversarial(pattern: str, replacement: str, value: str, timeout: float) -> dict[str, Any]:
    body, flags = _regex_parts(pattern)
    code = (
        "import re,sys; p=re.compile(sys.argv[1],int(sys.argv[2])); "
        "p.sub(sys.argv[3],sys.argv[4]); print('ok')"
    )
    try:
        cp = subprocess.run(
            [sys.executable, "-c", code, body, str(flags), _replacement_for_python(replacement), value],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=timeout, check=False,
        )
    except subprocess.TimeoutExpired:
        return {"status": "timeout", "bounded": False, "timeout_seconds": timeout}
    return {"status": "passed" if cp.returncode == 0 else "failed", "bounded": cp.returncode == 0,
            "timeout_seconds": timeout, "stderr": cp.stderr[-500:]}


def verify_regex(payload: dict[str, Any], samples: dict[str, Any], *, timeout: float = 1.5) -> dict[str, Any]:
    pattern = payload.get("find_regex")
    if not isinstance(pattern, str) or not pattern:
        raise WorldBuilderError("regex payload requires non-empty find_regex")
    replacement = str(payload.get("replace_string", ""))
    body, flags = _regex_parts(pattern)
    try:
        compiled = re.compile(body, flags)
    except re.error as exc:
        raise WorldBuilderError(f"regex does not compile in the verifier: {exc}") from exc
    matching = samples.get("matching") if isinstance(samples, dict) else None
    nonmatching = samples.get("nonmatching") if isinstance(samples, dict) else None
    adversarial = samples.get("adversarial") if isinstance(samples, dict) else None
    if not isinstance(matching, list) or not matching or not isinstance(nonmatching, list) or not nonmatching or not isinstance(adversarial, str):
        raise WorldBuilderError("regex samples require non-empty matching/nonmatching arrays and one adversarial string")
    py_replacement = _replacement_for_python(replacement)
    match_results = []
    for row in matching:
        if not isinstance(row, dict) or not isinstance(row.get("input"), str) or not isinstance(row.get("expected"), str):
            raise WorldBuilderError("each matching sample must contain string input and expected")
        actual = compiled.sub(py_replacement, row["input"])
        match_results.append({"input": row["input"], "expected": row["expected"], "actual": actual, "passed": actual == row["expected"]})
    nonmatch_results = []
    for value in nonmatching:
        if not isinstance(value, str):
            raise WorldBuilderError("each nonmatching sample must be a string")
        actual = compiled.sub(py_replacement, value)
        nonmatch_results.append({"input": value, "actual": actual, "passed": actual == value})
    adversarial_result = _run_adversarial(pattern, replacement, adversarial, timeout)
    static = {
        "greedy_quantifier_risk": greedy_quantifier_risk(pattern),
        "catastrophic_backtracking_risk": catastrophic_backtracking_risk(pattern),
    }
    passed = all(r["passed"] for r in match_results + nonmatch_results) and adversarial_result["bounded"] and not static["catastrophic_backtracking_risk"]
    return {
        "kind": "worldbuilder-regex-verification", "verification_version": 1, "contract": CONTRACT,
        "status": "passed" if passed else "failed", "pattern": pattern, "pattern_sha256": _sha(pattern),
        "replacement": replacement, "matching": match_results, "nonmatching": nonmatch_results,
        "adversarial": adversarial_result, "static_findings": static,
    }


def _card_data(card: dict[str, Any]) -> dict[str, Any]:
    data = card.get("data") if isinstance(card.get("data"), dict) else card
    if not isinstance(data, dict):
        raise WorldBuilderError("card must be a JSON object")
    return data


def bundle_regex(card: dict[str, Any], payload: dict[str, Any], verification: dict[str, Any], *, approval: str) -> dict[str, Any]:
    if not isinstance(approval, str) or not approval.strip():
        raise WorldBuilderError("WorldBuilder-authored character Regex requires the person's explicit approval before bundling")
    if verification.get("status") != "passed" or verification.get("pattern_sha256") != _sha(str(payload.get("find_regex", ""))):
        raise WorldBuilderError("Regex verification is missing, failed, or bound to different pattern bytes")
    adapter_payload = copy.deepcopy(payload)
    if "name" not in adapter_payload and "script_name" in adapter_payload:
        adapter_payload["name"] = adapter_payload.pop("script_name")
    if "placements" not in adapter_payload and "placement" in adapter_payload:
        adapter_payload["placements"] = adapter_payload.pop("placement")
    envelope = {"contract": "worldbuilder-extension-adapter-v1", "extension": "regex", "payload": adapter_payload}
    serialized = serialize_to_target(envelope, "character_regex_scripts")
    out = copy.deepcopy(card)
    data = _card_data(out)
    extensions = data.get("extensions") if isinstance(data.get("extensions"), dict) else {}
    data["extensions"] = extensions
    scripts = extensions.get("regex_scripts") if isinstance(extensions.get("regex_scripts"), list) else []
    scripts.extend(copy.deepcopy(serialized["regex_scripts"]))
    extensions["regex_scripts"] = scripts
    marker = extensions.get("worldbuilder_graphics_designer") if isinstance(extensions.get("worldbuilder_graphics_designer"), dict) else {"contract": CONTRACT, "regex": [], "html": []}
    marker.setdefault("regex", []).append({
        "script_id": serialized["regex_scripts"][0]["id"], "pattern_sha256": verification["pattern_sha256"],
        "verification": copy.deepcopy(verification), "approved_by_person": approval.strip(), "scope": "character",
    })
    extensions["worldbuilder_graphics_designer"] = marker
    return out


def _mvu_initial_state(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(k): _mvu_initial_state(v) for k, v in value.items()}
    if isinstance(value, list) and 1 <= len(value) <= 2:
        return copy.deepcopy(value)
    return [copy.deepcopy(value)]

def author_tracker(name: str, initial_state: dict[str, Any], *, keys: list[str] | None = None, order: int = 100) -> dict[str, Any]:
    if not isinstance(initial_state, dict) or not initial_state:
        raise WorldBuilderError("tracker state must be a non-empty object")
    normalized_state = _mvu_initial_state(initial_state)
    envelope = {"contract": "worldbuilder-extension-adapter-v1", "extension": "mvu", "payload": {
        "name": name, "initial_state": normalized_state, "enabled": False, "keys": keys or [], "order": order,
    }}
    entry = serialize_to_target(envelope, "world_info_initvar")
    return {"contract": CONTRACT, "kind": "mvu_initvar_state", "entry": entry,
            "rendering_boundary": "Deliberately not supported: WorldBuilder authors tracker state, not a competing custom HTML tracker display. Custom display HTML is a separate manual step."}


class StrictHTMLVerifier(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.stack: list[str] = []
        self.errors: list[str] = []
    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        tag = tag.casefold()
        if tag == "script": self.errors.append("script elements are not allowed in auto-shipped greeting markup")
        if any(str(k).casefold().startswith("on") for k, _ in attrs): self.errors.append("inline event-handler attributes are not allowed")
        if tag not in VOID_TAGS: self.stack.append(tag)
    def handle_startendtag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        self.handle_starttag(tag, attrs)
        if self.stack and self.stack[-1] == tag.casefold(): self.stack.pop()
    def handle_endtag(self, tag: str) -> None:
        tag = tag.casefold()
        if tag in VOID_TAGS: return
        if not self.stack or self.stack[-1] != tag:
            self.errors.append(f"mismatched closing tag </{tag}>")
            return
        self.stack.pop()


def verify_html(markup: str) -> dict[str, Any]:
    parser = StrictHTMLVerifier()
    try:
        parser.feed(str(markup)); parser.close()
    except Exception as exc:
        parser.errors.append(f"HTML parser error: {exc}")
    if parser.stack:
        parser.errors.append("unclosed tags: " + ", ".join(parser.stack))
    return {"kind": "worldbuilder-greeting-html-verification", "verification_version": 1, "contract": CONTRACT,
            "status": "passed" if not parser.errors else "failed", "markup_sha256": _sha(str(markup)), "errors": parser.errors}


def bundle_html(card: dict[str, Any], markup: str, verification: dict[str, Any]) -> dict[str, Any]:
    if verification.get("status") != "passed" or verification.get("markup_sha256") != _sha(markup):
        raise WorldBuilderError("greeting HTML verification is missing, failed, or bound to different markup bytes")
    out = copy.deepcopy(card); data = _card_data(out); data["first_mes"] = markup
    ext = data.get("extensions") if isinstance(data.get("extensions"), dict) else {}; data["extensions"] = ext
    marker = ext.get("worldbuilder_graphics_designer") if isinstance(ext.get("worldbuilder_graphics_designer"), dict) else {"contract": CONTRACT, "regex": [], "html": []}
    marker.setdefault("html", []).append({"markup_sha256": verification["markup_sha256"], "verification": copy.deepcopy(verification), "separate_approval_required": False})
    ext["worldbuilder_graphics_designer"] = marker
    return out


def analyze_artifact_regex(card: dict[str, Any]) -> dict[str, Any]:
    data = _card_data(card); ext = data.get("extensions") if isinstance(data.get("extensions"), dict) else {}
    scripts = ext.get("regex_scripts") if isinstance(ext.get("regex_scripts"), list) else []
    marker = ext.get("worldbuilder_graphics_designer") if isinstance(ext.get("worldbuilder_graphics_designer"), dict) else {}
    authored = marker.get("regex") if isinstance(marker.get("regex"), list) else []
    by_id = {str(row.get("script_id")): row for row in authored if isinstance(row, dict) and row.get("script_id") is not None}
    findings: list[dict[str, Any]] = []
    for idx, script in enumerate(scripts):
        if not isinstance(script, dict): continue
        script_id = str(script.get("id"))
        if script_id not in by_id: continue  # imported/third-party regex is outside this authoring receipt contract
        pattern = str(script.get("findRegex", "")); meta = by_id[script_id]
        if greedy_quantifier_risk(pattern): findings.append({"category":"regex_greedy_quantifier_risk","script_id":script_id,"path":f"/data/extensions/regex_scripts/{idx}","summary":"greedy .+ or .* spans a repeated delimiter; review whether a lazy quantifier is required"})
        if catastrophic_backtracking_risk(pattern): findings.append({"category":"regex_catastrophic_backtracking_risk","script_id":script_id,"path":f"/data/extensions/regex_scripts/{idx}","summary":"nested or stacked quantifiers can cause catastrophic backtracking"})
        verification = meta.get("verification")
        if not isinstance(verification, dict) or verification.get("status") != "passed" or verification.get("pattern_sha256") != _sha(pattern):
            findings.append({"category":"regex_unverified_pattern","script_id":script_id,"path":f"/data/extensions/regex_scripts/{idx}","summary":"WorldBuilder-authored Regex has no matching successful verification record"})
    return {"kind":REGEX_REPORT_KIND,"report_version":REGEX_REPORT_VERSION,"contract":CONTRACT,"applicable":bool(authored),"findings":findings,"authored_regex_count":len(authored)}


def validate_delivery_metadata(card: dict[str, Any]) -> dict[str, Any]:
    data = _card_data(card); ext = data.get("extensions") if isinstance(data.get("extensions"), dict) else {}
    marker = ext.get("worldbuilder_graphics_designer") if isinstance(ext.get("worldbuilder_graphics_designer"), dict) else None
    if not marker: return {"applicable": False, "regex_count": 0, "html_count": 0}
    scripts = ext.get("regex_scripts") if isinstance(ext.get("regex_scripts"), list) else []
    script_by_id = {str(s.get("id")): s for s in scripts if isinstance(s, dict) and s.get("id") is not None}
    for row in marker.get("regex", []) if isinstance(marker.get("regex"), list) else []:
        if not isinstance(row, dict): raise WorldBuilderError("invalid WorldBuilder Graphics Designer Regex metadata")
        sid = str(row.get("script_id")); script = script_by_id.get(sid)
        if script is None: raise WorldBuilderError(f"WorldBuilder-authored Regex {sid} is missing from card extensions")
        if not str(row.get("approved_by_person", "")).strip(): raise WorldBuilderError(f"WorldBuilder-authored Regex {sid} lacks explicit person approval")
        verification = row.get("verification")
        if not isinstance(verification, dict) or verification.get("status") != "passed" or verification.get("pattern_sha256") != _sha(str(script.get("findRegex", ""))):
            raise WorldBuilderError(f"WorldBuilder-authored Regex {sid} lacks a matching successful verification record")
    for row in marker.get("html", []) if isinstance(marker.get("html"), list) else []:
        if not isinstance(row, dict) or row.get("separate_approval_required") is not False:
            raise WorldBuilderError("invalid Graphics Designer greeting HTML metadata")
        ver = row.get("verification")
        if not isinstance(ver, dict) or ver.get("status") != "passed" or ver.get("markup_sha256") != _sha(str(data.get("first_mes", ""))):
            raise WorldBuilderError("Graphics Designer greeting HTML verification does not match first_mes")
    return {"applicable": True, "regex_count": len(marker.get("regex", [])), "html_count": len(marker.get("html", []))}


def main() -> int:
    p=argparse.ArgumentParser(description=__doc__); sub=p.add_subparsers(dest="command",required=True)
    vr=sub.add_parser("verify-regex"); vr.add_argument("--spec",required=True); vr.add_argument("--samples",required=True); vr.add_argument("--output",required=True); vr.add_argument("--timeout",type=float,default=1.5)
    br=sub.add_parser("bundle-regex"); br.add_argument("--card",required=True); br.add_argument("--spec",required=True); br.add_argument("--verification",required=True); br.add_argument("--approval",required=True); br.add_argument("--output",required=True)
    tr=sub.add_parser("author-tracker"); tr.add_argument("--name",required=True); tr.add_argument("--state",required=True); tr.add_argument("--output",required=True); tr.add_argument("--key",action="append",default=[]); tr.add_argument("--order",type=int,default=100)
    vh=sub.add_parser("verify-html"); vh.add_argument("--html",required=True); vh.add_argument("--output",required=True)
    bh=sub.add_parser("bundle-html"); bh.add_argument("--card",required=True); bh.add_argument("--html",required=True); bh.add_argument("--verification",required=True); bh.add_argument("--output",required=True)
    an=sub.add_parser("analyze-regex"); an.add_argument("--card",required=True)
    a=p.parse_args()
    try:
        if a.command=="verify-regex": result=verify_regex(load_json(Path(a.spec)),load_json(Path(a.samples)),timeout=a.timeout); atomic_write_json(Path(a.output),result)
        elif a.command=="bundle-regex": result=bundle_regex(load_json(Path(a.card)),load_json(Path(a.spec)),load_json(Path(a.verification)),approval=a.approval); atomic_write_json(Path(a.output),result)
        elif a.command=="author-tracker": result=author_tracker(a.name,load_json(Path(a.state)),keys=a.key,order=a.order); atomic_write_json(Path(a.output),result)
        elif a.command=="verify-html": markup=Path(a.html).read_text(encoding="utf-8"); result=verify_html(markup); atomic_write_json(Path(a.output),result)
        elif a.command=="bundle-html": markup=Path(a.html).read_text(encoding="utf-8"); result=bundle_html(load_json(Path(a.card)),markup,load_json(Path(a.verification))); atomic_write_json(Path(a.output),result)
        else: result=analyze_artifact_regex(load_json(Path(a.card)))
        if a.command not in {"bundle-regex","author-tracker","verify-html","verify-regex","bundle-html"}: print(json.dumps(result,ensure_ascii=False,indent=2))
        return 0 if not isinstance(result,dict) or result.get("status") != "failed" else 2
    except (WorldBuilderError,OSError,ValueError,json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}",file=sys.stderr); return 1


if __name__=="__main__": raise SystemExit(main())
