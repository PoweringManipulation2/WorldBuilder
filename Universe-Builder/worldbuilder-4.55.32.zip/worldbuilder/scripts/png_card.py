#!/usr/bin/env python3
"""Batch 8: PNG card container; read and write chara/ccv3 tEXt chunks.

No read or write of PNG tEXt chunks existed before this; the dominant
real-world SillyTavern card distribution format was simply unsupported.
The PNG is a container; the character JSON lives inside a tEXt chunk,
base64-encoded. This module never touches image pixel data at all.

Pure stdlib, deliberately: Pillow requires a compiled, native image
library and would change SKILL.md's own declared anyBins contract
(currently just python3/python). PNG chunk parsing is a length/type/data/
CRC walk: zlib.crc32 already computes the exact checksum PNG chunks
use, so no image library is needed for any of this.
"""
from __future__ import annotations

import argparse
import base64
import binascii
import json
import struct
import sys
import zlib
from pathlib import Path
from typing import Any, Iterator

from wb_common import WorldBuilderError

SIGNATURE = b"\x89PNG\r\n\x1a\n"
TEXT_KEYWORDS = ("ccv3", "chara")  # ccv3 preferred, chara fallback, plan's own stated order


class Chunk:
    __slots__ = ("chunk_type", "data", "start", "end")

    def __init__(self, chunk_type: bytes, data: bytes, start: int, end: int) -> None:
        self.chunk_type = chunk_type
        self.data = data
        self.start = start  # offset of the length field, i.e. the whole chunk's start
        self.end = end      # offset just past the CRC, i.e. the whole chunk's end


def iter_chunks(png_bytes: bytes) -> Iterator[Chunk]:
    """Walks every chunk in a PNG byte string, verifying the signature
    and each chunk's CRC32; a corrupt or truncated file is rejected
    immediately, never silently skipped or guessed at."""
    if not png_bytes.startswith(SIGNATURE):
        raise WorldBuilderError("not a valid PNG file: signature mismatch")
    offset = len(SIGNATURE)
    total = len(png_bytes)
    seen_iend = False
    while offset < total:
        if offset + 8 > total:
            raise WorldBuilderError("truncated PNG: incomplete chunk header")
        length = int.from_bytes(png_bytes[offset:offset + 4], "big")
        chunk_type = png_bytes[offset + 4:offset + 8]
        data_start = offset + 8
        data_end = data_start + length
        crc_end = data_end + 4
        if crc_end > total:
            raise WorldBuilderError(f"truncated PNG: {chunk_type!r} chunk data extends past end of file")
        chunk_data = png_bytes[data_start:data_end]
        stored_crc = int.from_bytes(png_bytes[data_end:crc_end], "big")
        computed_crc = zlib.crc32(chunk_type + chunk_data) & 0xFFFFFFFF
        if stored_crc != computed_crc:
            raise WorldBuilderError(f"corrupt PNG: {chunk_type!r} chunk CRC mismatch")
        yield Chunk(chunk_type, chunk_data, offset, crc_end)
        offset = crc_end
        if chunk_type == b"IEND":
            seen_iend = True
            break
    if not seen_iend:
        raise WorldBuilderError("truncated PNG: no IEND chunk found")


def extract_card_json(png_bytes: bytes) -> tuple[Any, str]:
    """Returns (card_data, source_keyword). ccv3 is preferred over chara
    when both are present, matching the plan's stated precedence exactly."""
    found: dict[str, bytes] = {}
    for chunk in iter_chunks(png_bytes):
        if chunk.chunk_type != b"tEXt":
            continue
        if b"\x00" not in chunk.data:
            continue  # malformed tEXt chunk (no keyword/text separator); skip, don't crash on it
        keyword, _sep, text = chunk.data.partition(b"\x00")
        try:
            keyword_str = keyword.decode("latin-1")
        except UnicodeDecodeError:
            continue
        if keyword_str in TEXT_KEYWORDS and keyword_str not in found:
            found[keyword_str] = text  # first occurrence wins for a given keyword

    for keyword_str in TEXT_KEYWORDS:  # ccv3 first, chara second; iteration order IS the precedence
        if keyword_str in found:
            raw_text = found[keyword_str]
            try:
                decoded = base64.b64decode(raw_text, validate=True)
            except (binascii.Error, ValueError) as exc:
                raise WorldBuilderError(f"{keyword_str!r} tEXt chunk is not valid base64: {exc}")
            try:
                card_data = json.loads(decoded.decode("utf-8"))
            except (UnicodeDecodeError, json.JSONDecodeError) as exc:
                raise WorldBuilderError(f"{keyword_str!r} tEXt chunk does not decode to valid UTF-8 JSON: {exc}")
            return card_data, keyword_str

    raise WorldBuilderError("no chara or ccv3 tEXt chunk found in PNG")


def build_chunk(chunk_type: bytes, data: bytes) -> bytes:
    """A complete, CRC-correct chunk: length + type + data + CRC32. The
    one piece of chunk-construction logic every chunk-producing function
    in this module shares; never reimplemented per caller."""
    return struct.pack(">I", len(data)) + chunk_type + data + struct.pack(">I", zlib.crc32(chunk_type + data) & 0xFFFFFFFF)


def build_text_chunk(card_data: Any, *, keyword: str = "ccv3") -> bytes:
    """A complete, CRC-correct tEXt chunk (length+type+data+crc) carrying
    card_data as base64-encoded JSON under keyword. Used both to insert a
    fresh chunk and to build the replacement in write_card_json."""
    if keyword not in TEXT_KEYWORDS:
        raise WorldBuilderError(f"keyword must be one of {TEXT_KEYWORDS}, got {keyword!r}")
    json_bytes = json.dumps(card_data, ensure_ascii=False).encode("utf-8")
    encoded = base64.b64encode(json_bytes)
    data = keyword.encode("latin-1") + b"\x00" + encoded
    return build_chunk(b"tEXt", data)


def generate_placeholder_png(
    width: int = 400, height: int = 600, *,
    color: tuple[int, int, int] = (120, 120, 150), gradient_to: tuple[int, int, int] | None = None,
) -> bytes:
    """Batch 8, Phase C: a solid-color or top-to-bottom gradient PNG,
    stdlib only. This is NOT image generation; there is no content
    awareness here at all, only a color or two; it exists purely so a
    build with no supplied or preserved carrier image still produces a
    valid PNG rather than having no image path at all. Real generation is
    Batch 10.

    8-bit RGB, filter type 0 (None) per scanline: the simplest valid
    PNG encoding, correct for any width/height, at the cost of a larger
    IDAT than a real image would need. That tradeoff is fine here: this
    output is a placeholder, not something optimized for file size.
    """
    if width <= 0 or height <= 0:
        raise WorldBuilderError(f"width and height must be positive, got {width}x{height}")

    def scanline_color(y: int) -> tuple[int, int, int]:
        if gradient_to is None:
            return color
        t = y / max(1, height - 1)
        return tuple(round(color[i] + (gradient_to[i] - color[i]) * t) for i in range(3))

    raw = bytearray()
    for y in range(height):
        r, g, b = scanline_color(y)
        raw.append(0)  # filter type: None
        raw.extend((r, g, b) * width)

    ihdr_data = struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0)  # 8-bit depth, color type 2 = truecolor RGB
    idat_data = zlib.compress(bytes(raw), 9)
    return SIGNATURE + build_chunk(b"IHDR", ihdr_data) + build_chunk(b"IDAT", idat_data) + build_chunk(b"IEND", b"")


def write_card_json(png_bytes: bytes, card_data: Any, *, keyword: str = "ccv3") -> bytes:
    """Returns new PNG bytes: every chunk from png_bytes preserved byte-
    for-byte except chara/ccv3 tEXt chunks, which are replaced by exactly
    one fresh tEXt chunk carrying card_data. The new chunk goes where the
    first old chara/ccv3 chunk was, or immediately before the first IDAT
    if none existed; matching where an ancillary chunk like this
    conventionally belongs. Every other byte of the file, including pixel
    data, is untouched: this function never decodes, re-encodes, or
    otherwise looks at IHDR/IDAT/IEND content, only chunk boundaries.

    Batch 10: a freshly generated image (from image_generate, via
    expression_assets.py's generation_sequence, or a standalone base
    portrait) works as png_bytes with no change to this function at all
    ; it is just PNG bytes, indistinguishable here from an uploaded or
    round-trip-preserved carrier. This function has no opinion about
    where the image came from.
    """
    chunks = list(iter_chunks(png_bytes))  # validates signature and every chunk's CRC before touching anything
    new_text_chunk = build_text_chunk(card_data, keyword=keyword)

    is_old_card_chunk: list[bool] = []
    for chunk in chunks:
        if chunk.chunk_type != b"tEXt" or b"\x00" not in chunk.data:
            is_old_card_chunk.append(False)
            continue
        chunk_keyword, _sep, _text = chunk.data.partition(b"\x00")
        try:
            is_old_card_chunk.append(chunk_keyword.decode("latin-1") in TEXT_KEYWORDS)
        except UnicodeDecodeError:
            is_old_card_chunk.append(False)

    insert_index = next((i for i, is_card in enumerate(is_old_card_chunk) if is_card), None)
    if insert_index is None:
        insert_index = next((i for i, c in enumerate(chunks) if c.chunk_type == b"IDAT"), len(chunks))

    out = bytearray(SIGNATURE)
    inserted = False
    for i, chunk in enumerate(chunks):
        if is_old_card_chunk[i]:
            continue  # drop every old chara/ccv3 chunk; exactly one replacement goes in below
        if i == insert_index and not inserted:
            out += new_text_chunk
            inserted = True
        out += png_bytes[chunk.start:chunk.end]  # untouched original bytes, not re-serialized
    if not inserted:  # insert_index pointed past the end (no IDAT, no old card chunk; append before IEND)
        iend_index = next((i for i, c in enumerate(chunks) if c.chunk_type == b"IEND"), len(chunks))
        out = bytearray(SIGNATURE)
        for i, chunk in enumerate(chunks):
            if is_old_card_chunk[i]:
                continue
            if i == iend_index:
                out += new_text_chunk
            out += png_bytes[chunk.start:chunk.end]
    return bytes(out)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--read", metavar="PNG_PATH", help="Extract card JSON from a PNG and print it")
    parser.add_argument("--output", help="Write the extracted JSON here instead of stdout")
    args = parser.parse_args()
    try:
        if args.read:
            png_bytes = Path(args.read).read_bytes()
            card_data, source = extract_card_json(png_bytes)
            result = {"source_chunk": source, "card": card_data}
            text = json.dumps(result, ensure_ascii=False, indent=2)
            if args.output:
                from wb_common import atomic_write_json
                atomic_write_json(Path(args.output), result)
            print(text)
            return 0
        parser.print_help()
        return 1
    except (WorldBuilderError, OSError, ValueError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
