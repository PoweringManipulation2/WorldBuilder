#!/usr/bin/env python3
"""Restore files from a hash-indexed WorldBuilder invalidation archive."""
from __future__ import annotations

import argparse
import json
import os
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from wb_common import WorldBuilderError, atomic_write_json, load_build_state, load_json, sha256_file

STAGES = ("discovery", "era", "placement", "budget", "dynamic", "planning", "manifest", "generation", "runtime")


def _stamp() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")


def _contains_uid(value: Any, wanted: str) -> bool:
    if isinstance(value, dict):
        for key, child in value.items():
            if key in {"uid", "source_uid", "target_uid"} and str(child) == wanted:
                return True
            if _contains_uid(child, wanted):
                return True
    elif isinstance(value, list):
        return any(_contains_uid(child, wanted) for child in value)
    return False


def _archives(root: Path) -> list[tuple[Path, dict[str, Any], dict[str, Any]]]:
    base = root / ".work" / "invalidated"
    result: list[tuple[Path, dict[str, Any], dict[str, Any]]] = []
    if not base.is_dir():
        return result
    for archive in sorted((p for p in base.iterdir() if p.is_dir()), reverse=True):
        index_path = archive / "index.json"
        receipt_path = archive / "invalidation-receipt.json"
        if not index_path.is_file() or not receipt_path.is_file():
            continue
        index = load_json(index_path)
        receipt = load_json(receipt_path)
        if isinstance(index, dict) and isinstance(receipt, dict):
            result.append((archive, index, receipt))
    return result


def restore(build_state: str, *, stage: str | None = None, uid: str | None = None) -> dict[str, Any]:
    root, state = load_build_state(build_state)
    archives = _archives(root)
    if not archives:
        raise WorldBuilderError("no hash-indexed invalidation archives are available to restore")
    selected_archive: Path | None = None
    selected_index: dict[str, Any] | None = None
    selected_rows: list[dict[str, Any]] = []
    for archive, index, receipt in archives:
        if index.get("build_id") != state.get("build_id"):
            continue
        rows = [row for row in index.get("entries", []) if isinstance(row, dict)]
        if stage is not None:
            if receipt.get("stage") != stage:
                continue
            selected_archive, selected_index, selected_rows = archive, index, rows
            break
        assert uid is not None
        matches: list[dict[str, Any]] = []
        for row in rows:
            archived = root / str(row.get("archive_path", ""))
            if not archived.is_file() or archived.suffix.lower() != ".json":
                continue
            try:
                value = load_json(archived)
            except (OSError, json.JSONDecodeError, UnicodeDecodeError):
                continue
            if _contains_uid(value, str(uid)):
                matches.append(row)
        if matches:
            selected_archive, selected_index, selected_rows = archive, index, matches
            break
    if selected_archive is None or selected_index is None or not selected_rows:
        label = f"stage {stage}" if stage is not None else f"UID {uid}"
        raise WorldBuilderError(f"no indexed archived files match {label}")

    restored: list[dict[str, Any]] = []
    skipped: list[str] = []
    for row in selected_rows:
        source_rel = str(row.get("source_path", ""))
        archive_rel = str(row.get("archive_path", ""))
        if not source_rel or not archive_rel:
            raise WorldBuilderError("archive index contains an entry without source_path/archive_path")
        source = (root / source_rel).resolve()
        archived = (root / archive_rel).resolve()
        try:
            source.relative_to(root)
            archived.relative_to(root)
        except ValueError as exc:
            raise WorldBuilderError("archive index resolves outside the build workspace") from exc
        if not archived.exists():
            raise WorldBuilderError(f"indexed archive payload is missing: {archived}")
        expected = row.get("sha256")
        if archived.is_file() and isinstance(expected, str) and sha256_file(archived) != expected:
            raise WorldBuilderError(f"indexed archive payload hash mismatch: {archive_rel}")
        if source.exists():
            if source.is_file() and archived.is_file() and sha256_file(source) == sha256_file(archived):
                skipped.append(source_rel)
                continue
            raise WorldBuilderError(
                f"refusing to overwrite live path during restore: {source_rel}; move or invalidate the live file first"
            )
        source.parent.mkdir(parents=True, exist_ok=True)
        if archived.is_dir():
            shutil.copytree(archived, source)
        else:
            shutil.copy2(archived, source)
        restored.append({"source_path": source_rel, "archive_path": archive_rel, "sha256": sha256_file(source) if source.is_file() else None})

    receipt_dir = root / ".work" / "restores"
    receipt_dir.mkdir(parents=True, exist_ok=True)
    receipt_path = receipt_dir / f"{_stamp()}-restore.json"
    receipt = {
        "kind": "worldbuilder-lineage-restore",
        "receipt_version": 1,
        "build_id": state.get("build_id"),
        "source_archive": str(selected_archive.relative_to(root)).replace(os.sep, "/"),
        "source_index_sha256": sha256_file(selected_archive / "index.json"),
        "selector": {"stage": stage, "uid": uid},
        "restored": restored,
        "already_present_identical": skipped,
    }
    atomic_write_json(receipt_path, receipt)
    return {"status": "restored", "restored": restored, "skipped": skipped, "receipt": str(receipt_path)}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--build-state", required=True)
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--stage", choices=STAGES)
    group.add_argument("--uid")
    args = parser.parse_args()
    try:
        print(json.dumps(restore(args.build_state, stage=args.stage, uid=args.uid), ensure_ascii=False, indent=2))
        return 0
    except (WorldBuilderError, OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
