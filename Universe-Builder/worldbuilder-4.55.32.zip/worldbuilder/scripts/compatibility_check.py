#!/usr/bin/env python3
"""Detect drift between WorldBuilder's named SillyTavern compatibility claims and source.

This is diagnostic/build-time tooling.  A clean result means the checked source claims
still match the frozen baseline.  It never certifies a new application version: fixture
acceptance and an explicit profile update remain separate release decisions.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_BASELINE = ROOT / "references" / "compatibility-baseline.json"
REPORT_KIND = "worldbuilder-compatibility-check-v1"
BASELINE_KIND = "worldbuilder-compatibility-baseline-v1"


def _sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def _json_pointer(value: Any, pointer: str) -> Any:
    if pointer == "":
        return value
    if not pointer.startswith("/"):
        raise ValueError(f"invalid JSON pointer: {pointer!r}")
    current = value
    for raw in pointer[1:].split("/"): 
        token = raw.replace("~1", "/").replace("~0", "~")
        if isinstance(current, list):
            current = current[int(token)]
        elif isinstance(current, dict):
            current = current[token]
        else:
            raise KeyError(token)
    return current


def validate_baseline(data: Any) -> list[str]:
    errors: list[str] = []
    if not isinstance(data, dict):
        return ["baseline must be a JSON object"]
    if data.get("kind") != BASELINE_KIND:
        errors.append(f"kind must be {BASELINE_KIND!r}")
    target = data.get("target")
    if not isinstance(target, dict):
        errors.append("target must be an object")
    else:
        for key in ("application", "repository", "branch", "claimed_profile", "expected_version"):
            if not isinstance(target.get(key), str) or not target[key].strip():
                errors.append(f"target.{key} must be a non-empty string")
    sources = data.get("sources")
    if not isinstance(sources, dict) or not sources:
        errors.append("sources must be a non-empty object")
        sources = {}
    else:
        for sid, spec in sources.items():
            if not isinstance(spec, dict):
                errors.append(f"sources.{sid} must be an object")
                continue
            for key in ("path", "url"):
                if not isinstance(spec.get(key), str) or not spec[key].strip():
                    errors.append(f"sources.{sid}.{key} must be a non-empty string")
    checks = data.get("checks")
    if not isinstance(checks, list) or not checks:
        errors.append("checks must be a non-empty array")
        return errors
    seen: set[str] = set()
    for i, check in enumerate(checks):
        where = f"checks[{i}]"
        if not isinstance(check, dict):
            errors.append(f"{where} must be an object")
            continue
        cid = check.get("id")
        if not isinstance(cid, str) or not cid.strip():
            errors.append(f"{where}.id must be a non-empty string")
        elif cid in seen:
            errors.append(f"duplicate check id: {cid}")
        else:
            seen.add(cid)
        sid = check.get("source")
        if sid not in sources:
            errors.append(f"{where}.source references unknown source {sid!r}")
        ctype = check.get("type")
        if ctype == "json_equals":
            if not isinstance(check.get("pointer"), str):
                errors.append(f"{where}.pointer must be a string")
            if "expected" not in check:
                errors.append(f"{where}.expected is required")
        elif ctype == "regex_all":
            patterns = check.get("patterns")
            if not isinstance(patterns, list) or not patterns or not all(isinstance(p, str) and p for p in patterns):
                errors.append(f"{where}.patterns must be a non-empty string array")
        else:
            errors.append(f"{where}.type is unsupported: {ctype!r}")
        claims = check.get("local_claims", [])
        if not isinstance(claims, list):
            errors.append(f"{where}.local_claims must be an array")
            continue
        for j, claim in enumerate(claims):
            cwhere = f"{where}.local_claims[{j}]"
            if not isinstance(claim, dict) or not isinstance(claim.get("path"), str):
                errors.append(f"{cwhere} must contain path")
                continue
            modes = [key for key in ("contains", "regex") if isinstance(claim.get(key), str)]
            if len(modes) != 1:
                errors.append(f"{cwhere} must contain exactly one of contains/regex")
    return errors


def _read_sources(baseline: dict[str, Any], source_dir: Path | None, timeout: float) -> tuple[dict[str, str], list[dict[str, str]]]:
    texts: dict[str, str] = {}
    errors: list[dict[str, str]] = []
    for sid, spec in baseline["sources"].items():
        try:
            if source_dir is not None:
                path = (source_dir / spec["path"]).resolve()
                root = source_dir.resolve()
                if root not in path.parents and path != root:
                    raise ValueError("source path escapes --source-dir")
                raw = path.read_bytes()
            else:
                req = urllib.request.Request(spec["url"], headers={"User-Agent": "WorldBuilder-compatibility-check/1"})
                with urllib.request.urlopen(req, timeout=timeout) as response:
                    raw = response.read()
            texts[sid] = raw.decode("utf-8-sig")
        except Exception as exc:  # network/fixture errors are reportable input failures
            errors.append({"source": sid, "error": f"{type(exc).__name__}: {exc}"})
    return texts, errors


def _check_local_claims(check: dict[str, Any], worldbuilder_root: Path) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    root = worldbuilder_root.resolve()
    for claim in check.get("local_claims", []):
        item: dict[str, Any] = {"path": claim["path"], "status": "match"}
        try:
            path = (root / claim["path"]).resolve()
            if root not in path.parents and path != root:
                raise ValueError("claim path escapes WorldBuilder root")
            text = path.read_text(encoding="utf-8")
            if "contains" in claim:
                ok = claim["contains"] in text
                item["selector"] = {"contains": claim["contains"]}
            else:
                ok = re.search(claim["regex"], text, flags=re.MULTILINE | re.DOTALL) is not None
                item["selector"] = {"regex": claim["regex"]}
            if not ok:
                item["status"] = "drift"
        except Exception as exc:
            item["status"] = "error"
            item["error"] = f"{type(exc).__name__}: {exc}"
        out.append(item)
    return out


def run_check(
    baseline_path: Path = DEFAULT_BASELINE,
    *,
    source_dir: Path | None = None,
    worldbuilder_root: Path = ROOT,
    timeout: float = 20.0,
) -> tuple[dict[str, Any], int]:
    baseline_bytes = baseline_path.read_bytes()
    baseline = json.loads(baseline_bytes.decode("utf-8"))
    validation_errors = validate_baseline(baseline)
    if validation_errors:
        report = {
            "kind": REPORT_KIND,
            "status": "error",
            "baseline_sha256": _sha256_bytes(baseline_bytes),
            "validation_errors": validation_errors,
            "compatibility_certified": False,
            "certification_note": "A compatibility check never certifies a new target version.",
        }
        return report, 2

    texts, source_errors = _read_sources(baseline, source_dir, timeout)
    results: list[dict[str, Any]] = []
    for check in baseline["checks"]:
        item: dict[str, Any] = {"id": check["id"], "source": check["source"], "status": "match"}
        text = texts.get(check["source"])
        if text is None:
            item["status"] = "error"
            item["error"] = "source unavailable"
        else:
            try:
                if check["type"] == "json_equals":
                    actual = _json_pointer(json.loads(text), check["pointer"])
                    item["expected"] = check["expected"]
                    item["actual"] = actual
                    if actual != check["expected"]:
                        item["status"] = "drift"
                else:
                    matches: list[dict[str, Any]] = []
                    for pattern in check["patterns"]:
                        ok = re.search(pattern, text, flags=re.MULTILINE | re.DOTALL) is not None
                        matches.append({"pattern": pattern, "matched": ok})
                    item["patterns"] = matches
                    if not all(row["matched"] for row in matches):
                        item["status"] = "drift"
            except Exception as exc:
                item["status"] = "error"
                item["error"] = f"{type(exc).__name__}: {exc}"
        local = _check_local_claims(check, worldbuilder_root)
        item["local_claims"] = local
        if any(row["status"] == "error" for row in local):
            item["status"] = "error"
        elif any(row["status"] == "drift" for row in local) and item["status"] == "match":
            item["status"] = "drift"
        results.append(item)

    statuses = [r["status"] for r in results]
    if source_errors or "error" in statuses:
        status = "error"
        rc = 2
    elif "drift" in statuses:
        status = "drift"
        rc = 1
    else:
        status = "clean"
        rc = 0
    report = {
        "kind": REPORT_KIND,
        "checked_at": datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z"),
        "status": status,
        "target": baseline["target"],
        "baseline_sha256": _sha256_bytes(baseline_bytes),
        "source_mode": "snapshot" if source_dir is not None else "network",
        "source_errors": source_errors,
        "summary": {
            "checks": len(results),
            "matched": sum(r["status"] == "match" for r in results),
            "drifted": sum(r["status"] == "drift" for r in results),
            "errors": sum(r["status"] == "error" for r in results),
        },
        "checks": results,
        "compatibility_certified": False,
        "certification_note": (
            "Clean means only that the frozen claim-level baseline still matches the checked source. "
            "A new SillyTavern version requires explicit fixture acceptance and a deliberate profile update."
        ),
    }
    return report, rc


def _parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--baseline", type=Path, default=DEFAULT_BASELINE, help="baseline JSON (default: bundled baseline)")
    p.add_argument("--source-dir", type=Path, help="read source snapshots from this directory instead of the network")
    p.add_argument("--worldbuilder-root", type=Path, default=ROOT, help="WorldBuilder root for validating local claims")
    p.add_argument("--output", type=Path, help="optional JSON report path")
    p.add_argument("--timeout", type=float, default=20.0, help="network timeout seconds")
    return p


def main(argv: list[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    try:
        report, rc = run_check(
            args.baseline,
            source_dir=args.source_dir,
            worldbuilder_root=args.worldbuilder_root,
            timeout=args.timeout,
        )
    except Exception as exc:
        report = {
            "kind": REPORT_KIND,
            "status": "error",
            "compatibility_certified": False,
            "error": f"{type(exc).__name__}: {exc}",
        }
        rc = 2
    encoded = json.dumps(report, indent=2, ensure_ascii=False) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(encoded, encoding="utf-8")
    sys.stdout.write(encoded)
    return rc


if __name__ == "__main__":
    raise SystemExit(main())
