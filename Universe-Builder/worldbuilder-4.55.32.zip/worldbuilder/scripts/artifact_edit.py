#!/usr/bin/env python3
"""Batch 7, 7.7: the editing primitive WorldBuilder has never had.

WorldBuilder can generate artifacts and validate artifacts, but until this
module it could not edit them: "the model rewrites the file" was gated by a
verifier that never saw the original (verify_patches.py had no --before).

Five operations, addressed by UID or JSON Pointer:
    set-field     : change content, keys, secondary_keys, comment, or name
    add-entry     : new entry, ID from the same authority merge_phases.py uses
    remove-entry  : delete with an identity check (never a bare UID)
    move-depth    : change recursion_level / delay_until_recursion
    retag-keys    : keyword tightening without touching content

Atomic writes (atomic_write_json). Unknown fields, extension namespaces, and
key order survive every operation because each operation mutates the loaded
document's existing dict objects in place rather than rebuilding them:
Python dicts have been insertion-ordered since 3.7, so nothing needs sorting
or re-emitting to preserve order. Reuses verify_patches.py's identity/pointer
machinery (build_identity_index, resolve_pointer, parent_pointer) and
merge_phases.py's next_integer_identity rather than reimplementing either;
this is deliberate: an editor with its own, second notion of "what counts as
this entry's identity" is exactly how collateral damage goes undetected.

move-depth is called out explicitly in the plan as a deliberate loosening of
an existing invariant: pruning_receipt.ALLOWED_MUTABLE_FIELDS currently
blocks recursion_level/delay_until_recursion, and generation-worker.md tells
workers never to touch them. This module is the one place that exemption is
allowed to exist, and only when the caller states why (see DR "Editing is a
tool operation, not a rewrite"). Workers still may not; this tool is not
reachable from a generation assignment.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path
from typing import Any

from wb_common import WorldBuilderError, atomic_write_json, build_identity_index, detect_artifact, get_lorebook_container, load_json, normalize_identity
from verify_patches import resolve_pointer
from merge_phases import next_integer_identity
from lock_contract import assert_unlocked
from artifact_lookup import locate_entry as _locate

CONTRACT = "worldbuilder-artifact-edit-v1"
OPERATIONS = ("set-field", "add-entry", "remove-entry", "move-depth", "retag-keys")

# set-field's allowed targets. Deliberately the same vocabulary as
# pruning_receipt.ALLOWED_MUTABLE_FIELDS's content-bearing fields (content,
# keys, secondary_keys, comment, name); an editor that could touch more
# than a pruner is allowed to touch would be a wider hole than this batch
# means to open. key/keysecondary are the same fields under their World
# Info native names; both spellings are accepted, canonicalized to keys/
# secondary_keys on write so a single artifact never carries both.
SET_FIELD_ALLOWED = ("content", "keys", "secondary_keys", "key", "keysecondary", "comment", "name")

# Batch 58 / A06: the same logical field under two real spellings. A native World
# Info entry reads ``key``, ``keysecondary``, ``comment``, ``depth`` and
# ``delayUntilRecursion``; a portable CCv3 entry reads ``keys``,
# ``secondary_keys``, ``name``, ``recursion_level`` and ``delay_until_recursion``.
# Writing only the portable spelling into a native artifact reported success
# while leaving the field the application actually reads untouched. Resolution is
# per entry, not per artifact: a CCv3 entry legitimately carries BOTH ``name`` and
# ``comment``, so a requested spelling the entry already has is always honored.
_FIELD_COUNTERPARTS = {
    "key": "keys", "keys": "key",
    "keysecondary": "secondary_keys", "secondary_keys": "keysecondary",
    "name": "comment", "comment": "name",
    "recursion_level": "depth", "depth": "recursion_level",
    "delay_until_recursion": "delayUntilRecursion", "delayUntilRecursion": "delay_until_recursion",
}

_PORTABLE_SPELLINGS = {
    "keys": "keys", "secondary_keys": "secondary_keys", "name": "name",
    "recursion_level": "recursion_level", "delay_until_recursion": "delay_until_recursion",
}
_NATIVE_SPELLINGS = {
    "keys": "key", "secondary_keys": "keysecondary", "name": "comment",
    "recursion_level": "depth", "delay_until_recursion": "delayUntilRecursion",
}


def _artifact_spellings(data: Any) -> dict[str, str]:
    """Which spelling this artifact uses, for logical fields it does not carry yet.

    Key fields are disjoint between the formats (``key``/``keysecondary`` versus
    ``keys``/``secondary_keys``) and identify it outright. When neither or both
    appear, the container shape decides: a dict-keyed ``entries`` mapping is
    native World Info, a list is CCv3/lorebook_v3.
    """
    native = portable = 0
    for _path, row in build_identity_index(data).values():
        if not isinstance(row, dict):
            continue
        if row.get("key") is not None or row.get("keysecondary") is not None:
            native += 1
        if row.get("keys") is not None or row.get("secondary_keys") is not None:
            portable += 1
    if native and not portable:
        return _NATIVE_SPELLINGS
    if portable and not native:
        return _PORTABLE_SPELLINGS
    container = _resolve_entries_container(data)
    return _NATIVE_SPELLINGS if isinstance(container.get("entries"), dict) else _PORTABLE_SPELLINGS


def _effective_field(entry: Any, requested: str, spellings: dict[str, str]) -> str:
    """The field this entry actually reads for a requested logical field.

    Prefer the requested spelling when the entry already carries it (a CCv3 entry
    legitimately holds both ``name`` and ``comment``); then its format
    counterpart; otherwise the spelling this artifact's format uses, so a field
    that does not exist yet is created where the application will read it."""
    if not isinstance(entry, dict):
        return requested
    logical = None
    for name, spelling in spellings.items():
        if requested == name or requested == spelling or requested == _FIELD_COUNTERPARTS.get(name):
            logical = name; break
    # For fields whose portable/native spellings are mutually exclusive in the
    # consuming application, the artifact format is authoritative even if a
    # stale alias from an older WorldBuilder edit is also present.
    if logical in {"keys", "secondary_keys", "recursion_level", "delay_until_recursion"}:
        return spellings[logical]
    if requested in entry:
        return requested
    counterpart = _FIELD_COUNTERPARTS.get(requested)
    if counterpart and counterpart in entry:
        return counterpart
    return spellings.get(requested, requested)

DEPTH_FIELDS = ("recursion_level", "delay_until_recursion")




def _resolve_entries_container(data: Any) -> dict[str, Any]:
    """The actual container dict whose 'entries' key holds the real,
    mutable list or dict of entries, reusing wb_common's own artifact
    detection rather than re-deriving container structure from a parsed
    path string. Every branch here mirrors iter_entries' own resolution
    exactly, so a container this function returns is the same one
    iter_entries would have iterated."""
    info = detect_artifact(data)
    container = get_lorebook_container(data, info)
    if container is not None:
        return container
    if isinstance(data, dict):
        if isinstance(data.get("entries"), (list, dict)):
            return data
        if data and all(isinstance(v, dict) for v in data.values()):
            # A bare {uid: entry, ...} mapping with no "entries" wrapper key on
            # disk. {"entries": data} below is a synthesized view for this
            # function's own return shape, but its "entries" value IS data
            # itself (the same dict object); mutating it mutates the real,
            # on-disk structure, not a disconnected copy.
            return {"entries": data}
    raise WorldBuilderError("could not locate an entries container in this artifact")


def op_set_field(data: Any, *, uid: Any = None, pointer: str | None = None, field: str, value: Any) -> dict[str, Any]:
    if field not in SET_FIELD_ALLOWED:
        raise WorldBuilderError(f"set-field cannot target {field!r}; allowed: {', '.join(SET_FIELD_ALLOWED)}")
    entry = _locate(data, uid=uid, pointer=pointer)
    canonical_field = _effective_field(entry, field, _artifact_spellings(data))
    assert_unlocked(entry, field=canonical_field, operation="set-field")
    before = entry.get(canonical_field)
    entry[canonical_field] = value
    return {"operation": "set-field", "uid": uid, "pointer": pointer, "field": canonical_field, "before": before, "after": value}


def _identity_field_name(data: Any) -> str:
    """Which identity field this artifact's entries actually carry.

    Batch 58 / A07: CCv3 entries use ``id``; native World Info uses ``uid``.
    Allocating by ``uid`` alone on a CCv3 book could re-issue an identity that
    already existed under ``id``.
    """
    only_id = only_uid = 0
    for _path, row in build_identity_index(data).values():
        if not isinstance(row, dict):
            continue
        has_id = row.get("id") is not None
        has_uid = row.get("uid") is not None
        if has_id and has_uid:
            if normalize_identity(row["id"]) != normalize_identity(row["uid"]):
                raise WorldBuilderError(
                    f"entry carries conflicting identity mirrors: id={row['id']!r} vs uid={row['uid']!r}; "
                    "repair the artifact before adding entries"
                )
        elif has_id:
            only_id += 1
        elif has_uid:
            only_uid += 1
    if only_id and only_uid:
        raise WorldBuilderError(
            "artifact mixes entries keyed by 'id' and by 'uid'; repair the artifact before adding entries"
        )
    info = detect_artifact(data)
    if info.kind in {"card_v3_embedded", "lorebook_v3"}:
        return "id"
    if info.kind == "sillytavern_world_info":
        return "uid"
    return "id" if only_id else "uid"


def op_add_entry(data: Any, *, entry: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(entry, dict):
        raise WorldBuilderError("add-entry requires an object")
    index = build_identity_index(data)
    identity_field = _identity_field_name(data)
    # Batch 58 / A07: allocate from the canonical identity-index keys, not from
    # raw `uid` values, so an entry that only carries `id` still reserves its
    # identity and can never be re-issued.
    used: set[Any] = set(index)
    for _path, row in index.values():
        if isinstance(row, dict):
            for key in ("uid", "id"):
                if row.get(key) is not None:
                    used.add(row[key])
    manifest_hint = {"next_uid": max((u for u in used if isinstance(u, int) and not isinstance(u, bool)), default=-1) + 1}
    new_uid = next_integer_identity(used, manifest_hint)
    if entry.get("uid") is not None and entry.get("id") is not None and normalize_identity(entry["uid"]) != normalize_identity(entry["id"]):
        raise WorldBuilderError(
            f"add-entry: caller supplied conflicting identity mirrors id={entry['id']!r} and uid={entry['uid']!r}"
        )
    supplied = entry.get("uid") if entry.get("uid") is not None else entry.get("id")
    if supplied is not None and normalize_identity(supplied) != new_uid:
        raise WorldBuilderError(
            f"add-entry: caller supplied identity {supplied!r}, but the next available identity is {new_uid}; "
            "omit uid/id and let this tool allocate it: the same authority merge_phases.py uses, so a hand-picked "
            "identity can never collide with one generation would have assigned"
        )
    entry = dict(entry)
    entry.pop("uid", None)
    entry.pop("id", None)
    entry[identity_field] = new_uid

    container = _resolve_entries_container(data)
    entries = container["entries"]
    if isinstance(entries, list):
        entries.append(entry)
    elif isinstance(entries, dict):
        entries[str(new_uid)] = entry
    else:
        raise WorldBuilderError("entries container is neither a list nor an object")

    # Validate identity and schema on the mutated artifact, in memory, before
    # any caller replaces the file on disk.
    rebuilt = build_identity_index(data)
    if normalize_identity(new_uid) not in rebuilt:
        raise WorldBuilderError("add-entry: the new entry is not resolvable by identity after the edit")
    if len(rebuilt) != len(index) + 1:
        raise WorldBuilderError(
            f"add-entry: mutated artifact has {len(rebuilt)} identifiable entries, expected {len(index) + 1}; "
            "the edit changed more than the new entry"
        )
    return {"operation": "add-entry", "uid": new_uid, "identity_field": identity_field}


def op_remove_entry(data: Any, *, uid: Any, expected_name: str) -> dict[str, Any]:
    """Delete with an identity check: the caller must state what it thinks
    it is deleting. A UID reused after drift, or a stale reference, fails
    this check instead of silently removing the wrong entry."""
    if not isinstance(expected_name, str) or not expected_name.strip():
        raise WorldBuilderError("remove-entry requires expected_name: a bare UID is not an identity check")
    index = build_identity_index(data)
    key = normalize_identity(uid)
    if key not in index:
        raise WorldBuilderError(f"no entry with uid {uid!r}")
    path, entry = index[key]
    assert_unlocked(entry, operation="remove-entry")
    # Batch 58 / A06: the label lives under ``comment`` on a native World Info
    # artifact, so requiring ``name`` rejected every legitimate removal there.
    label_field = _effective_field(entry, "name", _artifact_spellings(data))
    actual_name = entry.get(label_field) if isinstance(entry, dict) else None
    if actual_name != expected_name:
        raise WorldBuilderError(
            f"remove-entry identity check failed for uid {uid!r}: expected name {expected_name!r}, found {actual_name!r}. "
            "Re-read the current artifact before deleting; do not retry with the found name blindly."
        )
    container = _resolve_entries_container(data)
    entries = container["entries"]
    if isinstance(entries, list):
        try:
            entries.remove(entry)
        except ValueError:
            raise WorldBuilderError(f"uid {uid!r} was found by identity but its object is not in the entries list")
    elif isinstance(entries, dict):
        removed = False
        for dict_key, value in list(entries.items()):
            if value is entry:
                del entries[dict_key]
                removed = True
                break
        if not removed:
            raise WorldBuilderError(f"uid {uid!r} was found by identity but its object is not in the entries mapping")
    else:
        raise WorldBuilderError("entries container is neither a list nor an object")
    return {"operation": "remove-entry", "uid": uid, "path": path, "removed_name": actual_name}


def op_move_depth(
    data: Any, *, uid: Any, recursion_level: int | None = None, delay_until_recursion: bool | None = None,
    receipt_bound_reason: str,
) -> dict[str, Any]:
    """7.7's deliberate, narrow exemption: pruning_receipt.ALLOWED_MUTABLE_FIELDS
    blocks these two fields, and generation-worker.md tells workers never to
    touch them. This is the one place that exemption exists, and only with
    an explicit, non-empty reason: there is no default, no silent path."""
    if not isinstance(receipt_bound_reason, str) or not receipt_bound_reason.strip():
        raise WorldBuilderError(
            "move-depth requires receipt_bound_reason: this loosens an invariant that blocks every other "
            "caller in the codebase, and it does not get to do that silently"
        )
    if recursion_level is None and delay_until_recursion is None:
        raise WorldBuilderError("move-depth requires at least one of recursion_level or delay_until_recursion")
    entry = _locate(data, uid=uid)
    spellings = _artifact_spellings(data)
    depth_field = _effective_field(entry, "recursion_level", spellings)
    delay_field = _effective_field(entry, "delay_until_recursion", spellings)
    if recursion_level is not None:
        assert_unlocked(entry, field=depth_field, operation="move-depth")
    if delay_until_recursion is not None:
        assert_unlocked(entry, field=delay_field, operation="move-depth")
    before = {depth_field: entry.get(depth_field), delay_field: entry.get(delay_field)}
    if recursion_level is not None:
        entry[depth_field] = recursion_level
    if delay_until_recursion is not None:
        entry[delay_field] = delay_until_recursion
    after = {depth_field: entry.get(depth_field), delay_field: entry.get(delay_field)}
    return {
        "operation": "move-depth", "uid": uid, "before": before, "after": after,
        "receipt_bound_reason": receipt_bound_reason.strip(),
        "note": "activation graph is now stale for this entry: regenerate it before relying on activation-based checks",
    }


def op_retag_keys(data: Any, *, uid: Any, keys: list[str] | None = None, secondary_keys: list[str] | None = None) -> dict[str, Any]:
    """Keyword tightening without content change. Exists because
    pruning_receipt's token check (content only) currently rejects a
    keyword-only edit that would improve worst-case activation. Batch 7's
    fix to that gate is what makes this operation's output actually land."""
    if keys is None and secondary_keys is None:
        raise WorldBuilderError("retag-keys requires at least one of keys or secondary_keys")
    entry = _locate(data, uid=uid)
    spellings = _artifact_spellings(data)
    primary_field = _effective_field(entry, "keys", spellings)
    secondary_field = _effective_field(entry, "secondary_keys", spellings)
    if keys is not None:
        assert_unlocked(entry, field=primary_field, operation="retag-keys")
    if secondary_keys is not None:
        assert_unlocked(entry, field=secondary_field, operation="retag-keys")
    before = {primary_field: entry.get(primary_field), secondary_field: entry.get(secondary_field)}
    if keys is not None:
        entry[primary_field] = keys
    if secondary_keys is not None:
        entry[secondary_field] = secondary_keys
    after = {primary_field: entry.get(primary_field), secondary_field: entry.get(secondary_field)}
    return {"operation": "retag-keys", "uid": uid, "fields": [primary_field, secondary_field], "before": before, "after": after}


_DISPATCH = {
    "set-field": op_set_field, "add-entry": op_add_entry, "remove-entry": op_remove_entry,
    "move-depth": op_move_depth, "retag-keys": op_retag_keys,
}


def apply_operations(data: Any, operations: list[dict[str, Any]]) -> dict[str, Any]:
    """Applies every operation in order, in memory, and returns the
    machine-readable operation log. Callers write data back themselves
    (via write_artifact): this function never touches disk, so a caller
    can validate the fully-mutated result before committing."""
    log: list[dict[str, Any]] = []
    for op in operations:
        kind = op.get("operation")
        if kind not in _DISPATCH:
            raise WorldBuilderError(f"unknown operation {kind!r}; must be one of {', '.join(OPERATIONS)}")
        kwargs = {k: v for k, v in op.items() if k != "operation"}
        record = _DISPATCH[kind](data, **kwargs)
        record["applied_at_unix"] = int(time.time())
        log.append(record)
    return {"contract": CONTRACT, "operations": log}


def write_artifact(path: Path, data: Any) -> str:
    """Atomic write, preserving whatever key order and structure the
    operations left in place."""
    atomic_write_json(path, data)
    from wb_common import sha256_file
    return sha256_file(path)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--artifact", required=True, help="Path to the lorebook/card JSON to edit")
    parser.add_argument("--operations", required=True, help="Path to a JSON file: a list of operation objects")
    parser.add_argument("--output", help="Where to write the edited artifact (default: overwrite --artifact)")
    parser.add_argument("--log-output", help="Where to write the operation log (default: alongside --output)")
    args = parser.parse_args()
    try:
        artifact_path = Path(args.artifact)
        data = load_json(artifact_path)
        operations = load_json(Path(args.operations))
        if not isinstance(operations, list):
            raise WorldBuilderError("--operations must be a JSON list of operation objects")
        result = apply_operations(data, operations)
        output_path = Path(args.output) if args.output else artifact_path
        sha = write_artifact(output_path, data)
        log_path = Path(args.log_output) if args.log_output else output_path.with_suffix(".edit-log.json")
        atomic_write_json(log_path, {**result, "artifact_path": str(output_path), "artifact_sha256": sha})
        print(json.dumps({**result, "artifact_sha256": sha, "log_path": str(log_path)}, ensure_ascii=False, indent=2))
        return 0
    except (WorldBuilderError, OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
