#!/usr/bin/env python3
"""Stop a repair loop before it burns an unattended budget.

The expensive failure is not a gate that blocks. It is a gate that blocks, gets
"fixed", blocks identically, gets "fixed" again, and keeps going while nobody is
watching. Every gate in this project can fail; none of them could ever say "you have
tried this four times and nothing changed, stop."

The guard distinguishes **repetition** from **progress**. A different error after a fix
is progress and never counts against the budget, however many times it happens. The
same error signature after a fix is a loop, and three of those is enough evidence.

Signatures normalize away paths, hashes, timestamps, and line numbers, because the
same logical failure rarely produces byte-identical text twice.

Always on. A safety mechanism that has to be enabled is not one.

Commands:
    attempt  record a gate failure and get a verdict
    clear    reset a gate's counter after it passes
    status   show current counters and what has been tried
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
import time
from pathlib import Path
from typing import Any

from wb_common import TIMEOUT_SAFETY_MULTIPLIER, WorldBuilderError, atomic_write_json, load_build_state, load_json, raise_error, resolve_state_path

CONTRACT = "worldbuilder-repair-loop-guard-v1"
LEDGER_NAME = "repair-attempts.json"

# Three identical failures is enough. The first is information, the second may be an
# incomplete fix, the third means the model is not converging.
IDENTICAL_LIMIT = 3
# Distinct failures on one gate can still be a walk that never ends.
TOTAL_LIMIT = 8
# Repeated timeouts are expected to share a near-identical signature (the same
# "exceeded Ns" message), so they are never judged by IDENTICAL_LIMIT/TOTAL_LIMIT.
# DR-064 treats them as a separate escalation path: raise the timeout and retry,
# rather than stop as though the fix were not converging.
TIMEOUT_RETRY_LIMIT = 4
FAILURE_KINDS = {"failed", "timed_out"}

# Order matters: paths and timestamps first, then identifiers, then bare numbers.
# Real gate errors carry truncated hashes and build ids, so an identifier is any token
# mixing letters and digits; matching only long hex missed the common case.
_NOISE = (
    (re.compile(r"\b\d{4}-\d{2}-\d{2}[T ][\d:.+\-]+"), "<time>"),
    (re.compile(r"(/[^\s:'\"]+)+"), "<path>"),
    (re.compile(r"\bline \d+"), "line <n>"),
    (re.compile(r"\b(?=[0-9a-zA-Z_-]*\d)(?=[0-9a-zA-Z_-]*[a-zA-Z])[0-9a-zA-Z_-]{4,}\b"), "<id>"),
)
# Bare numbers are deliberately NOT normalized. They usually identify the subject:
# "entry 25 lacks format" and "entry 30 lacks format" are the same class of problem on
# different entries, which is progress, not a loop. Collapsing them would halt a model
# that is correctly working through fifty entries one at a time.


def signature(gate: str, detail: str) -> str:
    """Normalize a failure so the same logical error matches across attempts."""
    text = detail.strip()
    for pattern, replacement in _NOISE:
        text = pattern.sub(replacement, text)
    text = " ".join(text.split())[:400]
    return hashlib.sha256(f"{gate}::{text}".encode("utf-8")).hexdigest()[:16]


def ledger_path(build_state: str) -> Path:
    root, state = load_build_state(build_state)
    path = resolve_state_path(root, state, "repair_ledger", required=False)
    if path is None:
        path = root / "artifacts" / LEDGER_NAME
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


def _load(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {"kind": "worldbuilder-repair-ledger", "contract": CONTRACT, "gates": {}}
    data = load_json(path)
    if not isinstance(data, dict) or "gates" not in data:
        return {"kind": "worldbuilder-repair-ledger", "contract": CONTRACT, "gates": {}}
    return data


def attempt(build_state: str, gate: str, detail: str, *,
            failure_kind: str = "failed",
            identical_limit: int = IDENTICAL_LIMIT,
            total_limit: int = TOTAL_LIMIT,
            timeout_retry_limit: int = TIMEOUT_RETRY_LIMIT) -> dict[str, Any]:
    """Record a failure and return a verdict.

    failure_kind distinguishes a genuine content/logic failure ("failed") from
    a worker that ran out of time ("timed_out"). The two are judged
    separately: a "failed" gate is scored only against its own past "failed"
    attempts, so an interleaved timeout can neither mask nor manufacture a
    repair loop, and vice versa.

    "failed" verdicts are "continue" or "stop", exactly as before: three
    identical failures, or eight total, and it stops.

    "timed_out" verdicts are "retry_with_longer_timeout" (with a suggested
    next_safety_multiplier) until timeout_retry_limit is reached, then "stop".
    Identical timeout signatures are expected and are never themselves treated
    as evidence of a loop.
    """
    if not gate.strip():
        raise_error("gate name is required")
    if not detail.strip():
        raise_error("failure detail is required; the signature is what detects the loop")
    if failure_kind not in FAILURE_KINDS:
        raise_error(f"failure_kind must be one of {sorted(FAILURE_KINDS)}")

    path = ledger_path(build_state)
    ledger = _load(path)
    row = ledger["gates"].setdefault(gate, {"attempts": [], "distinct_signatures": []})

    sig = signature(gate, detail)
    same_kind = [a for a in row["attempts"] if a.get("failure_kind", "failed") == failure_kind]
    previous = [a for a in same_kind if a.get("signature") == sig]
    progressed = bool(same_kind) and same_kind[-1].get("signature") != sig

    row["attempts"].append({
        "signature": sig,
        "failure_kind": failure_kind,
        "at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        "detail": detail.strip()[:400],
        # Progress is the useful signal: it means the last fix changed something.
        "progressed_from_previous": progressed,
    })
    if sig not in row["distinct_signatures"]:
        row["distinct_signatures"].append(sig)

    identical = len(previous) + 1
    total_same_kind = len(same_kind) + 1

    if failure_kind == "timed_out":
        stop = total_same_kind >= timeout_retry_limit
        row["status"] = "halted" if stop else "open"
        atomic_write_json(path, ledger)
        verdict: dict[str, Any] = {
            "gate": gate,
            "signature": sig,
            "failure_kind": "timed_out",
            "timeout_attempts": total_same_kind,
            "verdict": "stop" if stop else "retry_with_longer_timeout",
        }
        if stop:
            verdict["reason"] = (
                f"{total_same_kind} timeouts on this gate even after raising the multiplier; "
                "this may not be a timing problem"
            )
            verdict["instruction"] = (
                "Stop retrying and report to the user. Raising the timeout further did not "
                "help; investigate whether the task is actually hung rather than merely slow."
            )
            verdict["tried"] = [a["detail"][:160] for a in row["attempts"]]
        else:
            verdict["next_safety_multiplier"] = TIMEOUT_SAFETY_MULTIPLIER + 2 * total_same_kind
            verdict["instruction"] = (
                f"Re-dispatch the same assignment with safety_multiplier={verdict['next_safety_multiplier']} "
                "(pass it through the same computed-timeout formula, never a flat guess). "
                f"{timeout_retry_limit - total_same_kind} attempt(s) before this gate halts."
            )
        return verdict

    total = total_same_kind
    stop = identical >= identical_limit or total >= total_limit

    row["status"] = "halted" if stop else "open"
    atomic_write_json(path, ledger)

    verdict = {
        "gate": gate,
        "signature": sig,
        "failure_kind": "failed",
        "identical_failures": identical,
        "total_attempts": total,
        "distinct_failures": len(row["distinct_signatures"]),
        "progressed": progressed,
        "verdict": "stop" if stop else "continue",
    }
    if stop:
        verdict["reason"] = (
            f"the same failure has occurred {identical} times"
            if identical >= identical_limit else
            f"{total} attempts on this gate without passing"
        )
        verdict["instruction"] = (
            "Stop repairing and report to the user. Include what was tried and what "
            "changed between attempts. Do not run this gate again until they respond: "
            "another attempt spends budget on a fix that is not converging."
        )
        verdict["tried"] = [a["detail"][:160] for a in row["attempts"]]
    elif identical > 1:
        verdict["warning"] = (
            f"this exact failure has now happened {identical} times; the last change did "
            f"not affect it. {identical_limit - identical} attempt(s) before this gate halts."
        )
    return verdict


def clear(build_state: str, gate: str) -> dict[str, Any]:
    """Reset after a gate passes. Only a pass clears a counter."""
    path = ledger_path(build_state)
    ledger = _load(path)
    row = ledger["gates"].pop(gate, None)
    atomic_write_json(path, ledger)
    return {"gate": gate, "cleared": row is not None,
            "attempts_discarded": len(row["attempts"]) if row else 0}


def status(build_state: str) -> dict[str, Any]:
    ledger = _load(ledger_path(build_state))
    gates = []
    for name, row in sorted(ledger.get("gates", {}).items()):
        attempts = row.get("attempts", [])
        gates.append({
            "gate": name,
            "status": row.get("status", "open"),
            "total_attempts": len(attempts),
            "distinct_failures": len(row.get("distinct_signatures", [])),
            "stuck_on": attempts[-1]["detail"][:160] if attempts else None,
            # No progress across several attempts is the diagnostic worth surfacing.
            "made_progress": any(a.get("progressed_from_previous") for a in attempts),
        })
    halted = [g for g in gates if g["status"] == "halted"]
    return {
        "kind": "worldbuilder-repair-status",
        "gates": gates,
        "halted": [g["gate"] for g in halted],
        "note": ("Halted gates need the user, not another attempt."
                 if halted else "No gate has hit its repair budget."),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Stop repair loops that burn budget unattended.")
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("attempt", help="record a gate failure and get a verdict")
    p.add_argument("--build-state", required=True)
    p.add_argument("--gate", required=True)
    p.add_argument("--detail", required=True)
    p.add_argument("--failure-kind", choices=sorted(FAILURE_KINDS), default="failed")
    p.add_argument("--identical-limit", type=int, default=IDENTICAL_LIMIT)
    p.add_argument("--total-limit", type=int, default=TOTAL_LIMIT)
    p.add_argument("--timeout-retry-limit", type=int, default=TIMEOUT_RETRY_LIMIT)

    p = sub.add_parser("clear", help="reset a gate's counter after it passes")
    p.add_argument("--build-state", required=True)
    p.add_argument("--gate", required=True)

    p = sub.add_parser("status", help="show counters and what has been tried")
    p.add_argument("--build-state", required=True)

    args = parser.parse_args()
    try:
        if args.command == "attempt":
            result = attempt(args.build_state, args.gate, args.detail,
                             failure_kind=args.failure_kind,
                             identical_limit=args.identical_limit, total_limit=args.total_limit,
                             timeout_retry_limit=args.timeout_retry_limit)
            print(json.dumps(result, ensure_ascii=False, indent=2))
            # Non-zero on stop so a wrapper or shell loop cannot ignore the verdict.
            # retry_with_longer_timeout is not a stop: it is instruction to re-dispatch.
            return 2 if result["verdict"] == "stop" else 0
        result = clear(args.build_state, args.gate) if args.command == "clear" else status(args.build_state)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (WorldBuilderError, OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
