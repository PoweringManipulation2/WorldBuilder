#!/usr/bin/env python3
"""Configure persistent WorldBuilder interface, model, and batching preferences.

The user-owned ``config.json`` is the cross-session authority. Existing keys are
preserved. ``interface.mode`` controls whether build routes show the compact
Simple menu or the single comprehensive Advanced menu.
"""
from __future__ import annotations

import argparse
import json
import re
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from wb_common import WorldBuilderError, atomic_write_json
from model_routing import MODEL_STRATEGIES, resolve_models, validate_worker_model

MODEL_RE = re.compile(r"^[A-Za-z0-9._:-]+/[A-Za-z0-9._:/+-]+$")
INTERFACE_MODES = {"simple", "advanced"}


def iso_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def validate_model_ref(value: str) -> str:
    model = value.strip()
    if model in {"inherit", "default"}:
        return model
    if not MODEL_RE.fullmatch(model):
        raise WorldBuilderError(
            "model must be 'inherit', 'default', or a provider/model reference such as openai/gpt-5.6"
        )
    return model.casefold()


def validate_interface_mode(value: str) -> str:
    mode = value.strip().casefold()
    aliases = {"pro": "advanced", "expert": "advanced", "basic": "simple", "normal": "simple"}
    mode = aliases.get(mode, mode)
    if mode not in INTERFACE_MODES:
        raise WorldBuilderError("interface mode must be 'simple' or 'advanced'")
    return mode


def load_config(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {
            "config_version": 5,
            "created_at": iso_now(),
            "updated_at": iso_now(),
            "builds_directory": "builds",
            "default_export_root": None,
            "keep_work_files_after_success": False,
            "keep_failed_builds": True,
            "interface": {"mode": "simple"},
        }
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise WorldBuilderError(f"invalid JSON in {path}: {exc}") from exc
    if not isinstance(data, dict):
        raise WorldBuilderError("WorldBuilder config must contain a JSON object")
    return data


def run_command(command: list[str], *, dry_run: bool) -> dict[str, Any]:
    if dry_run:
        return {"command": command, "status": "planned"}
    proc = subprocess.run(command, text=True, capture_output=True, check=False)
    if proc.returncode != 0:
        raise WorldBuilderError(
            f"command failed ({proc.returncode}): {' '.join(command)}\n{proc.stdout}\n{proc.stderr}"
        )
    return {"command": command, "status": "applied", "stdout": proc.stdout.strip()}


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Set WorldBuilder interface, model, and generation-batching preferences."
    )
    parser.add_argument("--workspace", required=True, help="Approved WorldBuilder workspace root.")
    parser.add_argument(
        "--interface-mode",
        help="Persistent build-menu mode: 'simple' or 'advanced'. Aliases: basic/normal, pro/expert.",
    )
    parser.add_argument("--main-model", help="Main coordinator provider/model, or 'default'.")
    parser.add_argument("--subagent-model", help="Backward-compatible default for all WorldBuilder child workers, provider/model or 'inherit'.")
    parser.add_argument("--discovery-model", help="Discovery/research worker provider/model, or 'inherit'; defaults to --subagent-model when unset.")
    parser.add_argument("--generation-model", help="Generation/recovery worker provider/model, or 'inherit'; defaults to --subagent-model when unset.")
    parser.add_argument("--audit-model", help="Compass/Weaver/Scout/Warden provider/model, or 'inherit'; defaults to --subagent-model when unset.")
    parser.add_argument("--model-strategy", choices=MODEL_STRATEGIES, help="Role-routing preset using only your configured main/subagent models; explicit role flags override it.")
    parser.add_argument("--image-model", help="image_generate model/provider to prefer, or 'primary' to use image_generate's own default.")
    parser.add_argument("--image-fallbacks", help="Comma-separated fallback models, tried in order if --image-model errors.")
    parser.add_argument("--image-timeout-ms", type=int, help="Per-call timeout in milliseconds for image_generate (1000-600000).")
    parser.add_argument("--image-analysis-mode", choices=("on", "off"), help="Generation-worker analysis of relevant primary/infobox images. Default: on; effective only when vision is reported available.")
    parser.add_argument("--generation-batch-size", type=int, help="Maximum entries per generation subagent (1-50).")
    parser.add_argument("--discovery-retry-limit", type=int, help="Independent recovery-stage failures before a URL is treated as confirmed dead (0-5).")
    parser.add_argument("--per-uid-seconds", type=int, help="Seed estimate for run_timeout_seconds: seconds of research+write time per generation entry (10-600).")
    parser.add_argument("--per-page-seconds", type=int, help="Seed estimate for run_timeout_seconds: seconds per page for discovery workers (5-120).")
    parser.add_argument("--autonomy", choices=["consent-required", "evidence-bounded"],
                        help="How far the model may proceed without asking. Scope decisions are never self-approvable.")
    parser.add_argument("--debug-log", choices=["on", "off"],
                        help="Record failing commands with their reproduction steps.")
    parser.add_argument("--unverified-policy", choices=["disable", "deprioritize", "despecify", "ship_labeled"],
                        help="Default handling for entries the verification budget does not reach.")
    parser.add_argument("--apply-openclaw", action="store_true", help="Also update OpenClaw persistent model defaults.")
    parser.add_argument("--dry-run", action="store_true", help="Show changes without writing or running commands.")
    args = parser.parse_args()

    if (
        args.interface_mode is None
        and args.main_model is None
        and args.subagent_model is None
        and args.discovery_model is None
        and args.generation_model is None
        and args.audit_model is None
        and args.model_strategy is None
        and args.image_model is None
        and args.image_fallbacks is None
        and args.image_timeout_ms is None
        and args.image_analysis_mode is None
        and args.generation_batch_size is None
        and args.discovery_retry_limit is None
        and args.per_uid_seconds is None
        and args.per_page_seconds is None
        and args.autonomy is None
        and args.debug_log is None
        and args.unverified_policy is None
    ):
        parser.error(
            "provide at least one of --interface-mode, --main-model, --subagent-model, "
            "--discovery-model, --generation-model, --audit-model, --model-strategy, "
            "--image-model, --image-fallbacks, --image-timeout-ms, --image-analysis-mode, "
            "--generation-batch-size, --discovery-retry-limit, --per-uid-seconds, --per-page-seconds, "
            "--autonomy, --debug-log, --unverified-policy"
        )

    try:
        root = Path(args.workspace).expanduser().resolve()
        root.mkdir(parents=True, exist_ok=True)
        config_path = root / "config.json"
        config = load_config(config_path)
        models = dict(config.get("models") or {})
        batching = dict(config.get("batching") or {})
        discovery_cfg = dict(config.get("discovery") or {})
        timeouts_cfg = dict(config.get("timeouts") or {})
        interface = dict(config.get("interface") or {})
        autonomy = dict(config.get("autonomy") or {})
        debug = dict(config.get("debug") or {})
        verification = dict(config.get("verification") or {})

        interface_mode = (
            validate_interface_mode(args.interface_mode)
            if args.interface_mode is not None
            else validate_interface_mode(str(interface.get("mode", "simple")))
        )
        main_model = validate_model_ref(args.main_model) if args.main_model is not None else models.get("main")
        subagent_model = validate_worker_model(args.subagent_model, field="--subagent-model") if args.subagent_model is not None else models.get("subagent", "inherit")
        if main_model is not None:
            models["main"] = main_model
        if args.subagent_model is not None:
            models["subagent"] = subagent_model
        else:
            models.setdefault("subagent", "inherit")
        if args.model_strategy is not None:
            models["strategy"] = args.model_strategy
            # Selecting a preset replaces prior role overrides unless that role
            # is explicitly overridden in this same command.
            for role in ("discovery", "generation", "audit"):
                models.pop(role, None)
        for role, value in (
            ("discovery", args.discovery_model),
            ("generation", args.generation_model),
            ("audit", args.audit_model),
        ):
            if value is not None:
                models[role] = validate_worker_model(value, field=f"--{role}-model")
        # Resolve now so an invalid strategy/config combination fails before any
        # persistent file or OpenClaw setting is changed.  Explicit role flags
        # win over the strategy; absent roles remain dynamic fallbacks in config.
        effective_models = resolve_models(models)
        image_cfg = dict(config.get("image_generation") or {})
        image_analysis_cfg = dict(config.get("image_analysis") or {})
        image_analysis_mode = str(image_analysis_cfg.get("mode", "on")).strip().casefold()
        if image_analysis_mode not in {"on", "off"}:
            raise WorldBuilderError("config image_analysis.mode must be on or off")
        if args.image_analysis_mode is not None:
            image_analysis_mode = args.image_analysis_mode
        image_analysis_cfg["mode"] = image_analysis_mode
        if args.image_model is not None:
            stripped = args.image_model.strip()
            if not stripped:
                raise WorldBuilderError("image-model must not be blank")
            # image_generate's own model names are reported at runtime by the
            # host (image-prompts.md), not a fixed provider/model format like
            # the coordinator/subagent models above: validate_model_ref's
            # stricter pattern would reject legitimate model names.
            image_cfg["model"] = None if stripped.lower() == "primary" else stripped
        if args.image_fallbacks is not None:
            image_cfg["fallbacks"] = [m.strip() for m in args.image_fallbacks.split(",") if m.strip()]
        if args.image_timeout_ms is not None:
            # Verified against docs.openclaw.ai/tools/image-generation: Microsoft
            # Foundry MAI, xAI, and Azure OpenAI image generation default to 600s,
            # and Codex dynamic-tool calls cap at 600000ms; a 300000ms ceiling
            # would reject a legitimate value for those providers.
            if not 1000 <= args.image_timeout_ms <= 600000:
                raise WorldBuilderError("image-timeout-ms must be between 1000 and 600000")
            image_cfg["timeout_ms"] = args.image_timeout_ms

        interface["mode"] = interface_mode
        interface["updated_at"] = iso_now()
        # Tool-level preferences: they persist across builds and a build may override
        # them for itself. They do not belong in the per-build settings pages.
        if args.autonomy is not None:
            autonomy["mode"] = args.autonomy
        if args.debug_log is not None:
            debug["log_problems"] = args.debug_log == "on"
        if args.unverified_policy is not None:
            verification["unverified_policy"] = args.unverified_policy
        if args.generation_batch_size is not None:
            if not 1 <= args.generation_batch_size <= 50:
                raise WorldBuilderError("generation batch size must be between 1 and 50 entries")
            batching["generation_entries_per_worker"] = args.generation_batch_size
        batching.setdefault("generation_entries_per_worker", 15)
        if args.discovery_retry_limit is not None:
            if not 0 <= args.discovery_retry_limit <= 5:
                raise WorldBuilderError("discovery retry limit must be between 0 and 5")
            discovery_cfg["confirmed_dead_after_rounds"] = args.discovery_retry_limit
        discovery_cfg.setdefault("confirmed_dead_after_rounds", 2)
        if args.per_uid_seconds is not None:
            if not 10 <= args.per_uid_seconds <= 600:
                raise WorldBuilderError("per-uid-seconds must be between 10 and 600")
            timeouts_cfg["per_uid_seconds"] = args.per_uid_seconds
        # Generous default: research + write + gate-pass for one lorebook entry.
        # DR-064: recalibrate from gate_telemetry.py's mean-attempts-to-pass
        # data rather than guessing a tighter number from scratch.
        timeouts_cfg.setdefault("per_uid_seconds", 90)
        if args.per_page_seconds is not None:
            if not 5 <= args.per_page_seconds <= 120:
                raise WorldBuilderError("per-page-seconds must be between 5 and 120")
            timeouts_cfg["per_page_seconds"] = args.per_page_seconds
        timeouts_cfg.setdefault("per_page_seconds", 20)
        models["updated_at"] = iso_now()
        config["interface"] = interface
        if autonomy:
            config["autonomy"] = autonomy
        if debug:
            config["debug"] = debug
        if verification:
            config["verification"] = verification
        config["models"] = models
        if image_cfg:
            config["image_generation"] = image_cfg
        config["image_analysis"] = image_analysis_cfg
        config["batching"] = batching
        config["discovery"] = discovery_cfg
        config["config_version"] = max(6, int(config.get("config_version", 0) or 0))
        config.setdefault("created_at", iso_now())
        config["updated_at"] = iso_now()

        commands: list[list[str]] = []
        if args.apply_openclaw:
            if shutil.which("openclaw") is None:
                raise WorldBuilderError("openclaw executable is not available")
            if main_model and main_model != "default":
                commands.append(["openclaw", "models", "set", main_model])
            if subagent_model:
                value = "" if subagent_model == "inherit" else subagent_model
                commands.append(["openclaw", "config", "set", "agents.defaults.subagents.model", value])
            if image_cfg.get("model"):
                commands.append(["openclaw", "config", "set", "agents.defaults.mediaModels.image.primary", image_cfg["model"]])
            if image_cfg.get("fallbacks"):
                commands.append(["openclaw", "config", "set", "agents.defaults.mediaModels.image.fallbacks", ",".join(image_cfg["fallbacks"])])
            if image_cfg.get("timeout_ms"):
                commands.append(["openclaw", "config", "set", "agents.defaults.mediaModels.image.timeoutMs", str(image_cfg["timeout_ms"])])
            commands.append(["openclaw", "config", "validate"])

        result = {
            "config_path": str(config_path),
            "interface": {
                "mode": interface_mode,
                "menu_behavior": (
                    "one comprehensive Advanced build menu" if interface_mode == "advanced" else "compact Simple build menu"
                ),
            },
            "models": effective_models,
            "image_generation": image_cfg if image_cfg else None,
            "image_analysis": image_analysis_cfg,
            "batching": {"generation_entries_per_worker": batching["generation_entries_per_worker"]},
            "discovery": {"confirmed_dead_after_rounds": discovery_cfg["confirmed_dead_after_rounds"]},
            "openclaw_commands": [run_command(command, dry_run=args.dry_run) for command in commands],
            "note": (
                "Interface mode persists in the approved WorldBuilder workspace and affects future sessions/builds. "
                "A persistent main-model change applies to new or unpinned sessions; use /model default in an "
                "already pinned OpenClaw session to inherit it. Role-specific WorldBuilder models are frozen per build "
                "and passed as explicit sessions_spawn.model overrides; --apply-openclaw changes only the shared main/subagent defaults."
            ),
        }
        if not args.dry_run:
            atomic_write_json(config_path, config)
        print(json.dumps(result, indent=2, ensure_ascii=False))
        return 0
    except (WorldBuilderError, OSError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
