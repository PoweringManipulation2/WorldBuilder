#!/usr/bin/env python3
"""Resolve, prepare, and apply UID-scoped regeneration without touching unrelated entries.

This extends Batch 12/13 scoped invalidation and audit machinery.  It does not
dispatch workers itself: it produces a concrete UID scope and preserves a
baseline; the host regenerates only those UIDs through the existing entry-cycle
contract, then this module applies the resulting replacement entries and emits
a normal change-set for ``audit_plan.py --scope changed``.
"""
from __future__ import annotations

import argparse
import copy
import json
import os
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

from activation_test_corpus import check as check_activation_test_corpus
from activation_semantics import manifest_entries, profile_defaults, resolved_emit
from change_set import CONTRACT as CHANGE_SET_CONTRACT
from lock_contract import assert_write_allowed, is_locked, lock_reason
from lineage_invalidate import invalidate as invalidate_lineage
from pipeline_stage_gate import amendment_scope_details, amendment_scope_message, load_ledger as load_pipeline_ledger
from wb_common import (
    WorldBuilderError,
    atomic_write_json,
    build_identity_index,
    canonical_entry_identity,
    entry_binding_hash,
    iter_entries,
    load_build_state,
    load_json,
    normalize_identity,
    resolve_state_path,
    sha256_file,
)

CONTRACT = "worldbuilder-selective-regeneration-v1"
SCOPE_KINDS = frozenset({"uids", "layer", "source", "detail"})


def _stamp() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")


def _manifest_edges(manifest: dict[str, Any]) -> list[dict[str, Any]]:
    graph = manifest.get("activation_graph")
    edges = graph.get("edges") if isinstance(graph, dict) else None
    return [row for row in edges if isinstance(row, dict)] if isinstance(edges, list) else []


def neighbour_uids(manifest: dict[str, Any], changed_uids: Iterable[str]) -> list[str]:
    changed = {str(uid) for uid in changed_uids}
    neighbours: set[str] = set()
    for edge in _manifest_edges(manifest):
        source = edge.get("source_uid")
        target = edge.get("target_uid")
        if source is None or target is None:
            continue
        source, target = str(source), str(target)
        if source in changed and target not in changed:
            neighbours.add(target)
        if target in changed and source not in changed:
            neighbours.add(source)
    return sorted(neighbours)


def _evidence_uids_for_source(evidence_paths: Iterable[Path], locator: str) -> set[str]:
    wanted = locator.strip()
    matched: set[str] = set()
    for path in evidence_paths:
        try:
            data = load_json(path)
        except (OSError, json.JSONDecodeError, UnicodeDecodeError):
            continue
        entries = data.get("entries") if isinstance(data, dict) else None
        if not isinstance(entries, list):
            continue
        for record in entries:
            if not isinstance(record, dict) or record.get("uid") is None:
                continue
            sources = record.get("sources")
            if not isinstance(sources, list):
                continue
            if any(isinstance(src, dict) and str(src.get("locator", "")).strip() == wanted for src in sources):
                matched.add(str(record["uid"]))
    return matched


def resolve_scope(
    manifest: dict[str, Any],
    *,
    scope_kind: str,
    uids: Iterable[str] = (),
    layer: str | None = None,
    source_locator: str | None = None,
    evidence_paths: Iterable[Path] = (),
) -> dict[str, Any]:
    if scope_kind not in SCOPE_KINDS:
        raise WorldBuilderError(f"unknown regeneration scope kind {scope_kind!r}")
    index = build_identity_index(manifest)
    selected: set[str] = set()
    mode = "research_and_write"

    if scope_kind in {"uids", "detail"}:
        requested = {str(normalize_identity(uid)) for uid in uids}
        missing = sorted(uid for uid in requested if normalize_identity(uid) not in index)
        if missing:
            raise WorldBuilderError(f"regeneration scope names unknown UID(s): {', '.join(missing)}")
        selected = requested
        if scope_kind == "detail":
            mode = "write_only"
    elif scope_kind == "layer":
        if not isinstance(layer, str) or not layer.strip():
            raise WorldBuilderError("layer scope requires a non-empty layer")
        wanted = layer.strip().casefold()
        for identity, (_path, entry) in index.items():
            architecture = entry.get("architecture") if isinstance(entry, dict) else None
            value = architecture.get("layer") if isinstance(architecture, dict) else entry.get("layer") if isinstance(entry, dict) else None
            if isinstance(value, str) and value.strip().casefold() == wanted:
                selected.add(str(identity))
    elif scope_kind == "source":
        if not isinstance(source_locator, str) or not source_locator.strip():
            raise WorldBuilderError("source scope requires a non-empty source locator")
        selected = _evidence_uids_for_source(evidence_paths, source_locator)
        if not selected:
            raise WorldBuilderError(
                f"no evidence ledger entry cites source {source_locator!r}; source-derived regeneration must resolve through claim/evidence provenance"
            )

    if not selected:
        raise WorldBuilderError("regeneration scope resolved to zero UIDs")

    included: list[str] = []
    excluded: list[dict[str, Any]] = []
    for uid in sorted(selected, key=lambda value: (not value.isdigit(), int(value) if value.isdigit() else value)):
        key = normalize_identity(uid)
        entry = index[key][1]
        if is_locked(entry):
            excluded.append({"uid": uid, "reason": lock_reason(entry), "name": entry.get("name") or entry.get("comment")})
        else:
            included.append(uid)
    if not included:
        raise WorldBuilderError("every UID in the requested regeneration scope is author-locked")

    return {
        "contract": CONTRACT,
        "scope_kind": scope_kind,
        "regeneration_mode": mode,
        "requested_uids": sorted(selected),
        "resolved_uids": included,
        "locked_exclusions": excluded,
        "neighbour_affected_uids": neighbour_uids(manifest, included),
    }


def _entries_by_identity(data: Any) -> dict[Any, dict[str, Any]]:
    return {identity: entry for identity, (_path, entry) in build_identity_index(data).items()}


def apply_replacements(base_data: Any, regenerated_data: Any, resolved_uids: Iterable[str]) -> tuple[Any, dict[str, Any]]:
    """Replace only resolved UIDs and prove every other entry hash stayed identical."""
    requested = {normalize_identity(uid) for uid in resolved_uids}
    before_index = _entries_by_identity(base_data)
    regenerated_index = _entries_by_identity(regenerated_data)
    missing = sorted(str(uid) for uid in requested if uid not in regenerated_index)
    extra = sorted(str(uid) for uid in regenerated_index if uid not in requested)
    if missing:
        raise WorldBuilderError(f"regenerated payload is missing requested UID(s): {', '.join(missing)}")
    if extra:
        raise WorldBuilderError(f"regenerated payload contains unrequested UID(s): {', '.join(extra)}")
    unknown = sorted(str(uid) for uid in requested if uid not in before_index)
    if unknown:
        raise WorldBuilderError(f"baseline artifact has no requested UID(s): {', '.join(unknown)}")

    result = copy.deepcopy(base_data)
    result_index = build_identity_index(result)
    for uid in requested:
        _path, target_entry = result_index[uid]
        replacement = copy.deepcopy(regenerated_index[uid])
        # Batch 58 / A02: enforce the lock against the artifact being written, at
        # write time. Planning excluded UIDs that were already locked, but a lock
        # added after prepare, or relocated by a portable export, would otherwise
        # be silently overwritten here.
        existing_lock = copy.deepcopy((target_entry.get("architecture") or {}).get("lock")) if isinstance(target_entry.get("architecture"), dict) else None
        if is_locked(target_entry) and replacement != target_entry:
            changed = sorted(
                key for key in set(replacement) | set(target_entry)
                if replacement.get(key) != target_entry.get(key)
            )
            assert_write_allowed(target_entry, changed, operation="selective-regeneration apply")
        target_entry.clear()
        target_entry.update(replacement)
        if existing_lock is not None:
            target_entry.setdefault("architecture", {})["lock"] = existing_lock

    after_index = _entries_by_identity(result)
    untouched = sorted(set(before_index) - requested, key=str)
    drifted = [str(uid) for uid in untouched if entry_binding_hash(before_index[uid]) != entry_binding_hash(after_index[uid])]
    if drifted:
        raise WorldBuilderError(f"selective regeneration modified untouched UID(s): {', '.join(drifted)}")
    proof = {
        "resolved_uids": sorted(str(uid) for uid in requested),
        "untouched_uid_count": len(untouched),
        "untouched_hashes_preserved": True,
        "before_hashes": {str(uid): entry_binding_hash(before_index[uid]) for uid in untouched},
        "after_hashes": {str(uid): entry_binding_hash(after_index[uid]) for uid in untouched},
    }
    return result, proof


def prepare(build_state: str, scope: dict[str, Any]) -> dict[str, Any]:
    state_path = Path(build_state).resolve()
    root, state = load_build_state(state_path)
    manifest_path = resolve_state_path(root, state, "manifest")
    manifest = load_json(manifest_path)
    activation_tests = check_activation_test_corpus(str(state_path), write_receipt=True, freeze_if_needed=True, enforce=True)
    resolved = list(scope["resolved_uids"])
    neighbours = list(scope["neighbour_affected_uids"])

    # Batch 40: surface the amendment-scope safety cap before copying a
    # baseline or invalidating any lineage. Planning is warning-only: callers
    # still receive the complete resolved scope and exact arithmetic so they
    # can decide whether to split the work or re-baseline.
    ledger = load_pipeline_ledger(root, state)
    amendments = ledger.get("amendments") if isinstance(ledger.get("amendments"), list) else []
    preflight_change_set = {
        "contract": CHANGE_SET_CONTRACT,
        "changed_uids": resolved,
        "neighbour_affected_uids": neighbours,
        "structural": False,
        "structural_diffs": [],
        "source": "selective_regeneration",
    }
    scope_details = amendment_scope_details(preflight_change_set, len(manifest_entries(manifest)), len(amendments))
    amendment_candidate = ledger.get("current_stage") == "delivery_permitted" or bool(amendments)
    scope_details["applies_to_current_plan"] = amendment_candidate
    scope_warning = None
    if amendment_candidate and (scope_details["depth_cap_reached"] or scope_details["over_fraction_cap"]):
        scope_warning = amendment_scope_message(scope_details) + " -> re-baseline required"
        preflight_root = root / ".work" / "regeneration" / _stamp()
        preflight_root.mkdir(parents=True, exist_ok=False)
        plan = {
            **scope,
            "kind": "worldbuilder-selective-regeneration-plan",
            "plan_version": 2,
            "build_id": state.get("build_id"),
            "manifest_sha256": sha256_file(manifest_path),
            "amendment_scope": scope_details,
            "warnings": [scope_warning],
            "lineage_invalidation": None,
            "change_set": None,
            "blocked_before_invalidation": True,
            "next": "Re-baseline this build, or reduce the resolved changed-plus-neighbour scope to fit the amendment cap before preparing the change.",
        }
        plan_path = preflight_root / "plan.json"
        atomic_write_json(plan_path, plan)
        return {"status": "amendment_scope_warning", "plan": str(plan_path), "plan_data": plan, "warning": scope_warning}

    base = resolve_state_path(root, state, "merge_input", required=False)
    if base is None or not base.exists():
        base = resolve_state_path(root, state, "final_output", required=False)
    if base is None or not base.exists():
        raise WorldBuilderError("selective regeneration requires an existing merge/final artifact baseline")

    regen_root = root / ".work" / "regeneration" / _stamp()
    regen_root.mkdir(parents=True, exist_ok=False)
    baseline = regen_root / "baseline.json"
    shutil.copy2(base, baseline)
    change_set = preflight_change_set
    change_set_path = regen_root / "change-set.json"
    atomic_write_json(change_set_path, change_set)
    invalidation = invalidate_lineage(
        str(state_path), "manifest",
        "selective regeneration scope prepared",
        change_set_path=str(change_set_path),
        preserve_evidence=scope.get("regeneration_mode") == "write_only",
    )
    plan = {
        **scope,
        "kind": "worldbuilder-selective-regeneration-plan",
        "plan_version": 2,
        "build_id": state.get("build_id"),
        "amendment_scope": scope_details,
        "warnings": [],
        "blocked_before_invalidation": False,
        "manifest_sha256": sha256_file(manifest_path),
        "baseline": str(baseline.relative_to(root)).replace(os.sep, "/"),
        "baseline_sha256": sha256_file(baseline),
        # Batch 58 / A01: bind the file this apply will overwrite, and its bytes.
        # Without this, apply rebuilt the baseline and silently reverted any edit
        # made to the target between prepare and apply while still reporting the
        # untouched hashes as preserved (it compared against the baseline).
        "target": str(base.relative_to(root)).replace(os.sep, "/"),
        "target_sha256": sha256_file(base),
        "lineage_invalidation": invalidation,
        "change_set": str(change_set_path.relative_to(root)).replace(os.sep, "/"),
        "activation_test_corpus_status": activation_tests.get("status"),
        "activation_test_corpus_sha256": activation_tests.get("corpus_sha256"),
        "next": (
            "Regenerate only resolved_uids through the existing entry-cycle gate; use research_and_write except "
            "detail scopes, which are write_only. Then run selective_regeneration.py apply and audit_plan.py --scope changed."
        ),
    }
    plan_path = regen_root / "plan.json"
    atomic_write_json(plan_path, plan)
    return {"status": "prepared", "plan": str(plan_path), "plan_data": plan}


def apply(build_state: str, plan_path: str, regenerated_path: str) -> dict[str, Any]:
    state_path = Path(build_state).resolve()
    root, state = load_build_state(state_path)
    plan_file = Path(plan_path).resolve()
    plan = load_json(plan_file)
    if plan.get("kind") != "worldbuilder-selective-regeneration-plan" or plan.get("build_id") != state.get("build_id"):
        raise WorldBuilderError("regeneration plan is invalid or belongs to another build")
    baseline = (root / str(plan["baseline"])).resolve()
    if sha256_file(baseline) != plan.get("baseline_sha256"):
        raise WorldBuilderError("regeneration baseline changed after planning")
    regenerated = Path(regenerated_path).resolve()
    try:
        regenerated.relative_to(root)
    except ValueError as exc:
        raise WorldBuilderError("regenerated payload must stay inside the build workspace") from exc
    # The manifest may have changed while the regeneration work was in flight.
    # Re-prove persisted activation expectations before mutating the baseline.
    activation_tests = check_activation_test_corpus(str(state_path), write_receipt=True, freeze_if_needed=False, enforce=True)
    target = (root / str(plan["target"])).resolve() if plan.get("target") else (
        resolve_state_path(root, state, "merge_input", required=False) or resolve_state_path(root, state, "final_output")
    )
    if not target.exists() or not target.is_file():
        raise WorldBuilderError(f"selective regeneration target does not exist at {target}")
    current_target_sha = sha256_file(target)
    planned_target_sha = plan.get("target_sha256")
    if not plan.get("target") or not planned_target_sha:
        raise WorldBuilderError(
            "selective regeneration plan is not bound to target bytes (legacy/unbound plan). "
            "Re-run selective_regeneration.py prepare against the current artifact before applying it."
        )
    if current_target_sha != planned_target_sha:
        raise WorldBuilderError(
            f"selective regeneration target changed after planning: {plan.get('target')} was {planned_target_sha} at plan time "
            f"but is now {current_target_sha}. Applying now would revert whatever changed in between. Re-run "
            "selective_regeneration.py prepare against the current target, or restore the planned bytes, then apply again."
        )
    baseline_data = load_json(baseline)
    regenerated_data = load_json(regenerated)
    # Re-check authoritative manifest locks at apply time as well as locks on
    # the artifact bytes. A user may lock an entry in the manifest after the
    # regeneration plan was prepared without touching the current artifact.
    manifest_now = load_json(resolve_state_path(root, state, "manifest"))
    manifest_index = _entries_by_identity(manifest_now)
    baseline_index = _entries_by_identity(baseline_data)
    regenerated_index = _entries_by_identity(regenerated_data)
    for raw_uid in plan["resolved_uids"]:
        uid = normalize_identity(raw_uid)
        authority = manifest_index.get(uid)
        if authority is None or not is_locked(authority):
            continue
        before = baseline_index.get(uid, {})
        replacement = regenerated_index.get(uid, {})
        changed = sorted(
            key for key in set(before) | set(replacement)
            if before.get(key) != replacement.get(key)
        )
        assert_write_allowed(authority, changed, operation="selective-regeneration apply")
    result, proof = apply_replacements(baseline_data, regenerated_data, plan["resolved_uids"])
    atomic_write_json(target, result)
    proof.update({
        "target": str(target.relative_to(root)).replace(os.sep, "/"),
        "target_sha256": sha256_file(target),
        "planned_target_sha256": planned_target_sha,
        "target_unchanged_since_prepare": True,
    })
    proof_path = plan_file.parent / "apply-proof.json"
    atomic_write_json(proof_path, proof)
    return {
        "status": "applied",
        "proof": str(proof_path),
        "change_set": str((root / str(plan["change_set"])).resolve()),
        "resolved_uids": plan["resolved_uids"],
        "locked_exclusions": plan.get("locked_exclusions", []),
        "activation_test_corpus_status": activation_tests.get("status"),
        "activation_test_corpus_sha256": activation_tests.get("corpus_sha256"),
        "next": "Run audit_plan.py --scope changed --change-set <change_set> and complete the ordinary audit/validation/delivery path.",
    }


def _entry_content_hash(entry: dict[str, Any]) -> str:
    import hashlib
    return hashlib.sha256(str(entry.get("content", "")).encode("utf-8")).hexdigest()


def _apply_resolved_metadata(target_entry: dict[str, Any], resolved: dict[str, Any]) -> None:
    """Project manifest-owned activation metadata without touching prose."""
    target_entry["keys"] = copy.deepcopy(resolved["primary_keywords"])
    target_entry["secondary_keys"] = copy.deepcopy(resolved["secondary_keywords"])
    for key in ("enabled", "insertion_order", "use_regex", "constant", "selective", "position", "case_sensitive"):
        target_entry[key] = copy.deepcopy(resolved[key])
    extensions = target_entry.get("extensions") if isinstance(target_entry.get("extensions"), dict) else {}
    target_entry["extensions"] = extensions
    ext_fields = {
        "vectorized": "vectorized", "selectiveLogic": "secondary_logic", "match_scenario": "match_scenario",
        "priority": "priority", "use_probability": "use_probability", "probability": "probability",
        "prevent_recursion": "prevent_recursion", "exclude_recursion": "exclude_recursion",
        "delay_until_recursion": "delay_until_recursion", "sticky": "sticky", "cooldown": "cooldown",
        "delay": "delay", "depth": "depth", "role": "role", "group": "group",
        "group_weight": "group_weight", "group_override": "group_override", "group_scoring": "group_scoring",
        "character_filter": "character_filter", "generation_triggers": "generation_triggers",
        "automation_id": "automation_id", "outlet": "outlet",
    }
    for out_key, resolved_key in ext_fields.items():
        value = copy.deepcopy(resolved.get(resolved_key))
        if value is None or value == []:
            extensions.pop(out_key, None)
        else:
            extensions[out_key] = value


def metadata_reemit(build_state: str, change_set_path: str, *, target_path: str | None = None) -> dict[str, Any]:
    """Re-emit only manifest-owned activation metadata for a changed UID slice.

    No research or prose generation occurs. Every entry's content hash is checked
    before and after, and unrelated entry binding hashes must remain unchanged.
    """
    state_path = Path(build_state).resolve()
    root, state = load_build_state(state_path)
    change_path = Path(change_set_path).expanduser().resolve()
    change = load_json(change_path)
    if not isinstance(change, dict) or change.get("contract") != CHANGE_SET_CONTRACT:
        raise WorldBuilderError("metadata re-emission requires a recognized change-set JSON")
    if change.get("structural"):
        raise WorldBuilderError("metadata-only re-emission cannot be used for a structural change set")
    changed = [str(uid) for uid in change.get("changed_uids", [])]
    if not changed:
        raise WorldBuilderError("metadata-only re-emission change set has no changed_uids")
    manifest_path = resolve_state_path(root, state, "manifest")
    profile_path = resolve_state_path(root, state, "default_profile")
    manifest = load_json(manifest_path)
    profile = load_json(profile_path)
    rows = {str(row.get("uid", row.get("id"))): row for row in manifest_entries(manifest)}
    missing_manifest = [uid for uid in changed if uid not in rows]
    if missing_manifest:
        raise WorldBuilderError("metadata-only re-emission cannot add/remove UIDs: " + ", ".join(missing_manifest))

    if target_path:
        target = Path(target_path).expanduser().resolve()
        try:
            target.relative_to(root)
        except ValueError as exc:
            raise WorldBuilderError("metadata re-emission target must stay inside the build workspace") from exc
    else:
        target = resolve_state_path(root, state, "merge_input", required=False)
        if target is None or not target.exists():
            target = resolve_state_path(root, state, "final_output", required=False)
    if target is None or not target.exists():
        raise WorldBuilderError("metadata-only re-emission requires an existing merge/final artifact baseline")

    data = load_json(target)
    before_index = build_identity_index(data)
    before_binding = {str(uid): entry_binding_hash(entry) for uid, (_path, entry) in before_index.items()}
    before_content = {str(uid): _entry_content_hash(entry) for uid, (_path, entry) in before_index.items()}
    changed_norm = {str(normalize_identity(uid)) for uid in changed}
    missing_target = sorted(uid for uid in changed_norm if uid not in {str(k) for k in before_index})
    if missing_target:
        raise WorldBuilderError("artifact baseline has no changed UID(s): " + ", ".join(missing_target))

    target_by_string = {str(uid): entry for uid, (_path, entry) in before_index.items()}
    resolved_rows: list[dict[str, Any]] = []
    for uid in changed:
        row = rows[uid]
        arch = row.get("architecture") if isinstance(row.get("architecture"), dict) else {}
        layer = arch.get("layer")
        if not isinstance(layer, str) or not layer.strip():
            raise WorldBuilderError(f"manifest UID {uid} has no architecture.layer")
        resolved = resolved_emit(row, profile_defaults(profile, layer))
        target_entry = target_by_string[str(normalize_identity(uid))]
        candidate = copy.deepcopy(target_entry)
        _apply_resolved_metadata(candidate, resolved)
        changed_fields = sorted(
            key for key in set(candidate) | set(target_entry)
            if candidate.get(key) != target_entry.get(key)
        )
        # Enforce both current artifact locks and authoritative manifest locks.
        assert_write_allowed(target_entry, changed_fields, operation="metadata re-emission")
        assert_write_allowed(row, changed_fields, operation="metadata re-emission")
        target_entry.clear(); target_entry.update(candidate)
        resolved_rows.append({"uid": uid, "recursion_role": (row.get("activation") or {}).get("recursion_role"), "prevent_recursion": resolved.get("prevent_recursion")})

    after_index = build_identity_index(data)
    after_content = {str(uid): _entry_content_hash(entry) for uid, (_path, entry) in after_index.items()}
    if before_content != after_content:
        drift = sorted(uid for uid in set(before_content) | set(after_content) if before_content.get(uid) != after_content.get(uid))
        raise WorldBuilderError("metadata-only re-emission changed prose/content for UID(s): " + ", ".join(drift))
    unrelated = sorted(set(before_binding) - changed_norm)
    after_binding = {str(uid): entry_binding_hash(entry) for uid, (_path, entry) in after_index.items()}
    drift = [uid for uid in unrelated if before_binding.get(uid) != after_binding.get(uid)]
    if drift:
        raise WorldBuilderError("metadata-only re-emission modified unrelated UID(s): " + ", ".join(drift))

    atomic_write_json(target, data)
    receipt = {
        "kind": "worldbuilder-metadata-reemit-receipt", "receipt_version": 1,
        "build_id": state.get("build_id"), "change_set": str(change_path),
        "change_set_sha256": sha256_file(change_path), "target": str(target.relative_to(root)).replace(os.sep, "/"),
        "target_sha256": sha256_file(target), "changed_uids": changed, "content_hashes_preserved": True,
        "unrelated_binding_hashes_preserved": True, "resolved": resolved_rows,
    }
    receipt_dir = root / ".work" / "metadata-reemit"
    receipt_dir.mkdir(parents=True, exist_ok=True)
    receipt_path = receipt_dir / f"{_stamp()}.json"
    atomic_write_json(receipt_path, receipt)
    state.setdefault("amendment", {}).setdefault("pending", {}).update({
        "change_set": str(change_path.relative_to(root)).replace(os.sep, "/") if change_path.is_relative_to(root) else str(change_path),
        "phase": "changed_scope_audit", "metadata_reemit_receipt": str(receipt_path.relative_to(root)).replace(os.sep, "/"),
        "metadata_reemit_sha256": sha256_file(receipt_path),
    })
    atomic_write_json(state_path, state)
    return {"status": "metadata_reemitted", "receipt": str(receipt_path), "target": str(target), "changed_uids": changed,
            "content_hashes_preserved": True, "unrelated_binding_hashes_preserved": True,
            "next": f"Run audit_plan.py --build-state {state_path} --stage post-generation --scope changed --change-set {change_path}"}


def _evidence_paths(root: Path, state: dict[str, Any]) -> list[Path]:
    result: list[Path] = []
    for key in ("evidence_receipts", "findings"):
        directory = resolve_state_path(root, state, key, required=False)
        if directory and directory.is_dir():
            result.extend(sorted(directory.rglob("*.json")))
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--build-state", required=True)
    sub = parser.add_subparsers(dest="command", required=True)
    plan_p = sub.add_parser("plan")
    scope = plan_p.add_mutually_exclusive_group(required=True)
    scope.add_argument("--uid", action="append", dest="uids")
    scope.add_argument("--layer")
    scope.add_argument("--source")
    scope.add_argument("--detail-uid", action="append", dest="detail_uids")
    apply_p = sub.add_parser("apply")
    apply_p.add_argument("--plan", required=True)
    apply_p.add_argument("--regenerated", required=True)
    metadata_p = sub.add_parser("metadata-reemit", help="Re-emit only manifest-owned activation metadata for a change-set UID slice; never regenerates prose.")
    metadata_p.add_argument("--change-set", required=True)
    metadata_p.add_argument("--target")
    args = parser.parse_args()
    try:
        if args.command == "apply":
            result = apply(args.build_state, args.plan, args.regenerated)
        elif args.command == "metadata-reemit":
            result = metadata_reemit(args.build_state, args.change_set, target_path=args.target)
        else:
            root, state = load_build_state(args.build_state)
            manifest = load_json(resolve_state_path(root, state, "manifest"))
            if args.uids:
                scope_result = resolve_scope(manifest, scope_kind="uids", uids=args.uids)
            elif args.detail_uids:
                scope_result = resolve_scope(manifest, scope_kind="detail", uids=args.detail_uids)
            elif args.layer:
                scope_result = resolve_scope(manifest, scope_kind="layer", layer=args.layer)
            else:
                scope_result = resolve_scope(
                    manifest, scope_kind="source", source_locator=args.source, evidence_paths=_evidence_paths(root, state)
                )
            result = prepare(args.build_state, scope_result)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (WorldBuilderError, OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
