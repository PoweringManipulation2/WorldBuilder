#!/usr/bin/env python3
"""Record build problems and the exact steps that produced them.

Hand-written field logs have been the most useful input this project receives, and the
part that makes them actionable is the reproduction command. A symptom without the
invocation that caused it needs a conversation; a symptom with it needs a fix.

`capture` is the mode that matters: it runs a command, and on failure records the exact
argv, exit code, stderr, and the pipeline stage it happened in. The reproduction step is
captured by construction rather than remembered afterwards.

Append-only JSONL, so a crashed run keeps everything recorded before it.

Privacy: records commands, exit codes, and tool output. It never reads chat logs or
artifact content, and `export` rewrites the workspace root to `<workspace>` so a log can
be shared without leaking a home directory.

Commands:
    capture   run a command; record it if it fails
    record    append a problem by hand
    resolve   attach a resolution to the most recent open problem
    report    summary grouped by category
    export    shareable markdown log
"""
from __future__ import annotations

import argparse
import json
import shlex
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

from wb_common import WorldBuilderError, load_build_state, raise_error, resolve_state_path

CONTRACT = "worldbuilder-debug-log-v1"
LOG_NAME = "debug-log.jsonl"
SEVERITIES = ("low", "medium", "high", "blocker")

# Recognised failure shapes, so a report can group by cause rather than by message.
CATEGORIES = {
    "gate_block": ("gate refused to pass", ("gate", "refused", "does not prove", "is stale")),
    "schema": ("artifact shape or field validation", ("must be", "is not a", "invalid", "expected")),
    "missing_artifact": ("required file absent", ("is missing", "not found", "no such file")),
    "version_sync": ("producer/consumer version disagreement", ("receipt_version", "not supported")),
    "staleness": ("hash binding no longer matches", ("stale", "sha256", "mismatch")),
    "consent": ("needs a decision only the user can make", ("consent", "approval", "user-confirmation")),
    "environment": ("host, network, or dependency", ("connection", "timeout", "unreachable", "docker")),
}


def log_path(build_state: str) -> Path:
    root, state = load_build_state(build_state)
    path = resolve_state_path(root, state, "debug_log", required=False)
    if path is None:
        path = root / "artifacts" / LOG_NAME
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


def enabled(build_state: str) -> bool:
    _root, state = load_build_state(build_state)
    debug = state.get("debug") if isinstance(state.get("debug"), dict) else {}
    return bool(debug.get("log_problems"))


def current_stage(build_state: str) -> str | None:
    """Best-effort stage label so a problem can be placed in the pipeline."""
    try:
        root, state = load_build_state(build_state)
        ledger = resolve_state_path(root, state, "pipeline_stage_ledger", required=False)
        if ledger and ledger.exists():
            data = json.loads(ledger.read_text(encoding="utf-8"))
            stages = data.get("stages") if isinstance(data, dict) else None
            if isinstance(stages, list) and stages:
                last = [s for s in stages if isinstance(s, dict)]
                if last:
                    return str(last[-1].get("stage"))
    except Exception:  # noqa: BLE001 - a stage label is a nicety, never a failure cause
        return None
    return None


def classify(text: str) -> str:
    folded = text.casefold()
    for name, (_label, markers) in CATEGORIES.items():
        if any(marker in folded for marker in markers):
            return name
    return "other"


def append(path: Path, row: dict[str, Any]) -> dict[str, Any]:
    row.setdefault("recorded_at", time.strftime("%Y-%m-%dT%H:%M:%S%z"))
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(row, ensure_ascii=False) + "\n")
    return row


def read(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        return []
    rows = []
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            row = json.loads(line)
        except json.JSONDecodeError:
            continue  # a truncated final line must not lose the rest
        if isinstance(row, dict):
            rows.append(row)
    return rows


def capture(build_state: str, command: list[str], *, always: bool = False) -> dict[str, Any]:
    """Run a command; record it if it fails.

    The reproduction step is the argv, captured here rather than reconstructed later.
    """
    if not command:
        raise_error("no command given to capture")
    started = time.time()
    proc = subprocess.run(command, capture_output=True, text=True, check=False)
    duration = round(time.time() - started, 2)

    failed = proc.returncode != 0
    if not (failed or always):
        return {"recorded": False, "returncode": 0, "duration_seconds": duration}
    if not enabled(build_state):
        return {"recorded": False, "reason": "debug logging is off for this build",
                "returncode": proc.returncode}

    stderr = (proc.stderr or "").strip()
    stdout = (proc.stdout or "").strip()
    detail = stderr or stdout
    row = append(log_path(build_state), {
        "kind": "worldbuilder-debug-entry",
        "contract": CONTRACT,
        "status": "open" if failed else "note",
        "severity": "blocker" if failed else "low",
        "category": classify(detail) if failed else "other",
        "stage": current_stage(build_state),
        "reproduce": " ".join(shlex.quote(part) for part in command),
        "returncode": proc.returncode,
        "duration_seconds": duration,
        # Tail only: the first line is usually a traceback header and the last is the cause.
        "detail": detail[-1500:],
        "resolution": None,
    })
    return {"recorded": True, "returncode": proc.returncode, "category": row["category"],
            "stage": row["stage"], "log": str(log_path(build_state))}


def record(build_state: str, *, problem: str, reproduce: str = "", severity: str = "medium",
           category: str | None = None) -> dict[str, Any]:
    if severity not in SEVERITIES:
        raise_error(f"severity must be one of {SEVERITIES}")
    if not problem.strip():
        raise_error("problem description is required")
    if not enabled(build_state):
        return {"recorded": False, "reason": "debug logging is off for this build"}
    return append(log_path(build_state), {
        "kind": "worldbuilder-debug-entry",
        "contract": CONTRACT,
        "status": "open",
        "severity": severity,
        "category": category or classify(problem),
        "stage": current_stage(build_state),
        "reproduce": reproduce,
        "detail": problem.strip(),
        "resolution": None,
    })


def resolve(build_state: str, resolution: str, *, index: int | None = None) -> dict[str, Any]:
    """Attach a resolution. A problem without one teaches nothing next time."""
    if not resolution.strip():
        raise_error("resolution text is required")
    path = log_path(build_state)
    rows = read(path)
    open_rows = [i for i, r in enumerate(rows) if r.get("status") == "open"]
    if not open_rows:
        raise_error("no open problems to resolve")
    target = index if index is not None else open_rows[-1]
    if target not in open_rows:
        raise_error(f"entry {target} is not an open problem; open entries are {open_rows}")
    rows[target]["status"] = "resolved"
    rows[target]["resolution"] = resolution.strip()
    rows[target]["resolved_at"] = time.strftime("%Y-%m-%dT%H:%M:%S%z")
    path.write_text("".join(json.dumps(r, ensure_ascii=False) + "\n" for r in rows), encoding="utf-8")
    return {"resolved_index": target, "problem": rows[target]["detail"][:120]}


def report(build_state: str) -> dict[str, Any]:
    rows = read(log_path(build_state))
    by_category: dict[str, int] = {}
    for row in rows:
        by_category[row.get("category", "other")] = by_category.get(row.get("category", "other"), 0) + 1
    open_rows = [r for r in rows if r.get("status") == "open"]
    repeated = {}
    for row in rows:
        key = row.get("reproduce") or row.get("detail", "")[:80]
        repeated[key] = repeated.get(key, 0) + 1
    return {
        "kind": "worldbuilder-debug-report",
        "entry_count": len(rows),
        "open_count": len(open_rows),
        "by_category": dict(sorted(by_category.items(), key=lambda kv: -kv[1])),
        # A command that failed repeatedly is usually one fix attempted several ways.
        "repeated_failures": [{"reproduce": k, "count": v}
                              for k, v in sorted(repeated.items(), key=lambda kv: -kv[1]) if v > 1][:5],
        "open_problems": [{"category": r.get("category"), "stage": r.get("stage"),
                           "detail": (r.get("detail") or "")[:200]} for r in open_rows],
    }


def export(build_state: str) -> str:
    """Markdown log, with the workspace root masked so it can be shared."""
    root, state = load_build_state(build_state)
    rows = read(log_path(build_state))
    if not rows:
        return "# WorldBuilder Debug Log\n\nNo problems recorded.\n"

    # Mask the build root *and* the workspace above it. Masking only the build root
    # leaked the parent workspace path, which usually contains a real user directory.
    # Longest first, so a nested path is not partially replaced by its ancestor.
    candidates: list[tuple[str, str]] = [(str(root), "<workspace>")]
    workspace = state.get("workspace") if isinstance(state.get("workspace"), str) else None
    for extra in (workspace, str(root.parent), str(root.parent.parent)):
        if extra and len(extra) > 1:
            candidates.append((extra, "<workspace>"))
    candidates.append((str(Path.home()), "<home>"))
    ordered = sorted({c for c in candidates if c[0]}, key=lambda c: -len(c[0]))

    def mask(text: str) -> str:
        masked = text or ""
        for needle, label in ordered:
            masked = masked.replace(needle, label)
        return masked

    lines = ["# WorldBuilder Debug Log", "",
             f"Entries: {len(rows)} ({sum(1 for r in rows if r.get('status') == 'open')} open)", ""]
    for index, row in enumerate(rows):
        status = row.get("status", "open").upper()
        lines += [f"## {index}. [{status}] {row.get('category', 'other')} "
                  f"({row.get('severity', 'medium')})", ""]
        if row.get("stage"):
            lines.append(f"- **Stage:** {row['stage']}")
        if row.get("reproduce"):
            lines += ["- **Reproduce:**", "", "```bash", mask(row["reproduce"]), "```", ""]
        lines += ["- **Detail:**", "", "```text", mask(row.get("detail", "")), "```", ""]
        if row.get("resolution"):
            lines += [f"- **Resolution:** {mask(row['resolution'])}", ""]
    return "\n".join(lines) + "\n"


def main() -> int:
    parser = argparse.ArgumentParser(description="Record build problems and how to reproduce them.")
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("capture", help="run a command; record it if it fails")
    p.add_argument("--build-state", required=True)
    p.add_argument("--always", action="store_true", help="record successes too")
    p.add_argument("argv", nargs=argparse.REMAINDER,
                   help="the command to run, after --")

    p = sub.add_parser("record", help="append a problem by hand")
    p.add_argument("--build-state", required=True)
    p.add_argument("--problem", required=True)
    p.add_argument("--reproduce", default="")
    p.add_argument("--severity", default="medium", choices=list(SEVERITIES))
    p.add_argument("--category")

    p = sub.add_parser("resolve", help="attach a resolution to an open problem")
    p.add_argument("--build-state", required=True)
    p.add_argument("--resolution", required=True)
    p.add_argument("--index", type=int)

    for name, helptext in (("report", "summary grouped by category"),
                           ("export", "shareable markdown log")):
        s = sub.add_parser(name, help=helptext)
        s.add_argument("--build-state", required=True)
        if name == "export":
            s.add_argument("--output")

    args = parser.parse_args()
    try:
        if args.command == "capture":
            command = [c for c in args.argv if c != "--"]
            result = capture(args.build_state, command, always=args.always)
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return result.get("returncode", 0)
        if args.command == "record":
            result = record(args.build_state, problem=args.problem, reproduce=args.reproduce,
                            severity=args.severity, category=args.category)
        elif args.command == "resolve":
            result = resolve(args.build_state, args.resolution, index=args.index)
        elif args.command == "report":
            result = report(args.build_state)
        elif args.command == "export":
            text = export(args.build_state)
            if args.output:
                out = Path(args.output).expanduser().resolve()
                out.parent.mkdir(parents=True, exist_ok=True)
                out.write_text(text, encoding="utf-8")
                result = {"written": str(out), "bytes": len(text)}
            else:
                print(text)
                return 0
        else:
            raise_error(f"unknown command {args.command!r}")
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (WorldBuilderError, OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
