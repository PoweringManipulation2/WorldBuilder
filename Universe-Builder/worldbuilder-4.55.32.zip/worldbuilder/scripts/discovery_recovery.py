#!/usr/bin/env python3
"""Append exact bird-named recovery and verification work without rewriting prior assignments."""
from __future__ import annotations

import argparse
import json
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from discovery_contract import DISCOVERY_PLAN_VERSION
from discovery_plan import assignment_payload, category_urls, clean_urls, normalize_rounds, ramp_wave_sizes, stable_hash
from wb_common import WorldBuilderError, atomic_write_json, load_build_state, load_json, resolve_state_path, sha256_file


def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def probe_urls(probe: dict[str, Any]) -> set[str]:
    categories, _seeds = category_urls(probe.get("categories"))
    values: set[str] = set()
    for source in (
        (probe.get("sitemap") or {}).get("urls") if isinstance(probe.get("sitemap"), dict) else [],
        (probe.get("allpages") or {}).get("urls") if isinstance(probe.get("allpages"), dict) else [],
        (probe.get("redirects") or {}).get("urls") if isinstance(probe.get("redirects"), dict) else [],
        (probe.get("alllinks") or {}).get("urls") if isinstance(probe.get("alllinks"), dict) else [],
        (probe.get("special_allpages") or {}).get("urls") if isinstance(probe.get("special_allpages"), dict) else [],
        (probe.get("search_harvest") or {}).get("urls") if isinstance(probe.get("search_harvest"), dict) else [],
        (probe.get("internal_links") or {}).get("urls") if isinstance(probe.get("internal_links"), dict) else [],
        probe.get("bfs_seeds"),
        (probe.get("page_filter") or {}).get("harvested_urls") if isinstance(probe.get("page_filter"), dict) else [],
    ):
        values.update(clean_urls(source))
    for rows in categories.values():
        values.update(rows)
    return values


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--build-state", required=True)
    parser.add_argument("--runtime-cap", type=int, default=20)
    parser.add_argument("--target-pages-per-worker", type=int, default=75)
    parser.add_argument("--delta-probe", help="Fresh source-probe delta created with source_probe.py --delta-of")
    args = parser.parse_args()
    try:
        state_path = Path(args.build_state).resolve()
        root, state = load_build_state(state_path)
        plan_path = resolve_state_path(root, state, "discovery_plan")
        recovery_path = resolve_state_path(root, state, "discovery_recovery_plan", required=False) or (resolve_state_path(root, state, "discoveries") / "discovery-recovery-plan.json")
        if not recovery_path.exists():
            raise WorldBuilderError("no discovery recovery plan exists; run discovery_gate.py first")
        plan = load_json(plan_path)
        recovery = load_json(recovery_path)
        if not isinstance(plan, dict) or not isinstance(recovery, dict):
            raise WorldBuilderError("plan/recovery JSON must be objects")
        if int(plan.get("plan_version", 0) or 0) not in {3, 4, DISCOVERY_PLAN_VERSION}:
            raise WorldBuilderError("unsupported discovery plan version")
        if recovery.get("build_id") != state.get("build_id") or recovery.get("plan_sha256") != sha256_file(plan_path):
            raise WorldBuilderError("recovery plan is stale or belongs to another build")

        delta_sha: str | None = None
        delta_urls: set[str] = set()
        delta_expected_urls: set[str] = set()
        delta_prefilter_rows: list[dict[str, Any]] = []
        delta_alias_rows: list[dict[str, Any]] = []
        delta_reference_urls: list[str] = []
        delta_rounds: list[dict[str, Any]] = []
        if args.delta_probe:
            delta_path = Path(args.delta_probe).expanduser().resolve()
            try:
                delta_path.relative_to(root)
            except ValueError as exc:
                raise WorldBuilderError("delta probe must remain inside the build workspace") from exc
            delta = load_json(delta_path)
            if not isinstance(delta, dict) or delta.get("kind") != "worldbuilder-source-probe-delta" or delta.get("build_id") != state.get("build_id"):
                raise WorldBuilderError("delta probe is invalid or belongs to another build")
            delta_sha = sha256_file(delta_path)
            existing_expected = set(plan.get("expected_urls", []))
            delta_expected_urls = probe_urls(delta) - existing_expected
            page_filter = delta.get("page_filter") if isinstance(delta.get("page_filter"), dict) else {}
            filter_by_url: dict[str, dict[str, Any]] = {}
            if page_filter.get("status") == "complete":
                for row in page_filter.get("records", []):
                    if isinstance(row, dict) and isinstance(row.get("url"), str):
                        filter_by_url[row["url"]] = row
                delta_alias_rows = [row for row in page_filter.get("alias_map", []) if isinstance(row, dict)]
                delta_reference_urls = [url for url in page_filter.get("reference_only_urls", []) if isinstance(url, str)]
            for url in sorted(delta_expected_urls):
                row = filter_by_url.get(url)
                if not isinstance(row, dict) or row.get("classification") == "content":
                    delta_urls.add(url)
                    continue
                if isinstance(row.get("code"), str) and isinstance(row.get("reason"), str):
                    delta_prefilter_rows.append({
                        "url": url,
                        "classification": row.get("classification"),
                        "code": row.get("code"),
                        "reason": row.get("reason"),
                        "canonical_url": row.get("canonical_url"),
                        "requested_title": row.get("requested_title"),
                        "title": row.get("title"),
                        "evidence": row.get("evidence") if isinstance(row.get("evidence"), list) else [],
                    })
                else:
                    delta_urls.add(url)
            existing_worker_urls = {url for url in plan.get("worker_urls", []) if isinstance(url, str)}
            delta_rounds = normalize_rounds(delta, existing_worker_urls | delta_urls)
        elif recovery.get("requires_reprobe"):
            raise WorldBuilderError("recovery needs an incremental delta probe; run source_probe.py --delta-of with a new --output, then pass --delta-probe")

        if delta_expected_urls:
            existing_prefilter = plan.setdefault("prefilter_accounting", [])
            existing_prefilter_urls = {row.get("url") for row in existing_prefilter if isinstance(row, dict)}
            for row in delta_prefilter_rows:
                if row.get("url") not in existing_prefilter_urls:
                    existing_prefilter.append(row)
                    existing_prefilter_urls.add(row.get("url"))
            existing_aliases = plan.setdefault("alias_map", [])
            alias_keys = {(row.get("alias"), row.get("canonical_url")) for row in existing_aliases if isinstance(row, dict)}
            for row in delta_alias_rows:
                key = (row.get("alias"), row.get("canonical_url"))
                if key not in alias_keys:
                    existing_aliases.append(row); alias_keys.add(key)
            refs = plan.setdefault("reference_only_urls", [])
            for url in delta_reference_urls:
                if url not in refs:
                    refs.append(url)
            for url in sorted(delta_expected_urls):
                if url not in plan.setdefault("expected_urls", []):
                    plan["expected_urls"].append(url)
                plan.setdefault("url_provenance", {}).setdefault(url, []).append("delta_probe")

        if "recovery_actionable_urls" in recovery:
            # 3.6.7+: recovery plans distinguish URLs still worth a fresh worker
            # from ones already confirmed dead across independent rounds. Never
            # re-dispatch a worker against a confirmed-dead URL: that just
            # burns a round for zero new information; it needs exclusion
            # approval instead, not more recovery.
            candidates = [url for url in recovery.get("recovery_actionable_urls", []) if isinstance(url, str)]
            confirmed_dead = [url for url in recovery.get("confirmed_dead_urls", []) if isinstance(url, str)]
        else:
            candidates = [row.get("url") for row in recovery.get("candidate_urls", []) if isinstance(row, dict) and isinstance(row.get("url"), str)]
            confirmed_dead = []
        candidates = list(dict.fromkeys(candidates + sorted(delta_urls)))
        unused = [row for row in recovery.get("unused_verification_rounds", []) if isinstance(row, dict) and isinstance(row.get("urls"), list)]
        known_round_ids = {row.get("round") for row in unused if isinstance(row.get("round"), int)}
        unused.extend(row for row in delta_rounds if row.get("round") not in known_round_ids)
        if not candidates and not unused:
            if confirmed_dead:
                raise WorldBuilderError(
                    f"no actionable recovery work remains; {len(confirmed_dead)} candidate URL(s) are confirmed dead "
                    "across independent rounds and need a governed exclusion approval, not another recovery worker. "
                    "See references/discovery-approvals.md and write_discovery_approval.py."
                )
            raise WorldBuilderError("recovery plan has neither URL recovery work nor unused verification rounds")

        assignments_dir = resolve_state_path(root, state, "assignments")
        corpus_sha = str(plan.get("corpus_sha256", ""))
        next_pass = int(recovery.get("next_pass_number", 2))
        prior = plan.get("assignments", []) if isinstance(plan.get("assignments"), list) else []
        existing_count = len(prior)
        cap = max(1, min(20, args.runtime_cap))
        target = max(1, min(150, args.target_pages_per_worker))
        base_fetch_policy = None
        for row in prior:
            if isinstance(row, dict) and isinstance(row.get("path"), str):
                candidate = load_json(root / row["path"])
                if isinstance(candidate, dict) and isinstance(candidate.get("fetch_policy"), dict):
                    base_fetch_policy = candidate["fetch_policy"]
                    break
        if base_fetch_policy is None:
            raise WorldBuilderError("existing discovery plan has no fetch_policy")
        parts = [candidates[index:index + target] for index in range(0, len(candidates), target)]
        verification_to_add = unused[: max(0, 2 - sum(1 for row in prior if isinstance(row, dict) and row.get("stage") == "breadth_verification")) or 2]
        total = len(parts) + len(verification_to_add)
        wave_sizes = ramp_wave_sizes(total, cap)
        existing_waves = plan.get("dispatch_waves", []) if isinstance(plan.get("dispatch_waves"), list) else []
        base_wave = max((int(row.get("wave", 0) or 0) for row in existing_waves if isinstance(row, dict)), default=0)
        wave_map: dict[int, tuple[int, int]] = {}
        cursor = 0
        new_waves: list[dict[str, Any]] = []
        for offset, size in enumerate(wave_sizes, start=1):
            wave_no = base_wave + offset
            new_waves.append({"wave": wave_no, "planned_size": size, "status": "unlocked" if offset == 1 else "locked", "assignment_ids": [], "cycle": "recovery"})
            for position in range(1, size + 1):
                wave_map[cursor] = (wave_no, position)
                cursor += 1
        plan.setdefault("dispatch_waves", []).extend(new_waves)
        previous_plan_sha = sha256_file(plan_path)
        created: list[str] = []

        for offset, part in enumerate(parts):
            wave_no, position = wave_map[offset]
            assignment_id, assignment, output = assignment_payload(
                build_id=state["build_id"], source_stance=state.get("source", {}).get("stance", "source-canonical"),
                stage="breadth_recovery", pass_number=next_pass, index=existing_count + offset,
                urls=part, corpus_sha=corpus_sha, method="targeted_recovery", label_suffix=f"targeted recovery pass {next_pass}",
                root=root, fetch_policy=base_fetch_policy, dispatch_wave=wave_no, wave_position=position,
            )
            assignment["recovery_plan_sha256"] = sha256_file(recovery_path)
            if delta_sha:
                assignment["delta_probe_sha256"] = delta_sha
            path = assignments_dir / f"{assignment_id}.json"
            if path.exists():
                raise WorldBuilderError(f"refusing to overwrite recovery assignment {path.name}")
            atomic_write_json(path, assignment)
            row = {
                "assignment_id": assignment_id, "worker": assignment["worker"], "taskName": assignment["taskName"],
                "stage": assignment["stage"], "pass_number": next_pass, "path": str(path.relative_to(root)).replace("\\", "/"),
                "assignment_sha256": sha256_file(path), "page_count": len(part), "output": output,
                "runtime_receipt": assignment["runtime_receipt"], "dispatch_wave": wave_no, "wave_position": position,
            }
            plan.setdefault("assignments", []).append(row)
            next(item for item in plan["dispatch_waves"] if item.get("wave") == wave_no)["assignment_ids"].append(assignment_id)
            for url in part:
                plan.setdefault("url_provenance", {}).setdefault(url, []).append("delta_probe" if url in delta_urls else "recovery")
                if url not in plan.setdefault("expected_urls", []):
                    plan["expected_urls"].append(url)
                plan.setdefault("url_owners", {})[url] = assignment_id
            created.append(assignment_id)

        worker_index = existing_count + len(parts)
        verification_base = next_pass + (1 if parts else 0)
        for round_offset, round_info in enumerate(verification_to_add):
            index = len(parts) + round_offset
            wave_no, position = wave_map[index]
            pass_number = verification_base + round_offset
            urls = list(dict.fromkeys(url for url in round_info.get("urls", []) if isinstance(url, str)))
            assignment_id, assignment, output = assignment_payload(
                build_id=state["build_id"], source_stance=state.get("source", {}).get("stance", "source-canonical"),
                stage="breadth_verification", pass_number=pass_number, index=worker_index + round_offset,
                urls=urls, corpus_sha=corpus_sha, method="post_recovery_spot_check",
                label_suffix=f"post-recovery verification pass {round_offset + 1}", root=root, fetch_policy=base_fetch_policy,
                dispatch_wave=wave_no, wave_position=position,
            )
            assignment["verification_kind"] = round_info.get("kinds", ["independent"])
            assignment["source_round"] = round_info.get("round")
            path = assignments_dir / f"{assignment_id}.json"
            if path.exists():
                raise WorldBuilderError(f"refusing to overwrite verification assignment {path.name}")
            atomic_write_json(path, assignment)
            row = {
                "assignment_id": assignment_id, "worker": assignment["worker"], "taskName": assignment["taskName"],
                "stage": assignment["stage"], "pass_number": pass_number, "path": str(path.relative_to(root)).replace("\\", "/"),
                "assignment_sha256": sha256_file(path), "page_count": len(urls), "output": output,
                "runtime_receipt": assignment["runtime_receipt"], "verification_kind": assignment["verification_kind"],
                "dispatch_wave": wave_no, "wave_position": position,
            }
            plan.setdefault("assignments", []).append(row)
            next(item for item in plan["dispatch_waves"] if item.get("wave") == wave_no)["assignment_ids"].append(assignment_id)
            created.append(assignment_id)

        plan["expected_urls"] = sorted(set(plan.get("expected_urls", [])))
        for url, sources in plan.get("url_provenance", {}).items():
            plan["url_provenance"][url] = sorted(set(sources))
        plan.setdefault("plan_revisions", []).append({
            "created_at": utc_now(), "kind": "append_recovery", "previous_plan_sha256": previous_plan_sha,
            "recovery_plan_sha256": sha256_file(recovery_path), "delta_probe_sha256": delta_sha,
            "pass_number": next_pass, "candidate_count": len(candidates), "assignments": created, "dispatch_waves": wave_sizes,
            "delta_prefilter_accounted_count": len(delta_prefilter_rows), "delta_expected_url_count": len(delta_expected_urls),
        })
        plan["assignment_manifest_sha256"] = stable_hash(plan.get("assignments", []))
        atomic_write_json(plan_path, plan)
        history = resolve_state_path(root, state, "discoveries") / "recovery-history"
        history.mkdir(parents=True, exist_ok=True)
        shutil.copy2(recovery_path, history / f"{sha256_file(recovery_path)}.json")
        recovery_path.unlink()
        state.setdefault("discovery", {})["status"] = "recovery_dispatched"
        state["discovery"]["plan_sha256"] = sha256_file(plan_path)
        state["discovery"]["active_wave"] = base_wave + 1 if new_waves else None
        atomic_write_json(state_path, state)
        print(json.dumps({"status": "recovery_assignments_created", "assignments": created, "plan": str(plan_path), "target_pages_per_worker": target, "dispatch_waves": [row["wave"] for row in new_waves]}, indent=2))
        return 0
    except (WorldBuilderError, OSError, json.JSONDecodeError, ValueError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
