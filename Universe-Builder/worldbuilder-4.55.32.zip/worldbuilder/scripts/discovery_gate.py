#!/usr/bin/env python3
"""Validate additive breadth discovery, completeness, ownership, and saturation.

The gate proves more than worker completion: every URL is owned by one worker in
its pass, every assigned URL was attempted, source-level denominators reconcile,
independent verification rounds completed, and the final two verification rounds
reached low-yield saturation. Gaps produce a machine-readable recovery plan and
exit status 2; no final discovery receipt is written until all checks pass.
"""
from __future__ import annotations

import argparse
import json
import math
import re
import sys
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from dispatch_observation import (
    CHILD_RUN_COMPLETION, CHILD_RUNTIME_PARTIAL_KIND, CHILD_RUNTIME_RECEIPT_KIND,
    PARENT_EXEC_COMPLETION, PARENT_OBSERVED_CHILD_RUN, PARENT_OBSERVED_EXEC, RECORDED_BY_PARENT,
)
from typing import Any

from discovery_plan import canonicalize_url
from discovery_contract import (
    DISCOVERY_ASSIGNMENT_VERSION, DISCOVERY_GATE_RECEIPT_VERSION, DISCOVERY_PLAN_VERSION,
    DISCOVERY_RESULT_VERSION, DISCOVERY_RUNTIME_RECEIPT_VERSION, exclusion_policy, validate_contract,
)
from entity_taxonomy import normalize_entity
from entity_resolution import resolve_entities

RUNTIME_CLOCK_SKEW_SECONDS = 120
from write_discovery_approval import DISCOVERY_APPROVAL_VERSION
from wb_common import (
    step_driver_pointer,
    WorldBuilderError,
    atomic_write_json,
    ensure_inside,
    load_build_state,
    load_json,
    preflight_report,
    requirement_rows,
    resolve_state_path,
    sha256_file,
)
from pipeline_stage_gate import advance as advance_pipeline_stage


def rel_output(build_root: Path, discoveries: Path, assignment: dict[str, Any]) -> Path:
    value = assignment.get("output")
    if not isinstance(value, str) or not value.strip():
        raise WorldBuilderError(f"breadth-discovery assignment's 'output' field must be a non-empty string, found {value!r}")
    raw = Path(value)
    if raw.is_absolute():
        raise WorldBuilderError(f"breadth-discovery assignment's output path ({value!r}) must be relative to the build root, not absolute")
    output = (build_root / raw).resolve()
    ensure_inside(output, discoveries)
    return output



def parse_timestamp(value: Any, field: str) -> datetime:
    if not isinstance(value, str) or not value.strip():
        raise WorldBuilderError(f"{field} is missing or empty, found {value!r}")
    text = value.strip().replace("Z", "+00:00")
    try:
        parsed = datetime.fromisoformat(text)
    except ValueError as exc:
        raise WorldBuilderError(f"{field} ({value!r}) is not a valid ISO timestamp: {exc}") from exc
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def runtime_path_for(build_root: Path, runtime_root: Path, assignment: dict[str, Any]) -> Path:
    value = assignment.get("runtime_receipt")
    if not isinstance(value, str) or not value.strip():
        raise WorldBuilderError(f"breadth-discovery assignment's 'runtime_receipt' field must be a non-empty string, found {value!r}")
    raw = Path(value)
    if raw.is_absolute():
        raise WorldBuilderError(f"breadth-discovery assignment's runtime_receipt path ({value!r}) must be relative to the build root, not absolute")
    path = (build_root / raw).resolve()
    ensure_inside(path, runtime_root)
    return path


def validate_runtime_receipt(
    path: Path,
    *,
    assignment: dict[str, Any],
    assignment_path: Path,
    result_path: Path,
) -> dict[str, Any]:
    if not path.exists():
        raise WorldBuilderError(f"missing parent-observed discovery runtime receipt: {path}")
    runtime = load_json(path)
    if not isinstance(runtime, dict) or runtime.get("kind") != CHILD_RUNTIME_RECEIPT_KIND or int(runtime.get("receipt_version", 0) or 0) not in {2, DISCOVERY_RUNTIME_RECEIPT_VERSION}:
        raise WorldBuilderError(f"{path.name} is not a supported parent-observed discovery runtime receipt (kind={runtime.get('kind') if isinstance(runtime, dict) else type(runtime).__name__!r}, receipt_version={runtime.get('receipt_version') if isinstance(runtime, dict) else 'n/a'}; need kind='worldbuilder-child-runtime-receipt', version in {{2, {DISCOVERY_RUNTIME_RECEIPT_VERSION}}})")
    if int(runtime.get("receipt_version", 0) or 0) >= DISCOVERY_RUNTIME_RECEIPT_VERSION:
        validate_contract(runtime.get("contract"), label=f"{path.name}.contract", worker_kit_sha256=(assignment.get("contract") or {}).get("worker_kit_sha256"))
    source = runtime.get("runtime_source")
    if source not in {PARENT_OBSERVED_CHILD_RUN, PARENT_OBSERVED_EXEC} or runtime.get("recorded_by") != RECORDED_BY_PARENT:
        raise WorldBuilderError(f"{path.name} does not identify a supported parent-observed completion (runtime_source={source!r}, recorded_by={runtime.get('recorded_by')!r})")
    if source == PARENT_OBSERVED_EXEC:
        if runtime.get("exit_code") != 0 or not isinstance(runtime.get("workdir"), str) or not Path(runtime["workdir"]).is_absolute():
            raise WorldBuilderError(f"{path.name} has an invalid exec completion proof (exit_code={runtime.get('exit_code')!r}, workdir={runtime.get('workdir')!r}; need exit_code=0 and an absolute workdir path)")
    expected = {
        "build_id": assignment.get("build_id"),
        "assignment_id": assignment.get("assignment_id"),
        "assignment_sha256": sha256_file(assignment_path),
        "stage": assignment.get("stage"),
        "pass_number": assignment.get("pass_number"),
        "worker": assignment.get("worker"),
        "taskName": assignment.get("taskName"),
        "status": "completed",
        "result": assignment.get("output"),
        "result_sha256": sha256_file(result_path),
        "terminal_delimiter": assignment.get("expected_end_delimiter"),
    }
    for key, value in expected.items():
        if runtime.get(key) != value:
            raise WorldBuilderError(f"{path.name} mismatch at {key}: {runtime.get(key)!r} != {value!r}")
    expected_source = CHILD_RUN_COMPLETION if source == PARENT_OBSERVED_CHILD_RUN else PARENT_EXEC_COMPLETION
    if runtime.get("source") != expected_source:
        raise WorldBuilderError(f"{path.name}'s source is {runtime.get('source')!r}, but its runtime_source ({source!r}) requires source={expected_source!r}")
    for key in ("run_id", "runtime_event_id", "parent_session_id"):
        if not isinstance(runtime.get(key), str) or not runtime[key].strip():
            raise WorldBuilderError(f"{path.name} has no {key}")
    if source == PARENT_OBSERVED_CHILD_RUN:
        if not isinstance(runtime.get("child_session_id"), str) or not runtime["child_session_id"].strip():
            raise WorldBuilderError(f"{path.name} has no child_session_id")
        if runtime["parent_session_id"] == runtime["child_session_id"]:
            raise WorldBuilderError(f"{path.name} parent_session_id equals child_session_id")
    spawned = parse_timestamp(runtime.get("spawned_at"), f"{path.name}.spawned_at")
    completed = parse_timestamp(runtime.get("completed_at"), f"{path.name}.completed_at")
    created_raw = assignment.get("created_at")
    if created_raw is not None:
        created = parse_timestamp(created_raw, f"{assignment_path.name}.created_at")
        skew = float(RUNTIME_CLOCK_SKEW_SECONDS)
        if (created - spawned).total_seconds() > skew:
            raise WorldBuilderError(
                f"{path.name} spawned_at ({runtime.get('spawned_at')}) precedes assignment creation "
                f"({created_raw}) by more than {skew:.0f}s of allowed clock skew; verify both timestamps are "
                "UTC and taken from the real spawn event"
            )
    if completed < spawned:
        raise WorldBuilderError(f"{path.name}'s completed_at ({completed.isoformat()}) precedes its own spawned_at ({spawned.isoformat()})")
    return runtime

def normalized_urls(value: Any, label: str) -> list[str]:
    if value is None:
        return []
    if not isinstance(value, list):
        raise WorldBuilderError(f"{label} must be a list, found {type(value).__name__}")
    output: list[str] = []
    seen: set[str] = set()
    for item in value:
        url = canonicalize_url(item)
        if not url:
            raise WorldBuilderError(f"{label} contains an invalid or non-content URL: {item!r}")
        if url not in seen:
            seen.add(url)
            output.append(url)
    return output


def reasoned_urls(value: Any, label: str, *, require_code: bool = False) -> tuple[list[str], dict[str, str], dict[str, str]]:
    if value is None:
        return [], {}, {}
    if not isinstance(value, list):
        raise WorldBuilderError(f"{label} must be a list, found {type(value).__name__}")
    urls: list[str] = []
    reasons: dict[str, str] = {}
    codes: dict[str, str] = {}
    for index, item in enumerate(value):
        if not isinstance(item, dict):
            raise WorldBuilderError(f"{label}[{index}] must be an object with 'url' and 'reason', found {type(item).__name__}")
        url = canonicalize_url(item.get("url"))
        reason = item.get("reason")
        if not url or not isinstance(reason, str) or len(reason.strip()) < 5:
            raise WorldBuilderError(f"{label}[{index}] requires a valid URL (found {item.get('url')!r}) and a reason of at least 5 characters (found {reason!r})")
        if url in reasons:
            raise WorldBuilderError(f"{label} repeats URL {url}: each URL may appear at most once")
        code = item.get("code")
        if require_code or code is not None:
            exclusion_policy(code)
        urls.append(url)
        reasons[url] = reason.strip()
        if isinstance(code, str):
            codes[url] = code
    return urls, reasons, codes


def exact_delimiter(text: Any, expected: str) -> None:
    if text != expected:
        raise WorldBuilderError(f"discovery output's completion delimiter is missing or incorrect: expected the exact string {expected!r} as the final line, found {text!r}")


def validate_discovery(
    path: Path,
    assignment_path: Path,
    assignment: dict[str, Any],
    build_id: str,
    corpus_sha: str,
) -> dict[str, Any]:
    if not path.exists():
        raise WorldBuilderError(f"discovery output does not exist at {path}: run the discovery worker for this assignment before validating")
    data = load_json(path)
    if not isinstance(data, dict):
        raise WorldBuilderError(f"{path.name} must contain a JSON object, found {type(data).__name__}")
    meta = data.get("_worldbuilder")
    if not isinstance(meta, dict):
        raise WorldBuilderError(f"{path.name} has no '_worldbuilder' metadata object, found {type(meta).__name__}")
    expected = {
        "kind": "breadth-discovery",
        "build_id": build_id,
        "assignment_id": assignment.get("assignment_id"),
        "assignment_sha256": sha256_file(assignment_path),
        "corpus_sha256": corpus_sha,
        "worker": assignment.get("worker"),
        "taskName": assignment.get("taskName"),
        "pass_number": assignment.get("pass_number"),
        "completed": True,
        "runtime_status": "completed",
    }
    if int(assignment.get("assignment_version", 0) or 0) >= DISCOVERY_ASSIGNMENT_VERSION:
        expected["result_version"] = DISCOVERY_RESULT_VERSION
        validate_contract(assignment.get("contract"), label=f"{assignment_path.name}.contract")
        validate_contract(meta.get("contract"), label=f"{path.name}._worldbuilder.contract", worker_kit_sha256=(assignment.get("contract") or {}).get("worker_kit_sha256"))
    for key, value in expected.items():
        if meta.get(key) != value:
            raise WorldBuilderError(f"{path.name} metadata mismatch at {key}: {meta.get(key)!r} != {value!r}")
    echoed_session_id = meta.get("child_session_id")
    if echoed_session_id is not None and (not isinstance(echoed_session_id, str) or not echoed_session_id.strip()):
        raise WorldBuilderError(f"{path.name}'s optional _worldbuilder.child_session_id must be a non-empty string when present, found {echoed_session_id!r}")
    exact_delimiter(meta.get("end_delimiter"), str(assignment.get("expected_end_delimiter", "")))

    assigned = normalized_urls(assignment.get("page_urls"), f"{assignment_path.name} page_urls")
    visited = normalized_urls(data.get("visited_urls"), f"{path.name} visited_urls")
    failed = normalized_urls(data.get("failed_urls"), f"{path.name} failed_urls")
    require_codes = int(assignment.get("assignment_version", 0) or 0) >= DISCOVERY_ASSIGNMENT_VERSION
    excluded, excluded_reasons, excluded_codes = reasoned_urls(data.get("excluded_urls"), f"{path.name} excluded_urls", require_code=require_codes)
    delegated, delegated_reasons, _delegated_codes = reasoned_urls(data.get("delegated_urls"), f"{path.name} delegated_urls")
    discovered = normalized_urls(data.get("discovered_urls"), f"{path.name} discovered_urls")
    assigned_set = set(assigned)
    outcome_sets = {
        "visited": set(visited), "failed": set(failed), "excluded": set(excluded), "delegated": set(delegated),
    }
    labels = list(outcome_sets)
    for i, left in enumerate(labels):
        for right in labels[i + 1:]:
            overlap = outcome_sets[left] & outcome_sets[right]
            if overlap:
                raise WorldBuilderError(f"{path.name} lists URL(s) as both {left} and {right}: {sorted(overlap)[:8]!r}")
    claimed = set().union(*outcome_sets.values())
    if not claimed <= assigned_set:
        extra = sorted(claimed - assigned_set)
        raise WorldBuilderError(f"{path.name} claims URL(s) owned by another worker: {extra[:8]!r}")
    if claimed != assigned_set:
        missing = sorted(assigned_set - claimed)
        raise WorldBuilderError(f"{path.name} did not account for every owned URL: {missing[:8]!r}")

    fetch_records = data.get("fetch_records")
    if not isinstance(fetch_records, list):
        raise WorldBuilderError(f"{path.name}'s fetch_records must be a list, found {type(fetch_records).__name__}")
    fetch_by_url: dict[str, dict[str, Any]] = {}
    valid_statuses = {"visited", "failed", "excluded", "delegated"}
    expected_status: dict[str, str] = {}
    for status, values in (("visited", visited), ("failed", failed), ("excluded", excluded), ("delegated", delegated)):
        for url in values:
            expected_status[url] = status
    for index, record in enumerate(fetch_records):
        if not isinstance(record, dict):
            raise WorldBuilderError(f"{path.name}'s fetch_records[{index}] must be a JSON object, found {type(record).__name__}")
        url = canonicalize_url(record.get("url"))
        status = record.get("status")
        if not url or status not in valid_statuses:
            raise WorldBuilderError(f"{path.name}'s fetch_records[{index}] needs a valid url (found {record.get('url')!r}) and a terminal status in {sorted(valid_statuses)} (found {status!r})")
        if url in fetch_by_url:
            raise WorldBuilderError(f"{path.name} repeats fetch record for {url}")
        if url not in assigned_set:
            raise WorldBuilderError(f"{path.name} fetch record claims URL owned by another worker: {url}")
        if expected_status.get(url) != status:
            raise WorldBuilderError(f"{path.name} fetch record status for {url} disagrees with ownership arrays")
        method = record.get("method")
        if status == "visited" and (not isinstance(method, str) or not method.strip()):
            raise WorldBuilderError(f"{path.name} visited fetch record for {url} has no method")
        fetch_by_url[url] = record
    if set(fetch_by_url) != assigned_set:
        missing_fetch = sorted(assigned_set - set(fetch_by_url))
        raise WorldBuilderError(f"{path.name} lacks fetch record(s) for owned URL(s): {missing_fetch[:8]!r}")

    entities = data.get("entities")
    no_results = data.get("no_results")
    if not isinstance(entities, list):
        raise WorldBuilderError(f"{path.name}'s 'entities' must be a list, found {type(entities).__name__}")
    if not entities and no_results is not True:
        raise WorldBuilderError(f"{path.name} has zero entities, but no_results is {no_results!r}, not true: either report at least one entity or explicitly set no_results=true")
    # A discovered link is a recovery candidate, not factual evidence. Entity
    # records must cite a page this worker actually fetched.
    grounded_urls = set(visited)
    normalized_entities: list[dict[str, Any]] = []
    for index, entity in enumerate(entities):
        if not isinstance(entity, dict):
            raise WorldBuilderError(f"{path.name}'s entities[{index}] must be a JSON object, found {type(entity).__name__}")
        entity = normalize_entity(entity)
        normalized_entities.append(entity)
        if not isinstance(entity.get("name"), str) or not entity["name"].strip():
            raise WorldBuilderError(f"{path.name}'s entities[{index}] has no non-empty 'name' field: {entity!r}")
        urls = normalized_urls(entity.get("source_urls"), f"{path.name} entities[{index}].source_urls")
        if not urls:
            raise WorldBuilderError(f"{path.name}'s entities[{index}] ({entity.get('name')!r}) has no source_urls: every entity needs at least one")
        if not (set(urls) & grounded_urls):
            raise WorldBuilderError(f"{path.name}'s entities[{index}] ({entity.get('name')!r}) cites source_urls {urls}, none of which are in this worker's own visited_urls {sorted(grounded_urls)}")
    data["entities"] = normalized_entities
    covered = data.get("covered_scope")
    if not isinstance(covered, list) or not covered:
        raise WorldBuilderError(f"{path.name}'s 'covered_scope' must be a non-empty list, found {covered!r}")
    return {
        "data": data, "assigned": assigned, "visited": visited, "failed": failed,
        "excluded": excluded, "excluded_reasons": excluded_reasons, "excluded_codes": excluded_codes,
        "delegated": delegated, "delegated_reasons": delegated_reasons,
        "discovered": discovered,
        "fetch_records": fetch_records,
    }


def entity_key(entity: dict[str, Any]) -> str:
    # Discovery identity must remain stable when independent workers cite the
    # same entity from different pages. Prefer normalized name + type; URLs are
    # evidence and aliases, not the primary identity key.
    name = re.sub(r"\s+", " ", str(entity.get("name", "")).strip()).casefold()
    entity_type = re.sub(r"\s+", "_", str(entity.get("type", "other")).strip()).casefold() or "other"
    if name:
        return f"name:{name}|type:{entity_type}"
    raw_urls = entity.get("source_urls") if isinstance(entity.get("source_urls"), list) else []
    for item in raw_urls:
        raw = item.get("url") if isinstance(item, dict) else item
        url = canonicalize_url(raw)
        if url:
            return "url:" + url.casefold()
    aliases = entity.get("aliases") if isinstance(entity.get("aliases"), list) else []
    alias_basis = "|".join(sorted(re.sub(r"\s+", " ", str(item).strip()).casefold() for item in aliases if str(item).strip()))
    return "anonymous|aliases:" + alias_basis


def merge_list_field(target: dict[str, Any], source: dict[str, Any], field: str) -> None:
    values: list[Any] = []
    for item in (target.get(field), source.get(field)):
        if isinstance(item, list):
            values.extend(item)
        elif item not in (None, ""):
            values.append(item)
    dedup: list[Any] = []
    seen: set[str] = set()
    for item in values:
        marker = json.dumps(item, ensure_ascii=False, sort_keys=True) if isinstance(item, (dict, list)) else str(item).casefold()
        if marker not in seen:
            seen.add(marker)
            dedup.append(item)
    if dedup:
        target[field] = dedup


def merge_entity(target: dict[str, Any], source: dict[str, Any]) -> None:
    for field in ("aliases", "source_urls", "relationships", "affiliations", "locations", "tags", "concepts", "eras"):
        merge_list_field(target, source, field)
    conflicts = target.setdefault("_discovery_conflicts", [])
    if not isinstance(conflicts, list):
        conflicts = []
        target["_discovery_conflicts"] = conflicts
    for key, value in source.items():
        if key in {"aliases", "source_urls", "relationships", "affiliations", "locations", "tags", "concepts", "eras", "_discovery_conflicts"}:
            continue
        if key not in target or target[key] in (None, "", [], {}):
            target[key] = value
        elif target[key] != value and key not in {"name", "type"}:
            conflict = {"field": key, "values": [target[key], value]}
            marker = json.dumps(conflict, ensure_ascii=False, sort_keys=True)
            if marker not in {json.dumps(item, ensure_ascii=False, sort_keys=True) for item in conflicts if isinstance(item, dict)}:
                conflicts.append(conflict)
    if not conflicts:
        target.pop("_discovery_conflicts", None)


def apply_prefilter_aliases(all_entities: dict[str, dict[str, Any]], alias_rows: Any) -> int:
    """Attach redirect aliases harvested by the deterministic prefilter.

    Alias-only pages do not need worker prose. They still enrich the canonical
    entity when its target is present in discovery output.
    """
    if not isinstance(alias_rows, list):
        return 0
    by_name: dict[str, dict[str, Any]] = {}
    by_url: dict[str, dict[str, Any]] = {}
    for entity in all_entities.values():
        name = entity.get("name")
        if isinstance(name, str) and name.strip():
            by_name[name.strip().casefold()] = entity
        for url in entity.get("source_urls", []) if isinstance(entity.get("source_urls"), list) else []:
            normalized = canonicalize_url(url)
            if normalized:
                by_url[normalized] = entity
    applied = 0
    for row in alias_rows:
        if not isinstance(row, dict):
            continue
        alias = row.get("alias")
        target = row.get("target")
        canonical_url = canonicalize_url(row.get("canonical_url"))
        entity = by_url.get(canonical_url) if canonical_url else None
        if entity is None and isinstance(target, str):
            entity = by_name.get(target.strip().casefold())
        if entity is None or not isinstance(alias, str) or not alias.strip():
            continue
        aliases = entity.setdefault("aliases", [])
        if not isinstance(aliases, list):
            aliases = []
            entity["aliases"] = aliases
        if alias.strip().casefold() != str(entity.get("name", "")).strip().casefold() and alias.strip() not in aliases:
            aliases.append(alias.strip())
            applied += 1
        alias_url = canonicalize_url(row.get("alias_url"))
        if alias_url:
            urls = entity.setdefault("source_urls", [])
            if isinstance(urls, list) and alias_url not in urls:
                urls.append(alias_url)
    return applied


def load_assignments(root: Path, assignments_dir: Path, plan: dict[str, Any]) -> list[tuple[Path, dict[str, Any]]]:
    plan_rows = plan.get("assignments")
    if not isinstance(plan_rows, list) or not plan_rows:
        raise WorldBuilderError(f"discovery plan's 'assignments' must be a non-empty list, found {plan_rows!r}")
    rows: list[tuple[Path, dict[str, Any]]] = []
    seen_paths: set[str] = set()
    seen_ids: set[str] = set()
    for index, row in enumerate(plan_rows):
        if not isinstance(row, dict) or not isinstance(row.get("path"), str):
            raise WorldBuilderError(f"discovery plan's assignments[{index}] must be an object with a string 'path', found {row!r}")
        rel = str(row["path"])
        if rel in seen_paths:
            raise WorldBuilderError(f"discovery plan repeats assignment path {rel!r}: each assignment path must appear at most once")
        seen_paths.add(rel)
        path = (root / rel).resolve()
        ensure_inside(path, assignments_dir)
        if not path.exists():
            raise WorldBuilderError(f"discovery assignment does not exist at {path}: the plan references it, but it was never written")
        expected_sha = row.get("assignment_sha256")
        if not isinstance(expected_sha, str) or sha256_file(path) != expected_sha:
            raise WorldBuilderError(f"{path.name} changed after discovery planning (plan's own assignment_sha256={expected_sha!r}, actual current hash={sha256_file(path)!r})")
        value = load_json(path)
        if not isinstance(value, dict):
            raise WorldBuilderError(f"{path.name} must contain a JSON object, found {type(value).__name__}")
        assignment_id = value.get("assignment_id")
        if assignment_id != row.get("assignment_id") or not isinstance(assignment_id, str) or assignment_id in seen_ids:
            raise WorldBuilderError(f"{path.name}'s assignment_id ({assignment_id!r}) does not match the plan's own row ({row.get('assignment_id')!r}), is not a string, or is a duplicate")
        seen_ids.add(assignment_id)
        for key in ("worker", "taskName", "stage", "pass_number", "output", "runtime_receipt"):
            if row.get(key) != value.get(key):
                raise WorldBuilderError(f"{path.name}'s {key} ({value.get(key)!r}) does not match the discovery plan's own row for it ({row.get(key)!r})")
        rows.append((path, value))
    return rows


def write_recovery_plan(
    path: Path,
    *,
    build_id: str,
    plan_path: Path,
    candidate_reasons: dict[str, set[str]],
    reprobe_reasons: list[str],
    next_pass: int,
    unused_verification_rounds: list[dict[str, Any]],
    metrics: dict[str, Any],
    decision_options: list[dict[str, str]] | None = None,
) -> None:
    candidates = [
        {"url": url, "reasons": sorted(reasons)}
        for url, reasons in sorted(candidate_reasons.items())
    ]
    confirmed_dead = sorted(
        url for url, reasons in candidate_reasons.items() if "confirmed_dead_pending_exclusion" in reasons
    )
    recovery_actionable = sorted(
        url for url, reasons in candidate_reasons.items() if "confirmed_dead_pending_exclusion" not in reasons
    )
    atomic_write_json(path, {
        "kind": "breadth-discovery-recovery-plan",
        "recovery_version": 2,
        "build_id": build_id,
        "plan": str(plan_path),
        "plan_sha256": sha256_file(plan_path),
        "next_pass_number": next_pass,
        "candidate_urls": candidates,
        "recovery_actionable_urls": recovery_actionable,
        "confirmed_dead_urls": confirmed_dead,
        "confirmed_dead_note": (
            "These URLs failed independently across multiple recovery rounds already. Do not dispatch another "
            "recovery worker against them; re-fetching a confirmed-dead URL wastes a round for no new "
            "information. Construct a governed exclusion approval instead (references/discovery-approvals.md, "
            "write_discovery_approval.py, code http_terminal_failure or manual_scope_exclusion as appropriate)."
        ) if confirmed_dead else None,
        "requires_reprobe": bool(reprobe_reasons),
        "reprobe_reasons": reprobe_reasons,
        "unused_verification_rounds": unused_verification_rounds,
        "decision_options": decision_options or [],
        "metrics": metrics,
    })


def load_single_round_approval(path: Path | None, *, state: dict[str, Any], plan_path: Path, plan: dict[str, Any]) -> tuple[dict[str, Any] | None, Path | None, int]:
    """Validate the user-approved single-round waiver for small saturated sources."""
    if path is None or not path.exists():
        return None, None, 0
    approval = load_json(path)
    if not isinstance(approval, dict) or approval.get("kind") != "worldbuilder-discovery-single-round-approval" or approval.get("approval_version") != DISCOVERY_APPROVAL_VERSION:
        raise WorldBuilderError(f"{path.name} has the wrong format (kind={approval.get('kind') if isinstance(approval, dict) else type(approval).__name__!r}, approval_version={approval.get('approval_version') if isinstance(approval, dict) else 'n/a'}; need kind='worldbuilder-discovery-single-round-approval', version={DISCOVERY_APPROVAL_VERSION})")
    if approval.get("build_id") != state.get("build_id") or approval.get("user_approved") is not True:
        raise WorldBuilderError(f"{path.name} is not user-authorized for this build (build_id={approval.get('build_id')!r} vs this build's {state.get('build_id')!r}, user_approved={approval.get('user_approved')!r})")
    if approval.get("plan_sha256") != sha256_file(plan_path) or approval.get("corpus_sha256") != plan.get("corpus_sha256"):
        raise WorldBuilderError(f"{path.name} is stale relative to the current plan (its own plan_sha256/corpus_sha256 no longer match {plan_path.name}'s actual current values): re-approve against the current plan")
    limit = approval.get("max_urls", 500)
    if not isinstance(limit, int) or limit <= 0:
        raise WorldBuilderError(f"{path.name}'s max_urls must be a positive integer, found {limit!r}")
    return approval, path, limit


def is_pure_verification_metric(metric: dict[str, Any], first_contact_allowance: int = 0) -> bool:
    """A verification pass only proves saturation when it re-verifies covered
    ground. A pass that newly covers URLs is doing first-contact (recovery)
    work, so its entity yield says nothing about saturation and is excluded
    from the low-yield chain."""
    return int(metric.get("new_visited_url_count", 0) or 0) <= first_contact_allowance


def frontier_closure_decision(*, closure_enabled: bool, candidate_count: int, denominator_passed: bool) -> bool:
    """For enumerable corpora, a closed crawl frontier IS the saturation proof:
    every expected URL accounted, no candidates outstanding, and every
    denominator (enumeration channels, independent sources, capture ratio)
    green. Entity-yield statistics then become diagnostics, not gates."""
    return bool(closure_enabled and candidate_count == 0 and denominator_passed)


def build_decision_options(*, effective_saturated: bool, unused_rounds: list, candidate_reasons: dict) -> list[dict[str, str]]:
    """Pure: the sanctioned next moves when discovery is stuck. Fires whenever
    unsaturated with no unused verification rounds left, regardless of
    residual candidate count (a P2/P9 fix in 3.6.5; this used to only fire
    when candidates were exactly zero, leaving a small number of dead-link
    candidates with no listed way forward at all)."""
    options: list[dict[str, str]] = []
    if effective_saturated or unused_rounds:
        return options
    if not candidate_reasons:
        options.append({
            "option": "pure_reverification",
            "detail": "Add a verification round to the plan that samples ONLY already-visited URLs; a low-yield pure round can prove saturation.",
        })
    else:
        options.append({
            "option": "governed_exclusion",
            "detail": (
                f"{len(candidate_reasons)} candidate URL(s) remain outstanding. If they are confirmed dead "
                "links or out-of-scope pages (verify status manually or with source_probe.py --delta-of), "
                "approve them individually in a governed exclusion approval file passed via "
                "--exclusion-approval; excluded candidates no longer block completeness."
            ),
        })
    options.append({
        "option": "approve_saturation_stop",
        "detail": "Set approve_saturation_stop: true in the governed exclusion approval file (thresholds tunable via saturation_policy.terminal_stop_entity_ratio / terminal_stop_new_url_count).",
    })
    options.append({
        "option": "delta_reprobe",
        "detail": "Run source_probe.py --delta-of <frozen probe> to extend the corpus if the source may have grown.",
    })
    return options


def apply_single_round_policy(minimum_rounds: int, consecutive: int, *, approved: bool, url_count: int, limit: int) -> tuple[int, int, bool]:
    """Pure policy: a valid waiver on a small enough corpus relaxes both round requirements to 1."""
    if approved and url_count <= limit:
        return 1, 1, True
    return minimum_rounds, consecutive, False


def load_exclusion_approval(path: Path | None, *, root: Path, state: dict[str, Any], plan_path: Path, plan: dict[str, Any]) -> tuple[dict[str, dict[str, str]], dict[str, Any] | None, Path | None]:
    if path is None or not path.exists():
        return {}, None, None
    approval = load_json(path)
    if not isinstance(approval, dict) or approval.get("kind") != "worldbuilder-discovery-exclusion-approval" or approval.get("approval_version") != DISCOVERY_APPROVAL_VERSION:
        raise WorldBuilderError(f"{path.name} has the wrong format (kind={approval.get('kind') if isinstance(approval, dict) else type(approval).__name__!r}, approval_version={approval.get('approval_version') if isinstance(approval, dict) else 'n/a'}; need kind='worldbuilder-discovery-exclusion-approval', version={DISCOVERY_APPROVAL_VERSION})")
    if approval.get("build_id") != state.get("build_id") or approval.get("user_approved") is not True:
        raise WorldBuilderError(f"{path.name} is not user-authorized for this build (build_id={approval.get('build_id')!r} vs this build's {state.get('build_id')!r}, user_approved={approval.get('user_approved')!r})")
    if approval.get("plan_sha256") != sha256_file(plan_path) or approval.get("corpus_sha256") != plan.get("corpus_sha256"):
        raise WorldBuilderError(f"{path.name} is stale relative to the current plan (its own plan_sha256/corpus_sha256 no longer match {plan_path.name}'s actual current values): re-approve against the current plan")
    rows = approval.get("approved_urls")
    if not isinstance(rows, list):
        raise WorldBuilderError(f"{path.name}'s 'approved_urls' must be a list, found {type(rows).__name__}")
    approved: dict[str, dict[str, str]] = {}
    for index, row in enumerate(rows):
        if not isinstance(row, dict):
            raise WorldBuilderError(f"{path.name}'s approved_urls[{index}] must be a JSON object, found {type(row).__name__}")
        url = canonicalize_url(row.get("url"))
        code = row.get("code")
        reason = row.get("reason")
        exclusion_policy(code)
        if not url or not isinstance(reason, str) or len(reason.strip()) < 5:
            raise WorldBuilderError(f"{path.name}'s approved_urls[{index}] needs a valid url (found {row.get('url')!r}), code (found {code!r}), and a reason of at least 5 characters (found {reason!r})")
        if url in approved:
            raise WorldBuilderError(f"{path.name} repeats {url!r}: each approved URL must appear at most once")
        approved[url] = {"url": url, "code": code, "reason": reason.strip()}
    return approved, approval, path


def build_argument_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--build-state", required=True)
    parser.add_argument("--exclusion-approval", help="Governed approval JSON; defaults to build-state path when present")
    parser.add_argument("--single-round-approval", help="User-approved waiver JSON allowing saturated small sources to pass with one verification round")
    parser.add_argument("--requirements", action="store_true", help="Read-only preflight: print what this gate checks against the current build state.")
    return parser


def validate_arguments(args) -> None:
    """Validate CLI-only invariants; discovery-state validation remains in orchestration."""
    return None


def orchestrate(args) -> int:
    try:
        state_path = Path(args.build_state).resolve()
        root, state = load_build_state(state_path)
        build_id = str(state.get("build_id", "")).strip()
        if not build_id:
            raise WorldBuilderError(f"{state_path} has no build_id: this is not a valid, initialized build-state.json; re-run init_build.py")
        discovery_cfg = state.get("discovery")
        if not isinstance(discovery_cfg, dict) or not discovery_cfg.get("required"):
            raise WorldBuilderError(f"this gate is only valid when state.discovery.required is true, found {discovery_cfg.get('required') if isinstance(discovery_cfg, dict) else discovery_cfg!r}: this build's own route does not require breadth discovery")

        assignments_dir = resolve_state_path(root, state, "assignments")
        discoveries_dir = resolve_state_path(root, state, "discoveries")
        runtime_dir = resolve_state_path(root, state, "discovery_runtime")
        receipt_path = resolve_state_path(root, state, "discovery_receipt")
        index_path = resolve_state_path(root, state, "discovery_index")
        plan_path = resolve_state_path(root, state, "discovery_plan")
        recovery_path = resolve_state_path(root, state, "discovery_recovery_plan", required=False) or (discoveries_dir / "discovery-recovery-plan.json")
        plan = load_json(plan_path)
        if not isinstance(plan, dict) or plan.get("kind") != "breadth-discovery-plan" or int(plan.get("plan_version", 0) or 0) not in {3, 4, DISCOVERY_PLAN_VERSION}:
            raise WorldBuilderError(f"{plan_path.name} must use a supported plan version (kind={plan.get('kind') if isinstance(plan, dict) else type(plan).__name__!r}, plan_version={plan.get('plan_version') if isinstance(plan, dict) else 'n/a'}; need kind='breadth-discovery-plan', version in {{3, 4, {DISCOVERY_PLAN_VERSION}}})")
        if plan.get("build_id") != build_id:
            raise WorldBuilderError(f"{plan_path.name}'s build_id ({plan.get('build_id')!r}) does not match this build's own build_id ({build_id!r})")
        corpus_sha = str(plan.get("corpus_sha256", ""))
        if not corpus_sha:
            raise WorldBuilderError(f"{plan_path.name} has no non-empty corpus_sha256: it was not authored against a resolved corpus")
        default_approval = resolve_state_path(root, state, "discovery_exclusion_approval", required=False)
        approval_path = Path(args.exclusion_approval).resolve() if args.exclusion_approval else default_approval
        approved_map, approval_data, approval_path = load_exclusion_approval(
            approval_path, root=root, state=state, plan_path=plan_path, plan=plan
        )
        default_single_round = resolve_state_path(root, state, "discovery_single_round_approval", required=False)
        single_round_path = Path(args.single_round_approval).resolve() if args.single_round_approval else default_single_round
        single_round_data, single_round_path, single_round_limit = load_single_round_approval(
            single_round_path, state=state, plan_path=plan_path, plan=plan
        )

        assignments = load_assignments(root, assignments_dir, plan)
        rows: list[dict[str, Any]] = []
        all_entities: dict[str, dict[str, Any]] = {}
        entity_first_pass: dict[str, int] = {}
        pass_entities: dict[int, set[str]] = defaultdict(set)
        pass_discovered_urls: dict[int, set[str]] = defaultdict(set)
        pass_visited_urls: dict[int, set[str]] = defaultdict(set)
        visited_all: set[str] = set()
        excluded_all: set[str] = set()
        failed_all: set[str] = set()
        failed_url_rounds: dict[str, set[int]] = defaultdict(set)
        delegated_all: set[str] = set()
        primary_accounted: set[str] = set()
        entity_assignment_frequency: dict[str, int] = defaultdict(int)
        candidate_reasons: dict[str, set[str]] = defaultdict(set)
        completed_verification_source_rounds: set[int] = set()
        completed_assignment_ids: set[str] = set()
        observed_child_sessions: set[str] = set()
        observed_spawn_runs: set[str] = set()
        observed_runtime_events: set[str] = set()
        verification_owned_outside_corpus: set[str] = set()
        expected_urls_seed = {url for url in plan.get("expected_urls", []) if isinstance(url, str)}
        prefilter_rows = plan.get("prefilter_accounting") if isinstance(plan.get("prefilter_accounting"), list) else []
        prefilter_accounted: set[str] = set()
        prefilter_class_counts: dict[str, int] = defaultdict(int)
        for index, row in enumerate(prefilter_rows):
            if not isinstance(row, dict):
                raise WorldBuilderError(f"{plan_path.name}'s prefilter_accounting[{index}] must be a JSON object, found {type(row).__name__}")
            url = canonicalize_url(row.get("url"))
            code = row.get("code")
            reason = row.get("reason")
            classification = row.get("classification")
            if not url or url not in expected_urls_seed:
                raise WorldBuilderError(f"{plan_path.name}'s prefilter_accounting[{index}]'s url ({row.get('url')!r}) is invalid or not one of the plan's own expected_urls")
            if not isinstance(reason, str) or len(reason.strip()) < 5:
                raise WorldBuilderError(f"{plan_path.name}'s prefilter_accounting[{index}] needs a reason of at least 5 characters, found {reason!r}")
            policy_row = exclusion_policy(code)
            if policy_row.get("approval_required"):
                raise WorldBuilderError(f"{plan_path.name}'s prefilter_accounting[{index}] uses approval-required code {code!r}: that requires a worker to actually visit the URL, or a governed exclusion approval; it cannot be silently prefiltered")
            if classification not in {"index_only", "reference_only", "alias_only", "excluded"}:
                raise WorldBuilderError(f"{plan_path.name}'s prefilter_accounting[{index}]'s classification is {classification!r}; must be one of {{'index_only', 'reference_only', 'alias_only', 'excluded'}}")
            if url in prefilter_accounted:
                raise WorldBuilderError(f"{plan_path.name}'s prefilter_accounting repeats {url!r}: each URL must appear at most once")
            prefilter_accounted.add(url)
            prefilter_class_counts[str(classification)] += 1
        primary_accounted.update(prefilter_accounted)
        excluded_all.update(prefilter_accounted)

        # Verify per-pass ownership before reading worker outputs.
        ownership: dict[tuple[int, str], str] = {}
        for assignment_path, assignment in assignments:
            if int(assignment.get("assignment_version", 0) or 0) not in {5, 6, DISCOVERY_ASSIGNMENT_VERSION}:
                raise WorldBuilderError(f"{assignment_path.name}'s assignment_version ({assignment.get('assignment_version')!r}) is unsupported; must be one of {{5, 6, {DISCOVERY_ASSIGNMENT_VERSION}}}")
            if int(assignment.get("assignment_version", 0) or 0) >= DISCOVERY_ASSIGNMENT_VERSION:
                validate_contract(assignment.get("contract"), label=f"{assignment_path.name}.contract")
            if assignment.get("build_id") != build_id:
                raise WorldBuilderError(f"{assignment_path.name}'s build_id ({assignment.get('build_id')!r}) does not match this build's own build_id ({build_id!r})")
            if assignment.get("corpus_sha256") != corpus_sha:
                raise WorldBuilderError(f"{assignment_path.name}'s corpus_sha256 ({assignment.get('corpus_sha256')!r}) does not match the root discovery corpus's own hash ({corpus_sha!r})")
            pass_number = int(assignment.get("pass_number", 0) or 0)
            if pass_number < 1:
                raise WorldBuilderError(f"{assignment_path.name}'s pass_number must be a positive integer, found {assignment.get('pass_number')!r}")
            for url in normalized_urls(assignment.get("page_urls"), f"{assignment_path.name} page_urls"):
                key = (pass_number, url)
                if key in ownership:
                    raise WorldBuilderError(
                        f"URL {url} is assigned twice in pass {pass_number}: {ownership[key]} and {assignment_path.name}"
                    )
                ownership[key] = assignment_path.name

        for assignment_path, assignment in assignments:
            output = rel_output(root, discoveries_dir, assignment)
            result = validate_discovery(output, assignment_path, assignment, build_id, corpus_sha)
            data = result["data"]
            runtime_path = runtime_path_for(root, runtime_dir, assignment)
            runtime = validate_runtime_receipt(
                runtime_path, assignment=assignment, assignment_path=assignment_path, result_path=output
            )
            child_session_id = runtime.get("child_session_id")
            echoed_child = data.get("_worldbuilder", {}).get("child_session_id")
            if runtime.get("runtime_source") == PARENT_OBSERVED_CHILD_RUN:
                child_session_id = str(child_session_id).strip()
                if echoed_child not in (None, "") and echoed_child != child_session_id:
                    raise WorldBuilderError(f"{assignment_path.name}'s discovery result echoes child_session_id {echoed_child!r}, but its own runtime receipt says {child_session_id!r}")
                if child_session_id in observed_child_sessions:
                    raise WorldBuilderError(
                        f"child session {child_session_id!r} is already bound to another discovery assignment: one child session cannot satisfy more than one assignment"
                    )
            elif echoed_child not in (None, ""):
                raise WorldBuilderError(f"{assignment_path.name}'s exec-completion result claims child_session_id {echoed_child!r}, but exec completions must not claim an OpenClaw child session at all")
            if runtime["run_id"] in observed_spawn_runs:
                raise WorldBuilderError(f"sessions_spawn run_id {runtime['run_id']!r} is already bound to another discovery assignment: one spawn run cannot satisfy more than one assignment")
            if runtime["runtime_event_id"] in observed_runtime_events:
                raise WorldBuilderError(f"runtime completion event {runtime['runtime_event_id']!r} is already bound to another discovery assignment: one completion event cannot satisfy more than one assignment")
            if child_session_id:
                observed_child_sessions.add(str(child_session_id))
            observed_spawn_runs.add(runtime["run_id"])
            observed_runtime_events.add(runtime["runtime_event_id"])
            pass_number = int(assignment["pass_number"])
            stage = str(assignment.get("stage"))
            visited = set(result["visited"])
            excluded = set(result["excluded"])
            failed = set(result["failed"])
            delegated = set(result["delegated"])
            discovered = set(result["discovered"])
            visited_all.update(visited)
            excluded_all.update(excluded)
            failed_all.update(failed)
            if stage == "breadth_recovery":
                for url in failed:
                    failed_url_rounds[url].add(pass_number)
            delegated_all.update(delegated)
            pass_discovered_urls[pass_number].update(discovered)
            pass_visited_urls[pass_number].update(visited)
            if stage in {"breadth_discovery", "breadth_recovery"}:
                primary_accounted.update(visited | excluded)
            if stage == "breadth_verification":
                verification_owned_outside_corpus.update(set(result["assigned"]) - set(plan.get("expected_urls", [])))
                if isinstance(assignment.get("source_round"), int):
                    completed_verification_source_rounds.add(int(assignment["source_round"]))
            completed_assignment_ids.add(str(assignment.get("assignment_id")))
            assignment_entity_keys: set[str] = set()
            for entity in data.get("entities", []):
                key = entity_key(entity)
                assignment_entity_keys.add(key)
                pass_entities[pass_number].add(key)
                if key not in all_entities:
                    all_entities[key] = json.loads(json.dumps(entity))
                    entity_first_pass[key] = pass_number
                else:
                    merge_entity(all_entities[key], entity)
            for key in assignment_entity_keys:
                entity_assignment_frequency[key] += 1
            rows.append({
                "assignment_id": assignment.get("assignment_id"),
                "worker": assignment.get("worker"),
                "taskName": assignment.get("taskName"),
                "stage": stage,
                "pass_number": pass_number,
                "assignment_path": str(assignment_path.relative_to(root)).replace("\\", "/"),
                "assignment_sha256": sha256_file(assignment_path),
                "output": str(output.relative_to(root)).replace("\\", "/"),
                "output_sha256": sha256_file(output),
                "owned_url_count": len(result["assigned"]),
                "visited_url_count": len(visited),
                "excluded_url_count": len(excluded),
                "failed_url_count": len(failed),
                "delegated_url_count": len(delegated),
                "child_session_id": runtime.get("child_session_id"),
                "runtime_source": runtime.get("runtime_source"),
                "run_id": runtime.get("run_id"),
                "runtime_event_id": runtime.get("runtime_event_id"),
                "runtime_receipt": str(runtime_path.relative_to(root)).replace("\\", "/"),
                "runtime_receipt_sha256": sha256_file(runtime_path),
                "discovered_url_count": len(discovered),
                "entity_count": len(data.get("entities", [])),
            })

        prefilter_aliases_applied = apply_prefilter_aliases(all_entities, plan.get("alias_map"))
        expected_urls = {url for url in plan.get("expected_urls", []) if isinstance(url, str)}
        successful_urls = visited_all | excluded_all
        # Recovery is resolved by a later successful visit/exclusion. Historical
        # failures remain in metrics but do not create an infinite recovery loop.
        unresolved_primary = expected_urls - primary_accounted
        for url in unresolved_primary:
            candidate_reasons[url].add("unaccounted_primary_url")
        confirmed_dead_threshold = max(0, min(5, int((plan.get("saturation_policy") or {}).get("confirmed_dead_after_rounds", 2))))
        confirmed_dead: set[str] = set()
        for url in (failed_all - successful_urls):
            if len(failed_url_rounds.get(url, ())) >= confirmed_dead_threshold:
                candidate_reasons[url].add("confirmed_dead_pending_exclusion")
                # Exhausting the configured retry limit is a fact, not a scope decision.
                # Choosing not to fetch a URL removes possible canon and needs consent;
                # a URL that cannot be fetched after the user's own configured number of
                # attempts contains nothing to remove. The limit is the consent.
                candidate_reasons[url].add("retry_budget_exhausted")
                confirmed_dead.add(url)
            else:
                candidate_reasons[url].add("worker_failed_url")
        for url in (delegated_all - successful_urls):
            candidate_reasons[url].add("worker_delegated_url")
        for url in verification_owned_outside_corpus:
            if url not in expected_urls:
                candidate_reasons[url].add("independent_verification_url_outside_planned_corpus")
        for url in set().union(*pass_discovered_urls.values()):
            if url not in expected_urls:
                candidate_reasons[url].add("new_internal_url")

        approved_current: dict[str, dict[str, str]] = {}
        for url, row in approved_map.items():
            if url in candidate_reasons:
                approved_current[url] = row
                candidate_reasons.pop(url, None)
                excluded_all.add(url)
                if url in expected_urls:
                    primary_accounted.add(url)

        sources = plan.get("sources") if isinstance(plan.get("sources"), dict) else {}
        source_coverage: dict[str, Any] = {}
        for name, source in sources.items():
            source_urls = {url for url in source.get("urls", []) if isinstance(url, str)} if isinstance(source, dict) else set()
            covered = source_urls & (visited_all | excluded_all)
            ratio = len(covered) / len(source_urls) if source_urls else 1.0
            source_coverage[name] = {
                "listed": len(source_urls),
                "accounted": len(covered),
                "ratio": ratio,
                "missing": sorted(source_urls - (visited_all | excluded_all)),
            }

        policy = plan.get("coverage_policy") if isinstance(plan.get("coverage_policy"), dict) else {}
        primary_ratio = len(expected_urls & primary_accounted) / len(expected_urls) if expected_urls else 1.0
        reprobe_reasons: list[str] = []
        reported_total = plan.get("metrics_at_plan", {}).get("reported_allpages_total") if isinstance(plan.get("metrics_at_plan"), dict) else None
        listed_allpages = int(source_coverage.get("allpages", {}).get("listed", 0))
        probe_health = plan.get("probe_health") if isinstance(plan.get("probe_health"), dict) else {}
        if isinstance(reported_total, int) and reported_total > len(expected_urls):
            reprobe_reasons.append(
                f"additive corpus has {len(expected_urls)} URLs but MediaWiki reports at least {reported_total} articles; rerun source_probe without truncation"
            )
        if listed_allpages and not probe_health.get("allpages_complete") and (not isinstance(reported_total, int) or len(expected_urls) < reported_total):
            reprobe_reasons.append("MediaWiki AllPages enumeration was incomplete and the additive union did not reconcile its reported total")
        if int(source_coverage.get("redirects", {}).get("listed", 0)) and not probe_health.get("redirects_complete"):
            reprobe_reasons.append("MediaWiki redirect/alias enumeration was not complete")
        lower_bound = plan.get("metrics_at_plan", {}).get("lower_bound_page_count") if isinstance(plan.get("metrics_at_plan"), dict) else None
        if isinstance(lower_bound, int) and len(expected_urls) < lower_bound:
            reprobe_reasons.append(
                f"planned union has {len(expected_urls)} URLs below independent lower bound {lower_bound}"
            )

        required_source_ratios = {
            "allpages": float(policy.get("allpages_reconciliation_ratio", 0.995)),
            "special_allpages": float(policy.get("special_allpages_reconciliation_ratio", 0.995)),
            "sitemap": float(policy.get("sitemap_reconciliation_ratio", 0.995)),
            "categories": float(policy.get("category_reconciliation_ratio", 0.98)),
        }
        for name, minimum in required_source_ratios.items():
            row = source_coverage.get(name)
            if row and row["listed"] and row["ratio"] < minimum:
                for url in row["missing"]:
                    candidate_reasons[url].add(f"{name}_reconciliation_gap")

        verification_assignments = [row for row in rows if row["stage"] == "breadth_verification"]
        minimum_rounds = int(plan.get("saturation_policy", {}).get("minimum_verification_rounds", 2))
        _sr_consecutive = int((plan.get("saturation_policy") or {}).get("consecutive_low_yield_rounds", 2))
        minimum_rounds, _sr_consecutive, single_round_applied = apply_single_round_policy(
            minimum_rounds, _sr_consecutive,
            approved=single_round_data is not None, url_count=len(expected_urls), limit=single_round_limit,
        )
        if len({row["pass_number"] for row in verification_assignments}) < minimum_rounds:
            reprobe_reasons.append("fewer than the required independent verification passes completed")

        # Dynamic saturation: count entities first seen in each pass and URLs newly
        # discovered outside the planned corpus. Only verification passes count as
        # saturation evidence; recovery passes cannot certify themselves.
        pass_metrics: list[dict[str, Any]] = []
        seen_before: set[str] = set()
        visited_running: set[str] = set()
        for pass_number in sorted(set(pass_entities) | set(pass_discovered_urls)):
            current = pass_entities.get(pass_number, set())
            new_entities = current - seen_before
            before_count = len(seen_before)
            seen_before.update(current)
            new_urls = {url for url in pass_discovered_urls.get(pass_number, set()) if url not in expected_urls}
            pass_visited = pass_visited_urls.get(pass_number, set())
            new_visited = pass_visited - visited_running
            visited_running |= pass_visited
            stage_names = sorted({row["stage"] for row in rows if row["pass_number"] == pass_number})
            pass_metrics.append({
                "pass_number": pass_number,
                "stages": stage_names,
                "entity_count": len(current),
                "new_entity_count": len(new_entities),
                "new_entity_ratio": len(new_entities) / max(1, before_count),
                "new_url_count": len(new_urls),
                "new_visited_url_count": len(new_visited),
            })

        saturation_policy = plan.get("saturation_policy") if isinstance(plan.get("saturation_policy"), dict) else {}
        consecutive = _sr_consecutive if single_round_applied else int(saturation_policy.get("consecutive_low_yield_rounds", 2))
        ratio_limit = float(saturation_policy.get("low_yield_entity_ratio", 0.01))
        new_url_limit = int(saturation_policy.get("low_yield_new_url_count", 0))
        floor = int(saturation_policy.get("minimum_new_entities_floor", 2))
        verification_metrics = [
            metric for metric in pass_metrics
            if "breadth_verification" in metric["stages"]
        ]
        first_contact_allowance = int(saturation_policy.get("verification_first_contact_allowance", 0))
        pure_verification_metrics = [
            metric for metric in verification_metrics
            if is_pure_verification_metric(metric, first_contact_allowance)
        ]
        mixed_verification_count = len(verification_metrics) - len(pure_verification_metrics)
        low_flags: list[bool] = []
        for metric in pure_verification_metrics:
            threshold = max(floor, math.floor(max(1, len(all_entities) - metric["new_entity_count"]) * ratio_limit))
            low_flags.append(metric["new_entity_count"] <= threshold and metric["new_url_count"] <= new_url_limit)
        saturated = len(low_flags) >= consecutive and all(low_flags[-consecutive:])

        # New entities found in PURE verification are evidence that the corpus
        # was not saturated. Mixed rounds (rounds that newly covered URLs) are
        # first-contact work and cannot prove or disprove saturation.
        if saturated:
            saturation_reason = None
        elif mixed_verification_count and not pure_verification_metrics:
            saturation_reason = (
                f"all {mixed_verification_count} verification round(s) newly covered URLs (first-contact work); "
                "no pure re-verification round has run, so yield-based saturation cannot be evaluated"
            )
        else:
            saturation_reason = "independent verification has not reached consecutive low-yield rounds"

        all_rounds = plan.get("verification_rounds", []) if isinstance(plan.get("verification_rounds"), list) else []
        unused_rounds = [
            row for row in all_rounds
            if isinstance(row, dict) and isinstance(row.get("round"), int) and row["round"] not in completed_verification_source_rounds
        ]
        next_pass = max([int(row["pass_number"]) for row in rows] + [1]) + 1
        lower_bound_capture = min(1.0, len(expected_urls) / lower_bound) if isinstance(lower_bound, int) and lower_bound > 0 else 1.0
        frequency_values = list(entity_assignment_frequency.values())
        singletons = sum(value == 1 for value in frequency_values)
        doubletons = sum(value == 2 for value in frequency_values)
        observed_entities = len(all_entities)
        chao_unseen = (singletons * singletons) / (2 * doubletons) if doubletons else (singletons * max(0, singletons - 1)) / 2
        chao_estimate = observed_entities + chao_unseen
        chao_completeness = observed_entities / chao_estimate if chao_estimate else 1.0
        plan_metrics = plan.get("metrics_at_plan", {}) if isinstance(plan.get("metrics_at_plan"), dict) else {}
        independent_source_count = int(plan_metrics.get("independent_source_count", 0) or 0)
        independent_family_count = int(plan_metrics.get("independent_family_count", 0) or 0)
        minimum_sources = int(saturation_policy.get("minimum_independent_source_count", 3) or 3)
        enumerator_channels = int(probe_health.get("enumeration_channels", 0) or 0)
        supplemental_channels = int(probe_health.get("supplemental_channels", 0) or 0)
        source_class_passed = enumerator_channels >= 1 and supplemental_channels >= 1
        completeness = {
            "planned_union_count": len(expected_urls),
            "independent_lower_bound": lower_bound,
            "lower_bound_capture_ratio": lower_bound_capture,
            "required_lower_bound_capture_ratio": 0.995,
            "primary_accounted_ratio": primary_ratio,
            "required_primary_accounted_ratio": float(policy.get("primary_url_ratio", 1.0)),
            "independent_source_count": independent_source_count,
            "minimum_independent_source_count": minimum_sources,
            "independent_family_count": independent_family_count,
            "minimum_independent_family_count": 2,
            "enumeration_channels": enumerator_channels,
            "supplemental_channels": supplemental_channels,
            "source_class_requirement_passed": source_class_passed,
            "verification_rounds_completed": len(verification_metrics),
            "capture_recapture": {
                "observed_entities": observed_entities,
                "singletons": singletons,
                "doubletons": doubletons,
                "chao1_estimated_entities": round(chao_estimate, 3),
                "estimated_completeness_ratio": round(chao_completeness, 6),
                "diagnostic_only": True,
            },
        }
        denominator_passed = (
            lower_bound_capture >= 0.995
            and primary_ratio >= float(policy.get("primary_url_ratio", 1.0))
            and independent_source_count >= minimum_sources
            and independent_family_count >= 2
            and source_class_passed
        )
        frontier_closed = frontier_closure_decision(
            closure_enabled=bool(saturation_policy.get("closure_saturates", True)),
            candidate_count=len(candidate_reasons),
            denominator_passed=denominator_passed,
        )
        completeness_passed = denominator_passed and (
            len(verification_metrics) >= minimum_rounds or frontier_closed
        )
        approve_stop_requested = bool(approval_data and approval_data.get("approve_saturation_stop"))
        latest_metric = verification_metrics[-1] if verification_metrics else None
        terminal_low_yield = bool(
            latest_metric
            and latest_metric.get("new_entity_ratio", 1.0) <= float(saturation_policy.get("terminal_stop_entity_ratio", 0.02))
            and latest_metric.get("new_url_count", 999999) <= int(saturation_policy.get("terminal_stop_new_url_count", 5))
            and len(verification_metrics) >= minimum_rounds
        )
        approved_saturation_stop = bool(approve_stop_requested and terminal_low_yield and not candidate_reasons)
        effective_saturated = saturated or approved_saturation_stop or frontier_closed
        saturation_method = (
            "yield" if saturated
            else "approved_terminal_stop" if approved_saturation_stop
            else "frontier_closure" if frontier_closed
            else None
        )

        resolved_entities, entity_resolution_report = resolve_entities(
            [all_entities[key] for key in sorted(all_entities)]
        )
        resolved_entity_map = {entity_key(entity): entity for entity in resolved_entities}
        all_entities = resolved_entity_map

        metrics = {
            "primary": {
                "expected_url_count": len(expected_urls),
                "accounted_url_count": len(expected_urls & primary_accounted),
                "visited_url_count": len(expected_urls & visited_all),
                "excluded_url_count": len(expected_urls & excluded_all),
                "failed_url_count": len(failed_all & expected_urls),
                "delegated_url_count": len(delegated_all & expected_urls),
                "coverage_ratio": primary_ratio,
                "required_ratio": float(policy.get("primary_url_ratio", 1.0)),
                "prefilter_accounted_count": len(prefilter_accounted),
                "prefilter_classification_counts": dict(sorted(prefilter_class_counts.items())),
                "prefilter_aliases_applied": prefilter_aliases_applied,
            },
            "source_coverage": source_coverage,
            "completeness": {**completeness, "passed": completeness_passed},
            "unique_entity_count": len(all_entities),
            "entity_resolution": {
                "merged_group_count": len(entity_resolution_report),
                "groups": entity_resolution_report,
            },
            "pass_metrics": pass_metrics,
            "saturation": {
                "saturated": saturated,
                "effective_saturated": effective_saturated,
                "approved_terminal_stop": approved_saturation_stop,
                "method": saturation_method,
                "frontier_closed": frontier_closed,
                "reason": None if effective_saturated else saturation_reason,
                "required_consecutive_low_yield_rounds": consecutive,
                "verification_pass_count": len(verification_metrics),
                "pure_verification_pass_count": len(pure_verification_metrics),
                "mixed_verification_pass_count": mixed_verification_count,
                "verification_first_contact_allowance": first_contact_allowance,
                "low_yield_flags": low_flags,
            },
            "governed_exclusions": {
                "approved_count": len(approved_current),
                "approved_urls": [approved_current[url] for url in sorted(approved_current)],
                "approval_present": approval_data is not None,
            },
        }

        # If more independent rounds exist, lack of saturation is recoverable
        # without re-probing. Denominator/enumerator defects can never be waived.
        if not effective_saturated and not unused_rounds:
            reprobe_reasons.append(
                "no unused independent verification rounds remain to prove saturation by yield; "
                "sanctioned options are listed in the recovery plan's decision_options"
            )
        incomplete = bool(candidate_reasons or reprobe_reasons or not completeness_passed or not effective_saturated)
        index = {
            "kind": "breadth-discovery-index",
            "index_version": 3,
            "status": "provisional" if incomplete else "complete",
            "build_id": build_id,
            "plan_sha256": sha256_file(plan_path),
            "corpus_sha256": corpus_sha,
            "single_round_applied": single_round_applied,
            "single_round_approval": str(single_round_path.relative_to(root)).replace("\\", "/") if single_round_path else None,
            "single_round_approval_sha256": sha256_file(single_round_path) if single_round_path else None,
            "single_round_url_limit": single_round_limit if single_round_data else None,
            "assignment_count": len(rows),
            "unique_child_session_count": len(observed_child_sessions),
            "unique_spawn_run_count": len(observed_spawn_runs),
            "unique_runtime_event_count": len(observed_runtime_events),
            "unique_entity_count": len(all_entities),
            "prefilter_accounted_count": len(prefilter_accounted),
            "prefilter_aliases_applied": prefilter_aliases_applied,
            "assignments": sorted(rows, key=lambda row: (row["pass_number"], row["assignment_id"])),
            "entities": [all_entities[key] for key in sorted(all_entities)],
            "metrics": metrics,
        }
        atomic_write_json(index_path, index)

        if incomplete:
            decision_options = build_decision_options(
                effective_saturated=effective_saturated, unused_rounds=unused_rounds, candidate_reasons=candidate_reasons,
            )
            write_recovery_plan(
                recovery_path,
                build_id=build_id,
                plan_path=plan_path,
                candidate_reasons=candidate_reasons,
                reprobe_reasons=reprobe_reasons,
                next_pass=next_pass,
                unused_verification_rounds=unused_rounds,
                metrics=metrics,
                decision_options=decision_options,
            )
            state.setdefault("discovery", {})["status"] = "recovery_required"
            state["discovery"]["recovery_plan"] = str(recovery_path.relative_to(root)).replace("\\", "/")
            atomic_write_json(state_path, state)
            print(json.dumps({
                "status": "recovery_required",
                "recovery_plan": str(recovery_path),
                "candidate_urls": len(candidate_reasons),
                "reprobe_reasons": reprobe_reasons,
                "saturated": saturated,
            }, indent=2))
            return 2

        if recovery_path.exists():
            recovery_path.unlink()
        final_status = "passed_with_exclusions" if approved_current or approved_saturation_stop else "complete"
        receipt = {
            "kind": "breadth-discovery-gate",
            "receipt_version": DISCOVERY_GATE_RECEIPT_VERSION,
            "status": final_status,
            "build_id": build_id,
            "plan": str(plan_path.relative_to(root)).replace("\\", "/"),
            "plan_sha256": sha256_file(plan_path),
            "corpus_sha256": corpus_sha,
            "index": str(index_path.relative_to(root)).replace("\\", "/"),
            "index_sha256": sha256_file(index_path),
            "assignment_count": len(rows),
            "unique_child_session_count": len(observed_child_sessions),
            "unique_spawn_run_count": len(observed_spawn_runs),
            "unique_runtime_event_count": len(observed_runtime_events),
            "assignments": sorted(rows, key=lambda row: (row["pass_number"], row["assignment_id"])),
            "unique_entity_count": len(all_entities),
            "prefilter_accounted_count": len(prefilter_accounted),
            "prefilter_aliases_applied": prefilter_aliases_applied,
            "metrics": metrics,
            "bounded_coverage_proven": True,
        "completeness_proven": True,  # legacy receipt compatibility
            "saturation_proven": bool(saturated),
            "effective_saturation_accepted": bool(effective_saturated),
            "exclusion_approval": str(approval_path.relative_to(root)).replace("\\", "/") if approval_data and approval_path else None,
            "exclusion_approval_sha256": sha256_file(approval_path) if approval_data and approval_path else None,
            "approved_exclusion_count": len(approved_current),
            "all_assignments_completed": sorted(completed_assignment_ids),
        }
        atomic_write_json(receipt_path, receipt)
        state.setdefault("discovery", {})["status"] = final_status
        state["discovery"]["receipt_sha256"] = sha256_file(receipt_path)
        atomic_write_json(state_path, state)
        advance_pipeline_stage(state_path, "research_discovery")
        print(json.dumps({"status": final_status, "receipt": str(receipt_path), "entities": len(all_entities), "approved_exclusions": len(approved_current)}, indent=2))
        return 0
    except (WorldBuilderError, OSError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        print(step_driver_pointer(), file=sys.stderr)
        return 1


def requirements_preflight(build_state: str) -> int:
    root, state = load_build_state(build_state)
    print(json.dumps(preflight_report("discovery_gate", requirement_rows(Path(__file__), root, state)), ensure_ascii=False, indent=2))
    return 0


def main() -> int:
    parser = build_argument_parser()
    args = parser.parse_args()
    if args.requirements:
        return requirements_preflight(args.build_state)
    try:
        validate_arguments(args)
    except WorldBuilderError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    return orchestrate(args)

if __name__ == "__main__":
    raise SystemExit(main())
