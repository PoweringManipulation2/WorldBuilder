#!/usr/bin/env python3
"""Serialize WorldBuilder extension semantics to source-verified target shapes.

This module is intentionally target-specific. The internal envelope is a
WorldBuilder contract, not a claim that SillyTavern or third-party extensions
share one universal schema.
"""
from __future__ import annotations

import argparse
import copy
import json
import uuid
from pathlib import Path
from typing import Any, Callable, Mapping

from wb_common import WorldBuilderError, atomic_write_json, load_json

CONTRACT = "worldbuilder-extension-adapter-v1"
SOURCE_VERIFIED_DATE = "2026-09-04"
QUICK_REPLY_SET_VERSION_KEY = "version"
QUICK_REPLY_SET_VERSION = 2

EXTENSIONS = {
    "quick_replies",
    "regex",
    "vector_storage",
    "timed_effects",
    "mvu",
    "ejs",
}

TARGETS: dict[str, tuple[str, ...]] = {
    "quick_replies": ("quick_reply_set_v2",),
    "regex": ("regex_script_v1", "character_regex_scripts"),
    "vector_storage": ("world_info_native", "ccv3_extensions", "settings_patch"),
    "timed_effects": ("world_info_native", "ccv3_extensions"),
    "mvu": ("world_info_initvar",),
    "ejs": ("template_text", "world_info_entry"),
}

SOURCE_BASELINES: dict[str, dict[str, Any]] = {
    "quick_replies": {
        "project": "SillyTavern",
        "branch": "release",
        "verified": SOURCE_VERIFIED_DATE,
        "sources": [
            "public/scripts/extensions/quick-reply/src/QuickReply.js",
            "public/scripts/extensions/quick-reply/src/QuickReplySet.js",
            "public/scripts/extensions/quick-reply/index.js",
        ],
        "contract": "QuickReply.toJSON + QuickReplySet.toJSON version 2",
    },
    "regex": {
        "project": "SillyTavern",
        "branch": "release",
        "verified": SOURCE_VERIFIED_DATE,
        "sources": [
            "public/scripts/char-data.js",
            "public/scripts/extensions/regex/engine.js",
        ],
        "contract": "RegexScriptData + regex_placement",
    },
    "vector_storage": {
        "project": "SillyTavern",
        "branch": "release",
        "verified": SOURCE_VERIFIED_DATE,
        "sources": [
            "public/scripts/extensions/vectors/index.js",
            "public/scripts/world-info.js",
        ],
        "contract": "extension_settings.vectors + World Info vectorized",
    },
    "timed_effects": {
        "project": "SillyTavern",
        "branch": "release",
        "verified": SOURCE_VERIFIED_DATE,
        "sources": ["public/scripts/world-info.js", "World Info documentation"],
        "contract": "World Info sticky/cooldown/delay",
    },
    "mvu": {
        "project": "MagVarUpdate",
        "branch": "beta",
        "verified": SOURCE_VERIFIED_DATE,
        "sources": ["doc/tutorial.md", "src/variable_def.ts"],
        "contract": "[InitVar] World Info initializer + MVU stat_data model",
    },
    "ejs": {
        "project": "ST-Prompt-Template",
        "branch": "main",
        "verified": SOURCE_VERIFIED_DATE,
        "sources": ["manifest.json", "docs/features.md"],
        "contract": "EJS template blocks + documented World Info memo prefixes",
    },
}

REGEX_PLACEMENTS = {
    "user_input": 1,
    "ai_output": 2,
    "slash_command": 3,
    "world_info": 5,
    "reasoning": 6,
}
REGEX_ACTIVE_PLACEMENT_VALUES = set(REGEX_PLACEMENTS.values())
REGEX_SUBSTITUTION = {"none": 0, "raw": 1, "escaped": 2}

EJS_INJECTION_PREFIXES = {
    "generate_before": "[GENERATE:BEFORE]",
    "generate_after": "[GENERATE:AFTER]",
    "render_before": "[RENDER:BEFORE]",
    "render_after": "[RENDER:AFTER]",
    "initial_variables": "[InitialVariables]",
}


def _expect_object(value: Any, label: str) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise WorldBuilderError(f"{label} must be an object")
    return value


def _reject_unknown(payload: Mapping[str, Any], allowed: set[str], label: str) -> None:
    unknown = sorted(set(payload) - allowed)
    if unknown:
        raise WorldBuilderError(f"{label} contains unsupported field(s): {', '.join(unknown)}")


def _required_string(payload: Mapping[str, Any], key: str, label: str) -> str:
    value = payload.get(key)
    if not isinstance(value, str) or not value.strip():
        raise WorldBuilderError(f"{label}.{key} must be a non-empty string")
    return value


def _optional_string(payload: Mapping[str, Any], key: str, default: str = "") -> str:
    value = payload.get(key, default)
    if not isinstance(value, str):
        raise WorldBuilderError(f"{key} must be a string")
    return value


def _bool(payload: Mapping[str, Any], key: str, default: bool) -> bool:
    value = payload.get(key, default)
    if not isinstance(value, bool):
        raise WorldBuilderError(f"{key} must be boolean")
    return value


def _string_list(value: Any, label: str) -> list[str]:
    if value is None:
        return []
    if not isinstance(value, list) or any(not isinstance(item, str) for item in value):
        raise WorldBuilderError(f"{label} must be an array of strings")
    return list(value)


def _nonnegative_int(value: Any, label: str, *, allow_none: bool = False) -> int | None:
    if value is None and allow_none:
        return None
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        suffix = " or null" if allow_none else ""
        raise WorldBuilderError(f"{label} must be a non-negative integer{suffix}")
    return value


def _positive_int(value: Any, label: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
        raise WorldBuilderError(f"{label} must be a positive integer")
    return value


def validate_internal_repr(value: Any) -> dict[str, Any]:
    row = _expect_object(value, "extension adapter input")
    _reject_unknown(row, {"contract", "extension", "payload"}, "extension adapter input")
    if row.get("contract") != CONTRACT:
        raise WorldBuilderError(f"extension adapter input.contract must be {CONTRACT!r}")
    extension = row.get("extension")
    if extension not in EXTENSIONS:
        raise WorldBuilderError(f"extension must be one of: {', '.join(sorted(EXTENSIONS))}")
    payload = _expect_object(row.get("payload"), "extension adapter input.payload")
    return {"contract": CONTRACT, "extension": extension, "payload": copy.deepcopy(payload)}


def _quick_reply_item(row: Any, index: int) -> dict[str, Any]:
    item = _expect_object(row, f"quick_replies.payload.quick_replies[{index}]")
    allowed = {
        "id", "icon", "show_label", "label", "title", "message", "context_list",
        "prevent_auto_execute", "is_hidden", "execute_on_startup", "execute_on_user",
        "execute_on_ai", "execute_on_chat_change", "execute_on_group_member_draft",
        "execute_on_new_chat", "execute_before_generation", "automation_id",
    }
    _reject_unknown(item, allowed, f"quick_replies.payload.quick_replies[{index}]")
    item_id = item.get("id", index + 1)
    if isinstance(item_id, bool) or not isinstance(item_id, int) or item_id <= 0:
        raise WorldBuilderError("Quick Reply id must be a positive integer")
    automation = _optional_string(item, "automation_id")
    if automation:
        raise WorldBuilderError(
            "non-empty Quick Reply automation_id is outside Batch 23 item 7 scope; "
            "item 7 serializes Quick Reply assets but does not wire automations"
        )
    contexts = item.get("context_list", [])
    if not isinstance(contexts, list):
        raise WorldBuilderError("Quick Reply context_list must be an array")
    context_out: list[dict[str, Any]] = []
    for idx, context in enumerate(contexts):
        ctx = _expect_object(context, f"Quick Reply context_list[{idx}]")
        _reject_unknown(ctx, {"set", "is_chained"}, f"Quick Reply context_list[{idx}]")
        context_out.append({
            "set": _required_string(ctx, "set", f"Quick Reply context_list[{idx}]"),
            "isChained": _bool(ctx, "is_chained", False),
        })
    return {
        "id": item_id,
        "icon": _optional_string(item, "icon"),
        "showLabel": _bool(item, "show_label", False),
        "label": _optional_string(item, "label"),
        "title": _optional_string(item, "title"),
        "message": _optional_string(item, "message"),
        "contextList": context_out,
        "preventAutoExecute": _bool(item, "prevent_auto_execute", True),
        "isHidden": _bool(item, "is_hidden", False),
        "executeOnStartup": _bool(item, "execute_on_startup", False),
        "executeOnUser": _bool(item, "execute_on_user", False),
        "executeOnAi": _bool(item, "execute_on_ai", False),
        "executeOnChatChange": _bool(item, "execute_on_chat_change", False),
        "executeOnGroupMemberDraft": _bool(item, "execute_on_group_member_draft", False),
        "executeOnNewChat": _bool(item, "execute_on_new_chat", False),
        "executeBeforeGeneration": _bool(item, "execute_before_generation", False),
        "automationId": "",
    }


def _serialize_quick_replies(payload: dict[str, Any], target: str) -> dict[str, Any]:
    _reject_unknown(
        payload,
        {"name", "disable_send", "place_before_input", "inject_input", "color", "only_border_color", "quick_replies", "id_index"},
        "quick_replies.payload",
    )
    if target != "quick_reply_set_v2":
        raise WorldBuilderError("quick_replies supports only quick_reply_set_v2")
    rows = payload.get("quick_replies", [])
    if not isinstance(rows, list):
        raise WorldBuilderError("quick_replies.payload.quick_replies must be an array")
    quick_replies = [_quick_reply_item(row, idx) for idx, row in enumerate(rows)]
    ids = [row["id"] for row in quick_replies]
    if len(ids) != len(set(ids)):
        raise WorldBuilderError("Quick Reply ids must be unique")
    id_index = payload.get("id_index", max(ids, default=0))
    if isinstance(id_index, bool) or not isinstance(id_index, int) or id_index < max(ids, default=0):
        raise WorldBuilderError("quick_replies.payload.id_index must be an integer at least as large as every item id")
    return {
        QUICK_REPLY_SET_VERSION_KEY: QUICK_REPLY_SET_VERSION,
        "name": _required_string(payload, "name", "quick_replies.payload"),
        "disableSend": _bool(payload, "disable_send", False),
        "placeBeforeInput": _bool(payload, "place_before_input", False),
        "injectInput": _bool(payload, "inject_input", False),
        "color": _optional_string(payload, "color", "transparent"),
        "onlyBorderColor": _bool(payload, "only_border_color", False),
        "qrList": quick_replies,
        "idIndex": id_index,
    }


def _regex_id(payload: Mapping[str, Any]) -> str:
    explicit = payload.get("id")
    if explicit is not None:
        if not isinstance(explicit, str) or not explicit.strip():
            raise WorldBuilderError("regex.payload.id must be a non-empty string")
        return explicit
    stable = json.dumps(
        {
            key: payload.get(key)
            for key in ("name", "find_regex", "replace_string", "trim_strings", "placements")
        },
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    )
    return str(uuid.uuid5(uuid.NAMESPACE_URL, f"worldbuilder:regex:{stable}"))


def _regex_placements(value: Any) -> list[int]:
    if not isinstance(value, list) or not value:
        raise WorldBuilderError("regex.payload.placements must be a non-empty array")
    result: list[int] = []
    for raw in value:
        if isinstance(raw, str):
            normalized = raw.strip().casefold().replace(" ", "_")
            if normalized not in REGEX_PLACEMENTS:
                raise WorldBuilderError(f"unsupported Regex placement {raw!r}")
            resolved = REGEX_PLACEMENTS[normalized]
        elif isinstance(raw, int) and not isinstance(raw, bool):
            resolved = raw
        else:
            raise WorldBuilderError("Regex placements must be current placement names or integers")
        if resolved not in REGEX_ACTIVE_PLACEMENT_VALUES:
            if resolved == 0:
                raise WorldBuilderError("Regex placement 0 (MD_DISPLAY) is deprecated in current SillyTavern")
            if resolved == 4:
                raise WorldBuilderError("Regex placement 4 (sendAs) is legacy and migrated to SLASH_COMMAND")
            raise WorldBuilderError(f"unsupported current Regex placement value {resolved}")
        if resolved not in result:
            result.append(resolved)
    return result


def _regex_substitution(value: Any) -> int:
    if value is None:
        return 0
    if isinstance(value, str):
        normalized = value.strip().casefold()
        if normalized not in REGEX_SUBSTITUTION:
            raise WorldBuilderError("regex.payload.substitute_regex must be none, raw, or escaped")
        return REGEX_SUBSTITUTION[normalized]
    if isinstance(value, int) and not isinstance(value, bool) and value in REGEX_SUBSTITUTION.values():
        return value
    raise WorldBuilderError("regex.payload.substitute_regex must be none/raw/escaped or 0/1/2")


def _serialize_regex(payload: dict[str, Any], target: str) -> dict[str, Any]:
    allowed = {
        "id", "name", "find_regex", "replace_string", "trim_strings", "placements", "disabled",
        "markdown_only", "prompt_only", "run_on_edit", "substitute_regex", "min_depth", "max_depth",
    }
    _reject_unknown(payload, allowed, "regex.payload")
    if target not in TARGETS["regex"]:
        raise WorldBuilderError(f"regex supports only: {', '.join(TARGETS['regex'])}")
    min_depth = _nonnegative_int(payload.get("min_depth"), "regex.payload.min_depth", allow_none=True)
    max_depth = _nonnegative_int(payload.get("max_depth"), "regex.payload.max_depth", allow_none=True)
    if min_depth is not None and max_depth is not None and min_depth > max_depth:
        raise WorldBuilderError("regex.payload.min_depth cannot exceed max_depth")
    script = {
        "id": _regex_id(payload),
        "scriptName": _required_string(payload, "name", "regex.payload"),
        "findRegex": _required_string(payload, "find_regex", "regex.payload"),
        "replaceString": _optional_string(payload, "replace_string"),
        "trimStrings": _string_list(payload.get("trim_strings", []), "regex.payload.trim_strings"),
        "placement": _regex_placements(payload.get("placements")),
        "disabled": _bool(payload, "disabled", False),
        "markdownOnly": _bool(payload, "markdown_only", False),
        "promptOnly": _bool(payload, "prompt_only", False),
        "runOnEdit": _bool(payload, "run_on_edit", False),
        "substituteRegex": _regex_substitution(payload.get("substitute_regex")),
        "minDepth": min_depth,
        "maxDepth": max_depth,
    }
    if target == "regex_script_v1":
        return script
    return {"regex_scripts": [script]}


def _serialize_vector_storage(payload: dict[str, Any], target: str) -> dict[str, Any]:
    _reject_unknown(payload, {"vectorized", "enabled_world_info", "enabled_for_all", "max_entries"}, "vector_storage.payload")
    if target not in TARGETS["vector_storage"]:
        raise WorldBuilderError(f"vector_storage supports only: {', '.join(TARGETS['vector_storage'])}")
    if target == "settings_patch":
        for key in ("enabled_world_info", "enabled_for_all", "max_entries"):
            if key not in payload:
                raise WorldBuilderError(f"vector_storage settings_patch requires explicit {key}")
        enabled_world_info = _bool(payload, "enabled_world_info", False)
        enabled_for_all = _bool(payload, "enabled_for_all", False)
        max_entries = _positive_int(payload.get("max_entries"), "vector_storage.payload.max_entries")
        return {
            "mode": "recommendation-only",
            "target": "sillytavern-extension-settings",
            "extension": "vectors",
            "settings": {
                "enabled_world_info": enabled_world_info,
                "enabled_for_all": enabled_for_all,
                "max_entries": max_entries,
            },
        }
    if "vectorized" not in payload or not isinstance(payload["vectorized"], bool):
        raise WorldBuilderError("vector_storage entry targets require explicit boolean vectorized")
    if target == "world_info_native":
        return {"vectorized": payload["vectorized"]}
    return {"extensions": {"vectorized": payload["vectorized"]}}


def _timed_fields(payload: dict[str, Any]) -> dict[str, int]:
    _reject_unknown(payload, {"sticky", "cooldown", "delay"}, "timed_effects.payload")
    out: dict[str, int] = {}
    for key in ("sticky", "cooldown", "delay"):
        value = payload.get(key, 0)
        parsed = _nonnegative_int(value, f"timed_effects.payload.{key}")
        assert parsed is not None
        if parsed > 0:
            out[key] = parsed
    return out


def _serialize_timed_effects(payload: dict[str, Any], target: str) -> dict[str, Any]:
    if target not in TARGETS["timed_effects"]:
        raise WorldBuilderError(f"timed_effects supports only: {', '.join(TARGETS['timed_effects'])}")
    fields = _timed_fields(payload)
    return fields if target == "world_info_native" else {"extensions": fields}


def _validate_mvu_node(value: Any, path: str = "$") -> None:
    if isinstance(value, dict):
        if not value:
            raise WorldBuilderError(f"MVU initializer object at {path} cannot be empty")
        for key, child in value.items():
            if not isinstance(key, str) or not key.strip():
                raise WorldBuilderError(f"MVU initializer object at {path} has a blank/non-string key")
            _validate_mvu_node(child, f"{path}.{key}")
        return
    if isinstance(value, list) and 1 <= len(value) <= 2:
        if len(value) == 2 and not isinstance(value[1], str):
            raise WorldBuilderError(f"MVU initializer condition at {path}[1] must be a string")
        return
    raise WorldBuilderError(
        f"MVU initializer leaf at {path} must be [initial_value] or [initial_value, update_condition]"
    )


def _serialize_mvu(payload: dict[str, Any], target: str) -> dict[str, Any]:
    _reject_unknown(payload, {"name", "initial_state", "enabled", "keys", "order"}, "mvu.payload")
    if target != "world_info_initvar":
        raise WorldBuilderError("mvu supports only world_info_initvar")
    initial_state = _expect_object(payload.get("initial_state"), "mvu.payload.initial_state")
    _validate_mvu_node(initial_state)
    name = _required_string(payload, "name", "mvu.payload")
    comment = name if "[InitVar]" in name else f"[InitVar] {name}"
    order = payload.get("order", 100)
    if isinstance(order, bool) or not isinstance(order, int):
        raise WorldBuilderError("mvu.payload.order must be an integer")
    return {
        "comment": comment,
        "key": _string_list(payload.get("keys", []), "mvu.payload.keys"),
        "keysecondary": [],
        "content": json.dumps(initial_state, ensure_ascii=False, sort_keys=True, indent=2),
        "constant": False,
        "disable": not _bool(payload, "enabled", False),
        "order": order,
    }


def _serialize_ejs(payload: dict[str, Any], target: str) -> Any:
    _reject_unknown(payload, {"template", "memo", "injection", "enabled", "keys", "order"}, "ejs.payload")
    if target not in TARGETS["ejs"]:
        raise WorldBuilderError(f"ejs supports only: {', '.join(TARGETS['ejs'])}")
    template = payload.get("template")
    if not isinstance(template, str):
        raise WorldBuilderError("ejs.payload.template must be a string")
    if target == "template_text":
        return template
    injection = payload.get("injection")
    prefix = ""
    if injection is not None:
        if not isinstance(injection, str):
            raise WorldBuilderError("ejs.payload.injection must be a string")
        normalized = injection.strip().casefold().replace(" ", "_")
        if normalized not in EJS_INJECTION_PREFIXES:
            raise WorldBuilderError(
                "unsupported EJS injection; use generate_before, generate_after, render_before, render_after, or initial_variables"
            )
        prefix = EJS_INJECTION_PREFIXES[normalized]
    memo = _optional_string(payload, "memo", "WorldBuilder EJS")
    comment = f"{prefix} {memo}".strip() if prefix else memo
    order = payload.get("order", 100)
    if isinstance(order, bool) or not isinstance(order, int):
        raise WorldBuilderError("ejs.payload.order must be an integer")
    return {
        "comment": comment,
        "key": _string_list(payload.get("keys", []), "ejs.payload.keys"),
        "keysecondary": [],
        "content": template,
        "constant": False,
        "disable": not _bool(payload, "enabled", True),
        "order": order,
    }


_SERIALIZERS: dict[str, Callable[[dict[str, Any], str], Any]] = {
    "quick_replies": _serialize_quick_replies,
    "regex": _serialize_regex,
    "vector_storage": _serialize_vector_storage,
    "timed_effects": _serialize_timed_effects,
    "mvu": _serialize_mvu,
    "ejs": _serialize_ejs,
}


def serialize_to_target(internal_repr: Any, target_format: str) -> Any:
    row = validate_internal_repr(internal_repr)
    extension = row["extension"]
    if target_format not in TARGETS[extension]:
        raise WorldBuilderError(
            f"{extension} does not support target {target_format!r}; expected one of {', '.join(TARGETS[extension])}"
        )
    return _SERIALIZERS[extension](row["payload"], target_format)


def capability_report() -> dict[str, Any]:
    return {
        "contract": CONTRACT,
        "verified": SOURCE_VERIFIED_DATE,
        "extensions": {
            name: {
                "targets": list(TARGETS[name]),
                "source_baseline": copy.deepcopy(SOURCE_BASELINES[name]),
            }
            for name in sorted(EXTENSIONS)
        },
        "boundaries": {
            "automation_ids": "not synthesized or wired by item 7",
            "outlets": "not synthesized or wired by item 7",
            "application_global_settings": "recommendation-only; never mutated automatically",
            "runtime_target_adapter": "existing World Info delivery serialization remains authoritative",
        },
    }


def _write_output(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if isinstance(value, str):
        path.write_text(value, encoding="utf-8")
    else:
        atomic_write_json(path, value)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("capabilities", help="show supported extension targets and source baselines")
    ser = sub.add_parser("serialize", help="serialize a WorldBuilder extension envelope")
    ser.add_argument("--input", required=True, help="JSON file containing the internal extension envelope")
    ser.add_argument("--target", required=True, help="one target format listed by capabilities")
    ser.add_argument("--output", help="optional output file; strings are written as UTF-8 text, objects as JSON")
    args = parser.parse_args()
    try:
        if args.command == "capabilities":
            result: Any = capability_report()
        else:
            source = load_json(Path(args.input))
            result = serialize_to_target(source, args.target)
            if args.output:
                _write_output(Path(args.output), result)
                result = {
                    "status": "ok",
                    "contract": CONTRACT,
                    "extension": source.get("extension"),
                    "target": args.target,
                    "output": str(Path(args.output)),
                }
        if isinstance(result, str):
            print(result, end="")
        else:
            print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (WorldBuilderError, OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"extension adapter error: {exc}", file=__import__("sys").stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
