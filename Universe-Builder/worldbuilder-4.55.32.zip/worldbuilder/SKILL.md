---
name: worldbuilder
description: build, repair, audit, convert, and package SillyTavern CCv3 cards, CHARX files, lorebooks, personas, and shared group assets.
metadata: {"openclaw":{"requires":{"anyBins":["python3","python"]}}}
---
# WorldBuilder
<!-- phase-contract --> Exit contract: run `python3 {baseDir}/scripts/phase_contract.py --build-state <build-state> --stage <one of: workspace_initialized, delivery_permitted>` before this stage's gate; rendered copies ship in the build's worker kit under `exit-contracts/`.
- Treat worker execution as a parent-observed transaction. Parent task cards use absolute build paths; staged worker manuals may use relative links resolved from the build-root `cwd`. Never use the installed skill directory as mutable workspace state.
Create and maintain SillyTavern artifacts without mixing specification requirements, application compatibility, and WorldBuilder editorial preferences.
Documentation baseline: OpenClaw, SillyTavern 1.18.0, and the Character Card V3 proposal checked on **2026-07-17**. See `COMPATIBILITY.md` before making version-sensitive claims.
## Non-negotiable invariants
1. Treat the installed skill as immutable source. Never write user configuration, generated artifacts, prompt copies, or scratch data under `{baseDir}`.
2. Create one unique build workspace per task with `{baseDir}/scripts/init_build.py`.
3. Treat `build-state.json` as the only path authority. Do not recreate paths independently in prose or commands.
4. Keep the authoritative manifest intact. Never replace it with a progress index; use a different file for progress.
5. Preserve stable entry identifiers. Allocate only missing identifiers and reject duplicates or conflicting mirrors. An amendment to a sealed build (`pipeline_stage_gate.py`'s `record_amendment`) is bound to the same identifiers, tracked through `change_set.py`'s changed/neighbour UIDs; it is an edit to a specific, identified entry, never a wholesale rewrite that could silently reassign what an identifier refers to.
6. Separate validation layers:
   - `spec`: Character Card/Lorebook V3 structure.
   - `sillytavern`: import/runtime compatibility.
   - `worldbuilder`: optional editorial guidance, warning-only by default.
7. Require a content-bound post-generation audit for every Schema 2 or Schema 3 artifact. A Schema 1 card and persona text may skip that audit only after inspecting the target.
8. A child report is complete only when parent-observed runtime status is completed, the required output exists and validates, and the manual's end delimiter is present. Missing evidence means incomplete; host-specific dispatch details never substitute for this neutral completion contract.
9. Use canonical `phase-NNNN.json` files. Legacy `group-N-*.json` files may be read only for migration.
10. Do not claim third-party import compatibility without a tested fixture for that named version.
11. Generate in strict per-entry cycles: research one assigned UID, validate it with `entry_cycle_gate.py`, write and checkpoint that one entry, then move to the next UID. Never research the whole batch before writing. After all 1-50 cycles complete, run the aggregate `evidence_gate.py` and bind the final phase to both receipts. Global planning research never substitutes for per-entry evidence.
12. Generation assignments contain 1-50 entries. Read the frozen `batching.generation_entries_per_worker` value, never exceed it, and let dependency/token pressure reduce batches further.
13. Twelve build contracts govern content architecture, activation graph, card shell, character system, placement, budget/pruning, dynamic state, target adapter, full integration, pipeline stage gates, era roots, and soul voice. Read `references/contract-registry.md` before planning any build and treat every applicable contract there as an invariant of this list. `planning_gate.py` and `delivery_gate.py` enforce them; a contract that applies but has no current receipt blocks delivery. Editing a sealed build never rolls back to an earlier stage (`invalidate_from`); it records a scoped `amendment_N` in the same ledger instead (`pipeline_stage_gate.py`'s `record_amendment`), re-proving only what the change set actually touches; a sealed stage's own receipt is never removed or replaced.
## Step driver: never guess the next step
The pipeline stage ledger, not memory, decides what happens next. After **every** pipeline command (success or failure), run `python3 {baseDir}/scripts/pipeline_stage_gate.py --build-state /absolute/path/to/build-state.json --next`, execute exactly the `command` it prints, and re-read the file or section named in `read_first` before running it. Treat this output as authoritative over anything remembered from earlier in the conversation. When any gate blocks, its error names the exact recording command; run that command, never a guessed one, and never pass ledger stage names (such as `planning_validated`) to other scripts' `--stage` flags; each script's `--stage` vocabulary is its own. After any error, or when more than ten turns have passed since the last read, re-read the Non-negotiable invariants above and the current mode's manual before continuing. Do not record ledger stages directly with `--stage`; the dedicated gate scripts record them as a side effect of actually passing. `manifest.json` and every receipt are frozen pipeline artifacts once planning is recorded: never edit, regenerate, 'sync', or permission-lock them with ad-hoc scripts. When a hash-drift error prints an `--invalidate-from` recovery, run exactly those commands and regenerate assignments.
## First action: menu or route before setup
Read `references/greeting.md` before responding to a bare WorldBuilder invocation.
- When the user invokes WorldBuilder without a stated task, output the greeting block from `references/greeting.md` verbatim and nothing else.
- When the user already states a build, edit, audit, prune, image, info, Soul Extractor, upload, or resume request, skip the greeting and route directly.
- After routing to Character, World, Lorebook, Group Chat, Persona, or Quick Build, read `references/settings-menu.md`, load persistent `interface.mode` from the approved workspace config, and show exactly one matching **paged settings flow** before research, planning, workspace initialization, or generation. If a reusable build template was selected, read `references/build-templates.md` and pass it to `setup_state.py --template` before Page 1 so it supplies visible prefills only. Simple Mode uses the compact pages; Advanced Mode uses one comprehensive multi-page flow that already includes the standard choices. Never show more than 10 numbered setting blocks on one page.
- Parse supplied flags and details as prefilled choices rather than asking the user to repeat them.
- Extras and resume routes use their own workflows and do not receive the build settings batch.
The guided menu is a required UX contract. Do not replace it with a generic open-ended question or a compressed one-line list. Save each completed page with `scripts/setup_state.py` when resumption matters; setup drafts belong under the approved workspace `.setup-drafts/`. Keep Simple/Advanced as a persistent Home Config preference. Never show Simple first and then append Advanced; Advanced is one complete menu containing the simple choices and expert controls. After `[2A]`, pass its explicit answer and displayed default to `init_build.py` as `--guided-mode-answer`/`--guided-mode-default`; `[yes]` also requires `--custom-pipeline` plus the auditable `--custom-trigger-reason`, while `[no]` stays on the structured path.
- Hard requirement: the greeting must visibly contain all four of these as independent substrings, not as one contiguous string, before it is sent: `🧱 Build`, `🛠️ Tools    Audit · Prune · Iterate · Update/Merge · Convert · Art`, `Group Chat`, and `📚 Info`. If any are missing, reload `references/greeting.md` and do not answer until they are present. Tier-aware (GREETING_CONTRACT_VERSION 4; the widget tier needs a different assertion, not a deletion of this one): the four substrings above are the text-tier check; for the widget tier, every rendered button's `sendPrompt` text must instead be a routing phrase this same contract defines (a mode name, "soul extractor", a flag, or "continue [name]"). Check the widget source for `sendPrompt(` calls and verify each argument against that set.
Do not begin with a technical setup interrogation; read `references/setup-message.md` for the lazy-setup and workspace-choice contract. Once the mode and settings are sufficiently locked, initialize or resume the user-approved WorldBuilder workspace. Pass the exact dedicated root selected during first-time setup (for example `~/Desktop/WorldBuilder`):
```bash
python3 {baseDir}/scripts/init_build.py "PROJECT NAME" \
  --workspace "~/Desktop/WorldBuilder" \
  --artifact-type lorebook \
  --schema 3 \
  --source-stance hybrid \
  --source-kind known-property \
  --pipeline parallel \
  --era-mode single \
  --era-isolation strict \
  --opening-style open \
  --greeting-policy single \
  --scenario-policy blank
```
The script creates a unique build beneath that approved root:
```text
<approved-worldbuilder-root>/
  config.json
  research-stack/
  builds/<unique-build-id>/
    build-state.json
    input/
    artifacts/
      discoveries/
      research/
      field-registry.json
      default-profile.json
      manifest.json
      build-list.md
      recursion-map.md
      activation-map-gate.json
      card-shell-plan.json
      character-plan.json       # when generated character entries exist
      placement-plan.json       # lorebook-bearing builds
      budget-plan.json          # frozen Detail & Context Profile
      dynamic-state-plan.json   # optional behavior; deterministic by default
      semantic-ir.json          # parent-owned Batch 9 conversion authority
      target-compatibility-report.json
      runtime-target-adapter-receipt.json
    creations/
    .work/
      worker-kit/
      assignments/
      discovery-runtime/
      audit-assignments/
      audit-runtime/
      findings/
      phases/
      evidence-receipts/
```
The approved WorldBuilder folder is the working root, not merely an export destination. Keep every mutable file (planning artifacts, discovery outputs, manifests, phases, worker manuals, receipts, extracted inputs, temporary files, and final creations) inside its unique build directory. Never move working files into the OpenClaw or skill installation. Optional export copies may be made elsewhere only after delivery.
## Capability preflight
Before choosing a workflow, run `capability_probe.py` and inspect the current session's effective tools and filesystem visibility. Report, do not assume: every capability is `available`, `unavailable`, or `unknown`. An unreported tool-calling capability is `unknown`, never silently treated as `unavailable`, and a missing capability degrades a specific feature; it never blocks the product except python3 itself.
Required for every mode:
- Read/write access to the selected build workspace.
- Python 3.10 or newer, enforced by test rather than asserted: `test_no_backslash_inside_an_fstring_expression` and `test_no_other_post_310_syntax` fail on any construct a 3.10 host would reject at import. All documented commands invoke `python3`; use `python` only on hosts where `python3` is absent (typically Windows). The gate accepts either binary. If `python3` resolves to an older interpreter than `python` on your host, prefer whichever reports 3.10 or newer; the claim is now verified, so a crash on 3.10 is a bug worth reporting.
- Ability to execute the bundled scripts.
Additional capabilities, each reported by `capability_probe.py`:
- Parallel work: `sessions_spawn`; use `sessions_yield` when available. Report availability with `--sessions-spawn available|unavailable` from this session's own tool list, never guessed.
- Public-web research: the OpenClaw SearXNG plugin, a healthy SearXNG JSON endpoint, Cloudflare WARP (or administrator-approved replacement egress), and network access.
- CHARX assets: access to every source file being packaged.
- Card art and expression sets: `image_generate`. Report with `--image-generate available|unavailable`.
- Tiered interactive menus (Batch 11): `show_widget`. Report with `--show-widget available|unavailable`. No version threshold is hardcoded for this: it is a fast-moving host feature and a hardcoded version would go stale within weeks; detect it from the session's own tool list, the same way as the other two.
If a capability is absent, route to a supported alternative:
- No child tools → use a sequential parent-agent workflow only for original/user-canonical or explicitly limited tasks. For an exhaustive known-property build, stop or obtain explicit agreement to a downgraded non-exhaustive run; never claim the complete breadth pipeline ran.
- SearXNG/WARP preflight failure → do not perform high-volume public-web research or silently switch providers. Continue only when the build is genuinely user-canonical/offline, and state that external verification was not performed.
- Child cannot see the proposed path → ask for another dedicated WorldBuilder workspace and re-run the visibility probe. Do not silently fall back into the OpenClaw installation.
- No `image_generate` → produce image prompts only; do not claim a rendered image exists.
- No `show_widget` → fall back to text menus; do not claim a tiered menu was shown.
OpenClaw's subagent timeout is a computed liveness bound, never a model estimate (DR-064): read `run_timeout_seconds` from the assignment and pass it as `sessions_spawn`'s `runTimeoutSeconds` argument. Do not estimate or invent this value; it is stamped by `phase_gate.py`/`discovery_plan.py` before dispatch. If this specific host's `sessions_spawn` implementation genuinely rejects `runTimeoutSeconds`, note that host discrepancy plainly and proceed with the host's own default timeout; never omit the parameter silently or treat the fallback as routine.
## Resolve uploaded files
Inspect tool-visible attachments and OpenClaw inbound media first. Copy the resolved input into `paths.input` before editing. Ask for a host path only when no attachment or inbound-media file is available to the current runtime.
A `.png` upload is a card container, not an image to generate: the character JSON lives inside a `chara`/`ccv3` tEXt chunk (`ccv3` preferred), read via `scripts/png_card.py`, pure stdlib. Pass the copied file to `init_build.py --source-file`; a `.png` with no readable chunk fails there immediately.
Record the copied input's SHA-256 in `build-state.json.lineage.input`; `init_build.py --source-file` does this automatically when given a path.
## Select a mode
| User intent | Mode | Primary output | Read |
|---|---|---|---|
| One AI character | Character | Schema 1 V3 JSON or CHARX | `references/character-mode.md`, `references/card-shell-routing.md` |
| Open setting experience with embedded lore | World | Schema 2 V3 JSON or CHARX | `references/world-mode.md`, `references/card-shell-routing.md` |
| Standalone lore | Lorebook | Portable `lorebook_v3` by default; explicitly selected ST-native World Info for direct import | `references/lorebook-mode.md` |
| Several cards sharing lore | Group chat | Schema 1 cards plus Schema 3 lorebook | `references/group-chat-mode.md` |
| User avatar | Persona | Plain UTF-8 `.txt`; optional separate lorebook | `references/persona-mode.md` |
| Explain/research only | Info | Report, no artifact unless requested | `references/info-mode.md` |
| Modify an existing artifact | Iteration | Same format unless conversion requested | `references/iteration-mode.md` |
| Merge new material | Update/Merge | Updated artifact plus change report | `references/update-merge.md` |
| Reduce size | Prune | Smaller artifact plus removed-items report | `references/prune-mode.md` |
| Resume an interrupted build | Resume/Recovery | Continuation of the existing build, no restart | `references/runtime-recovery.md` |
| Validate an existing artifact | Audit | Findings and optional verified patches | `references/audit-mode.md` |
| Test generated behavior | Behavioral test-drive | Hash-bound behavior report | `references/behavioral-testdrive.md` |
| Minimal fast build | Quick build | Mode-appropriate output | `references/quick-build-mode.md` |
| Original request that fits no structured mode | Custom/dynamic | Same artifact contracts as target | `references/custom-pipeline-mode.md` |
| Extract a world, character, author, or text style | Soul Extractor | Target-specific soul/style profile | `references/soul-extractor.md` |
| Card art, scene prompts, or an expression set | Image Prompts | Prompt text and, for expression sets, CCv3 `emotion` descriptors; images only through `--generate` after explicit cost confirmation | `references/image-prompts.md`, `references/sillytavern-plugins.md` |
| Regex, tracker state, or greeting HTML/CSS | Graphics Designer | Verified character-scoped Regex, MVU InitVar state, or `first_mes` markup | `references/graphics-designer.md`, `references/extension-adapters.md` |
The custom/dynamic row is entered only from an explicit `[2A] Guided Mode = yes` answer. `[1] original` + `[2] no` changes only `[2A]`'s displayed default to yes; it never silently activates the route. Tell the user when routing there; read `references/custom-pipeline-mode.md`. Iteration, Update/Merge, and Audit all operate on an existing artifact, which may or may not have any WorldBuilder history at all. `capability_tiers.py` reports the artifact's tier (Unbound/Legacy-bound/Bound) up front, before any other work, not discovered three steps in as a gate error. Unbound (no WorldBuilder lineage, or its workspace is gone) is not a degraded mode: structural edit, derived activation graph, diff proof, format validation, and import probe all work on any lorebook, hand-made or third-party. Capability only grows from there, and only against a live, matching workspace; a provenance marker's own claim is never sufficient for Bound by itself.
Read `references/schemas.md` for every JSON/CHARX task. Read `references/character-template.md` and `references/character-identity-system.md` for every generated character output, and `references/era-system.md` for every multi-era or Character card-set build. Read `references/splitting-workflow.md` before dividing any artifact across multiple files. Read `references/anticipating-gate-blocks.md` before running any gate: it lists the constraints most often hit, the diagnostic sweeps that report them all at once, and which blocks you may clear yourself versus which belong to the user. Read only the additional references named by the selected mode. For Info, use the exact named/numbered tab home in `references/info-mode.md`, load `references/design-rationale.md` for design-why questions, route `SearXNG down` to repair, and end with `Any special questions?`.
For Soul Extractor, classify the target before extraction. A named world, franchise, setting, era, or location uses the world/setting lens; a named character uses the character lens; an author or body of work uses the authorial/style lens. World Mode must not route Soul Extractor through a character-only profile. World Mode is setting-first: never require a central character, fixed POV, narrator shell, or predefined user identity. Keep Scenario blank by default as a user settings field; keep Description brief; place the substantive world engine in the embedded lorebook. Treat documented decisions in `references/design-rationale.md` as product contracts during planning and audit; do not normalize intentional design choices into conventional card behavior without explicit user approval.
## Lock source stance
Set one stance in `build-state.json.source.stance`:
- `user-canonical`: user-provided facts control; do not overwrite them with web material.
- `source-canonical`: authoritative sources control; report conflicts before changing user material.
- `hybrid`: preserve explicit user deviations and verify everything else.
Research is conditional, not universal. Do not browse for an original character when the user is the source of truth unless they request comparison or verification. When a manifest declares `architecture.source_type_weights`, treat them as evidence-confidence multipliers; explicit `canon_precedence` remains authoritative over any weight-derived conflict order. Whenever public-web research is required, SearXNG plus WARP (or recorded replacement egress) is mandatory and `scripts/searxng_preflight.py` must pass before dispatch. On first use, read `references/searxng-setup.md`, plan setup with `scripts/first_time_setup.py` before applying it, prefer Docker, fall back to the official native Python/source installation when Docker is unsupported, register user-approved automatic startup, and run `scripts/ensure_research_stack.py --start --preflight` before research.
For MediaWiki/Fandom sources, probe the documented API endpoint and honor status codes, rate limits, robots, and licensing. Never describe an API as a universal bypass.
## Mandatory breadth discovery before planning
For a known franchise, world, setting, era, or other established property, the initial source collection is a mandatory parallel subagent stage. Mark the build with `--source-kind known-property` and read `references/parallel-research-pipeline.md`; `references/parallel-research-flowchart.md` is the one-page visual of the same sweep.
The collector is additive, not a fallback ladder:
```text
recursive sitemap/index/gzip
+ MediaWiki statistics and fully paginated AllPages
+ redirects and AllLinks
+ Special:AllPages
+ recursive categories/subcategories
+ mandatory SearXNG site harvest
+ bounded same-site link traversal
+ independent random/category verification rounds
```
Run the deterministic source probe, then create exact bird-named assignments:
```bash
python3 {baseDir}/scripts/source_probe.py \
  --build-state /absolute/path/to/build-state.json \
  --base-url https://example-wiki.invalid/ \
  --searxng-base-url http://127.0.0.1:8888
python3 {baseDir}/scripts/discovery_plan.py \
  --build-state /absolute/path/to/build-state.json \
  --probe /absolute/path/to/artifacts/discoveries/source-probe.json \
  --max-concurrent 20 \
  --target-pages-per-worker 75 \
  --minimum-verification-rounds 2
```
Discovery uses a health-gated **4 → 10 → 20** ramp. Dispatch only wave 1, record its completions, then run:
```bash
python3 {baseDir}/scripts/discovery_wave_gate.py \
  --build-state /absolute/path/to/build-state.json \
  --wave 1
```
Only a passed wave unlocks the next wave. Continue with up to 10 workers, then up to 20 workers per later wave when enough assignments remain. `20` is the maximum concurrent discovery-child setting, not a limit on the total number of assignments for a very large corpus.
For MediaWiki/Fandom pages, the probe first classifies the additive URL union with batched API metadata. Indexes are link-harvest-only, redirects are alias-only, transcripts may be reference-only, and discussion/maintenance/production junk is accounted without bird prose; all URLs remain in bounded source-set coverage accounting. Assigned content then uses staged `wiki_fetch.py` (`action=parse`, revision wikitext, normal HTML last) and a second deterministic page filter before full extraction.
Dispatch the exact assignments in the unlocked bounded wave with the current host's child-run capability. Core requirement: each assignment gets a distinct parent-observed completion, and the parent records it with `record_discovery_runtime.py`; the gate validates host-neutral `parent_observed_child_run` semantics rather than a provider/tool name. For OpenClaw-specific `sessions_spawn` arguments and receipt mapping, read `references/host-openclaw.md`. The parent may orchestrate and synthesize, but may not replace the breadth sweep with inline browsing.
Run:
```bash
python3 {baseDir}/scripts/discovery_gate.py \
  --build-state /absolute/path/to/build-state.json
```
The gate proves per-worker URL ownership, source-specific reconciliation, an independent lower-bound denominator, distinct runtime completions, and low-yield saturation across independent verification passes. Exit code `2` means recovery is required:
```bash
python3 {baseDir}/scripts/discovery_recovery.py \
  --build-state /absolute/path/to/build-state.json \
  --runtime-cap <actual-child-cap>
```
Dispatch only the new recovery/verification assignments and gate again. Re-run `source_probe.py` when the independent denominator or saturation cannot be satisfied from the current plan. Only a complete `discovery-gate.json` permits the build list, recursion map, manifest, and UIDs to be created. Bind those artifacts to `discovery_receipt_sha256`.
This breadth stage answers *what belongs in the build*. Later per-UID research still answers *what is true about each selected entry*.
## Plan before generation
For lorebook-bearing builds, create these artifacts before writing entries:
- `paths.manifest`: complete entry plan and declared settings.
- `paths.build_id`: build ID, manifest SHA-256, and exact entry count.
- `paths.build_list`: human-readable plan with a `WORLDBUILDER-ARTIFACT` header.
- `paths.field_registry`: frozen machine-readable planning field meanings.
- `paths.default_profile`: frozen build/layer defaults; blank map values inherit here.
- `paths.recursion_map`: complete activation ledger and edge ledger rendered from the manifest.
- `paths.character_plan`: structured identity, behavior, state, split, knowledge, and directed-relationship plan whenever generated character entries exist.
- `paths.dynamic_state_plan`: target-neutral optional behavior and deterministic safety defaults.
The manifest is authoritative and remains at the same path for the whole build. It must bind the frozen registry/profile and own `activation.strategy`, `activation.recursion_role`, `activation.emits`, `activation.forbidden_emits`, and `activation_graph.edges`. Character entries additionally bind the frozen character-plan hash, stable identity/state IDs, and structured identity/behavior model versions. Update it transactionally, then render and validate the map. A lightweight status index, if useful, belongs at `artifacts/progress-index.json`.
Before authoring any plan, read `build-state.json` `settings.conditions`; when non-empty, copy it verbatim to `manifest.architecture.build_conditions` so planning and generation cannot silently drop the accepted [3] Conditions & Modifications answer.
Run the pre-generation gate:
```bash
python3 {baseDir}/scripts/phase_gate.py \
  --stage pre-generation \
  --build-state /absolute/path/to/build-state.json
```
See `references/pre-gen-workflow.md` for exact headers and planning procedure.
## Choose sequential or parallel execution
Known-property breadth discovery is parallel-required when `sessions_spawn` is available and is not subject to the small-build sequential shortcut. Generation itself may still be sequential when appropriate.
Partition according to estimated token volume, cross-entry dependencies, source/API rate limits, model context, cost, and actual runtime capacity. Numeric thresholds in references are advisory defaults, not compatibility rules.
Configure OpenClaw with `agents.defaults.subagents.maxChildrenPerAgent=20` and `agents.defaults.subagents.maxConcurrent=20` during approved first-time setup. Calculate usable child capacity as the minimum of those effective limits, allowed agents, workload size, and any explicit user budget. The discovery ramp still begins at 4 to expose transport, prompt, and scope problems before scaling to 10 and then 20. The minimum is one usable child. Never raise a low real cap to an invented floor, and never claim a higher usable cap than the runtime actually reports.
Use sequential execution when:
- Child tools are unavailable.
- The artifact is small or highly interdependent.
- A single coherent voice matters more than throughput.
- The source imposes strict serial rate limits.
Use parallel execution when independent batches are large enough to justify child overhead.
## Stage and dispatch workers
`init_build.py` copies canonical `prompts/`, only the `references/` files the worker manuals name (`--full-worker-kit` stages everything), and only child-required scripts into the build's versioned `.work/worker-kit/`. Parent-only planners, runtime recorders, recovery tools, and gates stay under `{baseDir}/scripts` so a child cannot self-certify its completion. Worker manuals address every file as `<build_root>/...`, where `<build_root>` is the absolute build root carried in each assignment's `workspace_root`; never substitute host installation paths and never rely on the child's working directory.
Write one assignment JSON per child under `paths.assignments`. Generation assignments use `assignment_version: 3` and include:
- Stable `assignment_id`, `build_id`, role, worker label, and the absolute `workspace_root` build root.
- Schema/format and manifest SHA-256; `workspace_root` and per-UID `entry_hashes` are stamped by `phase_gate.py --stage pre-dispatch`; workers never author or edit them.
- Activation-map, field-registry, and default-profile SHA-256 values.
- The exact deterministic `map_slice` for assigned UIDs, including incoming/outgoing edges, neighbor summaries, required emitted terms, forbidden terms, and non-default special operations.
- For character-bearing assignments, the exact `character_plan_sha256` and `character_context` slice containing stable identity, behavior, selected state, knowledge limits, split rationale, required/forbidden terms, and directed relationships.
- For multi-era assignments, the exact `era_plan_sha256` and `era_router_context` slice containing the selected era boundary, canonical Scenario keyword, world state, past/future events, state assertions, prohibited state terms, knowledge restrictions, and planned entity/event states.
- For placement-aware assignments, the exact `placement_plan_sha256` and resolved `placement_context` slice containing purpose, influence class, position, order, priority, depth/role, outlet, activation path, and target mapping.
- For lorebook-bearing assignments, the exact `budget_plan_sha256` and resolved `budget_context` slice containing per-UID soft/hard targets, layer/era allocation, priority, protected categories, and pruning eligibility.
- For lorebook-bearing assignments, the exact `dynamic_state_plan_sha256` and resolved `dynamic_state_context` slice; workers copy only its neutral envelope and cannot invent runtime-native operations.
- Exact assigned UIDs and names.
- A non-empty `research_topics` list for every assigned UID.
- `research_mode`: `public_web`, `provided_sources`, or `mixed`.
- Relative `evidence_output`, `evidence_receipt`, and phase `output` paths.
- Expected end delimiter.
Read `references/research-before-writing.md`. Every generation worker must process assigned UIDs sequentially: research UID 1, validate UID 1, write/checkpoint UID 1, then repeat for UID 2. Researching all assigned UIDs first and writing later is forbidden. After the last entry cycle, run the aggregate evidence gate and assemble the phase from validated checkpoints. There is no research-free generation assignment; user-canonical projects use `provided_sources` and treat user material as evidence.
Use a small dispatch task:
```text
Read <build_root>/.work/worker-kit/prompts/generation-worker.md in full.
Read <build_root>/.work/assignments/wb_r1_raven.json and execute it exactly.
<build_root> is this absolute build root; never resolve any path relative to your working directory.
```
Dispatch each assignment through the current host's child-run capability using its stable task name, human-readable label, absolute build root, stamped timeout, and isolated context unless shared transcript context is genuinely required. The parent must observe completion and record the result; a child cannot certify its own runtime status. For OpenClaw `sessions_spawn`, use each assignment's frozen `requested_model`; for exact route/`resolvedModel` verification, `cwd`, timeout, and completion-event details, read `references/host-openclaw.md`.
Immediately before generation dispatch, and again before any resumed or re-routed generation wave, re-check vision against the model actually about to run. When that model is known, determine support from current host/provider capability evidence, then run `python3 {baseDir}/scripts/wb_operations.py vision-recheck --build-state /absolute/path/to/build-state.json --resolved-generation-model <actual-model> --vision-capable available` or the same command with `--vision-capable unavailable`. Never infer vision support from the model name. If the command returns `decision_required`, stop dispatch and show its exact three-option prompt; rerun with `--transition-policy rerun_all|new_work_only|stay_text_only` only after the user chooses. An unresolved/inherited model may remain unknown until the host can identify it, but once known it must be explicitly re-reported before generation work continues.
Within each generation task, the mandatory order is:
```text
for each assigned UID in order:
  research UID -> entry-cycle research gate -> write/checkpoint UID -> entry-cycle write gate
after all UIDs: aggregate evidence gate -> assemble phase
```
The worker runs, always wrapped in `debug_log.py capture`: it records the exact reproduction, stage, and failure detail mechanically, at the point of failure, rather than a reconstruction from memory at delivery time; costs nothing when debug logging is off. The worker's own `debug_log.py` is staged into the worker kit; it has no access to `{baseDir}`:
```bash
python3 <build_root>/.work/worker-kit/scripts/debug_log.py capture --build-state <build_root>/build-state.json -- python3 <build_root>/.work/worker-kit/scripts/evidence_gate.py --build-state <build_root>/build-state.json --assignment <build_root>/.work/assignments/<taskName>.json
```
Before the first parallel dispatch, using the parent's own installed copy:
```bash
python3 {baseDir}/scripts/debug_log.py capture --build-state /absolute/path/to/build-state.json -- python3 {baseDir}/scripts/phase_gate.py --stage pre-dispatch --build-state /absolute/path/to/build-state.json
```
After each generation completion, require all of the following:
1. Runtime status is `completed`.
2. The evidence ledger covers every assigned UID and required topic.
3. `evidence_gate.py` has produced a current assignment/evidence receipt.
4. Expected phase output exists under the build root.
5. Output build ID, assignment SHA-256, evidence SHA-256, and receipt SHA-256 match the assignment's declared bindings; the evidence receipt records whether the manifest binding verified `exact` or `slice_tolerated`.
6. Every phase UID appears exactly once and cites only claim IDs from its own evidence record.
7. `unsupported_claims` is an empty list and output validates for its role.
8. The exact end delimiter is present.
A failed, timed-out, unknown, truncated, delimiter-free, or invalid result must be repaired or re-run. Never infer completion from the absence of an error token.
Read `references/subagent-prompt.md` and the role-specific parallel reference before dispatch.
## Merge without losing data
Workers write `phase-NNNN.json` with `_worldbuilder` lineage metadata. Run:
```bash
python3 {baseDir}/scripts/phase_gate.py \
  --stage pre-merge \
  --build-state /absolute/path/to/build-state.json
python3 {baseDir}/scripts/merge_phases.py \
  --build-state /absolute/path/to/build-state.json \
  --schema auto
```
For fixed budgets the merger normalizes visible labels through `entry_naming.py` before post-generation auditors are dispatched. With `[auto]` context budgeting it instead freezes the merged bytes, runs the measured `context_budget_review` keep/prune checkpoint from `references/context-budget-pruning.md`, then normalizes labels. The merger:
- Sorts phases numerically.
- Preserves unknown shell/application metadata.
- Preserves stable IDs and rejects duplicates.
- Allocates only missing IDs.
- Removes internal `_worldbuilder` metadata from final data.
- Generates legacy mirrors only with the explicit opt-in `--legacy-mirrors`.
## Audit and patch
Schema 2 and Schema 3 builds require four structured auditors at both required audit stages. Create the post-generation plan after the final target bytes exist:

```bash
python3 {baseDir}/scripts/audit_plan.py \
  --build-state /absolute/path/to/build-state.json \
  --stage post-generation
```

Before dispatch, compute the current child-start stagger from the build telemetry ledger with `gate_telemetry.py stagger`; the deterministic result is bounded to **10-60 seconds** and defaults to 20 seconds when no usable history exists. Dispatch **Compass**, **Weaver**, **Scout**, and **Warden** as four distinct child runs in that order, waiting only the computed stagger between starts. Stagger starts only; do not serialize the audit. This pacing value never replaces or modifies any assignment's stamped `run_timeout_seconds`. Host-specific spawn arguments do not belong to the validation contract; for OpenClaw `sessions_spawn` details, read `references/host-openclaw.md`. After each completion event, record the actual runtime evidence:

```bash
python3 {baseDir}/scripts/record_audit_runtime.py \
  --build-state /absolute/path/to/build-state.json \
  --stage post-generation \
  --lens compass \
  --child-session-id <actual-child-session-id> \
  --run-id <actual-spawn-run-id> \
  --runtime-event-id <actual-completion-event-id> \
  --status completed \
  --spawned-at <ISO-8601> \
  --completed-at <ISO-8601> \
  --parent-session-id <actual-parent-session-id>
```

Then require the four-lens gate:

```bash
python3 {baseDir}/scripts/audit_gate.py \
  --build-state /absolute/path/to/build-state.json \
  --stage post-generation
```

Reconcile compatible findings, record accepted changes as exact JSON Pointer operations in `paths.patch_log`, verify patches against current bytes, revalidate, and rerun any invalidated audit lens. If the target changes, create a fresh audit plan and gate receipt for the new bytes.

After the current four-lens receipt passes and corrected bytes are at `paths.final_output`, run the parent-owned target adapter when the build selected a named output target:

```bash
python3 {baseDir}/scripts/runtime_target_adapter.py export \
  --build-state /absolute/path/to/build-state.json
python3 {baseDir}/scripts/runtime_target_adapter.py validate \
  --build-state /absolute/path/to/build-state.json
```

Then validate integrated output, seal, and release:

```bash
python3 {baseDir}/scripts/integration_acceptance.py validate \
  --build-state /absolute/path/to/build-state.json \
  --stage output
python3 {baseDir}/scripts/delivery_gate.py \
  --build-state /absolute/path/to/build-state.json \
  --seal
python3 {baseDir}/scripts/delivery_gate.py \
  --build-state /absolute/path/to/build-state.json
```

The build-state seal binds the audit-run ID, all four result and runtime-receipt hashes, target hash, merge hash, build ID, and entry count. Old `PASS 0-4` text markers are standalone legacy compatibility only and are not proof for a current build.

For Schema 1 or persona text, run the inspected direct delivery path. The gate rejects a no-audit bypass when the target actually contains a lorebook.

Read `references/post-gen-audit.md` and `references/parallel-audit-pipeline.md`.
## Validation commands
```bash
# JSON: default SillyTavern compatibility profile
python3 {baseDir}/scripts/validate_output.py artifact.json

# Pure V3 structure
python3 {baseDir}/scripts/validate_output.py artifact.json --profile spec

# Editorial recommendations (warnings)
python3 {baseDir}/scripts/validate_output.py artifact.json --profile worldbuilder

# Era and character content architecture
python3 {baseDir}/scripts/architecture_gate.py --build-state /path/build-state.json --stage output

# Persona text
python3 {baseDir}/scripts/validate_persona.py persona.txt --mode simple

# Conservative repair
python3 {baseDir}/scripts/repair_extensions.py artifact.json

# Semantic IR / target conversion
python3 {baseDir}/scripts/runtime_target_adapter.py export artifact.json output.json --target lorebook-v3
python3 {baseDir}/scripts/runtime_target_adapter.py roundtrip artifact.json --target sillytavern-native

# Full integration and resume proof
python3 {baseDir}/scripts/integration_acceptance.py validate --build-state /path/build-state.json --stage planning
python3 {baseDir}/scripts/integration_acceptance.py validate --build-state /path/build-state.json --stage resume

# Standalone CHARX packer (the runtime adapter also owns CHARX target conversion)
python3 {baseDir}/scripts/build_charx.py --card card.json --output card.charx --assets ./assets --modules ./modules
```

Do not turn WorldBuilder preferences (tag counts, rating tags, fixed insertion positions, exact talkativeness diversity, or personality-field routing) into schema errors.
## Output and export
Keep build internals in the workspace. Place finished artifacts under `paths.final_output`. If `paths.export_root` is set, copy only:

- Final JSON/TXT/CHARX files.
- Requested audit/change reports.
- Optional README for import steps.
- Only after delivery, an explicitly requested runtime bundle may be created with `python3 {baseDir}/scripts/runtime_target_adapter.py bundle --build-state /path/build-state.json`; normal delivery remains the default.

Before deleting `.work`, verify `.worldbuilder-owner.json` and matching `build_id`. Never recursively clean a shared parent directory.
## OpenClaw smoke checks
Use documented commands and an actual invocation:

```bash
openclaw skills list
openclaw agent --agent main --message "Use WorldBuilder to validate this small V3 card."
```

Interactive alternative:

```text
/skill worldbuilder validate this card
```

OpenClaw's skills watcher is on by default and picks up changed skill files on the next agent turn; a gateway restart or new session may be needed only when the watcher is disabled or the runtime lacks one. Do not claim that every runtime hot-reloads identically.
## Reference map
### Core contracts
- `references/greeting.md`: exact first-invocation visual menu and routing contract.
- `references/settings-menu.md`: mode-filtered guided settings menu and parsing contract.
- `references/config-mode.md`: main-agent, legacy subagent fallback, and per-role worker model settings.
- `references/schemas.md`: V3, native World Info, persona, and CHARX shapes.
- `references/global-rules.md`: source, writing, safety, and evidence rules.
- `references/pre-gen-workflow.md`: build planning and evidence artifacts.
- `references/entry-settings.md`: activation settings and architecture profiles.
- `references/lorebook-architecture.md`: mandatory retrieval layers, the optional world index, and dependency design.
- `references/era-system.md`: approved era plans, Scenario routing, state splits, and anti-bleed gates.
- `references/character-template.md`: canonical star and lorebook character format.
- `references/character-identity-system.md`: structured identity, behavior, state splitting, knowledge boundaries, and directed relationship planning.
- `references/design-rationale.md`: intentional product decisions, reasons, regression boundaries, and approved-change conditions.
- `references/error-blacklist.md`: release-blocking and editorial anti-patterns; `references/workspace-hygiene.md`: workspace/build boundaries, durable evidence, safe cleanup, and managed research-stack identity.
- `references/activation-hygiene.md`: recursion dampening, connectivity tiering, leaf stops, and pre-ship fan-out measurement.
- `references/pipeline-stage-gates.md`: ordered transition receipts, invalidation, and skipped-step recovery.
### Parallel work
- `references/subagent-prompt.md`; `references/host-openclaw.md` for OpenClaw-specific dispatch arguments and neutral receipt mapping
- `references/parallel-batch-pipeline.md`
- `references/parallel-research-pipeline.md`, `references/discovery-approvals.md` (approval file schema; construct with `write_discovery_approval.py`, never hand-author)
- `references/parallel-audit-pipeline.md`
### Formatting and compatibility
- `references/card-extensions-field.md`
- `references/sillytavern-plugins.md`
- `references/vectorization.md`
- `references/sillytavern-import-contract.md`: exact 1.18 embedded-book keys, strict JSON encoding, labels, and activation semantics.
- `references/prompt-placement.md`
- `references/context-budget-pruning.md`; `references/custom-pipeline-mode.md` for conversational/custom routing; `references/selective-regeneration.md` for UID-scoped rewrites; `references/source-sync.md`, `references/revision-history.md`, `references/multi-lorebook-packages.md`, `references/shared-state-summaries.md`, and `references/runtime-verification.md` for Batch 22 lifecycle/runtime operations
- `references/dynamic-state-variation.md`
- `references/runtime-target-adapter.md`
- `references/extension-adapters.md`: source-pinned Quick Reply, Regex, Vector Storage, Timed Effects, MVU, and EJS asset serialization.
- `references/charx-format.md`
- `references/behavioral-testdrive.md`: predicted activation, controlled generation, and voice/knowledge-boundary review; `references/entry-naming.md` covers the frozen terminology dictionary and canonical-form boundary.
- `references/settings-presets.md`: allowlisted portable project settings; explicit current-build choices override imported preset defaults.
- `references/build-templates.md`: reusable guided-setup defaults; templates prefill normal pages but never skip or complete them.
- `references/dashboard-artifacts.md`: renderer-neutral health, graph, source-coverage, and progress projections.
## Script authority
Bundled scripts are deterministic authorities for their narrow contracts:

- `init_build.py`: unique workspace, mode routing, staged worker kit, and safe preset defaulting. `setup_state.py` / `build_template.py`: resumable guided setup plus reusable prefill-only template validation/export. `settings_preset.py`: allowlisted post-menu preset validate/export contract. `wb_operations.py`: host-neutral named operation surface over existing deterministic CLIs.
- `creator_notes_stats.py`: generated Creator Notes lorebook stats & recommended-settings block (upsert and staleness check). `write_discovery_approval.py`: the only sanctioned way to construct discovery approval files (see `references/discovery-approvals.md`).
- `source_probe.py`: additive sitemap/API/category/search/link enumeration.
- `discovery_plan.py`: independent metrics, cost-balanced bird assignments, and verification passes.
- `record_discovery_runtime.py`: parent-observed discovery child receipts. `dispatch_observation.py`: host-neutral observation vocabulary shared by runtime producers/consumers.
- `discovery_gate.py`: URL ownership, bounded source-set coverage, evidence merge, and saturation.
- `discovery_recovery.py`: exact recovery and additional verification assignments.
- `audit_plan.py`: exact Compass/Weaver/Scout/Warden assignments and shared audit-run ID.
- `record_audit_runtime.py`: parent-observed auditor child receipts.
- `audit_gate.py`: four-lens result/runtime proof.
- `phase_gate.py`: planning, evidence, audit, and phase receipts.
- `merge_phases.py`: lossless stable-ID merge with CCv3-native identities.
- `validate_output.py`: layered JSON validation.
- `validate_persona.py`: plaintext persona validation.
- `repair_extensions.py`: conservative normalization.
- `validate_findings.py`: legacy/plaintext findings binding.
- `verify_patches.py`: exact patch verification; with `--before`, also checks for collateral damage (unknown-field or extension loss) beyond what the patch log itself accounts for.
- `change_set.py`: read-only manifest change-set computation: changed/neighbour-affected UIDs and whether a change is structural (forces full re-baseline) or eligible for amendment. `selective_regeneration.py`: exact UID scope, scoped invalidation, replacement, and untouched-hash proof.
- `artifact_edit.py`: the sanctioned way to edit an existing lorebook artifact: set-field, add-entry, remove-entry, move-depth, retag-keys. Atomic; preserves unknown fields, extension namespaces, and key order. `lock_contract.py`: sole authority for author locks and ownership.
- `artifact_diff.py`: structural before/after diff for any lorebook artifact: added/removed/changed UIDs, unknown-field loss, extension-namespace loss, key-order changes, moved entries.
- `capability_tiers.py`: reports an artifact's tier (Unbound/Legacy-bound/Bound) up front, from its provenance marker and, optionally, a live matching build workspace.
- `png_card.py`: read/write a card's chara/ccv3 tEXt chunk in a PNG container. Pure stdlib; the image carrier is preserved byte-for-byte on write. Optional stdlib-only placeholder generation when no carrier image exists yet.
- `build_charx.py`: fully validated portable CHARX package.
- `card_shell_contract.py` / `architecture_gate.py`: card-field ownership and output routing.
- `character_contract.py`: identity, behavior, state, and relationship ownership.
- `era_router_contract.py`: legacy Scenario-routed era isolation and temporal reach.
- `era_root_contract.py`: era-root token gating, cascade levels, inclusion groups, and required runtime settings.
- `soul_contract.py`: soul profile binding, runtime guide placement, and corpus-wide prose checks.
- `sillytavern_install.py`: read-only install reader: locate, settings preflight, world/keyword collisions, extensions, fixture capture.
- `repair_loop_guard.py`: halts a gate after repeated identical failures so an unattended repair loop cannot burn budget.
- `debug_log.py`: capture failing commands with their reproduction steps; report and export a shareable log. `diagnostics_bundle.py`: privacy-first public support ZIP of state shape, receipt metadata/hashes, scrubbed gate output, and capabilities; raw generated content is opt-in.
- `verification_triage.py`: verification priority by blast radius, confidence labels, de-risk policy, cost projection.
- `gate_telemetry.py`: gate convergence by model, and generation batches partitioned by dependency density. `model_routing.py`: frozen discovery/generation/audit routes plus OpenClaw `resolvedModel` verification.
- `expression_assets.py`: expression prompt set, CCv3 emotion descriptors, and CHARX member mapping.
- `activation_map_gate.py` / `planning_gate.py`: manifest, activation graph, and assignment-map authority. `world_index.py`: renders and validates the optional constant world-index roster from the manifest. `dashboard_artifacts.py`: renderer-neutral projections over existing build contracts.
- `placement_contract.py`: purpose-based placement and influence mapping.
- `delivery_gate.py`: final content-bound release decision and structured audit seal.
- `pipeline_stage_gate.py`: ordered SHA-256 stage ledger; blocks skipped, stale, or reordered workflow transitions.
- `entry_naming.py` / `terminology_dictionary.py`: semantic labels plus the project-wide frozen canonical spelling/alias/title dictionary and hash-bound receipts.
- `entry_cycle_gate.py`: enforce research-one/write-one sequencing, checkpoint budget limits, and lineage.
- `budget_contract.py`: freeze profiles, estimate pressure, simulate activation, and validate planning/output.
- `dynamic_state_contract.py`: freeze optional behavior, enforce protected defaults, slice assignments, and reject output drift.
- `runtime_target_adapter.py`: import/export complete semantic IR, validate emitted targets, report approved loss, reopen outputs, and bind adapter receipts.
- `extension_adapter.py`: source-pinned target serializers for Quick Replies, Regex, Vector Storage, Timed Effects, MVU, and EJS; never installs extensions or mutates global settings. `behavioral_testdrive.py`: hash-bound predicted-context generation/review orchestration; diagnostic only. `activation_test_corpus.py`: persistent positive/negative predicted-activation regression oracle; never a second activation engine. `decision_log.py`: append-only Guided Mode decision reuse/migration; never model-facing content.
- `sillytavern_import_probe.py`: strict JSON.parse-equivalent encoding plus embedded-card, native-World-Info, wrapper-route, and active-setting compatibility probe. `compatibility_check.py`: claim-level upstream/local drift detector for named SillyTavern compatibility baselines; never certifies a new version.
- `pruning_receipt.py`: bind before/after reductions, affected UIDs, impacts, hashes, and protected-removal approvals.
- `lineage_invalidate.py`: archive stale downstream artifacts after an upstream lineage change.
- `integration_acceptance.py`: route-level pipeline and deterministic acceptance binding.
- `first_time_setup.py`: consent-gated Docker/native-Python research-stack installation and startup registration.
- `ensure_research_stack.py`: restart/repair helper used at login and before research.
- `searxng_preflight.py`: OpenClaw-version, SearXNG, and bound research-egress health gate.
A model assertion cannot override a non-zero script exit code.
### Worker naming
Assign workers from this stable pool in order: **Raven, Magpie, Wren, Finch, Sparrow, Robin, Heron, Lark, Swift, Owl, Hawk, Falcon, Crow, Jay, Kestrel**. The readable bird name goes in `worker` and the `sessions_spawn` `label`. `taskName`, assignment ID, and filename slug always use the lowercase slug form of the same name (for example worker **Raven** → `taskName` `wb_r1_raven`, file `wb_r1_raven.json`), because OpenClaw requires `taskName` to match `[a-z][a-z0-9_-]{0,63}`; an uppercase or spaced name like `Raven` is rejected. Never use opaque UUID-like worker labels in user-visible logs. If more than fifteen workers are needed, reuse the pool with an explicit round suffix such as label `Raven R2` and slug `raven-r2`. Recovery workers keep the next available bird name or a clear suffix such as label `Wren Recovery 1`, slug `wren-recovery-1`.
